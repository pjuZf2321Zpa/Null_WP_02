<?php
/*
Template Name: 100% Width
*/

get_header(); ?>

<?php while ( have_posts() ) : the_post(); ?>

    <div class="page_full_width">
        <div class="entry-content">
            <?php the_content(); ?>
			<div class="clr"></div>
        </div><!-- .entry-content -->
    </div>

<?php endwhile; // end of the loop. ?>

<?php if( getbowtied_has_light_footer() || getbowtied_has_dark_footer() ) { ?>
	<div class="gbtr_widgets_footer_wrapper">
		<div class="trigger-footer-widget-area">
			<i class="getbowtied-icon-more-retailer"></i>
		</div>
		<?php
		get_template_part("light_footer");
		get_template_part("dark_footer");
		?>
	</div>
<?php } ?>

<?php get_footer(); ?>
