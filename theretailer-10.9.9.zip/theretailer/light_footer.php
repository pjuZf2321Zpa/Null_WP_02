<?php if( getbowtied_has_light_footer() ) { ?>

    <div class="gbtr_light_footer_wrapper">
        <div class="tr_content_wrapper">
        	<div class="grid_<?php echo esc_attr( GBT_Opt::getOption( 'light_footer_layout', '4col' ) ); ?>">
            	<?php dynamic_sidebar('widgets_light_footer'); ?>
            </div>
        </div>
    </div>

<?php } ?>
