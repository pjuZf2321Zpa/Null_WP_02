jQuery(function($) {

	"use strict";

	$(document).trigger("enhance");

	// progress bar
	if( theretailer_options.progress_bar ) {
		NProgress.configure({ parent: ".progress-bar-wrapper", speed: 400, minimum: 0.3 });
		NProgress.start();
		NProgress.done();
		setTimeout(function(){
			$(".shop_top, .product_top, .category_header, .global_content_wrapper, .page_full_width").css("opacity", "1");
		},600);
	}

	$('.page_sidebar.page_sidebar_horizontal > br').remove();
});
