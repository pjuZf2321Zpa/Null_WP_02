jQuery(function($) {

	"use strict";

	if( $('.products_slider.up_sells_section').length ) {

		var slides = 4;
		var medium_slides = 3;
		if( theretailer_options.related_products_number < 4  ) {
			slides = theretailer_options.related_products_number;
		}
		if( theretailer_options.related_products_number < 3  ) {
			medium_slides = theretailer_options.related_products_number;
		}

		if( $('.products_slider.up_sells_section').parents('.product').hasClass('product-layout-2') ) {
			slides = 3;
			medium_slides = 3;
			if( theretailer_options.related_products_number < 3  ) {
				slides = theretailer_options.related_products_number;
				medium_slides = theretailer_options.related_products_number;
			}
		}

		// Up-Sell Products
		var upsellProductsSlider = new Swiper( '.products_slider.up_sells_section .swiper-container', {
			slidesPerView: slides,
			loop: false,
			centerInsufficientSlides: true,
			spaceBetween: 40,
			breakpoints: {
				0: {
					slidesPerView: 2,
				},
				640: {
					slidesPerView: medium_slides,
				},
				959: {
					slidesPerView: slides,
				}
			},
			navigation: {
				nextEl: '.products_slider.up_sells_section .slider-button-next',
				prevEl: '.products_slider.up_sells_section .slider-button-prev',
			},
			pagination: {
				el: '.products_slider.up_sells_section .swiper-pagination',
				dynamicBullets: true
			},
		});

		var swiper__slidecount = upsellProductsSlider.slides.length;
		var total_slides = slides;
		if( $(window).innerWidth() <= 640 ) {
			total_slides = 2;
		} else if( $(window).innerWidth() > 641 && $(window).innerWidth() <= 959 ) {
			total_slides = medium_slides;
		}

		if ( swiper__slidecount <= total_slides ) {
			$('.products_slider.up_sells_section .slider-button-prev, .products_slider.up_sells_section .slider-button-next').remove();
			$('.products_slider.up_sells_section .swiper-wrapper').addClass( "disabled" );
			$('.products_slider.up_sells_section .swiper-pagination').addClass( "disabled" );
		}
	}

	if( $('.products_slider.related_products_section').length ) {

		var slides = 4;
		var medium_slides = 3;
		if( theretailer_options.related_products_number < 4  ) {
			slides = theretailer_options.related_products_number;
		}
		if( theretailer_options.related_products_number < 3  ) {
			medium_slides = theretailer_options.related_products_number;
		}

		if( $('.products_slider.related_products_section').parents('.product').hasClass('product-layout-2') ) {
			slides = 3;
			medium_slides = 3;
			if( theretailer_options.related_products_number < 3  ) {
				slides = theretailer_options.related_products_number;
				medium_slides = theretailer_options.related_products_number;
			}
		}

		// Related Products
		var relatedProductsSlider = new Swiper( '.products_slider.related_products_section .swiper-container', {
			slidesPerView: slides,
			loop: false,
			centerInsufficientSlides: true,
			spaceBetween: 40,
			breakpoints: {
				0: {
					slidesPerView: 2,
				},
				640: {
					slidesPerView: medium_slides,
				},
				959: {
					slidesPerView: slides,
				}
			},
			navigation: {
				nextEl: '.products_slider.related_products_section .slider-button-next',
				prevEl: '.products_slider.related_products_section .slider-button-prev',
			},
			pagination: {
				el: '.products_slider.related_products_section .swiper-pagination',
				dynamicBullets: true
			},
		});

		var swiper__slidecount = relatedProductsSlider.slides.length;
		var total_slides = slides;
		if( $(window).innerWidth() <= 640 ) {
			total_slides = 2;
		} else if( $(window).innerWidth() > 641 && $(window).innerWidth() <= 959 ) {
			total_slides = medium_slides;
		}

		if ( swiper__slidecount <= total_slides ) {
			$('.products_slider.related_products_section .slider-button-prev, .products_slider.related_products_section .slider-button-next').remove();
			$('.products_slider.related_products_section .swiper-wrapper').addClass( "disabled" );
			$('.products_slider.related_products_section .swiper-pagination').addClass( "disabled" );
		}
	}
});
