<?php

if ( ! function_exists( 'gbt_fs' ) ) {
	function gbt_fs() {
		global $gbt_fs;

		if ( ! isset( $gbt_fs ) ) {
			$config_path = get_template_directory() . '/dashboard/config.php';
			$sdk_path    = get_template_directory() . '/dashboard/inc/freemius/start.php';
			$config      = file_exists( $config_path ) ? include $config_path : array();
			$freemius    = $config['supported_themes'][ get_template() ]['freemius'] ?? null;

			if ( ! $freemius || ! file_exists( $sdk_path ) ) {
				$gbt_fs = false;
			} else {
				/*
				 * Workaround: skip our start.php if Freemius is already loaded.
				 * start.php fs_redirect()s to the same URL when the theme SDK is
				 * newer than a plugin's — themes can't win load order → redirect loop.
				 * Still call fs_dynamic_init() on the shared SDK.
				 *
				 * Revert when Freemius fixes this in start.php: always
				 * require_once $sdk_path; then fs_dynamic_init( ... );
				 */
				if ( ! class_exists( 'Freemius' ) ) {
					require_once $sdk_path;
				}

				$gbt_fs = fs_dynamic_init( array(
					'id'                  => $freemius['id'],
					'slug'                => $freemius['slug'],
					'premium_slug'        => $freemius['slug'],
					'type'                => 'theme',
					'public_key'          => $freemius['public_key'],
					'is_premium'          => true,
					'has_premium_version' => true,
					'is_premium_only'     => false,
					'has_addons'          => false,
					'has_paid_plans'      => true,
					'is_org_compliant'    => false,
					'menu'                => array(
						'slug'        => 'getbowtied-dashboard',
						'first-path'  => 'admin.php?page=getbowtied-dashboard&require_license=false',
						'contact'     => false,
						'support'     => false,
						'account'     => false,
						'pricing'     => false,
						'addons'      => false,
						'affiliation' => false,
					),
					'enable_anonymous'    => true,
					'anonymous_mode'      => true,
				) );
			}
		}

		return $gbt_fs;
	}
}

require_once get_template_directory() . '/dashboard/inc/fs-init.php';

gbt_fs();
do_action( 'gbt_fs_loaded' );

// Helpers
include_once( get_template_directory() . '/functions/helpers/helpers.php' );

// Admin Setup
if ( is_admin() || ( defined('WP_CLI') && WP_CLI ) ) {
	include_once( get_template_directory() . '/functions/admin-setup.php' );
	include_once( get_template_directory() . '/dashboard/index.php' );
}

// Customizer
include_once( get_template_directory() . '/inc/customizer/class/class-fonts.php' );
include_once( get_template_directory() . '/inc/customizer/class/read-options.php' );
include_once( get_template_directory() . '/inc/customizer/backend.php' );
include_once( get_template_directory() . '/inc/customizer/frontend.php' );

// Metaboxes
include_once( get_template_directory() . '/inc/metaboxes/page.php' );

// Styles
include_once( get_template_directory() . '/functions/enqueue/styles.php' );
include_once( get_template_directory() . '/functions/enqueue/admin-styles.php' );

include_once( get_template_directory() . '/inc/custom-styles/custom-styles.php' );

// Scripts
include_once( get_template_directory() . '/functions/enqueue/scripts.php' );
include_once( get_template_directory() . '/functions/enqueue/admin-scripts.php' );

// Theme Settings
include_once( get_template_directory() . '/functions/theme-setup.php' );

// Widget Areas
include_once( get_template_directory() . '/functions/wp/widget-areas.php' );

// WooCommerce
if( TR_WOOCOMMERCE_IS_ACTIVE ) {
	include_once( get_template_directory() . '/functions/wc/actions.php' );
	include_once( get_template_directory() . '/functions/wc/custom.php' );
	include_once( get_template_directory() . '/functions/wc/filters.php' );
}

// WPBakery Page Builder
if( TR_WPBAKERY_IS_ACTIVE ) {
	include_once( get_template_directory() . '/functions/wb/wpbakery-setup.php' );
}

// Revolution Slider
if(function_exists('set_revslider_as_theme')) {
	set_revslider_as_theme();
}
