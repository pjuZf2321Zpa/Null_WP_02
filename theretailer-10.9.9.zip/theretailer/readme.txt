=== The Retailer ===
Contributors: Get Bowtied
Author: Get Bowtied
Author URI: https://getbowtied.com/
Theme URI: https://theretailer-demo.getbowtied.com/
Tags: e-commerce, left-sidebar, right-sidebar, custom-colors, custom-header, custom-menu, featured-images, full-width-template, threaded-comments, blog, rtl-language-support, footer-widgets, sticky-post, theme-options, editor-style
Requires at least: 5.0
Tested up to: 7.1.2
Requires PHP: 7.4.1
Stable tag: 10.9.9
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: theretailer
Domain Path: /languages/

The Retailer is one of top selling eCommerce theme for WordPress and WooCommerce.

== Description ==

The Retailer is one of top selling eCommerce theme for WordPress and WooCommerce.

== Installation ==

1. Upload the `theretailer` folder to the `/wp-content/themes/` directory.
2. Activate the theme from the WordPress Dashboard under Appearance > Themes.
3. Install/enable any required plugins as prompted by the theme.

== Screenshots ==

1. Main screenshot
   screenshot.png

== Changelog ==

= 10.9.9 =
* Notice: The Retailer ThemeForest version has reached end of life. Updates on ThemeForest stop after October 1, 2026. From v11, new features, updates, and support continue on our own platform. Convert your ThemeForest purchase code into a new license key in your WordPress dashboard. Questions? Reach us at https://getbowtied.com/support/
