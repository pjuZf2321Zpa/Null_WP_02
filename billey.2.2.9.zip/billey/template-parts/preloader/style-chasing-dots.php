<?php
defined( 'ABSPATH' ) || exit;
?>
<div class="sk-wrap sk-chasing-dots">
	<div class="sk-child sk-dot1"></div>
	<div class="sk-child sk-dot2"></div>
</div>
