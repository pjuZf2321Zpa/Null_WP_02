<?php
defined( 'ABSPATH' ) || exit;
?>
<div class="sk-wrap sk-double-bounce">
	<div class="sk-child sk-double-bounce1"></div>
	<div class="sk-child sk-double-bounce2"></div>
</div>
