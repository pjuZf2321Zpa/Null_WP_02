<?php
defined( 'ABSPATH' ) || exit;
?>
<div class="sk-wrap sk-rotating-plane"></div>
