<?php
defined( 'ABSPATH' ) || exit;
?>
<div class="sk-wrap sk-spinner sk-spinner-pulse"></div>
