<?php
defined( 'ABSPATH' ) || exit;
?>
