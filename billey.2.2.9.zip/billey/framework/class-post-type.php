<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Billey_Post_Type' ) ) {
	class Billey_Post_Type {
		protected function build_extra_terms_query( $query_args, $taxonomies ) {
			if ( ! is_string( $taxonomies ) || '' === trim( $taxonomies ) ) {
				return $query_args;
			}

			$terms       = explode( ', ', $taxonomies );
			$tax_queries = array(); // List of taxonomies.

			if ( ! isset( $query_args['tax_query'] ) ) {
				$query_args['tax_query'] = array();

				foreach ( $terms as $term ) {
					$tmp = explode( ':', $term, 2 );
					if ( count( $tmp ) < 2 ) {
						continue;
					}
					$taxonomy  = sanitize_key( $tmp[0] );
					$term_slug = sanitize_title( $tmp[1] );
					if ( '' === $taxonomy || '' === $term_slug || ! taxonomy_exists( $taxonomy ) ) {
						continue;
					}
					if ( ! isset( $tax_queries[ $taxonomy ] ) ) {
						$tax_queries[ $taxonomy ] = array(
							'taxonomy' => $taxonomy,
							'field'    => 'slug',
							'terms'    => array( $term_slug ),
						);
					} else {
						$tax_queries[ $taxonomy ]['terms'][] = $term_slug;
					}
				}
				if ( empty( $tax_queries ) ) {
					unset( $query_args['tax_query'] );

					return $query_args;
				}
				$query_args['tax_query']             = array_values( $tax_queries );
				$query_args['tax_query']['relation'] = 'AND';
			} else {
				foreach ( $terms as $term ) {
					$tmp = explode( ':', $term, 2 );
					if ( count( $tmp ) < 2 ) {
						continue;
					}
					$taxonomy  = sanitize_key( $tmp[0] );
					$term_slug = sanitize_title( $tmp[1] );
					if ( '' === $taxonomy || '' === $term_slug || ! taxonomy_exists( $taxonomy ) ) {
						continue;
					}

					foreach ( $query_args['tax_query'] as $key => $query ) {
						if ( is_array( $query ) ) {
							if ( $query['taxonomy'] == $taxonomy ) {
								$query_args['tax_query'][ $key ]['terms'][] = $term_slug;
								break;
							} else {
								$query_args['tax_query'][] = array(
									'taxonomy' => $taxonomy,
									'field'    => 'slug',
									'terms'    => array( $term_slug ),
								);
							}
						}
					}
				}
			}

			return $query_args;
		}
	}
}
