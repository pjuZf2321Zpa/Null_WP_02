<?php
defined( 'ABSPATH' ) || exit;

/**
 * Plugin installation and activation for WordPress themes
 */
if ( ! class_exists( 'Billey_Register_Plugins' ) ) {
	class Billey_Register_Plugins {

		protected static $instance = null;

		const GOOGLE_DRIVER_API = 'AIzaSyDXOs0Bxx-uBEA4fH4fzgoHtl64g0RWv-g';

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		function initialize() {
			add_filter( 'insight_core_tgm_plugins', array( $this, 'register_required_plugins' ) );
		}

		public function register_required_plugins( $plugins ) {
			/*
			 * Array of plugin arrays. Required keys are name and slug.
			 * If the source is NOT from the .org repo, then source is also required.
			 */
			$new_plugins = array(
				array(
					'name'     => esc_html__( 'Insight Core', 'billey' ),
					'slug'     => 'insight-core',
					'source'   => $this->get_plugin_google_driver_url( '1yqn_qJTkbrbRCQQoQgWRIppMLmBx97TO' ),
					'version'  => '2.8.4',
					'required' => true,
				),
				array(
					'name'     => esc_html__( 'Elementor', 'billey' ),
					'slug'     => 'elementor',
					'required' => true,
				),
				array(
					'name'        => esc_html__( 'ThemeMove Addons For Elementor', 'billey' ),
					'description' => 'Additional functions for Elementor',
					'slug'        => 'tm-addons-for-elementor',
					'source'      => $this->get_plugin_google_driver_url( '1HPKaI5nUpbMxwDsuqOhnY2uLcXNEHJIT' ),
					'version'     => '2.1.2',
				),
				array(
					'name'    => esc_html__( 'Revolution Slider', 'billey' ),
					'slug'    => 'revslider',
					'source'  => $this->get_plugin_google_driver_url( '1Tz4kxUDfwRnEkTvEESJpUsdxPhhhUyJN' ),
					'version' => '6.7.58',
				),
				array(
					'name' => esc_html__( 'MailChimp for WordPress', 'billey' ),
					'slug' => 'mailchimp-for-wp',
				),
				array(
					'name' => esc_html__( 'WooCommerce', 'billey' ),
					'slug' => 'woocommerce',
				),
				array(
					'name' => esc_html__( 'WPC Smart Compare for WooCommerce', 'billey' ),
					'slug' => 'woo-smart-compare',
				),
				array(
					'name' => esc_html__( 'WPC Smart Wishlist for WooCommerce', 'billey' ),
					'slug' => 'woo-smart-wishlist',
				),
				array(
					'name' => esc_html__( 'Booking.com Official Search Box', 'billey' ),
					'slug' => 'bookingcom-official-searchbox',
				),
			);

			$plugins = array_merge( $plugins, $new_plugins );

			return $plugins;
		}

		public function get_plugin_google_driver_url( $file_id ) {
			return "https://www.googleapis.com/drive/v3/files/{$file_id}?alt=media&key=" . self::GOOGLE_DRIVER_API;
		}
	}

	Billey_Register_Plugins::instance()->initialize();
}
