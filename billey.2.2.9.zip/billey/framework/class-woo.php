<?php
defined( 'ABSPATH' ) || exit;

/**
 * Custom functions, filters, actions for WooCommerce.
 */
if ( ! class_exists( 'Billey_Woo' ) ) {
	class Billey_Woo extends Billey_Post_Type {

		protected static $instance = null;
		const MINIMUM_PLUGIN_VERSION = '4.0.2';

		public static $product_image_size_width = '';
		public static $product_image_size_height = '';
		public static $product_image_crop = true;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			// Do nothing if Woo plugin not activated.
			if ( ! $this->is_activated() ) {
				return;
			}

			add_filter( 'woocommerce_add_to_cart_fragments', array( $this, 'header_add_to_cart_fragment' ) );

			/**
			 * Begin hooks for checkout page.
			 */
			add_filter( 'woocommerce_checkout_fields', array( $this, 'override_checkout_fields' ) );
			/**
			 * End hooks for checkout page.
			 */

			add_action( 'wp_head', array( $this, 'wp_init' ) );

			// Move nav count to link.
			add_filter( 'woocommerce_layered_nav_term_html', array(
				$this,
				'move_layered_nav_count_inside_link',
			), 10, 4 );

			/**
			 * Begin hooks for shop archive.
			 */
			add_filter( 'loop_shop_per_page', array( $this, 'loop_shop_per_page' ), 20 );

			add_filter( 'woocommerce_pagination_args', array( $this, 'override_pagination_args' ) );

			// Add link to the product title of loop.
			remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
			add_action( 'woocommerce_shop_loop_item_title', array(
				$this,
				'template_loop_product_title',
			), 10 );

			// Move price before title.
			remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
			add_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_price', 5 );
			/**
			 * End hooks for shop archive.
			 */

			/**
			 * Begin hooks for single product.
			 */
			// Move product badge before title
			remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
			add_action( 'woocommerce_single_product_summary', 'woocommerce_show_product_sale_flash', 3 );

			// Move product rating after product price.
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating' );
			add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 15 );

			// Add sharing list.
			add_action( 'woocommerce_share', array( $this, 'entry_sharing' ) );

			// Move sharing to below description.
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50 );
			add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 25 );

			// Remove tab heading in on single product pages.
			add_filter( 'woocommerce_product_description_heading', '__return_empty_string' );
			add_filter( 'woocommerce_product_additional_information_heading', '__return_empty_string' );

			// Change review avatar size.
			add_filter( 'woocommerce_review_gravatar_size', array( $this, 'woocommerce_review_gravatar_size' ) );

			// Check old version installed.
			if ( defined( 'WOOSCP_VERSION' ) || ( defined( 'WOOSC_VERSION' ) && version_compare( WOOSC_VERSION, self::MINIMUM_PLUGIN_VERSION, '<' ) ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_compare_plugin_version' ] );
			}

			// Hide default smart compare & smart wishlist button.
			add_filter( 'woosw_button_position_archive', '__return_zero_string' );
			add_filter( 'woosw_button_position_single', '__return_zero_string' );
			add_filter( 'woosc_button_position_archive', '__return_false' );
			add_filter( 'woosc_button_position_single', '__return_false' );

			// Add compare & wishlist button again.
			add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'get_wishlist_button_template' ) );
			add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'get_compare_button_template' ) );

			// Add div tag wrapper quantity.
			add_action( 'woocommerce_before_add_to_cart_quantity', array( $this, 'add_quantity_open_wrapper' ) );
			add_action( 'woocommerce_after_add_to_cart_quantity', array( $this, 'add_quantity_close_wrapper' ) );

			// Provide the theme gallery markup for variations that own images (variation image / variation gallery).
			add_filter( 'woocommerce_available_variation', array( $this, 'add_variation_gallery_data' ), 20, 3 );
			/**
			 * End hooks for single product.
			 */

			/**
			 * Begin hooks for cart page.
			 */
			// Check for empty-cart get param to clear the cart.
			add_action( 'init', array( $this, 'woocommerce_clear_cart_url' ) );

			// Edit cart empty messages.
			remove_action( 'woocommerce_cart_is_empty', 'wc_empty_cart_message', 10 );
			add_action( 'woocommerce_cart_is_empty', array( $this, 'change_empty_cart_messages' ), 10 );
			/**
			 * End hook for cart page.
			 */

			/**
			 * Begin ajax requests.
			 */
			// Load more for widget Product.
			add_action( 'wp_ajax_product_infinite_load', array( $this, 'product_infinite_load' ) );
			add_action( 'wp_ajax_nopriv_product_infinite_load', array( $this, 'product_infinite_load' ) );

			// Quick view feature.
			add_action( 'wp_ajax_product_quick_view', array( $this, 'get_quick_view_content' ) );
			add_action( 'wp_ajax_nopriv_product_quick_view', array( $this, 'get_quick_view_content' ) );
			/**
			 * End ajax requests.
			 */

			add_action( 'after_switch_theme', array( $this, 'change_product_image_size' ), 2 );
			add_action( 'after_setup_theme', array( $this, 'modify_theme_support' ), 10 );

			// Fix Cart fragments issue with WC 7.8.0
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_wc_cart_fragments' ), 99 );

			add_action( 'init', array( $this, 'remove_wc_register_blocks' ), 1 );
		}

		/**
		 * This WC action hook make Customize Preview loading freeze.
		 * Temp remove it in customize preview
		 *
		 * @return void
		 */
		public function remove_wc_register_blocks() {
			if ( is_customize_preview() ) {
				billey_remove_filters_for_anonymous_class( 'init', 'Automattic\WooCommerce\Blocks\BlockTypesController', 'register_blocks' );
			}
		}

		function enqueue_wc_cart_fragments() {
			wp_enqueue_script( 'wc-cart-fragments' );
		}

		/**
		 * Check woocommerce plugin active
		 *
		 * @return boolean true if plugin activated
		 */
		function is_activated() {
			if ( class_exists( 'WooCommerce' ) ) {
				return true;
			}

			return false;
		}

		function woocommerce_clear_cart_url() {
			global $woocommerce;

			if ( isset( $_GET['empty-cart'] ) ) {
				$woocommerce->cart->empty_cart();
			}
		}

		function change_empty_cart_messages() {
			?>
			<div class="empty-cart-messages">
				<div class="empty-cart-icon">
					<span class="fa-light fa-shopping-cart"></span>
				</div>
				<h2 class="empty-cart-heading"><?php esc_html_e( 'Your cart is currently empty.', 'billey' ); ?></h2>
				<p class="empty-cart-text"><?php esc_html_e( 'You may check out all the available products and buy some in the shop.', 'billey' ); ?></p>
			</div>
			<?php
		}

		function add_quantity_open_wrapper() {
			?>
			<div class="quantity-button-wrapper">
			<label><?php esc_html_e( 'Quantity', 'billey' ); ?></label>
			<?php
		}

		function add_quantity_close_wrapper() {
			global $product;

			echo wc_get_stock_html( $product ); // WPCS: XSS ok.
			?>
			</div>
			<?php
		}

		function entry_sharing() {
			if ( Billey::setting( 'single_product_sharing_enable' ) === '1' && class_exists( 'InsightCore' ) ) :
				$social_sharing = Billey::setting( 'social_sharing_item_enable' );
				if ( ! empty( $social_sharing ) ) {
					?>
					<div class="entry-product-share">
						<div class="inner">
							<?php Billey_Templates::get_sharing_list(); ?>
						</div>
					</div>
					<?php
				}
			endif;
		}

		/*
		 * Change woocommerce product image size on first time switch to this theme.
		 */
		public function change_product_image_size() {
			global $pagenow;

			if ( ! isset( $_GET['activated'] ) || $pagenow != 'themes.php' ) {
				return;
			}

			$count = get_option( 'billey_switch_theme_count' );

			// Do it for first time.
			if ( ! $count || $count < 2 ) {
				// Update single image width
				//update_option( 'woocommerce_single_image_width', 760 );

				// Update thumbnail image width.
				update_option( 'woocommerce_thumbnail_image_width', 480 );

				// Update thumbnail cropping ratio.
				update_option( 'woocommerce_thumbnail_cropping', 'custom' );
				update_option( 'woocommerce_thumbnail_cropping_custom_width', 4 );
				update_option( 'woocommerce_thumbnail_cropping_custom_height', 5 );
			}
		}

		/**
		 * Modify image width theme support.
		 */
		function modify_theme_support() {
			/*$theme_support                          = get_theme_support( 'woocommerce' );
			$theme_support                          = is_array( $theme_support ) ? $theme_support[0] : array();
			$theme_support['single_image_width']    = 760;
			$theme_support['thumbnail_image_width'] = 400;

			remove_theme_support( 'woocommerce' );*/
			add_theme_support( 'woocommerce' );
		}

		/**
		 * Returns true if on a page which uses WooCommerce templates exclude single product (cart and checkout are standard pages with shortcodes and which are also included)
		 *
		 * @access public
		 * @return bool
		 */
		function is_woocommerce_page_without_product() {
			if ( ! $this->is_activated() ) {
				return false;
			}

			if ( is_shop() || is_product_taxonomy() || is_post_type_archive( 'product' ) ) {
				return true;
			}

			$the_id = get_the_ID();

			if ( $the_id !== false ) {
				$woocommerce_keys = array(
					'woocommerce_shop_page_id',
					'woocommerce_terms_page_id',
					'woocommerce_cart_page_id',
					'woocommerce_checkout_page_id',
					'woocommerce_pay_page_id',
					'woocommerce_thanks_page_id',
					'woocommerce_myaccount_page_id',
					'woocommerce_edit_address_page_id',
					'woocommerce_view_order_page_id',
					'woocommerce_change_password_page_id',
					'woocommerce_logout_page_id',
					'woocommerce_lost_password_page_id',
				);

				foreach ( $woocommerce_keys as $wc_page_id ) {
					if ( $the_id == get_option( $wc_page_id, 0 ) ) {
						return true;
					}
				}
			}

			return false;
		}

		/**
		 * Returns true if on a page which uses WooCommerce templates (cart and checkout are standard pages with shortcodes and which are also included)
		 *
		 * @access public
		 * @return bool
		 */
		function is_woocommerce_page() {
			if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
				return true;
			}

			$woocommerce_keys = array(
				"woocommerce_shop_page_id",
				"woocommerce_terms_page_id",
				"woocommerce_cart_page_id",
				"woocommerce_checkout_page_id",
				"woocommerce_pay_page_id",
				"woocommerce_thanks_page_id",
				"woocommerce_myaccount_page_id",
				"woocommerce_edit_address_page_id",
				"woocommerce_view_order_page_id",
				"woocommerce_change_password_page_id",
				"woocommerce_logout_page_id",
				"woocommerce_lost_password_page_id",
			);

			foreach ( $woocommerce_keys as $wc_page_id ) {
				if ( get_the_ID() == get_option( $wc_page_id, 0 ) ) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Returns true if on a archive product pages.
		 *
		 * @access public
		 * @return bool
		 */
		function is_product_archive() {
			if ( is_post_type_archive( 'product' ) || ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) ) {
				return true;
			}

			return false;
		}

		/**
		 * Custom product title instead of default product title
		 *
		 * @see woocommerce_template_loop_product_title()
		 */
		function template_loop_product_title() {
			?>
			<h2 class="woocommerce-loop-product__title">
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</h2>
			<?php
		}

		function loop_shop_per_page() {
			$number = Billey::setting( 'shop_archive_number_item' );
			if ( isset( $_GET['shop_archive_number_item'] ) && '' !== $_GET['shop_archive_number_item'] ) {
				$number = max( 1, absint( wp_unslash( $_GET['shop_archive_number_item'] ) ) );
			}

			if ( isset( $_GET['product_per_page'] ) && '' !== $_GET['product_per_page'] ) {
				$per_page = absint( wc_clean( wp_unslash( $_GET['product_per_page'] ) ) );

				return $per_page > 0 ? $per_page : max( 1, absint( $number ) );
			}

			return max( 1, absint( $number ) );
		}

		function override_pagination_args( $args ) {
			$args['prev_text'] = '<span class="fa-solid fa-angle-left"></span>' . esc_html__( 'Prev', 'billey' );
			$args['next_text'] = esc_html__( 'Next', 'billey' ) . '<span class="fa-solid fa-angle-right"></span>';

			return $args;
		}

		function woocommerce_review_gravatar_size() {
			return 108;
		}

		function wp_init() {

			if ( Billey::setting( 'single_product_tabs_enable' ) === '0' ) {
				remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
			}

			if ( Billey::setting( 'single_product_up_sells_enable' ) === '0' ) {
				remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
			}

			if ( Billey::setting( 'single_product_related_enable' ) === '0' ) {
				// Remove the related products output (the legacy woocommerce_related_products_args filter no longer exists).
				remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
			}

			// Remove Cross Sells from default position at Cart. Then add them back UNDER the Cart Table.
			remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
			if ( Billey::setting( 'shopping_cart_cross_sells_enable' ) === '1' ) {
				add_action( 'woocommerce_after_cart_table', 'woocommerce_cross_sell_display' );
			}

			if ( Billey::setting( 'shop_archive_sorting' ) !== '1' ) {
				remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
				remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
			} else {
				add_action( 'woocommerce_before_shop_loop', [ $this, 'add_shop_action_begin_wrapper' ], 15 );
				add_action( 'woocommerce_before_shop_loop', [ $this, 'add_shop_action_end_wrapper' ], 35 );
			}
		}

		function add_shop_action_begin_wrapper() {
			echo '<div class="archive-shop-actions row row-xs-center">';
		}

		function add_shop_action_end_wrapper() {
			echo '</div>';
		}

		/**
		 * Add placeholder for all fields.
		 *
		 * @param $fields
		 *
		 * @return mixed
		 */
		function override_checkout_fields( $fields ) {
			// Add placeholder for billing form.
			foreach ( $fields['billing'] as $field => $value ) {
				// If has label & not has placeholder.
				if ( ! empty( $fields['billing'][ $field ]['label'] ) && empty( $fields['billing'][ $field ]['placeholder'] ) ) {
					$fields['billing'][ $field ]['placeholder'] = $fields['billing'][ $field ]['label'];
				}
			}

			// Add placeholder for shipping form.
			foreach ( $fields['shipping'] as $field => $value ) {
				// If has label & not has placeholder.
				if ( ! empty( $fields['shipping'][ $field ]['label'] ) && empty( $fields['shipping'][ $field ]['placeholder'] ) ) {
					$fields['shipping'][ $field ]['placeholder'] = $fields['shipping'][ $field ]['label'];
				}
			}

			return $fields;
		}

		/**
		 * Ensure cart contents update when products are added to the cart via AJAX
		 * ========================================================================
		 *
		 * @param $fragments
		 *
		 * @return mixed
		 */
		function header_add_to_cart_fragment( $fragments ) {
			ob_start();
			$cart_html = $this->get_mini_cart();
			echo '' . $cart_html;
			$fragments['.mini-cart__button'] = ob_get_clean();

			return $fragments;
		}

		/**
		 * Get mini cart HTML
		 * ==================
		 *
		 * @return string
		 */
		function get_mini_cart() {
			global $woocommerce;
			$cart_url = '/cart';
			if ( isset( $woocommerce ) ) {
				$cart_url = wc_get_cart_url();
			}

			$cart_html = '';
			$qty       = WC()->cart->get_cart_contents_count();
			$cart_html .= '<a href="' . esc_url( $cart_url ) . '" class="mini-cart__button header-icon" title="' . esc_attr__( 'View your shopping cart', 'billey' ) . '">';
			$cart_html .= '<span class="mini-cart-icon" data-count="' . $qty . '"></span>';
			$cart_html .= '</a>';

			return $cart_html;
		}

		function render_mini_cart() {
			$header_type = Billey_Global::instance()->get_header_type();

			$enabled = Billey::setting( "header_style_{$header_type}_cart_enable" );

			if ( $this->is_activated() && in_array( $enabled, array( '1', 'hide_on_empty' ) ) ) {
				$classes = 'mini-cart';
				if ( $enabled === 'hide_on_empty' ) {
					$classes .= ' hide-on-empty';
				}
				?>
				<div id="mini-cart" class="<?php echo esc_attr( $classes ); ?>">
					<?php echo '' . $this->get_mini_cart(); ?>
					<div class="widget_shopping_cart_content"></div>
				</div>
			<?php }
		}

		/**
		 * @return string
		 */
		function get_percentage_price() {
			global $product;

			if ( $product->is_type( 'simple' ) || $product->is_type( 'external' ) ) {
				$_regular_price = $product->get_regular_price();
				$_sale_price    = $product->get_sale_price();

				$percentage = round( ( ( $_regular_price - $_sale_price ) / $_regular_price ) * 100 );

				return "-{$percentage}%";
			} else {
				return esc_html__( 'Sale !', 'billey' );
			}
		}

		function get_wishlist_button_template( $args = array() ) {
			if ( ( Billey::setting( 'shop_archive_wishlist' ) !== '1' ) || ! class_exists( 'WPCleverWoosw' ) ) {
				return;
			}

			global $product;
			$product_id = $product->get_id();

			$defaults = array(
				'show_tooltip'     => true,
				'tooltip_position' => 'top',
				'tooltip_skin'     => 'primary',
				'style'            => '01',
			);
			$args     = wp_parse_args( $args, $defaults );

			$_wrapper_classes = "product-action wishlist-btn style-{$args['style']}";

			if ( $args['show_tooltip'] === true ) {
				$_wrapper_classes .= ' hint--bounce';
				$_wrapper_classes .= " hint--{$args['tooltip_position']}";
				$_wrapper_classes .= " hint--{$args['tooltip_skin']}";
			}
			?>
			<div class="<?php echo esc_attr( $_wrapper_classes ); ?>"
			     aria-label="<?php esc_attr_e( 'Add to wishlist', 'billey' ) ?>">
				<?php echo do_shortcode( '[woosw id="' . $product_id . '" type="link"]' ); ?>
			</div>
			<?php
		}

		function get_compare_button_template( $args = array() ) {
			if ( Billey::setting( 'shop_archive_compare' ) !== '1' || wp_is_mobile() || ! class_exists( 'WPCleverWoosc' ) ) {
				return;
			}

			global $product;
			$product_id = $product->get_id();

			$defaults = array(
				'show_tooltip'     => true,
				'tooltip_position' => 'top',
				'tooltip_skin'     => 'primary',
				'style'            => '01',
			);
			$args     = wp_parse_args( $args, $defaults );

			$_wrapper_classes = "product-action compare-btn style-{$args['style']}";

			if ( $args['show_tooltip'] === true ) {
				$_wrapper_classes .= ' hint--bounce';
				$_wrapper_classes .= " hint--{$args['tooltip_position']}";
				$_wrapper_classes .= " hint--{$args['tooltip_skin']}";
			}
			?>
			<div class="<?php echo esc_attr( $_wrapper_classes ); ?>"
			     aria-label="<?php esc_attr_e( 'Compare', 'billey' ) ?>">
				<?php echo do_shortcode( '[woosc id="' . $product_id . '" type="link"]' ); ?>
			</div>
			<?php
		}

		function get_quick_view_button_template( $args = array() ) {
			if ( ( Billey::setting( 'shop_archive_quick_view' ) !== '1' ) || wp_is_mobile() ) {
				return;
			}

			global $product;
			$product_id = $product->get_id();

			$defaults = array(
				'show_tooltip'     => true,
				'tooltip_position' => 'top',
				'tooltip_skin'     => 'primary',
				'style'            => '01',
			);
			$args     = wp_parse_args( $args, $defaults );

			$_wrapper_classes = "product-action quick-view-btn style-{$args['style']}";

			if ( $args['show_tooltip'] === true ) {
				$_wrapper_classes .= ' hint--bounce';
				$_wrapper_classes .= " hint--{$args['tooltip_position']}";
				$_wrapper_classes .= " hint--{$args['tooltip_skin']}";
			}
			?>
			<div class="<?php echo esc_attr( $_wrapper_classes ); ?>"
			     aria-label="<?php echo esc_attr__( 'Quick view', 'billey' ) ?>"
			     data-pid="<?php echo esc_attr( $product_id ); ?>"
			     data-pnonce="<?php echo esc_attr( wp_create_nonce( 'woo_quick_view' ) ); ?>">
				<a class="quick-view-icon" href="#"></a>
			</div>
			<?php
		}

		public function get_quick_view_content() {
			check_ajax_referer( 'woo_quick_view', 'nonce' );

			if ( empty( $_POST['pid'] ) ) {
				wp_send_json_error( array( 'message' => esc_html__( 'Invalid product.', 'billey' ) ), 400 );
			}

			$product_id = absint( wp_unslash( $_POST['pid'] ) );

			if ( ! $product_id ) {
				wp_send_json_error( array( 'message' => esc_html__( 'Invalid product.', 'billey' ) ), 400 );
			}

			$post_object = get_post( $product_id );

			if ( ! $post_object || 'product' !== $post_object->post_type || 'publish' !== $post_object->post_status ) {
				wp_send_json_error( array( 'message' => esc_html__( 'Product not found.', 'billey' ) ), 404 );
			}

			setup_postdata( $GLOBALS['post'] = $post_object );

			ob_start();
			wc_get_template_part( 'content', 'quick-view' );
			$template = ob_get_clean();

			wp_reset_postdata();

			wp_send_json(
				array(
					'template' => $template,
				)
			);
		}

		public function product_infinite_load() {
			if ( ! check_ajax_referer( Billey_Helper::get_infinite_load_nonce_action(), 'nonce', false ) ) {
				wp_send_json_error( array( 'message' => '' ), 403 );
			}

			$source = isset( $_POST['source'] ) ? sanitize_text_field( wp_unslash( $_POST['source'] ) ) : '';

			if ( 'current_query' === $source ) {
				if ( ! isset( $_POST['query_vars'] ) || ! is_array( $_POST['query_vars'] ) ) {
					wp_send_json_error( array( 'message' => '' ), 400 );
				}
				$query_vars = Billey_Helper::data_clean( wp_unslash( $_POST['query_vars'] ) );
				$query_vars['post_type']   = 'product';
				$query_vars['nopaging']    = false;
				$query_vars['post_status'] = 'publish';
				if ( empty( $query_vars['paged'] ) ) {
					$query_vars['paged'] = 1;
				}
				$query_vars = Billey_Helper::cap_infinite_load_query_vars( $query_vars );

				$billey_query = new WP_Query( $query_vars );
			} else {
				$query_vars = isset( $_POST['query_vars'] ) && is_array( $_POST['query_vars'] )
					? Billey_Helper::data_clean( wp_unslash( $_POST['query_vars'] ) )
					: array();

				$posts_per_page = isset( $query_vars['posts_per_page'] ) ? intval( $query_vars['posts_per_page'] ) : - 1;
				if ( $posts_per_page > 500 || 0 === $posts_per_page ) {
					$posts_per_page = - 1;
				}
				$orderby = ! empty( $query_vars['orderby'] ) ? sanitize_text_field( $query_vars['orderby'] ) : 'date';
				$order   = ! empty( $query_vars['order'] ) ? strtoupper( sanitize_text_field( $query_vars['order'] ) ) : 'DESC';
				if ( ! in_array( $order, array( 'ASC', 'DESC' ), true ) ) {
					$order = 'DESC';
				}
				$paged = ! empty( $query_vars['paged'] ) ? max( 1, absint( $query_vars['paged'] ) ) : 1;

				$query_args = array(
					'post_type'      => 'product',
					'posts_per_page' => $posts_per_page,
					'orderby'        => $orderby,
					'order'          => $order,
					'paged'          => $paged,
					'post_status'    => 'publish',
				);

				$query_args = Billey_Helper::cap_infinite_load_query_vars( $query_args );

				if ( ! empty( $_POST['extra_taxonomy'] ) && is_string( $_POST['extra_taxonomy'] ) ) {
					$query_args = $this->build_extra_terms_query( $query_args, sanitize_text_field( wp_unslash( $_POST['extra_taxonomy'] ) ) );
				}

				$billey_query = new WP_Query( $query_args );
			}

			$response = array(
				'max_num_pages' => $billey_query->max_num_pages,
				'found_posts'   => $billey_query->found_posts,
				'count'         => $billey_query->post_count,
			);

			ob_start();

			if ( $billey_query->have_posts() ) :

				while ( $billey_query->have_posts() ) : $billey_query->the_post();
					wc_get_template_part( 'content', 'product' );
				endwhile;

				wp_reset_postdata();

			endif;

			$template = ob_get_clean();
			$template = preg_replace( '~>\s+<~', '><', $template );

			$response['template'] = $template;

			wp_send_json_success( $response );
		}

		function get_product_image( $args = array() ) {
			$defaults = array(
				'extra_class' => '',
			);

			$args = wp_parse_args( $args, $defaults );

			// Calculate product loop image size.
			if ( self::$product_image_size_width === '' ) {
				$width = 400;

				$shop_layout = Billey::setting( 'shop_archive_layout' );
				if ( 'wide' === $shop_layout ) {
					$width = 540;
				}

				$cropping = get_option( 'woocommerce_thumbnail_cropping' );
				$height   = $width;

				if ( $cropping === 'custom' ) {
					$ratio_w = get_option( 'woocommerce_thumbnail_cropping_custom_width' );
					$ratio_h = get_option( 'woocommerce_thumbnail_cropping_custom_height' );

					$height = ( $width * $ratio_h ) / $ratio_w;
					$height = (int) $height;
				} elseif ( $cropping === 'uncropped' ) {
					self::$product_image_crop = false;
					$height                   = 9999;
				}

				self::$product_image_size_width  = $width;
				self::$product_image_size_height = $height;
			}

			$image_args = array(
				'id'     => $args['id'],
				'size'   => 'custom',
				'width'  => self::$product_image_size_width,
				'height' => self::$product_image_size_height,
				'crop'   => self::$product_image_crop,
			);

			if ( $args['extra_class'] !== '' ) {
				$image_args['class'] = $args['extra_class'];
			}

			Billey_Image::the_attachment_by_id( $image_args );
		}

		function move_layered_nav_count_inside_link( $term_html, $term, $link, $count ) {
			if ( $count > 0 ) {
				$term_html = str_replace( '</a>', '', $term_html );
				$term_html = str_replace( '</span>', '</span></a>', $term_html );
			}

			return $term_html;
		}

		/**
		 * Get the gallery markup style for the current request.
		 *
		 * Quick view always uses the slider; otherwise it follows the product meta / theme option.
		 *
		 * @return string 'slider' or 'list'.
		 */
		public function get_single_product_gallery_style() {
			if ( true === apply_filters( 'billey_content_quick_view', false ) ) {
				return 'slider';
			}

			return 'list' === $this->get_single_product_style() ? 'list' : 'slider';
		}

		/**
		 * Get the ordered media items (images + gallery videos) of the single product gallery.
		 *
		 * Videos come from the WooCommerce "Product gallery videos" feature (beta, WC >= 11.0)
		 * when it is enabled; otherwise the featured image + gallery images are used.
		 *
		 * @param WC_Product $product   Product object.
		 * @param int[]|null $image_ids Optional list of image IDs to use instead of the product media (first = featured).
		 *
		 * @return array[] List of items: array( 'id' => int, 'type' => 'image'|'video', 'poster_id' => int ).
		 */
		public function get_single_product_media_items( $product, $image_ids = null ) {
			static $cache = array();

			$items = array();

			if ( ! $product instanceof WC_Product ) {
				return $items;
			}

			// The product media (no custom ID list) is requested once per variation: cache it per request.
			$cache_key = null === $image_ids ? $product->get_id() : 0;

			if ( $cache_key && isset( $cache[ $cache_key ] ) ) {
				return $cache[ $cache_key ];
			}

			if ( null === $image_ids ) {
				$items = $this->get_wc_media_gallery_items( $product );

				if ( empty( $items ) ) {
					$image_ids   = array_map( 'absint', (array) $product->get_gallery_image_ids() );
					$featured_id = absint( $product->get_image_id() );

					if ( $featured_id ) {
						$image_ids = array_diff( $image_ids, array( $featured_id ) );
						array_unshift( $image_ids, $featured_id );
					}
				}
			}

			if ( null !== $image_ids ) {
				$image_ids = array_unique( array_filter( array_map( 'absint', (array) $image_ids ) ) );

				foreach ( $image_ids as $image_id ) {
					$items[] = array(
						'id'        => $image_id,
						'type'      => 'image',
						'poster_id' => 0,
					);
				}
			}

			$items = apply_filters( 'billey_single_product_media_items', $items, $product );

			if ( $cache_key ) {
				$cache[ $cache_key ] = $items;
			}

			return $items;
		}

		/**
		 * Map the WooCommerce media gallery (images + videos) to theme media items.
		 *
		 * Only used when the WC "product_gallery_videos" feature is enabled. The WC class lives in an
		 * internal namespace, so everything is guarded and any failure falls back to images only.
		 *
		 * @param WC_Product $product Product object.
		 *
		 * @return array[]
		 */
		private function get_wc_media_gallery_items( $product ) {
			$gallery_class = '\Automattic\WooCommerce\Internal\ProductGallery\ProductMediaGallery';

			if ( ! class_exists( $gallery_class ) || ! method_exists( $gallery_class, 'is_feature_enabled' ) || ! method_exists( $gallery_class, 'get_product_media_gallery_items' ) ) {
				return array();
			}

			try {
				if ( ! $gallery_class::is_feature_enabled() ) {
					return array();
				}

				$media_items = $gallery_class::get_product_media_gallery_items(
					$product,
					array(
						'deduplicate'         => true,
						'include_placeholder' => false,
					)
				);
			} catch ( \Throwable $e ) {
				return array();
			}

			$items = array();

			foreach ( (array) $media_items as $media_item ) {
				if ( ! is_array( $media_item ) ) {
					continue;
				}

				$attachment_id = isset( $media_item['id'] ) ? absint( $media_item['id'] ) : 0;
				$source_type   = isset( $media_item['source_type'] ) ? $media_item['source_type'] : 'attachment';

				if ( ! $attachment_id || 'attachment' !== $source_type ) {
					continue;
				}

				$type      = ( isset( $media_item['media_type'] ) && 'video' === $media_item['media_type'] ) ? 'video' : 'image';
				$poster_id = 0;

				if ( 'video' === $type ) {
					$poster_id = isset( $media_item['poster_id'] ) ? absint( $media_item['poster_id'] ) : 0;

					if ( ! $poster_id ) {
						$poster_id = (int) get_post_thumbnail_id( $attachment_id );
					}
				}

				$items[] = array(
					'id'        => $attachment_id,
					'type'      => $type,
					'poster_id' => $poster_id,
				);
			}

			return $items;
		}

		/**
		 * Build the single product gallery markup (inner markup of .billey-product-gallery).
		 *
		 * @param array[] $media_items Items from get_single_product_media_items().
		 * @param string  $style       'slider' or 'list'.
		 * @param array   $args        {
		 *     @type bool|null       $open_gallery Whether items open in lightGallery. Defaults to the
		 *                                         woocommerce_single_product_open_gallery filter.
		 *     @type WC_Product|null $product      Product object. Defaults to the global $product.
		 * }
		 *
		 * @return string Escaped HTML.
		 */
		public function get_single_product_gallery_html( $media_items, $style = 'slider', $args = array() ) {
			$args = wp_parse_args(
				$args,
				array(
					'open_gallery' => null,
					'product'      => null,
				)
			);

			if ( null === $args['open_gallery'] ) {
				$args['open_gallery'] = apply_filters( 'woocommerce_single_product_open_gallery', true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
			}

			if ( ! $args['product'] instanceof WC_Product ) {
				$args['product'] = isset( $GLOBALS['product'] ) && $GLOBALS['product'] instanceof WC_Product ? $GLOBALS['product'] : false;
			}

			$media_items = array_values( array_filter( (array) $media_items, 'is_array' ) );

			if ( empty( $media_items ) ) {
				return '';
			}

			if ( 'slider' === $style ) {
				return $this->get_single_product_gallery_slider_html( $media_items, $args );
			}

			return $this->get_single_product_gallery_list_html( $media_items, $args );
		}

		/**
		 * Slider style: main Swiper + thumbs Swiper.
		 *
		 * @param array[] $media_items Media items.
		 * @param array   $args        See get_single_product_gallery_html().
		 *
		 * @return string
		 */
		private function get_single_product_gallery_slider_html( $media_items, $args ) {
			$main_slides_html   = '';
			$thumbs_slides_html = '';
			$count              = 0;

			foreach ( $media_items as $index => $media_item ) {
				$slide = $this->get_single_product_gallery_slide_html( $media_item, 0 === $index, $args );

				if ( '' === $slide['main'] ) {
					continue;
				}

				$main_slides_html   .= $slide['main'];
				$thumbs_slides_html .= $slide['thumb'];
				++$count;
			}

			if ( 0 === $count ) {
				return '';
			}

			$wrapper_classes = 'woo-single-gallery';

			if ( $count > 1 ) {
				$wrapper_classes .= ' has-thumbs-slider';
			}

			$html  = '<div class="' . esc_attr( $wrapper_classes ) . '">';
			$html .= '<div class="tm-swiper billey-main-swiper" data-lg-items="1" data-lg-gutter="30" data-speed="500" data-effect="slide" data-auto-height="1" data-nav="1">';
			$html .= '<div class="swiper-inner"><div class="swiper"><div class="swiper-wrapper">' . $main_slides_html . '</div></div></div>';
			$html .= '</div>';

			if ( $count > 1 ) {
				$html .= '<div class="tm-swiper billey-thumbs-swiper" data-lg-items="4" data-lg-gutter="10" data-speed="400" data-effect="slide" data-slide-to-clicked-slide="1" data-freemode="1">';
				$html .= '<div class="swiper-inner"><div class="swiper"><div class="swiper-wrapper">' . $thumbs_slides_html . '</div></div></div>';
				$html .= '</div>';
			}

			$html .= '</div>';

			return $html;
		}

		/**
		 * Build one slide (main + thumb) of the slider style gallery.
		 *
		 * @param array $media_item Media item.
		 * @param bool  $is_main    Whether this is the main (featured) item.
		 * @param array $args       See get_single_product_gallery_html().
		 *
		 * @return array array( 'main' => string, 'thumb' => string ).
		 */
		private function get_single_product_gallery_slide_html( $media_item, $is_main, $args ) {
			$empty         = array(
				'main'  => '',
				'thumb' => '',
			);
			$attachment_id = absint( $media_item['id'] );

			if ( 'video' === $media_item['type'] ) {
				$video = $this->get_single_product_gallery_video_html( $media_item, '570x570' );

				if ( '' === $video ) {
					return $empty;
				}

				$poster_id = absint( $media_item['poster_id'] );
				$thumb     = '';

				if ( $poster_id ) {
					$thumb = Billey_Image::get_attachment_by_id(
						array(
							'id'   => $poster_id,
							'size' => '120x150',
						)
					);
				}

				if ( ! $thumb ) {
					$thumb = '<video src="' . esc_url( wp_get_attachment_url( $attachment_id ) ) . '" muted playsinline preload="metadata"></video>';
				}

				// Same box as the image thumbs (4:5) + play icon overlay.
				$thumb = '<div class="product-gallery-video-thumb">' . $thumb . '<span class="product-gallery-video-play" aria-hidden="true"></span></div>';

				return array(
					'main'  => '<div class="swiper-slide product-gallery-video" data-image-id="' . esc_attr( $attachment_id ) . '">' . $video . '</div>',
					'thumb' => '<div class="swiper-slide product-gallery-video" data-image-id="' . esc_attr( $attachment_id ) . '">' . $thumb . '</div>',
				);
			}

			$props = wc_get_product_attachment_props( $attachment_id, $args['product'] );

			if ( empty( $props['url'] ) ) {
				return $empty;
			}

			$main_image = Billey_Image::get_attachment_by_id(
				array(
					'id'   => $attachment_id,
					'size' => '570x570',
				)
			);

			if ( ! $main_image ) {
				return $empty;
			}

			$classes = array( 'zoom', 'swiper-slide' );

			if ( $is_main ) {
				$classes[] = 'product-main-image';
			}

			$attributes = 'class="' . esc_attr( implode( ' ', $classes ) ) . '" data-image-id="' . esc_attr( $attachment_id ) . '"';

			if ( $args['open_gallery'] ) {
				$sub_html = $this->get_single_product_gallery_sub_html( $props );

				if ( '' !== $sub_html ) {
					$attributes .= ' data-sub-html="' . esc_attr( $sub_html ) . '"';
				}

				$attributes .= ' data-src="' . esc_url( $props['url'] ) . '"';
			}

			$thumb_image = Billey_Image::get_attachment_by_id(
				array(
					'id'   => $attachment_id,
					'size' => '120x150',
				)
			);

			return array(
				'main'  => '<div ' . $attributes . '>' . $main_image . '</div>',
				'thumb' => '<div class="swiper-slide" data-image-id="' . esc_attr( $attachment_id ) . '">' . $thumb_image . '</div>',
			);
		}

		/**
		 * List style: stacked images / videos.
		 *
		 * @param array[] $media_items Media items.
		 * @param array   $args        See get_single_product_gallery_html().
		 *
		 * @return string
		 */
		private function get_single_product_gallery_list_html( $media_items, $args ) {
			$html = '';

			foreach ( $media_items as $media_item ) {
				$attachment_id = absint( $media_item['id'] );

				if ( 'video' === $media_item['type'] ) {
					$video = $this->get_single_product_gallery_video_html( $media_item, 'custom', true );

					if ( '' !== $video ) {
						$html .= '<div class="product-gallery-video" data-image-id="' . esc_attr( $attachment_id ) . '">' . $video . '</div>';
					}

					continue;
				}

				$props = wc_get_product_attachment_props( $attachment_id, $args['product'] );

				if ( empty( $props['url'] ) ) {
					continue;
				}

				$image = Billey_Image::get_attachment_by_id(
					array(
						'id'     => $attachment_id,
						'size'   => 'custom',
						'width'  => 845,
						'height' => 9999,
						'crop'   => false,
					)
				);

				if ( ! $image ) {
					continue;
				}

				$link = $args['open_gallery'] ? $props['url'] : get_permalink( $args['product'] ? $args['product']->get_id() : null );

				$html .= sprintf(
					'<a href="%1$s" class="zoom" data-image-id="%2$s" data-sub-html="%3$s">%4$s</a>',
					esc_url( $link ),
					esc_attr( $attachment_id ),
					esc_attr( $this->get_single_product_gallery_sub_html( $props ) ),
					$image
				);
			}

			return $html;
		}

		/**
		 * Build the <video> tag of a gallery video item (mirrors the WC classic gallery video: muted, loop, inline).
		 *
		 * @param array  $media_item Media item.
		 * @param string $size       Poster image size (Billey_Image size).
		 * @param bool   $autoplay   Whether to add the autoplay attribute (slider items are played by JS).
		 *
		 * @return string
		 */
		private function get_single_product_gallery_video_html( $media_item, $size = '570x570', $autoplay = false ) {
			$attachment_id = absint( $media_item['id'] );
			$video_src     = $attachment_id ? wp_get_attachment_url( $attachment_id ) : '';

			if ( ! $video_src ) {
				return '';
			}

			$attributes = array(
				'class'       => 'product-gallery-video-el',
				'src'         => $video_src,
				'muted'       => 'muted',
				'loop'        => 'loop',
				'playsinline' => 'playsinline',
				'preload'     => 'metadata',
			);

			if ( $autoplay ) {
				$attributes['autoplay'] = 'autoplay';
			}

			$poster_id = absint( $media_item['poster_id'] );

			if ( $poster_id ) {
				$poster_args = array(
					'id'   => $poster_id,
					'size' => $size,
				);

				if ( 'custom' === $size ) {
					$poster_args['width']  = 845;
					$poster_args['height'] = 9999;
					$poster_args['crop']   = false;
				}

				$poster = Billey_Image::get_attachment_url_by_id( $poster_args );

				if ( $poster ) {
					$attributes['poster'] = $poster;
				}
			}

			$label = trim( wp_strip_all_tags( (string) get_post_field( 'post_title', $attachment_id ) ) );

			if ( '' !== $label ) {
				/* translators: %s: video title. */
				$attributes['aria-label'] = sprintf( __( 'Video: %s', 'billey' ), $label );
			}

			$attributes_html = '';

			foreach ( $attributes as $name => $value ) {
				$attributes_html .= ' ' . esc_attr( $name ) . '="' . ( 'src' === $name || 'poster' === $name ? esc_url( $value ) : esc_attr( $value ) ) . '"';
			}

			return '<video' . $attributes_html . '></video>';
		}

		/**
		 * Build the lightGallery caption (data-sub-html) from attachment props.
		 *
		 * @param array $props Result of wc_get_product_attachment_props().
		 *
		 * @return string Unescaped HTML (escape with esc_attr() when printed as attribute).
		 */
		private function get_single_product_gallery_sub_html( $props ) {
			$sub_html = '';

			if ( ! empty( $props['title'] ) ) {
				$sub_html .= '<h4>' . wp_kses_post( $props['title'] ) . '</h4>';
			}

			if ( ! empty( $props['caption'] ) ) {
				$sub_html .= '<p>' . wp_kses_post( $props['caption'] ) . '</p>';
			}

			return $sub_html;
		}

		/**
		 * Get the media items to show when a variation is selected, or an empty array when the
		 * parent gallery can be kept (JS then just slides to the matching image).
		 *
		 * - Variation with its own gallery images: variation image (if any) + variation gallery (like WC core).
		 * - Variation with its own image that is not part of the parent gallery: variation image replaces the
		 *   parent featured image, the rest of the parent gallery is kept.
		 *
		 * @param WC_Product $product   Parent (variable) product.
		 * @param WC_Product $variation Variation.
		 *
		 * @return array[]
		 */
		public function get_variation_gallery_media_items( $product, $variation ) {
			if ( ! $product instanceof WC_Product || ! $variation instanceof WC_Product ) {
				return array();
			}

			$own_image_id = absint( $variation->get_image_id( 'edit' ) );

			if ( $own_image_id && ! wp_attachment_is_image( $own_image_id ) ) {
				$own_image_id = 0;
			}

			$own_gallery_ids = array_values( array_filter( array_map( 'absint', (array) $variation->get_gallery_image_ids( 'edit' ) ), 'wp_attachment_is_image' ) );

			if ( ! empty( $own_gallery_ids ) ) {
				if ( $own_image_id ) {
					$own_gallery_ids = array_diff( $own_gallery_ids, array( $own_image_id ) );
					array_unshift( $own_gallery_ids, $own_image_id );
				}

				return $this->get_single_product_media_items( $product, $own_gallery_ids );
			}

			if ( ! $own_image_id ) {
				return array();
			}

			$parent_items = $this->get_single_product_media_items( $product );
			$parent_ids   = array_map( 'intval', wp_list_pluck( $parent_items, 'id' ) );

			if ( in_array( $own_image_id, $parent_ids, true ) ) {
				return array();
			}

			$parent_featured_id = absint( $product->get_image_id() );
			$items              = array(
				array(
					'id'        => $own_image_id,
					'type'      => 'image',
					'poster_id' => 0,
				),
			);

			foreach ( $parent_items as $item ) {
				if ( (int) $item['id'] === $parent_featured_id ) {
					continue;
				}

				$items[] = $item;
			}

			return $items;
		}

		/**
		 * Add the theme gallery markup of a variation to the variation data (woocommerce_available_variation).
		 *
		 * JS (woo.js) swaps the gallery with this markup on found_variation and restores it on reset_data.
		 *
		 * @param array      $data      Variation data.
		 * @param WC_Product $product   Parent product.
		 * @param WC_Product $variation Variation.
		 *
		 * @return array
		 */
		public function add_variation_gallery_data( $data, $product, $variation ) {
			if ( ! is_array( $data ) ) {
				return $data;
			}

			if ( ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( is_admin() && ! wp_doing_ajax() ) ) {
				return $data;
			}

			$media_items = $this->get_variation_gallery_media_items( $product, $variation );

			if ( empty( $media_items ) ) {
				return $data;
			}

			// On the product page / quick view the style is known; on WC AJAX (get_variation) build both.
			$styles = doing_action( 'woocommerce_variable_add_to_cart' ) ? array( $this->get_single_product_gallery_style() ) : array( 'slider', 'list' );

			$gallery = array();

			foreach ( $styles as $style ) {
				$html = $this->get_single_product_gallery_html( $media_items, $style, array( 'product' => $product ) );

				if ( '' !== $html ) {
					$gallery[ $style ] = $html;
				}
			}

			if ( ! empty( $gallery ) ) {
				$data['billey_gallery'] = $gallery;
			}

			return $data;
		}

		public function get_single_product_style() {
			$style = Billey_Helper::get_post_meta( 'single_product_layout_style' );

			if ( empty( $style ) ) {
				$style = Billey::setting( 'single_product_layout_style' );
			}

			return $style;
		}

		public function admin_notice_minimum_compare_plugin_version() {
			billey_notice_required_plugin_version( 'WPC Smart Compare for WooCommerce', '4.0.1' );
		}
	}

	Billey_Woo::instance()->initialize();
}
