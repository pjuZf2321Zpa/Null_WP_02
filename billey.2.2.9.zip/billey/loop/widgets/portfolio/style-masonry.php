<?php

defined( 'ABSPATH' ) || exit;
while ( $billey_query->have_posts() ) :
	$billey_query->the_post();
	$classes = array( 'portfolio-item grid-item' );
	?>
	<div <?php post_class( implode( ' ', $classes ) ); ?>>
		<div class="post-wrapper billey-box">
			<div class="post-thumbnail-wrapper billey-image">
				<a href="<?php Billey_Portfolio::instance()->the_permalink(); ?>"
				   class="post-permalink link-secret">
					<div class="post-thumbnail">
						<?php if ( has_post_thumbnail() ) { ?>
							<?php $size = Billey_Image::elementor_parse_image_size( $settings, '480x9999' ); ?>
							<?php Billey_Image::the_post_thumbnail( array( 'size' => $size ) ); ?>
						<?php } else { ?>
							<?php Billey_Templates::image_placeholder( 480, 480 ); ?>
						<?php } ?>
					</div>

				<?php if ( ! empty( $settings['overlay_style'] ) ) : ?>
					<?php
					$overlay_style = sanitize_text_field( $settings['overlay_style'] );
					// Whitelist allowed overlay styles
					$allowed_overlay_styles = array( 'faded', 'faded-02', 'faded-04', 'colored-faded', 'movement', 'flat', 'float', 'huge' );
					if ( ! in_array( $overlay_style, $allowed_overlay_styles, true ) ) {
						$overlay_style = '';
					}
					if ( ! empty( $overlay_style ) ) {
						get_template_part( 'loop/portfolio/overlay', $overlay_style );
					}
					?>
				<?php endif; ?>
			</a>
		</div>

		<?php if ( 'yes' === $settings['show_caption'] ) : ?>
			<?php
			$caption_style = ! empty( $settings['caption_style'] ) ? sanitize_text_field( $settings['caption_style'] ) : '01';
			// Whitelist allowed caption styles
			$allowed_caption_styles = array( '01', '02' );
			if ( ! in_array( $caption_style, $allowed_caption_styles, true ) ) {
				$caption_style = '01';
			}
			get_template_part( 'loop/portfolio/caption', $caption_style );
			?>
		<?php endif; ?>

		</div>
	</div>
<?php endwhile; ?>
