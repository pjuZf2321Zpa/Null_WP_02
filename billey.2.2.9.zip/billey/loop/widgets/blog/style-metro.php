<?php

defined( 'ABSPATH' ) || exit;
if ( isset( $settings['grid_metro_layout'] ) ) {
	$metro_layout = array();

	foreach ( $settings['grid_metro_layout'] as $key => $value ) {
		$metro_layout[] = $value['size'];
	}
} else {
	$metro_layout = array(
		'2:2',
		'1:1',
		'1:1',
		'1:1',
		'1:1',
		'1:1',
		'1:1',
		'1:1',
		'1:1',
		'2:2',
	);
}

if ( count( $metro_layout ) < 1 ) {
	return;
}

$metro_layout_count = count( $metro_layout );
$metro_item_count   = 0;
$count              = $billey_query->post_count;

while ( $billey_query->have_posts() ) : $billey_query->the_post();
	$classes = array( 'grid-item post-item' );

	$size   = $metro_layout[ $metro_item_count ];
	$ratio  = explode( ':', $size );
	$ratioW = $ratio[0];
	$ratioH = $ratio[1];

	$_image_width  = $settings['metro_image_size_width'];
	$_image_height = $_image_width * $settings['metro_image_ratio']['size'];
	if ( in_array( $ratioW, array( '2' ) ) ) {
		$_image_width *= 2;
	}

	if ( in_array( $ratioH, array( '1.3', '2' ) ) ) {
		$_image_height *= 2;
	}
	?>
	<div <?php post_class( implode( ' ', $classes ) ); ?>
		data-width="<?php echo esc_attr( $ratioW ); ?>"
		data-height="<?php echo esc_attr( $ratioH ); ?>"
	>
		<div class="post-wrapper billey-box">
			<div class="post-thumbnail-wrapper billey-image grid-item-height">

				<div class="post-thumbnail">
					<a href="<?php the_permalink(); ?>">
						<?php if ( has_post_thumbnail() ) { ?>
							<?php
							Billey_Image::the_post_thumbnail( array(
								'size'   => 'custom',
								'width'  => $_image_width,
								'height' => $_image_height,
							) );
							?>
						<?php } else { ?>
							<?php Billey_Templates::image_placeholder( 480, 480 ); ?>
						<?php } ?>
					</a>
				</div>

			<?php if ( 'yes' === $settings['show_overlay'] ) : ?>
				<?php
				$overlay_style = ! empty( $settings['overlay_style'] ) ? sanitize_text_field( $settings['overlay_style'] ) : 'float';
				// Whitelist allowed overlay styles
				$allowed_overlay_styles = array( 'float' );
				if ( ! in_array( $overlay_style, $allowed_overlay_styles, true ) ) {
					$overlay_style = 'float';
				}
				get_template_part( 'loop/blog/overlay', $overlay_style );
				?>
			<?php endif; ?>
		</div>

		<?php if ( 'yes' === $settings['show_caption'] ) : ?>
			<?php
			$caption_style = ! empty( $settings['caption_style'] ) ? sanitize_text_field( $settings['caption_style'] ) : '01';
			// Whitelist allowed caption styles
			$allowed_caption_styles = array( '01', '02', '03', '04' );
			if ( ! in_array( $caption_style, $allowed_caption_styles, true ) ) {
				$caption_style = '01';
			}
			get_template_part( 'loop/blog/caption', $caption_style );
			?>
		<?php endif; ?>
		</div>
	</div>
	<?php
	$metro_item_count++;
	if ( $metro_item_count == $count || $metro_layout_count == $metro_item_count ) {
		$metro_item_count = 0;
	}
	?>
<?php endwhile; ?>
