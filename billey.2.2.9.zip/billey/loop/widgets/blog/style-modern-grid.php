<?php

defined( 'ABSPATH' ) || exit;
while ( $billey_query->have_posts() ) :
	$billey_query->the_post();
	$classes = array( 'grid-item', 'post-item' );
	?>
	<div <?php post_class( implode( ' ', $classes ) ); ?>>
		<div class="post-wrapper billey-box">

			<?php if ( has_post_thumbnail() ) { ?>
				<div class="post-feature post-thumbnail billey-image">
					<a href="<?php the_permalink(); ?>">
						<?php
						$size = Billey_Image::elementor_parse_image_size( $settings, '480x480' );
						Billey_Image::the_post_thumbnail( array( 'size' => $size ) );
						?>
					</a>

			<?php if ( 'yes' === $settings['show_overlay'] ) : ?>
				<?php
				$overlay_style = ! empty( $settings['overlay_style'] ) ? sanitize_text_field( $settings['overlay_style'] ) : 'float';
				// Whitelist allowed overlay styles
				$allowed_overlay_styles = array( 'float' );
				if ( ! in_array( $overlay_style, $allowed_overlay_styles, true ) ) {
					$overlay_style = 'float';
				}
				get_template_part( 'loop/blog/overlay', $overlay_style );
				?>
			<?php endif; ?>
		</div>
	<?php } ?>

	<?php if ( 'yes' === $settings['show_caption'] ) : ?>
		<?php
		$caption_style = ! empty( $settings['caption_style'] ) ? sanitize_text_field( $settings['caption_style'] ) : '01';
		// Whitelist allowed caption styles
		$allowed_caption_styles = array( '01', '02', '03', '04' );
		if ( ! in_array( $caption_style, $allowed_caption_styles, true ) ) {
			$caption_style = '01';
		}
		get_template_part( 'loop/blog/caption', $caption_style );
		?>
	<?php endif; ?>
		</div>
	</div>
<?php endwhile;
