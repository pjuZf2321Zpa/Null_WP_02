<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 11.1.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

/**
 * Since WooCommerce 10.8.0, woocommerce_variable_add_to_cart() re-renders this template
 * to build a gallery snapshot (inline script + <template class="wc-product-gallery-default-template">)
 * and once more for every variation that owns gallery images. That snapshot is only consumed
 * by the default classic gallery (.woocommerce-product-gallery) swap logic in add-to-cart-variation.js.
 * The theme ships its own gallery (Swiper) and its own variation gallery data
 * (see Billey_Woo::add_variation_gallery_data()), so skip those extra renders.
 */
if ( doing_action( 'woocommerce_variable_add_to_cart' ) ) {
	return;
}

$billey_woo    = Billey_Woo::instance();
$is_quick_view = apply_filters( 'billey_content_quick_view', false );
$feature_style = true === $is_quick_view ? 'slider' : $billey_woo->get_single_product_style();
$gallery_style = 'slider' === $feature_style ? 'slider' : 'list';
$open_gallery  = apply_filters( 'woocommerce_single_product_open_gallery', true );

// Images + gallery videos (WooCommerce "Product gallery videos" feature, when enabled).
$media_items = $billey_woo->get_single_product_media_items( $product );

$gallery_html = $billey_woo->get_single_product_gallery_html(
	$media_items,
	$gallery_style,
	array(
		'open_gallery' => $open_gallery,
		'product'      => $product,
	)
);

if ( '' === $gallery_html ) {
	echo apply_filters( 'woocommerce_single_product_image_html', sprintf( '<img src="%s" alt="%s" />', esc_url( wc_placeholder_img_src() ), esc_attr__( 'Placeholder', 'billey' ) ), $product->get_id() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

	return;
}

$classes = array( 'billey-product-gallery', "feature-style-{$feature_style}" );

if ( $open_gallery ) {
	$classes[] = 'billey-light-gallery';
}
?>
<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" data-gallery-style="<?php echo esc_attr( $gallery_style ); ?>">
	<?php echo $gallery_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Billey_Woo::get_single_product_gallery_html(). ?>
</div>
