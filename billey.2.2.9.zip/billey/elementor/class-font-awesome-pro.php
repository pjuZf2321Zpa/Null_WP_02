<?php

namespace Billey_Elementor;

defined( 'ABSPATH' ) || exit;

class Font_Awesome_Pro {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function initialize() {
		add_action( 'elementor/frontend/after_register_styles', function() {
			foreach ( [ 'solid', 'regular', 'brands' ] as $style ) {
				wp_deregister_style( 'elementor-icons-fa-' . $style );
			}
		}, 20 );

		add_filter( 'elementor/icons_manager/native', array( $this, 'replace_font_awesome_pro' ), 10 );
		add_filter( 'elementor/icons_manager/additional_tabs', array( $this, 'replace_font_awesome_pro' ), 10 );

		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'admin_enqueue_scripts' ], 11 );
		add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'admin_enqueue_scripts' ], 11 );
	}

	public function replace_font_awesome_pro( $settings ) {
		$json_url = BILLEY_ELEMENTOR_ASSETS . '/libs/font-awesome-pro/%s.js';
		$version  = '6.4.2-pro';

		$icons['fa-regular'] = [
			'name'          => 'fa-regular',
			'label'         => esc_html__( 'Font Awesome - Regular Pro', 'billey' ),
			'url'           => false,
			'enqueue'       => false,
			'prefix'        => 'fa-',
			'displayPrefix' => 'fa-regular',
			'labelIcon'     => 'fa-regular fa-flag',
			'ver'           => $version,
			'fetchJson'     => sprintf( $json_url, 'regular' ),
			'native'        => true,
		];

		$icons['fa-solid'] = [
			'name'          => 'fa-solid',
			'label'         => esc_html__( 'Font Awesome - Solid Pro', 'billey' ),
			'url'           => false,
			'enqueue'       => false,
			'prefix'        => 'fa-',
			'displayPrefix' => 'fa-solid',
			'labelIcon'     => 'fa-solid fa-flag',
			'ver'           => $version,
			'fetchJson'     => sprintf( $json_url, 'solid' ),
			'native'        => true,
		];

		$icons['fa-brands'] = [
			'name'          => 'fa-brands',
			'label'         => esc_html__( 'Font Awesome - Brands Pro', 'billey' ),
			'url'           => false,
			'enqueue'       => false,
			'prefix'        => 'fa-',
			'displayPrefix' => 'fa-brands',
			'labelIcon'     => 'fa-brands fa-font-awesome-flag',
			'ver'           => $version,
			'fetchJson'     => sprintf( $json_url, 'brands' ),
			'native'        => true,
		];

		$icons['fa-light'] = [
			'name'          => 'fa-light',
			'label'         => esc_html__( 'Font Awesome - Light Pro', 'billey' ),
			'url'           => false,
			'enqueue'       => false,
			'prefix'        => 'fa-',
			'displayPrefix' => 'fa-light',
			'labelIcon'     => 'fa-light fa-flag',
			'ver'           => $version,
			'fetchJson'     => sprintf( $json_url, 'light' ),
			'native'        => true,
		];

		$icons['fa-duotone'] = [
			'name'          => 'fa-duotone',
			'label'         => esc_html__( 'Font Awesome - Duotone Pro', 'billey' ),
			'url'           => false,
			'enqueue'       => false,
			'prefix'        => 'fa-',
			'displayPrefix' => 'fa-duotone',
			'labelIcon'     => 'fa-duotone fa-flag',
			'ver'           => $version,
			'fetchJson'     => sprintf( $json_url, 'duotone' ),
			'native'        => true,
		];

		foreach ( array_keys( $icons ) as $icon_library ) {
			$icons[ $icon_library ]['render_callback'] = array( __CLASS__, 'render_font_icon' );
		}

		// Remove old from plugin.
		unset(
			$settings['fa-solid'],
			$settings['fa-regular'],
			$settings['fa-brands'],
			$settings['fa-light'],
			$settings['fa-duotone']
		);

		return array_merge( $icons, $settings );
	}

	/**
	 * Render a Font Awesome Pro icon with the bundled CSS font.
	 *
	 * Elementor's inline SVG data is based on Font Awesome 5 and does not contain
	 * the Pro Light or Duotone libraries. A render callback keeps all bundled Pro
	 * 6 icons on the CSS-font path without disabling inline SVG for other icons.
	 *
	 * @param array  $icon       Icon settings.
	 * @param array  $attributes HTML attributes.
	 * @param string $tag        HTML tag name.
	 * @return string
	 */
	public static function render_font_icon( $icon, $attributes = array(), $tag = 'i' ) {
		if ( empty( $icon['value'] ) || ! is_string( $icon['value'] ) ) {
			return '';
		}

		$tag = is_string( $tag ) ? strtolower( $tag ) : '';
		$tag = in_array( $tag, array( 'i', 'span' ), true ) ? $tag : 'i';

		if ( empty( $attributes['class'] ) ) {
			$attributes['class'] = $icon['value'];
		} elseif ( is_array( $attributes['class'] ) ) {
			$attributes['class'][] = $icon['value'];
		} else {
			$attributes['class'] .= ' ' . $icon['value'];
		}

		return '<' . $tag . ' ' . \Elementor\Utils::render_html_attributes( $attributes ) . '></' . $tag . '>';
	}

	/**
	 * Enqueue the bundled Font Awesome Pro stylesheet.
	 */
	public function admin_enqueue_scripts() {
		wp_enqueue_style( 'font-awesome-pro', BILLEY_THEME_URI . '/assets/fonts/awesome/css/fontawesome-all.min.css', null, '6.4.2' );
	}
}

Font_Awesome_Pro::instance()->initialize();
