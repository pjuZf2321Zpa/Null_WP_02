<?php

namespace Billey_Elementor;

use Elementor\Core\Base\Document;
use Elementor\Plugin;
use Elementor\TemplateLibrary\Source_Local;
use Elementor\User;

defined( 'ABSPATH' ) || exit;

class Module_Query_Base {

	const AUTOCOMPLETE_CONTROL_ID = 'autocomplete';
	const AUTOCOMPLETE_ERROR_CODE = 'QueryControlAutocomplete';
	const GET_TITLES_ERROR_CODE   = 'QueryControlGetTitles';
	const AUTOCOMPLETE_LIMIT      = 20;
	const GET_TITLES_LIMIT        = 100;
	const POST_QUERY_LIMIT        = 100;

	// Supported objects for query:
	const QUERY_OBJECT_POST             = 'post';
	const QUERY_OBJECT_TAX              = 'tax';
	const QUERY_OBJECT_AUTHOR           = 'author';
	const QUERY_OBJECT_USER             = 'user';
	const QUERY_OBJECT_LIBRARY_TEMPLATE = 'library_template';
	const QUERY_OBJECT_ATTACHMENT       = 'attachment';

	/**
	 * Supported server-side autocomplete object types.
	 *
	 * @var string[]
	 */
	private static $supported_objects_for_query = array(
		self::QUERY_OBJECT_POST,
		self::QUERY_OBJECT_TAX,
		self::QUERY_OBJECT_AUTHOR,
		self::QUERY_OBJECT_USER,
		self::QUERY_OBJECT_LIBRARY_TEMPLATE,
		self::QUERY_OBJECT_ATTACHMENT,
	);

	protected $post_type;
	protected $query_args;
	protected $widget_settings;

	private static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize() {
		add_action( 'elementor/ajax/register_actions', array( $this, 'register_ajax_actions' ) );
	}

	/**
	 * @param \Elementor\Core\Common\Modules\Ajax\Module $ajax_manager
	 */
	public function register_ajax_actions( $ajax_manager ) {
		$ajax_manager->register_ajax_action(
			'billey_elementor_autocomplete_search',
			array(
				$this,
				'autocomplete_search',
			)
		);
		$ajax_manager->register_ajax_action(
			'billey_elementor_autocomplete_render',
			array(
				$this,
				'autocomplete_render',
			)
		);
	}

	public function autocomplete_search( array $data ) {
		$this->verify_user_access_for_editing( $data );

		$query_data = $this->autocomplete_query_data( $data );
		if ( is_wp_error( $query_data ) ) {
			/** @var \WP_Error $query_data */
			throw new \Exception( esc_html( $query_data->get_error_code() . ':' . $query_data->get_error_message() ) );
		}

		$results    = array();
		$display    = $query_data['display'];
		$query_args = $query_data['query'];

		switch ( $query_data['object'] ) {
			case self::QUERY_OBJECT_TAX:
				$by_field = ! empty( $query_data['by_field'] ) ? $query_data['by_field'] : 'term_taxonomy_id';
				$terms    = get_terms( $query_args );
				if ( empty( $terms ) || is_wp_error( $terms ) ) {
					break;
				}
				foreach ( $terms as $term ) {
					$results[] = array(
						'id'   => $term->{$by_field},
						'text' => $this->get_term_name( $term, $display ),
					);
				}
				break;
			case self::QUERY_OBJECT_ATTACHMENT:
			case self::QUERY_OBJECT_POST:
				$query_args['no_found_rows'] = true;
				$query                       = new \WP_Query( $query_args );

				foreach ( $query->posts as $post ) {
					if ( ! current_user_can( 'edit_post', $post->ID ) ) {
						continue;
					}

					$text      = $this->format_post_for_display( $post, $display );
					$results[] = array(
						'id'   => $post->ID,
						'text' => $text,
					);

					if ( count( $results ) >= self::AUTOCOMPLETE_LIMIT ) {
						break;
					}
				}
				break;
			case self::QUERY_OBJECT_LIBRARY_TEMPLATE:
				$query_args['no_found_rows'] = true;
				$query                       = new \WP_Query( $query_args );

				foreach ( $query->posts as $post ) {
					if ( ! current_user_can( 'edit_post', $post->ID ) ) {
						continue;
					}

					$document = Plugin::$instance->documents->get( $post->ID );
					if ( $document ) {
						$text      = esc_html( $post->post_title ) . ' (' . esc_html( $document->get_post_type_title() ) . ')';
						$results[] = array(
							'id'   => $post->ID,
							'text' => $text,
						);

						if ( count( $results ) >= self::AUTOCOMPLETE_LIMIT ) {
							break;
						}
					}
				}
				break;
			case self::QUERY_OBJECT_USER:
			case self::QUERY_OBJECT_AUTHOR:
				$user_query = new \WP_User_Query( $query_args );

				foreach ( $user_query->get_results() as $user ) {
					$results[] = array(
						'id'   => $user->ID,
						'text' => $this->format_user_for_display( $user, $display ),
					);
				}
				break;
		}

		return array(
			'results' => $results,
		);
	}

	/**
	 * Resolve saved autocomplete IDs into labels.
	 *
	 * @param array $request Elementor query-control request.
	 *
	 * @return array
	 * @throws \Exception When the current user cannot edit the active document.
	 */
	public function autocomplete_render( array $request ) {
		$this->verify_user_access_for_editing( $request );

		$query_data = $this->get_titles_query_data( $request );
		if ( is_wp_error( $query_data ) ) {
			return array();
		}
		$display    = $query_data['display'];
		$query_args = $query_data['query'];

		$results = array();

		switch ( $query_data['object'] ) {
			case self::QUERY_OBJECT_TAX:
				$by_field = ! empty( $query_data['by_field'] ) ? $query_data['by_field'] : 'term_taxonomy_id';
				$terms    = get_terms( $query_args );

				if ( empty( $terms ) || is_wp_error( $terms ) ) {
					break;
				}
				foreach ( $terms as $term ) {
					$results[ $term->{$by_field} ] = $this->get_term_name( $term, $display );
				}
				break;
			case self::QUERY_OBJECT_ATTACHMENT:
			case self::QUERY_OBJECT_POST:
				$query_args['no_found_rows'] = true;
				$query                       = new \WP_Query( $query_args );

				foreach ( $query->posts as $post ) {
					if ( ! current_user_can( 'edit_post', $post->ID ) ) {
						continue;
					}

					$results[ $post->ID ] = $this->format_post_for_display( $post, $display );
				}
				break;
			case self::QUERY_OBJECT_LIBRARY_TEMPLATE:
				$query_args['no_found_rows'] = true;
				$query                       = new \WP_Query( $query_args );

				foreach ( $query->posts as $post ) {
					if ( ! current_user_can( 'edit_post', $post->ID ) ) {
						continue;
					}

					$document = Plugin::$instance->documents->get( $post->ID );
					if ( $document ) {
						$results[ $post->ID ] = esc_html( $post->post_title ) . ' (' . esc_html( $document->get_post_type_title() ) . ')';
					}
				}
				break;
			case self::QUERY_OBJECT_AUTHOR:
			case self::QUERY_OBJECT_USER:
				$user_query = new \WP_User_Query( $query_args );

				foreach ( $user_query->get_results() as $user ) {
					$results[ $user->ID ] = $this->format_user_for_display( $user, $display );
				}
				break;
		}

		return $results;
	}

	/**
	 * Format a term label for an autocomplete result.
	 *
	 * @param \WP_Term $term    Term being displayed.
	 * @param string   $display Display mode.
	 *
	 * @return string
	 */
	private function get_term_name( $term, $display ) {
		global $wp_taxonomies;
		$term_name = $this->get_term_name_with_parents( $term );
		$text      = $term_name;
		switch ( $display ) {
			case 'detailed':
				$taxonomy_label = isset( $wp_taxonomies[ $term->taxonomy ] ) ? $wp_taxonomies[ $term->taxonomy ]->labels->name : $term->taxonomy;
				$text           = $taxonomy_label . ': ' . $term_name;
				break;
			case 'minimal':
				$text = $term_name;
				break;
		}

		return esc_html( $text );
	}

	/**
	 * get_term_name_with_parents
	 *
	 * @param \WP_Term $term
	 * @param int      $max
	 *
	 * @return string
	 */
	private function get_term_name_with_parents( \WP_Term $term, $max = 3 ) {
		if ( 0 === $term->parent ) {
			return $term->name;
		}
		$separator = is_rtl() ? ' < ' : ' > ';
		$test_term = $term;
		$names     = array();
		while ( $test_term->parent > 0 ) {
			$test_term = get_term( $test_term->parent );
			if ( ! $test_term || is_wp_error( $test_term ) ) {
				break;
			}
			$names[] = $test_term->name;
		}

		$names = array_reverse( $names );
		if ( count( $names ) < ( $max ) ) {
			return implode( $separator, $names ) . $separator . $term->name;
		}

		$name_string = '';
		for ( $i = 0; $i < ( $max - 1 ); $i++ ) {
			$name_string .= $names[ $i ] . $separator;
		}

		return $name_string . '...' . $separator . $term->name;
	}

	/**
	 * get post name with parents
	 *
	 * @param \WP_Post $post
	 * @param int      $max
	 *
	 * @return string
	 */
	private function get_post_name_with_parents( $post, $max = 3 ) {
		if ( 0 === $post->post_parent ) {
			return $post->post_title;
		}
		$separator = is_rtl() ? ' < ' : ' > ';
		$test_post = $post;
		$names     = array();
		while ( $test_post->post_parent > 0 ) {
			$test_post = get_post( $test_post->post_parent );
			if ( ! $test_post ) {
				break;
			}
			$names[] = $test_post->post_title;
		}

		$names = array_reverse( $names );
		if ( count( $names ) < ( $max ) ) {
			return implode( $separator, $names ) . $separator . $post->post_title;
		}

		$name_string = '';
		for ( $i = 0; $i < ( $max - 1 ); $i++ ) {
			$name_string .= $names[ $i ] . $separator;
		}

		return $name_string . '...' . $separator . $post->post_title;
	}

	/**
	 * Verify that the request belongs to a user who can edit the current document.
	 *
	 * @param array $data Request data supplied by Elementor's authenticated AJAX dispatcher.
	 *
	 * @throws \Exception When the current user cannot edit the requested document.
	 */
	private function verify_user_access_for_editing( array $data ) {
		if ( ! current_user_can( 'edit_posts' ) || ! User::is_current_user_in_editing_black_list() ) {
			throw new \Exception( esc_html__( 'You do not have permission to use this query control.', 'billey' ) );
		}

		if ( ! empty( $data['editor_post_id'] ) ) {
			$editor_post_id = is_scalar( $data['editor_post_id'] ) ? absint( $data['editor_post_id'] ) : 0;
			if ( ! $editor_post_id || ! User::is_current_user_can_edit( $editor_post_id ) ) {
				throw new \Exception( esc_html__( 'You do not have permission to edit this content.', 'billey' ) );
			}
		}
	}

	/**
	 * Sanitize and cap the length of a search term.
	 *
	 * @param mixed $search_term Raw search term.
	 *
	 * @return string
	 */
	private function sanitize_search_term( $search_term ) {
		if ( ! is_scalar( $search_term ) ) {
			return '';
		}

		$search_term = sanitize_text_field( (string) $search_term );

		return function_exists( 'mb_substr' ) ? mb_substr( $search_term, 0, 100 ) : substr( $search_term, 0, 100 );
	}

	/**
	 * Sanitize post types and discard unregistered values.
	 *
	 * @param string|array $post_types Post type name or names.
	 * @param bool         $allow_any  Whether the special `any` value is allowed.
	 *
	 * @return string|array
	 */
	private function sanitize_post_types( $post_types, $allow_any = false ) {
		$original_is_array = is_array( $post_types );
		$post_types        = array_map(
			static function ( $post_type ) {
				return is_scalar( $post_type ) ? sanitize_key( (string) $post_type ) : '';
			},
			(array) $post_types
		);
		$post_types        = array_values(
			array_unique(
				array_filter(
					$post_types,
					static function ( $post_type ) use ( $allow_any ) {
						return ( $allow_any && 'any' === $post_type ) || post_type_exists( $post_type );
					}
				)
			)
		);

		if ( $original_is_array ) {
			return $post_types;
		}

		return ! empty( $post_types ) ? reset( $post_types ) : '';
	}

	/**
	 * Sanitize taxonomy names and discard unregistered values.
	 *
	 * @param string|array $taxonomies Taxonomy name or names.
	 *
	 * @return array
	 */
	private function sanitize_taxonomies( $taxonomies ) {
		$taxonomies = array_map(
			static function ( $taxonomy ) {
				return is_scalar( $taxonomy ) ? sanitize_key( (string) $taxonomy ) : '';
			},
			(array) $taxonomies
		);

		$taxonomies = array_filter(
			$taxonomies,
			static function ( $taxonomy ) {
				$taxonomy_object = get_taxonomy( $taxonomy );

				return $taxonomy_object
					&& ! empty( $taxonomy_object->cap->assign_terms )
					&& current_user_can( $taxonomy_object->cap->assign_terms );
			}
		);

		return array_values( array_unique( $taxonomies ) );
	}

	/**
	 * Allow only Elementor's document-type meta query used by template controls.
	 *
	 * @param array $query Raw library template query.
	 *
	 * @return array
	 */
	private function sanitize_library_meta_query( array $query ) {
		if ( empty( $query['meta_query'] ) || ! is_array( $query['meta_query'] ) ) {
			return array();
		}

		foreach ( $query['meta_query'] as $clause ) {
			if ( ! is_array( $clause ) || Document::TYPE_META_KEY !== ( $clause['key'] ?? '' ) ) {
				continue;
			}

			$document_types = array_map(
				static function ( $document_type ) {
					return is_scalar( $document_type ) ? sanitize_key( (string) $document_type ) : '';
				},
				(array) ( $clause['value'] ?? array() )
			);

			$registered_document_types = array_keys(
				Plugin::$instance->documents->get_document_types(
					array(
						'show_in_library' => true,
					)
				)
			);

			$document_types = array_values(
				array_intersect(
					array_unique( array_filter( $document_types ) ),
					$registered_document_types
				)
			);
			if ( empty( $document_types ) ) {
				continue;
			}

			return array(
				array(
					'key'     => Document::TYPE_META_KEY,
					'value'   => $document_types,
					'compare' => 'IN',
				),
			);
		}

		return array();
	}

	/**
	 * Restrict an author query to users who can edit posts.
	 *
	 * @param array $query User query arguments.
	 *
	 * @return array
	 */
	private function add_edit_capability_to_user_query( array $query ) {
		if ( version_compare( get_bloginfo( 'version' ), '5.9-alpha', '>=' ) ) {
			$query['capability'] = array( 'edit_posts' );
		} else {
			$query['who'] = 'authors';
		}

		return $query;
	}

	/**
	 * Restrict post searches for roles that cannot edit other users' content.
	 *
	 * @param array $query WP_Query arguments.
	 *
	 * @return array
	 */
	private function restrict_post_query_to_current_user( array $query ) {
		$post_types = (array) ( $query['post_type'] ?? 'any' );

		foreach ( $post_types as $post_type ) {
			$edit_others_capability = 'edit_others_posts';

			if ( 'any' !== $post_type ) {
				$post_type_object = get_post_type_object( $post_type );
				if ( $post_type_object && ! empty( $post_type_object->cap->edit_others_posts ) ) {
					$edit_others_capability = $post_type_object->cap->edit_others_posts;
				}
			}

			if ( ! current_user_can( $edit_others_capability ) ) {
				$query['author'] = get_current_user_id();
				break;
			}
		}

		return $query;
	}

	/**
	 * Validate autocomplete data and build allowlisted query arguments.
	 *
	 * Supported server-side objects are post, attachment, taxonomy, author, user,
	 * and Elementor library template. JavaScript resolves cpt_tax to tax before
	 * sending the request. Display modes are limited to minimal and detailed.
	 *
	 * @param array $data Autocomplete request data.
	 *
	 * @return array|\WP_Error
	 */
	private function autocomplete_query_data( $data ) {
		if ( empty( $data['autocomplete'] ) || ! is_array( $data['autocomplete'] ) || empty( $data['q'] ) || empty( $data['autocomplete']['object'] ) ) {
			return new \WP_Error( self::AUTOCOMPLETE_ERROR_CODE, 'Empty or incomplete data' );
		}

		if ( ! is_scalar( $data['autocomplete']['object'] ) ) {
			return new \WP_Error( self::AUTOCOMPLETE_ERROR_CODE, 'Unsupported query object' );
		}

		$object = sanitize_key( (string) $data['autocomplete']['object'] );
		if ( ! in_array( $object, self::$supported_objects_for_query, true ) ) {
			return new \WP_Error( self::AUTOCOMPLETE_ERROR_CODE, 'Unsupported query object' );
		}

		$display = isset( $data['autocomplete']['display'] ) && is_scalar( $data['autocomplete']['display'] ) ? sanitize_key( (string) $data['autocomplete']['display'] ) : 'minimal';
		if ( ! in_array( $display, array( 'minimal', 'detailed' ), true ) ) {
			$display = 'minimal';
		}

		$by_field = isset( $data['autocomplete']['by_field'] ) && is_scalar( $data['autocomplete']['by_field'] ) ? sanitize_key( (string) $data['autocomplete']['by_field'] ) : 'term_taxonomy_id';
		if ( ! in_array( $by_field, array( 'term_id', 'term_taxonomy_id' ), true ) ) {
			$by_field = 'term_taxonomy_id';
		}

		$data['q']            = $this->sanitize_search_term( $data['q'] );
		$data['autocomplete'] = array(
			'object'   => $object,
			'display'  => $display,
			'by_field' => $by_field,
			'query'    => isset( $data['autocomplete']['query'] ) && is_array( $data['autocomplete']['query'] ) ? $data['autocomplete']['query'] : array(),
		);

		if ( '' === $data['q'] ) {
			return new \WP_Error( self::AUTOCOMPLETE_ERROR_CODE, 'Empty search term' );
		}

		$method_name = 'autocomplete_query_for_' . $object;
		$query       = $this->$method_name( $data );
		if ( is_wp_error( $query ) ) {
			return $query;
		}

		$autocomplete          = $data['autocomplete'];
		$autocomplete['query'] = $query;

		return $autocomplete;
	}

	/**
	 * Build an allowlisted post autocomplete query.
	 *
	 * @param array $data Sanitized autocomplete request.
	 *
	 * @return array
	 */
	private function autocomplete_query_for_post( $data ) {
		$post_types = $this->sanitize_post_types( $data['autocomplete']['query']['post_type'] ?? 'any', true );

		$query = array(
			'post_type'      => empty( $post_types ) ? 'any' : $post_types,
			'posts_per_page' => self::POST_QUERY_LIMIT,
			's'              => $data['q'],
		);

		return $this->restrict_post_query_to_current_user( $query );
	}

	/**
	 * Build an allowlisted Elementor template autocomplete query.
	 *
	 * @param array $data Sanitized autocomplete request.
	 *
	 * @return array
	 */
	private function autocomplete_query_for_library_template( $data ) {
		$query = array(
			'post_type'      => Source_Local::CPT,
			'orderby'        => 'meta_value',
			'order'          => 'ASC',
			'posts_per_page' => self::POST_QUERY_LIMIT,
			's'              => $data['q'],
		);

		$meta_query = $this->sanitize_library_meta_query( $data['autocomplete']['query'] );
		if ( ! empty( $meta_query ) ) {
			$query['meta_query'] = $meta_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Allowlisted Elementor document type filter.
		}

		return $this->restrict_post_query_to_current_user( $query );
	}

	private function autocomplete_query_for_attachment( $data ) {
		$query = $this->autocomplete_query_for_post( $data );
		if ( is_wp_error( $query ) ) {
			return $query;
		}
		$query['post_type']   = 'attachment';
		$query['post_status'] = 'inherit';

		return $this->restrict_post_query_to_current_user( $query );
	}

	private function autocomplete_query_for_tax( $data ) {
		$requested_query = $data['autocomplete']['query'];
		$taxonomies      = $this->sanitize_taxonomies( $requested_query['taxonomy'] ?? array() );

		if ( empty( $taxonomies ) && ! empty( $requested_query['post_type'] ) ) {
			$post_types = $this->sanitize_post_types( $requested_query['post_type'] );
			$taxonomies = $this->sanitize_taxonomies( get_object_taxonomies( $post_types ) );
		}

		if ( empty( $taxonomies ) ) {
			return new \WP_Error( self::AUTOCOMPLETE_ERROR_CODE, 'Missing valid taxonomy' );
		}

		return array(
			'taxonomy'   => $taxonomies,
			'search'     => $data['q'],
			'hide_empty' => false,
			'number'     => self::AUTOCOMPLETE_LIMIT,
		);
	}

	private function autocomplete_query_for_author( $data ) {
		$query                        = $this->build_autocomplete_user_query( $data );
		$query['has_published_posts'] = true;

		return $this->add_edit_capability_to_user_query( $query );
	}

	private function autocomplete_query_for_user( $data ) {
		if ( ! current_user_can( 'list_users' ) ) {
			return new \WP_Error( self::AUTOCOMPLETE_ERROR_CODE, 'Insufficient permission to query users' );
		}

		return $this->build_autocomplete_user_query( $data );
	}

	/**
	 * Build the shared user/author autocomplete query.
	 *
	 * @param array $data Sanitized autocomplete request.
	 *
	 * @return array
	 */
	private function build_autocomplete_user_query( $data ) {
		$query = array(
			'fields'         => array(
				'ID',
				'display_name',
			),
			'number'         => self::AUTOCOMPLETE_LIMIT,
			'search'         => '*' . $data['q'] . '*',
			'search_columns' => array(
				'user_login',
				'user_nicename',
			),
		);
		if ( 'detailed' === $data['autocomplete']['display'] && current_user_can( 'list_users' ) ) {
			$query['fields'][] = 'user_email';
		}

		return $query;
	}

	private function get_titles_query_data( $data ) {
		if ( empty( $data['get_titles'] ) || ! is_array( $data['get_titles'] ) || empty( $data['id'] ) || empty( $data['get_titles']['object'] ) ) {
			return new \WP_Error( self::GET_TITLES_ERROR_CODE, 'Empty or incomplete data' );
		}

		if ( ! is_scalar( $data['get_titles']['object'] ) ) {
			return new \WP_Error( self::GET_TITLES_ERROR_CODE, 'Unsupported query object' );
		}

		$object = sanitize_key( (string) $data['get_titles']['object'] );
		if ( ! in_array( $object, self::$supported_objects_for_query, true ) ) {
			return new \WP_Error( self::GET_TITLES_ERROR_CODE, 'Unsupported query object' );
		}

		$display = isset( $data['get_titles']['display'] ) && is_scalar( $data['get_titles']['display'] ) ? sanitize_key( (string) $data['get_titles']['display'] ) : 'minimal';
		if ( ! in_array( $display, array( 'minimal', 'detailed' ), true ) ) {
			$display = 'minimal';
		}

		$by_field = isset( $data['get_titles']['by_field'] ) && is_scalar( $data['get_titles']['by_field'] ) ? sanitize_key( (string) $data['get_titles']['by_field'] ) : 'term_taxonomy_id';
		if ( ! in_array( $by_field, array( 'term_id', 'term_taxonomy_id' ), true ) ) {
			$by_field = 'term_taxonomy_id';
		}

		$ids = array_map(
			static function ( $id ) {
				return is_scalar( $id ) ? absint( $id ) : 0;
			},
			(array) $data['id']
		);
		$ids = array_slice( array_values( array_unique( array_filter( $ids ) ) ), 0, self::GET_TITLES_LIMIT );
		if ( empty( $ids ) ) {
			return new \WP_Error( self::GET_TITLES_ERROR_CODE, 'Missing valid IDs' );
		}

		$data['id']         = $ids;
		$data['get_titles'] = array(
			'object'   => $object,
			'display'  => $display,
			'by_field' => $by_field,
			'query'    => isset( $data['get_titles']['query'] ) && is_array( $data['get_titles']['query'] ) ? $data['get_titles']['query'] : array(),
		);

		$method_name = 'get_titles_query_for_' . $object;
		$query       = $this->$method_name( $data );
		if ( is_wp_error( $query ) ) {
			return $query;
		}

		$get_titles          = $data['get_titles'];
		$get_titles['query'] = $query;

		return $get_titles;
	}

	private function get_titles_query_for_post( $data ) {
		$post_types = $this->sanitize_post_types( $data['get_titles']['query']['post_type'] ?? 'any', true );

		return array(
			'post_type'      => empty( $post_types ) ? 'any' : $post_types,
			'posts_per_page' => count( $data['id'] ),
			'post__in'       => $data['id'],
		);
	}

	private function get_titles_query_for_attachment( $data ) {
		$query                = $this->get_titles_query_for_post( $data );
		$query['post_type']   = 'attachment';
		$query['post_status'] = 'inherit';

		return $query;
	}

	private function get_titles_query_for_tax( $data ) {
		$by_field = $data['get_titles']['by_field'];
		$query    = array(
			'hide_empty' => false,
		);

		if ( 'term_id' === $by_field ) {
			$query['include'] = $data['id'];
		} else {
			$query['term_taxonomy_id'] = $data['id'];
		}

		$taxonomies = $this->sanitize_taxonomies( $data['get_titles']['query']['taxonomy'] ?? array() );
		if ( empty( $taxonomies ) && ! empty( $data['get_titles']['query']['post_type'] ) ) {
			$post_types = $this->sanitize_post_types( $data['get_titles']['query']['post_type'] );
			$taxonomies = $this->sanitize_taxonomies( get_object_taxonomies( $post_types ) );
		}
		if ( ! empty( $taxonomies ) ) {
			$query['taxonomy'] = $taxonomies;
		} else {
			return new \WP_Error( self::GET_TITLES_ERROR_CODE, 'Missing valid taxonomy' );
		}

		return $query;
	}

	private function get_titles_query_for_library_template( $data ) {
		$query = array(
			'post_type'      => Source_Local::CPT,
			'orderby'        => 'meta_value',
			'order'          => 'ASC',
			'posts_per_page' => count( $data['id'] ),
			'post__in'       => $data['id'],
		);

		$meta_query = $this->sanitize_library_meta_query( $data['get_titles']['query'] );
		if ( ! empty( $meta_query ) ) {
			$query['meta_query'] = $meta_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Allowlisted Elementor document type filter.
		}

		return $query;
	}

	private function get_titles_query_for_author( $data ) {
		$query                        = $this->build_titles_user_query( $data );
		$query['has_published_posts'] = true;

		return $this->add_edit_capability_to_user_query( $query );
	}

	private function get_titles_query_for_user( $data ) {
		if ( ! current_user_can( 'list_users' ) ) {
			return new \WP_Error( self::GET_TITLES_ERROR_CODE, 'Insufficient permission to query users' );
		}

		return $this->build_titles_user_query( $data );
	}

	/**
	 * Build the shared saved user/author title query.
	 *
	 * @param array $data Sanitized title request.
	 *
	 * @return array
	 */
	private function build_titles_user_query( $data ) {
		$query = array(
			'fields'  => array(
				'ID',
				'display_name',
			),
			'include' => $data['id'],
			'number'  => count( $data['id'] ),
		);
		if ( 'detailed' === $data['get_titles']['display'] && current_user_can( 'list_users' ) ) {
			$query['fields'][] = 'user_email';
		}

		return $query;
	}

	/**
	 * @param \WP_Post $post
	 * @param string   $display
	 * @return mixed|string
	 */
	private function format_post_for_display( $post, $display ) {
		$text          = '';
		$post_type_obj = get_post_type_object( $post->post_type );
		if ( ! $post_type_obj ) {
			return esc_html( $post->post_title );
		}

		switch ( $display ) {
			case 'minimal':
				$text = ( $post_type_obj->hierarchical ) ? $this->get_post_name_with_parents( $post ) : $post->post_title;
				break;
			case 'detailed':
				$post_title = $post_type_obj->hierarchical ? $this->get_post_name_with_parents( $post ) : $post->post_title;
				$text       = $post_type_obj->labels->name . ': ' . $post_title;
				break;
		}

		return esc_html( $text );
	}

	/**
	 * @param \WP_User $user
	 * @param string   $display
	 * @return string $text
	 */
	private function format_user_for_display( $user, $display ) {
		$text = $user->display_name;

		switch ( $display ) {
			case 'detailed':
				if ( current_user_can( 'list_users' ) && ! empty( $user->user_email ) ) {
					$text = sprintf( '%s (%s)', $user->display_name, $user->user_email );
				}
				break;
		}

		return esc_html( $text );
	}

	/**\
	 * @param string $control_name
	 *
	 * @return mixed|null
	 */
	private function get_widget_settings( $control_name ) {
		return isset( $this->widget_settings[ $control_name ] ) ? $this->widget_settings[ $control_name ] : null;
	}

	public function get_query( array $settings, $post_type = 'post' ) {
		$this->widget_settings = $settings;
		$this->post_type       = $post_type;
		$this->build_query_args( $settings );

		if ( 'current_query' === $settings['query_source'] ) {
			global $wp_query;
			$query = $wp_query;
		} else {
			$query_args = $this->get_query_args();

			$query = new \WP_Query( $query_args );
		}

		return $query;
	}

	public function get_query_args() {
		return $this->query_args;
	}

	private function build_query_args( $settings ) {
		if ( 'current_query' === $settings['query_source'] ) {
			global $wp_query;

			$this->query_args = $wp_query->query_vars;

			$this->query_args['nopaging']    = false;
			$this->query_args['post_status'] = 'publish';

			$this->query_args['paged'] = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
		} else {
			$number  = ! empty( $settings['query_number'] ) ? $settings['query_number'] : get_option( 'posts_per_page' );
			$orderby = ! empty( $settings['query_orderby'] ) ? $settings['query_orderby'] : 'date';
			$order   = ! empty( $settings['query_order'] ) ? $settings['query_order'] : 'DESC';

			$number = intval( $number );

			if ( -1 === $number ) {
				// Use big number instead of -1 to make query offset working properly.
				$number = 9999;
			}

			$this->query_args = array(
				'post_type'      => $this->post_type,
				'posts_per_page' => $number,
				'orderby'        => $orderby,
				'order'          => $order,
				'post_status'    => 'publish',
			);

			if ( ! empty( $settings['query_offset'] ) ) {
				$this->query_args['offset'] = $settings['query_offset'];
			}

			if ( in_array( $settings['query_orderby'], array( 'meta_value', 'meta_value_num' ), true ) ) {
				$this->query_args['meta_key'] = $settings['query_sort_meta_key'];
			}

			$this->set_terms_args();
			$this->set_author_args();

			if ( get_query_var( 'paged' ) ) {
				$this->query_args['paged'] = get_query_var( 'paged' );
			} elseif ( get_query_var( 'page' ) ) {
				$this->query_args['paged'] = get_query_var( 'page' );
			} else {
				$this->query_args['paged'] = 1;
			}
		}
	}

	/**
	 * @param string $key
	 * @param mixed  $value
	 */
	private function set_query_arg( $key, $value ) {
		if ( ! isset( $this->query_args[ $key ] ) ) {
			$this->query_args[ $key ] = $value;
		}
	}

	private function build_terms_query( $control_id, $exclude = false ) {
		$settings_terms = $this->get_widget_settings( $control_id );

		if ( empty( $settings_terms ) ) {
			return;
		}

		$terms = array();

		// Switch to term_id in order to get all term children (sub-categories):
		foreach ( $settings_terms as $id ) {
			$term_data = get_term_by( 'term_taxonomy_id', $id );

			if ( false !== $term_data ) {
				$taxonomy             = $term_data->taxonomy;
				$terms[ $taxonomy ][] = $term_data->slug;
			}
		}

		$this->insert_tax_query( $terms, $exclude );
	}

	private function insert_tax_query( $terms, $exclude ) {
		$tax_query = array();
		foreach ( $terms as $taxonomy => $ids ) {
			$query = array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $ids,
			);

			if ( $exclude ) {
				$query['operator'] = 'NOT IN';
			}

			$tax_query[] = $query;
		}

		if ( empty( $tax_query ) ) {
			return;
		}

		if ( empty( $this->query_args['tax_query'] ) ) {
			$this->query_args['tax_query'] = $tax_query;
		} else {
			$this->query_args['tax_query']['relation'] = 'AND';
			$this->query_args['tax_query'][]           = $tax_query;
		}
	}

	private function set_terms_args() {
		$this->build_terms_query( 'query_include_term_ids' );
		$this->build_terms_query( 'query_exclude_term_ids', true );
	}

	private function set_author_args() {
		$include_authors = $this->get_widget_settings( 'query_include_authors' );
		if ( ! empty( $include_authors ) ) {
			$this->set_query_arg( 'author__in', $include_authors );
		}

		$exclude_authors = $this->get_widget_settings( 'query_exclude_authors' );
		if ( ! empty( $exclude_authors ) ) {
			//exclude only if not explicitly included
			if ( empty( $this->query_args['author__in'] ) ) {
				$this->set_query_arg( 'author__not_in', $exclude_authors );
			}
		}
	}
}

Module_Query_Base::instance()->initialize();
