<?php

namespace Billey_Elementor;

use Elementor\Plugin;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || exit;

class Modify_Widget_Section extends Modify_Base {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function initialize() {
		add_action(
			'elementor/element/section/section_layout/after_section_end',
			array(
				$this,
				'section_layout',
			)
		);

		add_action(
			'elementor/element/inner-section/section_layout/after_section_end',
			array(
				$this,
				'section_layout',
			)
		);

		add_action(
			'elementor/element/container/section_layout_container/before_section_end',
			array(
				$this,
				'container_layout',
			)
		);

		add_action(
			'elementor/element/container/section_layout_additional_options/before_section_end',
			array(
				$this,
				'container_additional_options',
			)
		);
	}

	/**
	 * Add theme-specific boxed content alignment to Containers.
	 *
	 * Elementor already provides native gap and flex alignment controls. This
	 * control only restores the theme's legacy boxed content positioning option.
	 *
	 * @param \Elementor\Controls_Stack $element The edited element.
	 */
	public function container_layout( $element ) {
		$element->start_injection(
			array(
				'type' => 'control',
				'at'   => 'after',
				'of'   => 'content_width',
			)
		);

		$element->add_control(
			'content_alignment',
			array(
				'label'                => esc_html__( 'Content Alignment', 'billey' ),
				'type'                 => Controls_Manager::CHOOSE,
				'options'              => Widget_Utils::get_control_options_horizontal_alignment(),
				'default'              => 'center',
				'toggle'               => false,
				'selectors_dictionary' => array(
					'left'   => 'margin-left: 0; margin-right: auto;',
					'center' => 'margin-left: auto; margin-right: auto;',
					'right'  => 'margin-left: auto; margin-right: 0;',
				),
				'selectors'            => array(
					'{{WRAPPER}} > .e-con-inner' => '{{VALUE}}',
				),
				'condition'            => array(
					'content_width' => 'boxed',
				),
			)
		);

		$element->end_injection();
	}

	/**
	 * Add the theme's child hover stacking option to Containers.
	 *
	 * @param \Elementor\Controls_Stack $element The edited element.
	 */
	public function container_additional_options( $element ) {
		$element->start_injection(
			array(
				'type' => 'control',
				'at'   => 'after',
				'of'   => 'overflow',
			)
		);

		$element->add_control(
			'column_hover_high_zindex',
			array(
				'label'        => esc_html__( 'High Z-Index on hover columns?', 'billey' ),
				'label_block'  => false,
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'elementor-section-columns-hover-',
				'return_value' => 'high-z-index',
				'selectors'    => array(
					'{{WRAPPER}} > .e-con:hover' => 'z-index: 1;',
					'{{WRAPPER}} > .e-con-inner > .e-con:hover' => 'z-index: 1;',
				),
			)
		);

		$element->end_injection();
	}

	/**
	 * Update section gap control in layout section.
	 *
	 * @param \Elementor\Controls_Stack $element The edited element.
	 */
	public function section_layout( $element ) {
		// Get section args.
		$section_gap = Plugin::instance()->controls_manager->get_control_from_stack( $element->get_unique_name(), 'gap' );

		if ( ! empty( $section_gap['options'] ) ) {
			$gap_options = $section_gap['options'];

			// Change 'Default' => 'Normal' text.
			if ( isset( $gap_options['default'] ) ) {
				$gap_options['default'] = esc_html__( 'Normal', 'billey' );
			}

			if ( isset( $gap_options['no'] ) ) {
				$gap_options['no'] = esc_html__( 'No Gap', 'billey' );
			}

			if ( isset( $gap_options['narrow'] ) ) {
				$gap_options['narrow'] = esc_html__( 'Narrow', 'billey' );
			}

			if ( isset( $gap_options['extended'] ) ) {
				$gap_options['extended'] = esc_html__( 'Extended', 'billey' );
			}

			if ( isset( $gap_options['wide'] ) ) {
				$gap_options['wide'] = esc_html__( 'Wide', 'billey' );
			}

			if ( isset( $gap_options['wider'] ) ) {
				$gap_options['wider'] = esc_html__( 'Wider', 'billey' );
			}

			// Add new gap option 'custom'.
			if ( ! isset( $gap_options['custom'] ) ) {
				$gap_options['custom'] = esc_html__( 'Custom', 'billey' );
			}

			// Set new options.
			$section_gap['options'] = $gap_options;
		}

		// Change default gap setting from 'default' => 'extended'.
		$section_gap['default'] = 'extended';

		// Apply gap changed.
		$element->update_control( 'gap', $section_gap );

		$element->start_injection(
			array(
				'type' => 'control',
				'at'   => 'after',
				'of'   => 'gap',
			)
		);

		$element->add_control(
			'gap_beside',
			array(
				'label'        => esc_html__( 'Gap Beside', 'billey' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'yes',
				'options'      => array(
					'no'  => esc_html__( 'No', 'billey' ),
					'yes' => esc_html__( 'Yes', 'billey' ),
				),
				'prefix_class' => 'elementor-section-gap-beside-',
				'condition'    => array(
					'gap!' => 'no',
				),
			)
		);

		$element->add_responsive_control(
			'gap_width',
			array(
				'label'     => esc_html__( 'Gap Width', 'billey' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min'  => 0,
						'max'  => 100,
						'step' => 2,
					),
				),
				'selectors' => array(
					// Legacy DOM with .elementor-row.
					'{{WRAPPER}} > .elementor-column-gap-custom > .elementor-row > .elementor-column > .elementor-element-populated' => 'padding-left: calc( {{SIZE}}{{UNIT}} / 2); padding-right: calc( {{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}}.elementor-section-gap-beside-no > .elementor-column-gap-custom > .elementor-row' => 'margin-left: calc( -{{SIZE}}{{UNIT}} / 2); margin-right: calc( -{{SIZE}}{{UNIT}} / 2);',
					// Optimized DOM without .elementor-row (Elementor 3.x+).
					'{{WRAPPER}} > .elementor-column-gap-custom > .elementor-column > .elementor-element-populated' => 'padding-left: calc( {{SIZE}}{{UNIT}} / 2); padding-right: calc( {{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}}.elementor-section-gap-beside-no > .elementor-column-gap-custom' => 'margin-left: calc( -{{SIZE}}{{UNIT}} / 2); margin-right: calc( -{{SIZE}}{{UNIT}} / 2);',
				),
				'condition' => array(
					'gap' => 'custom',
				),
			)
		);

		$element->end_injection();

		// Add control custom alignment of content.
		$element->start_injection(
			array(
				'type' => 'control',
				'at'   => 'before',
				'of'   => 'content_position',
			)
		);

		$element->add_control(
			'content_alignment',
			array(
				'label'        => esc_html__( 'Content Alignment', 'billey' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => Widget_Utils::get_control_options_horizontal_alignment(),
				'default'      => 'center',
				'toggle'       => false,
				'prefix_class' => 'elementor-section-content-align-',
				'condition'    => array(
					'content_width!' => '',
				),
			)
		);

		$element->add_control(
			'column_vertical_alignment',
			array(
				'label'                => esc_html__( 'Column Vertical Alignment', 'billey' ),
				'label_block'          => true,
				'type'                 => Controls_Manager::CHOOSE,
				'options'              => Widget_Utils::get_control_options_vertical_full_alignment(),
				'default'              => 'stretch',
				'toggle'               => false,
				'prefix_class'         => 'elementor-section-column-vertical-align-',
				'selectors'            => array(
					'{{WRAPPER}} > .elementor-container > .elementor-row' => 'align-items: {{VALUE}}',
					'{{WRAPPER}} > .elementor-container' => 'align-items: {{VALUE}}',
				),
				'selectors_dictionary' => array(
					'top'    => 'flex-start',
					'middle' => 'center',
					'bottom' => 'flex-end',
				),
			)
		);

		$element->update_control(
			'content_position',
			array(
				'condition' => array(
					'column_vertical_alignment' => 'stretch',
				),
			)
		);

		$element->end_injection();

		// Add control custom alignment of content.
		$element->start_injection(
			array(
				'type' => 'control',
				'at'   => 'after',
				'of'   => 'overflow',
			)
		);

		$element->add_control(
			'column_hover_high_zindex',
			array(
				'label'        => esc_html__( 'High Z-Index on hover columns?', 'billey' ),
				'label_block'  => false,
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'elementor-section-columns-hover-',
				'return_value' => 'high-z-index',
				'selectors'    => array(
					'{{WRAPPER}} > .elementor-container > .elementor-row > .elementor-column:hover' => 'z-index: 1;',
					'{{WRAPPER}} > .elementor-container > .elementor-column:hover'                  => 'z-index: 1;',
				),
			)
		);

		$element->end_injection();
	}
}

Modify_Widget_Section::instance()->initialize();
