<?php

namespace Billey_Elementor;

use Elementor\Controls_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

defined( 'ABSPATH' ) || exit;

class Modify_Widget_Heading extends Modify_Base {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function initialize() {
		add_action( 'elementor/element/heading/section_title_style/before_section_end', [
			$this,
			'before_end_section_title_style',
		] );

		add_action( 'elementor/element/heading/section_title_style/after_section_end', [
			$this,
			'section_title_style',
		] );
	}

	/**
	 * @param \Elementor\Widget_Base $element The edited element.
	 */
	public function before_end_section_title_style( $element ) {
		// Current Elementor keeps the Heading colors in Normal/Hover tabs and ships a
		// native "title_hover_color" (Hover tab). Anchor our legacy "link_hover_color"
		// right after it when present so both hover controls group together; fall back
		// to the always-present "title_color" on older Elementor that lacks it. The
		// control is added in every case, so pages that already saved a value keep it.
		$controls = $element->get_controls();
		$anchor   = isset( $controls['title_hover_color'] ) ? 'title_hover_color' : 'title_color';

		$element->start_injection( [
			'type' => 'control',
			'at'   => 'after',
			'of'   => $anchor,
		] );

		$element->add_control( 'link_hover_color', [
			'label'     => esc_html__( 'Link Hover Color', 'billey' ),
			'type'      => Controls_Manager::COLOR,
			'global'    => [
				'default' => Global_Colors::COLOR_PRIMARY,
			],
			'selectors' => [
				// Stronger selector to avoid section style from overwriting.
				'{{WRAPPER}}.elementor-widget-heading .elementor-heading-title a:hover' => 'color: {{VALUE}} !important;',
			],
		] );

		$element->end_injection();
	}

	/**
	 * @param \Elementor\Widget_Base $element The edited element.
	 */
	public function section_title_style( $element ) {
		// has_widget_inner_wrapper() only exists since Elementor 3.26 (Optimized Markup); older markup always has the wrapper.
		$alignment_selector = ! method_exists( $element, 'has_widget_inner_wrapper' ) || $element->has_widget_inner_wrapper()
			? '{{WRAPPER}} .elementor-widget-container'
			: '{{WRAPPER}}';

		$element->start_controls_section( 'heading_dimension_section', [
			'tab'   => Controls_Manager::TAB_STYLE,
			'label' => esc_html__( 'Dimension', 'billey' ),
		] );

		$element->add_responsive_control( 'heading_max_width', [
			'label'          => esc_html__( 'Max Width', 'billey' ),
			'type'           => Controls_Manager::SLIDER,
			'default'        => [
				'unit' => 'px',
			],
			'tablet_default' => [
				'unit' => 'px',
			],
			'mobile_default' => [
				'unit' => 'px',
			],
			'size_units'     => [ 'px', '%' ],
			'range'          => [
				'%'  => [
					'min' => 1,
					'max' => 100,
				],
				'px' => [
					'min' => 1,
					'max' => 1600,
				],
			],
			'selectors'      => [
				'{{WRAPPER}} .elementor-heading-title' => 'max-width: {{SIZE}}{{UNIT}};',
			],
		] );

		$element->add_responsive_control( 'alignment', [
			'label'                => esc_html__( 'Alignment', 'billey' ),
			'label_block'          => false,
			'type'                 => Controls_Manager::CHOOSE,
			'options'              => Widget_Utils::get_control_options_horizontal_alignment(),
			'selectors_dictionary' => [
				'left'  => 'flex-start',
				'right' => 'flex-end',
			],
			'selectors'            => [
				$alignment_selector => 'display: flex; justify-content: {{VALUE}}',
			],
		] );

		$element->end_controls_section();
	}
}

Modify_Widget_Heading::instance()->initialize();
