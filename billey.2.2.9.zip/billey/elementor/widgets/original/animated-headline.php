<?php

namespace Billey_Elementor;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || exit;

class Modify_Widget_Animated_Headline extends Modify_Base {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function initialize() {
		add_action( 'elementor/element/animated-headline/section_style_text/before_section_end', [
			$this,
			'before_end_section_style_text',
		] );

		add_action( 'elementor/element/animated-headline/section_style_text/after_section_end', [
			$this,
			'add_dimension_section',
		] );
	}

	/**
	 * @param \Elementor\Widget_Base $element The edited element.
	 */
	public function add_dimension_section( $element ) {
		// has_widget_inner_wrapper() only exists since Elementor 3.26 (Optimized Markup); older markup always has the wrapper.
		$alignment_selector = ! method_exists( $element, 'has_widget_inner_wrapper' ) || $element->has_widget_inner_wrapper()
			? '{{WRAPPER}} .elementor-widget-container'
			: '{{WRAPPER}}';

		$element->start_controls_section( 'heading_dimension_section', [
			'tab'   => Controls_Manager::TAB_STYLE,
			'label' => esc_html__( 'Dimension', 'billey' ),
		] );

		$element->add_responsive_control( 'heading_max_width', [
			'label'          => esc_html__( 'Max Width', 'billey' ),
			'type'           => Controls_Manager::SLIDER,
			'default'        => [
				'unit' => 'px',
			],
			'tablet_default' => [
				'unit' => 'px',
			],
			'mobile_default' => [
				'unit' => 'px',
			],
			'size_units'     => [ 'px', '%' ],
			'range'          => [
				'%'  => [
					'min' => 1,
					'max' => 100,
				],
				'px' => [
					'min' => 1,
					'max' => 1600,
				],
			],
			'selectors'      => [
				'{{WRAPPER}} .elementor-headline' => 'max-width: {{SIZE}}{{UNIT}};',
			],
		] );

		$element->add_responsive_control( 'heading_alignment', [
			'label'                => esc_html__( 'Alignment', 'billey' ),
			'label_block'          => false,
			'type'                 => Controls_Manager::CHOOSE,
			'options'              => Widget_Utils::get_control_options_horizontal_alignment(),
			'selectors_dictionary' => [
				'left'  => 'flex-start',
				'right' => 'flex-end',
			],
			'selectors'            => [
				$alignment_selector => 'display: flex; justify-content: {{VALUE}}',
			],
		] );

		$element->end_controls_section();
	}

	/**
	 * @param \Elementor\Widget_Base $element The edited element.
	 */
	public function before_end_section_style_text( $element ) {
		$element->start_injection( [
			'type' => 'control',
			'at'   => 'after',
			'of'   => 'heading_words_style',
		] );

		$element->add_responsive_control( 'words_before_spacing', [
			'label'     => esc_html__( 'Before Spacing', 'billey' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => [
				'px' => [
					'min' => 0,
					'max' => 200,
				],
			],
			'selectors' => [
				'{{WRAPPER}} .elementor-headline-dynamic-wrapper' => 'margin-left: {{SIZE}}{{UNIT}};',
			],
		] );

		$element->add_responsive_control( 'words_after_spacing', [
			'label'     => esc_html__( 'After Spacing', 'billey' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => [
				'px' => [
					'min' => 0,
					'max' => 200,
				],
			],
			'selectors' => [
				'{{WRAPPER}} .elementor-headline-dynamic-wrapper' => 'margin-right: {{SIZE}}{{UNIT}};',
			],
		] );

		$element->end_injection();
	}
}

Modify_Widget_Animated_Headline::instance()->initialize();
