<?php

namespace Billey_Elementor;

defined( 'ABSPATH' ) || exit;

/**
 * Bring Billey's on-brand defaults to Elementor's Nested Accordion.
 *
 * Current Elementor deprecates the classic "accordion" widget and hides it from the
 * panel (the `nested-elements` experiment is stable & active by default), so anything
 * a user drops in is a "nested-accordion" with different markup (.e-n-accordion).
 * Legacy pages saved as the classic widget still render and keep using
 * Modify_Widget_Accordion + _accordion.scss — this class only touches the new
 * nested-accordion, so existing content is untouched while freshly added accordions
 * match the theme out of the box.
 *
 * Icon defaults are changed the same way the classic modifier does (via
 * update_control), which behaves exactly like a native default and stays fully
 * overridable. All other look & feel is left to Elementor's own Nested Accordion
 * style controls (space, distance, border, colours, typography) plus the small
 * brand line-colour default in widgets/original/_nested-accordion.scss.
 *
 * @since 2.2.6
 */
class Modify_Widget_Nested_Accordion extends Modify_Base {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function initialize() {
		add_action( 'elementor/element/nested-accordion/section_items/after_section_end', [
			$this,
			'update_default_icon',
		] );
	}

	/**
	 * Match the classic Billey accordion icon set: Font Awesome Pro Light plus/minus.
	 *
	 * The FA Pro Light assets are already loaded by the theme (class-font-awesome-pro.php),
	 * the same set the classic accordion used.
	 *
	 * @param \Elementor\Widget_Base $element The edited element.
	 */
	public function update_default_icon( $element ) {
		$element->update_control( 'accordion_item_title_icon', [
			'default' => [
				'value'   => 'fa-light fa-plus',
				'library' => 'fa-light',
			],
		] );

		$element->update_control( 'accordion_item_title_icon_active', [
			'default' => [
				'value'   => 'fa-light fa-minus',
				'library' => 'fa-light',
			],
		] );
	}
}

Modify_Widget_Nested_Accordion::instance()->initialize();
