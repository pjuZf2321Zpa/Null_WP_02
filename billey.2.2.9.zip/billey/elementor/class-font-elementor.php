<?php

namespace Billey_Elementor;

defined( 'ABSPATH' ) || exit;

class Font_Elementor {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function initialize() {
		/**
		 * Elementor uses Eicons for core widget controls and navigation glyphs when
		 * the Inline Font Icons experiment is disabled. Let Elementor manage the
		 * stylesheet so those glyphs remain available on the frontend.
		 */
	}

	public function add_eicons_to_icon_manager( $settings ) {
		$json_url = BILLEY_ELEMENTOR_ASSETS . '/libs/eicons/eicons.json';

		$settings['eicons'] = [
			'name'          => 'eicons',
			'label'         => esc_html__( 'Eicons', 'billey' ),
			'url'           => false,
			'enqueue'       => false,
			'prefix'        => 'eicon-',
			'displayPrefix' => '',
			'labelIcon'     => 'eicon-elementor-square',
			'ver'           => '5.3.0',
			'fetchJson'     => $json_url,
			'native'        => true,
		];

		return $settings;
	}
}

Font_Elementor::instance()->initialize();
