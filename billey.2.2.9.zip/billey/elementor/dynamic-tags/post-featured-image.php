<?php

namespace Billey_Elementor;

use Elementor\Controls_Manager;
use Elementor\Core\DynamicTags\Data_Tag;
use Elementor\Modules\DynamicTags\Module as TagsModule;

defined( 'ABSPATH' ) || exit;

/**
 * "Featured Image" dynamic tag.
 *
 * Provides the post featured image as a dynamic value for image/media fields
 * (e.g. a Section background) without requiring Elementor Pro. Falls back to a
 * user-defined media when the post has no thumbnail.
 */
class Tag_Post_Featured_Image extends Data_Tag {

	public function get_name() {
		return 'billey-post-featured-image';
	}

	public function get_title() {
		return esc_html__( 'Featured Image', 'billey' );
	}

	public function get_group() {
		return Dynamic_Tags_Init::GROUP;
	}

	public function get_categories() {
		return [
			TagsModule::IMAGE_CATEGORY,
			TagsModule::MEDIA_CATEGORY,
		];
	}

	protected function register_controls() {
		$this->add_control( 'fallback', [
			'label' => esc_html__( 'Fallback', 'billey' ),
			'type'  => Controls_Manager::MEDIA,
		] );
	}

	public function get_value( array $options = [] ) {
		$thumbnail_id = get_post_thumbnail_id();

		if ( $thumbnail_id ) {
			$image_src = wp_get_attachment_image_src( $thumbnail_id, 'full' );

			return [
				'id'  => $thumbnail_id,
				'url' => $image_src ? $image_src[0] : '',
			];
		}

		return $this->get_settings( 'fallback' );
	}
}
