<?php

namespace Billey_Elementor;

use Elementor\Core\DynamicTags\Tag;
use Elementor\Modules\DynamicTags\Module as TagsModule;

defined( 'ABSPATH' ) || exit;

/**
 * "Post Title" dynamic tag.
 *
 * Provides the Post Title tag without requiring Elementor Pro (only Pro
 * registers this tag in free Elementor). Rendered via core get_the_title().
 */
class Tag_Post_Title extends Tag {

	public function get_name() {
		return 'billey-post-title';
	}

	public function get_title() {
		return esc_html__( 'Post Title', 'billey' );
	}

	public function get_group() {
		return Dynamic_Tags_Init::GROUP;
	}

	public function get_categories() {
		return [ TagsModule::TEXT_CATEGORY ];
	}

	public function render() {
		echo wp_kses_post( get_the_title() );
	}
}
