<?php

namespace Billey_Elementor;

defined( 'ABSPATH' ) || exit;

/**
 * Register the theme's own dynamic tags for Elementor.
 *
 * Free Elementor ships the dynamic tags infrastructure but registers no content
 * tags (Post Title... are registered by Elementor Pro). This class fills that
 * gap so widgets (e.g. tm-heading) can use dynamic content without Pro.
 */
class Dynamic_Tags_Init {

	/**
	 * Group name shown in the dynamic tag panel.
	 */
	const GROUP = 'billey';

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function initialize() {
		add_action( 'elementor/dynamic_tags/register', [ $this, 'register_tags' ] );
	}

	/**
	 * @param \Elementor\Core\DynamicTags\Manager $dynamic_tags_manager
	 */
	public function register_tags( $dynamic_tags_manager ) {
		$dynamic_tags_manager->register_group( self::GROUP, [
			'title' => esc_html__( 'Billey', 'billey' ),
		] );

		require_once BILLEY_ELEMENTOR_DIR . '/dynamic-tags/post-title.php';
		require_once BILLEY_ELEMENTOR_DIR . '/dynamic-tags/post-featured-image.php';

		$dynamic_tags_manager->register( new Tag_Post_Title() );
		$dynamic_tags_manager->register( new Tag_Post_Featured_Image() );
	}
}

Dynamic_Tags_Init::instance()->initialize();
