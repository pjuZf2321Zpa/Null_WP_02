jQuery( document ).ready( function( $ ) {
	'use strict';

	var $body = $( 'body' );

	initQuantityButtons();
	initProductGalleries();
	initVariationGallery();
	initQuickViewPopup();

	function initQuantityButtons() {
		$( document ).on( 'click', '.quantity .increase, .quantity .decrease', function( evt ) {
			if ( $( this ).hasClass( 'disabled' ) ) {
				return false;
			}
			// Get values.
			var $qty       = $( this ).siblings( '.qty' ),
				currentVal = parseFloat( $qty.val() ),
				max        = parseFloat( $qty.attr( 'max' ) ),
				min        = parseFloat( $qty.attr( 'min' ) ),
				step       = $qty.attr( 'step' );

			// Format values.
			if ( !currentVal || currentVal === '' || currentVal === 'NaN' ) {
				currentVal = 0;
			}
			if ( max === '' || max === 'NaN' ) {
				max = '';
			}
			if ( min === '' || min === 'NaN' ) {
				min = 0;
			}
			if ( step === 'any' || step === '' || step === undefined || parseFloat( step ) === 'NaN' ) {
				step = 1;
			}

			// Change the value.
			if ( $( this ).is( '.increase' ) ) {
				if ( max && max === currentVal ) {
					evt.preventDefault();
				} else {
					if ( max && currentVal > max ) {
						$qty.val( max );
					} else {
						$qty.val( currentVal + parseFloat( step ) );
					}

					$qty.trigger( 'change' );
				}
			} else {
				if ( min && min === currentVal ) {
					evt.preventDefault();
				} else {
					if ( min && currentVal < min ) {
						$qty.val( min );
					} else if ( currentVal > 0 ) {
						$qty.val( currentVal - parseFloat( step ) );
					}

					$qty.trigger( 'change' );
				}
			}
		} );

		$( document ).on( 'blur', '.quantity .qty', function() {
			var $qty       = $( this ),
				currentVal = parseFloat( $qty.val() ),
				max        = parseFloat( $qty.attr( 'max' ) );

			if ( max !== '' && max !== 'NaN' && currentVal > max ) {
				$( this ).val( max );
			}
		} );
	}

	/**
	 * Init the single product gallery (Swiper main + thumbs) inside a .billey-product-gallery element.
	 */
	function initProductGallery( $gallery ) {
		if ( ! $gallery || ! $gallery.length ) {
			return;
		}

		// Keep the original markup (before Swiper mutates it) to restore after a variation gallery swap.
		if ( undefined === $gallery.data( 'billeyDefaultHtml' ) ) {
			$gallery.data( 'billeyDefaultHtml', $gallery.html() );
			$gallery.data( 'billeyCurrentHtml', $gallery.html() );
		}

		var $sliderWrap = $gallery.children( '.woo-single-gallery' );

		if ( ! $sliderWrap.length ) {
			return;
		}

		var options      = {},
		    thumbsSlider = null;

		if ( $sliderWrap.hasClass( 'has-thumbs-slider' ) ) {
			thumbsSlider = $sliderWrap.children( '.billey-thumbs-swiper' ).BilleySwiper();

			options = {
				thumbs: {
					swiper: thumbsSlider
				}
			};
		}

		var mainSlider = $sliderWrap.children( '.billey-main-swiper' ).BilleySwiper( options );

		if ( thumbsSlider ) {
			// Priority handler: runs before the Swiper thumbs module so the thumbs strip is positioned once.
			mainSlider.on( 'slideChange', function( swiper ) {
				keepActiveThumbVisible( swiper, thumbsSlider );
			}, true );
		}

		handleGalleryVideos( mainSlider );
	}

	/**
	 * Keep the active thumb away from the edges of the thumbs strip.
	 *
	 * When the active thumb is the first/last visible one and there are more thumbs on that side,
	 * scroll the thumbs strip so the neighbour thumb is visible (hint that more items exist).
	 */
	function keepActiveThumbVisible( mainSwiper, thumbsSwiper ) {
		if ( ! mainSwiper || ! thumbsSwiper || thumbsSwiper.destroyed || ! thumbsSwiper.slides ) {
			return;
		}

		var index   = mainSwiper.realIndex,
		    total   = thumbsSwiper.slides.length,
		    visible = thumbsSwiper.visibleSlidesIndexes || [];

		if ( total < 2 || ! visible.length ) {
			return;
		}

		var perView = 'auto' === thumbsSwiper.params.slidesPerView ? thumbsSwiper.slidesPerViewDynamic() : thumbsSwiper.params.slidesPerView,
		    first   = Math.min.apply( null, visible ),
		    last    = Math.max.apply( null, visible ),
		    target  = null;

		perView = Math.max( 1, Math.floor( perView ) );

		if ( index >= last && index < total - 1 ) {
			// Active thumb at (or beyond) the right edge: place it second to last so the next thumb shows.
			target = index - Math.max( 0, perView - 2 );
		} else if ( index <= first && index > 0 ) {
			// Active thumb at (or beyond) the left edge: place it second so the previous thumb shows.
			target = index - 1;
		}

		if ( null !== target ) {
			thumbsSwiper.slideTo( Math.max( 0, target ) );
		}
	}

	/**
	 * Play the (muted) gallery video of the active slide only, pause the others.
	 */
	function handleGalleryVideos( swiper ) {
		if ( ! swiper || ! swiper.wrapperEl ) {
			return;
		}

		var $videos = $( swiper.wrapperEl ).find( '.product-gallery-video video' );

		if ( ! $videos.length ) {
			return;
		}

		var playActive = function() {
			$videos.each( function() {
				this.pause();
			} );

			var $active = $( swiper.slides[ swiper.activeIndex ] ).find( 'video' );

			if ( $active.length ) {
				var playPromise = $active.get( 0 ).play();

				if ( playPromise && playPromise.catch ) {
					playPromise.catch( function() {} );
				}
			}
		};

		swiper.on( 'slideChangeTransitionEnd', playActive );
		playActive();
	}

	function destroyProductGallery( $gallery ) {
		// Destroy main slider first (it references the thumbs slider).
		$gallery.find( '.billey-main-swiper .swiper, .billey-thumbs-swiper .swiper' ).each( function() {
			if ( this.swiper ) {
				this.swiper.destroy( true, true );
			}
		} );

		var lightGallery = $gallery.data( 'lightGallery' );

		if ( lightGallery && lightGallery.destroy ) {
			lightGallery.destroy( true );
		}
	}

	function replaceProductGallery( $gallery, html ) {
		// Same markup already shown (e.g. two variations sharing one gallery): nothing to rebuild.
		if ( html === $gallery.data( 'billeyCurrentHtml' ) ) {
			return;
		}

		destroyProductGallery( $gallery );

		$gallery.html( html );
		$gallery.data( 'billeyCurrentHtml', html );

		initProductGallery( $gallery );

		if ( $gallery.hasClass( 'billey-light-gallery' ) ) {
			$( document ).trigger( 'billey_init_light_gallery', [ $gallery ] );
		}
	}

	function restoreProductGallery( $gallery ) {
		var html = $gallery.data( 'billeyDefaultHtml' );

		if ( ! $gallery.hasClass( 'billey-gallery-swapped' ) || undefined === html ) {
			return;
		}

		$gallery.removeClass( 'billey-gallery-swapped' );

		replaceProductGallery( $gallery, html );
	}

	function slideGalleryToImage( $gallery, imageId ) {
		var $main = $gallery.find( '.billey-main-swiper .swiper' ).first();

		if ( ! $main.length || ! $main.get( 0 ).swiper ) {
			return;
		}

		var swiper  = $main.get( 0 ).swiper,
		    $slides = $( swiper.wrapperEl ).children( '.swiper-slide' ),
		    $target = imageId ? $slides.filter( '[data-image-id="' + imageId + '"]' ) : $slides.filter( '.product-main-image' );

		if ( ! $target.length ) {
			return;
		}

		swiper.slideTo( $slides.index( $target.first() ) );
	}

	function initProductGalleries() {
		$( '.billey-product-gallery' ).each( function() {
			initProductGallery( $( this ) );
		} );
	}

	function getGalleryForVariationForm( $form ) {
		return $form.closest( '.product' ).find( '.billey-product-gallery' ).first();
	}

	/**
	 * Variation gallery: uses the WooCommerce variation form events.
	 * - Variation with its own gallery markup (variation.billey_gallery): swap the gallery.
	 * - Otherwise: restore the default gallery and slide to the variation image.
	 */
	function initVariationGallery() {
		$( document ).on( 'found_variation', '.variations_form', function( e, variation ) {
			var $gallery = getGalleryForVariationForm( $( this ) );

			if ( ! $gallery.length ) {
				return;
			}

			var style = $gallery.data( 'galleryStyle' ) || 'slider',
			    html  = variation && variation.billey_gallery && variation.billey_gallery[ style ] ? variation.billey_gallery[ style ] : '';

			if ( html ) {
				$gallery.addClass( 'billey-gallery-swapped' );
				replaceProductGallery( $gallery, html );

				return;
			}

			restoreProductGallery( $gallery );
			slideGalleryToImage( $gallery, variation ? variation.image_id : 0 );
		} ).on( 'reset_data', '.variations_form', function() {
			var $gallery = getGalleryForVariationForm( $( this ) );

			if ( ! $gallery.length ) {
				return;
			}

			restoreProductGallery( $gallery );
			slideGalleryToImage( $gallery, 0 );
		} );
	}

	function initQuickViewPopup() {
		$( '.billey-product' ).on( 'click', '.quick-view-btn', function( e ) {
			e.preventDefault();
			e.stopPropagation();

			var $button = $( this );

			var $actions = $button.parents( '.product-actions' ).first();
			$actions.addClass( 'refresh' );

			$button.addClass( 'loading' );
			var productID = $button.data( 'pid' );

			/**
			 * Avoid duplicate ajax request.
			 */
			var $popup = $body.children( '#' + 'popup-product-quick-view-content-' + productID );
			if ( $popup.length > 0 ) {
				openQuickViewPopup( $popup, $button );
			} else {
				var data = {
					action: 'product_quick_view',
					pid: productID,
					nonce: $button.data( 'pnonce' )
				};

				$.ajax( {
					url: $billey.ajaxurl,
					type: 'POST',
					data: data,
					dataType: 'json',
					success: function( results ) {
						$popup = $( results.template );
						$body.append( $popup );
						openQuickViewPopup( $popup, $button );
					},
				} );
			}
		} );
	}

	function openQuickViewPopup( $popup, $button ) {
		$button.removeClass( 'loading' );

		$.magnificPopup.open( {
			mainClass: 'mfp-fade popup-product-quick-view',
			items: {
				src: $popup.html(),
				type: 'inline'
			},
			callbacks: {
				open: function() {
					initProductGallery( this.content.find( '.billey-product-gallery' ).first() );

					this.content.find( '.entry-summary .inner-content' ).perfectScrollbar( {
						suppressScrollX: true
					} );
				},
			}
		} );
	}
} );
