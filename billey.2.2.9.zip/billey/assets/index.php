<?php

defined( 'ABSPATH' ) || exit;
// silence is golden, prevent direct access!
