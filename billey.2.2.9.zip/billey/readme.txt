=== Billey ===

Contributors: thememove
Tags: editor-style, featured-images, microformats, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready

Requires at least: 5.x.x
Tested up to: 5.3.x
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Billey - Ultimate Multipurpose Creative WordPress Theme

== Description ==

In creative design, being able to get identified as a unique, original, and classy individual or company means more than just showing off your talents directly. The creation of a professionally responsive & aesthetically beautiful website requires more than just a normal theme. It’s a pleasure to bring you our latest Minimal Creative Portfolio Theme for creative agencies, design houses, and other related businesses.

Adopting the minimal style with a black & white color scheme, Billey has an exquisite design that leaves no room for any outdated thing. From the typography, hovering style, Parallax scrolling, slider transition, spacing, and animation, all utilized the trending modern elements. Plus, the easy installation and customization of this theme mainly bases on drag & drop method from the Elementor page builder & Slider Revolution. You don’t need to be an expert, just a smart user is enough to work on this theme. Dig deeper into the details if you like. If you “fall”, only Billey can do that.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =


== Changelog ==

= 2.2.9 - October 22, 2026 =
- Updated:
Updated outdated templates of WooCommerce 11.2.0
Compatibility with WooCommerce 11.2.1 (cart & mini-cart item names include the selected "Any" variation values on WooCommerce 11.2.0+, single product meta categories ordered by hierarchy)
Compatibility with Elementor 4.3.5

= 2.2.8 - September 9, 2026 =
- Added:
Support WooCommerce "Product gallery videos" (beta) in the single product gallery (slider & list layouts)
Variation-specific gallery: switch the product gallery to the variation image / variation gallery images
- Updated:
Single product gallery: added prev/next navigation arrows on the main slider
Single product gallery: faster slide transition
Single product gallery: thumbnails auto-scroll when the active thumbnail is at the edge, so the next/previous thumbnail is visible
Updated outdated templates of WooCommerce 11.1.0
Compatibility with WooCommerce 11.1.0 (skip the WC variation gallery snapshot renders of the theme gallery template)
- Fixed:
Fix: "Related Products" option could not be disabled (legacy woocommerce_related_products_args filter)

= 2.2.7 - August 20, 2026 =
- Updated:
Updated outdated templates of WooCommerce 11.0.0
- Fixed:
Fix: Restore woocommerce_widget_shopping_cart_after_buttons hook in mini-cart

= 2.2.6 - July 24, 2026 =
- Updated:
ThemeMove Addons For Elementor plugin v.2.1.2
Compatibility with Elementor 4.2.0 & Elementor Pro 4.0.2
Register custom Elementor controls on Elementor's current elementor/controls/register hook
- Added:
Nested Accordion support (Elementor's default accordion) with Billey's Font Awesome Pro Light icons
- Fixed:
Text Stroke group control no longer overrides Elementor's built-in one used by Heading, Nested Accordion and Elementor Pro widgets
Heading Link Hover Color now groups with Elementor's native Hover color controls
Portfolio archive title override no longer affects other archive titles

= 2.2.5 - July 17, 2026 =
- Updated:
Insight Core plugin v.2.8.4
Revolution Slider plugin v.6.7.58
Compatibility with Elementor 4.1.5 & Elementor Pro 4.0.2
Theme Builder Single templates now render on the frontend
Form widget custom controls (icon spacing, Auto Fit, custom button width) work with the new Buttons section
Added Content Alignment & hover z-index options to the Container element
Font Awesome Pro icons are compatible with the Inline Font Icons feature
Load lightGallery, Waypoints and Smooth Scroll assets only where needed
- Fixed:
Fix Elementor Icons (eicons) missing on the frontend
Fix Section vertical column alignment & hover z-index with current Elementor markup
Fix Heading & Animated Headline alignment when Optimized Markup is active
Fix Accordion icon defaults using the wrong Font Awesome library
Harden Elementor autocomplete AJAX endpoints (capability checks, input allowlists, result limits)

= 2.2.4 - May 27, 2026 =
- Updated:
Revolution Slider plugin v.6.7.56
Updated outdated templates of WooCommerce 10.8.0

= 2.2.3 - May 14, 2026 =
- Updated:
Insight Core plugin v.2.8.2
Revolution Slider plugin v.6.7.54
- Fixed:
Fix PHP warning
Fix Gap Width control not applying on Inner Section element

= 2.2.2 - April 10, 2026 =
- Updated:
Revolution Slider plugin v.6.7.52
- Fixed:
Fix grid layout not calculating sizes correctly.
Fix template portfolio parallel scroll showcase not working
Fix(testimonial): sync thumbs active state when changing slides

= 2.2.1 - March 24, 2026 =
- Improvement:
Optimize JS/CSS asset enqueueing performance.
Add explicit version strings to script handles for proper cache buster.
Security: AJAX nonces for grid infinite load and cookie notice.
- Fixed:
Fix PHP 8 warning in Image Gallery widget.
Fix lightGallery runtime error on Elementor pages.
Fix duplicate Swiper CSS and Isotope JS registrations.

= 2.2.0 - March 18, 2026 =
- Updated:
Revolution Slider plugin v.6.7.51
Updated outdated templates of WooCommerce 10.5.0
- Fixed:
Fix Security: escape output, validate input, add ABSPATH checks

= 2.1.9 - January 15, 2026 =
- Updated:
Insight Core plugin v.2.8.1
Revolution Slider plugin v.6.7.40
Move CSS inline to files
- Fixed:
Local File Inclusion security
PHP waring

= 2.1.8 - December 4, 2025 =
- Updated:
Insight Core plugin v.2.8.0
Revolution Slider plugin v.6.7.39
- Fixed:
Local File Inclusion security

= 2.1.7 - October 28, 2025 =
- Updated:
Revolution Slider plugin v.6.7.38
Updated outdated templates of WooCommerce 10.3.0
Update image placeholder use SVG instead of online source from https://via.placeholder.com

= 2.1.6 - August 27, 2025 =
- Updated:
Revolution Slider plugin v.6.7.36
Updated outdated templates of WooCommerce 10.1.0

= 2.1.5 - July 21, 2025 =
- Fixed:
Fix security issue on AJAX action.

= 2.1.4 - July 16, 2025 =
- Updated:
Updated outdated templates of WooCommerce 10.0.0

= 2.1.3 - July 7, 2025 =
- Updated:
ThemeMove Addons For Elementor plugin v.2.1.0
Revolution Slider plugin v.6.7.35

= 2.1.2 - June 13, 2025 =
- Fixed:
Fix security issue on AJAX action.

= 2.1.1 - June 12, 2025 =
- Updated:
Updated outdated templates of WooCommerce 9.9.0

= 2.1.0 - May 29, 2025 =
- Updated :
Revolution Slider plugin - v.6.7.34
- Fixed:
Fix security issue on AJAX action.

= 2.0.1 - Feb 27, 2025 =
- Updated:
Revolution Slider plugin v.6.7.29
Updated outdated templates of WooCommerce 9.7.0

= 2.0.0 - Feb 18, 2025 =
- Updated:
Insight Core plugin v.2.7.3
- Fixed:
Fix Kirki @font-face load wrong url.

= 1.9.2 - February 14, 2025 =
- Updated:
Insight Core plugin v.2.7.2
Revolution Slider plugin v.6.7.28
Improvement customize preview loading time

= 1.9.1 - January 22, 2024 =
- Updated:
Revolution Slider plugin v.6.7.25
Updated outdated templates of WooCommerce 9.6.0

= 1.9.0 - December 18, 2024 =
- Fixed:
Compatible with the latest version of Elementor plugin
Updated outdated templates of WooCommerce 9.5.0

= 1.8.9 - December 16, 2024 =
- Updated:
Revolution Slider plugin v.6.7.23
- Fixed:
Fix out-date WooCommerce templates v.9.4.0
Fix load theme text domain

= 1.8.8 - November 11, 2024 =
- Updated:
Revolution Slider plugin v.6.7.21
ThemeMove Addons For Elementor plugin v.2.0.1

= 1.8.7 - October 17, 2024 =
- Updated:
Insight Core plugin - v.2.7.1
Revolution Slider plugin - v.6.7.20

= 1.8.6 - September 17, 2024 =
- Updated:
Updated out-date templates of WooCommerce 9.3.0
- Fixed:
Fix Elementor widgets used waypoint broken in Elementor 2.24.x

= 1.8.5 - August 27, 2024 =
- Updated:
Updated out-date templates of WooCommerce 9.2.0
Revolution Slider plugin v.6.7.18
- Fixed:
Fix Preloader loading infinitely on some browsers

1.8.4 - August 13, 2024
- Updated:
Revolution Slider plugin - v.6.7.17
- Fixed:
Fix Template: Parallel Scroll Showcase section not show on Customize
Fix out-date WooCommerce templates v.9.0.0

1.8.3 - Jun 27, 2024
- Updated:
Revolution Slider plugin - v.6.7.14
- Fixed:
Fix out-date WooCommerce templates v.9.0.0

1.8.2 - Jun 5, 2024
- Updated:
Insight Core plugin 2.7.0
Revolution Slider plugin - v.6.7.12
ThemeMove Addons For Elementor plugin - v.2.0.0
Update Polylang switcher

1.8.1 - May 3, 2024
- Updated:
Revolution Slider plugin - v.6.7.9
ThemeMove Addons For Elementor plugin - v.1.3.3
- Fixed:
Fix out-date WooCommerce templates v.8.8

1.8.0 - March 15, 2024
- Updated:
Insight Core plugin 2.6.7
- Fixed:
Fix google font not working error.
Fix PHP warning

1.7.9 - January 31, 2024
- Updated:
Revolution Slider plugin - v.6.6.20
- Fixed:
Fix blurry logo

1.7.8 - December 19, 2023
- Updated:
Revolution Slider plugin - v.6.6.19
FontAwesome 6.4.2
- Fixed:
Fix items per view setting of Elementor Carousel & Grid widgets not working properly on mobile.

1.7.7 - December 6, 2023
- Updated:
Revolution Slider plugin - v.6.6.18
- Fixed:
Fix PHP waring from Elementor 3.18.0

= 1.7.6 - September 27, 2023 =
- Updated:
Revolution Slider plugin - v.6.6.16
- Fixed:
Remove Deprecated Elementor Code

= 1.7.5 - August 23, 2023 =
- Updated:
Insight Core plugin - v.2.6.5 (Fix out-date WordPress function, compatible with WordPress 6.2.0)

= 1.7.4 - August 21, 2023 =
- Updated:
Revolution Slider plugin - v.6.6.15
- Fixed:
Fix Flip box style on Safari.

= 1.7.3 - July 20, 2023 =
- Fixed:
Fix out-date WooCommerce templates v.7.9.0

= 1.7.2 - June 20, 2023 =
- Updated:
Insight Core plugin - v.2.6.4
Revolution Slider plugin - v.6.6.14
- Fixed:
Fix out-date WooCommerce templates v.7.8.0
Fix Cart fragments issue with WooCommerce 7.8.0

= 1.7.1 - February 28, 2023 =
- Updated:
Insight Core plugin - v.2.6.3
Revolution Slider plugin - v.6.6.11
- Fixed:
Compatible with WooCommerce 7.4.0

= 1.7.0 - January 13, 2022 =
- Fixed:
Fix Slider Modern Background not working in loop mode

= 1.6.9 - December 26, 2022 =
- Updated:
Insight Core plugin - v.2.6.0
Revolution Slider plugin - v.6.6.8
- Fixed:
Compatible with WooCommerce 7.2.1

= 1.6.8 - December 02, 2022 =
- Updated:
Insight Core plugin - v.2.4.12
Revolution Slider plugin - v.6.6.7
- Fixed:
Tested up to Compare plugin v.5.3.0

= 1.6.7 - November 02, 2022 =
- Updated:
Insight Core plugin - v.2.4.11
Revolution Slider plugin - v.6.6.5
Typography change to Satoshi.
- Fixed:
Out-date Woocommerce templates.

= 1.6.6 - October 17, 2022 =
- Updated:
Insight Core plugin - v.2.4.10
Revolution Slider plugin - v.6.6.3
Tested up with Elementor 3.7.5

= 1.6.5 - August 09, 2022 =
- Updated:
Insight Core plugin - v.2.4.7
Update FontAwesome 5.15.4

= 1.6.4 - July 01, 2022 =
- Added:
new Typed Headline widget for Elementor.
- Updated:
Insight Core plugin - v.2.4.6
Revolution Slider plugin - v.6.5.25
Instagram Feed plugin - v4.0.3
- Fixed:
jquery migration notices.

= 1.6.3 - May 25, 2022 =
- Updated:
Insight Core plugin - v.2.4.5
Revolution Slider plugin - v.6.5.23
- Fixed:
Fix whistlist style, compatible with WPC Smart Wishlist 3.0.0

= 1.6.2 - April 21, 2022 =
- Updated:
Insight Core plugin - v.2.4.4
Revolution Slider plugin - v.6.5.20

= 1.6.1 - April 07, 2022 =
- Fixed:
Fix Team Member Carousel Widget missing social url
Compatible with PHP 8

= 1.6.0 - March 30, 2022 =
- Updated:
Insight Core plugin - v.2.4.0
Revolution Slider plugin - v.6.5.19
- Fixed:
Compatible with latest Elementor plugin 3.6.1

= 1.5.7 - November 24, 2021 =
- Updated:
Insight Core plugin - v.2.2.7
Revolution Slider plugin - v.6.5.9
Elementor Pro plugin - v.3.4.2
- Improvement:
RTL Compatible
Import Demo

= 1.5.6 - September 21, 2021 =
- Updated:
Revolution Slider plugin - v.6.5.8
- Improvement:
responsive for Modern Background Carousel widget.

= 1.5.5 - August 24, 2021 =
- Updated:
Insight Core plugin - v.2.2.4
Revolution Slider plugin - v.6.5.7
Elementor Pro plugin - v.3.3.7
- Fixed:
Fix Contact Form 7 Ajax not working

= 1.5.4 July 29, 2021 =
- Updated:
Insight Core plugin - v.2.2.2
Revolution Slider plugin - v.6.5.5
Elementor Pro plugin - v.3.3.1
Import Files
- Fixed:
Fix compare, compatible with WPC Smart Compare 4.0.0

= 1.5.3 Jun 21, 2021 =
- Updated:
Insight Core plugin - v.2.2.1
Revolution Slider plugin - v.6.5.2
- Fixed:
One page menu not scrolling for anonymous user.
Product Variable Sku not changed.
Out-date Woocommerce templates.

= 1.5.2 May 18, 2021 =
- Added:
My Account Icon for Headers, hide on default.
- Updated:
Insight Core plugin - v.2.2.0
Revolution Slider plugin - v.6.4.11
Instagram Feed plugin - v.4.0.2
- Fixed:
Jquery Migration Notice

= 1.5.1 January 12, 2021 =
- Updated:
Insight Core plugin - v.1.7.9.2
Revolution Slider plugin - v.6.3.6
- Fixed:
Grid Layout broken after version 1.5.0

= 1.5.0 January 12, 2021 =
Fixed: Elementor broken on old browsers.
Updated: Insight Core plugin - v.1.7.8

= 1.4.0 December 11, 2020 =
Updated: Insight Core plugin - v.1.7.7
Updated: Revolution Slider plugin - v.6.3.3
Updated: Elementor Pro plugin - v.3.0.8
Added: Homepage Charity
Added: Demo RTL
Fixed: Warning aqua resize.

= 1.3.0 September 11, 2020 =
Fixed: PHP warning on image cropping.
Fixed: Content Importer broken with latest Elementor.
Updated: Insight Core plugin - v.1.7.3
Updated: Instagram Feed plugin - v.4.0.0

= 1.2.1 - August 27, 2020 =
Fixed: Mobile menu not working properly on some edge cases.
Updated: Insight Core plugin - v.1.7.2
Updated: Revolution Slider plugin - v.6.2.22
Updated: Out-date Woocommerce templates.

= 1.2.0 - August 13, 2020 =
Fixed: Customize not working with WordPress 5.5 (Required update Insight Core)
Updated: Insight Core plugin - v.1.7.1
Updated: Revolution Slider plugin - v.6.2.18
Updated: Out-date Woocommerce templates.
Added: new Instagram Feed plugin - v.3.8.7
Removed: old Instagram widget. Used Instagram Feed plugin instead of.

= 1.1.0 - July 08, 2020 =
Fixed: icon shape showing front of main icon in Icon Box widget.
Improvement: site performance.
Updated: Insight Core plugin - v.1.7.0
Updated: Revolution Slider plugin - v.6.2.15

= 1.0.7 - May 18, 2020 =
Fixed: gradient color is not working properly with font icons of Icon Box widget.
Fixed: gradient color is not working properly with font icons of Icon widget.
Fixed: out-date Woocommerce templates.
Updated: Insight Core plugin v.1.6.6
Updated: Revolution Slider plugin v.6.2.8

= 1.0.6 - March 20, 2020 =
Tweak: Optimize css.
Fixed: Slider slides width setting condition.
Fixed: Product Category widget manual selection working not properly.

= 1.0.5 - March 12, 2020 =
Updated: Compatible with latest Elementor plugin.

= 1.0.4 - March 09, 2020 =
Added: Customizable style for toggle button on mobile menu.
Added: Customizable background image for mobile menu.
Updated: Insight Core plugin - v.1.6.3
Updated: Elementor Pro plugin - v.2.8.5
Fixed: Customize Color field style

= 1.0.3 - March 06, 2020 =
Fixed: Theme can not load assets in Microsoft-IIS server.

= 1.0.2 - March 03, 2020 =
Updated: Insight Core plugin - v.1.6.1
Updated: Revolution Slider plugin - v.6.2.1

= 1.0.1 - February 19, 2020 =
Updated: demo import content.
Fixed: Compatible with Elementor Pro 2.8.4

= 1.0.0 - February 17, 2020 =
* Initial release

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
