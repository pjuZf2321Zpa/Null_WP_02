=== YITH Advanced Refund System for WooCommerce Premium ===

Contributors: yithemes
Tags: woocommerce, e-commerce, shop, refund, refunds, offer, coupon, coupons, system, exchange, exchanges, sales, yit, yith, yithemes
Requires at least: 6.2
Tested up to: 6.4
Stable tag: 1.34.0
License: GPLv2 or late
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==
= 1.34.0 - Released on 20 February 2024 =

* New: support for WooCommerce 8.6
* Update: YITH plugin framework

= 1.33.0 - Released on 16 January 2024 =

* New: support for WooCommerce 8.5
* Update: YITH plugin framework

= 1.32.0 - Released on 28 December 2023 =

* New: support for WooCommerce 8.4
* Update: YITH plugin framework

= 1.31.0 - Released on 28 November 2023 =

* New: support for WordPress 6.4
* New: support for WooCommerce 8.3
* Update: YITH plugin framework
* Fix: 'Refund requests' view on Orders page

= 1.30.0 - Released on 09 October 2023 =

* New: support for WooCommerce 8.2
* Update: YITH plugin framework
* Fix: avoid fatal error if product does not exist
* Fix: refund entire order button not shown

= 1.29.0 - Released on 07 September 2023 =

* New: support for WooCommerce 8.1
* Update: YITH plugin framework
* Fix: 'Ask for refund request' button was not working

= 1.28.0 - Released on 03 August 2023 =

* New: support for WordPress 6.3
* New: support for WooCommerce 8.0
* Update: YITH plugin framework

= 1.27.0 - Released on 10 July 2023 =

* New: support for WooCommerce 7.9
* Update: YITH plugin framework

= 1.26.0 - Released on 20 June 2023 =

* New: support for WooCommerce 7.8
* Update: YITH plugin framework

= 1.25.0 - Released on 11 May 2023 =

* New: support for WooCommerce 7.7
* Update: YITH plugin framework

= 1.24.0 - Released on 18 April 2023 =

* New: support for WooCommerce 7.6
* New: support for PHP 8.1
* Update: YITH plugin framework

= 1.23.0 - Released on 20 March 2023 =

* New: support for WooCommerce 7.5
* New: support for WordPress 6.2
* Update: YITH plugin framework

= 1.22.0 - Released on 09 February 2023 =

* New: support for WooCommerce 7.4
* Update: YITH plugin framework
* Fix: corrected window position after refund request is submitted

= 1.21.0 - Released on 05 January 2023 =

* New: support for WooCommerce 7.3
* Update: YITH plugin framework

= 1.20.0 - Released on 15 December 2022 =

* New: support for WooCommerce 7.2
* Update: YITH plugin framework

= 1.19.0 - Released on 14 November 2022 =

* New: support for WordPress 6.1
* New: support for WooCommerce 7.1
* Update: YITH plugin framework
* Fix: patched security vulnerability
* Dev: added filter "ywcars_check_if_image"

= 1.18.0 - Released on 04 October 2022 =

* New: support for WooCommerce 7.0
* Update: YITH plugin framework

= 1.17.0 - Released on 13 September 2022 =

* New: support for WooCommerce 6.9
* Update: YITH plugin framework

= 1.16.0 - Released on 11 August 2022 =

* New: support for WooCommerce 6.8
* Update: YITH plugin framework
* Update: language files
* Dev: added action "ywcars_request_form_before_submit"

= 1.15.0 - Released on 06 July 2022 =

* New: support for WooCommerce 6.7
* Update: YITH plugin framework

= 1.14.0 - Released on 17 June 2022 =

* New: support for WooCommerce 6.6
* Update: YITH plugin framework

= 1.13.0 - Released on 10 May 2022 =

* New: support for WordPress 6.0
* New: support for WooCommerce 6.5
* Update: YITH plugin framework

= 1.12.0 - Released on 11 April 2022 =

* New: French translation
* New: Polish translation

= 1.11.0 - Released on 30 March 2022 =

* New: support for WooCommerce 6.4
* Update: YITH plugin framework

= 1.10.0 - Released on 04 March 2022 =

* New: support for WooCommerce 6.3
* Update: YITH plugin framework

= 1.9.0 - Released on 08 February 2022 =

* New: support for WooCommerce 6.2
* Update: YITH plugin framework
* Fix: Responsive table in my account page

= 1.8.0 - Released on 25 January 2022 =

* New: support for WordPress 5.9
* Update: YITH plugin framework

= 1.7.0 - Released on 30 December 2021 =

* New: support for WooCommerce 6.1
* Update: YITH plugin framework

= 1.6.0 - Released on 16 December 2021 =

* New: support for WooCommerce 6.0
* Update: YITH plugin framework
* Fix: removed duplicated code printed in the refund request modal

= 1.5.0 - Released on 29 October 2021 =

* New: support for WooCommerce 5.9
* Update: YITH plugin framework

= 1.4.0 - Released on 13 October 2021 =

* New: support for WooCommerce 5.8
* Update: YITH plugin framework

= 1.3.1 - Released on 27 September 2021 =

* Update: YITH plugin framework
* Fix: debug info feature removed for all logged in users

= 1.3.0 - Released on 16 September 2021 =

* New: support for WooCommerce 5.7
* Update: YITH plugin framework

= 1.2.13 - Released on 24 August 2021 =

* New: support for WooCommerce 5.6
* Update: YITH plugin framework

= 1.2.12 - Released on 12 July 2021 =

* New: support for WordPress 5.8
* New: support for WooCommerce 5.5
* Update: YITH plugin framework
* Fix: line breaks were not being saved on request messages
* Tweak: allow to receive refund requests even if the product has been deleted

= 1.2.11 - Released on 16 June 2021 =

* Update: YITH plugin framework
* Fix: it was possible to request a refund more times than quantity ordered

= 1.2.10 - Released on 11 June 2021 =

* Fix: error when uploading an image during message submitting

= 1.2.9 - Released on 09 June 2021 =

* New: support for WooCommerce 5.4
* Update: YITH plugin framework

= 1.2.8 - Released on 13 May 2021 =

* New: support for WooCommerce 5.3
* Update: YITH plugin framework

= 1.2.7 - Released on 20 April 2021 =

* New: support for WooCommerce 5.2
* Update: YITH plugin framework

= 1.2.6 - Released on 08 March 2021 =

* New: support for WordPress 5.7
* New: support for WooCommerce 5.1
* Update: YITH plugin framework
* Fix: support for custom order number plugins
* Dev: added filter "yith_ywcars_is_admin_message"

= 1.2.5 - Released on 09 February 2021 =

* New: support for WooCommerce 5.0
* Update: YITH plugin framework

= 1.2.4 - Released on 18 January 2021 =

* New: Support for WooCommerce 4.9
* Update: Plugin framework
* Fix: My Account page endpoints
* Fix: prevent refunds from being requested for cancelled orders

= 1.2.3 - Released on 11 December 2020 =

* New: Support for WordPress 5.6
* New: Support for WooCommerce 4.8
* Update: Plugin framework
* Fix: error if order total is 0
* Fix: placeholders on emails

= 1.2.2 - Released on 04 November 2020 =

* New: Support for WooCommerce 4.7
* Update: Plugin framework
* Update: Language files

= 1.2.1 - Released on 13 October 2020 =

* New: Support for WooCommerce 4.6
* Update: Plugin framework
* Update: Language files

= 1.2.0 - Released on 14 September =

* New: Support for WordPress 5.5
* New: Support for WooCommerce 4.5
* Update: Plugin framework
* Update: Language files
* Dev: Added new filter "yith_wcars_coupon_values"
* Dev: Added new filter "yith_ywcars_automatic_refunds_for_virtual_products"

= 1.1.12 - Released on 21 May 2020 =

* New: Support for WooCommerce 4.2

= 1.1.11 - Released on 14 May 2020 =

* New: Support for WooCommerce 4.1
* Update: Plugin framework
* Update: Language files

= 1.1.10 – Released on 10 March 2020 =

* New: Support for WooCommerce 4.0
* New: Support for WordPress 5.4
* New: Elementor widget - Refund Requests
* New: Elementor widget - View Request
* Update: Plugin framework
* Update: Language files
* Fix: Sequential order number compatibility
* Dev: Added filter "yith_wcars_order_date"
* Dev: Added filter "yith_ywcars_my_refund_requests_endpoint"

= 1.1.9 – Released on 02 January 2020 =

* New: Support for WooCommerce 3.9
* New: Added {items_table} placeholder for admin email (new refund request received)
* New: Compatibility with YITH WooCommerce Sequential Order Number
* Update: Plugin framework
* Update: Language files
* Fix: Improved refund process

= 1.1.8 – Released on 07 November 2019 =

* Update: Plugin framework

= 1.1.7 – Released on 30 October 2019 =

* New: Support for WordPress 5.3
* New: Support for WooCommerce 3.8
* Update: Plugin framework
* Update: Italian language
* Update: Spanish language
* Update: Dutch language
* Dev: Added new shortcode "ywcars_refund_requests"
* Dev: Added new filter "ywcars_refund_for_text"

= 1.1.6 - Released on 12 August 2019 =

* New: Support to WooCommerce 3.7
* Update: Plugin Core
* Update: Language files

=  1.1.5 - Released on 29 May 2019 =

* New: Support to WordPress 5.2.x
* Update: Plugin Core
* Update: Language files

= 1.1.4 - Released on 17 April 2019 =

* New: Support to WooCommerce 3.6.0
* Update: Plugin Core
* Update: Language files
* Dev: new filter 'ywcars_ask_for_refund_text'
* Dev: new filter 'ywcars_refund_entire_order_text'
* Dev: new filter 'ywcars_submit_request_redirect_url'

= 1.1.3 - Released on 19 February 2019 =

* New: option "Allow to close new requests"
* Update: Plugin Core
* Update: Language files
* Fix: automatic permalinks update when activating the plugin
* Fix: minimum value for Max File Size

= 1.1.2 - Released on 21 December 2018 =

* New: Support to WordPress 5.0
* New: Support to WooCommerce 3.5.3
* Update: Plugin Core
* Update: Language files

= 1.1.1 - Released on 23 October 2018 =

* Update: Plugin Core

= 1.1.0 - Released on 17 October 2018 =

* New: Support to WooCommerce 3.5.0 RC2
* New: Filter ywcars_datetime to change the date time of request
* Update: Plugin Core 3.0.25
* Update: Language files
* Fix: currency incompatibilities
* Fix: display message when there isn't any refund requests on My Account
* Fix: Safari browser issue when attachment is empty on Refund Request popup window

= 1.0.9 - Released on 25 May 2018 =

* New: Support to WooCommerce 3.4.0
* New: Support to WordPress 4.9.6
* Update: Plugin core
* Fix: missing strings for translation
* Dev: new filter 'ywcars_is_account_page'

= 1.0.8 - Released on 09 February 2018 =

* New: Spanish translation
* Update: Plugin core

= 1.0.7 - Released on 05 February 2018 =

* Fix: Set the schema to default in admin_url() calls
* Dev: Added filters "ywcars_ajax_url_scheme_frontend" and "ywcars_ajax_url_scheme_backend"

= 1.0.6 - Released on 31 January 2018 =

* New: Support to WC 3.3.0
* New: Hide Refund requests on Shop Orders table when they are many
* Update: Plugin core
* Update: Translation files

= 1.0.5 - Released on 09 January 2018 =

* Fix: Missing strings on Italian translation

= 1.0.4 - Released on 03 January 2018 =

* New: Dutch translation

= 1.0.3 - Released on 29 December 2017 =

* Update: plugin-fw
* Fix: prevent HTTPS requests on AJAX calls

= 1.0.2 - Released on 22 November 2017 =

* New: admin can change email recipients
* Update: language files

= 1.0.1 - Released on 17 November 2017 =

* New: prettyPhoto library
* New: italian language
* Update: plugin-fw
* Fix: expiration date of coupon
* Fix: language file
* Fix: restock items function
* Fix: show "Refunds" tab to all product types
* Fix: problem that showing "Refund" button for on-hold orders if "Number of days for refund" option was set to 0

= 1.0.0 - Released on 06 Jun 2017 =

* First release


== Suggestions ==

If you have suggestions about how to improve YITH Advanced Refund System for WooCommerce, you can [write us](mailto:plugins@yithemes.com "Your Inspiration Themes")
so we can bundle them into the next release of the plugin.


== Translators ==

If you have created your own language pack, or have an update for an existing one,
you can send [gettext PO and MO file](http://codex.wordpress.org/Translating_WordPress "Translating WordPress")
[use](http://yithemes.com/contact/ "Your Inspiration Themes")
so we can bundle it into YITH Advanced Refund System for WooCommerce languages.


= Available Languages =

* English
