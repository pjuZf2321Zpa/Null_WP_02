<?php
/**
 * Load Message Template.
 *
 * @package    YITH/AdvancedRefundSystem/Templates/Emails
 * @author     YITH <plugins@yithemes.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$body               = ! empty( $email->email_body ) ? $email->email_body : '';
$request_id         = ! empty( $email->request_id ) ? $email->request_id : '';
$request            = new YITH_Refund_Request( $request_id );
$current_order      = wc_get_order( $request->order_id );
$order_url          = $current_order->get_view_order_url();
$current_order_link = '<a href="' . $order_url . '">#' . $current_order->get_order_number() . '</a>';
$request_link       = '<a href="' . esc_attr( $request->get_view_request_url() ) . '">#' . $request_id . '</a>';
$customer           = new WP_User( $request->customer_id );

$coupon_amount      = ! empty( $email->coupon_amount ) ? $email->coupon_amount : '';
$coupon_code        = ! empty( $email->coupon_code ) ? $email->coupon_code : '';
$coupon_expiry_date = ! empty( $email->coupon_expiry_date ) ? $email->coupon_expiry_date : '';

do_action( 'woocommerce_email_header', $email_heading, $email );

echo '<p>';
$body = str_replace(
	array(
		'{customer_name}',
		'{order_number}',
		'{request_number}',
		'{coupon_amount}',
	),
	array(
		ucwords( $customer->display_name ),
		$current_order_link,
		$request_link,
		! empty( $coupon_amount ) ? wc_price( $coupon_amount ) : '',
	),
	$body
);
echo $body; // phpcs:ignore WordPress.Security.EscapeOutput
echo '</p>';

// If Coupon email, show the coupon code.

if ( ! empty( $coupon_code ) ) {
	?>
	<div class="ywcars_coupon_box">
		<span class="ywcars_coupon"><?php echo esc_attr( $coupon_code ); ?></span>
		<div class="ywcars_coupon_description">
			<div>
			<?php
			echo esc_html_x( 'Value:', 'Coupon amount', 'yith-advanced-refund-system-for-woocommerce' ) . ' ' . wc_price( $coupon_amount, array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			?>
				</div>
			<?php if ( esc_attr( $coupon_expiry_date ) ) : ?>
				<?php $date = gmdate( get_option( 'date_format' ), $coupon_expiry_date ); ?>
				<div><?php echo esc_html_x( 'Expires:', 'Coupon expiration date', 'yith-advanced-refund-system-for-woocommerce' ) . ' ' . esc_attr( $date ); ?></div>
			<?php endif; ?>
		</div>
	</div>
	<?php
}

do_action( 'woocommerce_email_footer' );
