<?php
/**
 * View items in table.
 *
 * @package    YITH/AdvancedRefundSystem/Templates/Admin
 * @author     YITH <plugins@yithemes.com>
 */

$request = new YITH_Refund_Request( $post->ID );
if ( ! ( $request instanceof YITH_Refund_Request && $request->exists() ) ) {
	return;
}
$finished_request = apply_filters( 'ywcars_finished_request', ( 'ywcars-approved' === $request->status || 'ywcars-rejected' === $request->status || 'trash' === $request->status ), $request );
$current_order    = wc_get_order( $request->order_id );
$order_id         = $current_order->get_id();
$order_number     = $current_order->get_order_number();
$order_total      = $current_order->get_total() - $current_order->get_total_refunded();
$item             = $current_order->get_item( $request->item_id );
$product_name     = ! $request->whole_order && $item instanceof WC_Order_Item_Product ? $item->get_name() : '';
$tax_enabled      = wc_tax_enabled() && 'yes' === get_option( 'yith_wcars_enable_taxes' );

?>
<div class="ywcars_items_info">
	<?php
	$href = admin_url( 'post.php?post=' . $order_id . '&action=edit' );
	/* translators: %s: Order ID */
	$current_title = $order_id === $order_number ? sprintf( esc_html__( 'Go to order #%d', 'yith-advanced-refund-system-for-woocommerce' ), $order_id ) : sprintf( esc_html__( 'Go to order %s', 'yith-advanced-refund-system-for-woocommerce' ), $order_number );
	$order_link    = '<a href="' . $href . '" title="' . $current_title . '">';
	$order_link   .= intval( $order_number ) === $order_id ? '#' . $order_id . '</a>' : $order_number . '</a>';

	$status_title = ywcars_get_request_status_by_key( $request->status );
	$src          = YITH_WCARS_ASSETS_URL . 'images/' . $request->status . '.png';
	?>
	<input type="hidden" id="ywcars_request_id"     value="<?php echo esc_attr( $request->ID ); ?>">
	<input type="hidden" id="ywcars_request_status" value="<?php echo esc_attr( $request->status ); ?>">
	<input type="hidden" id="ywcars_request_is_closed" value="<?php echo esc_attr( $request->is_closed ); ?>">
	<input type="hidden" id="ywcars_order_id"       value="<?php echo esc_attr( $request->order_id ); ?>">


	<?php if ( 'trash' === esc_attr( $request->status ) ) : ?>
		<span class="ywcars_trash_status_icon"></span>
	<?php else : ?>
		<img title="<?php echo esc_attr( $status_title ); ?>" src="<?php echo esc_url( $src ); ?>">
	<?php endif; ?>

	<h2 style="display: inline-block; vertical-align: super;">
	<?php
	/* translators: %s: Request ID and Order ID */
	printf( esc_html_x( 'Request %1$s for order %2$s', 'Request [request ID] for order [order ID]', 'yith-advanced-refund-system-for-woocommerce' ), '#' . esc_html( $request->ID ), wp_kses_post( $order_link ) );
	?>
		</h2>
	<div class="ywcars_before_items_table">
		<?php do_action( 'ywcars_before_items_table_start', $request ); ?>
		<?php
		$customer = version_compare( WC()->version, '3.0.0', '<' ) ? $request->get_customer_link_legacy() : $request->get_customer_link();
		if ( $request->whole_order ) {
			/* translators: %s: Customer */
			$info = sprintf( esc_html__( '%s made a request for the whole order', 'yith-advanced-refund-system-for-woocommerce' ), $customer );
		} else {
			$span_product = $product_name ? '<span style="text-decoration: underline;">' . $product_name . '</span>' : '';
			$span_qty     = '<span title="' . esc_html__( 'Quantity requested', 'yith-advanced-refund-system-for-woocommerce' ) . '">' . $request->qty . '</span>';
			/* translators: %s: Customer, Product Name and its quantity */
			$info = sprintf( esc_html__( '%1$s made a request for %2$s (%3$s)', 'yith-advanced-refund-system-for-woocommerce' ), $customer, $span_product, $span_qty );
		}
		?>
		<div><?php echo $info; ?></div> <?php // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<?php do_action( 'ywcars_before_items_table_end', $request ); ?>
	</div>

	<div style="overflow: auto;">
		<table class="ywcars_items_table">
			<thead>
			<tr>
				<th><?php esc_html_e( 'Item', 'yith-advanced-refund-system-for-woocommerce' ); ?></th>
				<th><?php esc_html_e( 'Item value', 'yith-advanced-refund-system-for-woocommerce' ); ?></th>
				<?php if ( $tax_enabled ) : ?>
					<th><?php esc_html_e( 'Tax per item', 'yith-advanced-refund-system-for-woocommerce' ); ?></th>
				<?php endif; ?>
				<th><?php esc_html_e( 'Qty', 'yith-advanced-refund-system-for-woocommerce' ); ?></th>
				<?php if ( $tax_enabled ) : ?>
					<th class="ywcars_items_table_totals"><?php esc_html_e( 'Item total', 'yith-advanced-refund-system-for-woocommerce' ); ?></th>
					<th class="ywcars_items_table_totals"><?php esc_html_e( 'Tax total', 'yith-advanced-refund-system-for-woocommerce' ); ?></th>
				<?php endif; ?>
				<th class="ywcars_items_table_totals"><?php esc_html_e( 'Order Total', 'yith-advanced-refund-system-for-woocommerce' ); ?></th>
				<th class="ywcars_items_table_totals ywcars_items_table_refund"><?php esc_html_e( 'Qty to refund', 'yith-advanced-refund-system-for-woocommerce' ); ?></th>
				<th class="ywcars_items_table_totals ywcars_items_table_refund">
				<?php
				esc_html_e(
					'Total to be refunded',
					'yith-advanced-refund-system-for-woocommerce'
				);
				?>
						</th>
			</tr>
			</thead>
			<tbody>
			<?php
			do_action( 'ywcars_items_table_tbody_start', $request, $tax_enabled );

			$items = $current_order->get_items( array( 'line_item', 'shipping', 'fee' ) );
			foreach ( $items as $item_id => $item ) {
				$item_type = version_compare( WC()->version, '3.0.0', '<' ) ? $item['type'] : $item->get_type();

				if ( $item instanceof WC_Order_Item_Product ) :
					$product = empty( $item['variation_id'] ) ? wc_get_product( $item['product_id'] ) : wc_get_product( $item['variation_id'] );

					$qty_requested = '0';
					if ( $request->whole_order ) {
						$qty_requested = $item['qty'];
					}
					if ( intval( $request->item_id ) === $item_id ) {
						$qty_requested = $request->qty;
					}

					$item_value   = $item['line_total'] / $item['qty'];
					$total_refund = $item_value * $qty_requested;
					if ( $tax_enabled ) {
						$item_and_tax_value = ( $item['line_total'] + $item['line_tax'] ) / $item['qty'];
						$tax_value          = $item['line_tax'] / $item['qty'];
						$total_refund       = $item_and_tax_value * $qty_requested;
					}

					?>
					<tr>
						<td>
							<?php
							echo esc_attr( $item->get_name() );
							if ( ! $product || ! $product->exists() ) {
								?>
								<p><i><?php esc_html_e( 'This product is in the trash or has been deleted', 'yith-advanced-refund-system-for-woocommerce' ); ?></i></p>
								<?php
							}
							?>
						</td>
						<td><?php echo wc_price( esc_attr( $item_value ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
						<?php if ( $tax_enabled ) : ?>
							<td><?php echo wc_price( esc_attr( $tax_value ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
						<?php endif; ?>
						<td><?php echo esc_attr( $item['qty'] ); ?></td>
						<?php if ( $tax_enabled ) : ?>
							<td class="ywcars_items_table_totals"><?php echo wc_price( esc_attr( $item['line_total'] ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
							<td class="ywcars_items_table_totals"><?php echo wc_price( esc_attr( $item['line_tax'] ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
						<?php endif; ?>
						<td class="ywcars_items_table_totals">
							<?php $total = $tax_enabled ? $item['line_total'] + $item['line_tax'] : $item['line_total']; ?>
							<span><?php echo wc_price( esc_attr( $total ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						</td>
						<td class="ywcars_items_table_totals ywcars_items_table_refund ywcars_item_data">
							<?php if ( ! YITH_Advanced_Refund_System_Request_Manager::order_has_wc_refunds( $current_order ) && ! $request->is_closed ) : ?>
								<input type="number" class="ywcars_item_qty" value="<?php echo $finished_request ? '0' : esc_attr( $qty_requested ); ?>"
									min="0"
									max="<?php echo esc_attr( $qty_requested ); ?>"
									step="1" >
							<?php else : ?>
								<input type="text" size="1" readonly class="ywcars_item_qty" value="<?php echo esc_attr( $qty_requested ); ?>">
							<?php endif; ?>
							<input type="hidden" class="ywcars_item_id" value="<?php echo esc_attr( $item_id ); ?>">
							<input type="hidden" class="ywcars_item_value" value="<?php echo esc_attr( $item_value ); ?>">
							<?php
							if ( $tax_enabled ) {
								$line_tax_data = maybe_unserialize( $item['line_tax_data'] );
								foreach ( $line_tax_data['total'] as $tax_id => $value ) {
									?>
									<input type="hidden" class="ywcars_item_tax" data-tax_id="<?php echo esc_attr( $tax_id ); ?>"
										value="<?php echo (float) $value / $item['qty']; ?>">
									<?php
								}
								?>
								<input type="hidden" class="ywcars_item_tax_value" value="<?php echo esc_attr( $tax_value ); ?>">
								<?php
							}
							?>
							<input type="hidden" class="ywcars_item_total" value="<?php echo esc_attr( $total_refund ); ?>">
						</td>
						<td class="ywcars_items_table_totals ywcars_items_table_refund ywcars_refund_subtotal_data"><?php echo wc_price( esc_attr( $total_refund ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
					</tr>
				<?php else : ?>
					<tr class="ywcars_non_line_item">
						<?php $item_name = version_compare( WC()->version, '3.0.0', '<' ) ? $item['name'] : $item->get_name(); ?>
						<?php if ( 'shipping' === $item_type ) : ?>
							<?php $shipping_total = version_compare( WC()->version, '3.0.0', '<' ) ? (float) $item['cost'] : (float) $item->get_total(); ?>
							<?php
							$shipping_tax = 0;
							if ( $tax_enabled ) {
								if ( version_compare( WC()->version, '3.0.0', '<' ) ) {
									foreach ( maybe_unserialize( $item['taxes'] ) as $iter_tax ) {
										$shipping_tax += (float) $iter_tax;
									}
								} else {
									$shipping_tax = (float) $item->get_total_tax();
								}
							}
							?>
							<?php $shipping_sum = $tax_enabled ? $shipping_total + $shipping_tax : $shipping_total; ?>
							<td><?php echo $item_name ? esc_attr( $item_name ) : esc_html__( 'Shipping', 'yith-advanced-refund-system-for-woocommerce' ); ?></td>
							<td></td><td></td>
							<?php if ( $tax_enabled ) : ?>
								<td></td>
								<td class="ywcars_items_table_totals"><?php echo wc_price( esc_attr( $shipping_total ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
								<td class="ywcars_items_table_totals"><?php echo wc_price( esc_attr( $shipping_tax ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
							<?php endif; ?>
							<td class="ywcars_items_table_totals"><?php echo wc_price( esc_attr( $shipping_sum ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
							<td class="ywcars_items_table_totals ywcars_items_table_refund ywcars_non_line_item_data">
								<?php if ( ! YITH_Advanced_Refund_System_Request_Manager::order_has_wc_refunds( $current_order ) && ! $request->is_closed ) : ?>
									<input class="ywcars_non_line_item_cb" type="checkbox">
								<?php else : ?>
									<input class="ywcars_non_line_item_cb" disabled type="checkbox">
								<?php endif; ?>
								<input type="hidden" class="ywcars_item_id" value="<?php echo esc_attr( $item_id ); ?>">
								<input type="hidden" class="ywcars_item_value" value="<?php echo esc_attr( $shipping_total ); ?>">
								<?php if ( $tax_enabled ) : ?>
									<?php
									$taxes_data = maybe_unserialize( $item['taxes'] );
									if ( empty( $taxes_data['total'] ) ) {
										$taxes = $current_order->get_items( 'tax' );
										foreach ( $taxes as $tax_item ) {
											?>
											<input type="hidden" class="ywcars_item_tax" data-tax_id="<?php echo esc_attr( $tax_item['rate_id'] ); ?>" value="0">
											<?php
										}
									} else {
										foreach ( $taxes_data['total'] as $tax_id => $value ) {
											?>
											<input type="hidden" class="ywcars_item_tax" data-tax_id="<?php echo esc_attr( $tax_id ); ?>" value="<?php echo esc_attr( (float) $value ); ?>">
											<?php
										}
									}
									?>
									<input type="hidden" class="ywcars_item_tax_value" value="<?php echo esc_attr( $shipping_tax ); ?>">
								<?php endif; ?>
								<input type="hidden" class="ywcars_item_total" value="<?php echo esc_attr( $shipping_sum ); ?>">
							</td>
							<td class="ywcars_items_table_totals ywcars_items_table_refund ywcars_refund_subtotal_data"></td>
						<?php endif; ?>
						<?php if ( 'fee' === $item_type ) : ?>

							<?php $fee_total = version_compare( WC()->version, '3.0.0', '<' ) ? (float) $item['line_total'] : (float) $item->get_total(); ?>
							<?php $fee_tax = version_compare( WC()->version, '3.0.0', '<' ) ? (float) $item['line_tax'] : (float) $item->get_total_tax(); ?>
							<?php $fee_sum = $tax_enabled ? $fee_total + $fee_tax : $fee_total; ?>
							<td><?php echo $item_name ? esc_attr( $item_name ) : esc_html__( 'Fee', 'yith-advanced-refund-system-for-woocommerce' ); ?></td>
							<td></td><td></td>
							<?php if ( $tax_enabled ) : ?>
								<td></td>
								<td class="ywcars_items_table_totals"><?php echo wc_price( esc_attr( $fee_total ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
								<td class="ywcars_items_table_totals"><?php echo wc_price( esc_attr( $fee_tax ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
							<?php endif; ?>
							<td class="ywcars_items_table_totals"><?php echo wc_price( esc_attr( $fee_sum ), array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
							<td class="ywcars_items_table_totals ywcars_items_table_refund ywcars_non_line_item_data">
								<?php if ( ! YITH_Advanced_Refund_System_Request_Manager::order_has_wc_refunds( $current_order ) && ! $request->is_closed ) : ?>
									<input class="ywcars_non_line_item_cb" type="checkbox">
								<?php else : ?>
									<input class="ywcars_non_line_item_cb" disabled type="checkbox">
								<?php endif; ?>
								<input type="hidden" class="ywcars_item_id" value="<?php echo esc_attr( $item_id ); ?>">
								<input type="hidden" class="ywcars_item_value" value="<?php echo esc_attr( $fee_total ); ?>">
								<?php if ( $tax_enabled ) : ?>
									<input type="hidden" class="ywcars_item_tax_value" value="<?php echo esc_attr( $fee_tax ); ?>">
								<?php endif; ?>
								<input type="hidden" class="ywcars_item_total" value="<?php echo esc_attr( $fee_sum ); ?>">
							</td>
							<td class="ywcars_items_table_totals ywcars_items_table_refund ywcars_refund_subtotal_data"></td>
						<?php endif; ?>
					</tr>
					<?php
				endif;
			}
			do_action( 'ywcars_items_table_tbody_end', $request, $tax_enabled );
			?>
			</tbody>
			<tfoot>
			<tr>
				<td></td><td></td>
				<?php if ( $tax_enabled ) : ?>
					<td></td>
				<?php endif; ?>
				<td class="ywcars_items_table_totals"><?php esc_html_e( 'Totals', 'yith-advanced-refund-system-for-woocommerce' ); ?></td>
				<?php $order_tax = $current_order->get_total_tax(); ?>
				<?php if ( $tax_enabled ) : ?>
					<td class="ywcars_items_table_totals"><?php echo wc_price( $current_order->get_total() - $order_tax, array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
					<td class="ywcars_items_table_totals"><?php echo wc_price( $order_tax, array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
				<?php endif; ?>
				<td class="ywcars_items_table_totals">
				<?php
					$order_total = $current_order->get_total() - $current_order->get_total_refunded();
					// If the option 'Enable taxes' is disabled but the order has old taxes set.
				if ( $order_tax && 'yes' !== get_option( 'yith_wcars_enable_taxes' ) ) {
					$order_total = $order_total - $order_tax;
					echo wc_price( $order_total, array( 'currency' => $current_order->get_currency() ) ); // phpcs:ignore WordPress.Security.EscapeOutput
				} else {
					echo $current_order->get_formatted_order_total(); // phpcs:ignore WordPress.Security.EscapeOutput

				}
				?>
					</td>
				<td class="ywcars_items_table_totals ywcars_items_table_refund"></td>
				<td class="ywcars_items_table_totals ywcars_items_table_refund ywcars_refund_total_data"></td>
			</tr>
			</tfoot>
		</table>
	</div>

	<?php if ( YITH_Advanced_Refund_System_Request_Manager::order_has_wc_refunds( $current_order ) ) : ?>
		<div>
			<h4><?php esc_html_e( 'Refunds for this order have already been managed through WooCommerce.', 'yith-advanced-refund-system-for-woocommerce' ); ?></h4>
		</div>
	<?php endif; ?>

	<?php if ( $request->is_closed ) : ?>
		<div>
			<h4><?php esc_html_e( 'This request is currently closed.', 'yith-advanced-refund-system-for-woocommerce' ); ?></h4>
		</div>
	<?php endif; ?>

	<?php if ( ! YITH_Advanced_Refund_System_Request_Manager::order_has_wc_refunds( $current_order ) && ! $request->is_closed ) : ?>

		<div class="ywcars_after_items_table">
			<div>
				<p class="ywcars_after_items_table_block">
				<span>
					<input id="ywcars_restock_items" type="checkbox">
					<label for="ywcars_restock_items"><?php esc_html_e( 'Restock selected items?', 'yith-advanced-refund-system-for-woocommerce' ); ?></label>
				</span>
				</p>
				<p class="ywcars_after_items_table_block">
				<span>
					<span><?php esc_html_e( 'Use a custom refund amount', 'yith-advanced-refund-system-for-woocommerce' ); ?></span>
					<input type="text" id="refund_amount" class="ywcars_custom_refund_amount wc_input_price">
				</span>
				</p>
			</div>

			<div>
				<input type="hidden" id="ywcars_whole_order"      value="<?php echo $request->whole_order ? 'true' : 'false'; ?>">
				<input type="hidden" id="ywcars_refunded_item_id" value="<?php echo esc_attr( $request->item_id ); ?>">
				<input type="hidden" id="refunded_amount"         value="<?php echo esc_attr( $current_order->get_total_refunded() ); ?>">
				<input type="hidden" id="ywcars_order_total"      value="<?php echo esc_attr( $order_total ); ?>">
				<input type="hidden" id="ywcars_taxes_enabled"    value="<?php echo esc_attr( $tax_enabled ); ?>">
				<input type="hidden" id="ywcars_refund_amount"    value="<?php echo esc_attr( $request->refund_total ); ?>">
				<?php
				$payment_gateway = wc_get_payment_gateway_by_order( $current_order );

				$refund_amount            = wc_price( 0, array( 'currency' => $current_order->get_currency() ) );
				$gateway_supports_refunds = false !== $payment_gateway && $payment_gateway->supports( 'refunds' );
				$gateway_name             = false !== $payment_gateway ? ( ! empty( $payment_gateway->method_title ) ? $payment_gateway->method_title : $payment_gateway->get_title() ) : esc_html__( 'Payment Gateway', 'yith-advanced-refund-system-for-woocommerce' );

				$automatic_refund_button_classes = $gateway_supports_refunds ? 'button-primary do-api-refund' : 'button-primary tips disabled';
				$automatic_tip                   = $gateway_supports_refunds ? '' : 'data-tip="' . esc_attr__( 'The payment gateway used to place this order does not support automatic refunds.', 'yith-advanced-refund-system-for-woocommerce' ) . '"';
				$manual_tip                      = 'data-tip="' . esc_attr__( 'You will need to manually issue a refund through your payment gateway after using this.', 'yith-advanced-refund-system-for-woocommerce' ) . '"';
				?>
				<button id="ywcars_api_refund_button"
						class="ywcars_request_action_button ywcars_accept_button button <?php echo esc_attr( $automatic_refund_button_classes ); ?>" <?php echo wp_kses_post( $automatic_tip ); ?>>
						<?php
							/* translators: %s: Amount and Gateway Name */
							printf( esc_html_x( 'Refund %1$s via %2$s', 'Refund [amount] via [gateway name]', 'yith-advanced-refund-system-for-woocommerce' ), wp_kses_post( $refund_amount ), esc_attr( $gateway_name ) );
						?>
					</button>
				<button id="ywcars_manual_refund_button"
						class="ywcars_request_action_button ywcars_accept_button button button-primary do-manual-refund tips" <?php echo wp_kses_post( $manual_tip ); ?>>
						<?php
							/* translators: %s: Amount */
							printf( esc_html_x( 'Refund %s manually', 'Refund $amount manually', 'yith-advanced-refund-system-for-woocommerce' ), wp_kses_post( $refund_amount ) );
						?>
					</button>
				<?php do_action( 'ywcars_after_refund_buttons', $request, $refund_amount, $tax_enabled ); ?>
				<button class="button button-secondary" id="ywcars_reject_request_button">
					<span><?php esc_html_e( 'Reject request', 'yith-advanced-refund-system-for-woocommerce' ); ?></span>
				</button>
				<button class="button button-secondary" id="ywcars_processing_request_button">
					<span><?php esc_html_e( 'Set to processing', 'yith-advanced-refund-system-for-woocommerce' ); ?></span>
				</button>
				<button class="button button-secondary" id="ywcars_on_hold_request_button">
					<span><?php esc_html_e( 'Set to on hold', 'yith-advanced-refund-system-for-woocommerce' ); ?></span>
				</button>
				<?php do_action( 'ywcars_after_action_buttons', $request, $refund_amount, $tax_enabled ); ?>
			</div>
		</div>
	<?php endif; ?>
	<?php if ( $finished_request && ! $request->is_closed || 'yes' === get_option( 'yith_wcars_allow_closing_requests', 'no' ) && ! $request->is_closed ) : ?>
		<div>
			<button class="button button-secondary tips" id="ywcars_close_request_button"
					data-tip="<?php esc_html_e( 'Close the request by stopping the messages system. This action prevents you from changing the request status.', 'yith-advanced-refund-system-for-woocommerce' ); ?>">
				<span><?php esc_html_e( 'Close this request', 'yith-advanced-refund-system-for-woocommerce' ); ?></span>
			</button>
		</div>
	<?php endif; ?>

</div>
