<?php
/**
 * View Request Template.
 *
 * @author   YITH <plugins@yithemes.com>
 * @package  YITH/AdvancedRefundSystem/Templates/MyAccount
 */

?>
<div class="ywcars_view_request" id="request_<?php echo esc_attr( $request_id ); ?>">
	<?php echo do_shortcode( '[ywcars_view_request id="' . $request_id . '"]' ); ?>
</div>
