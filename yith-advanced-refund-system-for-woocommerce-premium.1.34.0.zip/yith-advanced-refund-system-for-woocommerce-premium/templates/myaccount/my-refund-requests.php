<?php
/**
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * Load Message Template.
 *
 * @package    YITH/AdvancedRefundSystem/Templates/MyAccount
 * @author     YITH <plugins@yithemes.com>
 */

$columns = apply_filters(
    'ywcars_my_refund_requests_columns',
    array(
        'id'      => __( 'ID', 'yith-advanced-refund-system-for-woocommerce' ),
        'order'   => __( 'Order', 'yith-advanced-refund-system-for-woocommerce' ),
        'product' => __( 'Product', 'yith-advanced-refund-system-for-woocommerce' ),
        'amount'  => __( 'Requested amount', 'yith-advanced-refund-system-for-woocommerce' ),
        'status'  => __( 'Status', 'yith-advanced-refund-system-for-woocommerce' ),
        'action'  => __( 'Actions', 'yith-advanced-refund-system-for-woocommerce' ),
    )
);

?>

<?php if ( ! $request_ids ) : ?>
    <p><?php echo apply_filters( 'ywcars_no_requests_found', esc_html__( 'There are currently no refund requests, if you would like to request a refund, then please navigate to orders page and select which order or product you want to request a refund for.', 'yith-advanced-refund-system-for-woocommerce' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></p>
<?php else : ?>
    <table class="shop_table shop_table_responsive my_account_orders">
        <thead>
        <tr>
            <?php foreach ( $columns as $column_id => $column_name ) : ?>
                <th class="<?php echo esc_attr( $column_id ); ?>"><span class="nobr"><?php echo esc_html( $column_name ); ?></span></th>
            <?php endforeach; ?>
        </tr>
        </thead>
        <tbody>
        <?php
        foreach ( $request_ids as $request_id ) {
            $request = new YITH_Refund_Request( $request_id );
            if ( ! ( $request instanceof YITH_Refund_Request && $request->exists() ) ) {
                continue;
            }
            if ( 'trash' === $request->status ) {
                continue;
            }
            $request_link  = '<a href="' . esc_url( $request->get_view_request_url() ) . '">'
                . '#' . $request_id . '</a>';
            $current_order = wc_get_order( $request->order_id );
            $order_link    = '<a href="' . $current_order->get_view_order_url() . '">#' . $request->order_id . '</a>';
            if ( $request->whole_order ) {
                $product_link = '<b>' . esc_html__( 'Whole Order', 'yith-advanced-refund-system-for-woocommerce' ) . '</b>';
            } else {
                $product = wc_get_product( $request->product_id );
                if ( $product ) {
                    $product_link = '<a href="' . $product->get_permalink() . '">' . $product->get_title() . '</a>';
                }
            }
            $button = '<a class="button" href="' . esc_url( $request->get_view_request_url() ) . '">'
                . esc_html__( 'View', 'yith-advanced-refund-system-for-woocommerce' ) . '</a>';
            ?>
            <tr>
                <?php foreach ( $columns as $column_id => $column_name ) : ?>
                    <?php if ( 'id' === $column_id ) : ?>
                        <td data-title="<?php echo esc_attr( $column_name ); ?>"><?php echo $request_link; //phpcs:ignore WordPress.Security.EscapeOutput ?></td>
                    <?php elseif ( 'order' === $column_id ) : ?>
                        <td data-title="<?php echo esc_attr( $column_name ); ?>"><?php echo $order_link; //phpcs:ignore WordPress.Security.EscapeOutput ?></td>
                    <?php elseif ( 'product' === $column_id ) : ?>
                        <td data-title="<?php echo esc_attr( $column_name ); ?>"><?php echo $product_link; //phpcs:ignore WordPress.Security.EscapeOutput ?></td>
                    <?php elseif ( 'amount' === $column_id ) : ?>
                        <td data-title="<?php echo esc_attr( $column_name ); ?>"><?php echo wc_price( $request->refund_total ); //phpcs:ignore WordPress.Security.EscapeOutput ?></td>
                    <?php elseif ( 'status' === $column_id ) : ?>
                        <td data-title="<?php echo esc_attr( $column_name ); ?>"><?php echo 'ywcars-new' === $request->status ? esc_html__( 'Submitted', 'yith-advanced-refund-system-for-woocommerce' ) : esc_attr( ywcars_get_request_status_by_key( $request->status ) ); ?></td>
                    <?php elseif ( 'action' === $column_id ) : ?>
                        <td data-title="<?php echo esc_attr( $column_name ); ?>"><?php echo $button; //phpcs:ignore WordPress.Security.EscapeOutput ?></td>
                    <?php endif; ?>
                <?php endforeach;?>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
<?php endif; ?>
<?php
