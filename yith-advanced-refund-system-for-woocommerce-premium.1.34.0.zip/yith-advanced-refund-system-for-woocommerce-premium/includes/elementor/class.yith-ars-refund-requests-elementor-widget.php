<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @package YITH/AdvancedRefundSystem/Class/Elementor
 */

use Elementor\Controls_Manager;

/** Elementor Widget for Refund Requests.*/
class YITH_ARS_Refund_Requests_Elementor_Widget extends \Elementor\Widget_Base {

	/** Get Class Name */
	public function get_name() {
		return 'yith-ars-refund-requests';
	}

	/** Get Class Title */
	public function get_title() {
		return esc_html__( 'YITH Advanced Refund System - Refund Requests', 'yith-advanced-refund-system-for-woocommerce' );
	}

	/** Get Class Icon */
	public function get_icon() {
		return 'eicon-price-table';
	}

	/** Get Class Categories */
	public function get_categories() {
		return array( 'yith', 'woocommerce-elements-single' );
	}

	/** Get Class Keywords */
	public function get_keywords() {
		return array( 'woocommerce', 'shop', 'store', 'refund', 'request', 'myaccount' );
	}

	/** Add Elementor controls. */
	protected function _register_controls() { //phpcs:ignore
		// As it's a Elementor function, cant change PHPCS warning of _Function for visibility.
		$this->start_controls_section(
			'section_button',
			array(
				'label' => esc_html__( 'YITH Advanced Refund System - Refund Requests', 'yith-advanced-refund-system-for-woocommerce' ),
			)
		);

		$this->add_control(
			'wc_style_warning',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'This widget shows the current refund requests made by the customer', 'yith-advanced-refund-system-for-woocommerce' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->end_controls_section();

	}

	/** Renders the Widget. */
	protected function render() {
		echo YITH_Advanced_Refund_System_My_Account::get_instance()->refund_requests_shortcode( false ); //phpcs:ignore
	}

}
