<?php
/**
 * Class that manages DB calls.
 *
 * @class      YITH_Request_Message
 * @package    YITH/AdvancedRefundSystem/Class
 * @since      Version 1.0.0
 * @author     YITH <plugins@yithemes.com>
 */

if ( ! defined( 'YITH_WCARS_VERSION' ) ) {
	exit( 'Direct access forbidden.' );
}

if ( ! class_exists( 'YITH_Request_Message' ) ) {
	/**
	 * Class YITH_Request_Message
	 *
	 */
	class YITH_Request_Message {

		/**
		 * Message ID
		 *
		 * @var int
		 * @since 1.0
		 */
		public $ID = 0;

		/**
		 * Request ID.
		 *
		 * @var string
		 */
		public $request = null;

		/**
		 * Message date
		 *
		 * @var string
		 * @since 1.0
		 */
		public $date = null;

		/**
		 * Message content
		 *
		 * @var string
		 * @since 1.0
		 */
		public $message = null;

		/**
		 * Author ID
		 *
		 * @var string
		 * @since 1.0
		 */
		public $author = null;

		/**
		 * Construct
		 *
		 * @param  int $id Id of message.
		 * @since 1.0
		 */
		public function __construct( $id = 0 ) {
			global $wpdb;

			$this->ywcars_messages_table    = $wpdb->prefix . YITH_ARS_DB::$ywcars_messages_table;
			$this->ywcars_messagemeta_table = $wpdb->prefix . YITH_ARS_DB::$ywcars_messagemeta_table;
			if ( $id ) {
				$this->get_data( $id );
			}
		}

		/**
		 * Save the current object
		 */
		public function save() {
			global $wpdb;

			if ( $this->request && $this->message && $this->author ) {
				$insert_query =
					"INSERT INTO $this->ywcars_messages_table ( ID, request, date, message, author )"
					. " VALUES ( NULL, '" . $this->request . "', NOW(), '" . $this->message . "', '" . $this->author . "' )";
				$wpdb->query( $insert_query ); //phpcs:ignore
				$this->ID = $wpdb->insert_id;
			}
		}

		/**
		 * Get data from ID.
		 *
		 * @param  mixed $id Message ID.
		 * @return void
		 */
		private function get_data( $id ) {
			global $wpdb;

			$this->ID = $id;

			$query   = $wpdb->prepare( "SELECT * FROM $this->ywcars_messages_table WHERE ID = %d", $this->ID ); //phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$results = $wpdb->get_row( $query, ARRAY_A ); //phpcs:ignore

			$this->request = $results['request'];
			$this->date    = $results['date'];
			$this->message = $results['message'];
			$this->author  = $results['author'];

		}

		/**
		 * Add meta to current message with ID.
		 *
		 * @param  mixed $meta_key   Key.
		 * @param  mixed $meta_value Value.
		 * @return void
		 */
		public function add_message_meta( $meta_key, $meta_value ) {
			global $wpdb;

			if ( $meta_key && $meta_value ) {
				$insert_query =
					"INSERT INTO $this->ywcars_messagemeta_table ( meta_id, message, meta_key, meta_value )"
					. " VALUES ( NULL, '" . $this->ID . "','" . $meta_key . "', '" . $meta_value . "' )";
				$wpdb->query( $insert_query ); //phpcs:ignore
			}
		}

		/**
		 * Get Meta of message with ID.
		 *
		 * @return array
		 */
		public function get_message_metas() {
			global $wpdb;

			if ( $this->ID ) {
				$query   = $wpdb->prepare( "SELECT * FROM $this->ywcars_messagemeta_table WHERE message = %d", $this->ID ); //phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$results = $wpdb->get_results( $query, ARRAY_A ); //phpcs:ignore

				if ( ! $results ) {
					return false;
				}
				$message_metas = array();
				foreach ( $results as $result ) {
					$meta_key                   = $result['meta_key'];
					$meta_value                 = $result['meta_value'];
					$message_metas[ $meta_key ] = $meta_value;
				}
				return $message_metas;
			}
		}
	}
}
