<?php
/**
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @package    YITH/AdvancedRefundSystem/Class
 */

if ( ! defined( 'YITH_WCARS_VERSION' ) ) {
	exit( 'Direct access forbidden.' );
}

/**
 * Added Functionality to My Account Class.
 *
 * @class      YITH_Advanced_Refund_System_My_Account_Premium
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     YITH <plugins@yithemes.com>
 */

if ( ! class_exists( 'YITH_Advanced_Refund_System_My_Account_Premium' ) ) {
	/**
	 * Class YITH_Advanced_Refund_System_My_Account_Premium
	 *
	 */
	class YITH_Advanced_Refund_System_My_Account_Premium extends YITH_Advanced_Refund_System_My_Account {

		/**
		 * Construct
		 *
		 * @since 1.0.0
		 */
		public function __construct() {
			parent::__construct();
			add_action( 'ywcars_view_request_after_submit', array( $this, 'add_attachment_field_to_view_request' ) );
		}

		/** Add attachment field to view request */
		public function add_attachment_field_to_view_request() {
			?>
			<div>
				<label for="ywcars_form_attachment">
				<?php
					esc_html_e( 'Attach files (optional)', 'yith-advanced-refund-system-for-woocommerce' );
				?>
					</label>
			</div>
			<input type="hidden" name="MAX_FILE_SIZE"
				value="<?php echo esc_attr( get_option( 'yith_wcars_max_file_size', YITH_WCARS_ONE_KILOBYTE_IN_BYTES ) * YITH_WCARS_ONE_KILOBYTE_IN_BYTES ); ?>" />
			<input type="file" id="ywcars_form_attachment" name="ywcars_form_attachment[]"
				multiple <?php echo 'yes' === get_option( 'yith_wcars_enable_only_images', 'no' ) ? 'accept="image/*"' : ''; ?>>
			<?php
		}

	}
}
