<?php
/**
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @package    YITH/AdvancedRefundSystem/Class/Emails
 */

if ( ! defined( 'YITH_WCARS_VERSION' ) ) {
	exit( 'Direct access forbidden.' );
}

/**
 * Class used when the request is processing.
 *
 * @class      YITH_ARS_Processing_User_Email
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     YITH <plugins@yithemes.com>
 */

if ( ! class_exists( 'YITH_ARS_Processing_User_Email' ) ) {
	/**
	 * Class YITH_ARS_Processing_User_Email
	 *
	 */
	class YITH_ARS_Processing_User_Email extends WC_Email {
		/**
		 * Email content.
		 *
		 * @var mixed
		 */
		public $email_body;
		/**
		 * Current request ID.
		 *
		 * @var mixed
		 */
		public $request_id;

		/** Class construct.*/
		public function __construct() {

			$this->id             = 'yith_ywcars_processing_user_email';
			$this->customer_email = true;

			$this->title         = esc_html_x(
				'YITH Advanced Refund System: Request Processing - email for user',
				'Email descriptive title',
				'yith-advanced-refund-system-for-woocommerce'
			);
			$this->description   = esc_html__( 'The user will receive an email when the request is being processed.', 'yith-advanced-refund-system-for-woocommerce' );
			$this->heading       = esc_html__( 'Your refund request is being processed', 'yith-advanced-refund-system-for-woocommerce' );
			$this->subject       = esc_html__( 'Your refund request is being processed', 'yith-advanced-refund-system-for-woocommerce' );
			$this->email_body    = esc_html__(
				'Hi {customer_name}! Your request {request_number} for order {order_number} is being processing.',
				'yith-advanced-refund-system-for-woocommerce'
			);
			$this->template_html = 'emails/ywcars-email-for-user.php';

			add_action( 'ywcars_send_processing_user', array( $this, 'trigger' ) );

			parent::__construct();
			$this->email_type = 'html';
		}

		/**
		 * Main trigger function
		 *
		 * @param int $request_id Current refund request ID.
		 */
		public function trigger( $request_id ) {
			if ( ! $this->is_enabled() ) {
				return;
			}
			$request = null;
			if ( is_numeric( $request_id ) ) {
				$request = new YITH_Refund_Request( $request_id );
			}
			if ( ! ( $request instanceof YITH_Refund_Request ) ) {
				return;
			}
			$this->request_id = $request_id;
			$order            = wc_get_order( $request->order_id );
			$this->recipient  = $order instanceof WC_Data ? $order->get_billing_email() : $order->billing_email;

			$this->email_body = $this->get_option(
				'email_body',
				esc_html__(
					'Hi {customer_name}! Your request {request_number} for order {order_number} is
             being processing.',
					'yith-advanced-refund-system-for-woocommerce'
				)
			);

			$this->send(
				$this->get_recipient(),
				$this->get_subject(),
				$this->get_content(),
				$this->get_headers(),
				$this->get_attachments()
			);
		}

		/** Return content as HTML */
		public function get_content_html() {
			return wc_get_template_html(
				$this->template_html,
				array(
					'email_heading' => $this->get_heading(),
					'sent_to_admin' => false,
					'plain_text'    => false,
					'email'         => $this,
				),
				'',
				YITH_WCARS_TEMPLATE_PATH
			);
		}

		/** Initialize form fields. */
		public function init_form_fields() {
			$this->form_fields = array(
				'enabled'    => array(
					'title'   => esc_html__( 'Enable/Disable', 'yith-advanced-refund-system-for-woocommerce' ),
					'type'    => 'checkbox',
					'label'   => esc_html__( 'Enable this email notification', 'yith-advanced-refund-system-for-woocommerce' ),
					'default' => 'yes',
				),
				'subject'    => array(
					'title'       => esc_html__( 'Subject', 'yith-advanced-refund-system-for-woocommerce' ),
					'type'        => 'text',
					'description' => esc_html__( 'This controls the email subject line. Leave blank to use the default subject:', 'yith-advanced-refund-system-for-woocommerce' ) . sprintf( '<code>%s</code>', $this->subject ),
					'placeholder' => '',
					'default'     => '',
				),
				'heading'    => array(
					'title'       => esc_html__( 'Email Heading', 'yith-advanced-refund-system-for-woocommerce' ),
					'type'        => 'text',
					'description' => esc_html__( 'This controls the main heading in the email notification. Leave blank to use the default heading:', 'yith-advanced-refund-system-for-woocommerce' ) . sprintf( '<code>%s</code>', $this->heading ),
					'placeholder' => '',
					'default'     => '',
				),
				'email_body' => array(
					'title'       => esc_html__( 'Email Body', 'yith-advanced-refund-system-for-woocommerce' ),
					'type'        => 'textarea',
					'description' => esc_html__( 'Defaults to', 'yith-advanced-refund-system-for-woocommerce' ) . sprintf( '<code>%s</code>', $this->email_body )
						. '<br>' . esc_html_x( 'You can use the following placeholders:', 'yith-advanced-refund-system-for-woocommerce' )
						. '<code>{customer_name}, {request_number}, {order_number}</code>',
					'placeholder' => '',
					'default'     => '',
				),
			);
		}

	}

}
return new YITH_ARS_Processing_User_Email();
