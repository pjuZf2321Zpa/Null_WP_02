<?php
/**
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @package    YITH/AdvancedRefundSystem/Class
 */

if ( ! defined( 'YITH_WCARS_VERSION' ) ) {
	exit( 'Direct access forbidden.' );
}

/**
 * Request manager, added functionality.
 *
 * @class      YITH_Advanced_Refund_System_Request_Manager_Premium
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     YITH <plugins@yithemes.com>
 */

if ( ! class_exists( 'YITH_Advanced_Refund_System_Request_Manager_Premium' ) ) {
	/**
	 * Class YITH_Advanced_Refund_System_Request_Manager_Premium
	 *
	 */
	class YITH_Advanced_Refund_System_Request_Manager_Premium extends YITH_Advanced_Refund_System_Request_Manager {
		/**
		 * Construct
		 *
		 * @since 1.0.0
		 */
		public function __construct() {
			parent::__construct();
			add_action( 'wp_ajax_ywcars_create_coupon', array( $this, 'create_coupon' ) );

		}

		/**
		 * Create coupon.
		 *
		 * @throws Exception When creating (permissions, not exists).
		 */
		public function create_coupon() {

			check_ajax_referer( 'create-coupon', 'security' );

			$request_id = ! empty( $_POST['ywcars_request_id'] ) ? sanitize_text_field( wp_unslash( $_POST['ywcars_request_id'] ) ) : false;
			$amount     = ! empty( $_POST['amount'] ) ? sanitize_text_field( wp_unslash( $_POST['amount'] ) ) : false;

			try {
				if ( ! current_user_can( 'publish_shop_coupons' ) ) {
					throw new Exception( esc_html__( 'You do not have permission to create coupons.', 'yith-advanced-refund-system-for-woocommerce' ) );
				}

				$request = new YITH_Refund_Request( $request_id );
				if ( ! $request->exists() ) {
					throw new Exception( esc_html__( 'Refund request does not exist.', 'yith-advanced-refund-system-for-woocommerce' ) );
				}

				$code = get_option( 'yith_wcars_coupon_code' );

				if ( ! $code ) {
					$code = 'refund_{request_id}';
				}

				// Get customer email.
				$order = wc_get_order( $request->order_id );
				if ( ! $order ) {
					throw new Exception( esc_html__( 'Order does not exist.', 'yith-advanced-refund-system-for-woocommerce' ) );
				}
				$email = $order instanceof WC_Data ? $order->get_billing_email() : $order->billing_email;

				$coupon_code = str_replace(
					array( '{customer_email}', '{request_id}', '{coupon_amount}', '{order_number}' ),
					array( $email, $request_id, $amount, $request->order_id ),
					$code
				);

				$new_coupon = array(
					'post_title'   => $coupon_code,
					'post_content' => '',
					'post_status'  => 'publish',
					'post_author'  => get_current_user_id(),
					'post_type'    => 'shop_coupon',
					'post_excerpt' => '',
				);

				$id = wp_insert_post( $new_coupon, true );

				if ( is_wp_error( $id ) ) {
					throw new Exception( esc_html__( 'Error: invalid data when creating coupon.', 'yith-advanced-refund-system-for-woocommerce' ) );
				}

				global $wpdb;

				$coupon_code = $coupon_code . '_' . uniqid();
				$coupon_code  = wc_format_coupon_code( $coupon_code );
				$wpdb->update( $wpdb->posts, array( 'post_title' => $coupon_code ), array( 'ID' => $id ) ); //phpcs:ignore WordPress.DB.DirectDatabaseQuery
				clean_post_cache( $id );

				// Expiration date.
				$expiry_date_ndays = get_option( 'yith_wcars_expiry_date', 0 );
				$expiry_date       = $expiry_date_ndays ? strtotime( sprintf( '+%d days', $expiry_date_ndays ) ) : '';
				$date_expires      = $expiry_date ? gmdate( 'Y-m-d', $expiry_date ) : '';

				$values = apply_filters(
					'yith_wcars_coupon_values',
					array(
						'discount_type'              => 'fixed_cart',
						'coupon_amount'              => wc_format_decimal( $amount ),
						'individual_use'             => 'yes',
						'product_ids'                => '',
						'exclude_product_ids'        => '',
						'usage_limit'                => 1,
						'usage_limit_per_user'       => 1,
						'limit_usage_to_x_items'     => 0,
						'usage_count'                => 0,
						'date_expires'               => $date_expires,
						'expiry_date'                => $expiry_date,
						'free_shipping'              => 'no',
						'product_categories'         => array(),
						'exclude_product_categories' => array(),
						'exclude_sale_items'         => 'no',
						'minimum_amount'             => '',
						'maximum_amount'             => '',
						'customer_email'             => array( $email ),
						'ywcars_coupon'              => 'yes',
					),
					$request_id,
					$id,
					$coupon_code
				);

				foreach ( $values as $key => $value ) {
					update_post_meta( $id, $key, $value );
				}

				$request->coupon_id = $id;
				$request->set_coupon_offered();
				wp_send_json_success();
			} catch ( Exception $e ) {
				wp_send_json_error( array( 'error' => $e->getMessage() ) );
			}
		}

	}
}
