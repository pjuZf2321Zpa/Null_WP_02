<?php //phpcs:ignore WordPress.NamingConventions
/**
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @class   YITH_Advanced_Refund_System_Admin
 * @package YITH/AdvancedRefundSystem/Class
 * @since   Version 1.0.0
 * @author  YITH <plugins@yithemes.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_ARS_DB' ) ) {
	/**
	 * YITH Advanced Refund System Database
	 *
	 * @since 1.0.0
	 */
	class YITH_ARS_DB {

		/**
		 * DB version
		 *
		 * @var string
		 */
		public static $version = '1.0.0';

		/**
		 * Name of the table for messages.
		 *
		 * @var string
		 */
		public static $ywcars_messages_table = 'ywcars_messages';

		/**
		 * Name of the table for meta messages.
		 *
		 * @var string
		 */
		public static $ywcars_messagemeta_table = 'ywcars_messagemeta';


		/**
		 * Constructor
		 *
		 * @return YITH_ARS_DB
		 */
		private function __construct() {

		}

		/** Install DB */
		public static function install() {
			self::create_db_table();
		}

		/**
		 * Create table for Notes.
		 *
		 * @param bool $force Force creating table.
		 */
		public static function create_db_table( $force = false ) {
			global $wpdb;

			$current_version = get_option( 'ywcars_db_version' );

			if ( $force || $current_version !== self::$version ) {
				$wpdb->hide_errors();

				$messages_table    = $wpdb->prefix . self::$ywcars_messages_table;
				$messagemeta_table = $wpdb->prefix . self::$ywcars_messagemeta_table;
				$charset_collate   = $wpdb->get_charset_collate();

				$sql_messages = "CREATE TABLE IF NOT EXISTS $messages_table (
                    ID bigint(20) unsigned NOT NULL auto_increment,
                    request bigint(20) unsigned NOT NULL default '0',
                    date datetime NOT NULL default '0000-00-00 00:00:00',
                    message longtext NOT NULL,
                    author bigint(20) unsigned NOT NULL default '0',
                    PRIMARY KEY (ID)
                    ) $charset_collate;";

				$sql_messagesmeta = "CREATE TABLE IF NOT EXISTS $messagemeta_table (
                    meta_id bigint(20) unsigned NOT NULL auto_increment,
                    message bigint(20) unsigned NOT NULL default '0',
                    meta_key varchar(255) default NULL,
                    meta_value longtext,
                    PRIMARY KEY (meta_id)
                    ) $charset_collate;";

				if ( ! function_exists( 'dbDelta' ) ) {
					require_once ABSPATH . 'wp-admin/includes/upgrade.php';
				}
				dbDelta( $sql_messages );
				dbDelta( $sql_messagesmeta );
				update_option( 'ywcars_db_version', self::$version );
			}
		}

	}
}
