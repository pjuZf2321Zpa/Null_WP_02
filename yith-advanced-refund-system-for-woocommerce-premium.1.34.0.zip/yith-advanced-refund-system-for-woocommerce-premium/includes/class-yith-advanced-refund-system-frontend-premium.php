<?php
/**
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @package    YITH/AdvancedRefundSystem/Class
 */

if ( ! defined( 'YITH_WCARS_VERSION' ) ) {
	exit( 'Direct access forbidden.' );
}

/**
 * Added functionality from refund system.
 *
 * @class      YITH_Advanced_Refund_System_Frontend_Premium
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     YITH <plugins@yithemes.com>
 */

if ( ! class_exists( 'YITH_Advanced_Refund_System_Frontend_Premium' ) ) {
	/**
	 * Class YITH_Advanced_Refund_System_Frontend_Premium
	 *
	 */
	class YITH_Advanced_Refund_System_Frontend_Premium extends YITH_Advanced_Refund_System_Frontend {

		/**
		 * WC_Product object if it is not set by theme in 'woocommerce_stock_html' filter.
		 *
		 * @var mixed
		 */
		public $product_from_availability;

		/**
		 * Construct
		 *
		 * @since 1.0.0
		 */
		public function __construct() {
			parent::__construct();
			add_action( 'woocommerce_order_item_meta_end', array( $this, 'refund_single_product_button' ), 21, 3 );
			add_action( 'ywcars_request_form_before_reason', array( $this, 'add_qty_field_to_form' ), 10, 2 );
			add_action( 'ywcars_request_form_after_reason', array( $this, 'add_attachment_field_to_form' ), 10, 2 );
			add_filter( 'woocommerce_get_stock_html', array( $this, 'non_refundable_message' ), 10, 2 );
			add_filter( 'woocommerce_get_availability', array( $this, 'get_product_from_availability' ), 10, 2 );
		}

		/**
		 * Button to refund the whole order.
		 *
		 * @param WC_Order $order Affected order.
		 */
		public function refund_whole_order_button( $order ) {
			if ( ! apply_filters( 'ywcars_is_account_page', is_account_page() ) ) {
				return;
			}
			if ( ! $order ) {
				return;
			}
			if ( YITH_Advanced_Refund_System_Request_Manager::order_has_wc_refunds( $order ) ) {
				return;
			}
			if ( ! $this->order_has_minimum_order_amount( $order ) ) {
				return;
			}
			if ( ! $this->order_has_enough_ndays( $order ) ) {
				return;
			}

			$refundable = get_option( 'yith_wcars_allow_refunds' );
			if ( 'yes' !== $refundable ) {
				return;
			}
			$requests = $order->get_meta( '_ywcars_requests' );
			$text     = apply_filters( 'ywcars_refund_entire_order_text', esc_html__( 'Refund my entire order', 'yith-advanced-refund-system-for-woocommerce' ), $order );
			if ( ! $requests ) {
				$show_refund_button = true;
				foreach ( $order->get_items() as $item ) {
					$product_id = empty( $item['variation_id'] ) ? $item['product_id'] : $item['variation_id'];
					if ( ! $this->product_can_show_refundable_button( $order, $product_id ) ) {
						$show_refund_button = false;
						break;
					}
				}
				if ( $show_refund_button ) {
					$params = array(
						'ajax'       => 'true',
						'action'     => 'ywcars_open_request_window',
						'order_id'   => $order->get_id(),
						'target'     => 'whole_order',
						'line_total' => $order->get_total(),
					);
					$link   = add_query_arg( $params, admin_url( 'admin-ajax.php', apply_filters( 'ywcars_ajax_url_scheme_frontend', '' ) ) );
					?>
					<div class="ywcars_button_refund_container ywcars_whole_order" style="margin-bottom: 10px;">
						<a class="button ywcars_button_refund" data-rel="prettyPhoto"
							href="<?php echo esc_url( $link ); ?>"><?php echo esc_attr( $text ); ?></a>
					</div>
					<?php
				} else {
					?>
					<div class="ywcars_button_refund_container ywcars_button_refund_disabled ywcars_whole_order" style="margin-bottom: 10px;">
						<button disabled title="<?php esc_html_e( 'Refund on the entire order is not allowed', 'yith-advanced-refund-system-for-woocommerce' ); ?>"
								class="button ywcars_button_refund"><?php echo esc_attr( $text ); ?></button>
					</div>
					<?php
				}
			} else {
				?>
				<div class="ywcars_button_refund_container ywcars_button_refund_disabled ywcars_whole_order" style="margin-bottom: 10px;">
					<button disabled title="<?php esc_html_e( 'Refund on the entire order is not allowed', 'yith-advanced-refund-system-for-woocommerce' ); ?>"
							class="button ywcars_button_refund"><?php echo esc_attr( $text ); ?></button>
				</div>
				<?php
			}
		}

		/**
		 * Print button of refund single product.
		 *
		 * @param  mixed                 $item_id Current Item Id.
		 * @param  WC_Order_Item_Product $item    Current Item.
		 * @param  mixed                 $order   Current order.
		 * @return void
		 */
		public function refund_single_product_button( $item_id, $item, $order ) {
			if ( ! apply_filters( 'ywcars_is_account_page', is_account_page() ) ) {
				return;
			}
			if ( ! $item_id || ! $item || ! $order ) {
				return;
			}
			$product_id = empty( $item['variation_id'] ) ? $item['product_id'] : $item['variation_id'];
			$text       = apply_filters( 'ywcars_ask_for_refund_text', esc_html__( 'Ask for a refund', 'yith-advanced-refund-system-for-woocommerce' ), $product_id, $item, $order );
			if ( $this->product_can_show_refundable_button( $order, $product_id ) ) {
				$max_quantity = $this->item_qty_available( $item, $order );
				if ( $max_quantity > 0 ) {
					$params = array(
						'ajax'       => 'true',
						'action'     => 'ywcars_open_request_window',
						'order_id'   => $order->get_id(),
						'item_id'    => $item_id,
						'target'     => $product_id,
						'qty'        => $max_quantity,
						'qty_total'  => $item['qty'],
						'line_total' => $item['line_total'],
					);
					$link   = add_query_arg( $params, admin_url( 'admin-ajax.php', apply_filters( 'ywcars_ajax_url_scheme_frontend', '' ) ) );
					?>
					<div class="ywcars_button_refund_container">
						<a class="button ywcars_button_refund" data-rel="prettyPhoto"
							href="<?php echo esc_url( $link ); ?>"><?php echo esc_attr( $text ); ?></a>
					</div>
					<?php
				} else {
					?>
					<div class="ywcars_button_refund_container ywcars_button_refund_disabled">
						<button disabled title="<?php esc_html_e( 'No further refunds can be granted on this item', 'yith-advanced-refund-system-for-woocommerce' ); ?>"
							class="button ywcars_button_refund" ><?php echo esc_attr( $text ); ?></button>
					</div>
					<?php
				}
			} else {
				?>
				<div class="ywcars_button_refund_container ywcars_button_refund_disabled">
					<button disabled title="<?php esc_html_e( 'No refund shall be granted on this product', 'yith-advanced-refund-system-for-woocommerce' ); ?>"
						class="button ywcars_button_refund"><?php echo esc_attr( $text ); ?></button>
				</div>
				<?php
			}
		}

		/**
		 * If order has the minimum order amount.
		 *
		 * @param  WC_Order $order Current order.
		 * @return bool
		 */
		public function order_has_minimum_order_amount( $order ) {
			$order_total          = $order->get_total();
			$minimum_order_amount = get_option( 'yith_wcars_minimum_order_amount' );
			if ( $order_total >= $minimum_order_amount ) {
				return true;
			}
			return false;
		}

		/**
		 * Check if a product has enough ndays.
		 *
		 * @param  WC_Product $product Current product.
		 * @param  WC_Order   $order   Current order.
		 * @return bool void
		 */
		public function product_has_enough_ndays( $product, $order ) {
			if ( ! $product instanceof WC_Product || ! $order instanceof WC_Order ) {
				return false;
			}
			$order_date = $order->get_date_paid();
			$order_date = ! empty( $order_date ) ? $order_date : $order->get_date_completed();
			$order_date = apply_filters( 'yith_wcars_order_date', $order_date, $order, $product );

			if ( 'cancelled' === $order->get_status() || 'failed' === $order->get_status() ) {
				return false;
			}

			$ndays_global_value = get_option( 'yith_wcars_ndays_refund' );
			$product_ndays_type = $product->get_meta( '_ywcars_ndays_refund_type' );
			$ndays_type         = empty( $product_ndays_type ) ? 'global' : $product_ndays_type;
			$product_ndays      = $product->get_meta( '_ywcars_ndays_refund' );
			$ndays              = empty( $product_ndays ) ? $ndays_global_value : $product_ndays;

			if ( 'parent' === $ndays_type ) {
				$parent = wc_get_product( $product->get_parent_id() );
				$ndays  = $parent->get_meta( '_ywcars_ndays_refund' );
			}
			if ( 'global' === $ndays_type ) {
				$ndays = $ndays_global_value;
			}

			if ( ! $ndays && $order_date ) {
				return true;
			}
			if ( $order_date && ( ( $ndays * DAY_IN_SECONDS ) + strtotime( $order_date ) ) > time() ) {
				return true;
			}
			return false;
		}

		/**
		 * Check if the product is refundable.
		 *
		 * @param  mixed $id Product ID.
		 * @return bool
		 */
		public function product_id_is_refundable( $id ) {
			$product                  = wc_get_product( $id );
			$refundable_global_option = get_option( 'yith_wcars_allow_refunds' );
			$product_refundable       = $product->get_meta( '_ywcars_refundable' );
			$refundable               = empty( $product_refundable )
				? $refundable_global_option
				: $product_refundable;
			if ( 'parent' === $refundable ) {
				$parent     = $product->get_parent_id();
				$parent     = wc_get_product( $parent );
				$refundable = $parent->get_meta( '_ywcars_refundable' );
			}
			if ( 'global' === $refundable ) {
				$refundable = $refundable_global_option;
			}

			return $refundable;

		}

		/**
		 * If it can be refundable.
		 *
		 * @param  WC_Order   $order      Current order.
		 * @param  string|int $product_id Current product ID.
		 *
		 * @return bool
		 */
		public function product_can_show_refundable_button( $order, $product_id ) {
			if ( ! $order ) {
				return false;
			}
			if ( YITH_Advanced_Refund_System_Request_Manager::order_has_wc_refunds( $order ) ) {
				return false;
			}
			if ( ! $this->order_has_minimum_order_amount( $order ) ) {
				return false;
			}

			$product = wc_get_product( $product_id );
			if ( ! $this->product_has_enough_ndays( $product, $order ) ) {
				return false;
			}

			$refundable = $this->product_id_is_refundable( $product );
			if ( 'yes' !== $refundable ) {
				return false;
			}
			$requests = $order->get_meta( '_ywcars_requests' );
			if ( $requests ) {
				foreach ( $requests as $request_id ) {
					$request = new YITH_Refund_Request( $request_id );
					if ( ! ( $request instanceof YITH_Refund_Request && $request->exists() ) ) {
						continue;
					}
					if ( $request->whole_order ) {
						return false;
					}
				}
			}

			return apply_filters( 'yith_wcars_product_show_refundable_button', true, $order, $product_id );
		}

		/**
		 * Returns how many items are available.
		 *
		 * @param  WC_Order_Item_Product $item  Current Item.
		 * @param  WC_Order              $order Current order.
		 *
		 * @return int
		 */
		public function item_qty_available( $item, $order ) {
			if ( ! $item || ! $order ) {
				return false;
			}

			$requests      = $order->get_meta( '_ywcars_requests' );
			$qty_available = $item['qty'];

			if ( $requests ) {
				foreach ( $requests as $request_id ) {
					$request = new YITH_Refund_Request( $request_id );

					if ( $request->exists() && ( intval( $request->product_id ) === $item['product_id'] || intval( $request->product_id ) === $item['variation_id'] ) ) {
						$qty_available = (int) $qty_available - (int) $request->qty;
					}
				}
			}
			return $qty_available;
		}

		/**
		 * Add quantity field to the order form.
		 *
		 * @param  mixed $order          Current order.
		 * @param  mixed $is_whole_order If that's the whole order.
		 */
		public function add_qty_field_to_form( $order, $is_whole_order ) {
			if ( $is_whole_order ) {
				return;
			}
			! empty( $_GET['qty'] ) ? $qty             = sanitize_text_field( wp_unslash( $_GET['qty'] ) ) : $qty = ''; //phpcs:ignore WordPress.Security.NonceVerification
			! empty( $_GET['qty_total'] ) ? $qty_total = sanitize_text_field( wp_unslash( $_GET['qty_total'] ) ) : $qty_total = ''; //phpcs:ignore WordPress.Security.NonceVerification
			! empty( $_GET['item_id'] ) ? $item_id     = sanitize_text_field( wp_unslash( $_GET['item_id'] ) ) : $item_id = ''; //phpcs:ignore WordPress.Security.NonceVerification

			?>
			<div class="ywcars_block">
				<label><?php echo apply_filters( 'ywcars_qty_block_text', esc_html__( 'Please, select the amount of items:', 'yith-advanced-refund-system-for-woocommerce' ), $order, $is_whole_order ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<input type="hidden" name="ywcars_form_item_id" value="<?php echo esc_attr( $item_id ); ?>">
					<input type="number" name="ywcars_form_qty" class="ywcars_form_qty" min="1" max="<?php echo esc_attr( $qty ); ?>" step="1">
					<input type="hidden" name="ywcars_form_max_qty" value="<?php echo esc_attr( $qty ); ?>">
					<input type="hidden" name="ywcars_form_qty_total" value="<?php echo esc_attr( $qty_total ); ?>">
				</label>
			</div>
			<?php
		}

		/**
		 * Add attachment field to the order form.
		 *
		 * @param  mixed $order          Current order.
		 * @param  mixed $is_whole_order If that's the whole order.
		 */
		public function add_attachment_field_to_form( $order, $is_whole_order ) {
			?>
			<div class="ywcars_block">
				<div><label for="ywcars_form_attachment">
				<?php
						esc_html_e( 'Attach a file (optional)', 'yith-advanced-refund-system-for-woocommerce' );
				?>
						</label></div>
				<input type="hidden" name="MAX_FILE_SIZE" value="<?php echo esc_attr( get_option( 'yith_wcars_max_file_size', YITH_WCARS_ONE_KILOBYTE_IN_BYTES ) * YITH_WCARS_ONE_KILOBYTE_IN_BYTES ); ?>" />
				<input type="file" id="ywcars_form_attachment" name="ywcars_form_attachment[]" multiple <?php echo 'yes' === get_option( 'yith_wcars_enable_only_images', 'no' ) ? 'accept="image/*"' : ''; ?>>
			</div>
			<?php
		}

		/**
		 * Add the "no refundable" message.
		 *
		 * @param  mixed $availability_html HTML for availability.
		 * @param  mixed $product           Current product.
		 * @return mixed
		 */
		public function non_refundable_message( $availability_html, $product ) {
			$id         = $this->get_wpml_product_id( $product );
			$product    = wc_get_product( $id );
			$refundable = $this->product_id_is_refundable( $id );

			if ( 'no' === $refundable ) {
				$message_type = $product->get_meta( '_ywcars_message_type' );
				$message      = $product->get_meta( '_ywcars_message' );
				$color        = get_option( 'yith_wcars_message_color', '#000000' );
				if ( 'parent' === $message_type ) {
					$parent       = wc_get_product( $product->get_parent_id() );
					$message_type = $parent->get_meta( '_ywcars_message_type' );
					$message      = $parent->get_meta( '_ywcars_message' );
				}
				if ( 'global' === $message_type ) {
					$message = get_option( 'yith_wcars_message' );
				}
				return $availability_html . '<div style="font-weight: bold; color: ' . $color . '">' . $message . '</div>';
			}
			return $availability_html;
		}

		/**
		 * Get product from the availability param.
		 *
		 * @param  mixed $availability Availability.
		 * @param  mixed $product      Current product.
		 * @return mixed
		 */
		public function get_product_from_availability( $availability, $product ) {
			$this->product_from_availability = $product;
			return $availability;
		}

		/**
		 * Get WPML Product ID.
		 *
		 * @param  mixed $product Current product.
		 *
		 * @return int
		 */
		public function get_wpml_product_id( $product ) {
			global $sitepress;
			return $sitepress ? yit_wpml_object_id( $product->get_id(), 'product', true, $sitepress->get_default_language() ) : $product->get_id();
		}
	}
}
