<?php
/**
 * Meta Box connection
 *
 * @since 3.3.2
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Include metaboxes overrides.
 *
 */
require_once( PRESSCORE_EXTENSIONS_DIR . '/custom-meta-boxes/override-fields.php' ); 

/**
 * Include Meta-Box framework.
 *
 */
require_once( THE7_RWMB_DIR . 'meta-box.php' );

/**
 * Include custom metaboxes.
 *
 */
require_once( PRESSCORE_EXTENSIONS_DIR . '/custom-meta-boxes/metabox-fields.php' );
require_once( PRESSCORE_EXTENSIONS_DIR . '/custom-meta-boxes/class-the7-rwmb-dimension-field.php' );

/**
 * Meta box field types deprecated in 15.0.6, to be removed in 15.1.0.
 *
 * None of these are registered by the theme or by dt-the7-core. Field types are
 * internal surface: the shape of the $DT_META_BOXES array is the contract, the
 * type vocabulary is not.
 *
 * Deliberately not filterable: this list is deleted together with the classes
 * it names, and a PR retiring an extension surface should not create one.
 *
 * `file` and `image` are deprecated as *types* only. Their classes stay, since
 * THE7_RWMB_Image_Advanced_MK2_Field inherits from them.
 *
 * @return string[] Deprecated type => replacement type ( '' when there is none ).
 */
function the7_get_deprecated_meta_box_field_types() {
	return array(
		'button'            => '',
		'date'              => '',
		'divider'           => '',
		'dropdown_pages'    => '',
		'email'             => '',
		'fieldset_text'     => '',
		'file'              => 'image_advanced_mk2',
		'file_advanced'     => 'image_advanced_mk2',
		'hidden'            => '',
		'image'             => 'image_advanced_mk2',
		'image_advanced'    => 'image_advanced_mk2',
		'map'               => '',
		'number'            => '',
		'oembed'            => '',
		'password'          => '',
		'plupload_image'    => 'image_advanced_mk2',
		'post'              => '',
		'proportion_slider' => '',
		'range'             => '',
		'select_advanced'   => '',
		'taxonomy_advanced' => '',
		'text_list'         => '',
		'thickbox_image'    => 'image_advanced_mk2',
		'url'               => '',
		'wysiwyg'           => '',
	);
}

/**
 * Warn once per deprecated field type found in the registered meta boxes.
 *
 * Runs at registration rather than at render so the notice fires even for a
 * field that is never displayed. It only warns under WP_DEBUG, which is enough
 * here: nothing in the theme or dt-the7-core registers any of these types, so
 * the notice exists for developers building against the theme.
 *
 * @param array $meta_boxes Meta boxes about to be registered.
 *
 * @return void
 */
function the7_warn_about_deprecated_meta_box_field_types( $meta_boxes ) {
	$deprecated = the7_get_deprecated_meta_box_field_types();
	$reported   = array();

	foreach ( (array) $meta_boxes as $meta_box ) {
		if ( empty( $meta_box['fields'] ) || ! is_array( $meta_box['fields'] ) ) {
			continue;
		}

		foreach ( $meta_box['fields'] as $field ) {
			if ( ! isset( $field['type'] ) || ! is_string( $field['type'] ) ) {
				continue;
			}

			$type = $field['type'];

			if ( ! array_key_exists( $type, $deprecated ) || isset( $reported[ $type ] ) ) {
				continue;
			}

			$reported[ $type ] = true;

			if ( $deprecated[ $type ] ) {
				$message = sprintf(
					/* translators: 1: deprecated meta box field type, 2: replacement field type. */
					__( 'Meta box field type "%1$s" is deprecated and will be removed in The7 15.1.0. Use "%2$s" instead.', 'the7mk2' ),
					$type,
					$deprecated[ $type ]
				);
			} else {
				$message = sprintf(
					/* translators: %s: deprecated meta box field type. */
					__( 'Meta box field type "%s" is deprecated and will be removed in The7 15.1.0. It has no replacement.', 'the7mk2' ),
					$type
				);
			}

			_doing_it_wrong( 'presscore_register_meta_boxes', esc_html( $message ), '15.0.6' );
		}
	}
}

/**
 * Register meta boxes
 */
function presscore_register_meta_boxes() {
	// Make sure there's no errors when the plugin is deactivated or during upgrade
	if ( !class_exists( 'The7_RW_Meta_Box' ) ) {
		return;
	}

	global $DT_META_BOXES;

	do_action( 'the7_before_meta_box_registration' );

	the7_warn_about_deprecated_meta_box_field_types( $DT_META_BOXES );

	foreach ( $DT_META_BOXES as $meta_box ) {
		new The7_RW_Meta_Box( $meta_box );
	}
}
add_action( 'admin_init', 'presscore_register_meta_boxes', 30 );

/**
 * Define default meta boxes for templates
 *
 * @TODO: Delete in the future.
 *
 * @param  array $hidden Hidden Meta Boxes
 * @param  string|WP_Screen $screen Current screen
 * @param  bool $use_defaults Use default Meta Boxes or not
 * 
 * @return array Hidden Meta Boxes
 */
function presscore_hidden_meta_boxes( $hidden, $screen, $use_defaults ) {
	$template   = dt_get_template_name();
	$meta_boxes = the7_get_meta_boxes_with_template_dependencies();

	foreach ( $meta_boxes as $meta_box ) {
		if ( in_array( $template, (array) $meta_box['only_on']['template'], true ) ) {
			$meta_box_key_to_show = array_search( $meta_box['id'], $hidden, true );
			if ( false !== $meta_box_key_to_show ) {
				unset( $hidden[ $meta_box_key_to_show ] );
			}
		} else {
			$hidden[] = $meta_box['id'];
		}
	}

	return array_unique( $hidden );
}
//add_filter('hidden_meta_boxes', 'presscore_hidden_meta_boxes', 99, 3);

/**
 * @return array
 */
function the7_get_meta_boxes_with_template_dependencies() {
	global $DT_META_BOXES;

	$meta_boxes = array();

	foreach ( $DT_META_BOXES as $meta_box ) {
		if ( isset( $meta_box['only_on']['template'] ) ) {
			$meta_boxes[] = $meta_box;
		}
	}

	return $meta_boxes;
}