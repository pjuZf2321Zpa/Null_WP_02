<?php
/**
 * License platform module bootstrap.
 *
 * @package The7
 */

defined( 'ABSPATH' ) || exit;

\The7\License\License_Platform_Persistence::init();
