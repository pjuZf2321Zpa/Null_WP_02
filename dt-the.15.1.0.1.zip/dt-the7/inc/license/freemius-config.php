<?php
/**
 * Freemius platform configuration.
 *
 * @package The7
 */

namespace The7\License;

defined( 'ABSPATH' ) || exit;

/**
 * Class Freemius_Config
 *
 * URLs are placeholders until Freemius storefront URLs are finalized.
 */
class Freemius_Config implements Platform_Config {

	public function key() {
		return License_Platform::FREEMIUS;
	}

	public function purchase_url() {
		return 'https://the7.io/pricing/';
	}

	public function license_terms_url() {
		return 'https://the7.io/licenses/';
	}

	public function manage_url() {
		return 'https://customers.freemius.com/login';
	}

	public function product_id() {
		return '';
	}
}
