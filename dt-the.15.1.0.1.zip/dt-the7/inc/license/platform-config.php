<?php
/**
 * Platform-specific URLs and product metadata.
 *
 * @package The7
 */

namespace The7\License;

defined( 'ABSPATH' ) || exit;

/**
 * Interface Platform_Config
 */
interface Platform_Config {

	/**
	 * @return string Platform key (e.g. envato, freemius).
	 */
	public function key();

	/**
	 * @return string Checkout / purchase URL.
	 */
	public function purchase_url();

	/**
	 * @return string License terms URL.
	 */
	public function license_terms_url();

	/**
	 * @return string Account / license management URL.
	 */
	public function manage_url();

	/**
	 * @return string Marketplace product identifier.
	 */
	public function product_id();
}
