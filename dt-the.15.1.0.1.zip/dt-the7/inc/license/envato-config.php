<?php
/**
 * Envato / ThemeForest platform configuration.
 *
 * @package The7
 */

namespace The7\License;

defined( 'ABSPATH' ) || exit;

/**
 * Class Envato_Config
 */
class Envato_Config implements Platform_Config {

	public function key() {
		return License_Platform::ENVATO;
	}

	public function purchase_url() {
		return 'https://themeforest.net/checkout/from_item/5556590?license=regular&support=bundle_6month&ref=Dream-Theme';
	}

	public function license_terms_url() {
		return 'https://themeforest.net/licenses/standard';
	}

	public function manage_url() {
		return 'https://my.the7.io';
	}

	public function product_id() {
		return '5556590';
	}
}
