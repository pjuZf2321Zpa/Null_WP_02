<?php
/**
 * The7 dashboard screen.
 *
 * @package The7\Admin
 */

defined( 'ABSPATH' ) || exit;
?>

<div id="the7-dashboard" class="wrap">
	<h1 aria-hidden="true" class="hidden"><?php esc_html_e( 'The7 Dashboard', 'the7mk2' ); ?></h1>

	<?php \The7\Admin\Remote_Banner::instance()->render(); ?>

	<div class="the7-welcome">
		<svg xmlns="http://www.w3.org/2000/svg" width="132" height="132" fill="none" viewBox="0 0 132 132">
			<path fill="url(#a)" d="M41.436 15.713C22.12 24.913 8.77 44.617 8.77 67.438c0 31.624 25.636 57.261 57.26 57.261 31.625 0 57.261-25.637 57.261-57.26 0-22.68-13.184-42.28-32.307-51.554l1.668-3.38c20.368 9.888 34.409 30.77 34.409 54.933 0 33.706-27.325 61.031-61.03 61.031C32.323 128.469 5 101.144 5 67.439c0-24.308 14.209-45.295 34.773-55.11l1.663 3.384Z"></path>
			<path fill="#fff" d="M88.158 41.69v5.32L60 100.424h-6.747l28.423-53.21H49.481V41.69h38.677ZM52.65 1.096v3.88h3.354V6.99H52.65v6.207c0 .605.138 1.095.443 1.44l.001.002h.002l.001.003h.002c.326.347.787.508 1.353.508.19 0 .392-.038.605-.11.17-.056.35-.15.54-.272l.854 1.773a5.05 5.05 0 0 1-1.116.56h-.002l-.004.002a3.39 3.39 0 0 1-1.225.236c-1.28 0-2.23-.315-2.88-.92-.632-.617-.96-1.51-.96-2.7V6.99H48.2V4.976h2.063V1.095h2.387Z"></path>
			<path fill="#fff" fill-rule="evenodd" d="M78.06 4.677c1.074 0 2.041.28 2.905.84l.002.002c.86.543 1.542 1.334 2.042 2.384l.002.003c.493 1.002.753 2.198.775 3.588h-9.394l.014.2.004.06c.052.619.22 1.175.506 1.663l.001.002a3.64 3.64 0 0 0 1.388 1.336c.575.314 1.211.47 1.903.47.788 0 1.457-.172 1.992-.53h.002l.001-.001c.471-.329.862-.76 1.144-1.26l2.116.9a6.07 6.07 0 0 1-1.205 1.512l-.002.002a5.22 5.22 0 0 1-1.848 1.105h-.002c-.705.257-1.52.387-2.447.387-1.18 0-2.223-.266-3.135-.794a5.983 5.983 0 0 1-2.094-2.156l-.05-.09c-.513-.946-.772-2.042-.772-3.291 0-1.25.267-2.346.796-3.293a5.75 5.75 0 0 1 2.167-2.218c.93-.546 1.991-.821 3.188-.821Zm-.076 2.016c-.527 0-1.05.123-1.57.366a3.2 3.2 0 0 0-1.31 1.05l-.028.036c-.28.38-.443.843-.492 1.379l-.019.203h6.614l-.017-.201-.004-.05c-.049-.511-.192-.955-.436-1.323l-.025-.036a2.936 2.936 0 0 0-1.213-1.056 3.218 3.218 0 0 0-1.5-.368Z" clip-rule="evenodd"></path>
			<path fill="#fff" d="M61.262 0v7.056l.341-.517a4.06 4.06 0 0 1 1.115-1.147h.001l.003-.002c.678-.473 1.484-.713 2.43-.713.951 0 1.763.194 2.443.573.65.364 1.152.928 1.502 1.702l.033.076.002.003c.366.796.554 1.854.554 3.181v6.83h-2.41v-6.183c0-1.004-.117-1.797-.364-2.362-.236-.557-.57-.968-1.01-1.212l-.043-.023c-.428-.232-.92-.345-1.475-.345-.99-.018-1.778.306-2.334.988v.001l-.003.002c-.532.675-.785 1.627-.785 2.827v6.307H58.85V0h2.412Z"></path>
			<defs>
				<linearGradient id="a" x1="66.03" x2="66.03" y1="12.328" y2="128.469" gradientUnits="userSpaceOnUse">
					<stop stop-color="#0AD6FF"></stop>
					<stop offset="1" stop-color="#00ABF5"></stop>
				</linearGradient>
			</defs>
		</svg>
		<h2 class="the7-welcome-text">
			<?php
			// translators: %s: The7.
			printf( esc_html__( 'Welcome to %s', 'the7mk2' ), ' <strong>The7!</strong>' );
			?>
		</h2>
		<p class="the7-version"><?php echo esc_html( sprintf( 'v.%s', THE7_VERSION ) ); ?></p>
	</div>

	<div class="the7-registration">

		<?php $template_name = presscore_theme_is_activated() ? 'registered' : ''; ?>

		<div class="the7-thank-you">
			<?php presscore_get_template_part( 'the7_admin', '/partials/dashboard/welcome/thank-you', $template_name ); ?>
		</div>

		<?php if ( is_super_admin() ) : ?>

		<div class="the7-registration-area">

			<?php presscore_get_template_part( 'the7_admin', '/partials/dashboard/welcome/registration-area', $template_name ); ?>

		</div>

		<?php endif; ?>

		<div class="the7-resources">
			<h3><?php echo esc_html_x( 'The7 Resources', 'admin', 'the7mk2' ); ?></h3>
			<ul>
				<li><a href="https://guide.the7.io/?utm_source=wp-admin&utm_medium=referral&utm_campaign=the7-dashboard-resources&utm_content=user-guide" target="_blank" rel="noopener"><?php echo esc_html_x( 'User guide', 'admin', 'the7mk2' ); ?></a></li>
				<li><a href="https://the7.io/changelog/?utm_source=wp-admin&utm_medium=referral&utm_campaign=the7-dashboard-resources&utm_content=changelog" target="_blank" rel="noopener"><?php echo esc_html_x( 'Changelog', 'admin', 'the7mk2' ); ?></a></li>
				<li><a href="https://my.the7.io/?utm_source=wp-admin&utm_medium=referral&utm_campaign=the7-dashboard-resources&utm_content=license-management" target="_blank" rel="noopener"><?php echo esc_html_x( 'License management', 'admin', 'the7mk2' ); ?></a></li>
				<li><a href="https://the7.io/pricing/?utm_source=wp-admin&utm_medium=referral&utm_campaign=the7-dashboard-resources&utm_content=pricing-licensing" target="_blank" rel="noopener"><?php echo esc_html_x( 'Pricing & licensing', 'admin', 'the7mk2' ); ?></a></li>
				<li><a href="https://support.dream-theme.com/?utm_source=wp-admin&utm_medium=referral&utm_campaign=the7-dashboard-resources&utm_content=contact-support" target="_blank" rel="noopener"><?php echo esc_html_x( 'Contact support', 'admin', 'the7mk2' ); ?></a></li>
			</ul>
		</div>

	</div>

	<h2 id="pre-made-websites"><?php echo esc_html_x( 'Pre-made Website Templates', 'admin', 'the7mk2' ); ?></h2>

	<?php presscore_get_template_part( 'the7_admin', 'partials/dashboard/demos' ); ?>

</div>
