<?php

defined( 'ABSPATH' ) || exit;

?>

<h3><?php echo esc_html_x( 'Thank you for choosing The7', 'admin', 'the7mk2' ); ?></h3>
<p>
	<?php echo esc_html_x( 'Register this copy of The7 to access the updates, premium plugins, pre-made websites, and other features included with your license.', 'admin', 'the7mk2' ); ?>
</p>
<p>
	<?php
	echo wp_kses_post(
		sprintf(
			// translators: %s: view license options link.
			_x( 'Don\'t have a license yet? %s', 'admin', 'the7mk2' ),
			'<a href="https://the7.io/pricing/?utm_source=wp-admin&utm_medium=referral&utm_campaign=the7-license-options&utm_content=unregistered-theme" target="_blank" rel="noopener">' . esc_html_x( 'View license options', 'admin', 'the7mk2' ) . '</a>'
		)
	);
	?>
</p>
