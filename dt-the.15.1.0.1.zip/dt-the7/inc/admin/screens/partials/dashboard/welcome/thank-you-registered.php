<?php

defined( 'ABSPATH' ) || exit;

?>

<h3><?php echo esc_html_x( 'Your copy of The7 is registered', 'admin', 'the7mk2' ); ?></h3>
<p>
	<?php echo esc_html_x( 'The theme is registered and ready to use. You can access the updates and other features included with your license.', 'admin', 'the7mk2' ); ?>
</p>
