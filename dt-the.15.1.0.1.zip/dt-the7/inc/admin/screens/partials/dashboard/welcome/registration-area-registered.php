<?php
/**
 * The7 dashboard de-registration form.
 *
 * @package The7
 */

defined( 'ABSPATH' ) || exit;
?>

<h3><?php echo esc_html_x( 'Theme Registration', 'admin', 'the7mk2' ); ?></h3>
<form method="post">
	<?php settings_fields( 'the7_theme_registration' ); ?>
	<p>
		<?php echo esc_html_x( 'Your purchase code is:', 'admin', 'the7mk2' ); ?><br>
		<code class="the7-code"><?php echo esc_html( presscore_get_censored_purchase_code() ); ?></code>
	</p>
	<p>
		<button type="submit" class="button button-primary" name="deregister_theme" value="de-register" title="<?php echo esc_attr_x( 'De-register Theme', 'admin', 'the7mk2' ); ?>"><?php echo esc_html_x( 'De-register Theme', 'admin', 'the7mk2' ); ?></button>
	</p>
</form>
