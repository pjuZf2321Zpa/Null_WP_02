<?php
/**
 * The7 dashboard registration form.
 *
 * @package The7
 */

defined( 'ABSPATH' ) || exit;
?>

<h3><?php echo esc_html( _x( 'Theme Registration', 'admin', 'the7mk2' ) ); ?></h3>
<form method="post">
	<?php settings_fields( 'the7_theme_registration' ); ?>

	<p>
		<?php echo esc_html_x( 'Purchase Code:', 'admin', 'the7mk2' ); ?><br>
		<input id="the7_purchase_code" class="of-input" name="the7_purchase_code" type="text" value="" size="36" title="<?php echo esc_attr_x( 'Purchase Code', 'admin', 'the7mk2' ); ?>">
	</p>
	<p>
		<label>
			<input type="checkbox" id="the7-registration-terms">&nbsp;
			<?php
			echo esc_html_x( 'I consent to the collection and storage of this website’s URL and purchase code for license validation and copyright compliance. I understand that this information will be retained for as long as the purchase code remains valid.', 'admin', 'the7mk2' );
			?>
		</label>
	</p>
	<p>
		<button type="submit" id="the7-register-theme-button" class="button button-primary" name="register_theme" value="register" title="<?php echo esc_attr_x( 'Register Theme', 'admin', 'the7mk2' ); ?>" disabled="disabled"><?php echo esc_html_x( 'Register Theme', 'admin', 'the7mk2' ); ?></button>
	</p>
</form>
