<?php

namespace The7\Admin\Notices\Announcements;

use The7\Admin\Notices\Abstract_Notice;

defined( 'ABSPATH' ) || exit;

abstract class Abstract_Announcement extends Abstract_Notice {

	protected const POSTBOX      = 'the7-postbox';
	protected const ANNOUNCEMENT = 'the7-announcement';

	public function get_wrapper_class() {
		return self::NOTICE . ' ' . self::POSTBOX . ' ' . self::ANNOUNCEMENT . ' ' . self::DASHBOARD_NOTICE;
	}
}
