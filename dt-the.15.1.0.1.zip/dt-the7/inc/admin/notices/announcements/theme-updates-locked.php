<?php

namespace The7\Admin\Notices\Announcements;

use The7\Admin\Pages\Dashboard;
use The7_Feature_Access;

defined( 'ABSPATH' ) || exit;

/**
 * Capability Lock Notice for the `theme_updates` Feature Access capability.
 *
 * Purely informational: when the server verdict blocks `theme_updates` and carries a
 * message, this dismissible notice shows that server-authored message on the The7 dashboard
 * screen. The message is the notice's whole body, so a blocking verdict without one shows
 * nothing. No enforcement, no recheck.
 */
class Theme_Updates_Locked extends Abstract_Announcement {

	/**
	 * Dismissal code persisted in the7_dismissed_admin_notices.
	 */
	const CODE = 'the7_theme_updates_locked';

	public function render() {
		// Not reachable through is_visible() below, but the `the7_admin_notice_is_visible`
		// filter can force a render, so the guard is repeated rather than assumed.
		if ( ! the7_feature_access_is_usable() ) {
			return;
		}

		// Server-authored message, already sanitized with wp_kses_post by Feature Access.
		echo The7_Feature_Access::get_sanitized_message( The7_Feature_Access::THEME_UPDATES ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_kses_post sanitized upstream.
	}

	public function is_visible() {
		if ( ! Dashboard::is_current_screen() || ! the7_feature_access_is_usable() ) {
			return false;
		}

		return current_user_can( 'update_themes' ) && The7_Feature_Access::is_blocked_with_message( The7_Feature_Access::THEME_UPDATES );
	}

	public function get_code() {
		return self::CODE;
	}

	/**
	 * Keep the notice re-notifying on a fresh lapse.
	 *
	 * Dismissal is valid only while the capability is blocked: whenever it is granted,
	 * any stale dismissal is cleared so the next lapse shows an undismissed notice.
	 * Stateless — no previous verdict is stored.
	 *
	 * Keys on `is_blocked` alone, deliberately narrower than `is_visible()`: dismissal is
	 * scoped to the lapse, not to any one moment's announceability within it. Requiring a
	 * message here would let a mid-lapse message change re-notify about the same lapse.
	 *
	 * Runs on `admin_init` for every admin screen, so it is the one surface where an
	 * unreadable Feature Access build would lock the whole admin out. Bailing costs a single
	 * stale-dismissal reset, which the next healthy request performs.
	 *
	 * @return void
	 */
	public static function sync_dismissal() {
		if ( ! the7_feature_access_is_usable() ) {
			return;
		}

		if ( The7_Feature_Access::is_blocked( The7_Feature_Access::THEME_UPDATES ) ) {
			return;
		}

		$notices = the7_admin_notices();
		if ( $notices->notice_is_dismissed( self::CODE ) ) {
			$notices->reset( self::CODE );
		}
	}
}
