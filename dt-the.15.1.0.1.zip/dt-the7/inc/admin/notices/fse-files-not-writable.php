<?php

namespace The7\Admin\Notices;

use The7\Mods\Compatibility\Gutenberg\Block_Theme\The7_Block_Theme_Compatibility;

defined( 'ABSPATH' ) || exit;

/**
 * Reports a block theme transform that cannot move its files.
 */
class Fse_Files_Not_Writable extends Abstract_Notice {

	public function get_code() {
		return 'fse-files-not-writable';
	}

	/**
	 * @return bool
	 */
	public function is_visible() {
		if ( ! current_user_can( 'edit_theme_options' ) || The7_Block_Theme_Compatibility::get_files_error() === null ) {
			return false;
		}

		return the7_is_gutenberg_theme_mode_active()
			|| wp_is_block_theme()
			|| The7_Block_Theme_Compatibility::instance()->has_block_theme_files();
	}

	public function get_wrapper_class() {
		return parent::get_wrapper_class() . ' ' . self::NOTICE_ERROR;
	}

	public function render() {
		$error = The7_Block_Theme_Compatibility::get_files_error();
		if ( ! $error ) {
			return;
		}

		printf(
			'<p role="heading">%s</p>',
			esc_html_x( 'The7 could not set up the block theme files', 'admin', 'the7mk2' )
		);
		printf( '<p>%s</p>', esc_html( self::get_reason_sentence( $error ) ) );
		printf( '<p>%s</p>', esc_html( self::get_remediation_sentence( $error ) ) );
		printf( '<p><em>%s</em></p>', esc_html( self::get_provenance_sentence( $error ) ) );
	}

	/**
	 * @param array $error Recorded failure.
	 *
	 * @return string
	 */
	private static function get_reason_sentence( array $error ) {
		$dir = isset( $error['dir'] ) ? $error['dir'] : '';

		switch ( isset( $error['reason'] ) ? $error['reason'] : '' ) {
			case 'source':
				/* translators: %s: directory path. */
				$template = _x( 'The7 could not read the block theme files from “%s”.', 'admin', 'the7mk2' );
				break;
			case 'filesystem':
				/* translators: %s: directory path. */
				$template = _x( 'The7 could not get write access to “%s”.', 'admin', 'the7mk2' );
				break;
			case 'delete':
				/* translators: %s: directory path. */
				$template = _x( 'The7 could not remove the block theme files from “%s”.', 'admin', 'the7mk2' );
				break;
			case 'copy':
			default:
				/* translators: %s: directory path. */
				$template = _x( 'The7 could not write the block theme files to “%s”.', 'admin', 'the7mk2' );
		}

		return sprintf( $template, $dir );
	}

	/**
	 * @param array $error Recorded failure.
	 *
	 * @return string
	 */
	private static function get_remediation_sentence( array $error ) {
		if ( ( isset( $error['reason'] ) ? $error['reason'] : '' ) === 'source' ) {
			return _x(
				'Reinstall The7 so the block theme files it ships are back in place. Until they are, The7 tries this again on every page load.',
				'admin',
				'the7mk2'
			);
		}

		return _x(
			'Make sure the folder exists and that the web server can write to it (CHMOD 755). Until it can, The7 repeats this on every page load.',
			'admin',
			'the7mk2'
		);
	}

	/**
	 * @param array $error Recorded failure.
	 *
	 * @return string
	 */
	private static function get_provenance_sentence( array $error ) {
		$time    = isset( $error['time'] ) ? (int) $error['time'] : 0;
		$version = isset( $error['theme_version'] ) ? $error['theme_version'] : '';

		return sprintf(
			/* translators: 1: date and time, 2: The7 version. */
			_x( 'First seen %1$s, running The7 %2$s.', 'admin', 'the7mk2' ),
			wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $time ),
			$version
		);
	}
}
