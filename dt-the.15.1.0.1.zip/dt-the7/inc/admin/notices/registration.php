<?php

namespace The7\Admin\Notices;

use The7\License\Freemius_Config;

defined( 'ABSPATH' ) || exit;

class Registration extends Abstract_Notice {

	public function render() {
		$config       = new Freemius_Config();
		$register_url = admin_url( 'admin.php?page=the7-dashboard' );
		?>

		<p role="heading"><?php echo esc_html_x( 'Thank you for choosing The7!', 'admin', 'the7mk2' ); ?></p>
		<p>
			<?php
			echo wp_kses_post(
				sprintf(
					// translators: %s: register link.
					_x( '%s this copy of the theme to access premium plugins, pre-made website templates, one-click updates, and more.', 'admin', 'the7mk2' ),
					'<a href="' . esc_url( $register_url ) . '">' . esc_html_x( 'Register', 'admin', 'the7mk2' ) . '</a>'
				)
			);
			?>
		</p>
		<p>
			<?php
			echo wp_kses_post(
				sprintf(
					// translators: %s: purchase link.
					_x( 'Please note that each site/project built with The7 must be covered by either a separate 1-Site Lifetime license or an Unlimited license, both of which can be purchased %s.', 'admin', 'the7mk2' ),
					'<a href="' . esc_url( $config->purchase_url() ) . '" target="_blank" rel="nofollow">' . esc_html_x( 'here', 'admin', 'the7mk2' ) . '</a>'
				)
			);
			?>
		</p>

		<?php
	}

	public function get_code() {
		return 'the7_registration_notice';
	}

	public function is_visible() {
		return ! presscore_theme_is_activated();
	}

	public function get_wrapper_class() {
		return parent::get_wrapper_class() . ' ' . self::NOTICE_INFO;
	}
}
