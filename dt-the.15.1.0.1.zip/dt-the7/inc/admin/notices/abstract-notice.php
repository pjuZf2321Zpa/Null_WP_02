<?php

namespace The7\Admin\Notices;

use The7_Admin_Notices;

defined( 'ABSPATH' ) || exit;

abstract class Abstract_Notice {

	protected const NOTICE             = 'notice';
	protected const NOTICE_ERROR       = 'notice-error';
	protected const NOTICE_INFO        = 'notice-info';
	protected const NOTICE_WARNING     = 'notice-warning';
	protected const NOTICE_SUCCESS     = 'notice-success';
	protected const NOTICE_DISMISSIBLE = 'is-dismissible';
	protected const DASHBOARD_NOTICE   = 'the7-dashboard-notice';
	protected const DEBUG_NOTICE       = 'the7-debug-notice';
	protected const THE7_NOTICE        = 'the7-notice';

	abstract public function render();

	abstract public function get_code();

	public function is_visible() {
		return true;
	}

	public function get_wrapper_class() {
		return self::NOTICE . ' ' . self::THE7_NOTICE;
	}

	protected function should_display_once() {
		return The7_Admin_Notices::should_display_once( $this->get_code() );
	}
}
