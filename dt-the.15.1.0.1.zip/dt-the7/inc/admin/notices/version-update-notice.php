<?php

namespace The7\Admin\Notices;

use The7\Admin\Pages\Dashboard;

defined( 'ABSPATH' ) || exit;

/**
 * Version Update Notice.
 *
 * A dismissible admin notice shown to registered installations on every admin screen
 * except the dashboard, advertising that a newer The7 line exists and pointing the user
 * to the dashboard to review their update options. Theme-authored fixed copy — not an
 * Announcement, carries no server message and runs no shortcode pipeline. See CONTEXT.md,
 * "Version Update Notice".
 */
class Version_Update_Notice extends Abstract_Notice {

	/**
	 * Advertised major line. Hardcoded for now — a one-constant bump.
	 */
	const VERSION = '15';

	/**
	 * Dismissal code persisted in the7_dismissed_admin_notices.
	 */
	const CODE = 'the7_version_update_notice';

	public function render() {
		printf(
			'<p><strong>%1$s</strong><br>%2$s</p>',
			esc_html( self::get_headline() ),
			self::get_review_options_sentence() // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-sanitized with wp_kses_post.
		);
	}

	/**
	 * Headline advertising the available line, e.g. "The7 15 is available".
	 *
	 * @return string
	 */
	public static function get_headline() {
		/* translators: %s: The7 major version. */
		return sprintf( __( 'The7 %s is available', 'the7mk2' ), self::VERSION );
	}

	/**
	 * The shared "Review your update options …" sentence with a dashboard link,
	 * pre-sanitized for output. Reused by other update surfaces (e.g. the theme
	 * details "Update Available" box) so the copy lives in one place.
	 *
	 * @return string
	 */
	public static function get_review_options_sentence() {
		$dashboard_url = admin_url( 'admin.php?page=the7-dashboard' );

		return wp_kses_post(
			sprintf(
				/* translators: %s: "Review your update options" link. */
				__( '%s to keep receiving future security, compatibility, and feature updates.', 'the7mk2' ),
				'<a href="' . esc_url( $dashboard_url ) . '">' . esc_html__( 'Review your update options', 'the7mk2' ) . '</a>'
			)
		);
	}

	public function is_visible() {
		if ( Dashboard::is_current_screen() ) {
			return false;
		}

		return presscore_theme_is_activated() && current_user_can( 'update_themes' );
	}

	public function get_code() {
		return self::CODE;
	}

	public function get_wrapper_class() {
		return self::NOTICE . ' ' . self::NOTICE_INFO . ' ' . self::THE7_NOTICE . ' ' . self::NOTICE_DISMISSIBLE;
	}

	/**
	 * Keep the notice re-notifying after a fresh registration.
	 *
	 * Dismissal is valid only while the theme remains registered. Whenever it is not
	 * registered, any stale dismissal is cleared so a later registration shows an
	 * undismissed notice. Stateless — no previous registration state is stored.
	 *
	 * @return void
	 */
	public static function sync_dismissal() {
		if ( presscore_theme_is_activated() ) {
			return;
		}

		$notices = the7_admin_notices();
		if ( $notices->notice_is_dismissed( self::CODE ) ) {
			$notices->reset( self::CODE );
		}
	}
}
