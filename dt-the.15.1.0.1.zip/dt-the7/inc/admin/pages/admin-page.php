<?php
/**
 * Base admin page.
 *
 * @package The7\Admin\Pages
 */

namespace The7\Admin\Pages;

defined( 'ABSPATH' ) || exit;

abstract class Admin_Page {

	/**
	 * @var string
	 */
	protected $slug = '';

	/**
	 * @var string
	 */
	protected $title = '';

	/**
	 * @var string
	 */
	protected $capability = '';

	/**
	 * @var string
	 */
	protected $screen_path = '';

	/**
	 * @var string
	 */
	protected $hook_suffix = '';

	/**
	 * Get menu slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return $this->slug;
	}

	/**
	 * Get page title.
	 *
	 * @return string
	 */
	public function get_title() {
		return $this->title;
	}

	/**
	 * Get required capability.
	 *
	 * @return string
	 */
	public function get_capability() {
		return $this->capability;
	}

	/**
	 * Get path to page template.
	 *
	 * @return string
	 */
	public function get_screen_path() {
		return $this->screen_path;
	}

	/**
	 * Store page hook suffix.
	 *
	 * @param  string $hook_suffix Hook suffix.
	 */
	public function set_hook_suffix( string $hook_suffix ) {
		$this->hook_suffix = $hook_suffix;
	}

	/**
	 * Get page hook suffix.
	 *
	 * @return string
	 */
	public function get_hook_suffix() {
		return $this->hook_suffix;
	}

	/**
	 * Render page content.
	 */
	public function render() {
		include $this->get_screen_path();
	}

	/**
	 * Add a top level admin menu page.
	 *
	 * @param string $menu_title Menu title. Defaults to page title.
	 * @param string $icon_url   Icon URL.
	 * @param int    $position   Menu position.
	 *
	 * @return string Hook suffix.
	 */
	public function add_menu_page( $menu_title = '', $icon_url = '', $position = null ) {
		$title = $menu_title ? $menu_title : $this->get_title();

		$hook_suffix = add_menu_page(
			$this->get_title(),
			$title,
			$this->get_capability(),
			$this->get_slug(),
			[ $this, 'render' ],
			$icon_url,
			$position
		);

		$this->set_hook_suffix( $hook_suffix );

		$this->on_after_add_menu_page( $hook_suffix );

		return $hook_suffix;
	}

	/**
	 * Add submenu page under current page.
	 *
	 * @param Admin_Page $submenu_page Submenu page instance.
	 * @param array      $args         Optional overrides for menu args.
	 *
	 * @return array {
	 *     @type string $hook_suffix Hook suffix.
	 *     @type array  $page        Final page args after filters.
	 * }
	 */
	public function add_submenu_page( Admin_Page $submenu_page, $args = [] ) {
		$page = wp_parse_args(
			$args,
			[
				'dashboard_slug' => $this->get_slug(),
				'slug'           => $submenu_page->get_slug(),
				'title'          => $submenu_page->get_title(),
				'capability'     => $submenu_page->get_capability(),
				'page_title'     => '',
				'menu_title'     => '',
				'callback'       => [ $submenu_page, 'render' ],
			]
		);

		$page = apply_filters( 'the7_subpages_filter', $page );

		$hook_suffix = add_submenu_page(
			$page['dashboard_slug'],
			$page['page_title'] ? $page['page_title'] : $page['title'],
			$page['menu_title'] ? $page['menu_title'] : $page['title'],
			$page['capability'],
			$page['slug'],
			isset( $page['callback'] ) ? $page['callback'] : [ $submenu_page, 'render' ]
		);

		$submenu_page->set_hook_suffix( $hook_suffix );

		// The submenu page wires its own hooks. Calling this on `$this` ran the parent page's
		// setup for every child, so the dashboard's demo-content assets and load handlers landed
		// on every subpage while the subpages' own hooks (e.g. TGMPA on Plugins) never ran.
		$submenu_page->on_after_add_menu_page( $hook_suffix );

		return [
			'hook_suffix' => $hook_suffix,
			'page'        => $page,
		];
	}

	/**
	 * Remove "Screen Options" and "Help" tabs from the page.
	 *
	 * Runs on the page 'load-' hook, so it affects the current request only.
	 *
	 * @return void
	 */
	public function hide_screen_meta_links() {
		add_filter( 'screen_options_show_screen', '__return_false' );

		$remove_help_tabs = static function () {
			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
			if ( $screen ) {
				$screen->remove_help_tabs();
				$screen->set_help_sidebar( '' );
			}
		};

		$remove_help_tabs();

		// Help tabs may be added later (on 'admin_head' and alike), so clean them up
		// once more right before the screen meta is rendered.
		add_action( 'in_admin_header', $remove_help_tabs, 999 );
	}

	public function enqueue_styles() {
		// Override in subclass.
	}

	public function enqueue_scripts() {
		// Override in subclass.
	}

	protected function on_after_add_menu_page( $hook_suffix ) {
		// Hide "Screen Options" and "Help" tabs (#screen-meta-links).
		add_action(
			'load-' . $hook_suffix,
			[
				$this,
				'hide_screen_meta_links',
			]
		);

		// Custom assets.
		add_action(
			'admin_print_styles-' . $hook_suffix,
			[
				$this,
				'enqueue_styles',
			]
		);
		add_action(
			'admin_print_scripts-' . $hook_suffix,
			[
				$this,
				'enqueue_scripts',
			]
		);
	}
}
