<?php
/**
 * Kalium WordPress Theme
 *
 * Breadcrumb widget.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

if ( ! kalium()->is->breadcrumb_navxt_active() ) {
	return;
}

vc_map(
	[
		'base'        => 'kalium_breadcrumb',
		'name'        => 'Breadcrumb',
		'description' => 'Page location',
		'category'    => 'Laborator',
		'icon'        => kalium()->file_url( 'includes/wpbakery/assets/images/breadcrumb.svg' ),
		'params'      => [
			[
				'type'        => 'textfield',
				'heading'     => 'Extra class name',
				'param_name'  => 'el_class',
				'description' => 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.',
			],
			[
				'type'       => 'css_editor',
				'heading'    => 'Css',
				'param_name' => 'css',
				'group'      => 'Design options',
			],
		],
	]
);

class WPBakeryShortCode_Kalium_Breadcrumb extends WPBakeryShortCode {}
