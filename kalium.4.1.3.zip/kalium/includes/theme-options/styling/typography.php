<?php
/**
 * Kalium WordPress Theme
 *
 * Typography.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

// Section link control
kalium_customize_register_control(
	'kalium_styling_typography',
	[
		'type'         => 'kalium-section-link',
		'label'        => 'Typography',
		'priority'     => kalium()->customize->get_next_priority(),
		'section_link' => admin_url( 'admin.php?page=typolab' ),
	]
);
