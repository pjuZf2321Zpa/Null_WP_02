<?php
/**
 * Kalium WordPress Theme
 *
 * Page template hooks.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

// Page wrapper
add_action( 'kalium_page_before_content', 'kalium_page_content_wrapper_start', 5 );
add_action( 'kalium_page_after_content', 'kalium_page_content_wrapper_end', 100 );

// Page content
add_action( 'kalium_page_content', 'kalium_the_content' );
