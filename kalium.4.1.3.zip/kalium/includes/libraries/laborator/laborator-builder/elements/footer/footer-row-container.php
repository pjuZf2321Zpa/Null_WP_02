<?php
/**
 * Footer container row.
 */

namespace Laborator_Builder\Elements;

use Laborator_Builder\Attribute_Sets\Style_Background;

class Footer_Container_Row extends Container_Row {

	/**
	 * Name.
	 *
	 * @var string
	 */
	public static $name = 'footer_container_row';

	/**
	 * Get attribute sets.
	 *
	 * @return array
	 */
	public function get_attribute_sets() {
		return array_merge(
			parent::get_attribute_sets(),
			[
				Style_Background::class,
			]
		);
	}
}

// Register element
\Laborator_Builder::register_element_type( Footer_Container_Row::class );
