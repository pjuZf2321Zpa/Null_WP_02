<?php
/**
 * Social share link base element class.
 */

namespace Laborator_Builder\Elements;

use Laborator_Builder\Element;

class Social_Share_Link extends Element {

	/**
	 * Element name.
	 *
	 * @var string
	 * @static
	 */
	public static $name = 'social_share_link';

	/**
	 * Maximum instances of element.
	 *
	 * @var int
	 * @static
	 */
	public static $max_instances = 1;
}

// Register element
\Laborator_Builder::register_element_type( Social_Share_Link::class );
