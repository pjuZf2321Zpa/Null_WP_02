<?php
/**
 * Laborator Builder.
 *
 * Attribute data.
 */

namespace Laborator_Builder;

interface Attribute_Data {

	/**
	 * Content tab.
	 *
	 * @var string
	 */
	const TAB_CONTENT = 'Content';

	/**
	 * Style tab.
	 *
	 * @var string
	 */
	const TAB_STYLE = 'Style';

	/**
	 * Advanced tab.
	 *
	 * @var string
	 */
	const TAB_ADVANCED = 'Advanced';

	/**
	 * Layout section.
	 *
	 * @var string
	 */
	const SECTION_LAYOUT = 'Layout';

	/**
	 * Border section.
	 *
	 * @var string
	 */
	const SECTION_BORDER = 'Border';

	/**
	 * Positioning section.
	 *
	 * @var string
	 */
	const SECTION_DIMENSIONS = 'Dimensions';

	/**
	 * Visibility section.
	 *
	 * @var string
	 */
	const SECTION_VISIBILITY = 'Visibility';

	/**
	 * Text section.
	 *
	 * @var string
	 */
	const SECTION_TEXT = 'Text';

	/**
	 * Content section.
	 *
	 * @var string
	 */
	const SECTION_CONTENT = 'Content';

	/**
	 * Content section.
	 *
	 * @var string
	 */
	const SECTION_STYLE = 'Style';

	/**
	 * Custom CSS section.
	 *
	 * @var string
	 */
	const SECTION_CUSTOM_CSS = 'Custom CSS';
}
