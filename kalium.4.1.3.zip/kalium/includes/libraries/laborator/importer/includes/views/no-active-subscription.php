<?php
/**
 * Kalium WordPress Theme
 *
 * No active subscription.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}
?>
<div class="kalium-sites__content-pack-finish-view kalium-sites__content-pack-finish-view--visible">
<div class="kalium-sites__content-pack-finish-view-heading">
	<div class="kalium-sites__content-pack-finish-view-heading-icon failed">
		<svg class="checkmark error" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
			<circle class="checkmark_circle_error" cx="26" cy="26" r="25" fill="none"/>
			<path class="checkmark_check" stroke-linecap="round" fill="none" d="M16 16 36 36 M36 16 16 36"/>
		</svg>
	</div>

	<h3 class="kalium-sites__content-pack-finish-view-heading-title">Active Subscription Required</h3>
	<p class="kalium-sites__content-pack-finish-view-heading-description">
		In order to import <strong>Starter Sites</strong> you must have active subscription!
	</p>
</div>
</div>
