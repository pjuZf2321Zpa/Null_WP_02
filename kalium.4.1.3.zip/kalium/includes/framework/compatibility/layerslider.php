<?php
/**
 * Kalium WordPress Theme
 *
 * Layer Slider compatibility class.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
namespace Kalium\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class LayerSlider {

	/**
	 * Construct.
	 */
	public function __construct() {
		add_action( 'layerslider_ready', [ $this, '_disable_autoupdates' ] );
	}

	/**
	 * Disable auto updates.
	 */
	public function _disable_autoupdates() {
		$GLOBALS['lsAutoUpdateBox'] = false;
	}
}
