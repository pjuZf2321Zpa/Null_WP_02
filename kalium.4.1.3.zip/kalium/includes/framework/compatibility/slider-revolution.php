<?php
/**
 * Kalium WordPress Theme
 *
 * Slider Revolution compatibility class.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
namespace Kalium\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class Slider_Revolution {

	/**
	 * Construct.
	 */
	public function __construct() {

		// Set as theme
		if ( function_exists( 'set_revslider_as_theme' ) ) {
			set_revslider_as_theme();
		}
	}
}
