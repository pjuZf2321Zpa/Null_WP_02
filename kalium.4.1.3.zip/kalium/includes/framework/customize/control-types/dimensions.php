<?php
/**
 * Kalium WordPress Theme
 *
 * Customizer Control Type: Dimensions.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
namespace Kalium\Customize\Control_Types;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class Dimensions extends Base_Control {

	/**
	 * Control type.
	 *
	 * @var string
	 */
	public $type = 'kalium-dimensions';

	/**
	 * Width placeholder.
	 *
	 * @var string
	 */
	public $placeholder_width = 'Auto';

	/**
	 * Height placeholder.
	 *
	 * @var string
	 */
	public $placeholder_height = 'Auto';

	/**
	 * Add JSON data.
	 */
	public function to_json() {
		parent::to_json();

		$this->json['placeholder_width']  = $this->placeholder_width;
		$this->json['placeholder_height'] = $this->placeholder_height;
	}
}
