<?php
/**
 * Kalium WordPress Theme
 *
 * Customizer Control Type: Radio Button.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
namespace Kalium\Customize\Control_Types;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class Radio_Button extends Base_Control {

	/**
	 * Control type.
	 *
	 * @var string
	 */
	public $type = 'kalium-radio-button';

	/**
	 * Deselectable.
	 *
	 * @var bool
	 */
	public $allow_none = false;

	/**
	 * Add JSON data.
	 */
	public function to_json() {
		parent::to_json();

		$this->json['allow_none'] = $this->allow_none;
	}
}
