<?php
/**
 * Kalium WordPress Theme
 *
 * Customizer Control Type: Checkbox.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
namespace Kalium\Customize\Control_Types;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class Checkbox extends Base_Control {

	/**
	 * Control type.
	 *
	 * @var string
	 */
	public $type = 'kalium-checkbox';

	/**
	 * Input label.
	 *
	 * @var string
	 */
	public $input_label;

	/**
	 * Add JSON data.
	 */
	public function to_json() {
		parent::to_json();

		$this->json['input_label'] = $this->input_label;
	}
}
