<?php
/**
 * Kalium WordPress Theme
 *
 * Customizer Control Type: Quantity.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
namespace Kalium\Customize\Control_Types;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class Quantity extends Unit {

	/**
	 * Control type.
	 *
	 * @var string
	 */
	public $type = 'kalium-quantity';
}
