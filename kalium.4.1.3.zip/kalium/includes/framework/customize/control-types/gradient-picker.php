<?php
/**
 * Kalium WordPress Theme
 *
 * Customizer Control Type: Gradient Picker.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
namespace Kalium\Customize\Control_Types;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class Gradient_Picker extends Base_Control {

	/**
	 * Control type.
	 *
	 * @var string
	 */
	public $type = 'kalium-gradient-picker';

	/**
	 * Disable custom gradients.
	 *
	 * @var bool
	 */
	public $disable_custom_gradients;

	/**
	 * Inline label.
	 *
	 * @var bool
	 */
	public $inline_label = false;

	/**
	 * Add JSON data.
	 */
	public function to_json() {
		parent::to_json();

		$this->json['disable_custom_gradients'] = $this->disable_custom_gradients;
	}
}
