<?php
/**
 * Kalium WordPress Theme
 *
 * Customizer Control Type: Tabs.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
namespace Kalium\Customize\Control_Types;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class Tabs extends Base_Control {

	/**
	 * Control type.
	 *
	 * @var string
	 */
	public $type = 'kalium-tabs';

	/**
	 * Tabs do not store values as theme mods.
	 *
	 * @var bool
	 */
	public $contextual = true;

	/**
	 * First tab.
	 *
	 * @var bool
	 */
	public $first = true;

	/**
	 * Inline label.
	 *
	 * @var bool
	 */
	public $inline_label = false;

	/**
	 * To JSON.
	 */
	public function to_json() {
		parent::to_json();

		$this->json['first'] = $this->first;
	}
}
