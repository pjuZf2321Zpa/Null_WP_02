<?php
/**
 * Kalium WordPress Theme
 *
 * Customizer Control Type: Align Matrix.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
namespace Kalium\Customize\Control_Types;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class Align_Matrix extends Base_Control {

	/**
	 * Control type.
	 *
	 * @var string
	 */
	public $type = 'kalium-align-matrix';

	/**
	 * Max width.
	 *
	 * @var int
	 */
	public $width;

	/**
	 * Add JSON data.
	 */
	public function to_json() {
		parent::to_json();

		$this->json['width'] = $this->width;
	}
}
