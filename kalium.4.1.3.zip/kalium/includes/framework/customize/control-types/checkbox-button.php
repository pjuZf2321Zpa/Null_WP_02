<?php
/**
 * Kalium WordPress Theme
 *
 * Customizer Control Type: Checkbox Button.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
namespace Kalium\Customize\Control_Types;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class Checkbox_Button extends Checkbox {

	/**
	 * Control type.
	 *
	 * @var string
	 */
	public $type = 'kalium-checkbox-button';

	/**
	 * Allow none.
	 *
	 * @var string
	 */
	public $allow_none = true;

	/**
	 * Add JSON data.
	 */
	public function to_json() {
		parent::to_json();

		$this->json['allow_none'] = $this->allow_none;
	}
}
