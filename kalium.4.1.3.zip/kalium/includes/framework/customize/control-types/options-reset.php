<?php
/**
 * Kalium WordPress Theme
 *
 * Customizer Control Type: Options Reset.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
namespace Kalium\Customize\Control_Types;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

class Options_Reset extends Base_Control {

	/**
	 * Control type.
	 *
	 * @var string
	 */
	public $type = 'kalium-options-reset';

	/**
	 * Contextual.
	 *
	 * @var bool
	 */
	public $contextual = true;

	/**
	 * Button text.
	 *
	 * @var string
	 */
	public $button_text;

	/**
	 * Inline label.
	 *
	 * @var bool
	 */
	public $inline_label = false;

	/**
	 * Add JSON data.
	 */
	public function to_json() {
		parent::to_json();

		$this->json['button_text'] = $this->button_text;
	}
}
