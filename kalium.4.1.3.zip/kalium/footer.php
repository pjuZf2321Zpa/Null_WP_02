<?php
/**
 * Kalium WordPress Theme
 *
 * Theme footer.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

/**
 * Wrapper end hooks.
 *
 * @hooked kalium_footer_display - 10
 * @hooked kalium_site_wrapper_end - 99999
 */
do_action( 'kalium_wrapper_end' );

/**
 * After wrapper hooks.
 */
do_action( 'kalium_after_wrapper' );

/**
 * WP Footer actions.
 */
wp_footer();
?>
</body>
</html>
