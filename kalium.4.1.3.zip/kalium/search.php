<?php
/**
 * Kalium WordPress Theme
 *
 * Search template.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

/**
 * Theme header.
 */
get_header();

/**
 * Search page.
 *
 * @hooked kalium_search_page_content_wrapper_start - 10
 * @hooked kalium_search_results_info - 20
 * @hooked kalium_search_results - 30
 * @hooked kalium_search_page_content_wrapper_end - 40
 */
do_action( 'kalium_search_page' );

/**
 * Theme footer.
 */
get_footer();
