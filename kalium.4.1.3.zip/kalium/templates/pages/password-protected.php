<?php
/**
 * Kalium WordPress Theme
 *
 * Password protected page.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 * @version 4.0.6
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

/**
 * Post password form.
 *
 * @hooked kalium_show_post_password_form - 10
 */
do_action( 'kalium_post_password_form' );
