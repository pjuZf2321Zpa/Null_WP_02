<?php
/**
 * Kalium WordPress Theme
 *
 * Header wrapper template.
 *
 * @var array $header_classes
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

?>
<header <?php kalium_class_attr( $header_classes ); ?>>

	<?php
	/**
	 * Hook: kalium_header_content.
	 *
	 * @hooked kalium_header_top_bar_display - 10
	 * @hooked kalium_header_content_display - 20
	 * @hooked kalium_header_fullscreen_menu_display - 30
	 */
	do_action( 'kalium_header_content' );
	?>

</header>
