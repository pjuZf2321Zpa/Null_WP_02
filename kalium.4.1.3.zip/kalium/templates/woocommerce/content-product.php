<?php
/**
 * Kalium WordPress Theme
 *
 * Content product template.
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>
<li <?php wc_product_class( '', $product ); ?>>
	
	<?php
	/**
	 * Shop loop item hook.
	 *
	 * @hooked kalium_woocommerce_product_card_display - 10
	 */
	do_action( 'kalium_woocommerce_shop_loop_item' );
	?>

</li>
