<?php
/**
 * Kalium WordPress Theme
 *
 * Product category.
 *
 * @var WP_Term $category
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

?>
<li <?php wc_product_cat_class( '', $category ); ?>>
	<?php
		/**
		 * Show category template.
		 */
		kalium_woocommerce_category_display( $category );
	?>
</li>
