<?php
/**
 * Kalium WordPress Theme
 *
 * Content product list template.
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>
<li <?php wc_product_class( '', $product ); ?>>
	<?php
	/**
	 * Render template contents.
	 */
	laborator_builder_render(
		[
			'content_type'   => 'list_product_loop_card',
			'content_source' => 'list_product_loop_card',
		],
		[
			'parent_selector' => '.product',
		]
	);
	?>
</li>
