<?php
/**
 * Kalium WordPress Theme
 *
 * Product Price element.
 *
 * @var WC_Product $product
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

global $product;

// Display price
if ( $price_html = $product->get_price_html() ) :
	?>
	<span class="price"><?php echo $price_html; ?></span>
	<?php
endif;
