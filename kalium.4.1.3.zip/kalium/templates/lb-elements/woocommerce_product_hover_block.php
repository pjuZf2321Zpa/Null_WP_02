<?php
/**
 * Kalium WordPress Theme
 *
 * Product Hover Block element.
 *
 * @var \Laborator_Builder\Elements\WooCommerce_Product_Hover_Block $element
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

$classes = [
	$element->get_hover_layer_class(),
];

?>
<div <?php kalium_class_attr( $classes ); ?>></div>
