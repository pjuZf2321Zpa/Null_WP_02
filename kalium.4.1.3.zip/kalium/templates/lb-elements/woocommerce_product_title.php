<?php
/**
 * Kalium WordPress Theme
 *
 * Title element.
 *
 * @var bool $link_to_product
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

// Open link
if ( $link_to_product ) {
	woocommerce_template_loop_product_link_open();
}

// Product title
the_title();

// Close link
if ( $link_to_product ) {
	woocommerce_template_loop_product_link_close();
}
