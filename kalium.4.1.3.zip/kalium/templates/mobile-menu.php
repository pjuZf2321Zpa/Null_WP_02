<?php
/**
 * Kalium WordPress Theme
 *
 * Mobile menu template.
 *
 * @var array $classes
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

?>
<div <?php kalium_class_attr( $classes ); ?>>
	<?php
		/**
		 * Mobile menu hook.
		 *
		 * @hooked kalium_mobile_menu_content - 10
		 * @hooked kalium_mobile_menu_close_button_display - 20
		 */
		do_action( 'kalium_mobile_menu' );
	?>
</div>
