<?php
/**
 * Kalium WordPress Theme
 *
 * Portfolio item template.
 *
 * @var array $attributes
 * @var string $type
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

?>
<article <?php kalium_attributes( $attributes ); ?>>

	<?php
	/**
	 * Hook: kalium_portfolio_loop_item.
	 *
	 * @hooked kalium_portfolio_loop_item_type_display - 10
	 */
	do_action( 'kalium_portfolio_loop_item', $type );
	?>

</article>
