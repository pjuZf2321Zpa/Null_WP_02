<?php
/**
 * Kalium WordPress Theme
 *
 * Normal pagination (1,2,3...)
 *
 * @var array $classes
 * @var string $page_numbers
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

?>
<nav <?php kalium_class_attr( $classes ); ?> role="navigation">
	<?php
	/**
	 * Pagination links.
	 */
	echo $page_numbers;
	?>
</nav>
