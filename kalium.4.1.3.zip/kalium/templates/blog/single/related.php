<?php
/**
 * Kalium WordPress Theme
 *
 * Related posts.
 *
 * @var array $classes
 * @var string $title
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

?>
<div <?php kalium_class_attr( $classes ); ?>>
	<div class="container">
		<?php
		// Title
		if ( ! empty( $title ) ) :
			?>
			<h2 class="related-posts__title"><?php echo esc_html( $title ); ?></h2>
			<?php
		endif;

		// Posts loop
		kalium_blog_posts_loop();
		?>
	</div>
</div>
