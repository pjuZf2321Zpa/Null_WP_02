<?php
/**
 * Kalium WordPress Theme
 *
 * Post icon.
 *
 * @var string $icon
 * @var string[] $classes
 * @var string $position_vertical
 * @var string $position_horizontal
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}
?>
<div <?php kalium_class_attr( $classes ); ?> data-valign="<?php echo esc_attr( $position_vertical ); ?>" data-halign="<?php echo esc_attr( $position_horizontal ); ?>">
	<i class="<?php echo esc_attr( $icon ); ?>"></i>
</div>
