<?php
/**
 * Kalium WordPress Theme
 *
 * Footer template.
 *
 * @var array $classes
 *
 * @author  Laborator
 * @link    https://kaliumtheme.com
 * @version 4.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

?>
<footer id="footer" role="contentinfo" <?php kalium_class_attr( $classes ); ?>>
	<?php
		/**
		 * Footer content.
		 *
		 * @hooked kalium_footer_content_display - 10
		 */
		do_action( 'kalium_footer_content' );
	?>
</footer>
