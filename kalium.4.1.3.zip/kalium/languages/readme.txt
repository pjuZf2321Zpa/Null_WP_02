===========================
Kalium Theme Language Files
===========================

Thank you for using the Kalium theme! This directory is where you can store your language files for the theme.

However, it is not recommended to store your files here since this folder will be reset when the theme is updated to a newer version.

For better persistence, you can store your files in the child theme's `languages` folder, or in the main languages folder located at `wp-content/languages`.

===================
About Language Files
===================

This directory contains the `kalium.pot` file, which is used for translating the Kalium theme into different languages.

No additional language files are included here by default, as translations are automatically downloaded from Kalium's remote server.

=======================
Installing Language Files
=======================

To install language files:

1. Set your desired language in the WordPress **Settings** page.
2. Navigate to **Dashboard** -> **Updates**.
3. Click **Update Translations**.

And it's done! Your theme will now use the installed translations.

==========================
Supported Languages & Contributions
==========================

Kalium theme supports a variety of languages, and the list of all supported languages can be found here:

https://translate.kaliumtheme.com/projects/kalium/

We welcome contributions to make the Kalium theme more localizable and better for everyone.