<?php
/**
 * Kalium WordPress Theme
 *
 * Taxonomy template.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

// Portfolio taxonomies
if ( is_tax( kalium()->portfolio->get_taxonomies() ) ) {
	get_template_part( 'archive-portfolio' );
} else { // Other taxonomies
	get_template_part( 'archive' );
}
