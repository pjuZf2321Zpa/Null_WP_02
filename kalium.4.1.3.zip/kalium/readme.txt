=== Kalium ===
Contributors: Laborator
Requires at least: 5.3
Tested up to: 6.6.1
Requires PHP: 7.2
License: GNU General Public License version 3.0
License URI: https://www.gnu.org/licenses/gpl-3.0.htmlw

== Description ==
Create your unique website using the most beautiful WordPress theme of the decade – an award-winning design suitable for any type of website.

== Installation ==
1. Go to Appearance > Themes and click Add New Theme
2. Upload the kalium.zip archive file
3. Click Activate
4. Enter the license key you got from Freemius
5. Start building your dream website