<?php
/**
 * Kalium WordPress Theme
 *
 * Single post template.
 *
 * @author Laborator
 * @link   https://kaliumtheme.com
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

/**
 * Theme header.
 */
get_header();

/**
 * Show post information if exists.
 */
if ( have_posts() ) :

	while ( have_posts() ) :
		the_post();

		/**
		 * Single post content.
		 *
		 * @hooked kalium_blog_single_wrapper_start - 10
		 * @hooked kalium_content_wrapper_main_content_start - 20
		 * @hooked kalium_blog_single_content - 30
		 * @hooked kalium_content_wrapper_main_content_end - 70
		 * @hooked kalium_blog_single_post_sidebar - 80
		 * @hooked kalium_blog_single_wrapper_end - 90
		 * @hooked kalium_blog_single_post_related_posts - 100
		 * @hooked kalium_blog_single_post_comments - 110
		 */
		do_action( 'kalium_blog_single' );

	endwhile;

endif;

/**
 * Theme footer.
 */
get_footer();
