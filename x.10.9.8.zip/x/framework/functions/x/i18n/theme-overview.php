<?php

return array(
  'validation-notice'        => __( 'This license is ​<strong>not validated</strong>​. <a href="%s">Fix</a>', '__x__' ),
  'site-not-validated'       => __('Your license is <strong class="tco-c-nope">not validated</strong>. Place your Envato purchase code or Themeco license to unlock automatic updates, access to support, and Extensions. <a href="https://theme.co/docs/product-validation/" target="_blank">Learn more</a> about product validation or <a href="https://theme.co/account/dashboard/" target="_blank">manage licenses</a> directly in your Themeco account. <a href="https://theme.co/pricing" target="_blank" rel="noopener noreferrer">Upgrade to Pro</a>.', '__x__' ),
  'revoke-validation'        => __( 'By revoking validation, you will no longer receive automatic updates, access to demo content, or the ability to install Extensions. The site will still be linked in your Themeco account, so you can re-validate at anytime.<br/><br/> Visit "Licenses" in your Themeco account to transfer a license to another site.', '__x__' ),
  'separate-license-needed'  => __( 'A separate license is required for each site. Each purchase includes a Cornerstone license.', '__x__' ),
  'how-do-i-unlock'          => __( 'If you have purchased X from ThemeForest already, you can find your purchase code <a href="https://theme.co/app/uploads/images/find-item-purchase-code.png" target="_blank">here</a>. If you do not have a license or need to get another, you can <a href="https://theme.co/go/join.php" target="_blank">purchase</a> one.<br><br>Once you have a purchase code you can <a %s href="#">enter</a> it in the input at the top of this page. <a href="https://theme.co/pricing" target="_blank" rel="noopener noreferrer">Upgrade to Pro</a>.', '__x__' )
);
