<?php

// =============================================================================
// FUNCTIONS/GLOBAL/PLUGINS/ENVIRA-GALLERY.PHP
// -----------------------------------------------------------------------------
// Plugin setup for theme compatibility.
// =============================================================================

// =============================================================================
// TABLE OF CONTENTS
// -----------------------------------------------------------------------------
//   01. Hide License Functionality
// =============================================================================

// Hide License Functionality
// =============================================================================
function x_envira_gallery_hide_licensing_css() {

  return <<<CSS
    #envira-settings-key-box, .envira-notice[data-notice*=warning-license-key],
    .envira-notice[data-notice*=warning-invalid-license-key],
    .envira-notice[data-notice*=warning-license-key],
    #webnus-dashboard.about-wrap .envira-notice[data-notice*=warning-license-key]
    {
      display: none !important;
    }
CSS;

}

function x_envira_admin_enqueue_scripts() {
  wp_register_style('cs-envira-licensing-hide', false);
  wp_add_inline_style('cs-envira-licensing-hide', x_envira_gallery_hide_licensing_css());
  wp_enqueue_style('cs-envira-licensing-hide');
}

add_action( 'admin_enqueue_scripts', 'x_envira_admin_enqueue_scripts' );
