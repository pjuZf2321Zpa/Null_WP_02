<?php

// =============================================================================
// FUNCTIONS/GLOBAL/PLUGINS/MODERN-EVENT-CALENDAR.PHP
// -----------------------------------------------------------------------------
// Plugin setup for theme compatibility.
// =============================================================================

// =============================================================================
// TABLE OF CONTENTS
// -----------------------------------------------------------------------------
//   01. Filter for Removing Support Box
//   02. Partner License Entitlement
// =============================================================================

// Filter For Removing Support Box
// =============================================================================

add_filter( 'mec_dashboard_box_support', '__return_false' );
add_filter( 'mec_dashboard_box_stats', '__return_false' );



// Partner License Entitlement
// =============================================================================
// MEC Pro asks for a partner license instead of a purchase code. We hand it the
// customer's own X validation key along with the site URL we validated against,
// and Webnus verifies both with our API server to server before issuing a token
// to the site. Returning null lets MEC fall back to its purchase code flow.
//
// This must be registered on every request, not just in admin, since the check
// can run from WP-Cron.

function x_mec_partner_site_url() {

  if ( function_exists( 'tco_common' ) && did_action( 'after_setup_theme' ) ) {
    return tco_common()->get_site_url();
  }

  return esc_attr( trailingslashit( network_home_url() ) );

}

function x_mec_partner_license() {

  $key = esc_attr( get_option( 'x_product_validation_key', '' ) );

  if ( empty( $key ) ) {
    return null;
  }

  return array(
    'partner' => 'xtheme',
    'key'     => $key,
    'siteurl' => x_mec_partner_site_url()
  );

}

add_filter( 'mec_partner_license', 'x_mec_partner_license' );
