<?php

// =============================================================================
// LEGACY/SETUP.PHP
// -----------------------------------------------------------------------------
// Sets up the legacy theme views, features, options, et cetera.
// =============================================================================

// =============================================================================
// TABLE OF CONTENTS
// -----------------------------------------------------------------------------
//   01. Cranium Detection
//   02. Legacy Page Templates
// =============================================================================

// Cranium Detection
// =============================================================================

add_action('cs_will_output_header', function() {
  add_filter( 'x_legacy_cranium_headers', '__return_false' );
});

add_action('cs_will_output_footer', function() {
  add_filter( 'x_legacy_cranium_footers', '__return_false' );
});

add_action('cs_will_output_layout', function( $layout ) {

  $layout_settings = $layout->settings();

  if (!$layout_settings['header_enabled']) {
    add_filter( 'x_legacy_cranium_headers', '__return_false');
  }

  if (!$layout_settings['footer_enabled']) {
    add_filter('x_legacy_cranium_footers', '__return_false');
  }

});

function x_legacy_cranium_setup_headers() {
  require_once( X_TEMPLATE_PATH . '/framework/legacy/cranium/headers/setup.php' );
  do_action( 'x_classic_headers' );
}

function x_legacy_cranium_setup_footers() {
  require_once( X_TEMPLATE_PATH . '/framework/legacy/cranium/footers/setup.php' );
  do_action( 'x_classic_footers' );
}

add_filter( 'template_include', function( $template ) { // Run code after template_redirect

  $cranium_headers = apply_filters( 'x_legacy_cranium_headers', true );
  $cranium_footers = apply_filters( 'x_legacy_cranium_footers', true );

  if ( $cranium_headers ) {
    x_legacy_cranium_setup_headers();
  }

  if ( $cranium_footers ) {
    x_legacy_cranium_setup_footers();
  }

  return $template;

}, 99999 );


// The cranium setup files above attach the masthead/footer CSS to 'x_legacy_css'
// (see headers/setup.php and footers/setup.php), but they only load during a full
// page render. The builder regenerates theme options CSS through the 'cs-css'
// endpoint, which answers on template_redirect and dies before template_include
// runs — so x_get_generated_css() fired 'x_legacy_css' with no cranium listeners
// and the refreshed style tag came back without any .masthead / footer rules,
// wiping them from the preview. Load the setup files on demand so any context
// that generates the legacy CSS gets the cranium output too.
function x_legacy_cranium_setup_for_generated_css() {

  if ( apply_filters( 'x_legacy_cranium_headers', true ) && ! function_exists( 'x_legacy_cranium_headers_generated_css' ) ) {
    x_legacy_cranium_setup_headers();
  }

  if ( apply_filters( 'x_legacy_cranium_footers', true ) && ! function_exists( 'x_legacy_cranium_footers_generated_css' ) ) {
    x_legacy_cranium_setup_footers();
  }

}

add_action( 'x_legacy_css', 'x_legacy_cranium_setup_for_generated_css', 1 );



// Legacy Page Templates
// =============================================================================

add_filter( 'cs_output_header', function( $output_header ) {
  $output_header = ! x_is_blank( 3 ) && ! x_is_blank( 6 ) && ! x_is_blank( 7 ) && ! x_is_blank( 8 );
  return $output_header;
} );

add_filter( 'cs_output_footer', function( $output_footer ) {
  $output_footer = ! x_is_blank( 2 ) && ! x_is_blank( 3 ) && ! x_is_blank( 5 ) && ! x_is_blank( 6 );
  return $output_footer;
} );