<?php

// =============================================================================
// WOOCOMMERCE/SINGLE-PRODUCT/TABS/TABS.PHP
// -----------------------------------------------------------------------------
// @version 9.8.0
// =============================================================================

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

$tabs = apply_filters( 'woocommerce_product_tabs', array() );

if ( ! empty( $tabs ) ) :

  $tab_num = count( $tabs );

  switch ( $tab_num ) {
    case '1' :
      $tab_num_class = 'one-up';
      break;
    case '2' :
      $tab_num_class = 'two-up';
      break;
    case '3' :
      $tab_num_class = 'three-up';
      break;
    case '4' :
      $tab_num_class = 'four-up';
      break;
    case '5' :
      $tab_num_class = 'five-up';
      break;
  }

  $tab_keys      = array_keys( $tabs );
  $first_tab_key = $tab_keys[0];

  ?>

  <?php if ( x_get_option( 'x_woocommerce_product_tabs_enable' ) == '1' ) : ?>

    <?php ob_start(); ?>

      [x_tab_nav type="<?php echo $tab_num_class; ?>"]
        <?php foreach ( $tabs as $key => $tab ) : ?>
          <?php $active = ( $key === $first_tab_key ) ? ' active="true"' : ''; ?>
          [x_tab_nav_item<?php echo $active; ?> class="<?php echo esc_attr( $key ); ?>_tab" title="<?php echo apply_filters( 'woocommerce_product_' . $key . '_tab_title', esc_html( $tab['title'] ), $key ); ?>"]
        <?php endforeach; ?>
      [/x_tab_nav]
      [x_tabs]
        <?php foreach ( $tabs as $key => $tab ) : ?>
          <?php $active = ( $key === $first_tab_key ) ? ' active="true"' : ''; ?>
          [x_tab<?php echo $active; ?> class="<?php echo esc_attr( $key ); ?>_pane"]<?php if ( isset( $tab['callback'] ) ) { call_user_func( $tab['callback'], $key, $tab ); } ?>[/x_tab]
        <?php endforeach; ?>
      [/x_tabs]

    <?php $tabs = ob_get_clean(); ?>

    <div class="woocommerce-tabs">
      <?php echo do_shortcode( $tabs ); ?>
      <?php do_action( 'woocommerce_product_after_tabs' ); ?>
    </div>

  <?php endif; ?>

<?php endif; ?>
