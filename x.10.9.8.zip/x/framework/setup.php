<?php

// Versions
// =============================================================================

if ( ! defined( 'X_VERSION' ) ) {
  define( 'X_VERSION', '10.9.8' );
}

if ( ! defined( 'X_CS_VERSION' ) ) {
  define( 'X_CS_VERSION', '7.9.8' );
}


// Theme Constants
// =============================================================================

define( 'X_SLUG', 'x' );
define( 'X_TITLE', 'X' );
define( 'X_I18N_PATH', X_TEMPLATE_PATH . '/framework/functions/x/i18n');


// Legacy Constants - these are no longer utilized in the codebase, but may still be referenced by child themes

define( 'X_LAYERSLIDER_IS_ACTIVE', class_exists( 'LS_Sliders' ) );
define( 'X_REVOLUTION_SLIDER_IS_ACTIVE', class_exists( 'RevSlider' ) || class_exists( 'RevSliderSlider' ) );
define( 'X_WOOCOMMERCE_IS_ACTIVE', class_exists( 'WooCommerce' ) );

// Require Cornerstone
// =============================================================================

function x_require_cornerstone( $tgmpa ) {

  $tgmpa->register( array(
    'name'        => 'Cornerstone',
    'slug'        => 'cornerstone',
    'source'      => X_TEMPLATE_PATH . '/framework/cornerstone.zip',
    'required'    => true,
    'version'     => X_CS_VERSION,
    'is_callable' => 'CS'
  ) );

}

add_action( 'x_tgmpa_register', 'x_require_cornerstone' );

// add_filter( 'cornerstone_default_app_slug', function() {
//   return 'x';
// });


// Environment Setup
// =============================================================================

add_filter( '_cornerstone_app_env', function($env) {
  $env['product'] = 'x';
  $env['title'] = X_TITLE;
  $env['version'] = X_VERSION;
  $env['productKey'] = esc_attr( get_option( 'x_product_validation_key', '' ) );
  $env['siteBuilder'] = false;
  return $env;
} );

add_action( 'after_setup_theme', function() {

  if ( ! function_exists( 'tco_common' ) ) {
    require_once( X_TEMPLATE_PATH . '/framework/functions/x/tco.php' );
  }

  tco_common()->init( array(
    'url' => X_TEMPLATE_URL . '/framework/dist/tco'
  ) );

}, 0);




// Version Body Class
// =============================================================================

if ( ! function_exists( 'x_body_class_version' ) ) :
  function x_body_class_version( $output ) {

    $output[] = 'x-v' . str_replace( '.', '_', X_VERSION );
    return $output;

  }
  add_filter( 'body_class', 'x_body_class_version', 10000 );
endif;



// Overview Page Modules
// =============================================================================

add_action( 'x_overview_init', 'x_validation_modules' );

function x_validation_modules() {

  require_once( X_TEMPLATE_PATH . '/framework/functions/x/validation/class-validation-cornerstone.php' );

  X_Validation_Cornerstone::instance();

}

function x_load_preinit() {
  require_once X_TEMPLATE_PATH . '/framework/functions/x/migration.php';
}

add_action('x_boot_preinit', 'x_load_preinit' );


add_filter( 'x_boot_legacy_includes', function() {
  return include X_TEMPLATE_PATH . '/framework/legacy/includes.php';
} );


// Admin Menu
// =============================================================================

//
// Style admin menu items (Dashboard only)
//

function x_get_admin_menu_css() {
  ob_start(); ?>

  #adminmenu .toplevel_page_x-addons-home .wp-menu-image img {
    width: 20px;
    height: auto;
    padding: 7px 0 0 0;
  }

  <?php return ob_get_clean();
}

add_filter( 'x_admin_menu_css', 'x_get_admin_menu_css' );



function x_admin_menu_logo() {

  // this is already encoded because envato doesn't allow base64_encode
  return "data:image/svg+xml;base64,ICAgIDxzdmcgZmlsbD0iI2E3YWFhZCIgdmlld0JveD0iMCAwIDQwMCA0MDAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICAgIDxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC02MDAuMDAwMDAwLCAwLjAwMDAwMCkiPgogICAgICAgIDxwYXRoIGQ9Ik04MDAsMCBDOTEwLjQ1Njk1LDAgMTAwMCw4OS41NDMwNSAxMDAwLDIwMCBDMTAwMCwzMTAuNDU2OTUgOTEwLjQ1Njk1LDQwMCA4MDAsNDAwIEM2ODkuNTQzMDUsNDAwIDYwMCwzMTAuNDU2OTUgNjAwLDIwMCBDNjAwLDg5LjU0MzA1IDY4OS41NDMwNSwwIDgwMCwwIFogTTgwMCwzMiBDNzA3LjIxNjE2MiwzMiA2MzIsMTA3LjIxNjE2MiA2MzIsMjAwIEM2MzIsMjkyLjc4MzgzOCA3MDcuMjE2MTYyLDM2OCA4MDAsMzY4IEM4OTIuNzgzODM4LDM2OCA5NjgsMjkyLjc4MzgzOCA5NjgsMjAwIEM5NjgsMTA3LjIxNjE2MiA4OTIuNzgzODM4LDMyIDgwMCwzMiBaIE04NzAuNTc0ODQxLDEyOS4xNjczNTggTDg3MC42MDcwMDMsMTI5LjE5OTUxOSBMODcwLjYwNzAwMywxMjkuMTk5NTE5IEM4NzcuMTkzOTI0LDEzNS44MDQwNCA4NzcuMTk0MTA1LDE0Ni40OTMzNzMgODcwLjYwNzQwOSwxNTMuMDk4MTE4IEw4MjMuODY2MDgyLDE5OS45NjcwODIgTDg3MC44MDAwNzUsMjQ2Ljc3MjkwMiBDODc3LjM4MTc5MiwyNTMuMzM2NjMzIDg3Ny4zOTYzNzMsMjYzLjk5MzEyNCA4NzAuODMyNjQyLDI3MC41NzQ4NDEgTDg3MC44MDA0ODEsMjcwLjYwNzAwMyBMODcwLjgwMDQ4MSwyNzAuNjA3MDAzIEM4NjQuMTk1OTYsMjc3LjE5MzkyNCA4NTMuNTA2NjI3LDI3Ny4xOTQxMDUgODQ2LjkwMTg4MiwyNzAuNjA3NDA5IEw4MDAuMDMyMDgyLDIyMy44NjYwODIgTDc1My4yMjcwOTgsMjcwLjgwMDA3NSBDNzQ2LjY2MzM2NywyNzcuMzgxNzkyIDczNi4wMDY4NzYsMjc3LjM5NjM3MyA3MjkuNDI1MTU5LDI3MC44MzI2NDIgQzcyOS40MTQ0MjQsMjcwLjgyMTkzNiA3MjkuNDAzNzAzLDI3MC44MTEyMTYgNzI5LjM5Mjk5NywyNzAuODAwNDgxIEM3MjIuODA2MDc2LDI2NC4xOTU5NiA3MjIuODA1ODk1LDI1My41MDY2MjcgNzI5LjM5MjU5MSwyNDYuOTAxODgyIEw3NzYuMTMzMDgyLDIwMC4wMzIwODIgTDcyOS4xOTk5MjUsMTUzLjIyNzA5OCBDNzIyLjYxODIwOCwxNDYuNjYzMzY3IDcyMi42MDM2MjcsMTM2LjAwNjg3NiA3MjkuMTY3MzU4LDEyOS40MjUxNTkgQzcyOS4xNzgwNjQsMTI5LjQxNDQyNCA3MjkuMTg4Nzg0LDEyOS40MDM3MDMgNzI5LjE5OTUxOSwxMjkuMzkyOTk3IEM3MzUuODA0MDQsMTIyLjgwNjA3NiA3NDYuNDkzMzczLDEyMi44MDU4OTUgNzUzLjA5ODExOCwxMjkuMzkyNTkxIEw3OTkuOTY3MDgyLDE3Ni4xMzMwODIgTDg0Ni43NzI5MDIsMTI5LjE5OTkyNSBDODUzLjMzNjYzMywxMjIuNjE4MjA4IDg2My45OTMxMjQsMTIyLjYwMzYyNyA4NzAuNTc0ODQxLDEyOS4xNjczNTggWiIgaWQ9IlgtKE91dGxpbmVkKSI+PC9wYXRoPgogICAgICA8L2c+CiAgICA8L3N2Zz4KICA=";

}

function x_admin_menu() {
  $title = __( 'Validation', '__x__' );
  add_menu_page( $title, X_TITLE, 'manage_options', 'x-addons-home', 'x_addons_page_home', 'data:image/svg+xml;base64,' . x_admin_menu_logo(), 3 );
  add_submenu_page( 'x-addons-home', $title, $title, 'manage_options', 'x-addons-home', 'x_addons_page_home' );
}

add_action( 'admin_menu', 'x_admin_menu', 5 );


add_theme_support( 'cornerstone' );
add_theme_support( 'cornerstone-managed', [ 'handle' => 'x-theme' ] );
