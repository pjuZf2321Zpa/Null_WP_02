<?php

// Custom full width

get_header();

?>

  <div class="x-container max width offset">
    <div id="x-main" class="<?php x_main_content_class(); ?>" role="main" tabindex="-1">

      <?php while ( have_posts() ) : the_post(); ?>
        <?php x_get_view( 'custom', 'content', 'page' ); ?>
        <?php x_get_view( 'global', '_comments-template' ); ?>
      <?php endwhile; ?>

    </div>
  </div>

<?php get_footer(); ?>
