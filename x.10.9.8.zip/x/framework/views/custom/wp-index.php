<?php

// Index page output for Custom

get_header();

?>

  <div class="x-container max width offset">
    <div id="x-main" class="<?php x_main_content_class(); ?>" role="main" tabindex="-1">

      <?php x_get_view( 'global', '_index' ); ?>

    </div>

    <?php get_sidebar(); ?>

  </div>

<?php get_footer(); ?>
