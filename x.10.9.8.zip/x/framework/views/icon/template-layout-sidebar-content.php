<?php

// =============================================================================
// VIEWS/ICON/TEMPLATE-LAYOUT-SIDEBAR-CONTENT.PHP
// -----------------------------------------------------------------------------
// Sidebar left, content right page output for Icon (not active in this Stack).
// =============================================================================

x_get_view( 'global', '_header' );

?>

  <div id="x-main" class="x-main full" role="main" tabindex="-1">
    <article id="post-0" class="post-0 page type-page status-publish hentry">
      <div class="entry-wrap">
        <div class="x-container max width">
          <h1 class="entry-title">Hey There</h1>
          <p class="center-text mtl">Because of Icon's unique layout, this template is unavailable in this Stack. Please switch to another Stack if you need to make use of this feature. Thanks!</p>
        </div>
      </div>
    </article>
  </div>

<?php x_get_view( 'global', '_footer' ); ?>
