<?php

// =============================================================================
// VIEWS/ICON/TEMPLATE-LAYOUT-PORTFOLIO.PHP
// -----------------------------------------------------------------------------
// Portfolio page output for Icon.
// =============================================================================

get_header();

?>

  <div id="x-main" class="x-main full" role="main" tabindex="-1">
    <div class="x-container offset-bottom">

      <?php x_portfolio_filters(); ?>
      <?php x_get_view( 'global', '_portfolio' ); ?>

    </div>
  </div>

  <?php get_sidebar(); ?>
<?php get_footer(); ?>
