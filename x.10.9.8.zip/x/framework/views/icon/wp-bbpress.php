<?php

// =============================================================================
// VIEWS/ICON/WP-BBPRESS.PHP
// -----------------------------------------------------------------------------
// bbPress output for Icon.
// =============================================================================

get_header();

?>

  <div id="x-main" class="x-main full" role="main" tabindex="-1">

    <?php while ( have_posts() ) : the_post(); ?>
      <?php x_get_view( 'global', '_content', 'bbpress' ); ?>
    <?php endwhile; ?>

  </div>

  <?php get_sidebar(); ?>
<?php get_footer(); ?>
