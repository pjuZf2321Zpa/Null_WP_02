<?php

// =============================================================================
// VIEWS/INTEGRITY/WP-BBPRESS.PHP
// -----------------------------------------------------------------------------
// bbPress output for Integrity.
// =============================================================================

get_header();

?>

  <div class="x-container max width offset">
    <div id="x-main" class="<?php x_main_content_class(); ?>" role="main" tabindex="-1">

      <?php while ( have_posts() ) : the_post(); ?>
        <?php x_get_view( 'global', '_content', 'bbpress' ); ?>
      <?php endwhile; ?>

    </div>

    <?php get_sidebar(); ?>

  </div>

<?php get_footer(); ?>
