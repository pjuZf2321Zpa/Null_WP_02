<?php
/** Don't load directly */
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Foxiz_Ajax', false ) ) {
	class Foxiz_Ajax {

		/** Where the notification payload is cached; the invalidation below must agree with the reader. */
		const NOTIFICATION_CACHE = 'foxiz_notification_cache';

		/** Ceiling for a site that publishes nothing: the markup carries rendered relative times. */
		const NOTIFICATION_TTL = HOUR_IN_SECONDS;

		private static $instance;
		public $style = '';

		public static function get_instance() {

			if ( null === self::$instance ) {
				return new self();
			}

			return self::$instance;
		}

		public function __construct() {

			self::$instance = $this;
			add_action( 'init', [ $this, 'register_endpoint' ], 10 );
			add_action( 'template_redirect', [ $this, 'endpoint_redirect' ] );

			add_action( 'wp_ajax_nopriv_rblivep', [ $this, 'pagination' ] );
			add_action( 'wp_ajax_rblivep', [ $this, 'pagination' ] );
			add_action( 'wp_ajax_nopriv_rbsearch', [ $this, 'live_search' ] );
			add_action( 'wp_ajax_rbsearch', [ $this, 'live_search' ] );
			add_action( 'wp_ajax_nopriv_rbpersonalizeb', [ $this, 'personalize_block' ] );
			add_action( 'wp_ajax_rbpersonalizeb', [ $this, 'personalize_block' ] );
			add_action( 'wp_ajax_nopriv_rbpersonalizecat', [ $this, 'personalize_categories' ] );
			add_action( 'wp_ajax_rbpersonalizecat', [ $this, 'personalize_categories' ] );
			add_action( 'wp_ajax_nopriv_rbnotification', [ $this, 'notification' ] );
			add_action( 'wp_ajax_rbnotification', [ $this, 'notification' ] );
			add_action( 'wp_ajax_nopriv_rbvoting', [ $this, 'voting' ] );
			add_action( 'wp_ajax_rbvoting', [ $this, 'voting' ] );

			/**
			 * Invalidation lives beside the code that fills the cache: backend/hooks.php loads only
			 * in the admin, so WP-Cron, REST and WP-CLI publishes never cleared it.
			 */
			add_action( 'transition_post_status', [ $this, 'flush_notification_cache' ], 10, 3 );
			add_action( 'before_delete_post', [ $this, 'flush_notification_cache_on_delete' ] );

			/** The list's time window and markup come from Theme Options. */
			add_action( 'update_option_' . FOXIZ_TOS_ID, [ $this, 'flush_notification_cache_on_options' ] );
		}

		/**
		 * Drop the notification payload when a post enters or leaves publish.
		 *
		 * @param string       $new_status Status being moved to.
		 * @param string       $old_status Status being moved from.
		 * @param WP_Post|null $post       Post being moved.
		 *
		 * @return void
		 */
		public function flush_notification_cache( $new_status, $old_status, $post = null ) {

			if ( ! $post instanceof WP_Post || 'post' !== $post->post_type ) {
				return;
			}

			if ( 'publish' !== $new_status && 'publish' !== $old_status ) {
				return;
			}

			delete_transient( self::NOTIFICATION_CACHE );
		}

		/**
		 * @param int $post_id Post about to be deleted.
		 *
		 * @return void
		 */
		public function flush_notification_cache_on_delete( $post_id ) {

			$post = get_post( $post_id );

			if ( ! $post instanceof WP_Post || 'post' !== $post->post_type ) {
				return;
			}

			/* Only a published post can be in the list; a trashed one left it on its status transition. */
			if ( 'publish' !== $post->post_status ) {
				return;
			}

			delete_transient( self::NOTIFICATION_CACHE );
		}

		/**
		 * Drop the notification payload when Theme Options are saved.
		 *
		 * @return void
		 */
		public function flush_notification_cache_on_options() {

			delete_transient( self::NOTIFICATION_CACHE );
		}

		public function pagination() {

			if ( function_exists( 'foxiz_check_rate_limit' ) ) {
				foxiz_check_rate_limit( 'pagination', 'read' );
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public AJAX endpoint
			$data = isset( $_GET['data'] ) ? wp_unslash( $_GET['data'] ) : [];

			if ( empty( $data ) || empty( $data['name'] ) ) {
				wp_send_json( '' );
			}

			$settings = $this->validate( $data );

			$settings['no_found_rows'] = false;
			$settings['feat_lazyload'] = 'none';
			$paged                     = 2;

			if ( isset( $settings['page_next'] ) ) {
				$paged = absint( $settings['page_next'] );
			}
			if ( empty( $settings['posts_per_page'] ) ) {
				$settings['posts_per_page'] = get_option( 'posts_per_page' );
			}

			/** ajax for custom query */
			if ( ! empty( $settings['content_source'] ) ) {
				switch ( $settings['content_source'] ) {
					case 'related':
						$_query = foxiz_query_related( $settings, $paged );
						break;
					/**
					 * The three reader sources go through foxiz_personalize_query()
					 * rather than being dispatched again here. Repeating the
					 * dispatch is how this path came to miss the guest check that
					 * the renderers apply, letting a restricted visitor page past
					 * a first page they had been refused.
					 */
					case 'recommended':
					case 'saved':
					case 'history':
						$settings['paged'] = $paged;
						$_query            = foxiz_personalize_query( $settings );
						break;
				}
			} else {
				$_query = foxiz_query( $settings, $paged );
			}

			$response = [];

			if ( ! empty( $_query ) && $_query->have_posts() ) {
				if ( ! empty( $_query->paged ) ) {
					$response['paged'] = $_query->paged;
				} else {
					$response['paged'] = $paged;
				}
				if ( $response['paged'] >= ( isset( $settings['page_max'] ) ? (int) $settings['page_max'] : 0 ) ) {
					$response['notice'] = $this->end_list_info();
				}
				$response['content'] = $this->render( $settings, $_query );
				wp_reset_postdata();
			} else {
				$response['paged']   = ( isset( $settings['page_max'] ) ? (int) $settings['page_max'] : 0 ) + 99;
				$response['content'] = $this->end_list_info();
			}

			wp_send_json( $response );
		}

		/**
		 * @param $settings
		 *
		 * @return array|mixed|string
		 * validate input
		 */
		public function validate( $settings ) {

			if ( is_array( $settings ) ) {
				$sanitized = [];

				foreach ( $settings as $key => $value ) {
					$clean_key               = sanitize_key( $key );
					$sanitized[ $clean_key ] = $this->validate( $value );
				}

				return $this->sanitize_query_params( $sanitized );

			} elseif ( is_string( $settings ) ) {
				return foxiz_strip_tags( stripslashes( $settings ) );
			}

			return '';
		}

		/**
		 * Sanitize and cap query parameters to prevent abuse.
		 *
		 * @param array $settings The settings array.
		 *
		 * @return array Sanitized settings with capped values.
		 */
		public function sanitize_query_params( $settings ) {

			// Whitelist allowed content_source values.
			$allowed_sources = [ 'saved', 'history', 'recommended', 'related', '' ];
			if ( isset( $settings['content_source'] ) && ! in_array( $settings['content_source'], $allowed_sources, true ) ) {
				$settings['content_source'] = '';
			}

			return $settings;
		}

		/**
		 * @param $settings
		 * @param $_query
		 *
		 * @return false|string
		 * render
		 */
		public function render( $settings, $_query ) {

			// Allowlist of valid loop function suffixes
			$allowed_loops = [
				'grid_1',
				'grid_2',
				'grid_box_1',
				'grid_box_2',
				'grid_flex_1',
				'grid_flex_2',
				'grid_small_1',
				'grid_personalize_1',
				'grid_personalize_2',
				'list_1',
				'list_2',
				'list_flex',
				'list_box_1',
				'list_box_2',
				'list_small_1',
				'list_small_2',
				'list_small_3',
				'list_personalize',
				'overlay_1',
				'overlay_2',
				'overlay_flex',
				'overlay_personalize',
				'classic_1',
				'hierarchical_1',
				'hierarchical_2',
				'hierarchical_3',
				'breaking_news',
				'podcast_list_flex_1',
				'podcast_grid_flex_1',
				'podcast_overlay_flex_1',
			];

			$name = isset( $settings['name'] ) ? sanitize_key( $settings['name'] ) : '';

			if ( empty( $name ) || ! in_array( $name, $allowed_loops, true ) ) {
				return '';
			}

			ob_start();
			$func = 'foxiz_loop_' . $name;

			if ( function_exists( $func ) ) {
				call_user_func_array( $func, [ $settings, $_query ] );
			}

			return ob_get_clean();
		}

		/**
		 * @return string
		 * end list info
		 */
		public function end_list_info() {

			$output  = '<div class="p-wrap end-list-info is-meta"><i class="rbi rbi-chart" aria-hidden="true"></i><span>';
			$output .= foxiz_html__( 'You\'ve reached the end of the list!', 'foxiz' );
			$output .= '</span></div>';

			return $output;
		}

		public function register_endpoint() {
			add_rewrite_endpoint( 'rbsnp', EP_PERMALINK );
			add_rewrite_endpoint( 'rblive', EP_PERMALINK );
		}

		public function endpoint_redirect() {

			if ( ! is_singular( 'post' ) ) {
				return;
			}

			if ( get_query_var( 'rbsnp' ) ) {
				$this->handle_next_posts_endpoint();
			} elseif ( get_query_var( 'rblive' ) ) {
				$this->handle_live_endpoint();
			}
		}

		/**
		 * Handle AJAX next posts endpoint
		 */
		private function handle_next_posts_endpoint() {

			if ( ! foxiz_get_single_setting( 'ajax_next_post' ) ) {
				return;
			}

			$GLOBALS['foxiz_rbsnp'] = true;
			$file                   = '/templates/single/next-posts.php';
			$template               = locate_template( $file );

			if ( $template ) {
				include $template;
			}
			exit;
		}

		/**
		 * Handle live blog endpoint
		 */
		private function handle_live_endpoint() {

			if ( ! function_exists( 'foxiz_is_live_blog' ) || ! foxiz_is_live_blog() ) {
				return;
			}

			$post_id = get_queried_object_id();

			/* The fragment is cached once per post and served to every visitor, so it must never be
			   built for, or handed to, a request that has not unlocked the post. A preview poll renders
			   the unsaved autosave, so only someone who can edit the post may get it. */
			if ( post_password_required( $post_id ) || ( is_preview() && ! current_user_can( 'edit_post', $post_id ) ) ) {
				status_header( 403 );
				nocache_headers();
				exit;
			}

			$file     = '/templates/single/live.php';
			$template = locate_template( $file );

			if ( $template ) {
				include $template;
			}
			exit;
		}

		/** live search */
		public function live_search() {

			if ( function_exists( 'foxiz_check_rate_limit' ) ) {
				foxiz_check_rate_limit( 'search', 'read' );
			}

			// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public search endpoint
			$search_term = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';

			if ( empty( $search_term ) ) {
				wp_send_json( '' );
			}

			$search_type = isset( $_GET['search'] ) ? sanitize_key( $_GET['search'] ) : 'category';
			$limit       = isset( $_GET['limit'] ) ? absint( $_GET['limit'] ) : 4;
			$post_type   = isset( $_GET['ptype'] ) ? sanitize_text_field( wp_unslash( $_GET['ptype'] ) ) : '';
			$follow      = ! empty( $_GET['follow'] ) ? 1 : 0;
			$desc_source = isset( $_GET['dsource'] ) ? sanitize_text_field( wp_unslash( $_GET['dsource'] ) ) : '';
			$tax         = isset( $_GET['tax'] ) ? sanitize_text_field( wp_unslash( $_GET['tax'] ) ) : '';

			if ( 'category' === $search_type ) {
				wp_send_json( $this->search_categories( $search_term, $limit, $follow, $desc_source, $tax ) );
			} else {
				wp_send_json( $this->search_posts( $search_term, $limit, $post_type ) );
			}
		}

		public function search_posts( $input = '', $limit = 4, $post_type = '' ) {

			if ( empty( $input ) ) {
				return '';
			}

			$limit = ! empty( $limit ) ? $limit : foxiz_get_option( 'ajax_search_limit', 4 );

			if ( $limit > 10 ) {
				$limit = 10;
			}

			$params = [
				's'              => $input,
				'posts_per_page' => intval( $limit ),
				'post_status'    => 'publish',
			];

			/**
			 * Two lists, because the request and the site have different standing.
			 *
			 * $default is what a request naming nothing gets: the site's own choice,
			 * or every type WordPress considers searchable. $ceiling is as far as a
			 * request may reach, the union of the two, so an admin who opted a type in
			 * keeps it while a type the site never offered stays out of reach.
			 *
			 * The request used to replace this list rather than narrow it, which let a
			 * visitor read post types the site had marked exclude_from_search:
			 * reusable blocks, menu items, global styles, and whatever private records
			 * a plugin keeps as a post type.
			 */
			$searchable = array_values( get_post_types( [ 'exclude_from_search' => false ] ) );
			$configured = array_filter( array_map( 'trim', explode( ',', wp_strip_all_tags( (string) foxiz_get_option( 'search_post_types' ) ) ) ) );

			$default = $configured ? $configured : $searchable;
			$ceiling = array_unique( array_merge( $searchable, $configured ) );

			$disallowed = array_filter( array_map( 'trim', explode( ',', (string) foxiz_get_option( 'search_type_disallow' ) ) ) );

			if ( $disallowed ) {
				$default = array_diff( $default, $disallowed );
				$ceiling = array_diff( $ceiling, $disallowed );
			}

			if ( empty( $post_type ) ) {
				$post_type = $default;
			} else {
				$post_type = array_intersect(
					array_filter( array_map( 'trim', explode( ',', (string) $post_type ) ) ),
					$ceiling
				);
			}

			/**
			 * Nothing left to search means no results. An empty post_type array makes
			 * WP_Query fall back to 'post', answering a question nobody asked.
			 */
			if ( empty( $post_type ) ) {
				return '<div class="block-inner live-search-inner p-middle"><div class="search-no-result">'
					. foxiz_html__( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'foxiz' )
					. '</div></div>';
			}

			$params['post_type'] = array_values( $post_type );
			$_query              = new WP_Query( $params );

			$response = '<div class="block-inner live-search-inner p-middle">';
			if ( $_query->have_posts() ) {
				ob_start();
				while ( $_query->have_posts() ) :
					$_query->the_post();
					foxiz_list_small_2(
						[
							'featured_position' => 'left',
							'entry_meta'        => [ 'update', 'index' ],
							'title_index'       => '1',
							'title_tag'         => 'div',
							'title_classes'     => 'h5',
							'middle_mode'       => '1',
							'edit_link'         => false,
						]
					);
				endwhile;
				$response .= ob_get_clean();
				$response .= '<div class="live-search-link"><a class="is-btn" href="' . esc_url( get_search_link( $input ) ) . '">' . foxiz_html__( 'More Results', 'foxiz' ) . '</a></div>';
			} else {
				$response .= '<div class="search-no-result">' . foxiz_html__( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'foxiz' ) . '</div>';
			}

			$response .= '</div>';

			return $response;
		}

		public function search_categories( $input = '', $limit = 4, $follow = 0, $desc_source = '', $tax = '' ) {

			if ( empty( $input ) ) {
				return '';
			}

			if ( $limit > 6 ) {
				$limit = 6;
			}

			$params = [
				'search'     => $input,
				'number'     => $limit,
				'hide_empty' => true,
			];

			if ( '' !== $tax ) {
				/**
				 * Public taxonomies only, named explicitly even for 'all'.
				 *
				 * taxonomy_exists() was the wrong test: it is true for nav_menu, wp_theme
				 * and every private taxonomy a plugin registers, so a visitor could list
				 * menu names and template categories through a search box. Leaving 'all'
				 * unfiltered was the same hole with no argument to type.
				 *
				 * Naming them also keeps get_terms() from returning a WP_Error, whose
				 * ->term_id the loop below would read, printing a warning into the body
				 * the client injects into the page.
				 */
				$public = array_values( get_taxonomies( [ 'public' => true ] ) );

				$wanted = 'all' === $tax
					? $public
					: array_values( array_intersect( array_filter( array_map( 'trim', explode( ',', $tax ) ) ), $public ) );

				/** Asking for taxonomies out of reach returns nothing, not everything. */
				if ( ! $wanted ) {
					return '<div class="block-inner live-search-inner"><div class="search-no-result">'
						. foxiz_html__( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'foxiz' )
						. '</div></div>';
				}

				$params['taxonomy'] = $wanted;
			} else {
				$params['taxonomy'] = [ 'category' ];
			}

			$taxonomies = get_terms( $params );

			if ( is_wp_error( $taxonomies ) || ! is_array( $taxonomies ) ) {
				$taxonomies = [];
			}
			$response = '<div class="block-inner live-search-inner">';
			if ( ! empty( $taxonomies ) ) {
				ob_start();
				foreach ( $taxonomies as $category ) {
					foxiz_category_item_search(
						[
							'cid'         => $category->term_id,
							'follow'      => $follow,
							'count_posts' => 1,
							'desc_source' => $desc_source,
						]
					);
				}
				$response .= ob_get_clean();
			} else {
				$response .= '<div class="search-no-result">' . foxiz_html__( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'foxiz' ) . '</div>';
			}
			$response .= '</div>';

			return $response;
		}

		public function personalize_block() {

			if ( function_exists( 'foxiz_check_rate_limit' ) ) {
				foxiz_check_rate_limit( 'personalize_block', 'read' );
			}

			if ( empty( $_GET['data'] ) || empty( $_GET['data']['name'] ) ) {
				wp_send_json( '' );
				wp_die();
			}

			$settings = $this->validate( $_GET['data'] );

			/** validate() preserves a nested array under 'name'; trim() on it fatals. Require a string. */
			if ( empty( $settings['name'] ) || ! is_string( $settings['name'] ) ) {
				wp_send_json( '' );
				wp_die();
			}

			if ( ! empty( $settings['content_source'] ) ) {
				$_query = foxiz_personalize_query( $settings );
			} else {
				$_query = foxiz_query( $settings );
			}

			$func = 'foxiz_live_block_' . trim( $settings['name'] );

			ob_start();
			if ( function_exists( $func ) ) {
				call_user_func_array( $func, [ $settings, $_query ] );
			}

			wp_send_json( ob_get_clean() );
		}

		public function personalize_categories() {

			if ( function_exists( 'foxiz_check_rate_limit' ) ) {
				foxiz_check_rate_limit( 'personalize_cat', 'read' );
			}

			if ( empty( $_GET['data'] ) || empty( $_GET['data']['name'] ) ) {
				wp_send_json( '' );
				wp_die();
			}

			$settings = $this->validate( $_GET['data'] );

			/** validate() preserves a nested array under 'name'; trim() on it fatals. Require a string. */
			if ( empty( $settings['name'] ) || ! is_string( $settings['name'] ) ) {
				wp_send_json( '' );
				wp_die();
			}

			$func = 'foxiz_live_get_' . trim( $settings['name'] );

			ob_start();
			if ( function_exists( $func ) ) {
				call_user_func_array( $func, [ $settings ] );
			}
			wp_send_json( ob_get_clean() );
		}

		/** get notification */
		public function notification() {

			if ( function_exists( 'foxiz_check_rate_limit' ) ) {
				foxiz_check_rate_limit( 'notification', 'read' );
			}

			$cache_key = self::NOTIFICATION_CACHE;
			$response  = get_transient( $cache_key );

			// Return cached response if available
			if ( false !== $response ) {
				wp_send_json( $response );
			}

			$response = [
				'content' => '',
				'count'   => '',
				'ids'     => '',
			];

			$duration = (int) foxiz_get_option( 'notification_duration' );
			if ( $duration < 1 ) {
				$duration = 72;
			}
			$db_after = $duration . ' hours ago';
			$_query   = new WP_Query(
				[
					'post_type'      => 'post',
					'no_found_rows'  => true,
					'post_status'    => 'publish',
					'order'          => 'DESC',
					'posts_per_page' => 9,
					'date_query'     => [
						[ 'after' => $db_after ],
					],
				]
			);

			ob_start();
			if ( $_query->have_posts() ) :
				$response['count'] = $_query->post_count;
				$post_ids          = wp_list_pluck( $_query->posts, 'ID' );
				$response['ids']   = implode( ',', $post_ids ); ?>
				<div class="block-inner">
					<?php
					foxiz_loop_list_small_2(
						[
							'design_override'  => true,
							'title_tag'        => 'div',
							'title_classes'    => 'h5',
							'edit_link'        => false,
							'bookmark'         => false,
							'entry_category'   => true,
							'human_time'       => true,
							'featured_classes' => 'ratio-v2',
							'entry_meta'       => [ 'update' ],
						],
						$_query
					);
					?>
				</div>
				<?php
			endif;
			$response['content'] = ob_get_clean();

			wp_reset_postdata();

			if ( empty( $response['content'] ) ) {
				$response['content'] = '<span class="is-meta empty-notification">' . foxiz_html__( 'Stay Tuned! Check back later for the latest updates.', 'foxiz' ) . '</span>';
			}

			set_transient( $cache_key, $response, self::NOTIFICATION_TTL );

			wp_send_json( $response );
		}

		public function voting() {

			if ( function_exists( 'foxiz_check_rate_limit' ) ) {
				foxiz_check_rate_limit( 'voting', 'write' );
			}

			// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public AJAX endpoint
			$post_id  = isset( $_GET['pid'] ) ? absint( $_GET['pid'] ) : 0;
			$reaction = isset( $_GET['value'] ) ? sanitize_key( wp_unslash( $_GET['value'] ) ) : '';
			// phpcs:enable

			if ( empty( $post_id ) || empty( $reaction ) || ! class_exists( 'Foxiz_Personalize_Helper' ) ) {
				wp_send_json_error();
			}

			/**
			 * Validate post exists.
			 *
			 * increase_votes() writes through update_post_meta(), which does not
			 * check that the post is real, so an unchecked id left an orphan row
			 * in wp_postmeta as well as one in rb_personalize.
			 */
			if ( ! get_post( $post_id ) ) {
				wp_send_json_error();
			}

			switch ( $reaction ) {
				case 'like':
					Foxiz_Personalize_Helper::get_instance()->save_vote( 'like', $post_id );
					break;
				case 'dislike':
					Foxiz_Personalize_Helper::get_instance()->save_vote( 'dislike', $post_id );
					break;
				case 'rmlike':
					Foxiz_Personalize_Helper::get_instance()->delete_vote( 'like', $post_id );
					break;
				case 'rmdislike':
					Foxiz_Personalize_Helper::get_instance()->delete_vote( 'dislike', $post_id );
					break;
			}

			wp_send_json_success( $post_id );
		}
	}
}

/** load */
Foxiz_Ajax::get_instance();
