=== Foxiz ===
Contributors: themeruby
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.8.0
License: Themeforest Licence
License URI: https://themeforest.net/licenses/standard
Tags: custom-background, custom-menu, featured-images, theme-options, custom-colors, translation-ready, threaded-comments

Foxiz is a mobile-first, fast and complete publishing solution for WordPress news, magazine and newspaper sites.

== Description ==

This is **Foxiz**, the edition sold on ThemeForest.

Mobile-first by design, ready for Core Web Vitals, and built with over 1000 options so you can create any imaginable website without writing code. It is the perfect choice for professional publishers.

Highlights: front-end drag and drop builder, Ruby Templates, header and footer builders, dark mode, bookmark system, membership and paywall, podcast support, Web Stories, WooCommerce, bbPress forums, AdSense and custom ads, AMP support, and SEO optimization.

Foxiz Core, the companion plugin bundled with the theme, provides the blocks, widgets and admin tools. Install it when the theme prompts you.

Theme home: https://foxiz.io/
Documentation: https://help.themeruby.com/foxiz/
Support: https://ruby.ticksy.com/
Author: https://themeruby.com/

== Changelog ==

= 2.8.0 =
* Released: October 19, 2026

* Improved security hardening.
* Fixed the header notification list missing new posts and showing outdated times.
* Fixed styling issues on archive, author, Reading List and single post pages, and the Custom Social 1-3 colors.
* Fixed table fonts in the block editor.
* Fixed help text in Theme Options, Elementor blocks, the demo importer and the post, page, category and podcast settings, including the Rate Limits description.
* Many other improvements and bug fixes.
* Note: after updating, save Theme Options once so the corrected styles are applied.

= 2.7.9 =
* Released: September 13, 2026

* Fixed Mobile Layout not applying to post listing blocks.

= 2.7.8 =
* Released: September 12, 2026

* Improved security hardening.
* Fixed Elementor widgets inside Ruby templates losing their styles on the front end.
* Fixed the podcast player notices flooding the debug log in the Elementor editor.
* Fixed Instagram, Flickr and weather widgets breaking the front end.
* Fixed a fatal error in Theme Options when a typography font size is set to 0.
* Fixed page and category headers serving full-size images instead of the 2048x2048 crop and losing alt text.
* Fixed ad spots losing their wrapper classes, AdSense parsing warnings, and podcast social rows dropping valid entries.
* Fixed Google Fonts not applying non-Latin subsets.
* Fixed invalid image values in search and review structured data.
* Fixed the audio-embed block missing its wrapper class.
* Fixed the podcast RSS feed breaking on special characters.
* Fixed PHP notices on WooCommerce product tag and search archives.
* Fixed term colour CSS not regenerating when a term is created.
* Other improvements and bug fixes.

== Copyright ==

Foxiz WordPress Theme, (C) 2022-2026 ThemeRuby.
Foxiz is commercial software sold on ThemeForest and licensed per site under the
ThemeForest licence: https://themeforest.net/licenses/standard

Images used in the theme screenshot and demo content are licensed for
demonstration only and are not redistributed with the theme.
