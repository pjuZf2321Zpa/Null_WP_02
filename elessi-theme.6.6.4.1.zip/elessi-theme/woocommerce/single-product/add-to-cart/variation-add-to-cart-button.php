<?php
/**
 * Single variation cart button
 *
 * @author  NasaTheme
 * @package Elessi-theme/WooCommerce
 * @version 10.5.2
 */

defined('ABSPATH') || exit;

global $nasa_opt, $product;
?>

<div class="woocommerce-variation-add-to-cart variations_button">
    <?php
    do_action('woocommerce_before_add_to_cart_button');
    
    do_action('woocommerce_before_add_to_cart_quantity');

    if (!isset($nasa_opt['disable-cart']) || !$nasa_opt['disable-cart']) :
        woocommerce_quantity_input(array(
            'min_value'   => $product->get_min_purchase_quantity(),
            'max_value'   => $product->get_max_purchase_quantity(),
            'input_value' => isset($_POST['quantity']) ? wc_stock_amount(wp_unslash($_POST['quantity'])) : $product->get_min_purchase_quantity(),
        ));
    endif;

    do_action('woocommerce_after_add_to_cart_quantity');

    if (!isset($nasa_opt['disable-cart']) || !$nasa_opt['disable-cart']) :
        ?>
        <button type="submit" class="ns-single-add-btn single_add_to_cart_button button alt<?php echo esc_attr(wc_wp_theme_get_element_class_name('button') ? ' ' . wc_wp_theme_get_element_class_name('button') : ''); ?>">
            <?php echo esc_html($product->single_add_to_cart_text()); ?>
        </button>
        
        <input type="hidden" name="add-to-cart" value="<?php echo absint($product->get_id()); ?>" />
        <input type="hidden" name="product_id" value="<?php echo absint($product->get_id()); ?>" />
        <input type="hidden" name="variation_id" class="variation_id" value="0" />
        <?php
    endif;

    do_action('woocommerce_after_add_to_cart_button');
    ?>
</div>
