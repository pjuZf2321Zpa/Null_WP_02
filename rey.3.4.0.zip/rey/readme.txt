=== Rey ===
Contributors: reytheme
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 5.4
Stable tag: 3.4.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl.html
Tags: blog, two-columns, left-sidebar, custom-menu, featured-images, footer-widgets, theme-options, threaded-comments, translation-ready, e-commerce

One of the classiest and rich-featured themes on the market.

== Description ==

Rey is a feature-rich, performance-focused WordPress theme built for WooCommerce stores and content websites. It provides a header and footer builder, deep Elementor integration, and an extensive set of theme options. Most of the advanced functionality is delivered through the companion Rey Core plugin.

== Installation ==

1. In your WordPress admin, go to Appearance > Themes > Add New > Upload Theme.
2. Upload the theme .zip file and click Install Now.
3. Activate the theme and follow the setup wizard to install the required Rey Core plugin.

== Changelog ==

= 3.1.11 =
* Current stable release.
