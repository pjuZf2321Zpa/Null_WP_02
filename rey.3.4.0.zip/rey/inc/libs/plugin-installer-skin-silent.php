<?php
namespace Rey\Libs;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

if ( ! class_exists( '\Plugin_Upgrader', false ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
}

/**
 * WordPress class extended for on-the-fly plugin installations.
 */
class PluginInstallerSkinSilent extends \WP_Upgrader_Skin {

	/**
	 * Our own error store.
	 *
	 * The base WP_Upgrader_Skin does NOT expose an $errors property across all
	 * WP versions, so we keep our own and never touch the parent's internals.
	 *
	 * @var \WP_Error
	 */
	private $rey_errors;

	public function __construct( $args = [] ) {

		if ( ! function_exists( 'request_filesystem_credentials' ) ) {
			require_once( ABSPATH . 'wp-admin/includes/file.php' );
		}

		$this->rey_errors = new \WP_Error();

		parent::__construct($args);
	}

	/**
	 * Empty out the header of its HTML content.
	 */
	public function header() {}

	/**
	 * Empty out the footer of its HTML content.
	 */
	public function footer() {}

	/**
	 * Empty out the footer of its HTML content.
	 *
	 * @param string $string
	 * @param mixed  ...$args Optional text replacements.
	 */
	public function feedback( $string, ...$args ) {}

	/**
	 * Empty out JavaScript output that calls function to decrement the update counts.
	 *
	 * @param string $type Type of update count to decrement.
	 */
	public function decrement_update_count( $type ) {}

	/**
	 * Record the error (without printing any HTML) so the caller can read the
	 * real reason via $this->get_errors() and surface it to the user.
	 *
	 * @param string|\WP_Error $errors A string or WP_Error object of the install error/s.
	 */
	public function error( $errors ) {

		if ( ! ( $this->rey_errors instanceof \WP_Error ) ) {
			$this->rey_errors = new \WP_Error();
		}

		if ( is_string( $errors ) ) {
			$message = isset( $this->upgrader->strings[ $errors ] ) ? $this->upgrader->strings[ $errors ] : $errors;
			$this->rey_errors->add( 'install_error', $message );
		}
		elseif ( is_wp_error( $errors ) && $errors->has_errors() ) {
			foreach ( $errors->get_error_codes() as $code ) {
				$this->rey_errors->add( $code, $errors->get_error_message( $code ), $errors->get_error_data( $code ) );
			}
		}
	}

	/**
	 * Expose the collected errors to the caller.
	 *
	 * @return \WP_Error
	 */
	public function get_errors() {
		return $this->rey_errors;
	}
}
