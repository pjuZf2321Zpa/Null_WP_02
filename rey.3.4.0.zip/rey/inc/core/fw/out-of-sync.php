<?php
namespace Rey;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Handles out of sync notices to force major updates on both Core and Theme.
 */
class OutOfSync
{
	private static $items = [];

	const THEME_SLUG = 'rey';

	const CORE_SLUG = 'rey-core';

	public function __construct()
	{

		// determine which lib to load
		// and if it should load
		if( ! self::should_load() ){
			return;
		}

		define('REY_OUTDATED', true);

		// Legacy, remove old hooks
		if( class_exists('\ReyTheme_Base') && is_callable(['ReyTheme_Base', 'out_of_sync']) && function_exists('reycore__remove_filters_for_anonymous_class') ){
			reycore__remove_filters_for_anonymous_class( 'admin_notices', 'ReyTheme_Base', 'out_of_sync', 10 );
			reycore__remove_filters_for_anonymous_class( 'wp_body_open', 'ReyTheme_Base', 'out_of_sync', 10 );
		}

		add_action( 'admin_notices', [$this, 'render_notice'] );
		add_action( 'wp_body_open', [$this, 'render_notice'] );
		add_action( 'wp_ajax_rey_outdated_link', [$this, 'ajax__outdated_link'] );
		add_action( 'wp_ajax_rey_download_link', [$this, 'ajax__download_link'] );
		add_action( 'wp_ajax_rey_get_actions', [$this, 'ajax__get_actions'] );
	}

	/**
	 * Determines if the library should load
	 *
	 * @return boolean
	 */
	public static function should_load(){

		// GPL Vault: the theme/core pair we publish is not always version-matched, so this
		// gate would show a permanent admin notice and a front-end overlay. Delete this
		// return to restore it. Leaves REY_OUTDATED undefined, i.e. normal asset handling.
		return false;

		if( ! (current_user_can('administrator') || current_user_can('install_plugins')) ){
			return;
		}

		self::$items = [
			self::THEME_SLUG => [
				'version_constant' => 'REY_THEME_VERSION',
				'type'             => 'theme',
				'basename'         => self::THEME_SLUG,
			],
			self::CORE_SLUG => [
				'version_constant' => 'REY_CORE_VERSION',
				'type'             => 'plugin',
				'basename'         => 'rey-core/rey-core.php',
			],
		];

		$theme_version = self::$items[self::THEME_SLUG]['version_constant'];
		$core_version = self::$items[self::CORE_SLUG]['version_constant'];

		// must have both Core and Theme active
		if( ! ( defined( $theme_version ) && defined( $core_version ) ) ){
			return false;
		}

		self::$items[self::THEME_SLUG]['major_version'] = self::get_item_major_version( constant($theme_version) );
		self::$items[self::CORE_SLUG]['major_version'] = self::get_item_major_version( constant($core_version) );

		// if both major versions are similar, no need to continue
		if( self::$items[self::THEME_SLUG]['major_version'] === self::$items[self::CORE_SLUG]['major_version'] ){
			return false;
		}

		$ns = strtolower(__NAMESPACE__);

		// we're inside Core
		if( $ns === str_replace('-', '', self::CORE_SLUG) ){
			$v1 = constant($core_version);
			$v2 = constant($theme_version);
		}
		// we're inside theme
		elseif( $ns === self::THEME_SLUG ) {
			$v1 = constant(self::$items[self::THEME_SLUG]['version_constant']);
			$v2 = constant(self::$items[self::CORE_SLUG]['version_constant']);
		}

		return version_compare( $v1, $v2, '>' );
	}

	/**
	 * Retrieves the items.
	 *
	 * @return array
	 */
	public static function get_items(){

		if( function_exists('rey__get_props') ):
			// define only if undefined
			if( ! isset(self::$items[self::THEME_SLUG]['name']) ){
				self::$items[self::THEME_SLUG]['name'] = rey__get_props('theme_title');
			}
			if( ! isset(self::$items[self::CORE_SLUG]['name']) ){
				self::$items[self::CORE_SLUG]['name'] = rey__get_props('core_title');
			}
		endif;

		return self::$items;
	}

	/**
	 * Retrieve major version
	 *
	 * @param string $version
	 * @return string
	 */
	public static function get_item_major_version( $version ){
		$v = array_map('absint', explode( '.', $version ));
		return sprintf('%d.%d.0', $v[0], $v[1]);
	}

	public static function get_config( $slug, $items ){

		$sibling = self::CORE_SLUG === $slug ? self::THEME_SLUG : self::CORE_SLUG;

		if( ! version_compare( constant($items[ $sibling ]['version_constant']), $items[ $slug ]['major_version'], '<' ) ){
			return [];
		}

		return [
			'to_update'         => $items[ $sibling ]['name'],
			'from'              => $items[ $slug ]['name'],
			'major_version'     => $items[ $slug ]['major_version'],
			'to_update_version' => constant($items[ $sibling ]['version_constant']),
			'slug'              => $sibling,
			'type'              => $items[ $sibling ]['type']
		];
	}

	public function render_notice(){

		$items = self::get_items();

		$maybe_load_assets = [];

		foreach ( array_keys($items) as $slug ) {

			$config = self::get_config($slug, $items);

			if( empty($config) ){
				continue;
			}

			$maybe_load_assets[] = true;

			$nonce = wp_create_nonce( 'updates' );

			$kb_url = function_exists('rey__support_url') ? rey__support_url('kb/rey-theme-is-outdated-and-not-in-sync-with-rey-core-error/') : '';

			$sync_error = '<div class="outofsync-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M3 21v-5h5"/></svg></div>';

			$sync_error .= '<div class="outofsync-content">';

			$sync_error .= sprintf(
				'<h2 class="outofsync-title">%s</h2>',
				sprintf( __('%s needs an update', 'rey'), $config['to_update'] )
			);

			$sync_error .= sprintf(
				'<p class="outofsync-desc">%s</p>',
				sprintf(
					__('<strong>%1$s</strong> is out of sync with <strong>%2$s</strong>. They ship as a pair, and running mismatched versions can lead to errors or missing features. <a href="%3$s" target="_blank" rel="noopener noreferrer">Learn more</a>', 'rey'),
					$config['to_update'],
					$config['from'],
					esc_url( $kb_url )
				)
			);

			$sync_error .= sprintf(
				'<div class="outofsync-versions"><span class="outofsync-ver"><span class="outofsync-ver-label">%1$s</span><strong>%2$s</strong></span><svg class="outofsync-arrow" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg><span class="outofsync-ver --required"><span class="outofsync-ver-label">%3$s</span><strong>%4$s+</strong></span></div>',
				__('Current version', 'rey'),
				$config['to_update_version'],
				__('Required version', 'rey'),
				$config['major_version']
			);

			$sync_error .= sprintf('<div id="outofsync-error-actions" style="display:none" data-slug="%s" data-nonce="%s">', esc_attr($config['slug']), esc_attr($nonce));

			$sync_error .= sprintf(
				'<a href="#" data-slug="%2$s" data-nonce="%3$s" class="outofsync-btn --primary" id="js-update-link">%1$s</a>',
				sprintf( __('Update %s now', 'rey'), $config['to_update'] ),
				esc_attr($config['slug']),
				esc_attr($nonce)
			);

			$sync_error .= sprintf(
				'<a href="#" data-slug="%1$s" data-nonce="%2$s" class="outofsync-btn --secondary" id="js-update-download-link">%3$s</a>',
				esc_attr($config['slug']),
				esc_attr($nonce),
				__('Download .zip', 'rey')
			);

			$sync_error .= sprintf(
				'<span class="outofsync-hint">%s</span>',
				sprintf( __('The .zip file can also be installed manually, like any other %s.', 'rey'), $config['type'] )
			);

			$sync_error .= '</div>';

			$sync_error .= sprintf( '<p id="outofsync-error-spinner">%s</p>', __('Checking update options&hellip;', 'rey') );

			$sync_error .= sprintf(
				'<p class="outofsync-footnote">%s</p>',
				__('Only administrators can see this notice. Visitors will not see it.', 'rey')
			);

			$sync_error .= '</div>';

			printf('<div class="rey-overlay --no-close" id="outofsync-error--overlay"></div><div id="outofsync-error">%s</div>', $sync_error);
		}

		if( in_array(true, $maybe_load_assets, true) ){
			$this->print_js();
			$this->print_css();
		}

	}

	public static function ajax_get_data(){

		if ( ! wp_verify_nonce( $_POST['_ajax_nonce'], 'updates' ) ) {
			return ['error' => 'Operation not allowed!'];
		}

		if( ! (current_user_can('administrator') || current_user_can('install_plugins')) ){
			return ['error' => 'Operation not allowed!'];
		}

		if( ! function_exists('rey__clean') ){
			return ['error' => 'Missing clean function.'];
		}

		if( ! (isset($_POST['slug']) && $slug = rey__clean($_POST['slug'])) ){
			return ['error' => 'Missing type.'];
		}

		$items = self::get_items();

		if( ! isset($items[$slug]) ){
			return ['error' => 'Incorrect slug.'];
		}

		return [
			'slug' => $slug,
			'items' => $items,
		];
	}

	public function ajax__outdated_link(){

		$data = self::ajax_get_data();

		if( isset($data['error']) ){
			wp_send_json_error( $data['error'] );
		}

		if( ! class_exists('\Rey\Upgrader') ){
			require_once __DIR__ . '/upgrader.php';
		}

		$upgrader = new \Rey\Upgrader([
			'slug'     => $data['slug'],
			'basename' => $data['items'][ $data['slug'] ]['basename'],
			'hook'     => 'rey/update/outofsync',
		]);

		if( ! empty($upgrader->error) ){
			wp_send_json_error( $upgrader->error );
		}

		wp_send_json_success( $upgrader );
	}


	/**
	 * Handles downloading the lastest version
	 *
	 * @return void
	 */
	public function ajax__download_link(){

		$data = self::ajax_get_data();

		if( isset($data['error']) ){
			wp_send_json_error( $data['error'] );
		}

		if( ! ($download_link = self::get_download_url( $data['slug'] ) ) ){
			wp_send_json_error( 'Cannot retrieve download link.' );
		}

		wp_send_json_success($download_link);
	}

	public static function get_download_url( $slug ){

		if( ! class_exists('\ReyTheme_API') ){
			return false;
		}

		return \ReyTheme_API::getInstance()->get_download_url( self::THEME_SLUG === $slug ? 'theme' : $slug );
	}

	/**
	 * Handles downloading the lastest version
	 *
	 * @return void
	 */
	public function ajax__get_actions(){

		$data = self::ajax_get_data();

		if( isset($data['error']) ){
			wp_send_json_error( $data['error'] );
		}

		if( ! class_exists('\ReyTheme_API') ){
			wp_send_json_error();
		}

		$url = add_query_arg([
			'purchase_code' => \ReyTheme_Base::get_purchase_code()
			], \ReyTheme_API::$api_site_url
		);

		if( ! self::valid_url( $url ) ){
			wp_send_json_error();
		}

		wp_send_json_success();
	}

	/**
	 * Render CSS for handling the notice styling
	 *
	 * @return void
	 */
	public function print_css(){

		?>
		<style type="text/css">

		body:not(.wp-admin) #outofsync-error--overlay {
			visibility: visible;
			opacity: 1;
			pointer-events: auto;
			left: 0;
			cursor: auto;
		}

		#outofsync-error {
			--oos-text: #1d2327;
			--oos-muted: #667085;
			--oos-border: #e4e7ec;
			--oos-accent: #b45309;
			--oos-accent-bg: #fef3c7;
			position: relative;
			display: flex;
			align-items: flex-start;
			gap: 22px;
			box-sizing: border-box;
			margin: 25px 20px 15px 2px;
			padding: 28px 32px 24px;
			background-color: #fff;
			border: 1px solid var(--oos-border);
			border-radius: 12px;
			box-shadow: 0 1px 2px rgba(16, 24, 40, .05), 0 16px 40px -12px rgba(16, 24, 40, .14);
			color: var(--oos-text);
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
			font-size: 14px;
			font-weight: 400;
			line-height: 1.6;
		}

		#outofsync-error *,
		#outofsync-error *:before,
		#outofsync-error *:after {
			box-sizing: inherit;
		}

		#outofsync-error .outofsync-icon {
			flex: 0 0 auto;
			display: flex;
			align-items: center;
			justify-content: center;
			width: 48px;
			height: 48px;
			border-radius: 50%;
			background-color: var(--oos-accent-bg);
			color: var(--oos-accent);
		}

		#outofsync-error .outofsync-icon svg {
			width: 22px;
			height: 22px;
		}

		#outofsync-error .outofsync-content {
			flex: 1 1 auto;
			min-width: 0;
		}

		#outofsync-error .outofsync-title {
			margin: 4px 0 6px;
			padding: 0;
			font-size: 17px;
			font-weight: 600;
			line-height: 1.3;
			color: var(--oos-text);
		}

		#outofsync-error .outofsync-desc {
			margin: 0 0 18px;
			max-width: 72ch;
			font-size: 14px;
			color: #50575e;
		}

		#outofsync-error .outofsync-desc a {
			color: var(--oos-text);
			text-decoration: underline;
			text-underline-offset: 2px;
		}

		#outofsync-error .outofsync-desc a:hover {
			color: var(--oos-accent);
		}

		#outofsync-error .outofsync-versions {
			display: flex;
			align-items: center;
			flex-wrap: wrap;
			gap: 12px;
			margin-bottom: 20px;
		}

		#outofsync-error .outofsync-ver {
			display: flex;
			flex-direction: column;
			gap: 1px;
			min-width: 120px;
			padding: 8px 14px;
			border: 1px solid var(--oos-border);
			border-radius: 10px;
			background-color: #f9fafb;
		}

		#outofsync-error .outofsync-ver-label {
			font-size: 10px;
			font-weight: 600;
			letter-spacing: .06em;
			text-transform: uppercase;
			color: var(--oos-muted);
		}

		#outofsync-error .outofsync-ver strong {
			font-size: 15px;
			font-variant-numeric: tabular-nums;
			line-height: 1.4;
		}

		#outofsync-error .outofsync-ver.--required {
			border-color: #a6f4c5;
			background-color: #f0fdf4;
		}

		#outofsync-error .outofsync-ver.--required strong {
			color: #027a48;
		}

		#outofsync-error .outofsync-arrow {
			width: 18px;
			height: 18px;
			color: var(--oos-muted);
		}

		#outofsync-error-actions {
			display: flex;
			align-items: center;
			flex-wrap: wrap;
			gap: 10px 14px;
			margin: 0 0 20px;
		}

		#outofsync-error .outofsync-btn {
			display: inline-flex;
			align-items: center;
			gap: 8px;
			padding: 9px 18px;
			border: 1px solid transparent;
			border-radius: 8px;
			font-size: 13px;
			font-weight: 600;
			line-height: 1.3;
			text-decoration: none;
			cursor: pointer;
			transition: background-color .15s ease, border-color .15s ease, color .15s ease;
		}

		#outofsync-error .outofsync-btn.--primary {
			background-color: #1d2327;
			color: #fff;
		}

		#outofsync-error .outofsync-btn.--primary:hover {
			background-color: #000;
			color: #fff;
		}

		#outofsync-error .outofsync-btn.--secondary {
			border-color: #c3c4c7;
			background-color: transparent;
			color: var(--oos-text);
		}

		#outofsync-error .outofsync-btn.--secondary:hover {
			border-color: #8c8f94;
			background-color: #f6f7f7;
			color: var(--oos-text);
		}

		#outofsync-error .outofsync-btn.--disabled {
			opacity: .55;
			pointer-events: none;
		}

		#outofsync-error .outofsync-btn.--loading:before {
			content: "";
			flex: 0 0 auto;
			width: 1em;
			height: 1em;
			border: 2px solid currentColor;
			border-right-color: transparent;
			border-radius: 50%;
			animation: oos-spin .75s linear infinite;
		}

		#outofsync-error .outofsync-hint {
			flex-basis: 100%;
			font-size: 12px;
			color: var(--oos-muted);
		}

		#outofsync-error-spinner {
			display: flex;
			align-items: center;
			gap: 10px;
			margin: 0 0 20px;
			font-size: 12.5px;
			color: var(--oos-muted);
		}

		#outofsync-error-spinner:after {
			content: "";
			width: 1em;
			height: 1em;
			border: 2px solid transparent;
			border-right-color: currentColor;
			border-bottom-color: currentColor;
			border-radius: 50%;
			animation: oos-spin .75s linear infinite;
			opacity: .6;
		}

		@keyframes oos-spin {
			to {
				transform: rotate(360deg);
			}
		}

		#outofsync-error .outofsync-footnote {
			margin: 0;
			padding-top: 14px;
			border-top: 1px solid var(--oos-border);
			font-size: 12px;
			color: var(--oos-muted);
		}

		@media (max-width: 600px) {
			#outofsync-error {
				flex-direction: column;
				gap: 16px;
				padding: 22px 20px;
			}
		}

		body:not(.wp-admin) #outofsync-error {
			position: fixed;
			z-index: 9999;
			top: clamp(20px, 7vh, 90px);
			left: 50%;
			transform: translateX(-50%);
			width: min(680px, calc(100vw - 32px));
			margin: 0;
			max-height: calc(100vh - 40px);
			overflow: auto;
		}

		</style>
		<?php
	}

	/**
	 * Render JS for handling the notice actions
	 *
	 * @return void
	 */
	public function print_js(){
		?>
		<script type="text/javascript">

		document.addEventListener("DOMContentLoaded", function() {

			var notice = document.getElementById('outofsync-error');

			if( ! notice ){
				return;
			}

			var responseHolder = notice.querySelector('#outofsync-error-actions');

			if( responseHolder && typeof jQuery !== 'undefined'){
				jQuery.ajax({
					method: "post",
					url: '<?php echo admin_url( 'admin-ajax.php' ) ?>',
					data: {
						action     : "rey_get_actions",
						slug       : responseHolder.getAttribute('data-slug'),
						_ajax_nonce: responseHolder.getAttribute('data-nonce'),
					},
					success: function (response) {

						var spinner = notice.querySelector('#outofsync-error-spinner');

						if( spinner ){
							spinner.remove();
						}

						if( response.success ){
							responseHolder.removeAttribute('style');
						}
					},
				});
			}

			var updateLink = notice.querySelector('#js-update-link');

			var isUpdating = false;

			window.onbeforeunload = function () {
				if (isUpdating) {
					return "Updating is in progress! Please don't close window.";
				}
				return undefined;
			};

			updateLink && updateLink.addEventListener('click', function(e){
				e.preventDefault();

				var btn = e.currentTarget;

				isUpdating = true;

				btn.classList.add('--disabled');
				btn.classList.add('--loading');

				btn.textContent = 'Updating…';

				if( typeof jQuery === 'undefined' ){
					console.error('jQuery not defined.')
					return;
				}

				jQuery.ajax({
					method: "post",
					url: '<?php echo admin_url( 'admin-ajax.php' ) ?>',
					data: {
						action     : "rey_outdated_link",
						slug       : btn.getAttribute('data-slug'),
						_ajax_nonce: btn.getAttribute('data-nonce'),
					},
					success: function (response) {

						btn.classList.remove('--loading');
						btn.classList.remove('--disabled');

						btn.textContent = 'Updated! Reloading…';

						isUpdating = false;

						setTimeout(function () {
							location.reload();
						}, 1000);
					},
				});

			});


			var downloadLink = notice.querySelector('#js-update-download-link');

			downloadLink && downloadLink.addEventListener('click', function(e){
				e.preventDefault();

				var btn = e.currentTarget;

				btn.classList.add('--disabled');
				btn.classList.add('--loading');

				if( typeof jQuery === 'undefined' ){
					console.error('jQuery not defined.')
					return;
				}

				jQuery.ajax({
					method: "post",
					url: '<?php echo admin_url( 'admin-ajax.php' ) ?>',
					data: {
						action     : "rey_download_link",
						slug       : btn.getAttribute('data-slug'),
						_ajax_nonce: btn.getAttribute('data-nonce'),
					},
					success: function (response) {

						btn.classList.remove('--loading');

						if( ! response ){
							console.error(response);
							return;
						}

						if( ! response.success ){
							btn.textContent = response.data;
							console.error(response.data);
							return;
						}

						btn.classList.remove('--disabled');

						var a = document.createElement('a');
							a.href = response.data;
							a.download = btn.getAttribute('data-slug');
							a.dispatchEvent(new MouseEvent('click'));
					},
				});
			});
		});

		</script>
		<?php
	}

	public static function valid_url($url)
	{
		$response = wp_safe_remote_get( $url );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		return 200 === wp_remote_retrieve_response_code( $response );
	}
}

new OutOfSync;
