<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

if( ! class_exists('ReyTheme_WhatsNew') ):

/**
 * "What's New" page.
 *
 * A full-screen, changelog-style admin page that highlights the new features
 * after a major theme update. Adds a submenu item under the Rey dashboard, shows
 * an "unread" green dot on the menu item until visited, and lets the admin hide
 * it until the next major version or disable it permanently.
 *
 * Moved out of the rey-core plugin (was `ReyCore\WhatsNew`) so the theme owns it.
 * The option keys are kept identical to rey-core's so sites that already dismissed
 * the page stay dismissed after the move.
 */
class ReyTheme_WhatsNew {

	/**
	 * Option name for the DB option that
	 * highlights the What's new menu item
	 */
	const READ = 'reycore_whatsnew_read';

	/**
	 * Name of the option that will hide
	 * this page until a new major update.
	 */
	const HIDE_UNTIL_MAJOR = 'reycore_whatsnew_hide_minor';

	/**
	 * ACF option name that adds the ability to permanently hide
	 * the Whats new page from ever showing up.
	 */
	const WHATS_NEW_OPTION = 'rey_show_whatsnew';

	/**
	 * Tracks the last major version the page was shown for, so a major
	 * update can resurface the page without depending on rey-core's
	 * version system (previously the `reycore/updates/major_version` action).
	 */
	const LAST_MAJOR = 'rey_whatsnew_last_major';

	/**
	 * Page is enabled
	 *
	 * @var boolean
	 */
	public $is_enabled = true;

	public function __construct(){

		add_action( 'init', [$this, 'init'] );
		add_action( 'admin_menu', [$this, 'register_admin_menu'], 200 );
		add_action( 'admin_head', [ $this, 'load_google_font' ] );
		add_filter( 'rey/admin/submenu/classes', [ $this, 'submenu_classes' ], 10, 2 );

		add_action( 'wp_ajax_rey_whatsnew_page_visibility', [ $this, 'ajax__update_page_visibility' ] );
		add_action( 'wp_ajax_rey_whatsnew_hide_until_next_major', [ $this, 'ajax__hide_until_next_major' ] );
	}

	public function init(){

		// Resurface the page after a major update (replaces rey-core's
		// `reycore/updates/major_version` hook - keeps this self-contained).
		if( is_admin() ){
			$this->maybe_handle_major_update();
		}

		$this->add_acf_show_button();

		$this->is_enabled = $this->is_enabled();

	}

	/**
	 * Retrieve the current major x.x version, eg "3.2".
	 *
	 * @return string
	 */
	public static function get_current_major_version(){
		$v = array_map('absint', explode( '.', REY_THEME_VERSION ));
		return sprintf('%d.%d', isset($v[0]) ? $v[0] : 0, isset($v[1]) ? $v[1] : 0);
	}

	/**
	 * Marks the "What's new" page back as unread when the theme's major
	 * version changes (eg "3.1" => "3.2"), and clears the "hide until next
	 * major" flag so the page shows up again.
	 *
	 * @return void
	 */
	public function maybe_handle_major_update(){

		$current = self::get_current_major_version();
		$stored  = get_option(self::LAST_MAJOR);

		if( $stored && version_compare( $stored, $current, '<' ) ){
			// major version switch
			delete_option(self::READ);
			delete_option(self::HIDE_UNTIL_MAJOR);
		}

		if( $stored !== $current ){
			update_option(self::LAST_MAJOR, $current);
		}
	}

	/**
	 * Retrieve page slug
	 *
	 * @return string
	 */
	public function get_menu_slug(){
		return sprintf('%s-whatsnew', REY_THEME_NAME);
	}

	/**
	 * Marks What's new menu item as read, meaning
	 * that the green bubble will stop showing.
	 *
	 * @return bool
	 */
	private function mark_read(){

		if( ! $this->is_unread() ){
			return;
		}

		return update_option(self::READ, true);
	}

	/**
	 * Checks if Whats new page has been seen.
	 *
	 * @return boolean
	 */
	public function is_unread(){
		return ! get_option(self::READ);
	}

	/**
	 * Filter the submenus classes to be able to add an unread bubble
	 * inside the What's new menu item
	 *
	 * @param string $class
	 * @param array $item
	 * @return string
	 */
	public function submenu_classes($class, $item){

		if( isset($item[2]) && $this->get_menu_slug() === $item[2] ){
			// can show unread bubble
			if( $this->is_unread() ){
				$class .= ' --unread';
			}
		}

		return $class;
	}

	/**
	 * Load Google Font
	 *
	 * @return void
	 */
	public function load_google_font(){

		if( ! $this->is_enabled ){
			return;
		}

		if( isset($_REQUEST['page']) && $this->get_menu_slug() === rey__clean($_REQUEST['page']) ){
			// echo '<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&display=swap">';
		}
	}

	/**
	 * Adds the admin menu item
	 *
	 * @return void
	 */
	public function register_admin_menu() {

		if( ! $this->is_enabled ){
			return;
		}

		if( ! rey__get_props('branding') ){
			return;
		}

		if( ! rey__get_props('whats_new') ){
			return;
		}

		if( $dashboard_id = ReyTheme_Base::DASHBOARD_PAGE_ID ){
			$title = esc_html__('What\'s New', 'rey');
			add_submenu_page(
				$dashboard_id,
				$title,
				$title,
				'update_plugins',
				$this->get_menu_slug(),
				[ $this, 'render_page' ]
			);
		}
	}

	/**
	 * Features that are shown in the page
	 *
	 * @return array
	 */
	public function get_data(){

		// Hero: the new Settings panel (Customizer replacement).
		$items[] = [
			'version'  => '3.3.0',
			'label'    => 'Redesigned Experience',
			'title'    => 'The New Settings Panel',
			'desc'     => '<p>A brand new, lightning-fast settings experience that replaces the WordPress Customizer.</p>
			<p>Search any option instantly, navigate cleaner sections, and preview your changes side by side, all in a modern interface built from the ground up.</p>',
			'img'      => 'https://rey-theme.s3.us-west-2.amazonaws.com/public/whats-new/3.3.0/settings-app.jpg',
		];

		// Container Data Provider module.
		$items[] = [
			'size'    => 'third',
			'version' => '3.4.0',
			'label'   => 'Elementor',
			'title'   => 'Data-Driven Containers',
			'desc'    => '<p>Point a container at any post, product, term or ACF source, and every widget inside it renders against that data instead of the current page. It can also inherit the source from the page, the menu item or the global section it sits in.</p>',
			'img'     => 'https://rey-theme.s3.us-west-2.amazonaws.com/public/whats-new/3.4.0/container-data-provider.jpg',
		];

		// Header model v2.
		$items[] = [
			'size'    => 'third',
			'version' => '3.4.0',
			'label'   => 'Redesigned',
			'title'   => 'Simpler Header Positioning',
			'desc'    => '<p>The site-wide header is now simply Standard or Sticky. Overlapping the content moved to the page itself, so a single page can sit under a transparent header without touching any global setting.</p>',
			'img'     => 'https://rey-theme.s3.us-west-2.amazonaws.com/public/whats-new/3.4.0/header-positioning.jpg',
		];

		// Editor context actions.
		$items[] = [
			'size'    => 'third',
			'version' => '3.4.0',
			'label'   => 'Elementor',
			'title'   => 'Editor Shortcuts',
			'desc'    => '<p>Wrap a selection in a container, unwrap one without losing what is inside it, or turn a whole section into a Global Section. Each one takes a single click, and a single undo to step back.</p>',
			'img'     => 'https://rey-theme.s3.us-west-2.amazonaws.com/public/whats-new/3.4.0/editor-shortcuts.jpg',
		];

		// Hero: Mobile Bottom Bar.
		$items[] = [
			'reversed' => true,
			'version'  => '3.3.0',
			'label'    => 'Mobile Experience',
			'title'    => 'The Mobile Bottom Bar',
			'desc'     => '<p>Give mobile shoppers a native app-like toolbar, pinned to the bottom of the screen and always within thumb\'s reach.</p>
			<p>Build it your way with menu, search, cart, account and custom links, so the most important actions are one tap away on every page.</p>',
			'img'      => 'https://rey-theme.s3.us-west-2.amazonaws.com/public/whats-new/3.3.0/mobile-bottom-bar.jpg',
		];

		// Age restriction module.
		$items[] = [
			'size'    => 'third',
			'version' => '3.3.0',
			'label'   => 'Features',
			'title'   => 'Age Restriction Gate',
			'desc'    => '<p>Add a fullscreen age verification gate to your store. Cache-safe, with a blurred site preview behind it and an inline check that works even with page caching enabled.</p>',
			'img'     => 'https://rey-theme.s3.us-west-2.amazonaws.com/public/whats-new/3.3.0/age-restriction.jpg',
		];

		// Dynamic data in editors.
		$items[] = [
			'size'    => 'third',
			'version' => '3.3.0',
			'label'   => 'Features',
			'title'   => 'Dynamic Data in Editors',
			'desc'    => '<p>Insert dynamic values right from the settings editors, pulling in product attributes, global sections and ACF fields, then have them render live on the front end.</p>',
			'img'     => 'https://rey-theme.s3.us-west-2.amazonaws.com/public/whats-new/3.3.0/dynamic-data.jpg',
		];

		// Mobile navigation search module.
		$items[] = [
			'size'    => 'third',
			'version' => '3.3.0',
			'label'   => 'Features',
			'title'   => 'Search in Mobile Menu',
			'desc'    => '<p>Drop a search box right above the mobile navigation panel. It can show a simple form or swap the menu for live results as visitors type.</p>',
			'img'     => 'https://rey-theme.s3.us-west-2.amazonaws.com/public/whats-new/3.3.0/mobile-nav-search.jpg',
		];

		// reCAPTCHA module.
		$items[] = [
			'size'    => 'third',
			'version' => '3.3.0',
			'label'   => 'Security',
			'title'   => 'Built-in reCAPTCHA',
			'desc'    => '<p>Protect your login, register and account forms with Google reCAPTCHA v2 or v3, natively, without extra plugins. Just add your keys and pick where it applies.</p>',
			'img'     => 'https://rey-theme.s3.us-west-2.amazonaws.com/public/whats-new/3.3.0/recaptcha.jpg',
		];

		// Performance improvements.
		$items[] = [
			'size'    => 'third',
			'version' => '3.3.0',
			'label'   => 'Performance',
			'title'   => 'Faster Settings & Rendering',
			'desc'    => '<p>Under-the-hood work on how Rey reads and stores settings means less overhead on every page load, so this update should feel snappier across the board.</p>',
			'img'     => 'https://rey-theme.s3.us-west-2.amazonaws.com/public/whats-new/3.3.0/performance.jpg',
		];

		// New pricing model.
		$items[] = [
			'size'    => 'third',
			'version' => '3.3.0',
			'label'   => 'News',
			'title'   => 'New Pricing Model',
			'desc'    => '<p>Rey is now available for purchase directly on <a href="https://reytheme.com/pricing/" target="_blank">reytheme.com/pricing</a>, independent from ThemeForest, with new licensing options.</p>',
			'img'     => 'https://rey-theme.s3.us-west-2.amazonaws.com/public/whats-new/3.3.0/pricing-model.jpg',
		];

		$data = [];

		foreach ($items as $key => $value) {
			$data[$key] = wp_parse_args($value, [
				'size'     => 'full',
				'reversed' => false,
				'version'  => '',
				'label'    => '',
				'title'    => '',
				'desc'     => '',
				'img'      => '',
			]);
		}

		return $data;
	}

	/**
	 * Render the Whats New page
	 *
	 * @return void
	 */
	public function render_page(){

		if( ! $this->is_enabled ){
			return;
		}

		$this->mark_read(); ?>

		<div class="__rey-bg">
			<?php echo rey__get_svg_icon(['id'=>'logo', 'class' => '__bg-logo']) ?>
			<?php echo rey__get_svg_icon(['id'=>'logo', 'class' => '__bg-logo __bg-logo--2']) ?>
		</div>

		<div class="wrap rey-whatsNew-wrapper">

			<header class="rey-whatsNew-header">

				<div class="rey-whatsNew-headings">
					<h1><?php printf(__('What\'s new in <u>%s</u>', 'rey'), self::get_current_major_version()); ?></h1>
					<p><?php printf(__('Rey gets faster, better and easier to use with each update. See <a href="%s" target="_blank">full changelog</a>.', 'rey'), rey__support_url('changelog/')); ?></p>
				</div>

				<div class="rey-whatsNew-logo">
					<hr>
					<?php echo rey__get_svg_icon(['id'=>'logo']) ?>
					<hr>
				</div>

			</header>

			<div class="rey-whatsNew">

				<?php
				foreach ($this->get_data() as $key => $item):

					$classes = [
						'--item-' . sanitize_title($item['title']),
						'--' . $item['size'],
						$item['reversed'] ? '--reversed' : '',
					];

					printf( '<div class="rey-whatsNew-item %s">', esc_attr(implode(' ', $classes)) ); ?>

						<div class="__text">
							<?php if( ($label = $item['label']) || ($version = $item['version']) ): ?>
								<h2 class="__label">
									<?php echo $label ?>
									<?php if( $item['version'] ): ?>
										<span class="__version">v<?php echo esc_html($item['version']) ?></span>
									<?php endif; ?>
								</h2>
							<?php endif; ?>

							<h3 class="__title"><?php echo $item['title'] ?></h3>

							<?php if( $desc = $item['desc'] ): ?>
								<div class="__desc"><?php echo $desc ?></div>
							<?php endif; ?>
						</div>

						<div class="__media">
							<?php if( $img = $item['img'] ): ?>
							<img src="<?php echo $img ?>" class="__img" alt="<?php echo $item['title'] ?>">
							<?php endif; ?>
						</div>

					</div>
					<!-- .rey-whatsNew-item -->
				<?php endforeach; ?>

				<div class="__buttons">
					<a href="<?php echo rey__support_url('changelog/') ?>" target="_blank" class="rey-adminBtn rey-adminBtn-outline --ext">See Full Changelog</a> &nbsp;&nbsp;&nbsp;
					<a href="#" target="_blank" class="rey-adminBtn --btn-link __hide-until-next">Hide for now</a>
				</div>

				<div class="__buttons">
					<a href="#" target="_blank" class="rey-adminBtn --btn-link __never-show"><span class="__close">&times;</span><span>Don't show this page again</span></a>
				</div>

			</div>
			<!-- .rey-whatsNew -->

		</div><!-- /.wrap -->
		<?php
	}

	/**
	 * Hides the Whats new page on demand, through
	 * the "Never show again button".
	 *
	 * @return void
	 */
	public function ajax__update_page_visibility(){

		if ( ! check_ajax_referer( 'rey_dashboard_nonce', 'security', false ) ) {
			wp_send_json_error( esc_html__('Invalid security nonce!', 'rey') );
		}

		if( ! current_user_can( 'administrator' ) ){
			wp_send_json_error( esc_html__('Operation not allowed!', 'rey') );
		}

		if( ! function_exists('update_field') ){
			wp_send_json_error( 'ACF is not available.' );
		}

		if( ! update_field(self::WHATS_NEW_OPTION, false, REY_THEME_NAME) ){
			wp_send_json_error( 'Couldnt update the option' );
		}

		wp_send_json_success();
	}

	/**
	 * Hides the Whats new page on demand, but only until
	 * the upcoming major version eg: "3.1.x" => "3.2.x"
	 *
	 * @return void
	 */
	public function ajax__hide_until_next_major(){

		if ( ! check_ajax_referer( 'rey_dashboard_nonce', 'security', false ) ) {
			wp_send_json_error( esc_html__('Invalid security nonce!', 'rey') );
		}

		if( ! current_user_can( 'administrator' ) ){
			wp_send_json_error( esc_html__('Operation not allowed!', 'rey') );
		}

		if( ! update_option(self::HIDE_UNTIL_MAJOR, true) ){
			wp_send_json_error( 'Couldn\'t update the option.' );
		}

		wp_send_json_success();
	}

	/**
	 * Adds option in theme settings
	 */
	public function add_acf_show_button(){

		if( ! is_admin() ){
			return;
		}

		if( ! function_exists('acf_add_local_field') ){
			return;
		}

		acf_add_local_field([
			'key'          => 'field_' . self::WHATS_NEW_OPTION,
			'name'         => self::WHATS_NEW_OPTION,
			'label'        => esc_html__('Show "What\'s New"', 'rey'),
			'type'         => 'true_false',
			'instructions' => sprintf(esc_html_x('Disable this option to prevent %s from ever showing the "What\'s New" page.', 'Backend setting description', 'rey'), rey__get_props('theme_title')),
			'default_value' => 1,
			'ui'            => 1,
			'parent'        => 'group_5c990a758cfda',
			'menu_order'    => 350,
		]);
	}

	/**
	 * Checks if Whats new page is enabled.
	 * - Only in admin & if the user can update plugins.
	 * - Checks if it's set to be hidden until the next major update.
	 * - If ACF is missing, the option will return true, as enabled.
	 * - If the option is null (never saved) or saved and true, will return as enabled.
	 *
	 * @return boolean
	 */
	public function is_enabled(){

		if( ! is_admin() ){
			return false;
		}

		if( ! current_user_can('update_plugins') ){
			return false;
		}

		// Checks if the page is set to be hidden until the upcoming major
		// update. On a major switch, maybe_handle_major_update() has already
		// cleared this flag, so if it's still set there was no major bump.
		if( get_option(self::HIDE_UNTIL_MAJOR) && ! (defined('REY_WHATSNEW_ALWAYS_SHOW') && REY_WHATSNEW_ALWAYS_SHOW) ){
			return false;
		}

		if( ! class_exists('\ACF') ){
			return true;
		}

		if( ! function_exists('get_field') ){
			return true;
		}

		$opt = get_field(self::WHATS_NEW_OPTION, REY_THEME_NAME);

		return is_null($opt) || (bool) $opt === true;

	}
}

new ReyTheme_WhatsNew;

endif;
