<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( !class_exists('ReyTheme_Changelog') ):
	/**
	 * "What's New" dashbox.
	 *
	 * Pulls the latest changelog entry from the public support site
	 * (support.reytheme.com/changelog/, a normal WordPress page) and shows it on
	 * the theme dashboard.
	 *
	 * Performance is the priority here, so the remote request is kept off the
	 * dashboard's render path entirely:
	 *
	 *   - The heavy page (~80KB of HTML) is fetched over the REST API at most once
	 *     every {@see CACHE_TTL}, and only the small parsed result (one version's
	 *     version number, date and change list, a couple of KB) is cached.
	 *   - The remote fetch only ever runs inside the lazy AJAX handler, never
	 *     while the dashboard page is rendering.
	 *   - When the cache is warm the box renders its content inline (no AJAX round
	 *     trip); only a cold cache shows a skeleton and fills it over AJAX.
	 *
	 * @since 3.1.14
	 */
	class ReyTheme_Changelog
	{
		/**
		 * Transient holding the parsed latest-entry data. The trailing version
		 * lets a markup/format change invalidate stale caches on upgrade.
		 */
		const CACHE_KEY = 'rey_whats_new_v1';

		/**
		 * How long a successful fetch is cached.
		 */
		const CACHE_TTL = 12 * HOUR_IN_SECONDS;

		/**
		 * Shorter cache for a failed fetch, so a transient outage recovers soon
		 * without hammering the support site on every dashboard load.
		 */
		const CACHE_TTL_ERROR = HOUR_IN_SECONDS;

		public function __construct()
		{
			add_action( 'wp_ajax_rey_dashboard_changelog', [ $this, 'ajax_get' ] );
		}

		/**
		 * The box needs the support site URL to fetch from and to link to, so it
		 * follows the same gate as the rest of the KB/support surface.
		 */
		public static function is_enabled(){
			return (bool) rey__get_props('kb_links') && (bool) rey__get_props('support_url');
		}

		/**
		 * REST endpoint for the changelog page, trimmed to just the fields we use.
		 */
		public static function source_url(){
			return add_query_arg(
				[
					'slug'    => 'changelog',
					// Trim the payload to just the content object (drops _links, meta,
					// title, etc.). `content` is supported on every WP version.
					'_fields' => 'content',
				],
				trailingslashit( rey__get_props('support_url') ) . 'wp-json/wp/v2/pages'
			);
		}

		/**
		 * Public link to the full, human-readable changelog page.
		 */
		public static function changelog_url(){
			return rey__support_url('changelog/');
		}

		/**
		 * Read whatever is currently cached, without ever triggering a fetch.
		 * Used for the inline (warm-cache) render on page load.
		 *
		 * @return array|false Parsed data, an ['error'=>1] sentinel, or false when cold.
		 */
		public static function get_cached(){
			return get_transient( self::CACHE_KEY );
		}

		/**
		 * Return cached data, fetching + caching once if the cache is cold.
		 * Only ever called from the AJAX handler (off the render path).
		 *
		 * @return array
		 */
		public static function get_data(){

			$cached = self::get_cached();

			if( false !== $cached ){
				return $cached;
			}

			$data = self::fetch();

			set_transient(
				self::CACHE_KEY,
				$data,
				isset($data['error']) ? self::CACHE_TTL_ERROR : self::CACHE_TTL
			);

			return $data;
		}

		/**
		 * Fetch the changelog page over REST and parse the latest entry out of it.
		 *
		 * @return array Parsed ['version','date','body'] or ['error'=>1].
		 */
		public static function fetch(){

			$request = wp_remote_get( self::source_url(), [
				'timeout' => 15,
				'headers' => [ 'Accept' => 'application/json' ],
			] );

			if( is_wp_error($request) || 200 !== (int) wp_remote_retrieve_response_code($request) ){
				return [ 'error' => 1 ];
			}

			$data = json_decode( wp_remote_retrieve_body($request), true );

			// The REST list endpoint returns an array of matched pages.
			if( empty($data) || ! isset($data[0]['content']['rendered']) ){
				return [ 'error' => 1 ];
			}

			$parsed = self::parse( $data[0]['content']['rendered'] );

			return $parsed ? $parsed : [ 'error' => 1 ];
		}

		/**
		 * Extract the most recent version block from the changelog HTML.
		 *
		 * The changelog markup tags each entry with stable helper classes
		 * (`rey-changelog-version` for the version number) and lays out the
		 * changes as top-level `<ul>` lists, so we anchor on those rather than on
		 * fragile positional structure.
		 *
		 * @param string $html content.rendered
		 * @return array|false ['version','date','body'] or false.
		 */
		public static function parse( $html ){

			if( ! ($html = trim( (string) $html )) || ! class_exists('DOMDocument') ){
				return false;
			}

			$previous = libxml_use_internal_errors( true );

			$dom = new DOMDocument();
			// Force UTF-8 so multibyte characters in the changelog survive.
			$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html );

			libxml_clear_errors();
			libxml_use_internal_errors( $previous );

			$xpath = new DOMXPath( $dom );

			$has_class = "contains(concat(' ', normalize-space(@class), ' '), ' %s ')";

			// The first version node in document order is the newest release.
			$version_node = $xpath->query( sprintf( "(//span[%s])[1]", sprintf($has_class, 'rey-changelog-version') ) )->item(0);

			if( ! $version_node ){
				return false;
			}

			$version = trim( $version_node->textContent );

			// The whole entry lives in the nearest wrapping block group.
			$group = $xpath->query( sprintf( "ancestor::div[%s][1]", sprintf($has_class, 'wp-block-group') ), $version_node )->item(0);

			if( ! $group ){
				return false;
			}

			// Release date: the right-aligned paragraph next to the heading.
			$date = '';
			if( $date_node = $xpath->query( ".//p[contains(@class, 'has-text-align-right')][1]", $group )->item(0) ){
				$date = trim( $date_node->textContent );
			}

			// Change lists: only the top-level <ul>s (skip nested sub-lists).
			$body = '';
			foreach ( $xpath->query( ".//ul[not(ancestor::ul)]", $group ) as $list ) {
				$body .= $dom->saveHTML( $list );
			}

			if( ! ($body = trim($body)) ){
				return false;
			}

			return [
				'version' => wp_strip_all_tags( $version ),
				'date'    => wp_strip_all_tags( $date ),
				'body'    => self::sanitize_body( $body ),
			];
		}

		/**
		 * Keep only the safe list markup we render.
		 */
		public static function sanitize_body( $body ){
			return wp_kses( $body, [
				'ul'     => [ 'class' => [] ],
				'ol'     => [ 'class' => [] ],
				'li'     => [ 'class' => [] ],
				'a'      => [ 'href' => [], 'target' => [], 'rel' => [], 'title' => [] ],
				'strong' => [],
				'b'      => [],
				'em'     => [],
				'i'      => [],
				'code'   => [],
				'span'   => [],
				'br'     => [],
			] );
		}

		/**
		 * Render the inner box content from a data payload.
		 *
		 * @param array $data
		 * @return string
		 */
		public static function render_content( $data ){

			$changelog_url = self::changelog_url();

			// Fetch failed / nothing parseable: keep the box quiet but still useful.
			if( empty($data) || isset($data['error']) || empty($data['body']) ){
				return sprintf(
					'<p class="reyAdmin-notice --info">%s <a href="%s" target="_blank" rel="noopener">%s &#8599;</a></p>',
					esc_html__('The latest changes could not be loaded right now.', 'rey'),
					esc_url( $changelog_url ),
					esc_html__('Open the full changelog', 'rey')
				);
			}

			ob_start(); ?>

			<div class="reyChangelog-head">
				<?php if( ! empty($data['version']) ): ?>
					<span class="reyChangelog-version"><?php echo esc_html($data['version']); ?></span>
				<?php endif; ?>
				<?php if( ! empty($data['date']) ): ?>
					<span class="reyChangelog-date"><?php echo esc_html($data['date']); ?></span>
				<?php endif; ?>
			</div>

			<div class="reyChangelog-body">
				<?php echo $data['body']; // already sanitized in ::parse() ?>
			</div>

			<div class="reyChangelog-footer">
				<a href="<?php echo esc_url( $changelog_url ); ?>" target="_blank" rel="noopener" class="rey-adminBtn rey-adminBtn-line">
					<span><?php esc_html_e('See full changelog', 'rey'); ?></span>
					<span class="__ext" aria-hidden="true">&#8599;</span>
				</a>
			</div>

			<?php return ob_get_clean();
		}

		/**
		 * Render the whole dashbox.
		 *
		 * Inlines the content when the cache is warm (instant, no round trip);
		 * otherwise prints a skeleton that rey-admin.js fills over AJAX.
		 */
		public static function render_box(){

			$cached = self::get_cached();
			$is_cold = ( false === $cached ); ?>

			<div class="rey-dashBox rey-changelogBox js-reyChangelog">
				<div class="rey-dashBox-inner">

					<h2 class="rey-dashBox-title">
						<span class="__title"><?php esc_html_e("What's New", 'rey') ?></span>
					</h2>

					<div class="rey-dashBox-content js-reyChangelog-content">
						<?php if( $is_cold ): ?>
							<div class="reyChangelog-skeleton" aria-hidden="true">
								<span></span><span></span><span></span><span></span>
							</div>
						<?php else: ?>
							<?php echo self::render_content( $cached ); ?>
						<?php endif; ?>
					</div>

				</div>
			</div>

			<?php
		}

		/**
		 * Lazy-load handler for the cold-cache case.
		 */
		public function ajax_get(){

			if ( ! check_ajax_referer( 'rey_dashboard_nonce', 'security', false ) ) {
				wp_send_json_error( esc_html__('Invalid security nonce!', 'rey') );
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( esc_html__('Operation not allowed!', 'rey') );
			}

			if( ! self::is_enabled() ){
				wp_send_json_error( esc_html__("What's New is disabled.", 'rey') );
			}

			wp_send_json_success([ 'html' => self::render_content( self::get_data() ) ]);
		}

	}

	new ReyTheme_Changelog;
endif;
