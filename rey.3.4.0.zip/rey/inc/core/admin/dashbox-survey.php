<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customer Survey dashbox — teaser.
 *
 * The full, focused survey now lives on its own page (Rey dashboard → "Help shape
 * Rey"). On the dashboard we only show a small invite that links there, so the
 * dashboard stays uncluttered and this box needs no survey JS/CSS (it uses the
 * global admin styles). Eligibility is the cheap autoloaded gate, decided in the
 * `rey/dashboard/boxes` closure (dashboard.php).
 */

if ( ! class_exists( 'ReyTheme_SurveyBox' ) ) {
	return;
}

$survey_url = admin_url( 'admin.php?page=' . ReyTheme_SurveyBox::PAGE_SLUG );
?>

<div class="rey-dashBox rey-surveyTeaser">
	<div class="rey-dashBox-inner">

		<h2 class="rey-dashBox-title">
			<span class="__title"><?php echo esc_html( ReyTheme_SurveyBox::get_title() ); ?></span>
		</h2>

		<div class="rey-dashBox-content">
			<p style="margin-top:0;"><?php echo esc_html( ReyTheme_SurveyBox::get_intro() ); ?></p>
			<a class="rey-adminBtn rey-adminBtn-secondary --sm-padding" href="<?php echo esc_url( $survey_url ); ?>">
				<?php esc_html_e( 'Take the survey', 'rey' ); ?>
			</a>
		</div>

	</div>
</div>
