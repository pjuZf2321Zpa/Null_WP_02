<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fallback rendered when no dashbox produced any output, so the page never
 * looks broken. Usually a whitelabel setup, where `dashboxes` is off or every
 * box is listed in `excluded_dashboxes`. See ReyTheme_Setup::set_props().
 *
 * @since 3.3.0
 */
?>

<div class="rey-dashBox --full">
	<div class="rey-dashBox-inner">
		<div class="rey-dashBox-content">

			<p><?php esc_html_e( 'There is nothing to display on this page. All dashboard panels have been turned off through the site configuration.', 'rey' ); ?></p>

			<p><?php echo rey__wp_kses( __( 'If that was not intended, check the <code>THEME_PROPERTIES</code> constant in <code>wp-config.php</code>. The <code>dashboxes</code> key turns off every panel at once, while <code>excluded_dashboxes</code> hides them one by one.', 'rey' ) ); ?></p>

		</div>
	</div>
</div>
