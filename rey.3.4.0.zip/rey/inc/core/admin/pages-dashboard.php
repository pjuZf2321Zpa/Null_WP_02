<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Boxes are collected first, so the page can tell an empty dashboard apart from
 * a broken one. `dashboxes => false` (THEME_PROPERTIES) skips the hook entirely;
 * individual boxes can still opt out through `excluded_dashboxes`.
 */
$boxes = '';

if ( rey__get_props('dashboxes') || ReyTheme_Dashboard::force_show_dashboxes() ) {

	ob_start();

	/**
	 * Hook to add boxes into the theme's dasboard.
	 * Example of Dashboard box

		<div class="rey-dashBox">
			<div class="rey-dashBox-inner">
				<h2 class="rey-dashBox-title">This is a box</h2>
				<div class="rey-dashBox-content">
					...
				</div>
			</div>
		</div>
	 */

	do_action('rey/dashboard/boxes');

	$boxes = trim( ob_get_clean() );
}
?>

<div class="rey-adminPage-wrapper rey-dashboard-wrapper wrap">

	<main class="rey-dashboard-main <?php echo ReyTheme_Base::get_purchase_code() ? '--registered' : ''; ?>">
		<?php
		if ( '' !== $boxes ) {
			echo $boxes; // phpcs:ignore WordPress.Security.EscapeOutput -- each box escapes its own output.
		}
		else {
			require REY_THEME_DIR . '/inc/core/admin/dashbox-empty.php';
		}
		?>
	</main>

</div>
