<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugins Manager dashbox.
 *
 * When the `plugins_manager` prop is disabled (whitelabel), it falls back to the
 * legacy minimal "Install Required Plugins" list below.
 */
if( class_exists('ReyTheme_PluginsBox') && ( ReyTheme_PluginsBox::is_enabled() || ReyTheme_Dashboard::force_show_dashboxes() ) ): ?>

	<div class="rey-dashBox">
		<div class="rey-dashBox-inner">

			<h2 class="rey-dashBox-title">
				<span class="__title"><?php esc_html_e('Plugins Manager', 'rey') ?></span>
			</h2>

			<div class="rey-dashBox-content">

				<p><?php printf( esc_html__('Install and manage the plugins %s uses throughout its demos. Only %s is required, the rest are optional.', 'rey'), rey__get_props('theme_title'), rey__get_props('core_title') ); ?></p>

				<div class="reyPM js-reyPM" data-nonce-action="rey_dashboard_nonce">
					<div class="reyPM-skeleton" aria-hidden="true">
						<span></span><span></span><span></span><span></span>
					</div>
				</div>

			</div>
		</div>
	</div>

	<?php return;
endif;

include __DIR__ . '/tpl-required-plugins.php';

// Hidden when there's nothing to install, unless forced for the dashboxes debug overview.
if( empty($plugins_to_install) && ! ReyTheme_Dashboard::force_show_dashboxes() ){
	return;
} ?>

<div class="rey-dashBox">
	<div class="rey-dashBox-inner">

		<h2 class="rey-dashBox-title"><?php esc_html_e('Install Required Plugins', 'rey') ?></h2>

		<div class="rey-dashBox-content">

			<p><?php printf( esc_html__('%s needs the following plugins to be installed & active:', 'rey'), rey__get_props('theme_title') ); ?></p>

			<?php echo rey__kses_post_with_svg( $plugins_output ); ?>

			<div class="dashBox-reqPlugins-buttons">

				<button class="rey-adminBtn rey-adminBtn-secondary js-dashBox-installRequired <?php echo empty($plugins_to_install) ? 'rey-adminBtn--disabled' : ''; ?>"><?php esc_html_e('INSTALL / ACTIVATE PLUGINS', 'rey') ?></button>

			</div>

		</div>
	</div>
</div>
