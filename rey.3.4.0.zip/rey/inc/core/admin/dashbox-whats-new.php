<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * "What's New" dashbox.
 *
 * All markup + data handling lives in ReyTheme_Changelog; this template only
 * decides whether the box should render at all.
 */
if( ! class_exists('ReyTheme_Changelog') ){
	return;
}

// Disabled on whitelabeled installs (no support/KB surface to pull from or link to),
// unless forced for the dashboxes debug overview.
if( ! ReyTheme_Changelog::is_enabled() && ! ReyTheme_Dashboard::force_show_dashboxes() ){
	return;
}

ReyTheme_Changelog::render_box();
