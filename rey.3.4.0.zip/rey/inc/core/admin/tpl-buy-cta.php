<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Buy license CTA, appended as a footer inside the registration dashboxes.
 *
 * Set `$buy_cta_context = 'registered';` before including to get the
 * "buy another license" wording; defaults to the unregistered wording.
 *
 * @since 3.1.13
 */

// Marketing block; must never render on whitelabeled installs.
if( ! rey__get_props('branding') ){
	return;
}

$buy_cta_registered = isset($buy_cta_context) && 'registered' === $buy_cta_context;

// The Buy price + link come live from the central pricing.json (see ReyTheme_BuyPricing); the
// "from $X" shows as a skeleton until it resolves, with a $59 fallback only on failure.
$buy_url = ReyTheme_BuyPricing::buy_url('dashboard-cta');
?>

<div class="dashBox-buyCta">

	<h4 class="dashBox-buyCta-title"><?php
		echo $buy_cta_registered ?
			esc_html__('Need Rey for another website?', 'rey') :
			esc_html__('Don\'t have a license key?', 'rey');
	?></h4>

	<p><?php
		echo $buy_cta_registered ?
			esc_html__('Each website needs its own license. Get a new one for your next project.', 'rey') :
			esc_html__('Buy your own copy of Rey and unlock updates, demo imports and premium plugins.', 'rey');
	?></p>

	<div class="dashBox-buyCta-action"<?php echo ReyTheme_BuyPricing::pricing_atts('dashboard-cta'); ?>>
		<a href="<?php echo esc_url($buy_url); ?>" target="_blank" rel="noopener" class="rey-adminBtn rey-adminBtn-primary buy-new-license"><?php
			echo $buy_cta_registered ?
				esc_html__('Buy another license', 'rey') :
				esc_html__('Buy Rey', 'rey');
		?></a>
		<span class="dashBox-buyCta-price"><?php
			// The whole "from $X" shows as a skeleton until the live price resolves.
			echo ReyTheme_BuyPricing::price_html([ 'prefix' => esc_html__('from', 'rey') . ' ', 'width' => '4em' ]);
		?></span>
	</div>

</div>
