<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<div class="rey-dashBox">
	<div class="rey-dashBox-inner">

		<h2 class="rey-dashBox-title">
			<span><?php printf( esc_html__('Register %s', 'rey'), rey__get_props('theme_title')) ?></span>
			<?php if( rey__get_props('branding') ){
				echo rey__get_svg_icon(['id'=>'logo', 'class'=>'rDash-logo']);
			} ?>
		</h2>

		<div class="rey-dashBox-content">

			<div class="dashBox-registrationData">

				<p><?php esc_html_e('Thank you for registering! You are now able to get updates, import demos, install premium plugins, access dashboard support and other features.', 'rey') ?></p>

				<h4><?php esc_html_e('Your API KEY:', 'rey') ?></h4>
				<pre><?php echo ReyTheme_Base::get_hidden_purchase_code(); ?></pre>

				<?php
				/**
				 * On a network, spell out which site the key above actually belongs to.
				 * Shared by default, per site when REY_LICENSE_PER_NETWORK is off.
				 */
				if( is_multisite() && ! ReyTheme_Base::is_license_per_network() ): ?>
					<p><small><?php
						esc_html_e('This license key is stored for this site only.', 'rey');
					?></small></p>
				<?php endif; ?>

				<p>
					<a href="#" class="rey-adminBtn rey-adminBtn-line js-dashDeregister"><?php esc_html_e('Deregister license key', 'rey') ?></a>
				</p>
			</div>

			<?php
			$buy_cta_context = 'registered';
			include __DIR__ . '/tpl-buy-cta.php'; ?>

		</div>
	</div>
</div>
