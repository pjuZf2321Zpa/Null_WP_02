<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( !class_exists('ReyTheme_PluginsBox') ):
	/**
	 * Plugins Manager dashbox.
	 *
	 * Replaces the standalone "Plugins Manager" admin page (previously in Rey Core)
	 * with a dashboard box. The heavy list markup is loaded lazily over AJAX so the
	 * dashboard itself stays fast; plugin preview images are fetched only on hover.
	 *
	 * @since 3.1.12
	 */
	class ReyTheme_PluginsBox
	{
		/**
		 * Transient prefix for lazily fetched wp.org preview banners.
		 */
		const PREVIEW_CACHE_KEY = 'rey_pm_preview_';

		/**
		 * Plugins that should not be listed (deprecated or internal).
		 */
		const HIDDEN_PLUGINS = [ 'rey-module-fullscreen-menu' ];

		public function __construct()
		{
			add_action( 'wp_ajax_rey_dashboard_pm_list', [ $this, 'ajax_list' ] );
			add_action( 'wp_ajax_rey_dashboard_pm_refresh', [ $this, 'ajax_refresh' ] );
			add_action( 'wp_ajax_rey_dashboard_pm_action', [ $this, 'ajax_action' ] );
			add_action( 'wp_ajax_rey_dashboard_pm_preview', [ $this, 'ajax_preview' ] );
			add_action( 'admin_menu', [ $this, 'remove_legacy_page' ], 200 );
		}

		/**
		 * Older Rey Core versions still register their standalone "Plugins Manager"
		 * page (registered at priority 120). The dashbox replaces it, so drop the
		 * duplicate menu item when the plugin hasn't been updated yet. Harmless
		 * no-op when the page isn't registered.
		 */
		public function remove_legacy_page(){
			remove_submenu_page( ReyTheme_Base::DASHBOARD_PAGE_ID, 'rey-plugins-manager' );
		}

		/**
		 * Whether the full manager UI is enabled. When the `plugins_manager` prop
		 * is disabled (whitelabel), the dashbox falls back to the minimal
		 * required-plugins list.
		 */
		public static function is_enabled(){
			return (bool) rey__get_props('plugins_manager');
		}

		public static function actions(){
			return [
				'install'    => esc_html__('Install', 'rey'),
				'activate'   => esc_html__('Activate', 'rey'),
				'update'     => esc_html__('Update', 'rey'),
				'deactivate' => esc_html__('Deactivate', 'rey'),
			];
		}

		/**
		 * Get the displayable plugin items, normalized for the box markup.
		 *
		 * Always reads through a fresh `\Rey\Libs\Plugins` instance (not the
		 * statically cached `\Rey\Plugins::get_plugins()`), so a refresh or an
		 * install within the same request is reflected in the markup.
		 *
		 * @return array
		 */
		public static function get_items(){

			$plugins_ob = new \Rey\Libs\Plugins();
			$plugins    = $plugins_ob->get_plugins();

			if( empty($plugins) || ! is_array($plugins) ){
				return [];
			}

			// The API list is stored in reverse priority order.
			$plugins = array_reverse($plugins, true);

			$is_registered = (bool) ReyTheme_Base::get_purchase_code();
			$items = [];

			foreach ($plugins as $slug => $plugin) {

				if( isset($plugin['visibility']) && 'public' !== $plugin['visibility'] ){
					continue;
				}

				if( in_array($slug, self::HIDDEN_PLUGINS, true) ){
					continue;
				}

				$items[$slug] = self::prepare_item($slug, $plugin, $is_registered);
			}

			return $items;
		}

		/**
		 * Normalize a raw plugin entry into the fields the markup needs.
		 *
		 * @param string $slug
		 * @param array  $plugin
		 * @param bool   $is_registered
		 * @return array
		 */
		public static function prepare_item( $slug, $plugin, $is_registered ){

			$keywords  = isset($plugin['keywords']) && is_array($plugin['keywords']) ? $plugin['keywords'] : [];
			$required  = ! empty($plugin['required']);
			$installed = ! empty($plugin['installed']);
			$active    = ! empty($plugin['active']);

			$item = [
				'slug'          => $slug,
				'name'          => isset($plugin['name']) ? $plugin['name'] : $slug,
				'desc'          => isset($plugin['desc']) ? $plugin['desc'] : '',
				'type'          => isset($plugin['type']) ? $plugin['type'] : 'repo',
				'keywords'      => $keywords,
				'required'      => $required,
				'essential'     => $required || in_array('essential', $keywords, true),
				'installed'     => $installed,
				'active'        => $active,
				'version'       => $installed && isset($plugin['file_path']) ? \Rey\Libs\Plugins::get_plugin_version($plugin['file_path']) : '',
				'update'        => '',
				'image'         => isset($plugin['image']) ? $plugin['image'] : '',
				'premium_price' => isset($plugin['premium_price']) ? $plugin['premium_price'] : '',
				// Premium (self-hosted) plugins can only be downloaded with a valid license.
				'locked'        => REY_THEME_NAME === (isset($plugin['type']) ? $plugin['type'] : '') && ! $is_registered && ! $installed,
			];

			if( ! ($item['url'] = isset($plugin['url']) ? $plugin['url'] : '') ){
				$item['url'] = sprintf('https://wordpress.org/plugins/%s/', $slug);
			}

			$item['help_url'] = ! empty($plugin['help_url']) ? $plugin['help_url'] : $item['url'];

			if( $installed && isset($plugin['file_path']) ){
				$item['update'] = (string) \Rey\Libs\Plugins::get_plugin_update_status([
					'file_path' => $plugin['file_path'],
					'version'   => $item['version'],
				]);
			}

			return $item;
		}

		/**
		 * The main action for the item current state.
		 *
		 * @param array $item
		 * @return array [action, label]
		 */
		public static function get_item_action( $item ){

			$actions = self::actions();

			if( ! $item['installed'] ){
				return [ 'install', $actions['install'] ];
			}

			if( ! $item['active'] ){
				return [ 'activate', $actions['activate'] ];
			}

			if( $item['update'] ){
				return [ 'update', sprintf( esc_html__('Update to %s', 'rey'), $item['update'] ) ];
			}

			return [ 'deactivate', $actions['deactivate'] ];
		}

		/**
		 * Render the full box content (tabs + panels + footer).
		 *
		 * @return string
		 */
		public static function render_content(){

			$items = self::get_items();

			if( empty($items) ){
				return sprintf('<p class="reyAdmin-notice --info">%s</p>', esc_html__('The plugins list could not be loaded. Please use the Refresh list button or try again later.', 'rey'));
			}

			$tabs = [
				'essential'   => [
					'title' => esc_html__('Essential', 'rey'),
					'text'  => esc_html__('The foundation of the store. WooCommerce is optional if you are building a regular presentation website.', 'rey'),
					'items' => [],
				],
				'recommended' => [
					'title' => esc_html__('Recommended', 'rey'),
					'text'  => esc_html__('Optional plugins, recommended for their quality or used throughout the premade demos.', 'rey'),
					'items' => [],
				],
			];

			foreach ($items as $slug => $item) {
				$tabs[ $item['essential'] ? 'essential' : 'recommended' ]['items'][$slug] = $item;
			}

			// Required plugins (Rey Core) always sit at the top of the Essential tab.
			uasort($tabs['essential']['items'], function($a, $b){
				return (int) $b['required'] - (int) $a['required'];
			});

			$essential_attention = ! empty(array_filter($tabs['essential']['items'], function($item){
				return ! $item['active'];
			}));

			ob_start(); ?>

			<div class="reyPM-tabs" role="tablist">
				<?php foreach ($tabs as $tab_id => $tab): ?>
				<button type="button" role="tab" class="reyPM-tab js-reyPM-tab <?php echo 'essential' === $tab_id ? '--is-active' : ''; ?>" data-tab="<?php echo esc_attr($tab_id); ?>" aria-selected="<?php echo 'essential' === $tab_id ? 'true' : 'false'; ?>">
					<?php echo $tab['title']; ?>
					<span class="__count"><?php echo count($tab['items']); ?></span>
					<?php if( 'essential' === $tab_id && $essential_attention ): ?>
						<span class="__attention" title="<?php esc_attr_e('Some essential plugins are not active.', 'rey'); ?>"></span>
					<?php endif; ?>
				</button>
				<?php endforeach; ?>
			</div>

			<?php foreach ($tabs as $tab_id => $tab): ?>
			<div class="reyPM-panel <?php echo 'essential' === $tab_id ? '--is-active' : ''; ?>" data-tab-panel="<?php echo esc_attr($tab_id); ?>" role="tabpanel">
				<p class="reyPM-panelText"><?php echo $tab['text']; ?></p>
				<div class="reyPM-list">
					<?php foreach ($tab['items'] as $item) {
						echo self::render_item($item);
					} ?>
				</div>
			</div>
			<?php endforeach; ?>

			<div class="reyPM-footer">

				<button type="button" class="rey-adminBtn reyPM-btn --outline js-reyPM-refresh">
					<span><?php esc_html_e('Refresh list', 'rey'); ?></span>
				</button>

				<?php if( ! ReyTheme_Base::get_purchase_code() ): ?>
					<span class="reyPM-footerNote"><?php
						printf(
							wp_kses( __('Premium plugins need <a href="%s">theme registration</a>.', 'rey'), ['a' => ['href' => []]] ),
							esc_url( add_query_arg( ['page' => ReyTheme_Base::DASHBOARD_PAGE_ID], admin_url('admin.php') ) )
						);
					?></span>
				<?php else: ?>
					<span class="reyPM-footerNote"><a href="<?php echo esc_url( rey__support_url('kb/installing-rey-plugins/') ); ?>" target="_blank"><?php esc_html_e('About these plugins', 'rey'); ?></a></span>
				<?php endif; ?>

			</div>

			<?php return ob_get_clean();
		}

		/**
		 * Render a single plugin row, including its hover preview card.
		 *
		 * @param array $item
		 * @return string
		 */
		public static function render_item( $item ){

			$classes = [ '--status-off' ];

			if( $item['active'] ){
				$classes = [ '--status-active' ];
			}
			else if( $item['installed'] ){
				$classes = [ '--status-inactive' ];
			}

			if( $item['required'] ){
				$classes[] = '--required';
			}

			if( $item['locked'] ){
				$classes[] = '--locked';
			}

			list($action, $action_label) = self::get_item_action($item);

			$state_text = esc_html__('Not installed', 'rey');

			if( $item['active'] ){
				$state_text = esc_html__('Active', 'rey');
			}
			else if( $item['installed'] ){
				$state_text = esc_html__('Installed, inactive', 'rey');
			}

			if( $item['update'] ){
				$state_text .= sprintf(' &middot; %s', sprintf(esc_html__('Update %s available', 'rey'), esc_html($item['update'])));
			}

			ob_start(); ?>

			<div class="reyPM-item <?php echo esc_attr(implode(' ', $classes)); ?>" data-slug="<?php echo esc_attr($item['slug']); ?>" data-type="<?php echo esc_attr($item['type']); ?>">

				<span class="reyPM-statusDot" aria-hidden="true"></span>

				<div class="reyPM-itemMain">
					<h3 class="reyPM-itemName">
						<?php echo esc_html($item['name']); ?>
						<?php if( $item['version'] ): ?>
							<span class="__version"><?php echo esc_html($item['version']); ?></span>
						<?php endif; ?>
						<?php if( $item['required'] ): ?>
							<span class="reyPM-chip --required"><?php esc_html_e('Required', 'rey'); ?></span>
						<?php endif; ?>
						<?php if( $item['locked'] ): ?>
							<span class="reyPM-chip --locked"><?php esc_html_e('Needs registration', 'rey'); ?></span>
						<?php endif; ?>
						<button type="button" class="reyPM-more js-reyPM-more" aria-expanded="false" aria-label="<?php esc_attr_e('More information', 'rey'); ?>">
							<span class="__chev" aria-hidden="true"><?php echo rey__get_svg_icon(['id' => 'chevron']); ?></span>
						</button>
					</h3>
					<span class="reyPM-itemState"><?php echo $state_text; ?></span>
				</div>

				<div class="reyPM-itemActions">

					<?php if( ! $item['locked'] ):

						$action_icons = [
							'install'    => 'download',
							'activate'   => 'check-circle',
							'update'     => 'update',
							'deactivate' => 'minus-circle',
						]; ?>

						<button type="button" class="rey-adminBtn reyPM-btn --icon js-reyPM-action <?php echo 'deactivate' === $action ? '--ghost' : '--primary'; ?>" data-action="<?php echo esc_attr($action); ?>" data-slug="<?php echo esc_attr($item['slug']); ?>" data-tip="<?php echo esc_attr($action_label); ?>" aria-label="<?php echo esc_attr($action_label); ?>">
							<?php echo rey__get_svg_icon(['id' => $action_icons[$action]]); ?>
							<?php if( 'update' === $action ): ?>
								<span class="__dot" aria-hidden="true"></span>
							<?php endif; ?>
						</button>

						<?php if( 'update' === $action ): ?>
							<button type="button" class="rey-adminBtn reyPM-btn --icon --ghost js-reyPM-action" data-action="deactivate" data-slug="<?php echo esc_attr($item['slug']); ?>" data-tip="<?php echo self::actions()['deactivate']; ?>" aria-label="<?php echo self::actions()['deactivate']; ?>">
								<?php echo rey__get_svg_icon(['id' => 'minus-circle']); ?>
							</button>
						<?php endif; ?>

					<?php endif; ?>

				</div>

				<div class="reyPM-details" data-image="<?php echo esc_attr($item['image']); ?>">
					<div class="__inner">
						<span class="__media js-reyPM-media"></span>
						<?php if( $item['desc'] ): ?>
							<p class="__desc"><?php echo esc_html($item['desc']); ?></p>
						<?php endif; ?>
						<div class="__footerRow">
							<p class="__meta">
								<?php foreach ($item['keywords'] as $keyword): ?>
									<span class="reyPM-chip"><?php echo esc_html(ucfirst($keyword)); ?></span>
								<?php endforeach; ?>
								<?php if( $item['premium_price'] ): ?>
									<span class="reyPM-chip --premium"><?php printf( esc_html__('Premium, %s value', 'rey'), esc_html($item['premium_price']) ); ?></span>
								<?php endif; ?>
							</p>
							<a href="<?php echo esc_url($item['help_url']); ?>" target="_blank" rel="noopener" class="rey-adminBtn reyPM-btn --outline">
								<span><?php esc_html_e('Help', 'rey'); ?></span>
								<span class="__ext" aria-hidden="true">&#8599;</span>
							</a>
						</div>
					</div>
				</div>

			</div>

			<?php return ob_get_clean();
		}

		/**
		 * Common AJAX guards.
		 *
		 * @param string $capability
		 */
		private function guard( $capability = 'manage_options' ){

			if ( ! check_ajax_referer( 'rey_dashboard_nonce', 'security', false ) ) {
				wp_send_json_error( esc_html__('Invalid security nonce!', 'rey') );
			}

			if ( ! current_user_can( $capability ) ) {
				wp_send_json_error( esc_html__('Operation not allowed!', 'rey') );
			}

			if( ! self::is_enabled() ){
				wp_send_json_error( esc_html__('The plugins manager is disabled.', 'rey') );
			}
		}

		/**
		 * Lazily loads the box content after the dashboard page has rendered.
		 */
		public function ajax_list(){
			$this->guard();
			wp_send_json_success([ 'html' => self::render_content() ]);
		}

		/**
		 * Re-fetches the plugins list from the API, then returns fresh markup.
		 */
		public function ajax_refresh(){

			$this->guard('install_plugins');

			\Rey\Plugins::refresh();

			wp_send_json_success([ 'html' => self::render_content() ]);
		}

		/**
		 * Runs a plugin action (install / activate / update / deactivate) and
		 * returns the re-rendered row for that plugin.
		 */
		public function ajax_action(){

			$action = isset($_REQUEST['pm_action']) ? rey__clean($_REQUEST['pm_action']) : '';
			$slug   = isset($_REQUEST['slug']) ? rey__clean($_REQUEST['slug']) : '';

			$capabilities = [
				'install'    => 'install_plugins',
				'update'     => 'update_plugins',
				'activate'   => 'activate_plugins',
				'deactivate' => 'activate_plugins',
			];

			if( ! ( $action && isset($capabilities[$action]) ) ){
				wp_send_json_error( esc_html__('Please provide a valid action.', 'rey') );
			}

			$this->guard( $capabilities[$action] );

			$plugins_ob = new \Rey\Libs\Plugins();
			$plugins    = $plugins_ob->get_plugins();

			if( ! ( $slug && isset($plugins[$slug]) ) ){
				wp_send_json_error( esc_html__('Not a registered plugin.', 'rey') );
			}

			$plugin = $plugins[$slug];

			// State overrides for re-rendering the row. WP's plugin data is statically
			// cached during the request, so the outcome is predicted from the action
			// result instead of re-read from disk.
			$overrides = [];

			switch ( $action ):

				case 'install':

					$result = $plugins_ob->install_activate_plugins([ $slug ]);

					if( isset($result['error']) ){
						wp_send_json_error( $result['error'] );
					}

					$overrides = [
						'installed' => true,
						'active'    => true,
						'version'   => isset($plugin['version']) ? $plugin['version'] : '',
					];
					break;

				case 'activate':

					$activate = $plugins_ob->activate_plugin_by_slug($slug);

					if( is_wp_error($activate) ){
						wp_send_json_error( $activate->get_error_message() );
					}

					$overrides = [ 'active' => true ];
					break;

				case 'deactivate':

					if( false === $plugins_ob->deactivate_plugin_by_slug($slug) ){
						wp_send_json_error( esc_html__('The plugin could not be deactivated.', 'rey') );
					}

					$overrides = [ 'active' => false ];
					break;

				case 'update':

					if( ! ($update = $plugins_ob->upgrade_plugins_by_slug([ $slug ])) ){
						wp_send_json_error( esc_html__('The plugin could not be updated. Please retry later.', 'rey') );
					}

					$overrides = [
						'version' => array_values($update)[0],
						'update'  => '',
					];
					break;

			endswitch;

			$item = self::prepare_item( $slug, $plugin, (bool) ReyTheme_Base::get_purchase_code() );
			$item = array_merge( $item, $overrides );

			if( array_key_exists('active', $overrides) ){
				$item['update'] = ''; // freshly changed states settle on the next full render
			}

			wp_send_json_success([
				'html'   => self::render_item($item),
				// Activating or deactivating Rey Core reshapes the whole admin,
				// so the page needs a reload to reflect it.
				'reload' => REY_THEME_CORE_SLUG === $slug && in_array($action, ['install', 'activate', 'deactivate'], true),
			]);
		}

		/**
		 * Returns the preview image for a plugin, fetching wp.org banners lazily
		 * (first hover) and caching them for a week.
		 */
		public function ajax_preview(){

			$this->guard();

			$slug = isset($_REQUEST['slug']) ? rey__clean($_REQUEST['slug']) : '';

			$plugins_ob = new \Rey\Libs\Plugins();
			$plugin     = $plugins_ob->get_plugin_data($slug);

			if( empty($plugin) ){
				wp_send_json_error( esc_html__('Not a registered plugin.', 'rey') );
			}

			// Self-hosted plugins already carry their preview image.
			if( ! empty($plugin['image']) ){
				wp_send_json_success([ 'image' => $plugin['image'] ]);
			}

			if( 'repo' !== $plugin['type'] ){
				wp_send_json_success([ 'image' => '' ]);
			}

			$cache_key = self::PREVIEW_CACHE_KEY . $slug;

			if( false === ($image = get_transient($cache_key)) ){

				$image = '';

				if ( ! function_exists( 'plugins_api' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
				}

				$api = plugins_api( 'plugin_information', [
					'slug'   => $slug,
					'fields' => [
						'sections' => false,
						'banners'  => true,
					],
				] );

				if( ! is_wp_error($api) ){
					$api = (array) $api;
					if( ! empty($api['banners']['low']) ){
						$image = $api['banners']['low'];
					}
					else if( ! empty($api['banners']['high']) ){
						$image = $api['banners']['high'];
					}
				}

				// Cache empty results too ("none"), to avoid hammering the wp.org API.
				set_transient($cache_key, $image ? $image : 'none', WEEK_IN_SECONDS);
			}

			wp_send_json_success([ 'image' => 'none' === $image ? '' : $image ]);
		}

	}

	new ReyTheme_PluginsBox;
endif;
