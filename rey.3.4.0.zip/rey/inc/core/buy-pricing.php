<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Buy CTA pricing.
 *
 * Single client-side source for the "Buy" price + campaign shown on the theme dashboard/wizard
 * CTA and, via the shared static methods, the rey-demos panel. The values come from the central
 * pricing.json that Rey's licensing server publishes — the same static-file mechanism as
 * version.json (see ReyTheme_API). This renders a skeleton price element and prints a tiny
 * fetch/cache/UTM script once in the footer; the script fills in the live price on success, or
 * the fallback price only on failure, so the price never flashes a stale value first.
 *
 * All methods are static (no state) — call them on demand from templates.
 *
 * @since 3.1.13
 */
class ReyTheme_BuyPricing
{
	/**
	 * URL of the central pricing.json. Respects the API client's DEV_REY_API_URL override.
	 */
	public static function endpoint()
	{
		$base = class_exists('ReyTheme_API') ? ReyTheme_API::$api_files_url : 'https://api.reytheme.com/wp-content/uploads/api_routes/';
		return apply_filters('rey/buy_pricing/endpoint', trailingslashit($base) . 'pricing.json');
	}

	/**
	 * Fallback pricing, shown only if the live fetch fails: regular price, no sale.
	 */
	public static function fallback()
	{
		return apply_filters('rey/buy_pricing/fallback', [
			'currency' => '$',
			'price'    => 59,
			'sale'     => null,
			'buy_url'  => 'https://reytheme.com/buy/',
			'campaign' => 'evergreen',
		]);
	}

	/**
	 * A UTM-tagged Buy URL for a placement. This is the initial/fallback href; the script
	 * rewrites utm_campaign live from pricing.json.
	 */
	public static function buy_url( $medium, $source = 'rey-theme' )
	{
		$fallback = self::fallback();
		return add_query_arg([
			'utm_source'   => $source,
			'utm_medium'   => $medium,
			'utm_campaign' => $fallback['campaign'],
		], $fallback['buy_url']);
	}

	/**
	 * Data attributes for the element wrapping a Buy button (or the button itself). The script
	 * scans for [data-rey-pricing] containers.
	 */
	public static function pricing_atts( $medium, $source = 'rey-theme' )
	{
		return sprintf(
			' data-rey-pricing data-rey-pricing-medium="%s" data-rey-pricing-source="%s"',
			esc_attr($medium),
			esc_attr($source)
		);
	}

	/**
	 * The price element inside a Buy button. Renders ONLY an animated skeleton up-front (no
	 * price text); the script swaps in the live price on success, or the fallback price only on
	 * failure.
	 *
	 * @param array $args prefix = static text before the price (e.g. "from ", included in the
	 *                    skeleton), width = skeleton width, class = extra CSS classes.
	 * @return string
	 */
	public static function price_html( $args = [] )
	{
		$args = wp_parse_args($args, [
			'class'  => '',
			'prefix' => '',
			'width'  => '2.6em',
		]);

		self::enqueue_assets();

		$fallback = self::fallback();

		// Skeleton only — no price up-front. The <noscript> keeps a real price for no-JS/crawlers.
		// `data-rey-pricing-prefix` is prepended by the script when it fills in the resolved price.
		return sprintf(
			'<span class="rey-buyPrice %s" data-rey-pricing-price data-rey-pricing-prefix="%s"><span class="rey-buyPrice-skel" style="width:%s" aria-hidden="true"></span><noscript>%s%s%s</noscript></span>',
			esc_attr($args['class']),
			esc_attr($args['prefix']),
			esc_attr($args['width']),
			esc_html($args['prefix']),
			esc_html($fallback['currency']),
			esc_html($fallback['price'])
		);
	}

	/**
	 * Ensure the pricing script + skeleton CSS are printed once, in the footer (admin or
	 * frontend, no build step required).
	 */
	public static function enqueue_assets()
	{
		static $done = false;
		if( $done ){
			return;
		}
		$done = true;
		add_action( is_admin() ? 'admin_print_footer_scripts' : 'wp_print_footer_scripts', [ __CLASS__, 'print_assets' ], 99 );
	}

	/**
	 * Print the pricing skeleton CSS + the fetch/cache/UTM script once.
	 */
	public static function print_assets()
	{
		$config = [
			'endpoint' => self::endpoint(),
			'ttl'      => (int) apply_filters('rey/buy_pricing/cache_ttl', 20 * MINUTE_IN_SECONDS),
			'fallback' => self::fallback(),
		];
		?>
<style id="rey-pricing-css">.rey-buyPrice-skel{display:inline-block;height:.9em;min-width:1.5em;vertical-align:middle;border-radius:.2em;background:linear-gradient(90deg,rgba(128,128,128,.18) 25%,rgba(128,128,128,.4) 37%,rgba(128,128,128,.18) 63%);background-size:400% 100%;animation:reyPricingSkel 1.15s ease-in-out infinite}@keyframes reyPricingSkel{0%{background-position:100% 50%}100%{background-position:0 50%}}.rey-buyPrice del{opacity:.6;font-weight:400;margin-right:.15em}.rey-buyPrice strong{font-weight:700}</style>
<script id="rey-pricing-js">
(() => {
	"use strict";
	const CFG = <?php echo wp_json_encode($config); ?>;
	const KEY = "reyPricing:v1";

	const readCache = () => {
		try {
			const raw = localStorage.getItem(KEY);
			if( ! raw ){ return null; }
			const o = JSON.parse(raw);
			if( ! o || (Date.now() - o.t) > (CFG.ttl * 1000) ){ return null; }
			return o.d;
		} catch(e){ return null; }
	};

	const writeCache = (d) => {
		try { localStorage.setItem(KEY, JSON.stringify({ t: Date.now(), d })); } catch(e){}
	};

	const escHtml = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

	const priceHtml = (d) => {
		const cur = escHtml(d.currency || "$");
		const price = escHtml(d.price);
		if( d.sale && Number(d.sale) > 0 && Number(d.sale) < Number(d.price) ){
			return `<del>${cur}${price}</del> <strong>${cur}${escHtml(d.sale)}</strong>`;
		}
		return cur + price;
	};

	const buildUrl = (base, source, medium, campaign) => {
		try {
			const u = new URL(base);
			if( source ){ u.searchParams.set("utm_source", source); }
			if( medium ){ u.searchParams.set("utm_medium", medium); }
			if( campaign ){ u.searchParams.set("utm_campaign", campaign); }
			return u.toString();
		} catch(e){ return base; }
	};

	const applyOne = (el, d) => {
		const priceEl = el.querySelector("[data-rey-pricing-price]");
		if( priceEl ){
			const prefix = priceEl.getAttribute("data-rey-pricing-prefix") || "";
			priceEl.innerHTML = escHtml(prefix) + priceHtml(d);
		}
		const link = el.matches("a") ? el : (el.querySelector("a[data-rey-pricing-link]") || el.querySelector("a"));
		if( link && d.buy_url ){
			const source = el.getAttribute("data-rey-pricing-source") || "rey-theme";
			const medium = el.getAttribute("data-rey-pricing-medium") || "";
			link.setAttribute("href", buildUrl(d.buy_url, source, medium, d.campaign));
		}
	};

	const applyAll = (d) => document.querySelectorAll("[data-rey-pricing]").forEach((el) => applyOne(el, d));

	// Testing helper: add ?rey-pricing-fresh=1 to the page URL to skip the localStorage
	// cache AND bust the HTTP/edge cache, so a just-changed pricing.json shows immediately.
	const FRESH = /[?&]rey-pricing-fresh=1(?:&|$)/.test(location.search);
	const endpoint = () => FRESH
		? CFG.endpoint + (CFG.endpoint.indexOf("?") === -1 ? "?" : "&") + "_=" + Date.now()
		: CFG.endpoint;

	const init = () => {
		const els = document.querySelectorAll("[data-rey-pricing]");
		if( ! els.length ){ return; }

		const cached = FRESH ? null : readCache();
		if( cached ){ applyAll(cached); return; }
		if( ! CFG.endpoint ){ applyAll(CFG.fallback); return; }

		fetch(endpoint(), { credentials: "omit", cache: FRESH ? "no-store" : "default" })
			.then((r) => { if( ! r.ok ){ throw new Error("bad status"); } return r.json(); })
			.then((j) => {
				const d = (j && j.data) ? j.data : null;
				if( ! d ){ throw new Error("no data"); }
				writeCache(d);
				applyAll(d);
			})
			.catch(() => applyAll(CFG.fallback));
	};

	if( document.readyState === "loading" ){
		document.addEventListener("DOMContentLoaded", init);
	} else {
		init();
	}
})();
</script>
		<?php
	}
}
