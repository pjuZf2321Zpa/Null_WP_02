<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( !class_exists('ReyTheme_SurveyBox') ):
	/**
	 * Customer Survey dashbox.
	 *
	 * A compact, stepper-based survey (one question per step) shown as the second
	 * box on the Rey dashboard, above the Plugins Manager, on registered installs.
	 *
	 * Design constraints:
	 *  - Two-layer eligibility with NO blocking HTTP call on dashboard page load:
	 *    (1) a cached campaign flag read from the `rey_versions_data` transient, and
	 *    (2) a per-license state fetched by a background admin-ajax call and cached
	 *        locally in a transient, keyed by a hash of the license key.
	 *  - The browser never talks to the Rey API directly: it posts to admin-ajax,
	 *    which proxies the call server-to-server via `ReyTheme_API`.
	 *  - Assets are page-scoped to the Rey dashboard screen only.
	 *
	 * Modeled on {@see ReyTheme_PluginsBox}: skeleton shell + lazy AJAX hydration.
	 *
	 * @since 3.2.0
	 */
	class ReyTheme_SurveyBox
	{
		/**
		 * Prefix for the locally cached per-license state transient. The full key
		 * appends a hash of the license key, so the cache follows the license, not
		 * the install.
		 */
		const STATE_TRANSIENT_PREFIX = 'rey_survey_state_';

		/**
		 * How long the locally cached state is trusted before the background call
		 * refreshes it from the API.
		 */
		const STATE_TTL = 12 * HOUR_IN_SECONDS;

		/**
		 * Fallback campaign id, used only when `versions.json` does not carry one
		 * (dev/testing). In production the id always comes from the remote payload.
		 */
		const DEFAULT_SURVEY_ID = 'rey_customer_survey_2026_q3';

		/**
		 * Rey API endpoint paths this module owns. Kept here (not in ReyTheme_API)
		 * so the whole survey lives in one file and leaves no trace elsewhere when
		 * removed. `RESPONSE` is the single save/submit endpoint — a `final` flag
		 * distinguishes the per-step autosave from the final submission.
		 */
		const ENDPOINT_DEFINITION = 'survey_definition/';
		const ENDPOINT_STATUS     = 'survey_status/';
		const ENDPOINT_RESPONSE   = 'survey_response/';
		const ENDPOINT_DISMISS    = 'survey_dismiss/';
		const ENDPOINT_RESET      = 'survey_reset/';

		/**
		 * Shared nonce action with the rest of the dashboard AJAX surface.
		 */
		const NONCE_ACTION = 'rey_dashboard_nonce';

		/**
		 * Max length for the short "Other (please specify)" free-text inputs.
		 */
		const OTHER_MAX = 200;

		/**
		 * Max length for the open-feedback textarea (Q7).
		 */
		const FEEDBACK_MAX = 2000;

		/**
		 * Slug of the dedicated survey admin page (submenu of the Rey dashboard).
		 */
		const PAGE_SLUG = 'rey-survey';

		/**
		 * Autoloaded "gate" that precomputes whether the menu item + teaser should
		 * show, so every admin page load costs one autoloaded option read instead
		 * of the full (transient-hitting) eligibility check. Refreshed off the
		 * critical path via a throttled cron event.
		 */
		const GATE_OPTION  = 'rey_survey_gate';
		const GATE_TTL     = 12 * HOUR_IN_SECONDS;
		const GATE_LOCK    = 5 * MINUTE_IN_SECONDS;

		/**
		 * Hook suffix of the dedicated survey page, captured at registration so the
		 * assets enqueue matches it exactly.
		 */
		private static $page_hook = null;

		public function __construct()
		{
			add_action( 'wp_ajax_rey_survey_state',   [ $this, 'ajax_state' ] );
			add_action( 'wp_ajax_rey_survey_content', [ $this, 'ajax_content' ] );
			add_action( 'wp_ajax_rey_survey_save',    [ $this, 'ajax_save' ] );
			add_action( 'wp_ajax_rey_survey_submit',  [ $this, 'ajax_submit' ] );
			add_action( 'wp_ajax_rey_survey_dismiss', [ $this, 'ajax_dismiss' ] );

			add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );

			// Dedicated page + menu badge (both gated on the cheap autoloaded gate),
			// and the throttled off-page refresh that keeps that gate current — via
			// a non-blocking browser ping (reliable everywhere; WP-Cron loopback is
			// flaky on local installs and some hosts).
			add_action( 'admin_menu', [ $this, 'admin_menu' ], 6 );
			add_action( 'admin_footer', [ $this, 'maybe_print_gate_refresh' ] );
			add_action( 'wp_ajax_rey_survey_gate', [ $this, 'ajax_gate' ] );

			// Register the dashboard teaser box ourselves (priority 30 slots it
			// after the registration box and before the Plugins Manager), so the
			// dashboard carries no survey-specific code and removing this module
			// leaves nothing behind there.
			add_action( 'rey/dashboard/boxes', [ $this, 'register_dashbox' ], 30 );

			// The survey lives in the theme, so its reset tool does too — register
			// it into rey-core's dashboard migration runner (dev/debug only).
			add_filter( 'reycore/migrations/scripts', [ $this, 'register_migration' ] );
		}

		/* ---------------------------------------------------------------------
		 * Eligibility
		 * ------------------------------------------------------------------- */

		/**
		 * The hard gates that must all pass before the survey does anything at all.
		 *
		 * @return bool
		 */
		public static function hard_gates_pass(){

			if ( ! current_user_can( 'manage_options' ) ){
				return false;
			}

			// Registered installs only.
			if ( ! ReyTheme_Base::get_purchase_code() ){
				return false;
			}

			// Respect the global banners opt-out (rey-core ACF option).
			if ( ! self::banners_enabled() ){
				return false;
			}

			return true;
		}

		/**
		 * Whether Rey's global "Periodic banners" opt-out allows messaging. Honored
		 * only when rey-core (which owns the `rey_banners_enable` ACF option) is
		 * active; if the option/helper is unavailable, messaging is allowed.
		 *
		 * @return bool
		 */
		public static function banners_enabled(){

			if ( ! function_exists('reycore__acf_get_field') || ! defined('REY_CORE_THEME_NAME') ){
				return true;
			}

			$field = reycore__acf_get_field( 'rey_banners_enable', REY_CORE_THEME_NAME );

			// Not-yet-set defaults to enabled, matching the ACF field default.
			return is_null( $field ) || (bool) $field === true;
		}

		/**
		 * The campaign descriptor (id + enabled flag) read from the cached versions
		 * payload. Read only — never triggers a fetch here, so it adds no request
		 * to page load. Returns:
		 *   - [ 'id' => string, 'enabled' => true ]  when a campaign is live
		 *   - [ 'enabled' => false ]                  when known-disabled
		 *   - null                                    when unknown (cache cold)
		 *
		 * @param bool $allow_fetch Populate the versions cache if cold (background
		 *                          AJAX only — never on page render).
		 * @return array|null
		 */
		public static function get_campaign( $allow_fetch = false ){

			$transient = class_exists('ReyTheme_Updates') ? ReyTheme_Updates::VERSIONS_TRANSIENT : 'rey_versions_data';
			$data = get_transient( $transient );

			if ( false === $data && $allow_fetch ){
				// Piggyback on the same hourly versions payload the update system
				// uses, and share its cache. Happens only in the background call.
				$data = ReyTheme_API::getInstance()->get_main_versions();
				if ( ! is_wp_error( $data ) ){
					set_transient( $transient, $data, HOUR_IN_SECONDS );
				}
			}

			if ( ! ( is_array( $data ) && isset( $data['data']['survey'] ) && is_array( $data['data']['survey'] ) ) ){
				return $allow_fetch ? [ 'enabled' => false ] : null;
			}

			$survey = $data['data']['survey'];

			if ( empty( $survey['enabled'] ) ){
				return [ 'enabled' => false ];
			}

			$campaign = [
				'id'      => isset( $survey['id'] ) ? sanitize_key( $survey['id'] ) : self::DEFAULT_SURVEY_ID,
				'enabled' => true,
			];

			// Optional remote copy overrides (dashbox title + intro). Present only
			// when set on the server; kept raw here and escaped at output.
			foreach ( [ 'title', 'intro' ] as $copy_key ) {
				if ( isset( $survey[ $copy_key ] ) && '' !== trim( (string) $survey[ $copy_key ] ) ) {
					$campaign[ $copy_key ] = (string) $survey[ $copy_key ];
				}
			}

			return $campaign;
		}

		/**
		 * Current campaign id, best-effort.
		 *
		 * @return string
		 */
		public static function get_survey_id(){
			$campaign = self::get_campaign();
			return ( $campaign && ! empty( $campaign['id'] ) ) ? $campaign['id'] : self::DEFAULT_SURVEY_ID;
		}

		/**
		 * The dashbox title: the campaign's remote override when set, otherwise the
		 * theme's own translatable default. Returned raw — escape at output.
		 *
		 * @return string
		 */
		public static function get_title(){
			$campaign = self::get_campaign();
			if ( is_array( $campaign ) && ! empty( $campaign['title'] ) ){
				return (string) $campaign['title'];
			}
			return __( 'Help shape Rey', 'rey' );
		}

		/**
		 * The intro paragraph shown above the questions: remote override when set,
		 * otherwise the theme's translatable default. Returned raw — escape at output.
		 *
		 * @return string
		 */
		public static function get_intro(){
			$campaign = self::get_campaign();
			if ( is_array( $campaign ) && ! empty( $campaign['intro'] ) ){
				return (string) $campaign['intro'];
			}
			return __( 'A few quick questions to help shape the roadmap. About 2 minutes, and you can stop anytime.', 'rey' );
		}

		/**
		 * Whether the campaign is known and switched off. When true, the box never
		 * renders and no further calls are made.
		 *
		 * @return bool
		 */
		public static function is_campaign_disabled(){
			$campaign = self::get_campaign();
			return is_array( $campaign ) && empty( $campaign['enabled'] );
		}

		/**
		 * Local state transient key, scoped to the license key.
		 *
		 * @return string
		 */
		private static function state_key(){
			$code = ReyTheme_Base::get_purchase_code();
			return self::STATE_TRANSIENT_PREFIX . substr( hash( 'sha256', $code ? $code : 'none' ), 0, 20 );
		}

		/**
		 * Read the locally cached state (or false when cold).
		 *
		 * @return array|false [ state, snoozed_until ]
		 */
		public static function get_cached_state(){
			return get_transient( self::state_key() );
		}

		/**
		 * Persist the cached state.
		 *
		 * @param array $state
		 */
		public static function set_cached_state( $state ){
			set_transient( self::state_key(), $state, self::STATE_TTL );
		}

		/**
		 * Whether a given state means "show the box now".
		 *
		 * @param array|false $state
		 * @return bool
		 */
		public static function state_is_showable( $state ){

			if ( ! ( is_array( $state ) && isset( $state['state'] ) ) ){
				return false;
			}

			if ( 'eligible' === $state['state'] ){
				return true;
			}

			// A snooze that has elapsed becomes showable (the one final showing).
			if ( 'snoozed' === $state['state'] && ! empty( $state['snoozed_until'] ) ){
				return time() >= (int) $state['snoozed_until'];
			}

			return false;
		}

		/**
		 * Whether to server-render the box on this page load. Requires the hard
		 * gates, a known-enabled campaign, and a locally cached "showable" state.
		 * Unknown campaign (cold versions cache) does not render — the background
		 * call populates the cache so the box can appear right after / next load.
		 *
		 * @return bool
		 */
		public static function should_render(){

			if ( ! self::hard_gates_pass() ){
				return false;
			}

			$campaign = self::get_campaign();

			if ( ! ( is_array( $campaign ) && ! empty( $campaign['enabled'] ) ) ){
				return false;
			}

			return self::state_is_showable( self::get_cached_state() );
		}

		/**
		 * Whether to enqueue the survey assets on this screen. Broader than
		 * should_render(): the assets must load even on a cold cache so the
		 * background state call can bootstrap the box. Suppressed only when the
		 * campaign is positively known to be disabled.
		 *
		 * @return bool
		 */
		public static function should_enqueue(){
			return self::hard_gates_pass() && ! self::is_campaign_disabled();
		}

		/* ---------------------------------------------------------------------
		 * Cheap gate + dedicated page
		 *
		 * The survey also lives on its own admin page (a submenu of the Rey
		 * dashboard) with a menu badge, so it is discoverable without opening the
		 * dashboard. To keep that from taxing EVERY admin page load, the "show it"
		 * decision is precomputed into one AUTOLOADED option (already in the
		 * alloptions bundle WP loads once per request). Per page load we only read
		 * that option and check a capability — no transient, no per-page query. The
		 * real eligibility (which hits transients / the server) is recomputed off
		 * the critical path, throttled, via a single-shot cron event.
		 * ------------------------------------------------------------------- */

		/**
		 * The precomputed gate: [ 'show' => 0|1, 'until' => int ], or null.
		 */
		private static function get_gate(){
			$gate = get_option( self::GATE_OPTION );
			return is_array( $gate ) ? $gate : null;
		}

		/**
		 * Persist the gate decision with a fresh TTL. Autoloaded.
		 *
		 * @param bool $show
		 * @param int  $ttl
		 */
		private static function set_gate( $show, $ttl = self::GATE_TTL ){
			update_option( self::GATE_OPTION, [
				'show'  => $show ? 1 : 0,
				'until' => time() + (int) $ttl,
			], true );
		}

		/**
		 * Whether the menu item / teaser should show right now. O(1): a capability
		 * check + one autoloaded option read. No transient, no query.
		 *
		 * @return bool
		 */
		public static function gate_shows(){
			if ( ! current_user_can( 'manage_options' ) ){
				return false;
			}
			$gate = self::get_gate();
			return is_array( $gate ) && ! empty( $gate['show'] );
		}

		/**
		 * Recompute the gate from the real eligibility and persist it. This is the
		 * only place the heavier checks run — off the page render, from the
		 * throttled cron event (or right after a submit/dismiss).
		 *
		 * @return bool the decision written
		 */
		public static function refresh_gate(){

			$show = false;

			// SITE-level eligibility only. This runs from cron, where there is no
			// current user, so it must NOT use hard_gates_pass() (that includes a
			// manage_options check). The per-user capability is enforced separately
			// in gate_shows() / admin_menu, which run in a real admin page context.
			if ( ReyTheme_Base::get_purchase_code() && self::banners_enabled() ){
				$campaign = self::get_campaign( true ); // may warm the versions cache
				if ( is_array( $campaign ) && ! empty( $campaign['enabled'] ) ){
					$show = self::state_is_showable( self::resolve_state( true ) );
				}
			}

			self::set_gate( $show );

			return $show;
		}

		/**
		 * On admin pages, if the gate is stale, print a single non-blocking browser
		 * ping (after the page renders) that recomputes the gate server-side. A
		 * short optimistic lock keeps it from firing again while in flight. Cheap:
		 * capability + one autoloaded read + an integer compare; steady state (a
		 * fresh gate) prints nothing and writes nothing.
		 */
		public function maybe_print_gate_refresh(){

			if ( ! current_user_can( 'manage_options' ) ){
				return;
			}

			$gate  = self::get_gate();
			$until = ( is_array( $gate ) && isset( $gate['until'] ) ) ? (int) $gate['until'] : 0;

			if ( time() < $until ){
				return; // still fresh (or locked) — print nothing
			}

			// Optimistic lock: hold the last known decision for a few minutes so
			// concurrent loads do not pile up pings; the ping resets the full TTL.
			self::set_gate( is_array( $gate ) && ! empty( $gate['show'] ), self::GATE_LOCK );

			$url   = admin_url( 'admin-ajax.php' );
			$nonce = wp_create_nonce( self::NONCE_ACTION );
			?>
			<script>
			( function () {
				var body = new FormData();
				body.append( 'action', 'rey_survey_gate' );
				body.append( 'security', '<?php echo esc_js( $nonce ); ?>' );
				window.fetch( '<?php echo esc_url_raw( $url ); ?>', { method: 'POST', body: body, credentials: 'same-origin', keepalive: true } );
			} )();
			</script>
			<?php
		}

		/**
		 * Recompute the gate. Non-blocking, fire-and-forget target of the browser
		 * ping in maybe_print_gate_refresh().
		 */
		public function ajax_gate(){

			if ( ! check_ajax_referer( self::NONCE_ACTION, 'security', false ) ){
				wp_send_json_error();
			}

			if ( ! current_user_can( 'manage_options' ) ){
				wp_send_json_error();
			}

			self::refresh_gate();

			wp_send_json_success();
		}

		/* ---------------------------------------------------------------------
		 * Menu + dedicated page
		 * ------------------------------------------------------------------- */

		/**
		 * Register the dashboard teaser box. Self-contained here (rather than in
		 * dashboard.php) so the dashboard carries no survey-specific code; deleting
		 * this module removes the box with it. Priority 30 (set at the add_action)
		 * places it right after the registration box and above the Plugins Manager.
		 */
		public function register_dashbox(){

			$force = class_exists( 'ReyTheme_Dashboard' ) && ReyTheme_Dashboard::force_show_dashboxes();

			if ( ! $force ){
				$excluded = rey__get_props( 'excluded_dashboxes' );
				if ( $excluded && in_array( 'survey', $excluded, true ) ){
					return;
				}
				if ( ! self::gate_shows() ){
					return;
				}
			}

			require_once REY_THEME_DIR . '/inc/core/admin/dashbox-survey.php';
		}

		/**
		 * Register the dedicated survey page, only when the gate says to.
		 */
		public function admin_menu(){

			if ( ! self::gate_shows() ){
				return;
			}

			self::$page_hook = add_submenu_page(
				ReyTheme_Base::DASHBOARD_PAGE_ID,
				esc_html__( 'Help shape Rey', 'rey' ),
				esc_html__( 'Help shape Rey', 'rey' ),
				'manage_options',
				self::PAGE_SLUG,
				[ $this, 'render_page' ],
				1
			);
		}

		/**
		 * The dedicated, focused survey page: the same box, centered, with room to
		 * breathe. Reuses render_shell() + the page-scoped script, so the stepper
		 * hydrates exactly as it does in the dashbox.
		 */
		public function render_page(){
			?>
			<div class="wrap">
				<div class="rey-surveyPage" style="max-width:740px;margin:10vh auto 40px;">
					<?php echo self::render_shell(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup pre-escaped in render_shell(). ?>
				</div>
			</div>
			<?php
		}

		/* ---------------------------------------------------------------------
		 * Assets (page-scoped)
		 * ------------------------------------------------------------------- */

		/**
		 * The dashboard screen's hook suffix (top-level menu page).
		 */
		public static function dashboard_hook(){
			return 'toplevel_page_' . ReyTheme_Base::DASHBOARD_PAGE_ID;
		}

		/**
		 * Enqueue the dedicated survey JS/CSS pair, on the dedicated survey page
		 * only (the dashboard now shows a static teaser that needs no survey JS).
		 * On every other admin page this is a single string comparison and returns.
		 *
		 * @param string $hook
		 */
		public function enqueue_assets( $hook ){

			if ( ! self::$page_hook || $hook !== self::$page_hook ){
				return;
			}

			wp_enqueue_style(
				'rey-admin-survey',
				REY_THEME_URI . '/assets/css/rey-admin-survey.css',
				[ 'rey-admin-styles' ],
				REY_THEME_VERSION
			);

			wp_enqueue_script(
				'rey-admin-survey',
				REY_THEME_URI . '/assets/js/rey-admin-survey.js',
				[ 'jquery', 'masonry' ],
				REY_THEME_VERSION,
				true
			);

			wp_localize_script( 'rey-admin-survey', 'reySurveyParams', [
				'ajax_url'         => admin_url( 'admin-ajax.php' ),
				'nonce'            => wp_create_nonce( self::NONCE_ACTION ),
				'strings'          => self::js_strings(),
				// The survey script only loads on the dedicated page now, so a
				// dismiss there should return to the dashboard, not blank the page.
				'dismiss_redirect' => admin_url( 'admin.php?page=' . ReyTheme_Base::DASHBOARD_PAGE_ID ),
			] );
		}

		/**
		 * Translatable strings handed to the stepper script.
		 *
		 * @return array
		 */
		public static function js_strings(){
			return [
				'progress'    => esc_html__( 'Question %1$s of %2$s', 'rey' ),
				'next'        => esc_html__( 'Next', 'rey' ),
				'back'        => esc_html__( 'Back', 'rey' ),
				'submit'      => esc_html__( 'Send answers', 'rey' ),
				'sending'     => esc_html__( 'Sending', 'rey' ),
				'required'    => esc_html__( 'Please answer this question to continue.', 'rey' ),
				'specify'     => esc_html__( 'Please specify.', 'rey' ),
				'min_one'     => esc_html__( 'Please select at least one option.', 'rey' ),
				'max_three'   => esc_html__( 'You can select up to 3 options.', 'rey' ),
				'error'       => esc_html__( 'Something went wrong. Please try again.', 'rey' ),
				'thanks_title'=> esc_html__( 'Thank you!', 'rey' ),
				'thanks_text' => esc_html__( 'Your answers help shape what we build next in Rey.', 'rey' ),
			];
		}

		/* ---------------------------------------------------------------------
		 * Survey definition
		 *
		 * The questions (copy + rules) are fetched from the Rey API and rendered
		 * as-is; the theme carries no question copy of its own. So a wording change
		 * or a new question ships from the API with no theme update.
		 * ------------------------------------------------------------------- */

		/**
		 * The active question definition (id => descriptor), fetched from the
		 * server and cached, or null when it cannot be loaded. A null result means
		 * the survey simply does not render (same as any other "API unavailable"
		 * degrade).
		 *
		 * @return array|null
		 */
		public static function get_definition(){

			$survey_id = self::get_survey_id();
			$key       = 'rey_survey_def_' . substr( hash( 'sha256', $survey_id ), 0, 20 );

			$cached = get_transient( $key );
			if ( is_array( $cached ) ){
				return $cached;
			}

			$response = self::api_get( self::ENDPOINT_DEFINITION, [ 'survey_id' => $survey_id ] );

			if ( is_wp_error( $response ) || ! ( isset( $response['data']['questions'] ) && is_array( $response['data']['questions'] ) ) ){
				return null;
			}

			$definition = self::normalize_definition( $response['data']['questions'] );

			if ( $definition ){
				set_transient( $key, $definition, self::STATE_TTL );
			}

			return $definition;
		}

		/**
		 * Convert the server's wire shape (ordered list, options as [slug,label]
		 * pairs) into the internal keyed structure the renderer expects. All copy
		 * is escaped at output time, so it is stored as-is here.
		 *
		 * @param array $wire
		 * @return array|null
		 */
		private static function normalize_definition( $wire ){

			if ( ! is_array( $wire ) ){
				return null;
			}

			$out = [];

			foreach ( $wire as $item ){

				if ( empty( $item['id'] ) || empty( $item['type'] ) ){
					continue;
				}

				$id = sanitize_key( $item['id'] );

				$q = [
					'type'     => sanitize_key( $item['type'] ),
					'required' => ! empty( $item['required'] ),
					'title'    => isset( $item['title'] ) ? (string) $item['title'] : '',
				];

				foreach ( [ 'has_other', 'randomize' ] as $flag ){
					if ( ! empty( $item[ $flag ] ) ){
						$q[ $flag ] = true;
					}
				}

				if ( ! empty( $item['pin_last'] ) ){
					$q['pin_last'] = sanitize_key( $item['pin_last'] );
				}

				foreach ( [ 'min', 'max', 'maxlength' ] as $num ){
					if ( isset( $item[ $num ] ) ){
						$q[ $num ] = (int) $item[ $num ];
					}
				}

				foreach ( [ 'label_min', 'label_max' ] as $lbl ){
					if ( isset( $item[ $lbl ] ) ){
						$q[ $lbl ] = (string) $item[ $lbl ];
					}
				}

				if ( ! empty( $item['options'] ) && is_array( $item['options'] ) ){
					$q['options'] = [];
					foreach ( $item['options'] as $opt ){
						if ( isset( $opt['slug'] ) ){
							$slug = sanitize_key( $opt['slug'] );
							$q['options'][ $slug ] = isset( $opt['label'] ) ? (string) $opt['label'] : $slug;
						}
					}
				}

				$out[ $id ] = $q;
			}

			return $out ? $out : null;
		}

		/**
		 * Ordered option slugs for a question, applying per-render randomization
		 * and the pinned-last slug where configured.
		 *
		 * @param array $q
		 * @return array
		 */
		private static function rendered_option_order( $q ){

			if ( empty( $q['options'] ) ){
				return [];
			}

			$slugs = array_keys( $q['options'] );

			if ( empty( $q['randomize'] ) ){
				return $slugs;
			}

			$pin = ! empty( $q['pin_last'] ) ? $q['pin_last'] : null;

			if ( $pin ){
				$slugs = array_values( array_diff( $slugs, [ $pin ] ) );
			}

			shuffle( $slugs );

			if ( $pin ){
				$slugs[] = $pin;
			}

			return $slugs;
		}

		/* ---------------------------------------------------------------------
		 * Markup
		 * ------------------------------------------------------------------- */

		/**
		 * The box shell (title + dismiss + skeleton). Used both by the server-side
		 * template and by the background state call when it injects the box live.
		 *
		 * @return string
		 */
		public static function render_shell(){

			ob_start(); ?>

			<div class="rey-surveyBox js-reySurvey" data-nonce-action="<?php echo esc_attr( self::NONCE_ACTION ); ?>">
				<h1>
					<?php echo esc_html( self::get_title() ); ?>
				</h1>
				<div class="reySurvey js-reySurvey-body">
					<div class="reySurvey-skeleton" aria-hidden="true">
						<span></span><span></span><span></span><span></span>
					</div>
				</div>
			</div>

			<?php return ob_get_clean();
		}

		/**
		 * The stepper markup (all steps rendered; the script shows one at a time).
		 *
		 * @return string
		 */
		public static function render_stepper( $definition = null ){

			$questions = is_array( $definition ) ? $definition : self::get_definition();

			if ( empty( $questions ) ){
				return '';
			}

			$total = count( $questions );
			$index = 0;

			ob_start(); ?>

			<div class="reySurvey-stepper js-reySurvey-stepper" data-total="<?php echo esc_attr( $total ); ?>">

				<p class="reySurvey-intro"><?php echo esc_html( self::get_intro() ); ?></p>

				<div class="reySurvey-progress">
					<span class="reySurvey-progressText js-reySurvey-progressText"></span>
					<div class="reySurvey-progressBar"><span class="js-reySurvey-progressFill"></span></div>
				</div>

				<div class="reySurvey-error js-reySurvey-error" role="alert" hidden></div>

				<form class="reySurvey-form js-reySurvey-form" novalidate>
					<?php foreach ( $questions as $qid => $q ):
						$index++; ?>
						<div class="reySurvey-step" data-step="<?php echo esc_attr( $index ); ?>" data-qid="<?php echo esc_attr( $qid ); ?>" data-type="<?php echo esc_attr( $q['type'] ); ?>"<?php
							echo isset($q['min']) ? ' data-min="' . esc_attr( $q['min'] ) . '"' : '';
							echo isset($q['max']) ? ' data-max="' . esc_attr( $q['max'] ) . '"' : '';
							echo empty($q['required']) ? ' data-optional="1"' : '';
						?>>
							<h3 class="reySurvey-q">
								<?php echo esc_html( $q['title'] ); ?>
								<?php if ( empty( $q['required'] ) ): ?>
									<span class="reySurvey-optional"><?php esc_html_e( '(optional)', 'rey' ); ?></span>
								<?php endif; ?>
							</h3>
							<?php echo self::render_question_body( $qid, $q ); ?>
						</div>
					<?php endforeach; ?>
				</form>

				<div class="reySurvey-nav">
					<button type="button" class="rey-adminBtn reySurvey-btn --ghost js-reySurvey-back" hidden><?php esc_html_e( 'Back', 'rey' ); ?></button>
					<button type="button" class="rey-adminBtn rey-adminBtn-secondary reySurvey-btn js-reySurvey-next"><?php esc_html_e( 'Next', 'rey' ); ?></button>
					<button type="button" class="rey-adminBtn rey-adminBtn-secondary reySurvey-btn js-reySurvey-submit" hidden><?php esc_html_e( 'Send answers', 'rey' ); ?></button>
				</div>

				<p class="reySurvey-optout">
					<a href="#" class="js-reySurvey-dismiss"><?php esc_html_e( 'Not interested? Hide this', 'rey' ); ?></a>
				</p>

			</div>

			<?php return ob_get_clean();
		}

		/**
		 * The inputs for a single question.
		 *
		 * @param string $qid
		 * @param array  $q
		 * @return string
		 */
		private static function render_question_body( $qid, $q ){

			ob_start();

			if ( 'textarea' === $q['type'] ){ ?>
				<textarea class="reySurvey-textarea" name="<?php echo esc_attr( $qid ); ?>" rows="4" maxlength="<?php echo esc_attr( isset($q['maxlength']) ? $q['maxlength'] : self::FEEDBACK_MAX ); ?>" placeholder="<?php esc_attr_e( 'Your feedback (optional)', 'rey' ); ?>"></textarea>
				<?php return ob_get_clean();
			}

			if ( 'scale' === $q['type'] ){ ?>
				<div class="reySurvey-scale" role="radiogroup">
					<?php for ( $i = (int) $q['min']; $i <= (int) $q['max']; $i++ ): ?>
						<label class="reySurvey-scaleItem">
							<input type="radio" name="<?php echo esc_attr( $qid ); ?>" value="<?php echo esc_attr( $i ); ?>">
							<span class="reySurvey-scaleNum"><?php echo esc_html( $i ); ?></span>
						</label>
					<?php endfor; ?>
				</div>
				<div class="reySurvey-scaleLabels">
					<span><?php echo esc_html( $q['label_min'] ); ?></span>
					<span><?php echo esc_html( $q['label_max'] ); ?></span>
				</div>
				<?php return ob_get_clean();
			}

			// radio / checkbox
			$input_type = 'checkbox' === $q['type'] ? 'checkbox' : 'radio';
			$order      = self::rendered_option_order( $q ); ?>

			<div class="reySurvey-options js-reySurvey-options">
				<?php foreach ( $order as $slug ):
					$label = isset( $q['options'][ $slug ] ) ? $q['options'][ $slug ] : $slug; ?>
					<label class="reySurvey-option">
						<input type="<?php echo esc_attr( $input_type ); ?>" name="<?php echo 'checkbox' === $input_type ? esc_attr( $qid ) . '[]' : esc_attr( $qid ); ?>" value="<?php echo esc_attr( $slug ); ?>" data-slug="<?php echo esc_attr( $slug ); ?>">
						<span class="reySurvey-optionMark" aria-hidden="true"></span>
						<span class="reySurvey-optionLabel"><?php echo esc_html( $label ); ?></span>
					</label>
				<?php endforeach; ?>

				<?php if ( ! empty( $q['has_other'] ) ): ?>
					<div class="reySurvey-other js-reySurvey-other" hidden>
						<input type="text" class="reySurvey-otherInput" name="<?php echo esc_attr( $qid ); ?>_other" maxlength="<?php echo esc_attr( self::OTHER_MAX ); ?>" placeholder="<?php esc_attr_e( 'Please specify', 'rey' ); ?>">
					</div>
				<?php endif; ?>
			</div>

			<?php return ob_get_clean();
		}

		/* ---------------------------------------------------------------------
		 * Sanitizing
		 *
		 * The theme does not re-validate answers against a schema: the browser
		 * validates for instant feedback (from the rendered markup), and the API
		 * validates on its side. Here we only lightly clean the posted answers
		 * before forwarding — preserve newlines (feedback is multi-line), cap
		 * lengths, keep the array shape (checkbox answers).
		 * ------------------------------------------------------------------- */

		/**
		 * Schema-free recursive sanitize of the posted answers / render meta.
		 *
		 * @param mixed $value
		 * @return mixed
		 */
		private static function light_sanitize( $value ){

			if ( is_array( $value ) ){
				$out = [];
				foreach ( $value as $k => $v ){
					$out[ sanitize_key( $k ) ] = self::light_sanitize( $v );
				}
				return $out;
			}

			return mb_substr( sanitize_textarea_field( (string) $value ), 0, self::FEEDBACK_MAX );
		}

		/**
		 * Sanitize the recorded render order for the shuffled questions.
		 *
		 * @param array $raw
		 * @return array
		 */
		private static function sanitize_render_meta( $raw ){

			$out = [];

			foreach ( [ 'q2', 'q3', 'q5' ] as $qid ){
				$key = $qid . '_order';
				if ( isset( $raw[ $key ] ) && is_array( $raw[ $key ] ) ){
					$out[ $key ] = array_values( array_map( 'sanitize_key', $raw[ $key ] ) );
				}
			}

			return $out;
		}

		/* ---------------------------------------------------------------------
		 * Payload assembly
		 * ------------------------------------------------------------------- */

		/**
		 * Build the wire payload sent to the Rey API.
		 *
		 * @param array $answers     sanitized answers
		 * @param array $render_meta sanitized render order
		 * @return array
		 */
		private static function build_payload( $answers, $render_meta ){

			return [
				'survey_id'   => self::get_survey_id(),
				'answers'     => $answers,
				'render_meta' => $render_meta,
				'env_meta'    => [
					'rey_version'        => REY_THEME_VERSION,
					'wp_version'         => get_bloginfo( 'version' ),
					'woocommerce_active' => class_exists( 'WooCommerce' ),
					'elementor_active'   => defined( 'ELEMENTOR_VERSION' ),
					'site_hash'          => hash( 'sha256', home_url() ),
					'locale'             => get_locale(),
				],
			];
		}

		/* ---------------------------------------------------------------------
		 * API transport
		 *
		 * Every server call goes through ReyTheme_API::request() (a generic public
		 * passthrough), so the survey owns its own endpoint strings and adds no
		 * bespoke methods to the shared API class. The purchase code is attached
		 * here, since all survey endpoints require it.
		 * ------------------------------------------------------------------- */

		/**
		 * GET a survey endpoint with the purchase code attached.
		 *
		 * @param string $endpoint
		 * @param array  $args
		 * @return array|\WP_Error
		 */
		private static function api_get( $endpoint, $args = [] ){
			$args['purchase_code'] = ReyTheme_Base::get_purchase_code();
			return ReyTheme_API::getInstance()->request( $endpoint, $args, 'get' );
		}

		/**
		 * POST a survey endpoint with the purchase code attached.
		 *
		 * @param string $endpoint
		 * @param array  $args
		 * @return array|\WP_Error
		 */
		private static function api_post( $endpoint, $args = [] ){
			$args['purchase_code'] = ReyTheme_Base::get_purchase_code();
			return ReyTheme_API::getInstance()->request( $endpoint, $args, 'post' );
		}

		/* ---------------------------------------------------------------------
		 * AJAX
		 * ------------------------------------------------------------------- */

		/**
		 * Shared AJAX guard (nonce + capability + hard gates).
		 */
		private function guard(){

			if ( ! check_ajax_referer( self::NONCE_ACTION, 'security', false ) ){
				wp_send_json_error( esc_html__( 'Invalid security nonce!', 'rey' ) );
			}

			if ( ! current_user_can( 'manage_options' ) ){
				wp_send_json_error( esc_html__( 'Operation not allowed!', 'rey' ) );
			}

			if ( ! self::hard_gates_pass() ){
				wp_send_json_error( esc_html__( 'The survey is not available.', 'rey' ) );
			}
		}

		/**
		 * Resolve the current survey state, calling the API only when the local
		 * cache is cold.
		 *
		 * @param bool $allow_remote
		 * @return array [ state, snoozed_until ]
		 */
		public static function resolve_state( $allow_remote = true ){

			$cached = self::get_cached_state();

			if ( is_array( $cached ) ){
				return $cached;
			}

			if ( ! $allow_remote ){
				return [ 'state' => 'unknown' ];
			}

			$response = self::api_get( self::ENDPOINT_STATUS, [ 'survey_id' => self::get_survey_id() ] );

			$state = self::normalize_state_response( $response );

			// Only cache a definitive answer; leave "unknown" uncached so the next
			// load retries (API was unreachable).
			if ( 'unknown' !== $state['state'] ){
				self::set_cached_state( $state );
			}

			return $state;
		}

		/**
		 * Map an API status/dismiss response to the local state shape.
		 *
		 * @param mixed $response
		 * @return array
		 */
		private static function normalize_state_response( $response ){

			if ( is_wp_error( $response ) || ! is_array( $response ) ){
				return [ 'state' => 'unknown' ];
			}

			$data  = isset( $response['data'] ) && is_array( $response['data'] ) ? $response['data'] : $response;
			$state = isset( $data['state'] ) ? sanitize_key( $data['state'] ) : 'unknown';

			$allowed = [ 'eligible', 'snoozed', 'completed', 'dismissed' ];
			if ( ! in_array( $state, $allowed, true ) ){
				$state = 'unknown';
			}

			return [
				'state'         => $state,
				'snoozed_until' => isset( $data['snoozed_until'] ) ? (int) $data['snoozed_until'] : null,
			];
		}

		/**
		 * Background, non-blocking state resolver. Populates the local cache and,
		 * when showable, hands back the box shell so the script can inject it.
		 */
		public function ajax_state(){

			$this->guard();

			// Read (and, being the background call, may warm) the cached campaign
			// flag. Disabled means render nothing and make no further calls.
			$campaign = self::get_campaign( true );

			if ( ! ( is_array( $campaign ) && ! empty( $campaign['enabled'] ) ) ){
				wp_send_json_success( [ 'state' => 'disabled', 'showable' => false ] );
			}

			$state    = self::resolve_state( true );
			$showable = self::state_is_showable( $state );

			wp_send_json_success( [
				'state'    => $state['state'],
				'showable' => $showable,
				'box_html' => $showable ? self::render_shell() : '',
			] );
		}

		/**
		 * Lazy-load the stepper markup into the shell. Fetches the question
		 * definition from the server (cached); if it cannot be loaded, the box is
		 * removed client-side.
		 */
		public function ajax_content(){

			$this->guard();

			$html = self::render_stepper( self::get_definition() );

			if ( '' === $html ){
				wp_send_json_error( esc_html__( 'The survey could not be loaded. Please try again later.', 'rey' ) );
			}

			wp_send_json_success( [ 'html' => $html ] );
		}

		/**
		 * Per-step partial autosave. Fire-and-forget.
		 */
		public function ajax_save(){

			$this->guard();

			$answers     = self::light_sanitize( isset( $_POST['answers'] ) ? (array) wp_unslash( $_POST['answers'] ) : [] );
			$render_meta = self::sanitize_render_meta( isset( $_POST['render_meta'] ) ? (array) wp_unslash( $_POST['render_meta'] ) : [] );

			$payload  = self::build_payload( $answers, $render_meta );
			$response = self::api_post( self::ENDPOINT_RESPONSE, array_merge( $payload, [ 'final' => 0 ] ) );

			if ( is_wp_error( $response ) ){
				wp_send_json_error( $response->get_error_message() );
			}

			wp_send_json_success();
		}

		/**
		 * Final submission. Marks complete locally and surfaces the coupon when the
		 * response carries one.
		 */
		public function ajax_submit(){

			$this->guard();

			$answers     = self::light_sanitize( isset( $_POST['answers'] ) ? (array) wp_unslash( $_POST['answers'] ) : [] );
			$render_meta = self::sanitize_render_meta( isset( $_POST['render_meta'] ) ? (array) wp_unslash( $_POST['render_meta'] ) : [] );

			$payload  = self::build_payload( $answers, $render_meta );
			$response = self::api_post( self::ENDPOINT_RESPONSE, array_merge( $payload, [ 'final' => 1 ] ) );

			if ( is_wp_error( $response ) ){
				wp_send_json_error( $response->get_error_message() );
			}

			// Hide on the very next load regardless of what the response carries,
			// and drop the menu badge right away.
			self::set_cached_state( [ 'state' => 'completed' ] );
			self::set_gate( false );

			$data = ( is_array( $response ) && isset( $response['data'] ) && is_array( $response['data'] ) ) ? $response['data'] : [];

			wp_send_json_success( [
				'coupon'      => isset( $data['coupon'] ) ? sanitize_text_field( $data['coupon'] ) : '',
				'coupon_text' => isset( $data['coupon_text'] ) ? sanitize_text_field( $data['coupon_text'] ) : '',
			] );
		}

		/**
		 * Record a dismissal and hide immediately (local cache) as well as
		 * server-side.
		 */
		public function ajax_dismiss(){

			$this->guard();

			$response = self::api_post( self::ENDPOINT_DISMISS, [
				'survey_id' => self::get_survey_id(),
			] );

			$state = self::normalize_state_response( $response );

			// If the server was unreachable, still hide locally for the snooze
			// window so the box does not nag; the next refresh reconciles.
			if ( 'unknown' === $state['state'] ){
				$state = [ 'state' => 'snoozed', 'snoozed_until' => time() + 14 * DAY_IN_SECONDS ];
			}

			self::set_cached_state( $state );
			self::set_gate( self::state_is_showable( $state ) );

			wp_send_json_success( [ 'state' => $state['state'] ] );
		}

		/* ---------------------------------------------------------------------
		 * Migration / reset tool
		 *
		 * Surfaced through rey-core's dashboard migration runner via the
		 * `reycore/migrations/scripts` filter, so the reset code stays with the
		 * feature (the theme) instead of being hardcoded in the plugin.
		 * ------------------------------------------------------------------- */

		/**
		 * Register the "Clear survey data" entry in the dashboard migration runner.
		 *
		 * @param array $scripts slug => [ 'label' => string, 'callback' => callable ]
		 * @return array
		 */
		public function register_migration( $scripts ){

			if ( ! is_array( $scripts ) ){
				return $scripts;
			}

			$scripts['clear_survey_data'] = [
				'label'    => 'Clear survey data',
				'callback' => [ __CLASS__, 'migration_clear_survey_data' ],
			];

			return $scripts;
		}

		/**
		 * Wipe this site's locally cached survey data so the dashbox re-syncs on the
		 * next load: every rey_survey_* transient (the per-license state and the
		 * question-definition cache, across campaigns), plus the shared versions
		 * payload that carries the campaign flag.
		 *
		 * Runs on the customer site, so it clears local caches only.
		 *
		 * @return string status line for the dashboard response
		 */
		public static function migration_clear_survey_data(){

			global $wpdb;

			// All rey_survey_* transients (state + definition). Enumerate the option
			// rows, then delete through the API so persistent object caches are
			// honored too. Both the value and its timeout row map to one key.
			$like       = $wpdb->esc_like( '_transient_rey_survey_' ) . '%';
			$like_to    = $wpdb->esc_like( '_transient_timeout_rey_survey_' ) . '%';
			$option_rows = $wpdb->get_col( $wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				$like,
				$like_to
			) );

			$keys = [];
			foreach ( (array) $option_rows as $name ) {
				$keys[ preg_replace( '/^_transient_(timeout_)?/', '', $name ) ] = true;
			}

			foreach ( array_keys( $keys ) as $key ) {
				delete_transient( $key );
			}

			// The shared versions payload the campaign flag rides on.
			$versions_transient = class_exists( 'ReyTheme_Updates' ) ? ReyTheme_Updates::VERSIONS_TRANSIENT : 'rey_versions_data';
			delete_transient( $versions_transient );
			delete_transient( 'rey_versions_data' );

			// Drop the precomputed menu/teaser gate so it is re-evaluated on the
			// next admin load.
			delete_option( self::GATE_OPTION );

			// Also ask the API to reset this license's response, so a completed or
			// dismissed survey becomes eligible again — a full reset, not just a
			// local cache clear (this tool is debug-only). Best-effort.
			$server_reset = ! is_wp_error( self::api_post( self::ENDPOINT_RESET, [ 'survey_id' => self::get_survey_id() ] ) );

			$count = count( $keys );

			return sprintf(
				'Cleared %d local survey cache %s + the versions cache%s. The survey will re-appear on the next load.',
				$count,
				1 === $count ? 'entry' : 'entries',
				$server_reset ? ', and reset the response on the API' : ' (API reset failed — check the API connection)'
			);
		}

	}

	new ReyTheme_SurveyBox;
endif;
