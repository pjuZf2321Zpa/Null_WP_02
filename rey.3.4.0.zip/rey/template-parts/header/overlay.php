<div class="rey-overlay rey-overlay--header" style="opacity:0;"></div>
