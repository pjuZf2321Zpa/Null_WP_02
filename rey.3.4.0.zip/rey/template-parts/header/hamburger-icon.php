<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

rey_assets()->add_styles(['rey-hbg', 'rey-header-icon']);

$classes = [
	'btn',
	'rey-mainNavigation-mobileBtn',
	'rey-headerIcon',
	'__hamburger',
];

$attributes = [
	'aria-label' => esc_html__('Open menu', 'rey'),
];

$args = rey__header_nav_params();

$hamburger_icon = '';

if(  ! empty($args['load_hamburger']) ){
	if( isset($args['load_hamburger']['attributes']) && ($custom_attributes = $args['load_hamburger']['attributes']) ){
		$attributes = array_merge($attributes, $custom_attributes);
	}
	if( isset($args['load_hamburger']['classes']) && ($custom_classes = $args['load_hamburger']['classes']) ){
		$classes = array_merge($classes, $custom_classes);
	}
	if( ! empty($args['load_hamburger']['icon']) ){
		$hamburger_icon = $args['load_hamburger']['icon'];
	}
} ?>

<button class="<?php echo esc_attr( implode(' ', $classes) ) ?>" <?php echo rey__implode_html_attributes( $attributes ) ?>>
	<?php if( $hamburger_icon ) {
		echo rey__get_svg_icon(['id' => $hamburger_icon]);
	} else { ?>
		<div class="__bars">
			<span class="__bar"></span>
			<span class="__bar"></span>
			<span class="__bar"></span>
		</div>
	<?php } ?>
	<?php echo rey__get_svg_icon(['id' => 'close']); ?>
</button>
<!-- .rey-mainNavigation-mobileBtn -->
