<?php
/**
 * Theme functions and definitions
 *
 * @package rey
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

update_site_option('rey_purchase_code', 'AAAAAAAA-1111-1111-1111-AAAAAAAAAAAA');

/**
 * GPL Vault: serve Rey's plugin/demo API and its package downloads from our mirror.
 * The `/file/` segment is part of the public bucket path - dropping it 404s everything.
 * Endpoint args arrive in $r['body'], not on $url; only the ?download_item= links use the query string.
 * Remove up to "END GPL Vault" to restore upstream behaviour.
 */
define( 'GPLVAULT_REY_API', 'https://dl.gplvault.com/file/gplvault/rey-api/' );
// The GPL Vault mirror still ships Rey Core 3.2.0.1, behind the 3.4.0 theme. Only Rey Core is taken from here.
define( 'GPLTIMES_REY_CORE', 'https://dl.gpltimes.com/file/gpltimes/rey/plugins/rey-core.zip' );

add_filter(
	'pre_http_request',
	function ( $preempt, $r, $url ) {

		$api      = 'https://api.reytheme.com/';
		$endpoint = $api . 'wp-json/rey-api/v1/';

		if ( 0 !== strpos( $url, $api ) ) {
			return $preempt;
		}

		$rey_arg = function ( $key ) use ( $r, $url ) {
			if ( isset( $r['body'][ $key ] ) && is_scalar( $r['body'][ $key ] ) ) {
				return sanitize_key( $r['body'][ $key ] );
			}
			$query = array();
			parse_str( (string) wp_parse_url( $url, PHP_URL_QUERY ), $query );
			return isset( $query[ $key ] ) ? sanitize_key( $query[ $key ] ) : '';
		};

		$rey_mirror = function ( $path ) use ( $r ) {
			$response = wp_remote_get( GPLVAULT_REY_API . $path, $r );
			if ( ! is_wp_error( $response ) && isset( $response['body'] ) && is_string( $response['body'] ) ) {
				// Both forms: JSON encodes the slashes as \/, plain text does not.
				$response['body'] = str_replace(
					array( 'dl.gplvault.com/gplvault/', 'dl.gplvault.com\\/gplvault\\/' ),
					array( 'dl.gplvault.com/file/gplvault/', 'dl.gplvault.com\\/file\\/gplvault\\/' ),
					$response['body']
				);
			}
			return $response;
		};

		// Package downloads, used by both the theme dashboard and WP's own updater.
		if ( false !== strpos( $url, 'download_item=' ) ) {
			$item = $rey_arg( 'download_item' );
			if ( ! $item ) {
				return $preempt;
			}
			if ( 'rey-core' === $item ) {
				return wp_remote_get( GPLTIMES_REY_CORE, $r );
			}
			$package = 'theme' === $item ? 'rey.zip' : 'plugins/' . $item . '.zip';
			return wp_remote_get( GPLVAULT_REY_API . $package, $r );
		}

		if ( 0 === strpos( $url, $endpoint . 'get_plugins' ) ) {
			$response = $rey_mirror( 'get_plugins.json' );
			if ( ! is_wp_error( $response ) && isset( $response['body'] ) && is_string( $response['body'] ) ) {
				$response['body'] = str_replace(
					array( GPLVAULT_REY_API . 'plugins/rey-core.zip', str_replace( '/', '\\/', GPLVAULT_REY_API . 'plugins/rey-core.zip' ) ),
					array( GPLTIMES_REY_CORE, str_replace( '/', '\\/', GPLTIMES_REY_CORE ) ),
					$response['body']
				);
			}
			return $response;
		}

		if ( 0 === strpos( $url, $endpoint . 'get_plugin_data' ) ) {
			$slug = $rey_arg( 'slug' );

			if ( ! $slug ) {
				return new WP_Error( 'missing_slug', 'Plugin slug is required' );
			}

			return array(
				'headers'  => array(),
				'body'     => wp_json_encode(
					array(
						'success' => true,
						'data'    => array(
							'download_url' => 'rey-core' === $slug ? GPLTIMES_REY_CORE : GPLVAULT_REY_API . 'plugins/' . $slug . '.zip',
						),
					)
				),
				'response' => array(
					'code'    => 200,
					'message' => 'OK',
				),
				'cookies'  => array(),
				'filename' => null,
			);
		}

		if ( 0 === strpos( $url, $endpoint . 'get_demos' ) ) {
			return $rey_mirror( 'get_demos.json' );
		}

		if ( 0 === strpos( $url, $endpoint . 'get_demo_data' ) ) {
			$slug = $rey_arg( 'slug' );

			if ( ! $slug ) {
				return new WP_Error( 'missing_slug', 'Demo slug is required' );
			}

			return $rey_mirror( 'demo-content/' . $slug . '.json' );
		}

		if ( $api . '?purchase_code=AAAAAAAA-1111-1111-1111-AAAAAAAAAAAA' === $url ) {
			return array(
				'headers'  => array(),
				'body'     => '<style>
                        img {
                            max-width: 100%;
                            height: auto;
                            margin-left: auto;
                            margin-right: auto;
                            margin-top: 25vh;
                            display: block;
                        }
                      </style>
                      <img src="https://media.giphy.com/media/xT9IgG50Fb7Mi0prBC/giphy.gif" alt="Hello!" />',
				'response' => array(
					'code'    => 200,
					'message' => 'OK',
				),
			);
		}

		return $preempt;
	},
	10,
	3
);
// END GPL Vault.

/**
 * Global Variables
 */
define('REY_THEME_DIR', get_template_directory());
define('REY_THEME_PARENT_DIR', get_stylesheet_directory());
define('REY_THEME_URI', get_template_directory_uri());
define('REY_THEME_PLACEHOLDER', REY_THEME_URI . '/assets/images/placeholder.png');
define('REY_THEME_NAME', 'rey');
define('REY_THEME_CORE_SLUG', 'rey-core');
define('REY_THEME_VERSION', '3.4.0' );
define('REY_THEME_REQUIRED_PHP_VERSION', '5.4.0' ); // Minimum required versions


/**
 * Load Core
 */
require_once REY_THEME_DIR . '/inc/core/core.php';
