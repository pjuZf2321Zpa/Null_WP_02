<?php
/**
 * Silence is gold
 */
?>