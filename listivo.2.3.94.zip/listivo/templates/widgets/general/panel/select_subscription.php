<?php

use Tangibledesign\Framework\Models\Payments\SelectSubscriptionInterface;
use Tangibledesign\Framework\Widgets\General\PanelWidget;

$userSubscription = tdf_current_user()->getUserSubscription();
$currentSubscription = $userSubscription ? $userSubscription->getSubscription() : null;
$lstCurrentUserSubscriptionList = tdf_app('current_user_subscription_list');

if ($lstCurrentUserSubscriptionList->isEmpty()) :
    ?>
    <div class="listivo-panel-head">
        <div class="listivo-container">
            <h1 class="listivo-panel-head__label">
                <?php echo esc_html(tdf_string('choose_a_subscription')); ?>
            </h1>
        </div>
    </div>

    <div class="listivo-panel-section">
        <div class="listivo-container">
            <div class="listivo-panel-section__content listivo-panel-section__content--no-margin-top listivo-panel-section__content--with-background">
                <div class="listivo-panel-no-listings">
                    <h2 class="listivo-panel-no-listings__heading">
                        <?php echo esc_html(tdf_string('no_subscriptions_available')); ?>
                    </h2>

                    <div class="listivo-panel-no-listings__button">
                        <?php if (tdf_payment_packages_repository()->getRegularPaymentPackagesForUser(tdf_current_user())->isNotEmpty()) : ?>
                            <a
                                    class="listivo-button listivo-button--primary-2"
                                    href="<?php echo esc_url(PanelWidget::getUrl(PanelWidget::ACTION_BUY_PACKAGE)); ?>"
                            >
                                <span>
                                    <?php echo esc_html(tdf_string('buy_the_package')); ?>

                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="11"
                                         viewBox="0 0 12 11"
                                         fill="none">
                                        <path d="M7.13805 10.4713C7.00772 10.6017 6.83738 10.6667 6.66671 10.6667C6.49605 10.6667 6.32571 10.6017 6.19538 10.4713C5.93504 10.211 5.93504 9.78898 6.19538 9.52865L9.72407 5.99996H0.666672C0.298669 5.99996 0 5.70129 0 5.33329C0 4.96528 0.298669 4.66662 0.666672 4.66662H9.72407L6.19538 1.13792C5.93504 0.877589 5.93504 0.455586 6.19538 0.195251C6.45571 -0.0650838 6.87771 -0.0650838 7.13805 0.195251L11.8047 4.86195C12.0651 5.12229 12.0651 5.54429 11.8047 5.80462L7.13805 10.4713Z"
                                              fill="#FDFDFE"/>
                                    </svg>
                                </span>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    return;
endif;
?>
<div class="listivo-panel-head">
    <div class="listivo-container">
        <h1 class="listivo-panel-head__label">
            <?php echo esc_html(tdf_string('choose_a_subscription')); ?>
        </h1>
    </div>
</div>

<div class="listivo-panel-section">
    <div class="listivo-container">
        <div class="listivo-panel-section__content listivo-panel-section__content--no-margin-top">
            <lst-select-subscription
                    request-url="<?php echo esc_url(tdf_action_url('tdf/subscriptions/select')); ?>"
                    confirm-downgrade-title="<?php echo esc_attr(tdf_string('confirm_downgrade_title')); ?>"
                    confirm-downgrade-text="<?php echo esc_attr(tdf_string('confirm_downgrade_text')); ?>"
                    confirm-downgrade-button-text="<?php echo esc_attr(tdf_string('confirm_downgrade_button_text')); ?>"
                    confirm-downgrade-cancel-button-text="<?php echo esc_attr(tdf_string('cancel')); ?>"
                <?php if ($currentSubscription) : ?>
                    current-subscription-key="<?php echo esc_attr($currentSubscription->getKey()); ?>"
                <?php endif; ?>
            >
                <div slot-scope="props">
                    <div class="listivo-panel-packages-v2">
                        <?php
                        global $subscription;
                        foreach (tdf_app('current_user_subscription_list') as $subscription) :
                            /* @var SelectSubscriptionInterface $subscription */
                            get_template_part('templates/widgets/general/panel/subscription_card');
                        endforeach;
                        ?>
                    </div>
                </div>
            </lst-select-subscription>
        </div>
    </div>
</div>
