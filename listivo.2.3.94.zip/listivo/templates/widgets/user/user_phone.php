<?php
/* @var \Tangibledesign\Framework\Widgets\User\UserPhoneWidget $lstCurrentWidget */
global $lstCurrentWidget;

$lstUser = $lstCurrentWidget->getUser();
if (!$lstUser) {
    return;
}

if (!$lstUser->hasPhone()) {
    return;
}

$lstPhone = $lstUser->getDisplayPhone();
?>
<a href="tel:<?php echo esc_attr($lstUser->getPhoneUrl()); ?>" class="listivo-user__phone">
    <?php echo esc_html($lstPhone); ?>
</a>