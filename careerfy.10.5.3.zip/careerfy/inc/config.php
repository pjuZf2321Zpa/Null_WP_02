<?php

/**
 * Careerfy Theme Config.
 *
 * @package Careerfy
 */
define("CAREERFY_VERSION", "10.5.3");
define("WP_JOBSEARCH_VERSION", "3.4.3");
define("CAREERFY_DEMO_VERSION", "2.5");
define("WPBAKERY_VERSION", "9.1");
define("REVSLIDER_VERSION", "7.2.10");
define("ADDON_MEETINGS_VERSION", "3.0");
define("ADDON_RESUME_EXPORT_VERSION", "4.9.2");
define("ADDON_CHAT_VERSION", "3.5");
define("ADDON_ALL_IMPORT_VERSION", "2.0");

function careerfy_framework_options() {
    global $careerfy_framework_options;
    if (empty($careerfy_framework_options)) {
        $careerfy_framework_options = get_option('careerfy_framework_options');
    }
    return $careerfy_framework_options;
}