<?php
/**
 * Result Count
 *
 * Shows text: Showing x - x of x results.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/result-count.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     10.8.0
 *
 * Careerfy customizations preserved on the WC 10.8.0 merge:
 *   - Outer `.careerfy-shop-filter` wrapper used by the shop page layout.
 *   - Inner `<span>` (instead of WC's `<p>`) so the result-count sits
 *     inline next to the sort dropdown inside the filter row.
 *   - Translations come from the `careerfy` text domain, not `woocommerce`,
 *     so the strings stay translated via the theme's .po files.
 *   - `$ending_con` closes the wrapper div when total <= 1 to avoid a
 *     trailing empty row.
 *
 * WC 10.8.0 additions merged in:
 *   - `role="status"` + `aria-relevant="all"` on the result-count element
 *     so screen readers announce the count as products load.
 *   - `data-is-sorted-by="true"` attribute when an order-by is active.
 *   - Optional screen-reader-only sort-by announcement (added without
 *     touching the careerfy translation strings).
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

global $wp_query;

if (!woocommerce_products_will_display()) {
    return;
}
$ending_con = '';

// $orderedby is passed in by WC 10.8.0+; guard for older WC versions
// where the var doesn't exist so older callers don't fatal.
$careerfy_orderedby = isset($orderedby) ? $orderedby : '';
?>
<div class="careerfy-shop-filter">
<span class="woocommerce-result-count" role="status" aria-relevant="all"<?php echo ($careerfy_orderedby === '' || 1 === intval($wp_query->found_posts)) ? '' : ' data-is-sorted-by="true"'; ?>>
    <?php
    $paged = max(1, $wp_query->get('paged'));
    $per_page = $wp_query->get('posts_per_page');
    $total = $wp_query->found_posts;
    $first = ( $per_page * $paged ) - $per_page + 1;
    $last = min($total, $wp_query->get('posts_per_page') * $paged);

    if ($total <= $per_page || -1 === $per_page) {
        /* translators: %d: total results */
        printf(_n('Showing the single result', 'Showing all %d results', $total, 'careerfy'), $total);
    } else {
        /* translators: 1: first result 2: last result 3: total results */
        printf(_nx('Showing the single result', 'Showing %1$d&ndash;%2$d of %3$d results', $total, 'with first and last result', 'careerfy'), $first, $last, $total);
    }
    if ($total <= 1) {
        $ending_con = '</div>';
    }
    // Screen-reader-only sort-by announcement — added without modifying
    // the existing careerfy translation strings above so existing .po
    // files keep matching. Visually hidden via the standard WC class.
    if ($careerfy_orderedby !== '' && $total > 1) {
        echo '<span class="screen-reader-text">' . esc_html($careerfy_orderedby) . '</span>';
    }
    ?>
</span>
<?php
echo ($ending_con);
