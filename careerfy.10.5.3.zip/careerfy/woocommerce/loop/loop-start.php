<?php
/**
 * Product Loop Start
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/loop-start.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.3.0
 */

global $woocommerce_loop;

$products_loop_class = 'careerfy-shopgrid-sec';
if ( isset( $woocommerce_loop['columns'] ) && $woocommerce_loop['columns'] == 'list' ) {
	$products_loop_class = 'careerfy-shopgrid-sec careerfy-shop-list';
}
?>
<div class="careerfy-shop <?php echo esc_html($products_loop_class) ?>">
<ul class="row">
