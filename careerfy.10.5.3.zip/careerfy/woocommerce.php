<?php
/**
 * The template for displaying 
 * WooCommerace Products
 */
if (wp_is_mobile()) {
    get_header('mobile');
} else {
    get_header();
}
$shop_id = wc_get_page_id('shop');

if (is_single()) {
    wc_get_template('single-product.php');
}
else if (is_product_category() || is_product_tag()) {

    // Shop Taxonomies pages
    wc_get_template('archive-product.php');
} else {
    // Shop Other Pages
    ?>
    <div class="careerfy-shop-wrap">
        <?php 
        if (function_exists('woocommerce_content')) {
            woocommerce_content();
        } 
        ?>
    </div>
    <?php
}
get_footer();
