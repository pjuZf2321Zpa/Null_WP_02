<?php
/**
 * Functions
 *
 * @package WP Pro Real Estate 7
 * @subpackage Admin
 */

/*-----------------------------------------------------------------------------------*/
/* Constants */
/*-----------------------------------------------------------------------------------*/

update_option('realestate-7_license_key_status', 'valid');
update_option('realestate-7_license_key', 'B5E0B5F8DD8689E6ACA49DD6E6E1A930');
update_option('_transient_realestate-7_license_message', 'Your License is valid');

define('ADMIN_PATH', get_template_directory() . '/admin/');
define('INC_PATH', get_template_directory() . '/includes/');
define( 'REALESTATE7_SL_THEME_VERSION', wp_get_theme( 'realestate-7' )->get( 'Version' ) );

/** Shared feature check, with compatibility for a theme-first update. */
function ct_re7_listing_feature_enabled( string $module ): bool {
    if ( class_exists( 'CT_RE7_Listing_Modules' ) ) { return CT_RE7_Listing_Modules::enabled( $module ); }
    return match ( $module ) {
        'favorites' => function_exists( 'wpfp_link' ),
        'compare' => class_exists( 'Redq_Alike' ),
        'analytics' => class_exists( 'ctListingAnalytics' ),
        'alerts' => function_exists( 'ctea_show_alert_creation' ),
        default => false,
    };
}


/*-----------------------------------------------------------------------------------*/
/* Theme Setup Class */
/*-----------------------------------------------------------------------------------*/

class CT_Theme_Setup {
    
    public function __construct() {
        add_action( 'init', array( $this, 'load_textdomain' ), 1 );
        add_action( 'init', array( $this, 'load_theme_files' ), 2 );
        add_action( 'init', array( $this, 'getting_started' ), 3 );
		add_action( 'after_setup_theme', array( $this, 'load_dependencies' ), 4 );
        add_action( 'admin_init', array( 'CT_Settings', 'maybe_remove_redux' ) );
    }
    
    /**
     * Load text domain
     */
    public function load_textdomain() {
        load_theme_textdomain( 'contempo', get_template_directory() . '/languages' );
    }
    
    /**
     * Load theme file
     */
    public function load_theme_files() {
        // Load registration
        require_once(ADMIN_PATH . 'registration.php');
        
		// Theme Updater Dependencies
		require_once (ADMIN_PATH . 'updater/theme-updater-admin.php');

        // CT Settings Framework
        require_once(ADMIN_PATH . 'ct-settings/class-ct-settings.php');
        CT_Settings::boot( 'ct_options' );

        // Load files that depend on CT_Theme_Updater_Admin
        require_once(ADMIN_PATH . 'plugins/register.php');

        // Register all sections — must happen before hydrate_global below
        require_once(ADMIN_PATH . 'ct-settings/re7-config.php');

        // Hydrate $ct_options immediately after sections are registered.
        // This guarantees the global is populated for any code that runs after
        // this point (template hooks, wp_head, etc.) with zero timing uncertainty.
        CT_Settings::hydrate_global( 'ct_options' );

        require_once(ADMIN_PATH . 'merlin-config.php');
        require_once(ADMIN_PATH . 'theme-functions.php');

        // Bot Protection — must load after ct_options is hydrated above.
        require_once( get_template_directory() . '/classes/BotProtection.php' );
        add_action( 'after_switch_theme', [ RE7_BotProtection::instance(), 'create_table' ] );
        RE7_BotProtection::instance()->init();
        require_once(ADMIN_PATH . 'elementor-templates/bootstrap.php');
    }
    
    /**
     * Getting Started after everything is loaded
     */
    public function getting_started() {
        require_once (ADMIN_PATH . 'help-resources/help-resources.php');

        $ct_geting_started = new ct_getting_started_admin(
            $config = array(
                'item_name'      => 'WP Pro Real Estate 7 WordPress Theme',
                'theme_slug'     => 'realestate-7',
                'version'        => REALESTATE7_SL_THEME_VERSION,
                'author'         => 'Contempo',
            ),
            $strings = array(
                'getting-started'   => __( 'Help & Resources', 'contempo' ),
            )
        );
    }

	/**
     * Load dependencies
     */
    public function load_dependencies() {

        // WP Theme Support
        add_theme_support('automatic-feed-links');
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');

        // OAuth
        if(!class_exists('OAuthToken')) {
            require_once (ADMIN_PATH . 'OAuth.php');
        }

        // Custom Profile Fields
        require_once (ADMIN_PATH . 'profile-fields.php');

        // Theme Hooks
        require_once (ADMIN_PATH . 'theme-hooks.php');

        // Register Sidebars
        require_once (ADMIN_PATH . 'sidebars.php');

        // Single Listing Ajax Template Handler
        require_once (INC_PATH . 'ajax-single-listing.php');
        
        // Plugin Activation Dependencies
        require_once (ADMIN_PATH . 'plugins/class-ct-plugin-activation.php');
        require_once (ADMIN_PATH . 'plugins/class-ct-re7-plugins.php');
        require_once (ADMIN_PATH . 'plugins/deprecation.php');
        
        // Merlin Dependencies
        require_once (ADMIN_PATH . 'merlin/vendor/autoload.php' );
        require_once (ADMIN_PATH . 'merlin/class-merlin.php' );
    }
}

new CT_Theme_Setup();