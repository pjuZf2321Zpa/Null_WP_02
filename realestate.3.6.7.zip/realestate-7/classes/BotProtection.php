<?php
/**
 * Bot Protection
 *
 * Multi-layer bot and spam protection for all RE7 theme forms and AJAX
 * endpoints. Also covers CT IDX Pro+ endpoints automatically when that
 * plugin is active — no changes to the plugin are required.
 *
 * Protection layers (applied in order):
 *   1. IP whitelist bypass
 *   2. Honeypot field check
 *   3. Submit timing check (requires honeypot JS to be enabled)
 *   4. User-agent filtering
 *   5. IP-based rate limiting (WordPress transients)
 *   6. Server-side reCAPTCHA v3 token verification
 *
 * Security Log:
 *   All form-tier requests (accepted and blocked) are stored in the
 *   {prefix}ct_bp_security_log table and surfaced in an admin viewer
 *   under RE7 Options > Security > Security Log. Search/map/autocomplete
 *   requests are excluded to prevent high-volume noise.
 *
 * @package WP Pro Real Estate 7
 * @subpackage Classes
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class RE7_BotProtection {

    /** @var RE7_BotProtection|null */
    private static $instance = null;

    /** Protection tiers */
    const TIER_FORM   = 'form';
    const TIER_SEARCH = 'search';

    /** DB schema version — increment when the table structure changes */
    const DB_VERSION = '1.0';

    /** Known bot / headless-browser user-agent fragments */
    private static $blocked_ua_fragments = [
        'curl/',
        'python-requests',
        'python-urllib',
        'libwww-perl',
        'go-http-client',
        'java/',
        'scrapy',
        'wget/',
        'httpclient',
        'okhttp',
        'guzzle',
        'axios',
        'node-fetch',
        'got/',
        'aiohttp',
        'apache-httpclient',
        'mechanize',
        'lwp::simple',
        'zgrab',
        'masscan',
        'nikto',
        'sqlmap',
        'nmap',
        'headlesschrome',
        'phantomjs',
        'slimerjs',
    ];

    /* -----------------------------------------------------------------------
     * Bootstrap
     * --------------------------------------------------------------------- */

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function init(): void {
        global $ct_options;

        if ( isset( $ct_options['ct_bp_enabled'] ) && $ct_options['ct_bp_enabled'] !== 'yes' ) {
            return;
        }

        // Ensure the security log table exists (version-guarded, runs once per install).
        $this->maybe_create_table();

        // Inject honeypot + timestamp fields into every front-end form.
        add_action( 'wp_footer', [ $this, 'inject_honeypot_script' ] );

        // Intercept direct ajax-submit-*.php file requests via wp_loaded.
        add_action( 'wp_loaded', [ $this, 'check_direct_file_request' ], 1 );

        // Block unauthenticated ?ct_idx_pp_check_license_cron requests.
        add_action( 'init', [ $this, 'block_license_cron_exposure' ], 1 );

        // RE7 form tier — admin-ajax.php nopriv actions.
        $re7_form_actions = apply_filters( 'ct_bp_extra_form_actions', [
            'ct_add_new_member',
            'ct_login_member_ajax',
        ] );
        foreach ( $re7_form_actions as $action ) {
            add_action( 'wp_ajax_nopriv_' . $action, [ $this, 'verify_form_ajax' ], 1 );
        }

        // RE7 search/read tier.
        $re7_search_actions = [
            're7_load_single_listing',
            'map_listing_update',
            'street_keyword_search',
            'ct_additional_feature_search',
            'country_ajax',
            'communityajax',
            'state_ajax',
            'city_ajax',
            'zipcode_ajax',
        ];
        foreach ( $re7_search_actions as $action ) {
            add_action( 'wp_ajax_nopriv_' . $action, [ $this, 'verify_search_ajax' ], 1 );
        }

        // CT IDX Pro+ — conditional on plugin being active.
        if ( class_exists( 'Contempo\IDXPro\Api\ArchiveApi' ) ) {
            $this->register_idx_hooks();
        }

        // Block direct wp-login.php?action=register — all real registrations use
        // the theme or IDX AJAX forms which are already fully protected.
        add_action( 'login_head', static function () {
            if ( isset( $_GET['action'] ) && 'register' === $_GET['action'] ) {
                wp_safe_redirect( home_url() );
                exit;
            }
        } );

        // Daily log pruning via WP-Cron.
        add_action( 'ct_bp_prune_log', [ $this, 'prune_log' ] );
        if ( ! wp_next_scheduled( 'ct_bp_prune_log' ) ) {
            wp_schedule_event( time(), 'daily', 'ct_bp_prune_log' );
        }

        // Clear-log AJAX (logged-in admin only).
        add_action( 'wp_ajax_ct_bp_clear_log',       [ $this, 'ajax_clear_log' ] );

        // Viewer refresh AJAX — returns fresh viewer HTML for live DOM injection.
        add_action( 'wp_ajax_ct_bp_get_log_viewer', [ $this, 'ajax_get_log_viewer' ] );

        // Register the Security Log viewer section at admin_init, after options
        // are fully hydrated and the page slug is determinable from $_GET.
        add_action( 'admin_init',  [ $this, 'register_log_viewer_section' ] );

        // Inject JS that syncs the Security Log nav item to the toggle state
        // in real time — no page reload needed when enabling or disabling.
        add_action( 'admin_footer', [ $this, 'inject_security_log_nav_sync' ] );
    }

    private function register_idx_hooks(): void {
        $idx_form_actions = [
            'ct_idx_pro_plus/submit_form',
            'ct_idx_pro_plus/submit_share_form',
            'ct_idx_pro_plus/submit_calc_email',
            'ct_idx_pro_plus/login_window',
        ];
        foreach ( $idx_form_actions as $action ) {
            add_action( 'wp_ajax_nopriv_' . $action, [ $this, 'verify_form_ajax' ], 1 );
        }

        $idx_search_actions = [
            'ct_idx_pro_plus/get_items',
            'ct_idx_pro_plus/get_by_ids',
            'ct_idx_pro_plus/get_item',
            'ct_idx_pro_plus/get_autocomplete',
            'ct_idx_pro_plus/get_yelp',
            'ct_idx_pro_plus/get_walkscore',
            'ct_idx_pro_plus/toggle_favorites',
            'ct_idx_pro_plus/load_recenly_viewed',
            'ct_idx_pro_plus/log_recenly_viewed',
            'ct_idx_agents_get_all',
            'ct_idx_agent_get_profile',
            'ct_idx_agent_get_listings',
        ];
        foreach ( $idx_search_actions as $action ) {
            add_action( 'wp_ajax_nopriv_' . $action, [ $this, 'verify_search_ajax' ], 1 );
        }

        // REST API rate limiting for public agent routes.
        add_filter( 'rest_pre_dispatch', [ $this, 'check_rest_request' ], 10, 3 );
    }

    /* -----------------------------------------------------------------------
     * DB table
     * --------------------------------------------------------------------- */

    /**
     * Create or upgrade the security log table via dbDelta().
     * Called on after_switch_theme and from maybe_create_table() when the
     * version option is absent or stale.
     */
    public function create_table(): void {
        global $wpdb;

        $table           = $wpdb->prefix . 'ct_bp_security_log';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            logged_at    DATETIME        NOT NULL,
            status       VARCHAR(10)     NOT NULL,
            reason       VARCHAR(20)     NOT NULL DEFAULT '',
            ip           VARCHAR(45)     NOT NULL,
            action       VARCHAR(100)    NOT NULL DEFAULT '',
            uri          VARCHAR(500)    NOT NULL DEFAULT '',
            ua           TEXT            NOT NULL,
            PRIMARY KEY (id),
            KEY idx_logged_at (logged_at),
            KEY idx_status (status)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );

        update_option( 'ct_bp_db_version', self::DB_VERSION );
    }

    private function maybe_create_table(): void {
        if ( get_option( 'ct_bp_db_version', '' ) !== self::DB_VERSION ) {
            $this->create_table();
        }
    }

    /* -----------------------------------------------------------------------
     * Security Log — section registration
     * --------------------------------------------------------------------- */

    /**
     * Registers the Security Log viewer as a CT_Settings section under the
     * Security group. Always registers so the nav item is always in the DOM —
     * JS in inject_security_log_nav_sync() handles show/hide reactively.
     * Hooked to admin_init so the DB query runs only on admin page loads and
     * $ct_options is already hydrated at this point.
     */
    public function register_log_viewer_section(): void {
        ob_start();
        $this->render_log_viewer();
        $viewer_html = ob_get_clean();

        CT_Settings::set_section( 'ct_options', array(
            'title'  => __( 'Security Log', 'contempo' ),
            'id'     => 'security-log',
            'group'  => 'Security',
            'icon'   => 'fas fa-list-alt',
            'desc'   => __( 'Form submission activity for the current retention window. Search and map requests are excluded to keep the log focused.', 'contempo' ),
            'fields' => array(
                array(
                    'id'      => 'ct_bp_log_viewer',
                    'type'    => 'raw',
                    'content' => $viewer_html,
                ),
            ),
        ) );
    }

    /* -----------------------------------------------------------------------
     * Interception entry points
     * --------------------------------------------------------------------- */

    /**
     * Intercepts direct ajax-submit-*.php file requests.
     * These files call require_once(wp-load.php) and block until it returns,
     * so a rejection here prevents any $_POST processing in the calling file.
     */
    public function check_direct_file_request(): void {
        $script = $_SERVER['SCRIPT_FILENAME'] ?? '';
        if ( strpos( $script, 'ajax-submit-' ) === false ) {
            return;
        }
        $this->verify( self::TIER_FORM, true );
    }

    /** Called at priority 1 before each nopriv form action handler. */
    public function verify_form_ajax(): void {
        $this->verify( self::TIER_FORM, false );
    }

    /** Called at priority 1 before each nopriv search/read action handler. */
    public function verify_search_ajax(): void {
        $this->verify( self::TIER_SEARCH, false );
    }

    /** REST pre-dispatch check for IDX Pro+ public agent routes. */
    public function check_rest_request( $result, $server, $request ) {
        if ( $result !== null ) {
            return $result;
        }
        $route = $request->get_route();
        if ( strpos( $route, '/ct-idx-pro/v1/agent' ) === 0 || strpos( $route, '/ct-idx-pro/v1/agents' ) === 0 ) {
            $ip = $this->get_client_ip();
            if ( ! $this->is_ip_whitelisted( $ip ) ) {
                if ( ! $this->check_user_agent() ) {
                    return new WP_Error( 'ct_bp_blocked', __( 'Request blocked.', 'contempo' ), [ 'status' => 429 ] );
                }
                if ( ! $this->check_rate_limit( $ip, self::TIER_SEARCH ) ) {
                    return new WP_Error( 'ct_bp_rate_limit', __( 'Too many requests.', 'contempo' ), [ 'status' => 429 ] );
                }
            }
        }
        return $result;
    }

    /**
     * Blocks anonymous access to ?ct_idx_pp_check_license_cron.
     * The IDX Pro+ License class responds to this parameter before any
     * capability check, exposing license status to unauthenticated visitors.
     */
    public function block_license_cron_exposure(): void {
        if ( isset( $_REQUEST['ct_idx_pp_check_license_cron'] ) && ! current_user_can( 'manage_options' ) && ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
            wp_die( '', '', [ 'response' => 403 ] );
        }
    }

    /* -----------------------------------------------------------------------
     * Core verification pipeline
     * --------------------------------------------------------------------- */

    private function verify( string $tier, bool $is_direct_file ): void {
        $ip = $this->get_client_ip();

        if ( $this->is_ip_whitelisted( $ip ) ) {
            return;
        }

        if ( $tier === self::TIER_FORM ) {
            if ( ! $this->check_honeypot() ) {
                $this->reject( 'honeypot', $is_direct_file, $ip );
            }
            if ( ! $this->check_timing() ) {
                $this->reject( 'timing', $is_direct_file, $ip );
            }
        }

        if ( ! $this->check_user_agent() ) {
            $this->reject( 'ua', $is_direct_file, $ip );
        }

        if ( ! $this->check_rate_limit( $ip, $tier ) ) {
            $this->reject( 'rate_limit', $is_direct_file, $ip );
        }

        // Tighter per-IP rate limit specifically for registration actions.
        if ( $tier === self::TIER_FORM ) {
            $action     = isset( $_REQUEST['action'] ) ? sanitize_text_field( $_REQUEST['action'] ) : '';
            $sub_action = isset( $_REQUEST['sub_action'] ) ? sanitize_text_field( $_REQUEST['sub_action'] ) : '';

            $is_registration = (
                $action === 'ct_add_new_member'
                || ( $action === 'ct_idx_pro_plus/login_window' && $sub_action === 'register' )
            );

            if ( $is_registration && ! $this->check_registration_rate_limit( $ip ) ) {
                $this->reject( 'reg_rate_limit', $is_direct_file, $ip );
            }
        }

        if ( $tier === self::TIER_FORM && ! $this->verify_recaptcha() ) {
            $this->reject( 'recaptcha', $is_direct_file, $ip );
        }

        // All checks passed — log the allowed form-tier request.
        if ( $tier === self::TIER_FORM ) {
            $this->log_event( 'allowed', '', $ip );
        }
    }

    /* -----------------------------------------------------------------------
     * Layer 1 — Honeypot
     * --------------------------------------------------------------------- */

    private function check_honeypot(): bool {
        global $ct_options;

        if ( isset( $ct_options['ct_bp_honeypot_enabled'] ) && $ct_options['ct_bp_honeypot_enabled'] !== 'yes' ) {
            return true;
        }

        $hp_value = isset( $_POST['ct_hp_website'] ) ? $_POST['ct_hp_website'] : '';
        return ( $hp_value === '' );
    }

    /* -----------------------------------------------------------------------
     * Layer 2 — Submit timing
     * --------------------------------------------------------------------- */

    private function check_timing(): bool {
        global $ct_options;

        if ( isset( $ct_options['ct_bp_honeypot_enabled'] ) && $ct_options['ct_bp_honeypot_enabled'] !== 'yes' ) {
            return true;
        }

        if ( ! isset( $_REQUEST['ct_form_time'] ) ) {
            return true; // Field absent (e.g. React/AJAX forms) — do not penalise.
        }

        $min_time  = isset( $ct_options['ct_bp_min_submit_time'] ) ? (int) $ct_options['ct_bp_min_submit_time'] : 2;
        $form_time = (int) $_REQUEST['ct_form_time'];
        $elapsed   = time() - $form_time;

        return ( $elapsed >= $min_time );
    }

    /* -----------------------------------------------------------------------
     * Layer 3 — User-agent filtering
     * --------------------------------------------------------------------- */

    private function check_user_agent(): bool {
        $ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( $_SERVER['HTTP_USER_AGENT'] ) : '';

        if ( $ua === '' ) {
            return false;
        }

        foreach ( self::$blocked_ua_fragments as $fragment ) {
            if ( strpos( $ua, strtolower( $fragment ) ) !== false ) {
                return false;
            }
        }

        return true;
    }

    /* -----------------------------------------------------------------------
     * Layer 4 — IP rate limiting
     * --------------------------------------------------------------------- */

    private function check_rate_limit( string $ip, string $tier ): bool {
        global $ct_options;

        if ( $tier === self::TIER_FORM ) {
            if ( isset( $ct_options['ct_bp_rate_limit_enabled'] ) && $ct_options['ct_bp_rate_limit_enabled'] !== 'yes' ) {
                return true;
            }
            $max    = isset( $ct_options['ct_bp_rate_limit_max'] )    ? (int) $ct_options['ct_bp_rate_limit_max']    : 5;
            $window = isset( $ct_options['ct_bp_rate_limit_window'] ) ? (int) $ct_options['ct_bp_rate_limit_window'] : 60;
        } else {
            // Search tier: fixed generous limit — not user-configurable to avoid
            // disrupting map/autocomplete UX.
            $max    = 30;
            $window = 60;
        }

        $key   = 'ct_bp_' . md5( $ip . '_' . $tier );
        $count = get_transient( $key );

        if ( $count === false ) {
            set_transient( $key, 1, $window );
            return true;
        }

        if ( (int) $count >= $max ) {
            return false;
        }

        set_transient( $key, (int) $count + 1, $window );
        return true;
    }

    /* -----------------------------------------------------------------------
     * Layer 4b — Registration-specific rate limit
     * --------------------------------------------------------------------- */

    private function check_registration_rate_limit( string $ip ): bool {
        global $ct_options;

        $max_hourly = isset( $ct_options['ct_bp_reg_limit_hourly'] ) ? (int) $ct_options['ct_bp_reg_limit_hourly'] : 2;
        $max_daily  = isset( $ct_options['ct_bp_reg_limit_daily'] )  ? (int) $ct_options['ct_bp_reg_limit_daily']  : 5;

        $key_hour = 'ct_bp_reg_h_' . md5( $ip );
        $key_day  = 'ct_bp_reg_d_' . md5( $ip );

        $hourly = (int) get_transient( $key_hour );
        if ( $hourly >= $max_hourly ) {
            return false;
        }

        $daily = (int) get_transient( $key_day );
        if ( $daily >= $max_daily ) {
            return false;
        }

        set_transient( $key_hour, $hourly + 1, HOUR_IN_SECONDS );
        set_transient( $key_day,  $daily + 1,  DAY_IN_SECONDS );

        return true;
    }

    /* -----------------------------------------------------------------------
     * Layer 5 — reCAPTCHA v3 server-side verification
     * --------------------------------------------------------------------- */

    private function verify_recaptcha(): bool {
        global $ct_options;

        $enabled    = isset( $ct_options['ct_use_google_recaptcha'] ) ? $ct_options['ct_use_google_recaptcha'] : 'no';
        $secret_key = isset( $ct_options['ct_google_recaptcha_secret_key'] ) ? trim( $ct_options['ct_google_recaptcha_secret_key'] ) : '';

        if ( $enabled !== 'yes' || empty( $secret_key ) ) {
            return true; // reCAPTCHA not configured — skip.
        }

        $action     = isset( $_REQUEST['action'] ) ? sanitize_text_field( $_REQUEST['action'] ) : '';
        $min_score  = isset( $ct_options['ct_bp_recaptcha_min_score'] ) ? (float) $ct_options['ct_bp_recaptcha_min_score'] : 0.5;

        // --- Path 1: session token issued by ct-re-google-verifier (theme registration) ---
        $session_token = isset( $_POST['ct_rcv3'] ) ? sanitize_text_field( $_POST['ct_rcv3'] ) : '';
        if ( ! empty( $session_token ) ) {
            $transient_key = 'ct_rcv3_' . $session_token;
            $data          = get_transient( $transient_key );
            delete_transient( $transient_key ); // one-time use regardless of outcome
            if ( $data === false ) {
                return false; // token not found or already consumed
            }
            $stored_ip = isset( $data['ip'] ) ? $data['ip'] : '';
            return ( $stored_ip === $this->get_client_ip() );
        }

        // --- Path 2: IDX forms send the raw reCAPTCHA token as 'token' field ---
        // Only check this for IDX actions to prevent false-positive API calls on unrelated requests.
        $is_idx_action = ( strpos( $action, 'ct_idx_pro_plus/' ) === 0 );
        $idx_token     = ( $is_idx_action && isset( $_POST['token'] ) )
            ? sanitize_text_field( $_POST['token'] ) : '';

        if ( ! empty( $idx_token ) ) {
            $response = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', [
                'timeout' => 10,
                'body'    => [
                    'secret'   => $secret_key,
                    'response' => $idx_token,
                    'remoteip' => $this->get_client_ip(),
                ],
            ] );

            if ( is_wp_error( $response ) ) {
                return true; // network failure — fail open
            }

            $body = json_decode( wp_remote_retrieve_body( $response ), true );

            if ( empty( $body['success'] ) || ! $body['success'] ) {
                return false;
            }

            $score = isset( $body['score'] ) ? (float) $body['score'] : 0.0;
            return ( $score >= $min_score );
        }

        // --- Path 3: fail-closed only for theme registration ---
        // ct_add_new_member always has ct_rcv3 when reCAPTCHA is on (Path 1 above).
        // If we reach here for that action, the token is absent or was already used — block it.
        // All other actions (login, contact forms, etc.) remain fail-open.
        if ( $action === 'ct_add_new_member' ) {
            return false;
        }

        // --- Path 4: legacy g-recaptcha-response fallback (fail-open if absent) ---
        $token = isset( $_POST['g-recaptcha-response'] ) ? sanitize_text_field( $_POST['g-recaptcha-response'] ) : '';
        if ( empty( $token ) ) {
            return true; // fail-open for login, contact forms, etc.
        }

        $response = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', [
            'timeout' => 10,
            'body'    => [
                'secret'   => $secret_key,
                'response' => $token,
                'remoteip' => $this->get_client_ip(),
            ],
        ] );

        if ( is_wp_error( $response ) ) {
            return true; // Network failure — fail open to avoid blocking legitimate users.
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( empty( $body['success'] ) || ! $body['success'] ) {
            return false;
        }

        $score = isset( $body['score'] ) ? (float) $body['score'] : 0.0;
        return ( $score >= $min_score );
    }

    /* -----------------------------------------------------------------------
     * Helpers
     * --------------------------------------------------------------------- */

    private function get_client_ip(): string {
        // Prefer Cloudflare real IP, then standard proxy header, then REMOTE_ADDR.
        $candidates = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ];

        foreach ( $candidates as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                // X-Forwarded-For may contain a comma-separated list; take the first.
                $ip = trim( explode( ',', $_SERVER[ $key ] )[0] );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                    // Normalize IPv6 loopback to its IPv4 equivalent for readability.
                    return ( $ip === '::1' ) ? '127.0.0.1' : $ip;
                }
            }
        }

        return '0.0.0.0';
    }

    private function is_ip_whitelisted( string $ip ): bool {
        global $ct_options;

        $whitelist_raw = isset( $ct_options['ct_bp_ip_whitelist'] ) ? $ct_options['ct_bp_ip_whitelist'] : '';
        if ( empty( $whitelist_raw ) ) {
            return false;
        }

        $whitelist = array_filter( array_map( 'trim', explode( "\n", $whitelist_raw ) ) );
        return in_array( $ip, $whitelist, true );
    }

    /**
     * Terminate the request with a 429 response and log the blocked event.
     *
     * @param string $reason        Machine-readable rejection reason.
     * @param bool   $is_direct_file True when rejecting inside a direct ajax-submit-*.php file.
     * @param string $ip            Client IP address.
     */
    private function reject( string $reason, bool $is_direct_file, string $ip = '' ): void {
        $this->log_event( 'blocked', $reason, $ip );

        if ( $is_direct_file ) {
            http_response_code( 429 );
            header( 'Content-Type: application/json; charset=utf-8' );
            echo wp_json_encode( [ 'success' => false, 'message' => 'Request blocked.' ] );
            exit;
        }

        wp_send_json_error( [ 'message' => 'Request blocked.' ], 429 );
    }

    /* -----------------------------------------------------------------------
     * Security Log — data layer
     * --------------------------------------------------------------------- */

    /**
     * Insert one event row into the security log table.
     * Only runs for TIER_FORM calls; search/map requests are never logged.
     * No-ops when logging is disabled in settings.
     *
     * @param string $status 'allowed' or 'blocked'.
     * @param string $reason Empty string for allowed; rejection layer name for blocked.
     * @param string $ip     Client IP address.
     */
    private function log_event( string $status, string $reason, string $ip ): void {
        global $wpdb, $ct_options;

        $enabled = isset( $ct_options['ct_bp_logging_enabled'] ) ? $ct_options['ct_bp_logging_enabled'] : 'yes';
        if ( $enabled !== 'yes' ) {
            return;
        }

        $table = $wpdb->prefix . 'ct_bp_security_log';

        // Strip query string from REQUEST_URI — the action column already identifies
        // the endpoint, and GET-based AJAX requests embed all params in the URL
        // which can easily exceed VARCHAR(500).
        $path = isset( $_SERVER['REQUEST_URI'] ) ? strtok( $_SERVER['REQUEST_URI'], '?' ) : '';

        // Preserve slashes in action names (e.g. ct_idx_pro_plus/submit_form).
        // sanitize_key() strips '/' so we use a targeted filter instead.
        $action = isset( $_REQUEST['action'] )
            ? preg_replace( '/[^a-zA-Z0-9\/_\-.]/', '', $_REQUEST['action'] )
            : '';

        $wpdb->insert(
            $table,
            [
                'logged_at' => current_time( 'mysql' ),
                'status'    => $status,
                'reason'    => $reason,
                'ip'        => $ip,
                'action'    => $action,
                'uri'       => esc_url_raw( $path ),
                'ua'        => isset( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : '',
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
        );
    }

    /**
     * Delete rows older than the configured retention period.
     * Triggered by the daily ct_bp_prune_log WP-Cron event.
     */
    public function prune_log(): void {
        global $wpdb, $ct_options;

        $days  = isset( $ct_options['ct_bp_log_retention'] ) ? (int) $ct_options['ct_bp_log_retention'] : 30;
        $table = $wpdb->prefix . 'ct_bp_security_log';

        $wpdb->query( $wpdb->prepare(
            "DELETE FROM `{$table}` WHERE logged_at < DATE_SUB( NOW(), INTERVAL %d DAY )",
            $days
        ) );
    }

    /**
     * AJAX handler: truncate the security log table.
     * Requires manage_options capability and a valid nonce.
     */
    public function ajax_clear_log(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Unauthorized.', 'contempo' ) ], 403 );
        }

        $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
        if ( ! wp_verify_nonce( $nonce, 'ct_bp_clear_log' ) ) {
            wp_send_json_error( [ 'message' => __( 'Invalid security token.', 'contempo' ) ], 403 );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'ct_bp_security_log';
        $wpdb->query( "TRUNCATE TABLE `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        wp_send_json_success( [ 'message' => __( 'Log cleared.', 'contempo' ) ] );
    }

    /**
     * AJAX handler: return fresh viewer HTML for live DOM injection.
     * Called by inject_security_log_nav_sync() when the toggle is flipped ON.
     */
    public function ajax_get_log_viewer(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [], 403 );
        }

        $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
        if ( ! wp_verify_nonce( $nonce, 'ct_bp_viewer' ) ) {
            wp_send_json_error( [], 403 );
        }

        ob_start();
        $this->render_log_viewer();
        $html = ob_get_clean();

        wp_send_json_success( [ 'html' => $html ] );
    }

    /* -----------------------------------------------------------------------
     * Security Log — admin viewer
     * --------------------------------------------------------------------- */

    /**
     * Render the Security Log viewer HTML.
     * Always renders real data regardless of the logging-enabled setting —
     * nav item visibility (controlled by JS) communicates enabled/disabled.
     * Called both at admin_init (for initial page render) and via the
     * ct_bp_get_log_viewer AJAX endpoint (for live DOM refresh).
     */
    public function render_log_viewer(): void {
        global $wpdb, $ct_options;

        $table     = $wpdb->prefix . 'ct_bp_security_log';
        $retention = isset( $ct_options['ct_bp_log_retention'] ) ? (int) $ct_options['ct_bp_log_retention'] : 30;
        $per_page  = 20;
        $cur_page  = max( 1, (int) ( $_GET['bp_log_page'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

        // Summary counts.
        $total   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $allowed = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE status = %s", 'allowed' ) );
        $blocked = $total - $allowed;

        // Per-reason breakdown for blocked events.
        $reasons = $wpdb->get_results( $wpdb->prepare(
            "SELECT reason, COUNT(*) AS cnt FROM `{$table}` WHERE status = %s AND reason != '' GROUP BY reason ORDER BY cnt DESC",
            'blocked'
        ) );

        // Paginated rows.
        $offset      = ( $cur_page - 1 ) * $per_page;
        $total_pages = $total > 0 ? (int) ceil( $total / $per_page ) : 1;
        $rows        = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM `{$table}` ORDER BY logged_at DESC LIMIT %d OFFSET %d",
            $per_page,
            $offset
        ) );

        $clear_nonce = wp_create_nonce( 'ct_bp_clear_log' );
        $ajax_url    = esc_url( admin_url( 'admin-ajax.php' ) );
        $page_url    = esc_url( remove_query_arg( 'bp_log_page' ) );

        $reason_labels = [
            'honeypot'   => __( 'Honeypot', 'contempo' ),
            'timing'     => __( 'Timing', 'contempo' ),
            'ua'         => __( 'User Agent', 'contempo' ),
            'rate_limit' => __( 'Rate Limit', 'contempo' ),
            'recaptcha'  => __( 'reCAPTCHA', 'contempo' ),
        ];

        ?>
        <style>
        /* CT Security Log — design tokens mirror ct-settings.css exactly */
        .ct-sl{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen,Ubuntu,sans-serif;}

        /* Stats bar — matches .ct-field-section-divider */
        .ct-sl-stats{display:flex;align-items:center;gap:0;padding:14px 22px;background:#f8f9fb;border-bottom:1px solid #f0f2f5;flex-wrap:wrap;row-gap:10px;}
        .ct-sl-stat{display:flex;align-items:baseline;gap:6px;padding-right:24px;margin-right:24px;border-right:1px solid #e8eaed;}
        .ct-sl-stat:last-of-type{border-right:none;margin-right:0;padding-right:0;}
        .ct-sl-stat-n{font-size:20px;font-weight:700;line-height:1;color:#1a202c;}
        .ct-sl-stat-n--allowed{color:#027a48;}
        .ct-sl-stat-n--blocked{color:#b42318;}
        .ct-sl-stat-l{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#9aa0a8;}

        /* Reason pills */
        .ct-sl-pills{display:flex;flex-wrap:wrap;gap:6px;padding:10px 22px;background:#f8f9fb;border-bottom:1px solid #f0f2f5;}
        .ct-sl-pill{display:inline-flex;align-items:center;gap:4px;background:#fff;border:1px solid #e8eaed;border-radius:20px;padding:2px 9px;font-size:11px;color:#50575e;font-weight:500;}
        .ct-sl-pill-n{font-weight:700;color:#b42318;}

        /* Column header — matches .ct-field-section-divider h3 */
        .ct-sl-thead{display:flex;align-items:center;padding:8px 22px;background:#f8f9fb;border-bottom:2px solid #e6e9ee;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#9aa0a8;user-select:none;}

        /* Data rows — matches .ct-field-row */
        .ct-sl-row{display:flex;align-items:center;padding:13px 22px;border-bottom:1px solid #f0f2f5;font-size:13px;color:#1a202c;transition:background .1s;}
        .ct-sl-row:last-child{border-bottom:none;}
        .ct-sl-row:hover{background:#fafafa;}

        /* Column widths — shared between header and rows; NO color/font here */
        .ct-sl-c-ts  {flex:0 0 148px;}
        .ct-sl-c-st  {flex:0 0 86px;}
        .ct-sl-c-re  {flex:0 0 96px;}
        .ct-sl-c-ip  {flex:0 0 108px;}
        .ct-sl-c-ac  {flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
        .ct-sl-c-ua  {flex:0 0 160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
        .ct-sl-c-btn {flex:0 0 48px;display:flex;justify-content:flex-end;}

        /* Data-row column overrides — scoped so thead keeps its own uniform style */
        .ct-sl-row .ct-sl-c-ts {white-space:nowrap;color:#50575e;font-size:12.5px;}
        .ct-sl-row .ct-sl-c-re {font-size:12.5px;color:#50575e;}
        .ct-sl-row .ct-sl-c-ip {white-space:nowrap;font-size:12px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,monospace;color:#50575e;}
        .ct-sl-row .ct-sl-c-ac {font-size:12px;color:#50575e;}
        .ct-sl-row .ct-sl-c-ua {font-size:12px;color:#9aa0a8;}

        /* Status badge — mirrors .ct-field-info-banner color scheme */
        .ct-sl-badge{display:inline-flex;align-items:center;padding:2px 8px;border-radius:20px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;border:1px solid transparent;}
        .ct-sl-badge--allowed{background:#ecfdf3;color:#027a48;border-color:#d1fadf;}
        .ct-sl-badge--blocked{background:#fef3f2;color:#b42318;border-color:#fecdca;}

        /* View button — mirrors .ct-nav-confirm-cancel */
        .ct-sl-view-btn{background:#fff;color:#50575e;border:1px solid #c3c4c7;border-radius:4px;padding:3px 9px;font-size:11px;font-weight:500;cursor:pointer;transition:background .12s,border-color .12s;font-family:inherit;line-height:1.5;}
        .ct-sl-view-btn:hover{background:#f6f7f7;border-color:#9aa0a8;color:#1a202c;}

        /* Empty state */
        .ct-sl-empty{padding:52px 22px;text-align:center;color:#9aa0a8;font-size:13px;line-height:1.6;}
        .ct-sl-empty svg{display:block;margin:0 auto 12px;opacity:.35;}

        /* Footer bar (pagination + clear) */
        .ct-sl-footer{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;padding:13px 22px;background:#f8f9fb;border-top:1px solid #f0f2f5;}
        .ct-sl-pagination{display:flex;align-items:center;gap:8px;font-size:12.5px;color:#50575e;}
        .ct-sl-pagination .button{font-size:12px;height:28px;line-height:26px;padding:0 10px;}

        /* Clear button — mirrors .ct-nav-confirm-discard */
        .ct-sl-clear-btn{background:#fff;color:#d63638;border:1px solid #d63638;border-radius:4px;padding:6px 14px;font-size:12.5px;font-weight:500;cursor:pointer;transition:background .12s;font-family:inherit;}
        .ct-sl-clear-btn:hover{background:#fcf0f1;}
        .ct-sl-clear-btn:disabled{opacity:.6;cursor:not-allowed;}
        .ct-sl-footer-msg{font-size:12.5px;}

        /* Detail modal — mirrors .ct-nav-confirm-overlay + .ct-nav-confirm-dialog exactly */
        .ct-sl-overlay{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999999;display:none;align-items:center;justify-content:center;animation:ct-overlay-in .15s ease;}
        .ct-sl-overlay.is-open{display:flex;}
        .ct-sl-dialog{background:#fff;border-radius:8px;padding:28px 32px 24px;width:min(580px,92vw);max-height:90vh;overflow-y:auto;box-shadow:0 8px 40px rgba(0,0,0,.22);animation:ct-dialog-in .15s ease;}
        .ct-sl-dialog-hd{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;}
        .ct-sl-dialog-title{font-size:15px;font-weight:600;color:#1d2327;margin:0;display:flex;align-items:center;gap:8px;}
        .ct-sl-dialog-close{background:none;border:none;cursor:pointer;color:#9aa0a8;font-size:20px;line-height:1;padding:3px 5px;border-radius:4px;transition:color .12s,background .12s;}
        .ct-sl-dialog-close:hover{color:#1d2327;background:#f0f2f5;}

        /* Modal detail rows — same spacing as .ct-field-row */
        .ct-sl-dr{display:flex;gap:16px;padding:11px 0;border-bottom:1px solid #f0f2f5;}
        .ct-sl-dr:last-child{border-bottom:none;}
        .ct-sl-dk{flex:0 0 90px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#9aa0a8;padding-top:2px;}
        .ct-sl-dv{flex:1;font-size:13px;color:#1a202c;word-break:break-all;line-height:1.5;}
        .ct-sl-dv code{background:#f8f9fb;border:1px solid #e8eaed;border-radius:4px;padding:1px 6px;font-size:12px;color:#50575e;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,monospace;}
        </style>

        <!-- Detail modal — single instance, populated by JS on each row open -->
        <div id="ct-sl-overlay" class="ct-sl-overlay" role="dialog" aria-modal="true" aria-labelledby="ct-sl-dialog-title">
            <div class="ct-sl-dialog">
                <div class="ct-sl-dialog-hd">
                    <h3 class="ct-sl-dialog-title" id="ct-sl-dialog-title">
                        <svg width="15" height="15" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M10 2a8 8 0 100 16A8 8 0 0010 2zm0 3.5a1 1 0 110 2 1 1 0 010-2zm1.25 9h-2.5v-5h2.5v5z" fill="#9aa0a8"/></svg>
                        <?php esc_html_e( 'Event Detail', 'contempo' ); ?>
                    </h3>
                    <button class="ct-sl-dialog-close" id="ct-sl-dialog-close" aria-label="<?php esc_attr_e( 'Close', 'contempo' ); ?>">&times;</button>
                </div>
                <div class="ct-sl-dr"><span class="ct-sl-dk"><?php esc_html_e( 'Date / Time', 'contempo' ); ?></span><span class="ct-sl-dv" id="ct-sl-d-ts">—</span></div>
                <div class="ct-sl-dr"><span class="ct-sl-dk"><?php esc_html_e( 'Status', 'contempo' ); ?></span><span class="ct-sl-dv" id="ct-sl-d-st">—</span></div>
                <div class="ct-sl-dr"><span class="ct-sl-dk"><?php esc_html_e( 'Reason', 'contempo' ); ?></span><span class="ct-sl-dv" id="ct-sl-d-re">—</span></div>
                <div class="ct-sl-dr"><span class="ct-sl-dk"><?php esc_html_e( 'IP Address', 'contempo' ); ?></span><span class="ct-sl-dv" id="ct-sl-d-ip">—</span></div>
                <div class="ct-sl-dr"><span class="ct-sl-dk"><?php esc_html_e( 'Action', 'contempo' ); ?></span><span class="ct-sl-dv" id="ct-sl-d-ac">—</span></div>
                <div class="ct-sl-dr"><span class="ct-sl-dk"><?php esc_html_e( 'URI', 'contempo' ); ?></span><span class="ct-sl-dv" id="ct-sl-d-ur">—</span></div>
                <div class="ct-sl-dr"><span class="ct-sl-dk"><?php esc_html_e( 'User Agent', 'contempo' ); ?></span><span class="ct-sl-dv" id="ct-sl-d-ua">—</span></div>
            </div>
        </div>

        <div class="ct-sl">

            <?php if ( $total > 0 ) : ?>

                <!-- Stats bar -->
                <div class="ct-sl-stats">
                    <div class="ct-sl-stat">
                        <span class="ct-sl-stat-n"><?php echo esc_html( number_format_i18n( $total ) ); ?></span>
                        <span class="ct-sl-stat-l"><?php esc_html_e( 'Total', 'contempo' ); ?></span>
                    </div>
                    <div class="ct-sl-stat">
                        <span class="ct-sl-stat-n ct-sl-stat-n--allowed"><?php echo esc_html( number_format_i18n( $allowed ) ); ?></span>
                        <span class="ct-sl-stat-l"><?php esc_html_e( 'Allowed', 'contempo' ); ?></span>
                    </div>
                    <div class="ct-sl-stat">
                        <span class="ct-sl-stat-n ct-sl-stat-n--blocked"><?php echo esc_html( number_format_i18n( $blocked ) ); ?></span>
                        <span class="ct-sl-stat-l"><?php esc_html_e( 'Blocked', 'contempo' ); ?></span>
                    </div>
                </div>

                <?php if ( ! empty( $reasons ) ) : ?>
                    <div class="ct-sl-pills">
                        <?php foreach ( $reasons as $r ) :
                            $label = $reason_labels[ $r->reason ] ?? esc_html( $r->reason );
                        ?>
                            <span class="ct-sl-pill">
                                <span class="ct-sl-pill-n"><?php echo esc_html( number_format_i18n( (int) $r->cnt ) ); ?></span>
                                <?php echo esc_html( $label ); ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

            <?php endif; ?>

            <!-- Column headers -->
            <div class="ct-sl-thead">
                <span class="ct-sl-c-ts"><?php esc_html_e( 'Date / Time', 'contempo' ); ?></span>
                <span class="ct-sl-c-st"><?php esc_html_e( 'Status', 'contempo' ); ?></span>
                <span class="ct-sl-c-re"><?php esc_html_e( 'Reason', 'contempo' ); ?></span>
                <span class="ct-sl-c-ip"><?php esc_html_e( 'IP', 'contempo' ); ?></span>
                <span class="ct-sl-c-ac"><?php esc_html_e( 'Action', 'contempo' ); ?></span>
                <span class="ct-sl-c-ua"><?php esc_html_e( 'User Agent', 'contempo' ); ?></span>
                <span class="ct-sl-c-btn"></span>
            </div>

            <!-- Rows -->
            <?php if ( $total === 0 ) : ?>
                <div class="ct-sl-empty">
                    <svg width="36" height="36" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" stroke="#9aa0a8" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    <?php esc_html_e( 'No entries yet. Form submission events will appear here once activity is recorded.', 'contempo' ); ?>
                </div>
            <?php elseif ( empty( $rows ) ) : ?>
                <div class="ct-sl-empty"><?php esc_html_e( 'No entries on this page.', 'contempo' ); ?></div>
            <?php else : ?>
                <?php foreach ( $rows as $row ) :
                    $badge_mod    = $row->status === 'allowed' ? 'allowed' : 'blocked';
                    $reason_label = isset( $reason_labels[ $row->reason ] ) ? $reason_labels[ $row->reason ] : ( $row->reason !== '' ? $row->reason : '—' );
                    $ts           = get_date_from_gmt( $row->logged_at, 'Y-m-d H:i:s' );
                    $entry        = wp_json_encode( [
                        'ts'     => $ts,
                        'status' => $row->status,
                        'reason' => $row->reason !== '' ? ( $reason_labels[ $row->reason ] ?? $row->reason ) : '—',
                        'ip'     => $row->ip,
                        'action' => $row->action,
                        'uri'    => $row->uri,
                        'ua'     => $row->ua,
                    ] );
                ?>
                    <div class="ct-sl-row">
                        <span class="ct-sl-c-ts"><?php echo esc_html( $ts ); ?></span>
                        <span class="ct-sl-c-st"><span class="ct-sl-badge ct-sl-badge--<?php echo esc_attr( $badge_mod ); ?>"><?php echo esc_html( $row->status ); ?></span></span>
                        <span class="ct-sl-c-re"><?php echo esc_html( $reason_label ); ?></span>
                        <span class="ct-sl-c-ip"><?php echo esc_html( $row->ip ); ?></span>
                        <span class="ct-sl-c-ac" title="<?php echo esc_attr( $row->action ); ?>"><?php echo esc_html( $row->action ); ?></span>
                        <span class="ct-sl-c-ua" title="<?php echo esc_attr( $row->ua ); ?>"><?php echo esc_html( mb_strimwidth( $row->ua, 0, 55, '…' ) ); ?></span>
                        <span class="ct-sl-c-btn">
                            <button class="ct-sl-view-btn" type="button" data-entry="<?php echo esc_attr( $entry ); ?>"><?php esc_html_e( 'View', 'contempo' ); ?></button>
                        </span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <!-- Footer: pagination + clear -->
            <div class="ct-sl-footer">
                <div class="ct-sl-pagination">
                    <?php if ( $total_pages > 1 ) : ?>
                        <?php if ( $cur_page > 1 ) : ?>
                            <a class="button button-secondary" href="<?php echo esc_url( add_query_arg( 'bp_log_page', $cur_page - 1, $page_url ) ); ?>">&lsaquo; <?php esc_html_e( 'Prev', 'contempo' ); ?></a>
                        <?php endif; ?>
                        <span>
                            <?php printf(
                                /* translators: 1: current page, 2: total pages */
                                esc_html__( 'Page %1$s of %2$s', 'contempo' ),
                                '<strong>' . esc_html( $cur_page ) . '</strong>',
                                '<strong>' . esc_html( $total_pages ) . '</strong>'
                            ); ?>
                        </span>
                        <?php if ( $cur_page < $total_pages ) : ?>
                            <a class="button button-secondary" href="<?php echo esc_url( add_query_arg( 'bp_log_page', $cur_page + 1, $page_url ) ); ?>"><?php esc_html_e( 'Next', 'contempo' ); ?> &rsaquo;</a>
                        <?php endif; ?>
                    <?php else : ?>
                        <span style="color:#9aa0a8;font-size:12px;">
                            <?php printf(
                                /* translators: number of entries */
                                esc_html( _n( '%s entry', '%s entries', $total, 'contempo' ) ),
                                '<strong>' . esc_html( number_format_i18n( $total ) ) . '</strong>'
                            ); ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div style="display:flex;align-items:center;gap:10px;">
                    <span class="ct-sl-footer-msg" id="ct-sl-footer-msg"></span>
                    <button class="ct-sl-clear-btn" id="ct-sl-clear-btn" type="button"><?php esc_html_e( 'Clear Log', 'contempo' ); ?></button>
                </div>
            </div>

        </div>

        <script>
        (function () {
            /* ---- Detail modal ---- */
            var overlay   = document.getElementById('ct-sl-overlay');
            var closeBtn  = document.getElementById('ct-sl-dialog-close');
            var fields    = { ts:'ct-sl-d-ts', st:'ct-sl-d-st', re:'ct-sl-d-re', ip:'ct-sl-d-ip', ac:'ct-sl-d-ac', ur:'ct-sl-d-ur', ua:'ct-sl-d-ua' };
            var entryKeys = { ts:'ts', st:'status', re:'reason', ip:'ip', ac:'action', ur:'uri', ua:'ua' };

            function openModal(entry) {
                Object.keys(fields).forEach(function (k) {
                    document.getElementById(fields[k]).textContent = entry[entryKeys[k]] || '—';
                });
                overlay.classList.add('is-open');
                if (closeBtn) closeBtn.focus();
            }
            function closeModal() { overlay.classList.remove('is-open'); }

            if (closeBtn) closeBtn.addEventListener('click', closeModal);
            if (overlay)  overlay.addEventListener('click', function (e) { if (e.target === overlay) closeModal(); });
            document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });

            document.querySelectorAll('.ct-sl-view-btn').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    try { openModal(JSON.parse(btn.dataset.entry)); } catch (e) {}
                });
            });

            /* ---- Clear log ---- */
            var clearBtn = document.getElementById('ct-sl-clear-btn');
            var msg      = document.getElementById('ct-sl-footer-msg');
            if (clearBtn) {
                clearBtn.addEventListener('click', function () {
                    if (!window.confirm(<?php echo wp_json_encode( __( 'Clear the entire security log? This cannot be undone.', 'contempo' ) ); ?>)) return;
                    clearBtn.disabled = true;
                    msg.style.color = '#50575e';
                    msg.textContent = <?php echo wp_json_encode( __( 'Clearing…', 'contempo' ) ); ?>;
                    var fd = new FormData();
                    fd.append('action', 'ct_bp_clear_log');
                    fd.append('nonce', <?php echo wp_json_encode( $clear_nonce ); ?>);
                    fetch(<?php echo wp_json_encode( $ajax_url ); ?>, { method: 'POST', body: fd, credentials: 'same-origin' })
                        .then(function (r) { return r.json(); })
                        .then(function (d) {
                            if (d.success) {
                                msg.style.color = '#027a48';
                                msg.textContent = <?php echo wp_json_encode( __( 'Cleared. Reloading…', 'contempo' ) ); ?>;
                                setTimeout(function () { window.location.reload(); }, 800);
                            } else {
                                msg.style.color = '#b42318';
                                msg.textContent = (d.data && d.data.message) ? d.data.message : <?php echo wp_json_encode( __( 'An error occurred.', 'contempo' ) ); ?>;
                                clearBtn.disabled = false;
                            }
                        })
                        .catch(function () {
                            msg.style.color = '#b42318';
                            msg.textContent = <?php echo wp_json_encode( __( 'Request failed.', 'contempo' ) ); ?>;
                            clearBtn.disabled = false;
                        });
                });
            }
        })();
        </script>
        <?php
    }

    /* -----------------------------------------------------------------------
     * Security Log — nav item live sync
     * --------------------------------------------------------------------- */

    /**
     * Inject JavaScript on the CT Settings admin page that syncs the
     * "Security Log" sidebar nav item visibility to the ct_bp_logging_enabled
     * toggle in real time — no page reload required.
     *
     * Behaviour:
     *   - On page load: hides the nav item if the toggle is currently OFF.
     *   - On toggle change → ON: shows the nav item and fetches fresh viewer
     *     HTML via AJAX so the section reflects the current state immediately.
     *   - On toggle change → OFF: hides the nav item; if the user is currently
     *     viewing the Security Log section, navigates them to Bot Protection.
     */
    public function inject_security_log_nav_sync(): void {
        $screen = get_current_screen();
        if ( ! $screen || strpos( $screen->id, 'ct_options' ) === false ) {
            return;
        }

        $ajax_url    = esc_url( admin_url( 'admin-ajax.php' ) );
        $viewer_nonce = wp_create_nonce( 'ct_bp_viewer' );
        ?>
        <script>
        (function () {
            var checkbox = document.getElementById('ct_field_ct_bp_logging_enabled');
            if (!checkbox) return;

            var AJAX_URL = <?php echo wp_json_encode( $ajax_url ); ?>;
            var NONCE    = <?php echo wp_json_encode( $viewer_nonce ); ?>;

            function isLogSectionActive() {
                var item = document.querySelector('li[data-section="security-log"]');
                return item && item.classList.contains('active');
            }

            function getViewerWrap() {
                return document.querySelector(
                    '#section-security-log [data-field-id="ct_bp_log_viewer"] .ct-field-raw-wrap'
                );
            }

            function refreshViewerContent() {
                var wrap = getViewerWrap();
                if (!wrap) return;

                wrap.style.opacity = '0.5';

                var fd = new FormData();
                fd.append('action', 'ct_bp_get_log_viewer');
                fd.append('nonce', NONCE);

                fetch(AJAX_URL, { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function (r) { return r.json(); })
                    .then(function (d) {
                        if (d.success && d.data && d.data.html !== undefined) {
                            wrap.innerHTML = d.data.html;
                            // Re-execute any inline <script> blocks (e.g. clear-log handler).
                            wrap.querySelectorAll('script').forEach(function (orig) {
                                var s = document.createElement('script');
                                s.textContent = orig.textContent;
                                orig.parentNode.replaceChild(s, orig);
                            });
                        }
                    })
                    .catch(function () {})
                    .finally(function () {
                        var w = getViewerWrap();
                        if (w) w.style.opacity = '';
                    });
            }

            function syncNavItem() {
                var navItem = document.querySelector('li[data-section="security-log"]');
                if (!navItem) return;

                var enabled = checkbox.checked;
                navItem.style.display = enabled ? '' : 'none';

                if (enabled) {
                    // Refresh the section content so it reflects the live state.
                    refreshViewerContent();
                } else if (isLogSectionActive()) {
                    // Navigate away from Security Log when disabling.
                    var bpLink = document.querySelector(
                        'li[data-section="bot-protection"] a.ct-nav-link'
                    );
                    if (bpLink) bpLink.click();
                }
            }

            // Initial page-load state (no AJAX — content already rendered server-side).
            var navItem = document.querySelector('li[data-section="security-log"]');
            if (navItem) navItem.style.display = checkbox.checked ? '' : 'none';

            // React to every toggle change.
            checkbox.addEventListener('change', syncNavItem);
        })();
        </script>
        <?php
    }

    /* -----------------------------------------------------------------------
     * Honeypot JS injection
     * --------------------------------------------------------------------- */

    public function inject_honeypot_script(): void {
        global $ct_options;

        if ( isset( $ct_options['ct_bp_honeypot_enabled'] ) && $ct_options['ct_bp_honeypot_enabled'] !== 'yes' ) {
            return;
        }

        if ( is_admin() ) {
            return;
        }
        ?>
        <script>
        (function() {
            function ctBpInjectFields(form) {
                if (form.dataset.ctBpInjected) return;
                form.dataset.ctBpInjected = '1';

                var hp = document.createElement('input');
                hp.type = 'text';
                hp.name = 'ct_hp_website';
                hp.value = '';
                hp.setAttribute('autocomplete', 'off');
                hp.setAttribute('tabindex', '-1');
                hp.setAttribute('aria-hidden', 'true');
                hp.style.cssText = 'position:absolute;left:-9999px;top:-9999px;width:0;height:0;overflow:hidden;opacity:0;pointer-events:none;';
                form.appendChild(hp);

                var ts = document.createElement('input');
                ts.type = 'hidden';
                ts.name = 'ct_form_time';
                ts.value = Math.floor(Date.now() / 1000);
                form.appendChild(ts);
            }

            function ctBpInitForms() {
                document.querySelectorAll('form').forEach(ctBpInjectFields);
            }

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', ctBpInitForms);
            } else {
                ctBpInitForms();
            }

            // Re-scan after any dynamically added forms (e.g. modals).
            if (window.MutationObserver) {
                new MutationObserver(function(mutations) {
                    mutations.forEach(function(m) {
                        m.addedNodes.forEach(function(node) {
                            if (node.nodeType !== 1) return;
                            if (node.tagName === 'FORM') {
                                ctBpInjectFields(node);
                            } else {
                                node.querySelectorAll && node.querySelectorAll('form').forEach(ctBpInjectFields);
                            }
                        });
                    });
                }).observe(document.body, { childList: true, subtree: true });
            }
        })();
        </script>
        <?php
    }
}
