/**
 * ct.page.init.js
 *
 * Handles page-level initialization on window load:
 *   - Search filter / more-options toggle
 *   - Single-listing owl carousel (listings-two layout)
 *   - Sub-listings owl carousel
 *   - Flexslider for listing single (#carousel, #slider, .flexslider)
 *   - Flexslider for non-listing-single pages (.flexslider)
 *
 * Reads configuration from ct_page_config (localized via wp_localize_script on 'flexslider').
 */
(function ($) {
	'use strict';

	if (typeof ct_page_config === 'undefined') {
		return;
	}

	var config = ct_page_config;

	$(window).on('load', function () {

		// Search filter toggle
		$('#filters-search-options-toggle').on('click', function () {
			$('#header-search-inner-wrap').toggle();
		});

		// Refresh jQuery UI sliders inside the More panel after it becomes visible.
		// Sliders initialize at DOM-ready when the panel is display:none (zero width),
		// so the range bar needs recalculation once the container has real dimensions.
		function ct_refresh_more_sliders() {
			$('#more-search-options').find('.ui-slider').each(function () {
				$(this).slider('refresh');
			});
		}

		// More search options toggle — modal or slideToggle depending on config
		$('#more-search-options-toggle').on('click', function () {
			if (config.use_modal_search) {
				$('#more-search-options').toggle();
				$('body').addClass('noscroll');
				ct_refresh_more_sliders();
			} else {
				$('#more-search-options').slideToggle('fast', ct_refresh_more_sliders);
			}
		});

		if (config.use_modal_search) {
			$(document).on('mouseup', function (e) {
				if (!$(e.target).closest('#more-search-options').length) {
					$('#more-search-options').each(function () {
						$(this).hide();
						$('body').removeClass('noscroll');
					});
				}
			});
		}

		// Single listing carousel (listings-two layout only)
		if (config.is_listing_single && config.listing_single_layout === 'listings-two') {
			var $owl = $('.owl-carousel');
			$owl.owlCarousel({
				items: 3,
				loop: true,
				margin: 0,
				nav: false,
				dots: false,
				autoplay: true,
				autoplayTimeout: 4000,
				autoplayHoverPause: true,
				responsive: {
					0:    { items: 1, nav: false },
					600:  { items: 2, nav: false },
					1000: { items: 3, nav: false, loop: false }
				}
			});
		}

		// Sub-listings carousel
		if (config.sub_listings_carousel) {
			var $owlSub = $('#owl-listings-carousel-sub-listings');
			$owlSub.owlCarousel({
				items: 3,
				slideBy: 3,
				loop: false,
				margin: 20,
				nav: true,
				navContainer: '#ct-listings-carousel-nav-sub-listings',
				navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
				dots: false,
				autoplay: false,
				responsive: {
					0:    { items: 1, nav: false },
					600:  { items: 2, nav: false },
					1000: { items: 3, nav: true }
				}
			});
		}

		if (config.is_listing_single) {

			// Listing single: thumbnail nav carousel
			$('#carousel').flexslider({
				animation: 'slide',
				controlNav: false,
				animateHeight: true,
				directionNav: true,
				animationLoop: false,
				slideshow: config.animation ? config.animation : true,
				slideshowSpeed: config.slideshow_speed,
				animationDuration: config.animation_duration,
				itemWidth: 120,
				itemMargin: 0,
				asNavFor: '#slider'
			});

			// Listing single: main slider (slideshow forced off — syncs with #carousel)
			$('#slider').flexslider({
				animation: config.animation_listing,
				slideDirection: config.slide_direction,
				slideshow: false,
				slideshowSpeed: config.slideshow_speed,
				animationDuration: config.animation_duration,
				smoothHeight: true,
				controlNav: false,
				animationLoop: false,
				sync: '#carousel'
			});

			// Listing single: additional flexslider instances (e.g. virtual tour)
			$('.flexslider').flexslider({
				animation: config.animation_listing,
				slideDirection: config.slide_direction,
				slideshow: config.animation ? config.animation : true,
				slideshowSpeed: config.slideshow_speed,
				animationDuration: config.animation_duration,
				controlNav: false,
				directionNav: true,
				keyboardNav: true,
				randomize: config.randomize,
				pauseOnAction: true,
				pauseOnHover: false,
				animationLoop: true
			});

		} else {

			// Non-listing-single pages: general flexslider
			$('.flexslider').flexslider({
				animation: config.animation,
				slideDirection: config.slide_direction,
				slideshow: config.animation ? config.animation : true,
				slideshowSpeed: config.slideshow_speed,
				animationDuration: config.animation_duration,
				controlNav: false,
				directionNav: true,
				keyboardNav: true,
				randomize: config.randomize,
				pauseOnAction: true,
				pauseOnHover: false,
				animationLoop: true,
				smoothHeight: true
			});
		}
	});
})(jQuery);
