(function ($) {

  $(function () {

    var $header = $('#header-wrap');
    if ( $header.length === 0 ) return;

    // Making theme check happy.
    var $adminbar      = $( '#' + 'wpadminbar' );
    var isAlwaysSticky = typeof ct_sticky_header_config !== 'undefined' &&
                         ct_sticky_header_config.show_type === 'always_sticky';

    $adminbar.css('z-index', '999999');

    if ( ! isAlwaysSticky ) { return; }

    // Always-sticky: the always-sticky class is applied server-side via PHP, so
    // position:fixed is in place from the very first paint — no DOM-ready layout change.
    // JS only wires the scroll listener that toggles the visual .sticky class.
    var $target = $header.is('.header-style-two')
        ? $( '#nav-full-width' )
        : $header;

    window.addEventListener('scroll', function () {
      $target.toggleClass('sticky', window.scrollY > 1);
    }, { passive: true });

  });

})(jQuery);

/*-----------------------------------------------------------------------------------*/
/* Scroll Up Effect for Sticky Header                                                */
/*-----------------------------------------------------------------------------------*/

jQuery(document).ready(function($) {

  'use strict';

  // Bail if always_sticky — that mode is handled by the block above.
  if ( typeof ct_sticky_header_config !== 'undefined' &&
       ct_sticky_header_config.show_type === 'always_sticky' ) {
    return;
  }

  var $placeholder = $( '#header-wrap-placeholder' );
  var $header      = $( '#header-wrap' );
  if ( $header.length === 0 ) return;

  // Making theme check happy.
  var $adminbar     = $( '#' + 'wpadminbar' );
  var lastScrollTop = 0;
  var scrolledDown  = false;
  var scrolledUp    = false;
  var zIndex        = 99990;
  var isTransparent = $header.hasClass('trans-header');

  $adminbar.css('z-index', '999999');

  // For scroll-reveal the header eventually becomes position:fixed (leaving document
  // flow), so the placeholder must hold that space. Measure after the first paint to
  // avoid triggering a synchronous layout during DOM-ready.
  if ( isTransparent ) {
    $placeholder.css('height', '0');
  } else {
    requestAnimationFrame(function () {
      var h = $header[0].offsetHeight;
      if ( h > 0 ) { $placeholder.css('height', h + 'px'); }
    });
  }

  // Re-measure on viewport resize so mobile/desktop transitions stay correct.
  // Transparent headers always hold zero space — guard prevents overwriting the '0' set above.
  var _phResizeTimer;
  window.addEventListener('resize', function () {
    clearTimeout(_phResizeTimer);
    _phResizeTimer = setTimeout(function () {
      if ( isTransparent ) return;
      var h = $header[0].offsetHeight;
      if ( h > 0 ) { $placeholder.css('height', h + 'px'); }
    }, 100);
  }, { passive: true });

  // Add offset so scroll trigger doesn't fire prematurely.
  var offset = $adminbar.length ? $adminbar[0].offsetHeight : 0;
  var headerHeight = $header[0].offsetHeight + offset;

  if ( $header.hasClass('header-style-two') ) {
    var $nav = $( '#nav-full-width' );
    headerHeight = ( $nav.length ? $nav[0].offsetHeight : 0 ) + offset;
  }

  if ( isTransparent ) {
    $header.css({ position: 'absolute', left: 0, 'z-index': zIndex }).addClass('snap-to-top');
  }

  window.addEventListener('scroll', function() {

    var st = window.scrollY;

    if ( st <= headerHeight ) {
      $header.removeClass('active sticky inactive');
      if ( isTransparent ) {
        $header.css({ position: 'absolute', left: 0, 'z-index': zIndex }).addClass('snap-to-top');
      } else {
        $header.css({ position: '', left: '', 'z-index': '' });
      }
      scrolledDown  = false;
      scrolledUp    = false;
      lastScrollTop = 0;
      return;
    }

    if ( st > lastScrollTop ) {
      if ( ! scrolledDown ) {
        $header.removeClass('active snap-to-top sticky').addClass('inactive');
        scrolledDown = true;
        scrolledUp   = false;
        setTimeout(function () {
          $header.css({ position: 'static', left: 0, 'z-index': zIndex });
        }, 100);
      }
    } else {
      if ( ! scrolledUp ) {
        $header.addClass('sticky active').removeClass('inactive');
        $header.css({ position: 'fixed', left: 0, 'z-index': zIndex });
        scrolledUp   = true;
        scrolledDown = false;
      }
    }

    // Guard against negative scroll on mobile rubber-band.
    lastScrollTop = st <= 0 ? 0 : st;

  }, false);

});
