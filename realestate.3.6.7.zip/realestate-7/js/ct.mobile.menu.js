/**
 * CT Mobile Menu
 *
 * @package WP Pro Real Estate 7
 * @subpackage JavaScript
 */

jQuery(function ($) {
    $(document).ready(function () {

        $(".mobile-nav ul").removeClass("cbp-tm-menu");
        $(".mobile-nav ul").addClass("cbp-spmenu");

        var menuLeft = document.getElementById("cbp-spmenu"),
            showLeftPush = document.getElementById("showLeftPush"),
            showLeftPushIcon = document.getElementById("showLeftPushIcon"),
            headerWrap = document.getElementById("header-wrap"),
            body = document.body;

        if ( ! showLeftPush || ! menuLeft ) {
            return;
        }

        showLeftPush.addEventListener('click', function () {
            $("body").on("touchmove", function (e) {
                e.preventDefault();
            });

            this.classList.toggle("active");
            body.classList.toggle("cbp-spmenu-push-toleft");
            body.classList.toggle("stop-scrolling");
            menuLeft.classList.toggle("cbp-spmenu-open");
            if (headerWrap) {
                headerWrap.classList.toggle("to-left");
            }

            var isOpen = menuLeft.classList.contains("cbp-spmenu-open");

            // Update icon
            if (showLeftPushIcon) {
                if (isOpen) {
                    showLeftPushIcon.classList.remove("fa-bars");
                    showLeftPushIcon.classList.add("fa-xmark");
                } else {
                    showLeftPushIcon.classList.remove("fa-xmark");
                    showLeftPushIcon.classList.add("fa-bars");
                }
            }

            // Update ARIA
            showLeftPush.setAttribute("aria-expanded", isOpen ? "true" : "false");
            if (menuLeft) {
                menuLeft.setAttribute("aria-hidden", isOpen ? "false" : "true");
            }

            // Toggle backdrop
            var backdrop = document.getElementById("ct-menu-backdrop");
            if (backdrop) {
                backdrop.classList.toggle("is-visible", isOpen);
            }
        });

        // Close on backdrop click
        document.addEventListener('click', function (e) {
            if (e.target && e.target.id === 'ct-menu-backdrop') {
                showLeftPush.click();
            }
        });

        if (!$("body").hasClass("stop-scrolling")) {
            $("body").off("touchmove");
        }
    });
});

/**
 * Toggle Support
 * jshint: es6
 */
jQuery(document).ready(function ($) {

    "use strict";

    let $mobile_menu = $("#cbp-spmenu ul.menu");
    let $parent_menu_items = $mobile_menu.find("li.menu-item-has-children");
    $.each($parent_menu_items, function () {
        $("> a", $(this)).append("<span class='submenu-toggle'><i class='fas fa-chevron-down'></i></span>");
    });

    $("#cbp-spmenu li.current-menu-item").parentsUntil('ul.menu').addClass('open');
    $("#cbp-spmenu li.current-menu-item").parentsUntil('ul.menu').css('display', 'block');

    $("span.submenu-toggle").click(function (e) {
        e.preventDefault();
        let $parent_list = $(this).parent().parent();
        $parent_list.toggleClass('open');
        $parent_list.find(" > ul.sub-menu").slideToggle('fast');
    });
});
