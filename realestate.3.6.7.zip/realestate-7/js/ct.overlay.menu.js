/**
 * CT Overlay Menu — Header Style 4
 *
 * Handles open/close of the full-screen nav overlay, ARIA state,
 * ESC-key support, body scroll lock, and click-to-open submenus.
 *
 * @package WP Pro Real Estate 7
 * @subpackage JavaScript
 */

jQuery( function ( $ ) {
    'use strict';

    var $overlay  = $( '#ct-nav-overlay' );
    var $toggle   = $( '#ct-overlay-toggle' );
    var $close    = $( '#ct-overlay-close' );
    var $body     = $( 'body' );

    if ( ! $overlay.length || ! $toggle.length ) {
        return;
    }

    // -------------------------------------------------------------------------
    // Open / Close helpers
    // -------------------------------------------------------------------------

    function openOverlay() {
        $overlay.addClass( 'is-open' );
        $body.addClass( 'ct-overlay-open' );
        $overlay.attr( 'aria-hidden', 'false' );
        $toggle.attr( 'aria-expanded', 'true' );
        // Move focus into overlay for keyboard users
        $overlay.find( '#ct-overlay-close' ).trigger( 'focus' );
    }

    function closeOverlay() {
        $overlay.removeClass( 'is-open' );
        $body.removeClass( 'ct-overlay-open' );
        $overlay.attr( 'aria-hidden', 'true' );
        $toggle.attr( 'aria-expanded', 'false' );
        $toggle.trigger( 'focus' );
    }

    // -------------------------------------------------------------------------
    // Toggle on hamburger click
    // -------------------------------------------------------------------------

    $toggle.on( 'click', function () {
        if ( $overlay.hasClass( 'is-open' ) ) {
            closeOverlay();
        } else {
            openOverlay();
        }
    } );

    // -------------------------------------------------------------------------
    // Close button
    // -------------------------------------------------------------------------

    $close.on( 'click', function () {
        closeOverlay();
    } );

    // -------------------------------------------------------------------------
    // ESC key closes overlay
    // -------------------------------------------------------------------------

    $( document ).on( 'keydown', function ( e ) {
        if ( e.key === 'Escape' || e.keyCode === 27 ) {
            if ( $overlay.hasClass( 'is-open' ) ) {
                closeOverlay();
            }
        }
    } );

    // -------------------------------------------------------------------------
    // Inject submenu toggle spans into parent menu items
    // -------------------------------------------------------------------------

    var $parentItems = $overlay.find( 'ul.ct-overlay-menu li.menu-item-has-children' );

    $parentItems.each( function () {
        var $link = $( '> a', $( this ) );
        $link.append( '<span class="ct-overlay-submenu-toggle" aria-hidden="true"><i class="fas fa-chevron-down"></i></span>' );

        // First click opens the submenu; second click (when already open) follows the link
        $link.on( 'click', function ( e ) {
            var $item = $( this ).parent();
            if ( ! $item.hasClass( 'open' ) ) {
                e.preventDefault();
                toggleSubmenu( $item );
            }
            // If already open, fall through — browser follows the href naturally
        } );
    } );

    function closeSubmenu( $item ) {
        $item.removeClass( 'open' );
        $item.find( '> .sub-menu' ).slideUp( 200 );
    }

    function toggleSubmenu( $item ) {
        var isOpen = $item.hasClass( 'open' );

        // Accordion: close any other open siblings at the same level before opening
        $item.siblings( 'li.menu-item-has-children.open' ).each( function () {
            closeSubmenu( $( this ) );
        } );

        if ( ! isOpen ) {
            $item.addClass( 'open' );
            $item.find( '> .sub-menu' ).slideDown( 200 );
        }
        // If it was already open, the fall-through in the click handler navigates
    }

    // -------------------------------------------------------------------------
    // Auto-open submenus for the current active trail
    // -------------------------------------------------------------------------

    $overlay.find( 'li.current-menu-item, li.current-menu-ancestor, li.current_page_parent' )
        .parentsUntil( 'ul.ct-overlay-menu' )
        .filter( 'li.menu-item-has-children' )
        .each( function () {
            $( this ).addClass( 'open' );
            $( this ).find( '> .sub-menu' ).show();
        } );

} );
