/**
 * ct.geocomplete.init.js
 *
 * Initializes the geocomplete address autocomplete map on the submit-listing
 * and edit-listing templates. Reads entirely from the DOM — no PHP values needed.
 *
 * Wrapped in an IIFE to scope $ safely under jQuery.noConflict().
 */
(function ($) {
	'use strict';

	$(function () {

		function Onnextload() {
			var customcords = $('#customMetaLatLng').val();
			var ccords = customcords.split(',');
			var mlat = ccords[0];
			var mlng = ccords[1];

			$('#pac-input').geocomplete({
				map: '#map-canvas',
				details: 'form',
				zoom: 10,
				location: [mlat, mlng],
				markerOptions: { draggable: true },
				types: ['geocode', 'establishment']
			});

			$('#pac-input').geocomplete('find', $('input[name=customMetaLatLng]').val());

			setTimeout(function () {
				$('.pac-container').prependTo('#autocomplete-results');
			}, 300);
		}

		// Run immediately on ready, then expose for external callers
		Onnextload();
		window.Onnextload = Onnextload;

		$('#pac-input').on('geocode:dragged', function (event, latLng) {
			$('input[name=lat]').val(latLng.lat());
			$('input[name=lng]').val(latLng.lng());
			$('#pac-input').geocomplete('find', latLng.toString());

			var latlong = latLng.lat() + ', ' + latLng.lng();
			$('input[name=customMetaLatLng]').val(latlong);

			var map = $('#pac-input').geocomplete('map');
			map.panTo(latLng);

			var geocoder = new google.maps.Geocoder();
			geocoder.geocode({ latLng: latLng }, function (results, status) {
				if (status === google.maps.GeocoderStatus.OK && results[0]) {
					// formatted_address available as results[0].formatted_address if needed
				}
			});
		});

		$('#pac-input').on('click', function () {
			$('#pac-input').trigger('geocode');
		});
	});
})(jQuery);
