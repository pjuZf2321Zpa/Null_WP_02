/**
 * Submit Listing
 * 
 * @package WP Pro Real Estate 7
 * @subpackage JavaScript
 */

jQuery.fn.extend({
    live: function (event, callback) {
       if (this.selector) {
            jQuery(document).on(event, this.selector, callback);
        }
        return this;
    }
});

jQuery(document).ready(function($) {

	jQuery(function($) {
		/* Apply Sortable to Gallery Items */
		$( "#sortable" ).sortable({
		  placeholder: "placeholder col span_4",
		  revert: 100,
		  opacity: 0.9,
		  cursor: "move"
		});
		$( "#sortable" ).disableSelection();

		var postID = PostID.post_id;
		var templatePATH = TemplatePath.templateUrl;
		
		var fileTypeTitle = fileTypeTitle;

		/* Initialize Uploader */
		var uploader = new plupload.Uploader({
			runtimes: 'html5',
			chunk_size: '200kb',
			browse_button: 'select-images',
			container: 'plupload-container',
			drop_element: 'drag-drop-area',
			url: AdminURL.ajaxUrl + "?action=ct_front_img_upload&postid=" + PostID.post_id + "&_wpnonce=" + jQuery('#post_nonce_field').val(),
			max_retries: 5,
			multi_selection: true,
			file_data_name: 'async-upload',
			filters: {
				max_file_size: '10MB',
				prevent_duplicates: true
			},
			init: {
				FilesAdded: function(up, files) {
					plupload.each(files, function(file) {
						// Check if placeholder already exists
						if (jQuery("#file-" + file.id).length > 0) {
							return; // Skip if already exists
						}
						
						var galleryThumb = '<li id="file-' + file.id + '" class="col span_4 ui-sortable-handle">' +
							'<figure class="gallery-thumb">' +
							'<span class="featured-img"><a href="#" name="%1%" class="setImageFeatured"><i class="fa fa-star-o"></i></a></span>' +
							'<span class="delete-img"><a href="#" name="%1%" class="remImage"><i class="fa fa-trash-o"></i></a></span>' +
							'<img src="' + templatePATH + '/images/upload-placeholder.png">' +
							'<input type="hidden" value="%1%" id="att_id" name="att_id[]">' +
							'</figure>' +
							'<span class="loading"><i class="fa fa-circle-o-notch fa-spin"></i></span>' +
							'</li>';
						jQuery('#sortable').append(galleryThumb);
					});
					up.start();
				},
				FileUploaded: function(up, file, response) {
					try {
						var resp = JSON.parse(response.response);
						if (resp.success) {
							var element = jQuery("#file-" + file.id);
							
							// Prevent duplicate processing
							if (element.hasClass('processed')) {
								return;
							}
							element.addClass('processed');
							
							element.html(function(index, html) {
								return html.replace(/%1%/g, resp.data.id_att);
							});
							element.find('img').attr('src', resp.data.link);
							element.find('.loading').remove();
							element.attr('id', "file-" + resp.data.id_att);
						} else {
							console.error('Upload failed:', resp.data.message);
							alert('Upload failed: ' + resp.data.message);
						}
					} catch(e) {
						console.error('Upload response parse error:', e);
						alert('Error processing upload response');
					}
				},
				Error: function(up, err) {
					console.error('Upload error:', err);
					if (err.code === plupload.HTTP_ERROR) {
						console.error('HTTP Error. Status:', err.status);
					}
					alert("Error #" + err.code + ": " + err.message);
				}
			}
		});

		uploader.bind('Init', function(up) {
			var uploaddiv = $('#plupload-upload-ui');

			if ( up.features.dragdrop && ! $(document.body).hasClass('mobile') ) {
				uploaddiv.addClass('drag-drop');
				$('#drag-drop-area').bind('dragover.wp-uploader', function(){ // dragenter doesn't fire right :(
					uploaddiv.addClass('drag-over');
				}).bind('dragleave.wp-uploader, drop.wp-uploader', function(){
					uploaddiv.removeClass('drag-over');
				});
			} else {
				uploaddiv.removeClass('drag-drop');
				$('#drag-drop-area').unbind('.wp-uploader');
			}

			if ( up.runtime === 'html4' ) {
				$('.upload-flash-bypass').hide();
			}
		});

		uploader.init();

		/* Remove Image */
		$(document).on('click', '.remImage', function(event) {
			event.preventDefault();
			var attID = jQuery(this).attr('name');
			var $fileElement = $('#file-' + attID);
			
			$fileElement.append("<span class='loading'><i class='fa fa-circle-o-notch fa-spin'></i></span>");
			
			jQuery.ajax({
				type: 'post',
				url: AdminURL.ajaxUrl,
				data: {
					action: 'ct_delete_attachment_edit',
					att_ID: attID,
					_ajax_nonce: jQuery('#post_nonce_field').val()
				},
				success: function(response) {
					if (response.success) {
						$fileElement.fadeOut(function() {
							$(this).remove();
						});
					} else {
						alert(response.data.message || 'Error deleting file');
						$fileElement.find('.loading').remove();
					}
				},
				error: function() {
					alert('Network error occurred');
					$fileElement.find('.loading').remove();
				}
			});
		});
		
		/* Set featured Image */
		$(document).on('click','.setImageFeatured', function(event) {
			event.preventDefault();
			var attID = jQuery(this).attr('name');
			var element=jQuery(this);
			jQuery('.setImageFeatured .fa-star').each(function(){
				$(this).removeClass('fa-star').addClass('fa-star-o');
			});
			jQuery(element).find('.fa').removeClass('fa-star-o').addClass('fa-star');
			jQuery("#featured_id").val(attID);
		});
	});
});