/**
 * ct.sliders.js
 *
 * Initializes the jQuery UI price, size, and lot-size range sliders.
 * Reads configuration from:
 *   - object_name   (localized by _ct_localize_base_script)
 *   - ct_sliders_data (localized by _ct_localize_base_script — GET pre-population values)
 */
(function ($) {
	'use strict';

	if (typeof object_name === 'undefined' || typeof ct_sliders_data === 'undefined') {
		return;
	}

	var currency          = object_name.currency;
	var currencyPlacement = object_name.currency_placement;
	var sqftsm            = object_name.sqftsm;
	var acres             = object_name.acres;
	var priceMin          = parseInt(object_name.price_slider_min_value, 10);
	var priceMax          = parseInt(object_name.price_slider_max_value, 10);
	var sizeMin           = parseInt(object_name.size_slider_min_value, 10);
	var sizeMax           = parseInt(object_name.size_slider_max_value, 10);
	var lotMin            = parseInt(object_name.lot_size_slider_min_value, 10);
	var lotMax            = parseInt(object_name.lot_size_slider_max_value, 10);

	var priceFrom   = parseInt(ct_sliders_data.price_from, 10);
	var priceTo     = parseInt(ct_sliders_data.price_to, 10);
	var sqftFrom    = parseInt(ct_sliders_data.sqft_from, 10);
	var sqftTo      = parseInt(ct_sliders_data.sqft_to, 10);
	var lotsizeFrom = parseInt(ct_sliders_data.lotsize_from, 10);
	var lotsizeTo   = parseInt(ct_sliders_data.lotsize_to, 10);

	function numberWithCommas(x) {
		if (x !== null) {
			return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
		}
	}

	function formatPrice(value) {
		return currencyPlacement === 'after'
			? numberWithCommas(value) + currency
			: currency + numberWithCommas(value);
	}

	$(function () {

		// Price From / To
		$('#slider-range').slider({
			range: true,
			min: priceMin,
			step: Math.max(1, Math.ceil((priceMax - priceMin) / 200)),
			max: priceMax,
			values: [priceFrom, priceTo],
			slide: function (event, ui) {
				$('#slider-range #min').html(formatPrice(ui.values[0]));
				$('#slider-range #max').html(formatPrice(ui.values[1]));
				$('#price-from-to-slider .min-range').html(formatPrice(ui.values[0]));
				$('#price-from-to-slider .max-range').html(formatPrice(ui.values[1]));
				$('#ct_price_from').val(ui.values[0]);
				$('#ct_price_to').val(ui.values[1]);
			}
		});

		var $handler = $('#slider-range .ui-slider-handle');
		$handler.eq(0).append("<b class='amount'><span id='min'>" + formatPrice($('#slider-range').slider('values', 0)) + '</span></b>');
		$handler.eq(1).append("<b class='amount'><span id='max'>" + formatPrice($('#slider-range').slider('values', 1)) + '</span></b>');

		$handler.on('mousedown', function (e) {
			e.preventDefault();
			$(this).children('.amount').fadeIn(300);
		});
		$handler.on('mouseup', function (e) {
			e.preventDefault();
			$(this).children('.amount').fadeOut(300);
		});

		// Size From / To (square feet / m²)
		$('#slider-range-two').slider({
			range: true,
			min: sizeMin,
			step: 100,
			max: sizeMax,
			values: [sqftFrom, sqftTo],
			slide: function (event, ui) {
				$('#slider-range-two #min').html(numberWithCommas(ui.values[0]));
				$('#slider-range-two #max').html(numberWithCommas(ui.values[1]));
				$('#size-from-to-slider .min-range').html(numberWithCommas(ui.values[0]) + sqftsm);
				$('#size-from-to-slider .max-range').html(numberWithCommas(ui.values[1]) + sqftsm);
				$('#ct_sqft_from').val(ui.values[0]);
				$('#ct_sqft_to').val(ui.values[1]);
			}
		});

		var $handlertwo = $('#slider-range-two .ui-slider-handle');
		$('#size-from-to-slider .min-range').append(sqftsm);
		$('#size-from-to-slider .max-range').append(sqftsm);
		$handlertwo.eq(0).append("<b class='amount'><span id='min'>" + numberWithCommas($('#slider-range-two').slider('values', 0)) + '</span>' + sqftsm + '</b>');
		$handlertwo.eq(1).append("<b class='amount'><span id='max'>" + numberWithCommas($('#slider-range-two').slider('values', 1)) + '</span>' + sqftsm + '</b>');

		$handlertwo.on('mousedown', function (e) {
			e.preventDefault();
			$(this).children('.amount').fadeIn(300);
		});
		$handlertwo.on('mouseup', function (e) {
			e.preventDefault();
			$(this).children('.amount').fadeOut(300);
		});

		// Lot-size From / To
		$('#slider-range-three').slider({
			range: true,
			min: lotMin,
			step: 1,
			max: lotMax,
			values: [lotsizeFrom, lotsizeTo],
			slide: function (event, ui) {
				$('#slider-range-three #min').html(numberWithCommas(ui.values[0]));
				$('#slider-range-three #max').html(numberWithCommas(ui.values[1]));
				$('#lotsize-from-to-slider .min-range').html(numberWithCommas(numberWithCommas(ui.values[0]) + ' ' + acres));
				$('#lotsize-from-to-slider .max-range').html(numberWithCommas(numberWithCommas(ui.values[1]) + ' ' + acres));
				$('#ct_lotsize_from').val(ui.values[0]);
				$('#ct_lotsize_to').val(ui.values[1]);
			}
		});

		var $handlerthree = $('#slider-range-three .ui-slider-handle');
		$('#lotsize-from-to-slider .min-range').append(' ' + acres);
		$('#lotsize-from-to-slider .max-range').append(' ' + acres);
		$('#lotsize-from-to-slider .min-range').replaceWith(
			"<span class='min-range'>" + numberWithCommas($('#slider-range-three').slider('values', 0)) + ' ' + acres + '</span>'
		);

		$handlerthree.eq(0).append("<b class='amount'><span id='min'>" + numberWithCommas($('#slider-range-three').slider('values', 0)) + '</span> ' + acres + '</b>');
		$handlerthree.eq(1).append("<b class='amount'><span id='max'>" + numberWithCommas($('#slider-range-three').slider('values', 1)) + '</span> ' + acres + '</b>');

		$handlerthree.on('mousedown', function (e) {
			e.preventDefault();
			$(this).children('.amount').fadeIn(300);
		});
		$handlerthree.on('mouseup', function (e) {
			e.preventDefault();
			$(this).children('.amount').fadeOut(300);
		});
	});
})(jQuery);
