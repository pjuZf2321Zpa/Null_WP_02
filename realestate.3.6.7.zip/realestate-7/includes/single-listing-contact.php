<?php
/**
 * Single Listing Content
 *
 * @package WP Pro Real Estate 7
 * @subpackage Include
 */
 
global $ct_options;

$ct_single_listing_agent_details_layout = isset( $ct_options['ct_single_listing_agent_details_layout']['enabled'] ) ? $ct_options['ct_single_listing_agent_details_layout']['enabled'] : '';
$ct_listing_agent_contact_logged_in = isset( $ct_options['ct_listing_agent_contact_logged_in'] ) ? $ct_options['ct_listing_agent_contact_logged_in'] : '';
$ct_co_listing_agent_enabled = isset( $ct_options['ct_co_listing_agent_enabled'] ) ? $ct_options['ct_co_listing_agent_enabled'] : 'no';

$ct_source = get_post_meta($post->ID, 'source', true);

$ct_idx_pro_assign_agents = get_option( 'ct_idx_pro_assign_agents' );
$ct_idx_pro_assign_agents = isset( $ct_idx_pro_assign_agents ) ? $ct_idx_pro_assign_agents : '';
$ct_idx_pro_assign_agents = json_decode($ct_idx_pro_assign_agents, true);

if(!empty($ct_idx_pro_assign_agents) && $ct_source == 'idx-api') {
    
    foreach($ct_idx_pro_assign_agents as $agent) {
        $ct_agent_first_name = get_user_meta($agent, 'first_name', true);
        $ct_agent_last_name = get_user_meta($agent, 'last_name', true);
        $ct_agent_display_name = $ct_agent_first_name . ' ' . $ct_agent_last_name;
        $ct_agent_name_IDX = get_post_meta( $post->ID, '_ct_agent_name', true );

        if($ct_agent_name_IDX == $ct_agent_display_name) {
            $author_id = $agent;
            $user_info = get_userdata($agent);
        } else {
            $author_id = get_the_author_meta('ID');
            $user_info = get_userdata($author_id);
        }
    }

} else {
    $author_id = get_the_author_meta('ID');
    $user_info = get_userdata($author_id);
}

$ct_profile_url = get_user_meta($author_id, 'ct_profile_url', true);
$first_name = get_user_meta($author_id, 'first_name', true);
$last_name = get_user_meta($author_id, 'last_name', true);
$tagline = get_user_meta($author_id, 'tagline', true);
$specialties = get_user_meta($author_id, 'specialties', true);
$mobile = get_user_meta($author_id, 'mobile', true);
$office = get_user_meta($author_id, 'office', true);
$fax = get_user_meta($author_id, 'fax', true);
$email = isset( $user_info->user_email ) ? $user_info->user_email: '';
$agent_license = get_user_meta($author_id, 'agentlicense', true);
$ct_user_url = get_user_meta($author_id, 'user_url', true);
$twitterhandle = get_user_meta($author_id, 'twitterhandle', true);
$facebookurl = get_user_meta($author_id, 'facebookurl', true);
$instagramurl = get_user_meta($author_id, 'instagramurl', true);
$linkedinurl = get_user_meta($author_id, 'linkedinurl', true);
$gplus = get_user_meta($author_id, 'gplus', true);
$youtubeurl = get_user_meta($author_id, 'youtubeurl', true);

$ct_listing_price = get_post_meta( get_the_ID(), '_ct_price', true );
$ct_listing_price = preg_replace( '/[\$,]/', '', $ct_listing_price );
$ct_listing_sqft = get_post_meta( get_the_ID(), '_ct_sqft', true );
$ct_listing_beds = strip_tags( get_the_term_list( get_the_ID(), 'beds', '', ', ', '' ) );
$ct_listing_baths = strip_tags( get_the_term_list( get_the_ID(), 'baths', '', ', ', '' ) );
$ct_listing_lotsize = get_post_meta( get_the_ID(), '_ct_lotsize', true );
$ct_listing_mls_number = get_post_meta( get_the_ID(), '_ct_mls', true );
$ct_property_type = strip_tags( get_the_term_list( get_the_ID(), 'property_type', '', ', ', '' ) );

?>

<?php do_action('before_single_listing_agent'); ?>

<!-- Agent Contact -->
<div id="listing-contact" class="marb20 listing-agent-contact">
    <div class="main-agent">

        <?php if($ct_single_listing_agent_details_layout) {

            echo '<div class="col span_4 first agent-info">';

                if($ct_listing_agent_contact_logged_in == 'yes') {
        
                    if(!is_user_logged_in()) {

                        echo '<div class="must-be-logged-in-agent">';
                            echo '<div class="must-be-logged-in-agent-info">';
                                echo '<p class="center">' . __('You must be registered to view agent details', 'contempo') . '</p>';
                                echo '<p class="center login-register-btn marB0"><a class="btn login-register" href="#">Login/Register</a></p>';
                            echo '</div>';
                        echo '</div>';

                    }

                }
                            
                foreach($ct_single_listing_agent_details_layout as $key => $value) {

                    switch($key) {

                        // Agent Name
                        case 'listing_agent_name' : ?>    

                            <?php if(!empty($first_name) || !empty($last_name)) { ?>
                                <h4 class="border-bottom marB20 <?php ct_blur_agent_details(); ?>"><small id="agent-print-only"><?php _e('Agent', 'contempo'); ?></small><a href="<?php echo get_author_posts_url($author_id); ?>"><?php echo esc_html($first_name); ?> <?php echo esc_html($last_name); ?></a></h4>
                            <?php } ?>
                        
                        <?php break; ?>

                        <?php case 'listing_agent_image' : ?>    

                            <?php
                            echo '<figure class="col span_12 first row">';
                                echo '<a href="' . get_author_posts_url($author_id) . '">';
                                   if(!empty($ct_profile_url)) { ?>  
                                        <img class="authorimg <?php ct_blur_agent_details(); ?>" src="<?php echo esc_url($ct_profile_url); ?>" />
                                    <?php } else {
                                        echo '<img class="author-img <?php ct_blur_agent_details(); ?>" src="' . get_template_directory_uri() . '/images/user-default.png' . '" />';
                                    }
                                echo '</a>';
                            echo '</figure>';
                            ?>
                        
                        <?php break; ?>

                        <?php case 'listing_agent_info' : ?>    

                            <?php do_action('before_single_listing_agent_details'); ?>

                             <ul class="marB0 <?php ct_blur_agent_details(); ?>">
                                <?php if($mobile) { ?>
                                    <li class="marT3 marB0 row"><span class="left"><?php ct_phone_svg(); ?></span><span class="right"><a href="tel:<?php echo esc_html($mobile); ?>"><?php echo esc_html($mobile); ?></a></span></li>
                                <?php } ?>
                                <?php if($office) { ?>
                                    <li class="marT3 marB0 row"><span class="left"><?php ct_office_svg(); ?></span><span class="right"><a href="tel:<?php echo esc_html($office); ?>"><?php echo esc_html($office); ?></a></span></li>
                                <?php } ?>
                                <?php if($fax) { ?>
                                    <li class="marT3 marB0 row"><span class="left"><?php ct_printer_svg(); ?></span><span class="right"><a href="tel:<?php echo esc_html($fax); ?>"><?php echo esc_html($fax); ?></a></span></li>
                                <?php } ?>
                                <?php if($email) { ?>
                                    <li class="marT3 marB0 row"><span class="left"><?php ct_envelope_svg(); ?></span><span class="right"><a href="mailto:<?php echo antispambot($email,1) ?>" target="_blank"><?php esc_html_e('Email', 'contempo'); ?></a></span></li>
                                <?php } ?>
                                <?php if($ct_user_url) {
                                    $ct_user_url = trim($ct_user_url, '/');
                                    // If scheme not included, prepend it
                                    if (!preg_match('#^http(s)?://#', $ct_user_url)) {
                                        $ct_user_url = 'http://' . $ct_user_url;
                                    }

                                    $ct_urlParts = parse_url($ct_user_url);

                                    // remove www
                                    $ct_domain = preg_replace('/^www\./', '', $ct_urlParts['host']);
                                ?>
                                    <li class="row"><span class="left"><?php ct_globe_svg(); ?></span> <span class="right"><a href="<?php echo esc_html($ct_user_url); ?>"><?php echo esc_html($ct_domain); ?></a></span></li>
                                <?php } ?>
                                <?php if($agent_license) { ?>
                                    <li class="marT3 marB0 row"><span class="left"><?php _e('Agent #', 'contempo'); ?></span><span class="right"><?php echo esc_html($agent_license); ?></a></span></li>
                                <?php } ?>
                            </ul>
                        
                        <?php break; ?>

                        <?php case 'listing_agent_specialties' : ?>

                            <?php 
                                if(!empty($specialties)) {
                                    $specialties_array = explode(',', $specialties);

                                    echo '<div id="agent-specialties" class="marT15">';
                                        foreach($specialties_array as $specialty) { 

                                            echo '<span>';
                                                echo trim($specialty);
                                            echo '</span>';

                                        } 
                                    echo '</div>';
                                } 
                            ?>

                        <?php break; ?>

                        <?php case 'listing_agent_social' : ?>    

                            <ul class="social marT20 marL0 <?php ct_blur_agent_details(); ?>">
                                <?php if ($twitterhandle) { ?><li class="twitter"><a href="https://twitter.com/#!/<?php echo esc_html($twitterhandle); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li><?php } ?>
                                <?php if ($facebookurl) { ?><li class="facebook"><a href="<?php echo esc_url($facebookurl); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li><?php } ?>
                                <?php if ($instagramurl) { ?><li class="instagram"><a href="<?php echo esc_url($instagramurl); ?>" target="_blank"><i class="fa fa-instagram"></i></a></li><?php } ?>
                                <?php if ($linkedinurl) { ?><li class="facebook"><a href="<?php echo esc_url($linkedinurl); ?>" target="_blank"><i class="fa fa-linkedin"></i></a></li><?php } ?>
                                <?php if ($youtubeurl) { ?><li class="youtube"><a href="<?php echo esc_url($youtubeurl); ?>" target="_blank"><i class="fa fa-youtube"></i></a></li><?php } ?>
                            </ul>

                        <?php break;

                    }
                }

            echo '</div>';

        } ?>

            <?php do_action('before_single_listing_agent_contact'); ?>
            
            <div class="col span_8 agent-contact">
                <h4 class="border-bottom marB20"><?php esc_html_e('Request More Information', 'contempo'); ?></h4>
                
                <?php
                $ct_default_listing_form_id = get_option( 'ct_default_listing_form_id' );
                if ( $ct_default_listing_form_id && shortcode_exists( 'ct_form' ) ) {
                    echo do_shortcode( '[ct_form id="' . absint( $ct_default_listing_form_id ) . '"]' );
                } else {
                    echo '<p>' . sprintf(
                        __( 'Please <a href="mailto:%s">contact us by email</a>.', 'contempo' ),
                        esc_attr( get_option( 'admin_email' ) )
                    ) . '</p>';
                }
                ?>

            </div>
        </div>
                <div class="clear"></div>

        <?php
        $co_agent_id = $ct_co_listing_agent_enabled === 'yes'
            ? get_post_meta( get_the_id(), '_ct_co_listing_agent', true )
            : false;

        if ( $co_agent_id ) :
            $co_agent_info  = get_userdata( $co_agent_id );
            $co_profile_url = get_user_meta( $co_agent_id, 'ct_profile_url', true );
            $co_tagline     = get_user_meta( $co_agent_id, 'tagline', true );
            $co_mobile      = get_user_meta( $co_agent_id, 'mobile', true );
            $co_office      = get_user_meta( $co_agent_id, 'office', true );
            $co_fax         = get_user_meta( $co_agent_id, 'fax', true );
            $co_brokername  = get_user_meta( $co_agent_id, 'brokername', true );
            $co_brokernum   = get_user_meta( $co_agent_id, 'brokernum', true );
            $co_twitter     = get_user_meta( $co_agent_id, 'twitterhandle', true );
            $co_facebook    = get_user_meta( $co_agent_id, 'facebookurl', true );
            $co_linkedin    = get_user_meta( $co_agent_id, 'linkedinurl', true );
        ?>
            <!-- Co Agent -->
            <div class="co-list-agent col span_12 first marB20">
                <h5 class="border-bottom marB20"><?php esc_html_e( 'Co-listing Agent', 'contempo' ); ?></h5>
                <ul id="co-agent" class="marB0">
                    <li class="agent">
                        <figure class="col span_3 first">
                            <a href="<?php echo esc_url( get_author_posts_url( $co_agent_id ) ); ?>" title="<?php echo esc_attr( $co_agent_info->display_name ); ?>">
                                <?php if ( $co_profile_url ) : ?>
                                    <img class="author-img" src="<?php echo esc_url( $co_profile_url ); ?>" />
                                <?php else : ?>
                                    <img class="author-img" src="<?php echo esc_url( get_template_directory_uri() . '/images/user-default.png' ); ?>" />
                                <?php endif; ?>
                            </a>
                        </figure>
                        <div class="agent-info col span_9">
                            <h4 class="marT0 marB0"><?php echo esc_html( $co_agent_info->display_name ); ?></h4>
                            <div class="agent-bio col span_8 first">
                                <?php if ( $co_tagline ) : ?>
                                    <p class="tagline"><strong><?php echo esc_html( $co_tagline ); ?></strong></p>
                                <?php endif; ?>
                                <ul class="col span_8 marT15 first">
                                    <?php if ( $co_mobile ) : ?>
                                        <li class="row"><span class="muted left"><i class="fa fa-phone"></i></span> <span class="right"><?php echo esc_html( $co_mobile ); ?></span></li>
                                    <?php endif; ?>
                                    <?php if ( $co_office ) : ?>
                                        <li class="row"><span class="muted left"><i class="fa fa-building"></i></span> <span class="right"><?php echo esc_html( $co_office ); ?></span></li>
                                    <?php endif; ?>
                                    <?php if ( $co_fax ) : ?>
                                        <li class="row"><span class="muted left"><i class="fa fa-print"></i></span> <span class="right"><?php echo esc_html( $co_fax ); ?></span></li>
                                    <?php endif; ?>
                                    <?php if ( $co_agent_info->user_email ) : $co_email = $co_agent_info->user_email; ?>
                                        <li class="row"><span class="muted left"><i class="fa fa-envelope"></i></span> <span class="right"><a href="mailto:<?php echo antispambot( $co_email, 1 ); ?>"><?php esc_html_e( 'Email', 'contempo' ); ?></a></span></li>
                                    <?php endif; ?>
                                    <?php if ( $co_agent_info->user_url ) :
                                        $co_url = trim( $co_agent_info->user_url, '/' );
                                        if ( ! preg_match( '#^http(s)?://#', $co_url ) ) {
                                            $co_url = 'http://' . $co_url;
                                        }
                                        $co_url_parts  = parse_url( $co_url );
                                        $co_url_domain = preg_replace( '/^www\./', '', $co_url_parts['host'] );
                                    ?>
                                        <li class="row"><span class="left"><i class="fa fa-globe"></i></span> <span class="right"><a href="<?php echo esc_url( $co_agent_info->user_url ); ?>"><?php echo esc_html( $co_url_domain ); ?></a></span></li>
                                    <?php endif; ?>
                                    <?php if ( $co_brokername ) : ?><p class="marB3"><strong><?php echo esc_html( $co_brokername ); ?></strong></p><?php endif; ?>
                                    <?php if ( $co_brokernum ) : ?><p class="marB3"><?php echo esc_html( $co_brokernum ); ?></p><?php endif; ?>
                                </ul>
                            </div>
                            <ul class="social">
                                <?php if ( $co_twitter ) : ?><li class="twitter"><a href="https://twitter.com/#!/<?php echo esc_attr( $co_twitter ); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li><?php endif; ?>
                                <?php if ( $co_facebook ) : ?><li class="facebook"><a href="<?php echo esc_url( $co_facebook ); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li><?php endif; ?>
                                <?php if ( $co_linkedin ) : ?><li class="facebook"><a href="<?php echo esc_url( $co_linkedin ); ?>" target="_blank"><i class="fa fa-linkedin"></i></a></li><?php endif; ?>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="clear"></div>
            <!-- //Co Agent -->
        <?php endif; ?>

</div>
<!-- //Agent Contact -->
