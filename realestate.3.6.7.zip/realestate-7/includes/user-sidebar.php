<?php
/**
 * User Sidebar Template
 *
 * @package WP Pro Real Estate 7
 * @subpackage Includes
 */

global $ct_options;

$current_user = wp_get_current_user();

$ct_user_listings_count = ct_listing_post_count($current_user->ID, 'listings');
$ct_user_dashboard = isset( $ct_options['ct_user_dashboard'] ) ? esc_html( $ct_options['ct_user_dashboard'] ) : '';
$ct_saved_listings = isset( $ct_options['ct_saved_listings'] ) ? esc_html( $ct_options['ct_saved_listings'] ) : '';
$ct_listing_email_alerts_page_id = isset( $ct_options['ct_listing_email_alerts_page_id'] ) ? esc_attr( $ct_options['ct_listing_email_alerts_page_id'] ) : '';
$ct_submit_listing = isset( $ct_options['ct_submit'] ) ? esc_html( $ct_options['ct_submit'] ) : '';
$ct_view_user_listings = isset( $ct_options['ct_view'] ) ? esc_html( $ct_options['ct_view'] ) : '';
$ct_membership = isset( $ct_options['ct_membership'] ) ? esc_html( $ct_options['ct_membership'] ) : '';
$ct_invoices = isset( $ct_options['ct_invoices'] ) ? esc_html( $ct_options['ct_invoices'] ) : '';
$ct_listing_analytics = isset( $ct_options['ct_listing_analytics'] ) ? esc_html( $ct_options['ct_listing_analytics'] ) : '';
$ct_user_profile = isset( $ct_options['ct_profile'] ) ? esc_html( $ct_options['ct_profile'] ) : '';

?>

<?php do_action('before_user_sidebar'); ?>

<!-- Sidebar -->
<div id="user-sidebar" class="col span_2 first sidebar-sticky">
	<div id="sidebar-inner">
        
        <aside id="user-nav" class="left">
            <ul class="user-nav">
                <?php do_action('first_user_sidebar_menu'); ?>
                <?php if(is_super_admin() || in_array('administrator', (array) $current_user->roles) || in_array('editor', (array) $current_user->roles) || in_array('author', (array) $current_user->roles) || in_array('contributor', (array) $current_user->roles) || in_array('seller', (array) $current_user->roles) || in_array('agent', (array) $current_user->roles) || in_array('broker', (array) $current_user->roles)) { ?>
                    <?php
                    // When CT Leads Pro is active its page becomes the dashboard destination.
                    $_ct_lp_page = ct_get_leads_pro_page();
                    if ( $_ct_lp_page ) {
                        $_ct_dashboard_id  = $_ct_lp_page->ID;
                        $_ct_dashboard_url = get_permalink( $_ct_dashboard_id );
                    } elseif ( $ct_user_dashboard !== '' ) {
                        $_ct_dashboard_id  = $ct_user_dashboard;
                        $_ct_dashboard_url = get_permalink( $ct_user_dashboard );
                    } else {
                        $_ct_dashboard_id  = null;
                        $_ct_dashboard_url = null;
                    }
                    ?>
                    <?php if ( $_ct_dashboard_url ) { ?>
                        <li class="dashboard"><a <?php if ( is_page( $_ct_dashboard_id ) && ! isset( $_GET['view'] ) ) { echo 'class="current"'; } ?> href="<?php echo esc_url( $_ct_dashboard_url ); ?>"><?php ct_filters_svg_white(); ?><span> <?php esc_html_e('Dashboard', 'contempo'); ?></span></a></li>
                    <?php } ?>
                    <?php if ( $_ct_lp_page ) {
                        $_ct_leads_url = add_query_arg( 'view', 'inbox', get_permalink( $_ct_lp_page->ID ) );
                        $_ct_leads_active = is_page( $_ct_lp_page->ID ) && isset( $_GET['view'] ) && $_GET['view'] === 'inbox';
                    ?>
                        <li class="leads"><a <?php if ( $_ct_leads_active ) { echo 'class="current"'; } ?> href="<?php echo esc_url( $_ct_leads_url ); ?>"><?php ct_leads_svg_white(); ?><span> <?php esc_html_e('Leads', 'contempo'); ?></span></a></li>
                    <?php } ?>
                <?php } ?>
                <?php if(class_exists('Contempo\IDXPro\Admin\SettingsPage')) { ?>
                    <?php if(in_array('buyer', (array) $current_user->roles) || in_array('subscriber', (array) $current_user->roles)) { ?>
                        <li class="recently-viewed">
                            <a <?php if(rtrim(ct_get_server_info('REQUEST_URI') ?? '', '/') === '/my/recently-viewed') echo 'class="current"'; ?> href="<?php echo home_url('/my/recently-viewed'); ?>">
                                <?php ct_clock_svg_white(); ?>
                                <span><?php esc_html_e('Recently Viewed', 'contempo'); ?></span>
                                <?php echo do_shortcode('[ct-idx-pro-plus-user-recently-viewed-count]'); ?>
                            </a>
                        </li>
                        <li class="saved-listings">
                            <a <?php if(rtrim(ct_get_server_info('REQUEST_URI') ?? '', '/') === '/my/favorite-listings') echo 'class="current"'; ?> href="<?php echo home_url('/my/favorite-listings'); ?>">
                                <?php ct_heart_outline_svg_white(); ?>
                                <span><?php esc_html_e('Favorite Listings', 'contempo'); ?></span>
                                <?php echo do_shortcode('[ct-idx-pro-plus-user-favorites-number]'); ?>
                            </a>
                        </li>
                    <?php } ?>
                <?php } else { ?>
                    <?php if(in_array('buyer', (array) $current_user->roles) || in_array('subscriber', (array) $current_user->roles)) { ?>
                        <?php if($ct_saved_listings != '' && ct_re7_listing_feature_enabled( 'favorites' )) { ?>
                            <li class="saved-listings"><a <?php if(is_page($ct_saved_listings)) { echo 'class="current"'; } ?> href="<?php echo get_permalink($ct_saved_listings); ?>"><?php ct_heart_outline_svg_white(); ?><span> <?php esc_html_e('Favorite Listings', 'contempo'); ?></span></a></li>
                        <?php } ?>
                    <?php } ?>
                <?php } ?>
                <?php do_action('middle_user_sidebar_menu'); ?>
                <?php if(class_exists('Contempo\IDXPro\Admin\SettingsPage')) { ?>
                    <li class="listing-email-alerts">
                        <a <?php if(rtrim(ct_get_server_info('REQUEST_URI') ?? '', '/') === '/my/saved-searches') echo 'class="current"'; ?> href="<?php echo home_url('/my/saved-searches'); ?>">
                            <?php ct_alert_svg_white(); ?>
                            <?php if(is_super_admin() || in_array('administrator', (array) $current_user->roles) || in_array('editor', (array) $current_user->roles) || in_array('author', (array) $current_user->roles) || in_array('contributor', (array) $current_user->roles) || in_array('seller', (array) $current_user->roles) || in_array('agent', (array) $current_user->roles) || in_array('broker', (array) $current_user->roles)) { ?>
                                <span><?php _e('Lead Alerts', 'contempo'); ?></span>
                            <?php } else { ?>
                                <span><?php _e('Saved Searches', 'contempo'); ?></span>
                            <?php } ?>
                            <?php echo do_shortcode('[ct-idx-pro-plus-user-saved-search-count]'); ?>
                        </a>
                    </li>
                <?php } else { ?>
                    <?php if($ct_listing_email_alerts_page_id != '' && ct_re7_listing_feature_enabled( 'alerts' )) { ?>
                        <li class="listing-email-alerts">
                            <a <?php if(is_page($ct_listing_email_alerts_page_id)) { echo 'class="current"'; } ?> href="<?php echo get_permalink($ct_listing_email_alerts_page_id); ?>">
                                <?php ct_alert_svg_white(); ?>
                                <span>
                                    <?php if(is_super_admin() || in_array('administrator', (array) $current_user->roles) || in_array('editor', (array) $current_user->roles) || in_array('author', (array) $current_user->roles) || in_array('contributor', (array) $current_user->roles) || in_array('seller', (array) $current_user->roles) || in_array('agent', (array) $current_user->roles) || in_array('broker', (array) $current_user->roles)) { ?>
                                        <?php _e('Lead Alerts', 'contempo'); ?>
                                    <?php } else { ?>
                                        <?php _e('Saved Searches', 'contempo'); ?>
                                    <?php } ?>
                                </span>
                                <?php if(function_exists('ctea_get_saved_alerts_count_alert')) { ctea_get_saved_alerts_count(); } ?>
                            </a>
                        </li>
                    <?php } ?>
                <?php } ?>  
                <?php if(!class_exists('Contempo\IDXPro\Admin\SettingsPage')) { ?>
                    <?php if(is_super_admin() || in_array('administrator', (array) $current_user->roles) || in_array('editor', (array) $current_user->roles) || in_array('author', (array) $current_user->roles) || in_array('contributor', (array) $current_user->roles) || in_array('seller', (array) $current_user->roles) || in_array('agent', (array) $current_user->roles) || in_array('broker', (array) $current_user->roles)) { ?>
                        <?php if(!empty($ct_submit_listing) && $ct_options['ct_enable_front_end'] == 'yes') { ?>
                            <li class="submit-listing"><a <?php if(is_page($ct_submit_listing)) { echo 'class="current"'; } ?> href="<?php echo get_permalink($ct_submit_listing); ?>"><?php ct_plus_circle_svg_white(); ?><span> <?php esc_html_e('Submit Listing', 'contempo'); ?></span></a></li>
                        <?php } ?>
                        <?php if(!empty($ct_view_user_listings) && $ct_options['ct_enable_front_end'] == 'yes') { ?>
                            <li class="my-listings"><a <?php if(is_page($ct_view_user_listings)) { echo 'class="current"'; } ?> href="<?php echo get_permalink($ct_view_user_listings); ?>"><?php ct_listings_svg_white(); ?><span> <?php esc_html_e('My Listings', 'contempo'); ?> <span class="user-data-count"><?php echo esc_html($ct_user_listings_count); ?></span></span></a></li>
                        <?php } ?>
                        <?php if($ct_membership != '' && function_exists('ct_create_packages')) { ?>
                            <li class="membership"><a <?php if(is_page($ct_membership)) { echo 'class="current"'; } ?> href="<?php echo get_permalink($ct_membership); ?>"><?php ct_membership_svg_white(); ?><span> <?php esc_html_e('Membership', 'contempo'); ?></span></a></li>
                        <?php } ?>
                        <?php if($ct_invoices != '' && function_exists('ct_create_packages')) { ?>
                            <li class="invoices"><a <?php if(is_page($ct_invoices)) { echo 'class="current"'; } ?> href="<?php echo get_permalink($ct_invoices); ?>"><?php ct_invoice_svg_white(); ?><span> <?php esc_html_e('Invoices', 'contempo'); ?></span></a></li>
                        <?php } ?>
                        <?php if(shortcode_exists('ct_listing_analytics') && !empty($ct_listing_analytics)) { ?>
                            <li class="listing-analytics"><a <?php if(is_page($ct_listing_analytics)) { echo 'class="current"'; } ?> href="<?php echo get_permalink($ct_listing_analytics); ?>"><?php ct_chart_bars_svg(); ?><span> <?php esc_html_e('Analytics', 'contempo'); ?></span></a></li>
                        <?php } ?>
                    <?php } ?>
                <?php } ?>
                <?php 
                if (class_exists('Contempo\IDXPro\Admin\SettingsPage')) { ?>
                    <li class="my-profile">
                        <a <?php if(rtrim(ct_get_server_info('REQUEST_URI') ?? '', '/') === '/my/profile') echo 'class="current"'; ?> href="<?php echo home_url('/my/profile'); ?>">
                            <?php ct_account_svg_white(); ?>
                            <?php esc_html_e('My Profile', 'contempo'); ?>
                        </a>
                    </li>
                <?php } elseif(!empty($ct_user_profile)) { ?>
                    <li class="my-account">
                        <a <?php if(is_page($ct_user_profile)) { echo 'class="current"'; } ?> href="<?php echo get_permalink($ct_user_profile); ?>">
                            <?php ct_account_svg_white(); ?>
                            <?php esc_html_e('Account Settings', 'contempo'); ?>
                        </a>
                    </li>
                <?php } ?>
                <?php do_action('last_user_sidebar_menu'); ?>
                <li class="logout"><a href="<?php echo wp_logout_url( home_url() ); ?>"><?php ct_logout_svg_white(); ?><span> <?php esc_html_e('Logout', 'contempo'); ?></span></a></li>
            </ul>
        </aside>

		<?php if(is_active_sidebar('user-sidebar')) {
            dynamic_sidebar('User Sidebar');
        } ?>
            <div class="clear"></div>
	</div>
</div>
<!-- //Sidebar -->

<?php do_action('after_user_sidebar'); ?>