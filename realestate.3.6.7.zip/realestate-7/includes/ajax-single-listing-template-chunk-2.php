<?php
/**
 * Disable direct file access.
 */
if ( ! defined('ABSPATH') ) {
	return;
}

get_template_part( 'includes/single-listing-sub-navigation' );
get_template_part( 'includes/single-listing-content' );
get_template_part( 'includes/single-listing-contact' );
ct_listing_creation_date();
get_template_part( 'includes/single-listing-brokerage' );
echo '<div style="position:relative;" class="ajax-modal-sub-listing">';
get_template_part( 'includes/single-listing-sub-listings' );
echo '</div>';
get_template_part( 'includes/single-listing-affordability-calculator' );
	
echo '<div class="clear"></div>';

// IDX Disclaimers
if(class_exists('IDX')) {
    $oIDX = new IDX();
    $disclaimer = $oIDX->ct_idx_disclaimer_text();

    if($disclaimer != '') {
		echo '<div id="disclaimer" class="muted col span_12 first">';
			print wp_kses_post( $disclaimer, 'post' );
		echo '</div>';
    }
}

?>

<div class="clear"></div>

<?php do_action( 'after_single_listing_content' ); ?>