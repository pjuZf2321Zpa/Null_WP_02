<?php
/**
 * Single Listing Header
 *
 * @package WP Pro Real Estate 7
 * @subpackage Include
 */
 
global $ct_options;

$ct_listing_single_layout = isset( $ct_options['ct_listing_single_layout'] ) ? esc_html( $ct_options['ct_listing_single_layout'] ) : '';
$ct_single_listing_main_layout = isset( $ct_options['ct_single_listing_main_layout']['enabled'] ) ? $ct_options['ct_single_listing_main_layout']['enabled'] : '';
$ct_single_listing_header_layout = isset( $ct_options['ct_single_listing_header_layout']['enabled'] ) ? $ct_options['ct_single_listing_header_layout']['enabled'] : '';
$ct_listing_idx_mls_compliance_info_header = isset( $ct_options['ct_listing_idx_mls_compliance_info'] ) ? $ct_options['ct_listing_idx_mls_compliance_info'] : '';
$ct_listing_idx_mls_compliance_info_brokerage_phone = isset( $ct_options['ct_listing_idx_mls_compliance_info_brokerage_phone'] ) ? $ct_options['ct_listing_idx_mls_compliance_info_brokerage_phone'] : '';
$ct_co_listing_agent_enabled = isset( $ct_options['ct_co_listing_agent_enabled'] ) ? $ct_options['ct_co_listing_agent_enabled'] : 'no';

$ct_property_type = strip_tags( get_the_term_list( get_the_id(), 'property_type', '', ', ', '' ) );

$ct_source = get_post_meta(get_the_id(), 'source', true);
$ct_idx_rupid = get_post_meta(get_the_id(), '_ct_idx_rupid', true);

$ct_cpt_brokerage = get_post_meta(get_the_id(), '_ct_brokerage', true);
$ct_cpt_brokerage_phone = get_post_meta(get_the_id(), '_ct_branding_agent_office_phone', true);

if($ct_cpt_brokerage != 0) {

    $brokerage = new WP_Query(array(
        'post_type' => 'brokerage',
        'p' => $ct_cpt_brokerage,
        'nopaging' => true
    ));

    if ( $brokerage->have_posts() ) : while ( $brokerage->have_posts() ) : $brokerage->the_post();
        
        $ct_brokerage_name = strtolower(get_the_title());

    endwhile; endif; wp_reset_postdata();

}

do_action('before_single_listing_location');

echo '<!-- Location -->';
if(in_array('Save Button', $ct_single_listing_header_layout)) {
    echo '<header class="listing-location has-save-button">';
} else {
    echo '<header class="listing-location">';
}

    do_action('before_single_listing_location_inner');

    if ($ct_single_listing_header_layout) {

        foreach ($ct_single_listing_header_layout as $key => $value) {
        
            switch($key) {

            // Status
            case 'listing_status' :   

                echo '<div class="snipe-wrap">';
                    if( $ct_co_listing_agent_enabled === 'yes' && get_post_meta( get_the_id(), '_ct_co_listing_agent', true ) ) {
                        echo '<h6 class="snipe co-listing"><span>' . __('Co-listing', 'contempo') . '</span></h6>';
                    }
                    ct_status_featured();
                    ct_status();
                    echo '<div class="clear"></div>';
                echo '</div>';
        
            break;

            // Title
            case 'listing_title' :

               echo '<h1 id="listing-title" class="marT24 marB0">';
                    ct_listing_title();
                echo '</h1>';
                
            break;

            // City, State, Zip/Postcode
            case 'listing_city_state_zip' :

                echo '<p class="location marB0">';
                    city();
                    echo ', ';
                    state();
                    echo ' ';
                    zipcode();
                    //echo ' ';
                    country();
                echo '</p>';
                
            break;

            // Map Button
            case 'listing_map_btn' :

                echo '<div id="listing-map-btn">';
                    echo '<a href="#listing-location">';
                        echo '<i class="fas fa-map-marker-alt"></i>';
                        echo '<span id="map-btn-label">' . __('Map', 'contempo') . '</span>';
                    echo '</a>';
                echo '</div>';

            break;

            // Save Button
            case 'listing_save_btn' :

                ct_fav_listing_btn();
                
            break;

            }

        }
        
    } else {

        echo '<div class="snipe-wrap">';
            if( $ct_co_listing_agent_enabled === 'yes' && get_post_meta( get_the_id(), '_ct_co_listing_agent', true ) ) {
                echo '<h6 class="snipe co-listing"><span>' . __('Co-listing', 'contempo') . '</span></h6>';
            }
            ct_status();
            echo '<div class="clear"></div>';
        echo '</div>';
        echo '<h2 class="marT5 marB0">';
            ct_listing_title();
        echo '</h2>';
        echo '<p class="location marB0">';
            city() . ', ' . state() . ' ' . zipcode() . ' ' . country();
        echo '</p>';

    }

    if($ct_listing_single_layout == 'listings-three' || $ct_listing_single_layout == 'listings-four' || $ct_listing_single_layout == 'listings-five') {

        if(has_term(array('for-rent', 'rental', 'lease'), 'ct_status', get_the_ID())) {
            $ct_price_type_class = 'ct-price-rental';
        } else {
            $ct_price_type_class = 'ct-price-purchase';
        }
        
        if(!in_array('Est Payment', (array) $ct_single_listing_main_layout)) {
            echo '<div id="listing-price-type" class="no-estimated-payment ' . $ct_price_type_class . '">';
        } else {
            echo '<div id="listing-price-type" class="' . $ct_price_type_class . '">';
        }

            get_template_part('includes/single-listing-price');

            if(!has_term(array('for-rent', 'rental', 'lease'), 'ct_status', get_the_ID())) {
                get_template_part('includes/single-listing-estimated-payment');
            }
            
            if(has_term(array('for-rent', 'rental', 'lease'), 'ct_status', get_the_ID())) {
                if(!empty($ct_property_type)) {
                    echo '<p id="property-type" class="muted">';
                        echo esc_html($ct_property_type);
                    echo '</p>';
                }
            }
        echo '</div>';
    }

    if( $ct_source == 'idx-api' ) {
        if($ct_listing_idx_mls_compliance_info_header == 'yes') {
            if(!empty($ct_brokerage_name)) {
                echo '<p id="idx-compliance-broker-info" class="muted marB0"><small>';
                    if(has_term(array('sold'), 'ct_status', get_the_ID())) {
                        echo 'Selling Office: ';
                    } else {
                        echo 'Offered By: ';
                    }
                    echo ucwords($ct_brokerage_name);
                    if(!empty($ct_cpt_brokerage_phone) && $ct_listing_idx_mls_compliance_info_brokerage_phone == 'yes') {
                        echo ', ' . esc_html($ct_cpt_brokerage_phone);
                    }
                echo '</small></p>';
            }
        }
    }
        
echo '</header>';
echo '<!--//Location -->';