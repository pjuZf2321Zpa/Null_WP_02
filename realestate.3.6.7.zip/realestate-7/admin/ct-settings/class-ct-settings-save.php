<?php
/**
 * CT Settings — AJAX Save Handler
 *
 * Receives the full serialized form, sanitizes each field via its field class,
 * validates required fields (email), writes to wp_options, returns a fresh nonce.
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-ct-settings-sanitize.php';

class CT_Settings_Save {

    public static function register_ajax(): void {
        add_action( 'wp_ajax_ct_settings_save',         [ __CLASS__, 'handle' ] );
        add_action( 'wp_ajax_ct_settings_reset_section',[ __CLASS__, 'handle_reset_section' ] );
        add_action( 'wp_ajax_ct_settings_import',       [ __CLASS__, 'handle_import' ] );
        add_action( 'wp_ajax_ct_settings_export',       [ __CLASS__, 'handle_export' ] );
        add_action( 'wp_ajax_re7_save_onboarding_step', [ __CLASS__, 'handle_onboarding_step' ] );
        add_action( 'wp_ajax_re7_complete_onboarding',  [ __CLASS__, 'handle_onboarding_complete' ] );
    }

    // -------------------------------------------------------------------------
    // Onboarding
    // -------------------------------------------------------------------------

    public static function handle_onboarding_step(): void {
        check_ajax_referer( 're7_onboarding', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'contempo' ) ], 403 );
        }

        $step_id = sanitize_key( $_POST['step_id'] ?? '' );
        $checked = ! empty( $_POST['checked'] ) && $_POST['checked'] !== 'false';

        if ( empty( $step_id ) ) {
            wp_send_json_error( [ 'message' => __( 'Invalid step.', 'contempo' ) ] );
        }

        $steps             = get_option( 're7_onboarding_steps', [] );
        $steps[ $step_id ] = $checked;
        update_option( 're7_onboarding_steps', $steps );

        wp_send_json_success( [ 'step_id' => $step_id, 'checked' => $checked ] );
    }

    public static function handle_onboarding_complete(): void {
        check_ajax_referer( 're7_onboarding', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'contempo' ) ], 403 );
        }

        update_option( 're7_onboarding_complete', true );

        wp_send_json_success( [ 'redirect' => admin_url( 'admin.php?page=ct_options' ) ] );
    }

    // -------------------------------------------------------------------------
    // Save
    // -------------------------------------------------------------------------

    public static function handle(): void {
        check_ajax_referer( 'ct_settings_save', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'contempo' ) ], 403 );
        }

        $opt_name     = sanitize_key( $_POST['opt_name'] ?? 'ct_options' );
        $raw_post     = $_POST['data'] ?? null;
        $post_is_json = false;

        // DEBUG: capture raw POST state before any processing
        $debug = [
            'post_data_type'   => gettype( $raw_post ),
            'post_data_length' => is_string( $raw_post ) ? strlen( $raw_post ) : ( is_array( $raw_post ) ? count( $raw_post ) : 0 ),
            'post_keys'        => array_keys( $_POST ),
            'opt_name'         => $opt_name,
        ];

        $raw_data = $raw_post ?? [];

        if ( ! is_array( $raw_data ) ) {
            $post_is_json = true;
            $decoded      = json_decode( wp_unslash( (string) $raw_data ), true );
            $debug['json_decode_error'] = json_last_error_msg();
            $debug['json_decoded_keys'] = is_array( $decoded ) ? count( $decoded ) : 0;
            $raw_data = $decoded ?? [];
        }

        $debug['raw_data_key_count'] = count( $raw_data );
        $debug['post_is_json']       = $post_is_json;

        $field_defs = CT_Settings::get_all_fields( $opt_name );
        $existing   = get_option( $opt_name, [] );

        $debug['field_defs_count'] = count( $field_defs );
        $debug['existing_key_count'] = count( $existing );

        $sanitized  = [];
        $errors     = [];

        // Sanitize each submitted field via its field class
        foreach ( $raw_data as $key => $value ) {
            $key = sanitize_key( $key );
            $field = $field_defs[ $key ] ?? null;

            if ( ! $field ) {
                $sanitized[ $key ] = self::sanitize_unknown_value( $value );
                continue;
            }

            $type = $field['type'] ?? 'text';

            if ( ! empty( $field['validate'] ) ) {
                $validation_error = self::validate_field( $field, $value );
                if ( $validation_error ) {
                    $errors[ $key ] = $validation_error;
                    if ( array_key_exists( $key, $existing ) ) {
                        $sanitized[ $key ] = $existing[ $key ];
                    }
                    continue;
                }
            }

            $sanitized[ $key ] = self::sanitize_field( $type, $field, $value );
        }

        $debug['sanitized_key_count'] = count( $sanitized );

        // Merge with existing to preserve any keys not in current submission
        $merged = array_merge( $existing, $sanitized );

        $debug['merged_key_count'] = count( $merged );

        $update_result             = update_option( $opt_name, $merged );
        $debug['update_result']    = $update_result; // true = updated, false = no change or error
        $debug['merged_sample']    = array_slice( $merged, 0, 5, true ); // first 5 keys for inspection

        // Refresh the global
        CT_Settings::hydrate_global( $opt_name );

        wp_send_json_success( [
            'message'  => __( 'Settings saved.', 'contempo' ),
            'nonce'    => wp_create_nonce( 'ct_settings_save' ),
            'errors'   => $errors,
            'opt_name' => $opt_name,
            'debug'    => $debug,  // DEBUG — remove before release
        ] );
    }

    // -------------------------------------------------------------------------
    // Reset Section
    // -------------------------------------------------------------------------

    public static function handle_reset_section(): void {
        check_ajax_referer( 'ct_settings_save', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'contempo' ) ], 403 );
        }

        $opt_name   = sanitize_key( $_POST['opt_name'] ?? 'ct_options' );
        $section_id = sanitize_key( $_POST['section_id'] ?? '' );

        $sections = CT_Settings::get_sections( $opt_name );
        $existing = get_option( $opt_name, [] );
        $defaults = [];

        foreach ( $sections as $section ) {
            if ( ( $section['id'] ?? '' ) !== $section_id ) continue;

            $fields = $section['fields'] ?? [];
            foreach ( $fields as $field ) {
                $fields = array_merge( $fields, $field['fields'] ?? [] );
            }
            foreach ( $fields as $field ) {
                $id = $field['id'] ?? '';
                if ( ( $field['type'] ?? '' ) === 'compare_fields' && class_exists( 'CT_RE7_Listing_Modules' ) ) {
                    $field['default'] = CT_RE7_Listing_Modules::default_comparison_data();
                }
                if ( $id && array_key_exists( 'default', $field ) ) {
                    $existing[ $id ] = $field['default'];
                    $defaults[ $id ] = $field['default'];
                }
            }
            break;
        }

        update_option( $opt_name, $existing );
        CT_Settings::hydrate_global( $opt_name );

        wp_send_json_success( [
            'message'  => __( 'Section reset to defaults.', 'contempo' ),
            'nonce'    => wp_create_nonce( 'ct_settings_save' ),
            'defaults' => $defaults,
        ] );
    }

    // -------------------------------------------------------------------------
    // Import / Export
    // -------------------------------------------------------------------------

    public static function handle_export(): void {
        check_ajax_referer( 'ct_settings_save', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [], 403 );
        }

        $opt_name = sanitize_key( $_POST['opt_name'] ?? 'ct_options' );
        $data     = get_option( $opt_name, [] );

        wp_send_json_success( [
            'data' => wp_json_encode( $data ),
        ] );
    }

    public static function handle_import(): void {
        check_ajax_referer( 'ct_settings_save', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [], 403 );
        }

        $opt_name = sanitize_key( $_POST['opt_name'] ?? 'ct_options' );
        $json     = stripslashes( $_POST['import_data'] ?? '' );
        $imported = json_decode( $json, true );

        if ( ! is_array( $imported ) ) {
            wp_send_json_error( [ 'message' => __( 'Invalid import data.', 'contempo' ) ] );
        }

        $imported = self::normalize_strings_deep( $imported );

        $existing = get_option( $opt_name, [] );
        $merged   = array_merge( $existing, $imported );
        update_option( $opt_name, $merged );
        CT_Settings::hydrate_global( $opt_name );

        wp_send_json_success( [
            'message' => __( 'Settings imported successfully.', 'contempo' ),
            'nonce'   => wp_create_nonce( 'ct_settings_save' ),
        ] );
    }

    // -------------------------------------------------------------------------
    // Sanitization — delegates to CT_Settings_Sanitize (shared with Customizer)
    // -------------------------------------------------------------------------

    /**
     * Sanitize POST values for keys not in the registered field map (legacy / plugin extras).
     */
    private static function sanitize_unknown_value( mixed $value ): mixed {
        return CT_Settings_Sanitize::unknown( $value );
    }

    /**
     * Strip legacy slash buildup from every string in an options array (import / nested POST).
     */
    private static function normalize_strings_deep( mixed $data ): mixed {
        if ( is_array( $data ) ) {
            foreach ( $data as $k => $v ) {
                $data[ $k ] = self::normalize_strings_deep( $v );
            }
            return $data;
        }
        if ( is_string( $data ) ) {
            return CT_Settings::normalize_code( $data );
        }
        return $data;
    }

    private static function sanitize_field( string $type, array $field, mixed $value ): mixed {
        return CT_Settings_Sanitize::field( $type, $field, $value );
    }

    // -------------------------------------------------------------------------
    // Validation
    // -------------------------------------------------------------------------

    private static function validate_field( array $field, mixed $value ): ?string {
        return CT_Settings_Sanitize::validate( $field, $value );
    }
}
