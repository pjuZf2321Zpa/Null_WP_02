<?php
/**
 * CT Settings — Custom Customizer Control Classes
 *
 * All custom WP_Customize_Control subclasses needed by CT_Customizer.
 * Compound values (color_rgba, typography, media, background) are encoded
 * as JSON objects so wp.customize can transport them via postMessage.
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ---------------------------------------------------------------------------
// Color RGBA
// ---------------------------------------------------------------------------

class CT_Customize_Color_Rgba_Control extends WP_Customize_Control {

    public $type = 'ct-color-rgba';

    /**
     * Expose the value as a JSON object for the JS api.
     * WP serializes setting values via json_encode; arrays become objects in JS.
     */
    public function to_json(): void {
        parent::to_json();
        $raw = $this->value();
        // Ensure it's always an array so JS gets an object, not a scalar
        if ( ! is_array( $raw ) ) {
            $raw = [ 'color' => '', 'alpha' => 1, 'rgba' => '' ];
        }
        $this->json['ct_value'] = $raw;
    }

    public function enqueue(): void {
        // Color picker assets are enqueued by CT_Customizer globally
    }

    public function render_content(): void {
        $raw   = $this->value();
        if ( ! is_array( $raw ) ) {
            $raw = [ 'color' => '', 'alpha' => 1, 'rgba' => '' ];
        }
        $color = sanitize_hex_color( $raw['color'] ?? '' ) ?? '';
        $alpha = (float) ( $raw['alpha'] ?? 1 );
        $rgba  = esc_attr( $raw['rgba'] ?? '' );

        $default_raw   = $this->setting->default ?? [];
        $default_color = is_array( $default_raw ) ? ( $default_raw['color'] ?? '' ) : '';
        ?>
        <label>
            <?php if ( ! empty( $this->label ) ) : ?>
                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <?php endif; ?>
            <?php if ( ! empty( $this->description ) ) : ?>
                <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
            <?php endif; ?>
        </label>
        <div class="ct-rgba-wrap" data-setting="<?php echo esc_attr( str_replace( 'ct_ctrl_', '', $this->id ) ); ?>">
            <input type="hidden" class="ct-rgba-color" value="<?php echo esc_attr( $color ); ?>" />
            <input type="hidden" class="ct-rgba-alpha" value="<?php echo esc_attr( $alpha ); ?>" />
            <input type="hidden" class="ct-rgba-rgba"  value="<?php echo esc_attr( $rgba ); ?>" />

            <div class="ct-rgba-picker-wrap">
                <div class="ct-rgba-swatch<?php echo $color ? '' : ' ct-rgba-swatch--empty'; ?>"
                     style="<?php echo $color ? 'background:' . esc_attr( $rgba ?: $color ) . ';' : ''; ?>">
                    <span class="ct-rgba-hex-display"><?php echo esc_html( $color ); ?></span>
                </div>
                <div class="ct-rgba-picker-popout" style="display:none;">
                    <input type="text"
                           class="ct-color-picker ct-rgba-hex-input"
                           value="<?php echo esc_attr( $color ); ?>"
                           data-default-color="<?php echo esc_attr( $default_color ); ?>"
                           placeholder="#rrggbb"
                           autocomplete="off"
                           spellcheck="false"
                           maxlength="7" />
                    <div class="ct-rgba-alpha-wrap">
                        <label><?php esc_html_e( 'Opacity', 'contempo' ); ?></label>
                        <input type="range"   class="ct-rgba-alpha-slider" min="0" max="1" step="0.01" value="<?php echo esc_attr( $alpha ); ?>" />
                        <input type="number"  class="ct-rgba-alpha-number" min="0" max="1" step="0.01" value="<?php echo esc_attr( $alpha ); ?>" />
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}

// ---------------------------------------------------------------------------
// Typography
// ---------------------------------------------------------------------------

class CT_Customize_Typography_Control extends WP_Customize_Control {

    public $type = 'ct-typography';

    private static array $font_list = [
        'Arial', 'Helvetica', 'Georgia', 'Times New Roman', 'Courier New', 'Verdana', 'Trebuchet MS',
        'Abel', 'Abril Fatface', 'Alegreya', 'Aleo', 'Arimo', 'Arvo', 'Asap', 'Bitter', 'Cabin',
        'Cinzel', 'Crete Round', 'Crimson Text', 'Dancing Script', 'Domine', 'Dosis', 'EB Garamond',
        'Exo', 'Exo 2', 'Fira Sans', 'Frank Ruhl Libre', 'Gelasio', 'Gentium Book Basic', 'Gudea',
        'Headland One', 'Hind', 'Hind Siliguri', 'IBM Plex Sans', 'IBM Plex Serif', 'Inconsolata',
        'Inter', 'Josefin Sans', 'Josefin Slab', 'Jost', 'Karla', 'Lato', 'Libre Baskerville',
        'Libre Franklin', 'Lobster', 'Lora', 'Merriweather', 'Merriweather Sans', 'Montserrat',
        'Mukta', 'Noto Sans', 'Noto Serif', 'Nunito', 'Nunito Sans', 'Open Sans', 'Oswald',
        'Oxygen', 'PT Sans', 'PT Serif', 'Pacifico', 'Playfair Display', 'Poppins', 'Quicksand',
        'Raleway', 'Roboto', 'Roboto Condensed', 'Roboto Mono', 'Roboto Slab', 'Rubik',
        'Source Code Pro', 'Source Sans 3', 'Source Serif 4', 'Titillium Web', 'Ubuntu',
        'Urbanist', 'Varela Round', 'Work Sans', 'Yantramanav', 'Zilla Slab',
    ];

    public function to_json(): void {
        parent::to_json();
        $raw = $this->value();
        if ( ! is_array( $raw ) ) $raw = [];
        $this->json['ct_value']     = $raw;
        $this->json['ct_font_list'] = self::$font_list;
    }

    public function render_content(): void {
        $val = $this->value();
        if ( ! is_array( $val ) ) $val = [];

        $family      = esc_attr( $val['font-family']   ?? '' );
        $size        = esc_attr( $val['font-size']      ?? '' );
        $weight      = esc_attr( $val['font-weight']    ?? '' );
        $style       = esc_attr( $val['font-style']     ?? '' );
        $line_height = esc_attr( $val['line-height']    ?? '' );
        $letter_sp   = esc_attr( $val['letter-spacing'] ?? '' );
        $text_align  = esc_attr( $val['text-align']     ?? '' );
        $text_trans  = esc_attr( $val['text-transform'] ?? '' );
        $color       = esc_attr( $val['color']          ?? '' );
        $is_google   = ! empty( $val['google'] );
        $subsets     = esc_attr( $val['subsets']        ?? 'latin' );
        $font_backup = esc_attr( $val['font-backup']    ?? '' );

        $datalist_id = 'ct_typo_dl_' . esc_attr( $this->id );

        $preview_style = '';
        if ( $family )      $preview_style .= "font-family:'{$family}';";
        if ( $size )        $preview_style .= "font-size:{$size};";
        if ( $weight )      $preview_style .= "font-weight:{$weight};";
        if ( $color )       $preview_style .= "color:{$color};";
        if ( $line_height ) $preview_style .= "line-height:{$line_height};";

        $weights = [
            '' => '— Default —', '100' => '100 Thin', '200' => '200 Extra Light',
            '300' => '300 Light', '400' => '400 Normal', '500' => '500 Medium',
            '600' => '600 Semi Bold', '700' => '700 Bold', '800' => '800 Extra Bold',
            '900' => '900 Black',
        ];
        ?>
        <label>
            <?php if ( ! empty( $this->label ) ) : ?>
                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <?php endif; ?>
            <?php if ( ! empty( $this->description ) ) : ?>
                <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
            <?php endif; ?>
        </label>
        <div class="ct-typography-wrap" data-setting="<?php echo esc_attr( str_replace( 'ct_ctrl_', '', $this->id ) ); ?>">
            <div class="ct-typography-preview" style="<?php echo esc_attr( $preview_style ); ?>">
                <?php esc_html_e( 'The quick brown fox jumps over the lazy dog', 'contempo' ); ?>
            </div>
            <div class="ct-typography-controls">

                <div class="ct-typography-row">
                    <label><?php esc_html_e( 'Font Family', 'contempo' ); ?></label>
                    <input type="text"
                           class="ct-typo-family regular-text"
                           value="<?php echo $family; ?>"
                           list="<?php echo $datalist_id; ?>"
                           autocomplete="off" />
                    <datalist id="<?php echo $datalist_id; ?>">
                        <?php foreach ( self::$font_list as $f ) : ?>
                            <option value="<?php echo esc_attr( $f ); ?>">
                        <?php endforeach; ?>
                    </datalist>
                    <label class="ct-typo-google-label">
                        <input type="checkbox" class="ct-typo-google" value="1" <?php checked( $is_google ); ?> />
                        <?php esc_html_e( 'Google Font', 'contempo' ); ?>
                    </label>
                </div>

                <div class="ct-typography-row">
                    <label><?php esc_html_e( 'Size', 'contempo' ); ?></label>
                    <input type="text" class="small-text ct-typo-size" value="<?php echo $size; ?>" placeholder="e.g. 16px" />
                </div>

                <div class="ct-typography-row">
                    <label><?php esc_html_e( 'Weight', 'contempo' ); ?></label>
                    <select class="ct-typo-weight">
                        <?php foreach ( $weights as $wv => $wl ) : ?>
                            <option value="<?php echo esc_attr( $wv ); ?>" <?php selected( $weight, $wv ); ?>><?php echo esc_html( $wl ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="ct-typography-row">
                    <label><?php esc_html_e( 'Style', 'contempo' ); ?></label>
                    <select class="ct-typo-style">
                        <?php foreach ( [ '' => '— Default —', 'normal' => 'Normal', 'italic' => 'Italic', 'oblique' => 'Oblique' ] as $sv => $sl ) : ?>
                            <option value="<?php echo esc_attr( $sv ); ?>" <?php selected( $style, $sv ); ?>><?php echo esc_html( $sl ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="ct-typography-row">
                    <label><?php esc_html_e( 'Line Height', 'contempo' ); ?></label>
                    <input type="text" class="small-text ct-typo-line-height" value="<?php echo $line_height; ?>" placeholder="e.g. 1.6" />
                </div>

                <div class="ct-typography-row">
                    <label><?php esc_html_e( 'Letter Spacing', 'contempo' ); ?></label>
                    <input type="text" class="small-text ct-typo-letter-spacing" value="<?php echo $letter_sp; ?>" placeholder="e.g. 0.05em" />
                </div>

                <div class="ct-typography-row">
                    <label><?php esc_html_e( 'Text Align', 'contempo' ); ?></label>
                    <select class="ct-typo-text-align">
                        <?php foreach ( [ '' => '— Default —', 'left' => 'Left', 'center' => 'Center', 'right' => 'Right', 'justify' => 'Justify' ] as $tv => $tl ) : ?>
                            <option value="<?php echo esc_attr( $tv ); ?>" <?php selected( $text_align, $tv ); ?>><?php echo esc_html( $tl ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="ct-typography-row">
                    <label><?php esc_html_e( 'Text Transform', 'contempo' ); ?></label>
                    <select class="ct-typo-text-transform">
                        <?php foreach ( [ '' => '— Default —', 'none' => 'None', 'uppercase' => 'Uppercase', 'lowercase' => 'Lowercase', 'capitalize' => 'Capitalize' ] as $ttv => $ttl ) : ?>
                            <option value="<?php echo esc_attr( $ttv ); ?>" <?php selected( $text_trans, $ttv ); ?>><?php echo esc_html( $ttl ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="ct-typography-row">
                    <label><?php esc_html_e( 'Color', 'contempo' ); ?></label>
                    <input type="text" class="ct-color-picker ct-typo-color" value="<?php echo $color; ?>" />
                </div>

                <input type="hidden" class="ct-typo-subsets"     value="<?php echo $subsets; ?>" />
                <input type="hidden" class="ct-typo-font-backup"  value="<?php echo $font_backup; ?>" />
            </div>
        </div>
        <?php
    }
}

// ---------------------------------------------------------------------------
// Slider
// ---------------------------------------------------------------------------

class CT_Customize_Slider_Control extends WP_Customize_Control {

    public $type  = 'ct-slider';
    public $min   = 0;
    public $max   = 100;
    public $step  = 1;
    public $unit  = '';

    public function to_json(): void {
        parent::to_json();
        $this->json['ct_min']  = $this->min;
        $this->json['ct_max']  = $this->max;
        $this->json['ct_step'] = $this->step;
        $this->json['ct_unit'] = $this->unit;
    }

    public function render_content(): void {
        $val = (int) $this->value();
        ?>
        <label>
            <?php if ( ! empty( $this->label ) ) : ?>
                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <?php endif; ?>
            <?php if ( ! empty( $this->description ) ) : ?>
                <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
            <?php endif; ?>
        </label>
        <div class="ct-slider-wrap" data-setting="<?php echo esc_attr( str_replace( 'ct_ctrl_', '', $this->id ) ); ?>">
            <input type="range"
                   class="ct-slider-range"
                   min="<?php echo esc_attr( $this->min ); ?>"
                   max="<?php echo esc_attr( $this->max ); ?>"
                   step="<?php echo esc_attr( $this->step ); ?>"
                   value="<?php echo esc_attr( $val ); ?>" />
            <input type="number"
                   class="ct-slider-number small-text"
                   min="<?php echo esc_attr( $this->min ); ?>"
                   max="<?php echo esc_attr( $this->max ); ?>"
                   step="<?php echo esc_attr( $this->step ); ?>"
                   value="<?php echo esc_attr( $val ); ?>" />
            <?php if ( $this->unit ) : ?>
                <span class="ct-slider-unit"><?php echo esc_html( $this->unit ); ?></span>
            <?php endif; ?>
        </div>
        <?php
    }
}

// ---------------------------------------------------------------------------
// Switch (Toggle)
// ---------------------------------------------------------------------------

class CT_Customize_Switch_Control extends WP_Customize_Control {

    public $type = 'ct-switch';

    public function render_content(): void {
        $checked = ( $this->value() === 'yes' );
        ?>
        <div class="ct-switch-wrap" data-setting="<?php echo esc_attr( str_replace( 'ct_ctrl_', '', $this->id ) ); ?>">
            <?php if ( ! empty( $this->label ) ) : ?>
                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <?php endif; ?>
            <label class="ct-toggle-label">
                <input type="checkbox"
                       class="ct-toggle-checkbox"
                       value="yes"
                       <?php checked( $checked ); ?> />
                <span class="ct-toggle-slider"></span>
                <span class="ct-toggle-status"><?php echo $checked ? esc_html__( 'On', 'contempo' ) : esc_html__( 'Off', 'contempo' ); ?></span>
            </label>
            <?php if ( ! empty( $this->description ) ) : ?>
                <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
            <?php endif; ?>
        </div>
        <?php
    }
}

// ---------------------------------------------------------------------------
// Image Select (visual radio buttons with image previews)
// ---------------------------------------------------------------------------

class CT_Customize_Image_Select_Control extends WP_Customize_Control {

    public $type    = 'ct-image-select';
    public $choices = []; // [ 'value' => ['label' => '', 'img' => ''] ]

    public function to_json(): void {
        parent::to_json();
        $this->json['ct_choices'] = $this->choices;
    }

    public function render_content(): void {
        $current = $this->value();
        ?>
        <label>
            <?php if ( ! empty( $this->label ) ) : ?>
                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <?php endif; ?>
            <?php if ( ! empty( $this->description ) ) : ?>
                <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
            <?php endif; ?>
        </label>
        <div class="ct-image-select-wrap" data-setting="<?php echo esc_attr( str_replace( 'ct_ctrl_', '', $this->id ) ); ?>">
            <?php foreach ( $this->choices as $val => $choice ) : ?>
                <label class="ct-image-select-option <?php echo $current === (string) $val ? 'selected' : ''; ?>">
                    <input type="radio"
                           class="ct-image-select-radio"
                           name="ct_img_sel_<?php echo esc_attr( $this->id ); ?>"
                           value="<?php echo esc_attr( $val ); ?>"
                           <?php checked( $current, (string) $val ); ?> />
                    <?php if ( ! empty( $choice['img'] ) ) : ?>
                        <img src="<?php echo esc_url( $choice['img'] ); ?>"
                             alt="<?php echo esc_attr( $choice['label'] ?? $val ); ?>" />
                    <?php endif; ?>
                    <?php if ( ! empty( $choice['label'] ) ) : ?>
                        <span><?php echo esc_html( $choice['label'] ); ?></span>
                    <?php endif; ?>
                </label>
            <?php endforeach; ?>
        </div>
        <?php
    }
}

// ---------------------------------------------------------------------------
// Media (stores full array: url, id, width, height, thumbnail)
// ---------------------------------------------------------------------------

class CT_Customize_Media_Control extends WP_Customize_Control {

    public $type    = 'ct-media';
    public $allowed = 'image'; // 'image' | 'all'

    public function to_json(): void {
        parent::to_json();
        $raw = $this->value();
        if ( ! is_array( $raw ) ) {
            $raw = [ 'url' => '', 'id' => 0, 'width' => '', 'height' => '', 'thumbnail' => '' ];
        }
        $this->json['ct_value']   = $raw;
        $this->json['ct_allowed'] = $this->allowed;
    }

    public function enqueue(): void {
        wp_enqueue_media();
    }

    public function render_content(): void {
        $val   = $this->value();
        if ( ! is_array( $val ) ) {
            $val = [ 'url' => '', 'id' => 0, 'width' => '', 'height' => '', 'thumbnail' => '' ];
        }
        $url   = esc_url( $val['url'] ?? '' );
        $thumb = esc_url( $val['thumbnail'] ?? $url );
        ?>
        <label>
            <?php if ( ! empty( $this->label ) ) : ?>
                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <?php endif; ?>
            <?php if ( ! empty( $this->description ) ) : ?>
                <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
            <?php endif; ?>
        </label>
        <div class="ct-media-wrap" data-setting="<?php echo esc_attr( str_replace( 'ct_ctrl_', '', $this->id ) ); ?>" data-allowed="<?php echo esc_attr( $this->allowed ); ?>">
            <input type="hidden" class="ct-media-url"    value="<?php echo $url; ?>" />
            <input type="hidden" class="ct-media-id"     value="<?php echo esc_attr( (int)( $val['id'] ?? 0 ) ); ?>" />
            <input type="hidden" class="ct-media-width"  value="<?php echo esc_attr( $val['width'] ?? '' ); ?>" />
            <input type="hidden" class="ct-media-height" value="<?php echo esc_attr( $val['height'] ?? '' ); ?>" />
            <input type="hidden" class="ct-media-thumb"  value="<?php echo esc_url( $val['thumbnail'] ?? '' ); ?>" />

            <div class="ct-media-preview">
                <?php if ( $url ) : ?>
                    <img src="<?php echo $thumb ?: $url; ?>" class="ct-media-preview-img" alt="" />
                <?php endif; ?>
            </div>

            <div class="ct-media-actions">
                <button type="button" class="button ct-media-upload-btn">
                    <?php esc_html_e( 'Upload / Select', 'contempo' ); ?>
                </button>
                <button type="button" class="button ct-media-remove-btn" <?php echo $url ? '' : 'style="display:none;"'; ?>>
                    <?php esc_html_e( 'Remove', 'contempo' ); ?>
                </button>
            </div>

            <?php if ( $url ) : ?>
                <span class="ct-media-url-display"><?php echo esc_html( $url ); ?></span>
            <?php endif; ?>
        </div>
        <?php
    }
}

// ---------------------------------------------------------------------------
// Background (compound: color, image, repeat, size, position, attachment)
// ---------------------------------------------------------------------------

class CT_Customize_Background_Control extends WP_Customize_Control {

    public $type = 'ct-background';

    public function to_json(): void {
        parent::to_json();
        $raw = $this->value();
        if ( ! is_array( $raw ) ) $raw = [];
        $this->json['ct_value'] = $raw;
    }

    public function enqueue(): void {
        wp_enqueue_media();
    }

    public function render_content(): void {
        $val        = $this->value();
        if ( ! is_array( $val ) ) $val = [];

        $bg_color   = esc_attr( $val['background-color']      ?? '' );
        $bg_image   = esc_url(  $val['background-image']      ?? '' );
        $bg_repeat  = esc_attr( $val['background-repeat']     ?? 'no-repeat' );
        $bg_size    = esc_attr( $val['background-size']       ?? 'cover' );
        $bg_pos     = esc_attr( $val['background-position']   ?? 'center center' );
        $bg_attach  = esc_attr( $val['background-attachment'] ?? 'scroll' );
        $thumb_url  = esc_url( ( $val['media']['thumbnail'] ?? '' ) ?: $bg_image );

        $repeats    = [ 'no-repeat' => 'No Repeat', 'repeat' => 'Repeat', 'repeat-x' => 'Repeat X', 'repeat-y' => 'Repeat Y' ];
        $sizes      = [ 'cover' => 'Cover', 'contain' => 'Contain', 'auto' => 'Auto' ];
        $positions  = [
            'left top'      => 'Left Top',      'center top'   => 'Center Top',   'right top'      => 'Right Top',
            'left center'   => 'Left Center',   'center center'=> 'Center',        'right center'   => 'Right Center',
            'left bottom'   => 'Left Bottom',   'center bottom'=> 'Center Bottom', 'right bottom'   => 'Right Bottom',
        ];
        $attachments = [ 'scroll' => 'Scroll', 'fixed' => 'Fixed', 'local' => 'Local' ];
        ?>
        <label>
            <?php if ( ! empty( $this->label ) ) : ?>
                <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <?php endif; ?>
            <?php if ( ! empty( $this->description ) ) : ?>
                <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
            <?php endif; ?>
        </label>
        <div class="ct-bg-wrap" data-setting="<?php echo esc_attr( str_replace( 'ct_ctrl_', '', $this->id ) ); ?>">
            <div class="ct-bg-row">
                <label><?php esc_html_e( 'Background Color', 'contempo' ); ?></label>
                <input type="text" class="ct-color-picker ct-bg-color" value="<?php echo $bg_color; ?>" />
            </div>

            <div class="ct-bg-row">
                <label><?php esc_html_e( 'Background Image', 'contempo' ); ?></label>
                <div class="ct-media-preview">
                    <?php if ( $bg_image ) : ?>
                        <img src="<?php echo $thumb_url ?: $bg_image; ?>" class="ct-bg-preview-img" alt="" />
                    <?php endif; ?>
                </div>
                <input type="hidden" class="ct-bg-image-url" value="<?php echo $bg_image; ?>" />
                <input type="hidden" class="ct-bg-media-id"  value="<?php echo esc_attr( (int)( $val['media']['id'] ?? 0 ) ); ?>" />
                <div class="ct-media-actions">
                    <button type="button" class="button ct-bg-upload-btn"><?php esc_html_e( 'Select Image', 'contempo' ); ?></button>
                    <button type="button" class="button ct-bg-remove-btn" <?php echo $bg_image ? '' : 'style="display:none;"'; ?>><?php esc_html_e( 'Remove', 'contempo' ); ?></button>
                </div>
            </div>

            <div class="ct-bg-row">
                <label><?php esc_html_e( 'Repeat', 'contempo' ); ?></label>
                <select class="ct-bg-repeat">
                    <?php foreach ( $repeats as $rv => $rl ) : ?>
                        <option value="<?php echo esc_attr( $rv ); ?>" <?php selected( $bg_repeat, $rv ); ?>><?php echo esc_html( $rl ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="ct-bg-row">
                <label><?php esc_html_e( 'Size', 'contempo' ); ?></label>
                <select class="ct-bg-size">
                    <?php foreach ( $sizes as $sv => $sl ) : ?>
                        <option value="<?php echo esc_attr( $sv ); ?>" <?php selected( $bg_size, $sv ); ?>><?php echo esc_html( $sl ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="ct-bg-row">
                <label><?php esc_html_e( 'Position', 'contempo' ); ?></label>
                <select class="ct-bg-position">
                    <?php foreach ( $positions as $pv => $pl ) : ?>
                        <option value="<?php echo esc_attr( $pv ); ?>" <?php selected( $bg_pos, $pv ); ?>><?php echo esc_html( $pl ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="ct-bg-row">
                <label><?php esc_html_e( 'Attachment', 'contempo' ); ?></label>
                <select class="ct-bg-attachment">
                    <?php foreach ( $attachments as $av => $al ) : ?>
                        <option value="<?php echo esc_attr( $av ); ?>" <?php selected( $bg_attach, $av ); ?>><?php echo esc_html( $al ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <?php
    }
}
