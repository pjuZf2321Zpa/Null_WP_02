<?php
/**
 * CT Settings — Dynamic CSS Output
 *
 * Unified CSS pipeline replacing both custom-stylesheet.php (priority 10)
 * and Redux's output-array CSS (priority 150). One <style> block, one place to maintain.
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class CT_Dynamic_CSS {

    // -------------------------------------------------------------------------
    // Entry Points
    // -------------------------------------------------------------------------

    /**
     * Output the full unified <style> block on wp_head @ 150.
     */
    public static function output( string $opt_name ): void {
        /**
         * Filter: ct_dynamic_css_skip_output
         *
         * Return true to suppress PHP CSS output entirely.
         * Available for future Customizer-preview optimisation where the
         * preview JS handles all CSS injection via postMessage. For the
         * current implementation both the PHP block and the JS overrides
         * coexist — JS updates win because they are appended to <head> later.
         *
         * @param bool   $skip     Default false.
         * @param string $opt_name The options name (e.g. 'ct_options').
         */
        if ( apply_filters( 'ct_dynamic_css_skip_output', false, $opt_name ) ) return;

        global $ct_options;

        // In the Customizer preview frame the global was re-hydrated on the wp
        // action (boot() @ priority 1) AFTER WP applied its pre_option filter,
        // so $ct_options already contains the unsaved preview values here.
        // Self-healing fallback for any context where hydration was skipped.
        if ( ! is_array( $ct_options ) || empty( $ct_options ) ) {
            CT_Settings::hydrate_global( $opt_name );
            // Re-read the global after hydration
            $ct_options = $GLOBALS[ $opt_name ] ?? [];
        }

        $opts = is_array( $ct_options ) ? $ct_options : [];

        $css = '';

        // Always output explicit CSS — ct_use_styles gate was a Redux-era concept;
        // now that CT Settings is built in, styles should always apply.
        $css .= self::explicit_css( $opts );

        // Output-array CSS (typography, colors with output arrays)
        $css .= self::output_array_css( $opt_name, $opts );

        // Custom CSS — single output here; the ct_wp_head() block is removed
        if ( ! empty( $opts['ct_custom_css'] ) ) {
            $css .= ct_sanitize_output( CT_Settings::normalize_code( $opts['ct_custom_css'] ) );
        }

        if ( $css === '' ) return;

        // Match the element id Redux used so any CSS targeting it continues to work
        echo '<style id="ct_options-dynamic-css" class="redux-options-output" type="text/css">' . "\n";
        echo $css;
        echo "\n</style>\n";
    }

    /**
     * Enqueue Google Fonts for typography fields.
     * Runs on wp_enqueue_scripts @ 10.
     */
    public static function enqueue_google_fonts( string $opt_name ): void {
        $sections = CT_Settings::get_sections( $opt_name );
        $opts     = $GLOBALS[ CT_Settings::get_args( $opt_name )['global_variable'] ?? $opt_name ] ?? [];

        $fonts = [];

        foreach ( $sections as $section ) {
            foreach ( $section['fields'] ?? [] as $field ) {
                if ( ( $field['type'] ?? '' ) !== 'typography' ) continue;
                $id    = $field['id'] ?? '';
                $saved = $opts[ $id ] ?? [];
                if ( ! is_array( $saved ) ) continue;
                if ( empty( $saved['google'] ) || empty( $saved['font-family'] ) ) continue;

                $family  = $saved['font-family'];
                $weights = [];
                if ( ! empty( $saved['font-weight'] ) ) $weights[] = $saved['font-weight'];
                if ( ! empty( $saved['font-style'] ) && $saved['font-style'] === 'italic' ) {
                    $weights = array_map( fn( $w ) => $w . 'italic', $weights ?: [ '400' ] );
                }
                $subsets = ! empty( $saved['subsets'] ) ? $saved['subsets'] : 'latin';

                $key = str_replace( ' ', '+', $family );
                if ( ! isset( $fonts[ $key ] ) ) {
                    $fonts[ $key ] = [ 'weights' => [], 'subsets' => [] ];
                }
                $fonts[ $key ]['weights'] = array_unique( array_merge( $fonts[ $key ]['weights'], $weights ) );
                $subsets_arr              = array_map( 'trim', explode( ',', $subsets ) );
                $fonts[ $key ]['subsets'] = array_unique( array_merge( $fonts[ $key ]['subsets'], $subsets_arr ) );
            }
        }

        if ( empty( $fonts ) ) return;

        $families = [];
        foreach ( $fonts as $name => $data ) {
            $w = implode( ',', $data['weights'] );
            $families[] = $name . ( $w ? ':' . $w : '' );
        }

        $all_subsets = [];
        foreach ( $fonts as $data ) {
            $all_subsets = array_merge( $all_subsets, $data['subsets'] );
        }
        $all_subsets = array_unique( $all_subsets );

        $url = 'https://fonts.googleapis.com/css?family=' . implode( '|', $families )
             . '&subset=' . implode( ',', $all_subsets )
             . '&display=swap';

        wp_enqueue_style( 'redux-google-fonts-ct_options', $url, [], null );
    }

    // -------------------------------------------------------------------------
    // Explicit CSS (formerly custom-stylesheet.php)
    // -------------------------------------------------------------------------

    /**
     * Replicate every rule from includes/custom-stylesheet.php.
     * Always called. Outputs CSS for all custom style options.
     */
    private static function explicit_css( array $opts ): string {
        $css = '';

        // Body background
        $bg = $opts['ct_background'] ?? [];
        if ( ! empty( $bg ) ) {
            $bg_color      = ! empty( $bg['background-color'] )  ? CT_Settings::esc_css( $bg['background-color'] ) : '';
            $bg_image      = ! empty( $bg['background-image'] )  ? CT_Settings::esc_css( $bg['background-image'] ) : '';
            $bg_repeat     = ! empty( $bg['background-repeat'] ) ? CT_Settings::esc_css( $bg['background-repeat'] ) : '';
            $bg_position   = ! empty( $bg['background-position'] ) ? CT_Settings::esc_css( $bg['background-position'] ) : '';
            $bg_size       = ! empty( $bg['background-size'] )   ? CT_Settings::esc_css( $bg['background-size'] ) : '';
            $bg_attachment = ! empty( $bg['background-attachment'] ) ? CT_Settings::esc_css( $bg['background-attachment'] ) : '';

            $body_rules = '';
            if ( $bg_color )      $body_rules .= "background-color:{$bg_color};";
            if ( $bg_image )      $body_rules .= "background-image:url({$bg_image});";
            if ( $bg_repeat )     $body_rules .= "background-repeat:{$bg_repeat};";
            if ( $bg_position )   $body_rules .= "background-position:{$bg_position};";
            if ( $bg_size )       $body_rules .= "background-size:{$bg_size};";
            if ( $bg_attachment ) $body_rules .= "background-attachment:{$bg_attachment};";

            if ( $body_rules ) $css .= "body{{$body_rules}}";
        }

        // Top Bar
        $v = self::rgba_or_empty( $opts['ct_header_bar_color'] ?? '' );
        if ( $v ) {
            $b    = self::rgba_or_empty( $opts['ct_header_bar_border_color'] ?? '' );
            $css .= "#topbar-wrap{background:{$v} !important;" . ( $b ? "border-bottom-color:{$b} !important;" : '' ) . "}";
        }
        // ct_header_bar_text_color covers both the container text and all top-bar links/anchors
        $v = self::rgba_or_empty( $opts['ct_header_bar_text_color'] ?? '' );
        if ( $v ) $css .= "#topbar-wrap,#topbar-wrap .container,#topbar-wrap a,#topbar-wrap a:visited{color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_header_bar_border_color'] ?? '' );
        if ( $v ) {
            $css .= "#topbar-wrap .container{border-bottom-color:{$v};}";
            $css .= "#topbar-wrap .social li:first-child a{border-left-color:{$v};}";
            $css .= "#topbar-wrap .social a{border-right-color:{$v};}";
        }
        $v = self::rgba_or_empty( $opts['ct_header_bar_user_bg_color'] ?? '' );
        if ( $v ) $css .= "#topbar-wrap li.user-logged-in a,#topbar-wrap ul.user-drop{background:{$v};}";

        $v = self::rgba_or_empty( $opts['ct_header_bar_user_link_color'] ?? '' );
        if ( $v ) $css .= "#topbar-wrap li.user-logged-in a{color:{$v};}";

        $v = self::rgba_or_empty( $opts['ct_header_bar_user_btm_border_color'] ?? '' );
        if ( $v ) $css .= "#topbar-wrap li.user-logged-in a,#topbar-wrap ul.user-drop li{border-bottom-color:{$v};}";

        // Header user login area (main header bar)
        $v = self::rgba_or_empty( $opts['ct_header_user_trigger_bg'] ?? '' );
        if ( $v ) $css .= ".user-frontend li.user-logged-in > a{background-color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_header_user_name_color'] ?? '' );
        if ( $v ) $css .= ".user-frontend li.user-logged-in span.user-name{color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_header_user_drop_bg'] ?? '' );
        if ( $v ) $css .= ".user-frontend ul.user-drop{background-color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_header_user_drop_link_color'] ?? '' );
        if ( $v ) $css .= ".user-frontend ul.user-drop a{color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_header_user_drop_icon_color'] ?? '' );
        if ( $v ) $css .= ".user-frontend ul.user-drop li svg{fill:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_header_user_drop_separator'] ?? '' );
        if ( $v ) $css .= ".user-frontend ul.user-drop li{border-bottom-color:{$v} !important;}";

        // user-drop hover + current → secondary brand color (auto-cohesive, no extra option needed)
        $v = self::rgba_or_empty( $opts['ct_secondary_bg_color'] ?? '' );
        if ( $v ) $css .= ".user-frontend ul.user-drop a:hover,.user-frontend ul.user-drop a.current{background-color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_secondary_text_color'] ?? '' );
        if ( $v ) $css .= ".user-frontend ul.user-drop a:hover,.user-frontend ul.user-drop a.current{color:{$v} !important;}";

        // User sidebar navigation
        $v = self::rgba_or_empty( $opts['ct_user_sidebar_bg'] ?? '' );
        if ( $v ) $css .= "aside#user-nav{background-color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_user_sidebar_link_bg'] ?? '' );
        if ( $v ) $css .= "ul.user-nav li a{background-color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_user_sidebar_link_color'] ?? '' );
        if ( $v ) $css .= "ul.user-nav li a{color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_user_sidebar_current_bg'] ?? '' );
        if ( $v ) $css .= "ul.user-nav li a.current{background-color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_user_sidebar_current_color'] ?? '' );
        if ( $v ) $css .= "ul.user-nav li a.current{color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_user_sidebar_icon_color'] ?? '' );
        if ( $v ) $css .= ".user-nav svg *{fill:{$v} !important;}.my-listings-count,.user-data-count,.ctidxpp-favorites-count,.ctidxpp-saved-search-count,.ctidxpp-recently-viewed-count{color:{$v} !important;border-color:{$v} !important;}";

        // user sidebar hover → secondary brand color (auto-cohesive, no extra option needed)
        $v = self::rgba_or_empty( $opts['ct_secondary_bg_color'] ?? '' );
        if ( $v ) $css .= "ul.user-nav li a:hover{background-color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_secondary_text_color'] ?? '' );
        if ( $v ) $css .= "ul.user-nav li a:hover{color:{$v} !important;}";

        // Auto-contrast icon fill on hover — white on dark secondary, dark on light secondary
        $secondary_hex = is_array( $opts['ct_secondary_bg_color'] ?? null )
            ? ( $opts['ct_secondary_bg_color']['color'] ?? '' )
            : '';
        if ( $secondary_hex ) {
            $icon_hover = self::hex_luminance( $secondary_hex ) < 0.5 ? '#fff' : '#191919';
            $css .= "ul.user-nav li a:hover svg *,.user-frontend ul.user-drop a:hover svg *{fill:{$icon_hover} !important;}";
        }

        // Header nav
        $v = self::rgba_or_empty( $opts['ct_header_nav_font_color'] ?? '' );
        if ( $v ) $css .= ".ct-menu > li > a,.home #header-wrap.trans-header.sticky nav li > a,.page #header-wrap.trans-header.sticky nav li > a,.home #header-wrap.trans-header.sticky.active nav li > a,.page #header-wrap.trans-header.sticky.active nav li > a,.user-frontend li.login-register a{color:{$v};}";

        $v = self::rgba_or_empty( $opts['ct_header_nav_current_bg'] ?? '' );
        if ( $v ) $css .= ".ct-menu li.current-menu-item a,.ct-menu li.current_page_parent a{border-top-color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_header_nav_hover_border_color'] ?? '' );
        if ( $v ) $css .= "nav > ul.ct-menu > li:hover > a,.ct-menu li.current-menu-item > a,.ct-menu li.current-menu-ancestor > a{border-top-color:{$v} !important;}";

        // Sub nav — color_rgba fields, use rgba value
        foreach ( [
            'ct_header_sub_nav_font_color'            => '.ct-menu .sub-menu > li > a{color:%s !important;}',
            'ct_header_sub_nav_hover_font_color'      => '.ct-menu .sub-menu > li > a:hover{color:%s !important;}',
            'ct_header_sub_nav_hover_background_color'=> '.ct-menu .sub-menu > li > a:hover{background-color:%s !important;}',
            'ct_header_sub_nav_background_color'      => '.ct-menu .sub-menu,.ct-menu .multicolumn > .sub-menu,.ct-menu .sub-menu > li,.ct-menu .sub-menu > li > a{background-color:%s !important;}',
            'ct_header_sub_nav_items_border_bottom_color' => '.ct-menu .sub-menu > li > a{border-bottom-color:%s !important;}',
        ] as $key => $template ) {
            $val = self::rgba_or_empty( $opts[ $key ] ?? '' );
            if ( $val ) $css .= sprintf( $template, $val );
        }

        // Header Style 4 — Overlay nav colors
        $v = self::rgba_or_empty( $opts['ct_header_four_overlay_bg'] ?? '' );
        if ( $v ) $css .= "#ct-nav-overlay{background-color:{$v};}";

        $v = self::rgba_or_empty( $opts['ct_header_four_overlay_link_color'] ?? '' );
        if ( $v ) $css .= "#ct-nav-overlay .ct-overlay-menu a{color:{$v};}";

        $v = self::rgba_or_empty( $opts['ct_header_four_overlay_link_hover_color'] ?? '' );
        if ( $v ) $css .= "#ct-nav-overlay .ct-overlay-menu a:hover{color:{$v};}.ct-overlay-hamburger:hover .hamburger-line{background-color:{$v} !important;}.ct-overlay-nav li.open > a .ct-overlay-submenu-toggle i{color:{$v} !important;}.ct-overlay-nav ul.ct-overlay-menu > li > a:hover .ct-overlay-submenu-toggle i{color:{$v} !important;}";

        // Mobile menu
        $v = self::rgba_or_empty( $opts['ct_mobile_btn_icon_color'] ?? '' );
        if ( $v ) $css .= ".show-hide{color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_mobile_menu_bg_color'] ?? '' );
        if ( $v ) $css .= ".cbp-spmenu,.cbp-spmenu a{background-color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_mobile_menu_link_hover_bg_color'] ?? '' );
        if ( $v ) $css .= ".cbp-spmenu a:hover{background:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_header_nav_btn_outline'] ?? '' );
        if ( $v ) $css .= "a.btn-outline,.header-style-three .user-frontend.not-logged-in li a.btn-outline{color:{$v} !important;border-color:{$v} !important;}";

        // Secondary brand color — CSS is emitted via the field's output array in output_array_css().

        // Map toggle
        $v = self::rgba_or_empty( $opts['ct_map_toggle'] ?? '' );
        if ( $v ) $css .= "span.map-toggle a,span.search-toggle a,.listing-tools li a.btn{background-color:{$v} !important;}";

        // Filter pills
        $v = self::rgba_or_empty( $opts['ct_filter_pill_bg'] ?? '' );
        if ( $v ) $css .= ".ct-filter-pill{background:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_filter_pill_text'] ?? '' );
        if ( $v ) $css .= ".ct-filter-pill{color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_filter_pill_remove_color'] ?? '' );
        if ( $v ) $css .= ".ct-filter-pill-remove{color:{$v} !important;}";

        // Featured listings view all
        $v = self::rgba_or_empty( $opts['ct_featured_view_all'] ?? '' );
        if ( $v ) $css .= ".featured-listings a.view-all{background-color:{$v} !important;}";

        // Listing
        $v = self::rgba_or_empty( $opts['ct_listing_font_color'] ?? '' );
        if ( $v ) $css .= "li.listing,.propinfo .muted,article.listing,.page-template-template-submit-listing article,.page-template-template-edit-listing-php article{color:{$v};}";

        $v = self::rgba_or_empty( $opts['ct_listing_border_bottom_color'] ?? '' );
        if ( $v ) $css .= ".propinfo li.row,.agent-info li.row{border-bottom-color:{$v};}";

        $v = self::rgba_or_empty( $opts['ct_listing_background_color'] ?? '' );
        if ( $v ) $css .= "li.listing,article.listing,.page-template-template-submit-listing article,.page-template-template-edit-listing-php article{background-color:{$v};}";

        // Listing single
        $v = self::rgba_or_empty( $opts['ct_listing_heading_font_color'] ?? '' );
        if ( $v ) $css .= ".single-listings header.listing-location h2{color:{$v};}";

        $v = self::rgba_or_empty( $opts['ct_listing_more_info_font_color'] ?? '' );
        if ( $v ) $css .= ".main-agent h5,.main-agent a,.main-agent i{color:{$v};}";

        // Price
        $v = self::rgba_or_empty( $opts['ct_price_bg'] ?? '' );
        if ( $v ) $css .= ".flex-caption p.price,.grid-listing-info .price,.list-listing-info .price,.single-listings article .price,.infobox .price{background:{$v};}";

        // Widgets
        $v = self::rgba_or_empty( $opts['ct_sidebar_widget_bg'] ?? '' );
        if ( $v ) $css .= "aside.widget,#sidebar .widget,.aq-block-aq_widgets_block .widget{background:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_sidebar_widget_link_color'] ?? '' );
        if ( $v ) $css .= "#sidebar .widget li a,aside.widget li a,.aq-block-aq_widgets_block .widget li a{color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_sidebar_widget_link_hover_color'] ?? '' );
        if ( $v ) $css .= "#sidebar .widget li a:hover,aside.widget li a:hover,.aq-block-aq_widgets_block .widget li a:hover{color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_widget_header_bg_color'] ?? '' );
        if ( $v ) $css .= ".widget h5,.aq-block-aq_widgets_block .widget h2,.aq-block-aq_widgets_block .widget h5{background-color:{$v} !important;}";

        // Links
        $v = self::rgba_or_empty( $opts['ct_link_color'] ?? '' );
        if ( $v ) $css .= "a,.more,.pagination .current,.flex-direction-nav a i{color:{$v};}";

        $v = self::rgba_or_empty( $opts['ct_visited_color'] ?? '' );
        if ( $v ) $css .= "a:visited{color:{$v};}";

        $v = self::rgba_or_empty( $opts['ct_hover_color'] ?? '' );
        if ( $v ) $css .= "a:hover,.more:hover,.pagination a:hover{color:{$v};}";

        $v = self::rgba_or_empty( $opts['ct_active_color'] ?? '' );
        if ( $v ) $css .= "a:active,.more:active,.pagination a:active{color:{$v};}";

        // Footer
        $v = self::rgba_or_empty( $opts['ct_footer_widget_background'] ?? '' );
        if ( $v ) $css .= "#footer-widgets{background:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_footer_widget_heading_color'] ?? '' );
        if ( $v ) $css .= "#footer-widgets h5{color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_footer_widget_font_color'] ?? '' );
        if ( $v ) {
            $css .= "#footer-widgets .widget,#footer-widgets .widget a,#footer-widgets .widget a:visited,#footer-widgets .widget li{color:{$v} !important;border-bottom-color:{$v} !important;}";
            $css .= "#footer-widgets .contact-social li a,#footer-widgets .widget_ct_mortgagecalculator p.muted{border-color:{$v} !important;}";
        }

        $v = self::rgba_or_empty( $opts['ct_footer_link_color'] ?? '' );
        if ( $v ) $css .= "footer,footer nav ul li a,footer nav ul li a:visited,footer a,footer a:visited{color:{$v} !important;}";

        // Footer nav link hover
        $v = self::rgba_or_empty( $opts['ct_footer_link_hover_color'] ?? '' );
        if ( $v ) $css .= "footer nav ul li a:hover,footer a:hover{color:{$v} !important;}";

        $v = self::rgba_or_empty( $opts['ct_footer_background'] ?? '' );
        if ( $v ) $css .= "footer{background:{$v} !important;}";

        // Footer top border (field exists but had no CSS rule before)
        $v = self::rgba_or_empty( $opts['ct_footer_border_top_color'] ?? '' );
        if ( $v ) $css .= "footer#site-footer{border-top-color:{$v} !important;}";

        // Footer widget link hover
        $v = self::rgba_or_empty( $opts['ct_footer_widget_link_hover_color'] ?? '' );
        if ( $v ) $css .= "#footer-widgets .widget a:hover{color:{$v} !important;}";

        // Footer widget item border
        $v = self::rgba_or_empty( $opts['ct_footer_widget_border_color'] ?? '' );
        if ( $v ) {
            $css .= "#footer-widgets .widget li{border-bottom-color:{$v} !important;}";
            $css .= "#footer-widgets .contact-social li a{border-color:{$v} !important;}";
        }

        // Header nav link hover text color — scoped to <header> so #nav-full-width (outside <header>) keeps its white text on the colored bar
        $v = self::rgba_or_empty( $opts['ct_header_nav_hover_color'] ?? '' );
        if ( $v ) $css .= "header .ct-menu > li > a:hover,header .ct-menu li.current-menu-item > a,header .ct-menu li.current-menu-ancestor > a,header .ct-menu li.current_page_parent > a{color:{$v} !important;}";

        // Sticky header background
        $v = self::rgba_or_empty( $opts['ct_header_sticky_background'] ?? '' );
        if ( $v ) $css .= "#home.home #header-wrap.trans-header.sticky,.page #header-wrap.trans-header.sticky,.single #header-wrap.trans-header.sticky,.search-listings #header-wrap.trans-header.sticky,#header-wrap.sticky{background:{$v} !important;}";

        // Sticky header nav text color
        $v = self::rgba_or_empty( $opts['ct_header_sticky_nav_font_color'] ?? '' );
        if ( $v ) $css .= ".home #header-wrap.trans-header.sticky nav li > a,.page #header-wrap.trans-header.sticky nav li > a,.home #header-wrap.trans-header.sticky.active nav li > a,.page #header-wrap.trans-header.sticky.active nav li > a{color:{$v} !important;}";

        // Sticky header nav hover text color
        $v = self::rgba_or_empty( $opts['ct_header_sticky_nav_hover_color'] ?? '' );
        if ( $v ) $css .= ".home #header-wrap.trans-header.sticky nav li > a:hover,.page #header-wrap.trans-header.sticky nav li > a:hover,.home #header-wrap.trans-header.sticky.active nav li > a:hover,.page #header-wrap.trans-header.sticky.active nav li > a:hover,#header-wrap.sticky nav li > a:hover{color:{$v} !important;}";

        // Transparent header user name color
        $v = self::rgba_or_empty( $opts['ct_header_trans_user_name_color'] ?? '' );
        if ( $v ) $css .= ".home #header-wrap.trans-header .user-frontend li.user-logged-in span.user-name,.page #header-wrap.trans-header .user-frontend li.user-logged-in span.user-name{color:{$v} !important;}";

        // Header search bar background
        $v = self::rgba_or_empty( $opts['ct_header_search_bar_bg'] ?? '' );
        if ( $v ) $css .= "#header-search-wrap{background:{$v} !important;border-top-color:{$v};border-bottom-color:{$v};}";

        // Search autocomplete/suggestion box background
        $v = self::rgba_or_empty( $opts['ct_header_search_suggestion_bg'] ?? '' );
        if ( $v ) $css .= "#suggestion-box,#hero-suggestion-box,#suggestion-box .listing-records,#hero-suggestion-box .listing-records{background:{$v} !important;}";

        // Body text color
        $v = self::rgba_or_empty( $opts['ct_body_text_color'] ?? '' );
        if ( $v ) $css .= "body,p{color:{$v};}";

        // Form input background
        $v = self::rgba_or_empty( $opts['ct_input_background_color'] ?? '' );
        if ( $v ) $css .= "input[type=text],input[type=email],input[type=tel],input[type=number],input[type=search],input[type=password],input[type=url],select,textarea{background-color:{$v} !important;}";

        // Form input border
        $v = self::rgba_or_empty( $opts['ct_input_border_color'] ?? '' );
        if ( $v ) $css .= "input[type=text],input[type=email],input[type=tel],input[type=number],input[type=search],input[type=password],input[type=url],select,textarea{border-color:{$v} !important;}";

        // Form input text color
        $v = self::rgba_or_empty( $opts['ct_input_text_color'] ?? '' );
        if ( $v ) $css .= "input[type=text],input[type=email],input[type=tel],input[type=number],input[type=search],input[type=password],input[type=url],select,textarea{color:{$v} !important;}";

        // Listing card "View Listing" button background
        $v = self::rgba_or_empty( $opts['ct_listing_view_btn_bg'] ?? '' );
        if ( $v ) $css .= "li.listing.modern .search-view-listing.btn,li.listing.modern_two .search-view-listing.btn{background:{$v} !important;border-color:{$v} !important;}";

        // Listing card "View Listing" button text color
        $v = self::rgba_or_empty( $opts['ct_listing_view_btn_text'] ?? '' );
        if ( $v ) $css .= "li.listing.modern .search-view-listing.btn,li.listing.modern_two .search-view-listing.btn{color:{$v} !important;}";

        // Listing status snipe pill background
        $v = self::rgba_or_empty( $opts['ct_status_snipe_color'] ?? '' );
        if ( $v ) $css .= "h6.snipe.status span{background:{$v} !important;}";

        // Listing featured snipe pill background
        $v = self::rgba_or_empty( $opts['ct_status_featured_color'] ?? '' );
        if ( $v ) $css .= "h6.snipe.featured span{background:{$v} !important;}";

        // ── Header Style 2: Info Blocks ───────────────────────────────────────

        // Info block background
        $v = self::rgba_or_empty( $opts['ct_header_two_info_bg'] ?? '' );
        if ( $v ) $css .= ".header-info{background-color:{$v};}";

        // Info block border (border-top shown at tablet/mobile breakpoints)
        $v = self::rgba_or_empty( $opts['ct_header_two_info_border'] ?? '' );
        if ( $v ) $css .= ".header-info{border-top-color:{$v} !important;}";

        // Info block icon color
        $v = self::rgba_or_empty( $opts['ct_header_two_info_icon_color'] ?? '' );
        if ( $v ) $css .= ".header-info i{color:{$v} !important;}";

        // Info block title color
        $v = self::rgba_or_empty( $opts['ct_header_two_info_title_color'] ?? '' );
        if ( $v ) $css .= ".header-info h5{color:{$v} !important;}";

        // Info block subtext color
        $v = self::rgba_or_empty( $opts['ct_header_two_info_text_color'] ?? '' );
        if ( $v ) $css .= ".header-info p.muted{color:{$v} !important;}";

        // ── Header Style 2: Full-Width Nav Bar ────────────────────────────────

        // Nav bar link color
        $v = self::rgba_or_empty( $opts['ct_header_two_nav_link_color'] ?? '' );
        if ( $v ) $css .= "#nav-full-width .ct-menu > li > a{color:{$v} !important;}";

        // Nav bar link hover color
        $v = self::rgba_or_empty( $opts['ct_header_two_nav_link_hover_color'] ?? '' );
        if ( $v ) $css .= "#nav-full-width .ct-menu > li > a:hover{color:{$v} !important;}";

        // ── Header Style 3: Login / Register Area ─────────────────────────────

        // Login button outline border color
        $v = self::rgba_or_empty( $opts['ct_header_three_login_border_color'] ?? '' );
        if ( $v ) $css .= ".header-style-three .user-frontend li a.btn-outline{border-color:{$v} !important;}";

        // Logged-in user name and link text color
        $v = self::rgba_or_empty( $opts['ct_header_three_user_text_color'] ?? '' );
        if ( $v ) {
            $css .= ".header-style-three .user-frontend li.user-logged-in > a{color:{$v} !important;}";
            $css .= ".header-style-three .user-frontend li.user-logged-in span.user-name{color:{$v} !important;}";
        }

        // ── Text Logo Font Size ───────────────────────────────────────────────────
        if ( ( $opts['ct_text_logo'] ?? 'no' ) === 'yes' ) {
            $v = (int)( $opts['ct_text_logo_font_size'] ?? 28 );
            if ( $v > 0 ) $css .= "header #logo h2,header #logo h2 a{font-size:{$v}px !important;}";
        }

        // ── Advanced Logo Sizing ──────────────────────────────────────────────────
        if ( ( $opts['ct_logo_advanced_sizing'] ?? 'no' ) === 'yes' ) {
            $v = (int)( $opts['ct_logo_max_width'] ?? 228 );
            if ( $v > 0 ) $css .= "header#masthead .logo-wrap img{max-width:{$v}px !important;width:auto !important;}";
        }

        return $css;
    }

    // -------------------------------------------------------------------------
    // Output-Array CSS (formerly Redux_Output::enqueue)
    // -------------------------------------------------------------------------

    /**
     * Walk all registered fields and emit CSS from their `output` arrays.
     * Replicates Redux_Output behavior exactly.
     */
    private static function output_array_css( string $opt_name, array $opts ): string {
        $css      = '';
        $sections = CT_Settings::get_sections( $opt_name );

        // Only emit custom typography CSS when the advanced controls toggle is on.
        $typostyles_on = in_array( $opts['ct_use_typostyles'] ?? 'no', [ 'yes', 'on', true, '1', 1 ], true );

        foreach ( $sections as $section ) {
            foreach ( $section['fields'] ?? [] as $field ) {
                if ( ( $field['type'] ?? '' ) === 'typography' && ! $typostyles_on ) continue;
                $css .= self::field_output_css( $field, $opts );
            }
        }

        return $css;
    }

    private static function field_output_css( array $field, array $opts ): string {
        $id     = $field['id'] ?? '';
        $type   = $field['type'] ?? '';
        $output = $field['output'] ?? null;

        if ( empty( $id ) || empty( $output ) ) return '';

        $saved = $opts[ $id ] ?? null;
        if ( $saved === null || $saved === '' || $saved === false ) return '';

        $css = '';

        match ( $type ) {
            'color'      => $css = self::color_output_css( $field, $saved ),
            'color_rgba' => $css = self::color_rgba_output_css( $field, $saved ),
            'typography' => $css = self::typography_output_css( $field, $saved ),
            'background' => $css = self::background_output_css( $field, $saved ),
            default      => $css = self::generic_output_css( $field, $saved ),
        };

        return $css;
    }

    /**
     * Color field output.
     * Saved value: plain hex string, e.g. "#2271b1" or "transparent"
     */
    private static function color_output_css( array $field, mixed $saved ): string {
        if ( ! is_string( $saved ) || $saved === '' ) return '';

        $mode      = $field['mode'] ?? 'color';
        $output    = $field['output'];
        $important = '';

        return self::build_css_from_output( $output, $mode, CT_Settings::esc_css( $saved ), $important );
    }

    /**
     * Color RGBA field output.
     * Saved value: ['color' => '#hex', 'alpha' => 0.8, 'rgba' => 'rgba(...)']
     * Also accepts a legacy plain hex string (migrated from old color field saves).
     */
    private static function color_rgba_output_css( array $field, mixed $saved ): string {
        $value = self::rgba_or_empty( $saved );
        if ( $value === '' ) return '';

        $mode   = $field['mode'] ?? 'color';
        $output = $field['output'];

        return self::build_css_from_output( $output, $mode, $value, '' );
    }

    /**
     * Typography field output.
     * Saved value: array with font-family, font-size, font-weight, line-height, color, etc.
     * Emits one block per output selector with all sub-key CSS properties.
     */
    private static function typography_output_css( array $field, mixed $saved ): string {
        if ( ! is_array( $saved ) || empty( $field['output'] ) ) return '';

        $style_string = self::typography_css_style( $saved );
        if ( $style_string === '' ) return '';

        $selectors = is_array( $field['output'] ) ? implode( ',', $field['output'] ) : (string) $field['output'];
        if ( $selectors === '' ) return '';

        return "{$selectors}{{$style_string}}";
    }

    /**
     * Build CSS property string from a typography saved value.
     * Mirrors Redux's Redux_Typography::css_style() behavior.
     */
    private static function typography_css_style( array $saved ): string {
        $skip = [ 'google', 'subsets', 'font-backup', 'font-options' ];
        $props = [];

        // Collect shadow sub-keys first so we can collapse them
        $shadow = [
            'shadow-color'      => $saved['shadow-color'] ?? '',
            'shadow-horizontal' => $saved['shadow-horizontal'] ?? '',
            'shadow-vertical'   => $saved['shadow-vertical'] ?? '',
            'shadow-blur'       => $saved['shadow-blur'] ?? '',
        ];

        $has_shadow = $shadow['shadow-color'] !== '';

        foreach ( $saved as $prop => $val ) {
            if ( in_array( $prop, $skip, true ) ) continue;
            if ( str_starts_with( $prop, 'shadow-' ) ) continue; // collapsed below
            if ( $val === '' || $val === null || $val === false ) continue;

            if ( $prop === 'font-family' ) {
                $family = (string) $val;
                if ( str_contains( $family, ' ' ) ) {
                    $family = "'{$family}'";
                }
                $backup = $saved['font-backup'] ?? '';
                $props[] = "font-family:{$family}" . ( $backup ? ",{$backup}" : '' ) . ';';
                continue;
            }

            $props[] = "{$prop}:" . CT_Settings::esc_css( (string) $val ) . ';';
        }

        // If no font-weight or font-style but other font props exist, force 'normal'
        $has_font_props = ! empty( array_filter( array_keys( $saved ), fn( $k ) => str_starts_with( $k, 'font-' ) && $k !== 'font-backup' && $k !== 'font-options' ) );
        if ( $has_font_props ) {
            if ( ( $saved['font-weight'] ?? '' ) === '' ) {
                $props[] = 'font-weight:normal;';
            }
            if ( ( $saved['font-style'] ?? '' ) === '' ) {
                $props[] = 'font-style:normal;';
            }
        }

        // text-shadow from sub-keys
        if ( $has_shadow ) {
            $props[] = sprintf(
                'text-shadow:%s %s %s %s;',
                CT_Settings::esc_css( $shadow['shadow-horizontal'] ),
                CT_Settings::esc_css( $shadow['shadow-vertical'] ),
                CT_Settings::esc_css( $shadow['shadow-blur'] ),
                CT_Settings::esc_css( $shadow['shadow-color'] )
            );
        }

        return implode( '', $props );
    }

    /**
     * Background field output.
     * Saved value: array with background-color, background-image, etc.
     */
    private static function background_output_css( array $field, mixed $saved ): string {
        if ( ! is_array( $saved ) || empty( $field['output'] ) ) return '';

        $parts = [];
        $skip  = [ 'media' ];

        foreach ( $saved as $prop => $val ) {
            if ( in_array( $prop, $skip, true ) || $val === '' || $val === null ) continue;

            if ( $prop === 'background-image' ) {
                $parts[] = "background-image:url('" . CT_Settings::esc_css( $val ) . "');";
            } else {
                $parts[] = "{$prop}:" . CT_Settings::esc_css( (string) $val ) . ';';
            }
        }

        if ( empty( $parts ) ) return '';

        $style_string = implode( '', $parts );
        $selectors    = is_array( $field['output'] ) ? implode( ',', $field['output'] ) : (string) $field['output'];

        return "{$selectors}{{$style_string}}";
    }

    /**
     * Generic scalar output (select, text, slider) — uses field mode as CSS property.
     */
    private static function generic_output_css( array $field, mixed $saved ): string {
        if ( ! is_scalar( $saved ) || $saved === '' ) return '';

        $mode   = $field['mode'] ?? 'color';
        $output = $field['output'];

        return self::build_css_from_output( $output, $mode, CT_Settings::esc_css( (string) $saved ), '' );
    }

    // -------------------------------------------------------------------------
    // CSS Builder Helpers
    // -------------------------------------------------------------------------

    /**
     * Build CSS string from an `output` array in either format:
     *
     * Format 1 (numeric): ['selector', 'selector2'] → "selector,selector2{mode:value;}"
     * Format 2 (associative): ['css-prop' => 'selectors'] → "selectors{css-prop:value;}"
     * Special: ['important' => true] forces !important
     */
    private static function build_css_from_output(
        array|string $output,
        string $default_mode,
        string $value,
        string $important_suffix
    ): string {
        if ( is_string( $output ) ) {
            $output = [ $output ];
        }

        $is_important = ! empty( $output['important'] );
        $imp          = $is_important ? ' !important' : $important_suffix;

        // Detect format: if all keys are integers → Format 1
        $numeric_keys = array_filter( array_keys( $output ), 'is_int' );
        if ( count( $numeric_keys ) === count( $output ) ) {
            // Format 1
            $selectors = implode( ',', array_values( $output ) );
            if ( $selectors === '' ) return '';
            return "{$selectors}{{$default_mode}:{$value}{$imp};}";
        }

        // Format 2 (associative, possibly with 'important' mixed in)
        $css = '';
        foreach ( $output as $prop => $selectors ) {
            if ( $prop === 'important' ) continue;
            if ( ! is_string( $selectors ) || $selectors === '' ) continue;
            $css .= "{$selectors}{{$prop}:{$value}{$imp};}";
        }
        return $css;
    }

    // -------------------------------------------------------------------------
    // Value Helpers
    // -------------------------------------------------------------------------

    /**
     * Extract a usable CSS value from a color_rgba saved value.
     * Returns empty string if nothing usable.
     */
    private static function rgba_or_empty( mixed $val ): string {
        if ( is_string( $val ) && $val !== '' ) {
            return CT_Settings::esc_css( $val );
        }
        if ( is_array( $val ) ) {
            $alpha = (float) ( $val['alpha'] ?? 1 );
            $color = $alpha < 1 ? ( $val['rgba'] ?? '' ) : ( $val['color'] ?? '' );
            return $color !== '' ? CT_Settings::esc_css( $color ) : '';
        }
        return '';
    }

    /**
     * Calculate relative luminance (0.0–1.0) from a hex color string.
     * Uses the linearized sRGB formula per WCAG 2.x.
     * Returns 0.5 (neutral) if the hex is malformed.
     */
    private static function hex_luminance( string $hex ): float {
        $hex = ltrim( $hex, '#' );
        if ( strlen( $hex ) !== 6 ) return 0.5;
        $chan = static function( int $c ): float {
            $s = $c / 255;
            return $s <= 0.03928 ? $s / 12.92 : ( ( $s + 0.055 ) / 1.055 ) ** 2.4;
        };
        return 0.2126 * $chan( hexdec( substr( $hex, 0, 2 ) ) )
             + 0.7152 * $chan( hexdec( substr( $hex, 2, 2 ) ) )
             + 0.0722 * $chan( hexdec( substr( $hex, 4, 2 ) ) );
    }
}
