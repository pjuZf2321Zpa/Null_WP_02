/**
 * CT Settings Admin Panel — Main JS
 *
 * Features:
 * - Hash-based navigation (bookmarkable sections)
 * - Required/conditional field visibility engine
 * - AJAX save with snackbar feedback
 * - Cmd/Ctrl+S keyboard shortcut
 * - localStorage draft recovery
 * - Section reset to defaults
 * - Live typography preview
 * - WP color picker + RGBA color picker
 * - Media uploader integration
 * - Sorter drag-and-drop
 * - CodeMirror for ace_editor fields
 * - Image select
 * - Search / filter
 * - Responsive sidebar
 *
 * @package WP Pro Real Estate 7
 */

/* global ctSettings, wp */
(function ($) {
    'use strict';

    const CS = ctSettings; // localized data

    // =========================================================================
    // State
    // =========================================================================
    let currentSection    = null;
    let isDirty           = false;
    let dirtySections     = new Set();
    let pendingNavigation = null;
    let nonce             = CS.nonce;
    let draftKey          = 'ct_settings_draft_' + CS.optName;
    let draftData         = null;
    let activeSearchQuery = '';
    let searchIndex       = null; // built once on init from rendered DOM

    // =========================================================================
    // Init
    // =========================================================================
    function init() {
        initNav();
        initRequiredEngine();
        initSave();
        initKeyboardShortcut();
        initColorPickers();
        initRGBAPickers();
        initMediaUploader();
        initBgPreview();
        initSorter();
        initCodeEditor();
        initImageSelect();
        initPagePicker();
        initCombobox();
        initSliders();
        initTypographyPreview();
        buildSearchIndex(); // pre-build before initSearch attaches listeners
        initSearch();
        initSectionReset();
        initImportExport();
        initMobileSidebar();
        initDraftRecovery();
        initSwitchLabels();
        initDirtyTracking();
        initOnboarding();

        // Navigate to hash or first section
        const hash = window.location.hash.replace('#', '');
        navigateTo(hash || getFirstSectionId());

        // Dismiss loading overlay
        const loader = document.getElementById('ct-settings-loading');
        if (loader) loader.classList.add('ct-loading-hidden');
    }

    // =========================================================================
    // Navigation
    // =========================================================================
    function getFirstSectionId() {
        const first = document.querySelector('.ct-nav-item');
        return first ? first.getAttribute('data-section') : '';
    }

    function navigateTo(sectionId) {
        if (!sectionId) return;

        // Hide search results panel so the section panel is shown instead
        const resultsPanel = document.getElementById('ct-search-results');
        if (resultsPanel) resultsPanel.style.display = 'none';

        // Hide all sections
        document.querySelectorAll('.ct-settings-section').forEach(el => {
            el.style.display = 'none';
        });

        // Show target section
        const target = document.querySelector('.ct-settings-section[data-section="' + sectionId + '"]');
        if (target) {
            target.style.display = 'block';
            currentSection = sectionId;
        }

        // Update sidebar active state
        setActiveNavItem(sectionId);

        // Update URL hash without scroll jump
        if (history.replaceState) {
            history.replaceState(null, '', '#' + sectionId);
            window.dispatchEvent(new CustomEvent('ct:sectionchange', { detail: { section: sectionId } }));
        }

        // Re-run visibility engine for newly visible section
        runRequiredEngine();

        // Init field types that require visible DOM (color pickers, CodeMirror)
        initColorPickersInSection();
        initCodeEditorInSection(target);
    }

    // =========================================================================
    // Navigation Confirmation (unsaved changes intercept)
    // =========================================================================

    function discardSectionChanges(sectionId) {
        const sectionDef = (CS.sections || []).find(function (s) { return s.id === sectionId; });
        if (sectionDef && CS.saved) {
            sectionDef.fields.forEach(function (field) {
                if (field.id && Object.prototype.hasOwnProperty.call(CS.saved, field.id)) {
                    setFieldValue(field.id, CS.saved[field.id]);
                }
            });
        }
        clearDirtySection(sectionId);
        runRequiredEngine();
    }

    function showNavConfirm(targetSection) {
        const overlay = document.createElement('div');
        overlay.className = 'ct-nav-confirm-overlay';
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.setAttribute('aria-labelledby', 'ct-nav-confirm-title');
        overlay.innerHTML =
            '<div class="ct-nav-confirm-dialog">' +
                '<h3 id="ct-nav-confirm-title">Unsaved Changes</h3>' +
                '<p>This panel has unsaved changes. Save them before leaving, or discard to continue without saving.</p>' +
                '<div class="ct-nav-confirm-actions">' +
                    '<button type="button" class="ct-nav-confirm-cancel">Stay</button>' +
                    '<button type="button" class="ct-nav-confirm-discard">Discard &amp; Leave</button>' +
                    '<button type="button" class="ct-nav-confirm-save">Save &amp; Leave</button>' +
                '</div>' +
            '</div>';

        document.body.appendChild(overlay);
        overlay.querySelector('.ct-nav-confirm-save').focus();

        function close() {
            overlay.remove();
            document.removeEventListener('keydown', onKey);
        }

        function onKey(e) {
            if (e.key === 'Escape') close();
        }
        document.addEventListener('keydown', onKey);

        // Backdrop click = cancel
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) close();
        });

        overlay.querySelector('.ct-nav-confirm-cancel').addEventListener('click', close);

        overlay.querySelector('.ct-nav-confirm-discard').addEventListener('click', function () {
            discardSectionChanges(currentSection);
            close();
            navigateTo(targetSection);
        });

        overlay.querySelector('.ct-nav-confirm-save').addEventListener('click', function () {
            pendingNavigation = targetSection;
            close();
            saveSettings();
        });
    }

    function initNav() {
        // Nav link clicks — handle both parent (has-children) and leaf items
        document.querySelectorAll('.ct-nav-link').forEach(link => {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                const item    = this.closest('.ct-nav-item');
                const section = item.getAttribute('data-section');

                // Determine which parent (if any) should stay open after this click.
                const ownParent = item.closest('.ct-nav-submenu')?.closest('.ct-nav-item--has-children') || null;
                const keepOpen  = item.classList.contains('ct-nav-item--has-children') ? item : ownParent;

                // Collapse every open parent that isn't the one to keep
                document.querySelectorAll('.ct-nav-item--has-children.open').forEach(other => {
                    if (other !== keepOpen) other.classList.remove('open');
                });

                if ( item.classList.contains('ct-nav-item--has-children') ) {
                    const wasOpen = item.classList.contains('open');
                    item.classList.toggle('open', !wasOpen);
                } else if ( ownParent ) {
                    ownParent.classList.add('open');
                }

                // Intercept navigation when current panel has unsaved changes
                if (section !== currentSection && dirtySections.has(currentSection)) {
                    showNavConfirm(section);
                    return;
                }

                navigateTo(section);

                // Close mobile sidebar and hide overlay
                document.querySelector('.ct-settings-sidebar')?.classList.remove('open');
                const activeOverlay = document.querySelector('.ct-sidebar-overlay');
                if (activeOverlay) activeOverlay.style.display = 'none';
            });
        });

        // Hash-based back/forward — guard against losing changes
        window.addEventListener('hashchange', function () {
            const hash = window.location.hash.replace('#', '');
            if (!hash) return;

            if (hash !== currentSection && dirtySections.has(currentSection)) {
                // Snap hash back so the URL stays correct, then confirm
                history.replaceState(null, '', '#' + currentSection);
                showNavConfirm(hash);
                return;
            }

            navigateTo(hash);
        });

        // Group toggles (collapse entire group)
        document.querySelectorAll('.ct-nav-group__toggle').forEach(btn => {
            btn.addEventListener('click', function () {
                this.closest('.ct-nav-group').classList.toggle('collapsed');
            });
        });
    }

    /**
     * Mark the active nav item and handle active-parent state for parent items
     * whose child is currently active.
     */
    function setActiveNavItem(sectionId) {
        document.querySelectorAll('.ct-nav-item').forEach(el => {
            el.classList.remove('active', 'active-parent');
        });

        const activeItem = document.querySelector(`.ct-nav-item[data-section="${sectionId}"]`);
        if (!activeItem) return;

        activeItem.classList.add('active');

        // If this item itself is a parent with children, keep it open so its
        // submenu is visible on page load / refresh (e.g. hash = "blog-archive").
        if (activeItem.classList.contains('ct-nav-item--has-children')) {
            activeItem.classList.add('open');
        }

        // If inside a submenu, mark parent as active-parent and ensure it's open
        const parentItem = activeItem.closest('.ct-nav-submenu')?.closest('.ct-nav-item--has-children');
        if (parentItem) {
            parentItem.classList.add('active-parent', 'open');
        }
    }

    // =========================================================================
    // Required / Conditional Visibility Engine
    // =========================================================================
    function runRequiredEngine() {
        document.querySelectorAll('.ct-field-row[data-required]').forEach(row => {
            try {
                const required = JSON.parse(row.getAttribute('data-required'));
                const visible  = evaluateRequired(required);
                row.classList.toggle('ct-field-hidden', !visible);
            } catch (e) {
                // Malformed required — show field
            }
        });
    }

    function evaluateRequired(required) {
        if (!required) return true;

        // Single condition: ['field_id', '=', 'value']
        if (typeof required[0] === 'string') {
            return evaluateCondition(required[0], required[1], required[2]);
        }

        // Compound AND: [['field_id', 'op', 'val'], ...]
        if (Array.isArray(required[0])) {
            return required.every(condition => evaluateCondition(condition[0], condition[1], condition[2]));
        }

        return true;
    }

    function evaluateCondition(fieldId, op, expected) {
        const current = getFieldValue(fieldId);

        switch (op) {
            case '=':
            case 'equals':
                return String(current) === String(expected);
            case '!=':
            case 'not':
                return String(current) !== String(expected);
            case '>':
                return parseFloat(current) > parseFloat(expected);
            case '<':
                return parseFloat(current) < parseFloat(expected);
            case 'contains':
                return String(current).includes(String(expected));
            default:
                return String(current) === String(expected);
        }
    }

    function getFieldValue(fieldId) {
        // Look for any input with data-field-key matching
        const el = document.querySelector('[data-field-key="' + fieldId + '"]');
        if (!el) return '';

        const tag = el.tagName.toLowerCase();

        if (tag === 'input') {
            if (el.type === 'checkbox') return el.checked ? (el.value || 'yes') : 'no';
            return el.value || '';
        }
        if (tag === 'select')   return el.value || '';
        if (tag === 'textarea') return el.value || '';

        // Switch: find the checkbox inside
        if (el.classList.contains('ct-switch-wrap')) {
            const cb = el.querySelector('input[type="checkbox"]');
            return cb && cb.checked ? 'yes' : 'no';
        }

        // Try hidden field for image_select / color_rgba
        const hidden = el.querySelector('input[type="hidden"]');
        if (hidden) return hidden.value || '';

        return '';
    }

    function initRequiredEngine() {
        // Re-run engine whenever any field changes
        document.getElementById('ct-settings-content')?.addEventListener('change', runRequiredEngine);
        document.getElementById('ct-settings-content')?.addEventListener('input', debounce(runRequiredEngine, 150));
        runRequiredEngine();
    }

    // =========================================================================
    // Switch Label Updates
    // =========================================================================
    function initSwitchLabels() {
        document.getElementById('ct-settings-content')?.addEventListener('change', function (e) {
            const cb = e.target;
            if ( cb.type !== 'checkbox' ) return;
            const wrap = cb.closest('.ct-switch-wrap');
            if ( !wrap ) return;
            const label = wrap.querySelector('.ct-switch-label');
            if ( !label ) return;
            label.textContent = cb.checked
                ? ( label.dataset.on  || 'On'  )
                : ( label.dataset.off || 'Off' );
        });
    }

    // =========================================================================
    // Dirty Tracking
    // =========================================================================
    function initDirtyTracking() {
        const content = document.getElementById('ct-settings-content');
        if (!content) return;

        function onFieldChange(e) {
            if ( e.target.classList.contains('ct-onboarding-checkbox') ) return;
            markDirty();
        }

        content.addEventListener('change', onFieldChange);
        content.addEventListener('input', onFieldChange);

        // Warn on page leave
        window.addEventListener('beforeunload', function (e) {
            if (isDirty) {
                e.preventDefault();
                e.returnValue = '';
            }
        });
    }

    function markDirty() {
        // Always update the per-section dot, even when already globally dirty
        if (currentSection && !dirtySections.has(currentSection)) {
            dirtySections.add(currentSection);
            const navItem = document.querySelector('.ct-nav-item[data-section="' + currentSection + '"]');
            navItem?.querySelector('.ct-nav-dirty-dot')?.style.setProperty('display', 'inline-block');
        }

        if (isDirty) return;
        isDirty = true;
        document.getElementById('ct-unsaved-dot')?.classList.add('visible');

        // Save draft to localStorage
        saveDraftToStorage();
    }

    function clearDirtySection(sectionId) {
        dirtySections.delete(sectionId);

        // Hide just this section's nav dot
        const navItem = document.querySelector('.ct-nav-item[data-section="' + sectionId + '"]');
        navItem?.querySelector('.ct-nav-dirty-dot')?.style.setProperty('display', 'none');

        // Update global dirty state based on remaining dirty sections
        isDirty = dirtySections.size > 0;
        document.getElementById('ct-unsaved-dot')?.classList.toggle('visible', isDirty);

        if (!isDirty) localStorage.removeItem(draftKey);
    }

    function clearDirty() {
        isDirty = false;
        dirtySections.clear();
        document.getElementById('ct-unsaved-dot')?.classList.remove('visible');
        document.querySelectorAll('.ct-nav-dirty-dot').forEach(el => {
            el.style.display = 'none';
        });
        localStorage.removeItem(draftKey);
    }

    // =========================================================================
    // AJAX Save
    // =========================================================================
    function initSave() {
        document.getElementById('ct-save-btn')?.addEventListener('click', saveSettings);
    }

    function saveSettings() {
        const btn = document.getElementById('ct-save-btn');
        if (!btn) return;

        btn.classList.add('loading');
        btn.textContent = CS.strings.saving;

        // Flush all CodeMirror instances so their textareas have the latest values
        document.querySelectorAll('.ct-ace-editor').forEach(ta => {
            ta._ctCodeEditor?.codemirror?.save();
        });

        const formData = collectFormData();
        const jsonPayload = JSON.stringify(formData);

        $.ajax({
            url: CS.ajaxUrl,
            type: 'POST',
            data: {
                action:   'ct_settings_save',
                nonce:    nonce,
                opt_name: CS.optName,
                data:     jsonPayload,
            },
            success: function (response) {
                btn.classList.remove('loading');
                btn.textContent = CS.strings.saved.replace('…', '') || 'Save Changes';

                // Restore button text after a moment
                setTimeout(() => {
                    btn.textContent = 'Save Changes';
                }, 2000);

                if (response.success) {
                    nonce = response.data.nonce; // Refresh nonce
                    clearDirty();
                    showSnackbar(CS.strings.saved, 'success');

                    // Navigate to pending section if save was triggered by nav confirm
                    if (pendingNavigation) {
                        const target = pendingNavigation;
                        pendingNavigation = null;
                        navigateTo(target);
                    }

                    // Show field-level errors if any
                    const errors = response.data.errors || {};
                    Object.entries(errors).forEach(([fieldId, msg]) => {
                        markFieldError(fieldId, msg);
                    });
                } else {
                    showSnackbar(response.data?.message || CS.strings.error, 'error');
                }
            },
            error: function (xhr, status, err) {
                btn.classList.remove('loading');
                btn.textContent = 'Save Changes';
                showSnackbar(CS.strings.error, 'error');
            },
        });
    }

    function collectFormData() {
        const data = {};
        const content = document.getElementById('ct-settings-content');
        if (!content) return data;

        // Serialize directly from the live DOM so current user-input .value properties
        // are captured. $(content).clone() copies the initial HTML attribute values only —
        // any user changes would be lost, causing update_option() to see no difference.
        const serialized = $(content).find(':input').serializeArray();

        serialized.forEach(item => {
            // Strip the ct_settings_fields[] wrapper
            const match = item.name.match(/^ct_settings_fields\[([^\]]+)\](.*)$/);
            if (!match) return;

            const key     = match[1];
            const subpath = match[2]; // e.g. [color] or [enabled][city]

            if (!subpath) {
                data[key] = item.value;
            } else {
                // Deep key e.g. [color] → key = 'ct_header_bg', sub = 'color'
                if (!data[key] || typeof data[key] !== 'object') {
                    data[key] = {};
                }
                // Parse sub-path segments
                const segs = subpath.match(/\[([^\]]*)\]/g)?.map(s => s.slice(1, -1)) || [];
                setNestedValue(data[key], segs, item.value);
            }
        });

        return data;
    }

    function setNestedValue(obj, segments, value) {
        if (segments.length === 0) return;
        const key = segments[0];
        if (segments.length === 1) {
            obj[key] = value;
        } else {
            if (!obj[key] || typeof obj[key] !== 'object') {
                obj[key] = {};
            }
            setNestedValue(obj[key], segments.slice(1), value);
        }
    }

    function markFieldError(fieldId, message) {
        const row = document.querySelector('.ct-field-row[data-field-id="' + fieldId + '"]');
        if (!row) return;

        let errEl = row.querySelector('.ct-field-error');
        if (!errEl) {
            errEl = document.createElement('p');
            errEl.className = 'ct-field-error';
            errEl.style.cssText = 'color:#b42318;font-size:12px;margin:4px 0 0;';
            row.querySelector('.ct-field-input')?.appendChild(errEl);
        }
        errEl.textContent = message;
    }

    // =========================================================================
    // Keyboard Shortcut — Cmd/Ctrl+S
    // =========================================================================
    function initKeyboardShortcut() {
        document.addEventListener('keydown', function (e) {
            if ((e.metaKey || e.ctrlKey) && e.key === 's') {
                e.preventDefault();
                saveSettings();
            }
        });
    }

    // =========================================================================
    // localStorage Draft Recovery
    // =========================================================================
    function saveDraftToStorage() {
        try {
            const data = collectFormData();
            localStorage.setItem(draftKey, JSON.stringify({ ts: Date.now(), data }));
        } catch (e) { /* storage full or unavailable */ }
    }

    function initDraftRecovery() {
        try {
            const stored = localStorage.getItem(draftKey);
            if (!stored) return;

            const parsed = JSON.parse(stored);
            if (!parsed || !parsed.data) return;

            draftData = parsed.data;

            const banner = document.getElementById('ct-draft-banner');
            if (!banner) return;

            const textEl = banner.querySelector('.ct-draft-banner__text');
            if (textEl) textEl.textContent = CS.strings.restore_draft;

            const restoreBtn = document.getElementById('ct-draft-restore');
            const dismissBtn = document.getElementById('ct-draft-dismiss');

            if (restoreBtn) {
                restoreBtn.textContent = CS.strings.restore_yes;
                restoreBtn.addEventListener('click', function () {
                    applyDraft(draftData);
                    banner.style.display = 'none';
                    markDirty();
                });
            }

            if (dismissBtn) {
                dismissBtn.textContent = CS.strings.restore_dismiss;
                dismissBtn.addEventListener('click', function () {
                    banner.style.display = 'none';
                    localStorage.removeItem(draftKey);
                });
            }

            banner.style.display = 'flex';
        } catch (e) { /* ignore */ }
    }

    function applyDraft(data) {
        Object.entries(data).forEach(([key, value]) => {
            setFieldValue(key, value);
        });
        runRequiredEngine();
    }

    function setFieldValue(key, value) {
        const jsonField = document.querySelector('input[data-json-field][data-field-key="' + key + '"]');
        if (jsonField) {
            jsonField.value = typeof value === 'string' ? value : JSON.stringify(value);
            jsonField.dispatchEvent(new Event('ct-settings-restore'));
            return;
        }
        // For simple string values
        if (typeof value === 'number' || typeof value === 'boolean') value = String(value);
        if (typeof value === 'string') {
            const el = document.querySelector('[data-field-key="' + key + '"]');
            if (!el) return;
            if (el.tagName === 'INPUT' && el.type !== 'checkbox') el.value = value;
            if (el.tagName === 'SELECT') el.value = value;
            if (el.tagName === 'TEXTAREA') el.value = value;
            if (el.tagName === 'INPUT' && el.type === 'checkbox') el.checked = (value === 'yes' || value === '1');
        }
        // For object values — set hidden sub-fields
        if (typeof value === 'object' && value !== null) {
            Object.entries(value).forEach(([subKey, subVal]) => {
                const input = document.querySelector('input[name="ct_settings_fields[' + key + '][' + subKey + ']"]');
                if (input) input.value = subVal;
            });
        }
    }

    // =========================================================================
    // Color Pickers (WP Iris)
    // =========================================================================
    function initColorPickers() {
        // Color pickers are now initialized per-section inside navigateTo()
        // Run once for the initial section shown on page load
        initColorPickersInSection();
    }

    function initColorPickersInSection() {
        if (!$.fn.wpColorPicker) return;
        const visible = document.querySelector('.ct-settings-section[style*="block"]');
        if (!visible) return;

        // Exclude .ct-rgba-hex-input — those are initialized lazily inside initRGBAPickers()
        // with the correct updateRGBAFromPicker callback. Initializing them here would attach
        // the wrong callback and cause WP's synthetic document click to close the RGBA popout.
        $(visible).find('.ct-color-picker:not(.ct-rgba-hex-input):not(.wp-color-picker-initialized)').each(function () {
            const pickerEl = this;
            $(this).wpColorPicker({
                change: function () {
                    // Ignore the synthetic change fired during wpColorPicker() init
                    if (!$(pickerEl).hasClass('wp-color-picker-initialized')) return;
                    markDirty();
                    runRequiredEngine();
                    updateTypographyPreview($(this).closest('.ct-typography-wrap'));
                    updateBgPreview($(this).closest('.ct-bg-wrap')[0]);
                },
                clear: function () {
                    // Close the picker so the still-open Iris UI cannot restore the
                    // old color by firing _change when the user touches a slider.
                    // Guard with .wp-picker-open so we never accidentally re-open
                    // a picker that was already closed via another code path.
                    const $toggler = $(pickerEl).closest('.wp-picker-container').find('.wp-color-result');
                    if ($toggler.hasClass('wp-picker-open')) {
                        $(pickerEl).wpColorPicker('close');
                    }
                    // Force the input to empty — defensive in case close() triggered
                    // any synchronous Iris writeback (e.g. future WP versions).
                    $(pickerEl).val('');
                    markDirty();
                    runRequiredEngine();
                    updateTypographyPreview($(pickerEl).closest('.ct-typography-wrap'));
                    updateBgPreview($(pickerEl).closest('.ct-bg-wrap')[0]);
                },
            });
            $(this).addClass('wp-color-picker-initialized');
        });
    }

    // =========================================================================
    // RGBA Color Pickers
    // =========================================================================
    function initRGBAPickers() {
        document.querySelectorAll('.ct-rgba-swatch').forEach(swatch => {
            swatch.addEventListener('click', function (e) {
                // Prevent the click from bubbling to the document close handler,
                // which would immediately re-close a freshly opened popout.
                e.stopPropagation();

                const wrap   = this.closest('.ct-rgba-wrap');
                const popout = this.nextElementSibling;
                if (!popout) return;
                const isOpen = popout.style.display !== 'none';

                // Close all OTHER open popouts
                document.querySelectorAll('.ct-rgba-picker-popout').forEach(p => {
                    if (p !== popout) p.style.display = 'none';
                });
                popout.style.display = isOpen ? 'none' : 'block';

                // Lazily init WP color picker with the correct RGBA callback.
                // Use requestAnimationFrame so WP's own synthetic document-click
                // (fired during wpColorPicker() init to close other pickers) fires
                // BEFORE the popout is visible — avoiding a false close.
                if (!isOpen) {
                    const hexInput = popout.querySelector('.ct-rgba-hex-input');
                    if (hexInput && !hexInput.classList.contains('wp-color-picker-initialized')) {
                        hexInput.classList.add('wp-color-picker-initialized'); // mark first
                        $(hexInput).wpColorPicker({
                            change: function (event, ui) {
                                updateRGBAFromPicker($(this).closest('.ct-rgba-wrap'));
                            },
                            clear: function () {
                                // Force the hex input to stay empty, then sync the three
                                // hidden sub-fields and the swatch via the normal helper.
                                $(hexInput).val('');
                                updateRGBAFromPicker($(hexInput).closest('.ct-rgba-wrap'));
                            },
                        });
                    }
                }
            });
        });

        // Alpha slider changes
        document.addEventListener('input', function (e) {
            if (e.target.classList.contains('ct-rgba-alpha-slider')) {
                const wrap = e.target.closest('.ct-rgba-wrap');
                if (wrap) {
                    wrap.querySelector('.ct-rgba-alpha-number').value = e.target.value;
                    updateRGBAFromPicker($(wrap));
                }
            }
            if (e.target.classList.contains('ct-rgba-alpha-number')) {
                const wrap = e.target.closest('.ct-rgba-wrap');
                if (wrap) {
                    wrap.querySelector('.ct-rgba-alpha-slider').value = e.target.value;
                    updateRGBAFromPicker($(wrap));
                }
            }

            // Hex typed directly into the input field
            if (e.target.classList.contains('ct-rgba-hex-input')) {
                const input = e.target;
                let raw = input.value.trim();

                // Strip any character that isn't # or a hex digit
                raw = raw.replace(/[^#0-9a-fA-F]/g, '');

                // Auto-prepend # if missing
                if (raw !== '' && raw.charAt(0) !== '#') raw = '#' + raw;

                // Enforce max length (#rrggbb = 7 chars)
                if (raw.length > 7) raw = raw.slice(0, 7);

                // Write back only if it changed (avoid cursor jump)
                if (input.value !== raw) {
                    const pos = input.selectionStart;
                    input.value = raw;
                    try { input.setSelectionRange(pos, pos); } catch(err) {}
                }

                // Sync swatch when we have a full valid hex
                if (/^#[0-9a-fA-F]{6}$/.test(raw)) {
                    const wrap = input.closest('.ct-rgba-wrap');
                    if (wrap) {
                        // Update Iris picker if initialized so the visual square reflects the typed hex
                        const $input = $(input);
                        if ($input.hasClass('wp-color-picker-initialized')) {
                            try { $input.wpColorPicker('color', raw); } catch(err) {}
                        }
                        updateRGBAFromPicker($(wrap));
                    }
                }
            }
        });

        // Close popouts when the user presses down outside the wrap.
        // We use 'mousedown' rather than 'click' because WP's iris picker binds
        // a jQuery $(document).on('click') handler that can call
        // stopImmediatePropagation — jQuery's dispatcher is registered on document
        // before our native listener, so it can silently swallow the event before
        // we see it. 'mousedown' fires before jQuery's 'click' pipeline entirely,
        // so it is not affected by iris's stopImmediatePropagation.
        // WP does not fire synthetic 'mousedown' events, so the isTrusted guard
        // is still a safe no-op here.
        document.addEventListener('mousedown', function (e) {
            if (!e.isTrusted) return;
            if (!e.target.closest('.ct-rgba-wrap')) {
                document.querySelectorAll('.ct-rgba-picker-popout').forEach(p => p.style.display = 'none');
            }
        });
    }

    /**
     * Returns '#ffffff' or '#1e2939' — whichever gives readable contrast
     * against the given hex colour at the given opacity.
     */
    function contrastColor(hex, alpha) {
        alpha = parseFloat(alpha) || 1;
        if (alpha < 0.4) return '#1e2939';
        const m = hex.match(/^#([0-9a-f]{6})$/i);
        if (!m) return '#1e2939';
        const r = parseInt(m[1].substring(0, 2), 16);
        const g = parseInt(m[1].substring(2, 4), 16);
        const b = parseInt(m[1].substring(4, 6), 16);
        // Perceived brightness (ITU-R BT.601)
        const brightness = (r * 299 + g * 587 + b * 114) / 1000;
        return brightness > 128 ? '#1e2939' : '#ffffff';
    }

    function updateRGBAFromPicker($wrap) {
        const hexInput   = $wrap.find('.ct-rgba-hex-input');
        const alphaInput = $wrap.find('.ct-rgba-alpha-slider');
        const hex        = hexInput.val() || '';
        const alpha      = parseFloat(alphaInput.val()) || 1;

        // Convert hex to rgba
        let rgba = hex;
        const match = hex.match(/^#([0-9a-f]{6})$/i);
        if (match) {
            const r = parseInt(match[1].substring(0, 2), 16);
            const g = parseInt(match[1].substring(2, 4), 16);
            const b = parseInt(match[1].substring(4, 6), 16);
            rgba = 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
        }

        $wrap.find('.ct-rgba-color').val(hex);
        $wrap.find('.ct-rgba-alpha').val(alpha);
        $wrap.find('.ct-rgba-rgba').val(rgba);

        const swatch = $wrap.find('.ct-rgba-swatch')[0];
        if (hex) {
            swatch.classList.remove('ct-rgba-swatch--empty');
            $wrap.find('.ct-rgba-hex-display').text(hex);
            $(swatch).css({ 'background': rgba || hex, 'color': contrastColor(hex, alpha) });
        } else {
            swatch.classList.add('ct-rgba-swatch--empty');
            $wrap.find('.ct-rgba-hex-display').text('');
            $(swatch).css({ 'background': '', 'color': '' });
        }

        markDirty();
        runRequiredEngine();
    }

    // =========================================================================
    // Media Uploader
    // =========================================================================
    function initMediaUploader() {
        document.addEventListener('click', function (e) {
            if (e.target.classList.contains('ct-media-upload-btn')) {
                e.preventDefault();
                const wrap    = e.target.closest('.ct-media-wrap');
                const allowed = e.target.getAttribute('data-allowed') || 'all';
                const frame   = wp.media({
                    title:    'Select Image',
                    multiple: false,
                    library:  { type: allowed === 'image' ? 'image' : undefined },
                    button:   { text: 'Select' },
                });
                frame.on('select', function () {
                    const attachment = frame.state().get('selection').first().toJSON();
                    fillMediaWrap(wrap, attachment);
                    markDirty();
                });
                frame.open();
            }

            if (e.target.classList.contains('ct-media-remove-btn')) {
                e.preventDefault();
                const wrap = e.target.closest('.ct-media-wrap');
                fillMediaWrap(wrap, null);
                markDirty();
            }
        });
    }

    function fillMediaWrap(wrap, attachment) {
        if (!wrap) return;
        const url    = attachment ? (attachment.url || '') : '';
        const id     = attachment ? (attachment.id || 0)  : 0;
        const width  = attachment ? (attachment.width || '') : '';
        const height = attachment ? (attachment.height || '') : '';
        const thumb  = attachment ? (attachment.sizes?.thumbnail?.url || url) : '';

        const get = (cls) => wrap.querySelector('.' + cls);

        if (get('ct-media-url'))    get('ct-media-url').value    = url;
        if (get('ct-media-id'))     get('ct-media-id').value     = id;
        if (get('ct-media-width'))  get('ct-media-width').value  = width;
        if (get('ct-media-height')) get('ct-media-height').value = height;
        if (get('ct-media-thumb'))  get('ct-media-thumb').value  = thumb;

        // Update bg image input if this is inside a bg wrap
        const bgUrl = wrap.querySelector('.ct-bg-image-url');
        if (bgUrl) bgUrl.value = url;

        // Refresh the background preview strip
        const bgWrapEl = wrap.closest('.ct-bg-wrap');
        if (bgWrapEl) updateBgPreview(bgWrapEl);

        const preview = wrap.querySelector('.ct-media-preview');
        if (preview) {
            if (url) {
                let img = preview.querySelector('.ct-media-preview-img');
                if (!img) {
                    img = document.createElement('img');
                    img.className = 'ct-media-preview-img';
                    img.alt = '';
                    preview.appendChild(img);
                }
                img.src = thumb || url;
            } else {
                preview.innerHTML = '';
            }
        }

        const removeBtn = wrap.querySelector('.ct-media-remove-btn');
        if (removeBtn) removeBtn.style.display = url ? 'inline-block' : 'none';

        const urlDisplay = wrap.querySelector('.ct-media-url-display');
        if (urlDisplay) urlDisplay.textContent = url || '';
    }

    // =========================================================================
    // Background Field — live preview
    // =========================================================================
    const BG_BADGE_LABELS = {
        repeat:     { 'no-repeat': 'No Repeat', 'repeat': 'Repeat', 'repeat-x': 'Repeat X', 'repeat-y': 'Repeat Y' },
        size:       { 'auto': 'Auto', 'cover': 'Cover', 'contain': 'Contain', '100%': '100%' },
        position:   {
            'center center': 'Center Center', 'center top': 'Center Top',    'center bottom': 'Center Bottom',
            'left top':      'Left Top',      'left center': 'Left Center',  'left bottom':   'Left Bottom',
            'right top':     'Right Top',     'right center': 'Right Center', 'right bottom':  'Right Bottom',
        },
        attachment: { 'scroll': 'Scroll', 'fixed': 'Fixed', 'local': 'Local' },
    };

    function updateBgPreview(bgWrap) {
        if (!bgWrap) return;
        const preview = bgWrap.querySelector('.ct-bg-preview');
        if (!preview) return;

        const rawColor   = bgWrap.querySelector('input[name*="[background-color]"]')?.value       || '';
        const color      = rawColor === '#' ? '' : rawColor;
        const image      = bgWrap.querySelector('.ct-bg-image-url')?.value                        || '';
        const repeat     = bgWrap.querySelector('select[name*="[background-repeat]"]')?.value     || '';
        const position   = bgWrap.querySelector('select[name*="[background-position]"]')?.value  || '';
        const size       = bgWrap.querySelector('select[name*="[background-size]"]')?.value       || '';
        const attachment = bgWrap.querySelector('select[name*="[background-attachment]"]')?.value || '';

        preview.style.backgroundColor    = color || '';
        preview.style.backgroundImage    = image ? 'url(' + image + ')' : '';
        preview.style.backgroundSize     = image ? (size     || 'cover')         : '';
        preview.style.backgroundPosition = image ? (position || 'center center') : '';
        preview.style.backgroundRepeat   = image ? (repeat   || '')              : '';

        // Show/hide the "Preview" placeholder label
        preview.classList.toggle('ct-bg-active', !!(color || image));

        // Refresh property badges
        const badgesEl = preview.querySelector('.ct-bg-badges');
        if (badgesEl) {
            const pills = [
                BG_BADGE_LABELS.repeat[repeat],
                BG_BADGE_LABELS.size[size],
                BG_BADGE_LABELS.position[position],
                BG_BADGE_LABELS.attachment[attachment],
            ].filter(Boolean);
            badgesEl.innerHTML = pills.map(p => '<span class="ct-bg-badge">' + p + '</span>').join('');
        }
    }

    function initBgPreview() {
        // Catch select-field changes inside any background wrap
        document.addEventListener('change', function (e) {
            const bgWrap = e.target.closest?.('.ct-bg-wrap');
            if (bgWrap) updateBgPreview(bgWrap);
        });
    }

    // =========================================================================
    // Sorter (jQuery UI Sortable)
    // =========================================================================
    function initSorter() {
        if (!$.fn.sortable) return;

        document.querySelectorAll('.ct-sorter-wrap').forEach(wrap => {
            const $enabled  = $(wrap).find('.ct-sorter-enabled');
            const $disabled = $(wrap).find('.ct-sorter-disabled');

            [$enabled, $disabled].forEach($list => {
                $list.sortable({
                    connectWith: '.ct-sorter-list',
                    placeholder: 'ct-sorter-placeholder',
                    tolerance:   'pointer',
                    update: function () {
                        updateSorterHiddenInputs(wrap);
                        markDirty();
                    },
                }).disableSelection();
            });
        });
    }

    function updateSorterHiddenInputs(wrap) {
        // Rebuild hidden inputs based on current DOM order
        const fieldId   = wrap.getAttribute('data-field-key') ||
                          wrap.closest('.ct-field-row')?.getAttribute('data-field-id');
        const prefix    = 'ct_settings_fields[' + fieldId + ']';

        ['enabled', 'disabled'].forEach(bucket => {
            const list = wrap.querySelector('.ct-sorter-' + bucket);
            if (!list) return;

            // Remove old inputs (except placebo)
            list.querySelectorAll('li.ct-sorter-item input[type="hidden"]').forEach(el => el.remove());

            // Re-add in current order
            list.querySelectorAll('li.ct-sorter-item').forEach(item => {
                const key   = item.getAttribute('data-key');
                const label = item.querySelector('.ct-sorter-label')?.textContent || key;
                const input = document.createElement('input');
                input.type  = 'hidden';
                input.name  = prefix + '[' + bucket + '][' + key + ']';
                input.value = label;
                item.appendChild(input);
            });
        });
    }

    // =========================================================================
    // CodeMirror (for ace_editor fields)
    // =========================================================================
    function initCodeEditor() {
        // CodeMirror requires visible DOM — initialized per-section in navigateTo()
        // Run once for the initial visible section
        const visible = document.querySelector('.ct-settings-section[style*="block"]');
        initCodeEditorInSection(visible);
    }

    function initCodeEditorInSection(section) {
        if (!section) return;
        if (typeof wp === 'undefined' || !wp.codeEditor) return;

        section.querySelectorAll('.ct-ace-editor:not(.ct-codemirror-initialized)').forEach(textarea => {
            const mode = textarea.getAttribute('data-codemirror-mode') || 'text/css';

            try {
                const editor = wp.codeEditor.initialize(textarea, {
                    codemirror: {
                        mode,
                        lineNumbers:  true,
                        lineWrapping: true,
                        indentUnit:   4,
                        tabSize:      4,
                        theme:        'default',
                    },
                });

                // Store editor on the element so the save flush can reach it
                textarea._ctCodeEditor = editor;

                // Sync back to textarea on change so serialization picks it up
                editor.codemirror.on('change', function () {
                    editor.codemirror.save();
                    markDirty();
                });

                textarea.classList.add('ct-codemirror-initialized');
            } catch (e) {
                // Fallback: just use the textarea as-is
            }
        });
    }

    // =========================================================================
    // Image Select
    // =========================================================================
    function initImageSelect() {
        document.addEventListener('click', function (e) {
            const item = e.target.closest('.ct-image-select-item');
            if (!item) return;

            const wrap  = item.closest('.ct-image-select-wrap');
            const value = item.getAttribute('data-value');

            wrap.querySelectorAll('.ct-image-select-item').forEach(el => {
                el.classList.remove('ct-image-select-item--selected');
            });
            item.classList.add('ct-image-select-item--selected');

            const hidden = wrap.querySelector('input[type="hidden"]');
            if (hidden) {
                hidden.value = value;
            }

            markDirty();
            runRequiredEngine();
        });
    }

    // =========================================================================
    // Combobox — searchable replacement for large selects (> 8 options)
    // =========================================================================
    // =========================================================================
    // Page Picker
    // =========================================================================
    function initPagePicker() {
        document.querySelectorAll('.ct-page-picker').forEach(function (wrap) {
            if (wrap.dataset.ppInit) return;
            wrap.dataset.ppInit = '1';

            const hiddenInput = wrap.querySelector('input[type="hidden"]');
            const searchInput = wrap.querySelector('.ct-pp-search');
            const resultsList = wrap.querySelector('.ct-pp-results');
            const chipsList   = wrap.querySelector('.ct-pp-chips');

            let allPages = [];
            try { allPages = JSON.parse(wrap.dataset.pages || '[]'); } catch (e) {}

            function getSelected() {
                try { return JSON.parse(hiddenInput.value || '[]'); } catch (e) { return []; }
            }

            function setSelected(ids) {
                hiddenInput.value = JSON.stringify(ids);
                hiddenInput.dispatchEvent(new Event('change', { bubbles: true }));
            }

            function escHtml(str) {
                return str
                    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
            }

            function renderChips(ids) {
                chipsList.innerHTML = '';
                ids.forEach(function (id) {
                    const page = allPages.find(function (p) { return p.id === id; });
                    if (!page) return;
                    const li = document.createElement('li');
                    li.className = 'ct-pp-chip';
                    li.dataset.id = String(id);
                    li.innerHTML = '<span>' + escHtml(page.title) + '</span>'
                        + '<button type="button" class="ct-pp-chip-remove" aria-label="Remove">&times;</button>';
                    chipsList.appendChild(li);
                });
            }

            let activeIndex = -1;

            function getItems() {
                return Array.from(resultsList.querySelectorAll('li[data-id]'));
            }

            function setActiveIndex(idx) {
                const items = getItems();
                items.forEach(function (li) { li.classList.remove('ct-pp-result--active'); });
                activeIndex = Math.max(-1, Math.min(idx, items.length - 1));
                if (activeIndex >= 0) {
                    items[activeIndex].classList.add('ct-pp-result--active');
                    items[activeIndex].scrollIntoView({ block: 'nearest' });
                }
            }

            function selectItem(li) {
                const id       = parseInt(li.dataset.id, 10);
                const selected = getSelected();
                if (!selected.includes(id)) { selected.push(id); setSelected(selected); renderChips(selected); }
                searchInput.value  = '';
                resultsList.hidden = true;
                activeIndex        = -1;
                markDirty();
            }

            function showResults(query) {
                const q        = query.trim().toLowerCase();
                const selected = getSelected();
                const matches  = allPages.filter(function (p) {
                    return p.title.toLowerCase().includes(q) && !selected.includes(p.id);
                });

                resultsList.innerHTML = '';
                activeIndex = -1;
                if (!q || !matches.length) { resultsList.hidden = true; return; }

                matches.slice(0, 12).forEach(function (page) {
                    const li = document.createElement('li');
                    li.dataset.id  = String(page.id);
                    li.textContent = page.title;
                    li.setAttribute('role', 'option');
                    resultsList.appendChild(li);
                });
                resultsList.hidden = false;
            }

            searchInput.addEventListener('input', function () { showResults(this.value); });

            searchInput.addEventListener('keydown', function (e) {
                const items = getItems();

                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    if (resultsList.hidden) { showResults(searchInput.value); }
                    setActiveIndex(activeIndex + 1);
                    return;
                }
                if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    setActiveIndex(activeIndex - 1);
                    return;
                }
                if (e.key === 'Enter') {
                    e.preventDefault();
                    if (!resultsList.hidden && activeIndex >= 0 && items[activeIndex]) {
                        selectItem(items[activeIndex]);
                    }
                    return;
                }
                if (e.key === 'Escape') {
                    resultsList.hidden = true;
                    activeIndex        = -1;
                    this.value         = '';
                }
            });

            resultsList.addEventListener('mousedown', function (e) {
                const li = e.target.closest('li[data-id]');
                if (!li) return;
                e.preventDefault();
                selectItem(li);
            });

            chipsList.addEventListener('click', function (e) {
                const btn = e.target.closest('.ct-pp-chip-remove');
                if (!btn) return;
                const chip     = btn.closest('.ct-pp-chip');
                if (!chip) return;
                const id       = parseInt(chip.dataset.id, 10);
                const selected = getSelected().filter(function (i) { return i !== id; });
                setSelected(selected);
                renderChips(selected);
                markDirty();
            });

            document.addEventListener('click', function (e) {
                if (!wrap.contains(e.target)) { resultsList.hidden = true; }
            });
        });
    }

    function initCombobox() {
        document.querySelectorAll('select.ct-field-select').forEach(function (select) {
            if (select.options.length <= 8) return;
            if (select.dataset.comboboxInit) return; // idempotent
            select.dataset.comboboxInit = '1';
            buildCombobox(select);
        });
    }

    function buildCombobox(select) {
        const getLabel = () => {
            const opt = select.options[select.selectedIndex];
            return opt ? opt.text : '';
        };

        // Wrapper
        const wrap = document.createElement('div');
        wrap.className = 'ct-combobox';
        wrap.setAttribute('role', 'combobox');
        wrap.setAttribute('aria-expanded', 'false');

        // Trigger row: search input + chevron
        const trigger = document.createElement('div');
        trigger.className = 'ct-combobox-trigger';

        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'ct-combobox-search';
        input.autocomplete = 'off';
        input.spellcheck = false;
        input.setAttribute('aria-autocomplete', 'list');
        input.value = getLabel();

        const chevron = document.createElement('span');
        chevron.className = 'ct-combobox-chevron';
        chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

        trigger.appendChild(input);
        trigger.appendChild(chevron);

        // Dropdown
        const dropdown = document.createElement('div');
        dropdown.className = 'ct-combobox-dropdown';
        dropdown.hidden = true;

        const list = document.createElement('ul');
        list.className = 'ct-combobox-list';
        list.setAttribute('role', 'listbox');
        dropdown.appendChild(list);

        wrap.appendChild(trigger);
        wrap.appendChild(dropdown);

        // Insert wrap after the hidden select
        select.style.display = 'none';
        select.parentNode.insertBefore(wrap, select.nextSibling);

        // ---- helpers ----

        function buildOptions(filter) {
            list.innerHTML = '';
            const q = (filter || '').toLowerCase();
            let count = 0;

            Array.from(select.options).forEach(function (opt) {
                if (q && !opt.text.toLowerCase().includes(q)) return;

                const li = document.createElement('li');
                li.className = 'ct-combobox-option' +
                    (opt.value === select.value ? ' ct-combobox-option--selected' : '');
                li.setAttribute('role', 'option');
                li.setAttribute('data-value', opt.value);
                li.setAttribute('aria-selected', String(opt.value === select.value));
                li.textContent = opt.text;

                // mousedown keeps focus on input while allowing selection
                li.addEventListener('mousedown', function (e) {
                    e.preventDefault();
                    choose(opt.value, opt.text);
                });

                list.appendChild(li);
                count++;
            });

            if (count === 0) {
                const li = document.createElement('li');
                li.className = 'ct-combobox-no-results';
                li.textContent = 'No results';
                list.appendChild(li);
            }
        }

        function choose(value, label) {
            select.value = value;
            input.value  = label;
            close();
            markDirty();
            runRequiredEngine();
            select.dispatchEvent(new Event('change', { bubbles: true }));
        }

        function open() {
            buildOptions('');
            dropdown.hidden = false;
            wrap.setAttribute('aria-expanded', 'true');
            wrap.classList.add('ct-combobox--open');
            input.select();
            const sel = list.querySelector('.ct-combobox-option--selected');
            if (sel) sel.scrollIntoView({ block: 'nearest' });
        }

        function close() {
            dropdown.hidden = true;
            wrap.setAttribute('aria-expanded', 'false');
            wrap.classList.remove('ct-combobox--open');
            // Restore display label if search text doesn't match any option
            const match = Array.from(select.options).find(o => o.text === input.value);
            if (!match) input.value = getLabel();
        }

        function moveHighlight(dir) {
            const items = Array.from(list.querySelectorAll('.ct-combobox-option'));
            if (!items.length) return;
            const cur = list.querySelector('.ct-combobox-option--selected');
            let idx   = items.indexOf(cur);
            items.forEach(i => i.classList.remove('ct-combobox-option--selected'));
            idx = ((idx + dir) + items.length) % items.length;
            items[idx].classList.add('ct-combobox-option--selected');
            items[idx].scrollIntoView({ block: 'nearest' });
        }

        // ---- events ----

        // Clicking anywhere on the trigger (chevron, padding, etc.) opens the dropdown
        trigger.addEventListener('mousedown', function (e) {
            if (e.target === input) return; // let input's own focus/click handle it
            e.preventDefault(); // prevent blur on any currently focused element
            input.focus();
            if (dropdown.hidden) open(); else close();
        });

        input.addEventListener('focus', open);

        input.addEventListener('input', function () {
            dropdown.hidden = false;
            buildOptions(input.value);
        });

        input.addEventListener('keydown', function (e) {
            if (e.key === 'Escape')      { close(); input.blur(); }
            else if (e.key === 'ArrowDown') { e.preventDefault(); moveHighlight(1); }
            else if (e.key === 'ArrowUp')   { e.preventDefault(); moveHighlight(-1); }
            else if (e.key === 'Enter') {
                e.preventDefault();
                const hl = list.querySelector('.ct-combobox-option--selected');
                if (hl) choose(hl.getAttribute('data-value'), hl.textContent);
            }
        });

        // Delay close so mousedown on option fires first
        input.addEventListener('blur', function () {
            setTimeout(close, 160);
        });
    }

    // =========================================================================
    // Slider sync
    // =========================================================================
    function initSliders() {
        document.addEventListener('input', function (e) {
            if (e.target.classList.contains('ct-field-slider')) {
                const wrap = e.target.closest('.ct-slider-wrap');
                if (wrap) {
                    const num = wrap.querySelector('.ct-slider-number');
                    if (num) num.value = e.target.value;
                }
            }
            if (e.target.classList.contains('ct-slider-number')) {
                const wrap = e.target.closest('.ct-slider-wrap');
                if (wrap) {
                    const slider = wrap.querySelector('.ct-field-slider');
                    if (slider) slider.value = e.target.value;
                }
            }
        });
    }

    // =========================================================================
    // Typography live preview
    // =========================================================================
    function initTypographyPreview() {
        document.addEventListener('change', function (e) {
            const wrap = e.target.closest('.ct-typography-wrap');
            if (wrap) updateTypographyPreview($(wrap));
        });
        document.addEventListener('input', function (e) {
            const wrap = e.target.closest('.ct-typography-wrap');
            if (wrap) updateTypographyPreview($(wrap));
        });
    }

    function updateTypographyPreview($wrap) {
        const preview = $wrap.find('.ct-typography-preview')[0];
        if (!preview) return;

        const family      = $wrap.find('[name*="[font-family]"]').val();
        const size        = $wrap.find('[name*="[font-size]"]').val();
        const weight      = $wrap.find('[name*="[font-weight]"]').val();
        const lineHeight  = $wrap.find('[name*="[line-height]"]').val();
        const color       = $wrap.find('[name*="[color]"]').val();
        const fontStyle   = $wrap.find('[name*="[font-style]"]').val();

        if (family)     preview.style.fontFamily   = family;
        if (size)       preview.style.fontSize      = size;
        if (weight)     preview.style.fontWeight    = weight;
        if (lineHeight) preview.style.lineHeight    = lineHeight;
        if (color)      preview.style.color         = color;
        if (fontStyle)  preview.style.fontStyle     = fontStyle;
    }

    // =========================================================================
    // Search — Index + Full-Panel Results View
    // =========================================================================

    /**
     * Build a flat index of every searchable field row across all sections.
     * Called once during init so the DOM is fully rendered.
     * Each entry: { sectionId, sectionTitle, label, desc, rowEl }
     */
    function buildSearchIndex() {
        searchIndex = [];
        document.querySelectorAll('.ct-settings-section').forEach(sectionEl => {
            const sectionId    = sectionEl.getAttribute('data-section');
            const sectionTitle = sectionEl.querySelector('.ct-section-title')?.textContent.trim() || sectionId;

            sectionEl.querySelectorAll('.ct-field-row').forEach(row => {
                if (row.classList.contains('ct-field-row--full')) return; // skip raw/code blocks

                const label    = row.querySelector('label')?.textContent.trim() || '';
                const desc     = row.querySelector('.ct-field-desc')?.textContent.trim() || '';
                const subhead  = row.querySelector('h3')?.textContent.trim() || '';
                const display  = label || subhead;

                if (!display) return; // skip blank rows

                searchIndex.push({ sectionId, sectionTitle, label: display, desc, rowEl: row });
            });
        });
    }

    // ---- HTML helpers ----

    function escHtml(str) {
        return String(str ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    /**
     * Wrap every case-insensitive occurrence of `query` in `text` with a
     * <mark> tag. Both text and query are treated as plain text (no HTML).
     */
    function highlightMatch(text, query) {
        if (!query || !text) return escHtml(text);
        const q     = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const parts = String(text).split(new RegExp('(' + q + ')', 'gi'));
        return parts.map((part, i) =>
            i % 2 === 1
                ? '<mark class="ct-search-highlight">' + escHtml(part) + '</mark>'
                : escHtml(part)
        ).join('');
    }

    // ---- Results panel ----

    function showSearchResults(query) {
        const resultsPanel = document.getElementById('ct-search-results');
        if (!resultsPanel) return;

        // Hide all section panels — content area becomes the results view
        document.querySelectorAll('.ct-settings-section').forEach(el => el.style.display = 'none');

        const q       = query.toLowerCase();
        const matches = (searchIndex || []).reduce((acc, entry, idx) => {
            if ( entry.label.toLowerCase().includes(q) ||
                 entry.desc.toLowerCase().includes(q)  ||
                 entry.sectionTitle.toLowerCase().includes(q) ) {
                acc.push({ entry, idx });
            }
            return acc;
        }, []);

        const count = matches.length;
        let html = '<div class="ct-search-results__header">';
        html += count === 0
            ? 'No results for <strong>' + escHtml(query) + '</strong>'
            : '<strong>' + count + '</strong> ' + (count === 1 ? 'result' : 'results') + ' for <strong>' + escHtml(query) + '</strong>';
        html += '</div>';

        if (count > 0) {
            html += '<div class="ct-search-results__list">';
            matches.forEach(({ entry, idx }) => {
                html += '<button type="button" class="ct-search-result-item" data-section="' + escHtml(entry.sectionId) + '" data-idx="' + idx + '">';
                html += '<span class="ct-search-result-item__breadcrumb">' + escHtml(entry.sectionTitle) + '</span>';
                html += '<span class="ct-search-result-item__label">'     + highlightMatch(entry.label, q) + '</span>';
                if (entry.desc) {
                    html += '<span class="ct-search-result-item__desc">'  + highlightMatch(entry.desc, q) + '</span>';
                }
                html += '</button>';
            });
            html += '</div>';
        }

        resultsPanel.innerHTML = html;
        resultsPanel.style.display = 'block';
    }

    function hideSearchResults() {
        const resultsPanel = document.getElementById('ct-search-results');
        if (!resultsPanel) return;
        resultsPanel.style.display = 'none';
        resultsPanel.innerHTML     = '';
    }

    // ---- Nav sidebar filter (mirrors what's in the results panel) ----

    function filterSidebarNav(query) {
        const q             = query.toLowerCase();
        const hasVisibleInGroup = {};

        // Mark sections that have at least one field match
        const sectionHasMatch = {};
        (searchIndex || []).forEach(entry => {
            if (sectionHasMatch[entry.sectionId]) return;
            if ( entry.label.toLowerCase().includes(q) ||
                 entry.desc.toLowerCase().includes(q)  ||
                 entry.sectionTitle.toLowerCase().includes(q) ) {
                sectionHasMatch[entry.sectionId] = true;
            }
        });

        document.querySelectorAll('.ct-nav-item--has-children').forEach(p => p.classList.remove('ct-search-open'));

        document.querySelectorAll('.ct-nav-item').forEach(item => {
            const text      = item.querySelector(':scope > .ct-nav-link .ct-nav-text')?.textContent.toLowerCase() || '';
            const sid       = item.getAttribute('data-section');
            const matches   = text.includes(q) || !!sectionHasMatch[sid];

            item.classList.toggle('ct-search-hidden', !matches);

            if (matches) {
                const parentItem = item.closest('.ct-nav-submenu')?.closest('.ct-nav-item--has-children');
                if (parentItem) {
                    parentItem.classList.remove('ct-search-hidden');
                    parentItem.classList.add('open', 'ct-search-open');
                }
                const group = item.closest('.ct-nav-group');
                if (group) hasVisibleInGroup[ group.getAttribute('data-group') ] = true;
            }
        });

        document.querySelectorAll('.ct-nav-group').forEach(group => {
            const id = group.getAttribute('data-group');
            if (hasVisibleInGroup[id]) {
                group.style.display = '';
                if (group.classList.contains('collapsed')) {
                    group.classList.remove('collapsed');
                    group.classList.add('ct-search-expanded');
                }
            } else {
                group.style.display = 'none';
            }
        });
    }

    function restoreSidebarNav() {
        document.querySelectorAll('.ct-nav-item').forEach(el => {
            el.classList.remove('ct-search-hidden');
            if (el.classList.contains('ct-nav-item--has-children')) {
                el.classList.remove('ct-search-open');
                const hasActive = el.querySelector('.ct-nav-item--sub.active');
                if (!hasActive) el.classList.remove('open');
            }
        });
        document.querySelectorAll('.ct-nav-group').forEach(el => {
            el.style.display = '';
            if (el.classList.contains('ct-search-expanded')) {
                el.classList.remove('ct-search-expanded');
                el.classList.add('collapsed');
            }
        });
    }

    // ---- Main entry point ----

    function initSearch() {
        const searchInput = document.getElementById('ct-settings-search');
        if (!searchInput) return;

        const doFilter = debounce(function () {
            activeSearchQuery = searchInput.value.trim().toLowerCase();
            filterSections(activeSearchQuery);
        }, 180);

        // 'input' fires on each keystroke; 'search' fires on the native ✕ clear
        searchInput.addEventListener('input',  doFilter);
        searchInput.addEventListener('search', doFilter);

        // Result item clicks — event delegation on the content area
        document.getElementById('ct-settings-content')?.addEventListener('click', function (e) {
            const item = e.target.closest('.ct-search-result-item');
            if (!item) return;

            const sectionId = item.getAttribute('data-section');
            const idx       = parseInt(item.getAttribute('data-idx'), 10);

            // 1. Clear search state before navigating so navigateTo doesn't
            //    re-apply field filtering to the destination section.
            activeSearchQuery = '';
            if (searchInput) searchInput.value = '';

            // 2. Hide results + restore nav
            hideSearchResults();
            restoreSidebarNav();
            document.querySelectorAll('.ct-field-row').forEach(el => el.classList.remove('ct-search-hidden'));

            // 3. Navigate to the containing section
            navigateTo(sectionId);

            // 4. Scroll to the specific field and briefly flash it
            if (searchIndex && searchIndex[idx]) {
                const rowEl = searchIndex[idx].rowEl;
                setTimeout(() => {
                    rowEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    rowEl.classList.add('ct-search-highlight-row');
                    setTimeout(() => rowEl.classList.remove('ct-search-highlight-row'), 2000);
                }, 60);
            }
        });
    }

    function filterSections(query) {
        activeSearchQuery = query;

        if (!query) {
            hideSearchResults();
            restoreSidebarNav();
            document.querySelectorAll('.ct-field-row').forEach(el => el.classList.remove('ct-search-hidden'));
            // Re-show the active section (hidden by showSearchResults)
            if (currentSection) {
                document.querySelectorAll('.ct-settings-section').forEach(el => el.style.display = 'none');
                const sec = document.querySelector('.ct-settings-section[data-section="' + currentSection + '"]');
                if (sec) sec.style.display = 'block';
            }
            return;
        }

        // Filter sidebar nav to reflect what's in the results panel
        filterSidebarNav(query);

        // Transform content area into the results view
        showSearchResults(query);
    }

    // =========================================================================
    // Section Reset to Defaults
    // =========================================================================
    function initSectionReset() {
        document.querySelectorAll('.ct-section-reset').forEach(btn => {
            btn.addEventListener('click', function () {
                const section = this.getAttribute('data-section');
                if (!confirm(CS.strings.reset_section)) return;

                $.ajax({
                    url: CS.ajaxUrl,
                    type: 'POST',
                    data: {
                        action:     'ct_settings_reset_section',
                        nonce:      nonce,
                        opt_name:   CS.optName,
                        section_id: section,
                    },
                    success: function (response) {
                        if (response.success) {
                            nonce = response.data.nonce;
                            // Apply defaults to fields
                            const defaults = response.data.defaults || {};
                            applyDraft(defaults);
                            clearDirtySection(section);
                            showSnackbar('Section reset to defaults.', 'success');
                        }
                    },
                });
            });
        });
    }

    // =========================================================================
    // Import / Export
    // =========================================================================
    function initImportExport() {
        document.getElementById('ct-export-btn')?.addEventListener('click', function () {
            $.ajax({
                url: CS.ajaxUrl,
                type: 'POST',
                data: { action: 'ct_settings_export', nonce, opt_name: CS.optName },
                success: function (response) {
                    if (response.success) {
                        const blob = new Blob([response.data.data], { type: 'application/json' });
                        const url  = URL.createObjectURL(blob);
                        const a    = document.createElement('a');
                        a.href     = url;
                        a.download = CS.optName + '-settings.json';
                        a.click();
                        URL.revokeObjectURL(url);
                    }
                },
            });
        });

        document.getElementById('ct-import-btn')?.addEventListener('click', function () {
            const data = document.getElementById('ct-import-data')?.value;
            const status = document.getElementById('ct-import-status');
            if (!data) return;

            if (status) status.textContent = 'Importing…';

            $.ajax({
                url: CS.ajaxUrl,
                type: 'POST',
                data: {
                    action:      'ct_settings_import',
                    nonce,
                    opt_name:    CS.optName,
                    import_data: data,
                },
                success: function (response) {
                    if (response.success) {
                        nonce = response.data.nonce;
                        if (status) status.textContent = response.data.message;
                        showSnackbar(response.data.message, 'success');
                        setTimeout(() => window.location.reload(), 1500);
                    } else {
                        if (status) status.textContent = response.data?.message || 'Import failed.';
                    }
                },
            });
        });
    }

    // =========================================================================
    // Mobile Sidebar
    // =========================================================================
    function initMobileSidebar() {
        const toggle  = document.getElementById('ct-sidebar-toggle');
        const sidebar = document.querySelector('.ct-settings-sidebar');
        const overlay = document.createElement('div');
        overlay.className = 'ct-sidebar-overlay';
        overlay.style.cssText = 'display:none;position:fixed;inset:0;z-index:399;background:rgba(0,0,0,0.4);';
        document.body.appendChild(overlay);

        toggle?.addEventListener('click', function () {
            sidebar?.classList.toggle('open');
            overlay.style.display = sidebar?.classList.contains('open') ? 'block' : 'none';
        });

        overlay.addEventListener('click', function () {
            sidebar?.classList.remove('open');
            overlay.style.display = 'none';
        });
    }

    // =========================================================================
    // Snackbar
    // =========================================================================
    let snackbarTimer = null;

    function showSnackbar(message, type) {
        const snackbar = document.getElementById('ct-settings-snackbar');
        if (!snackbar) return;

        snackbar.textContent  = message;
        snackbar.className    = 'ct-settings-snackbar';
        if (type === 'success') snackbar.classList.add('ct-snackbar--success');
        if (type === 'error')   snackbar.classList.add('ct-snackbar--error');
        snackbar.classList.add('show');

        if (snackbarTimer) clearTimeout(snackbarTimer);
        snackbarTimer = setTimeout(() => {
            snackbar.classList.remove('show');
        }, 3500);
    }

    // =========================================================================
    // Onboarding Checklist
    // =========================================================================
    function initOnboarding() {
        const checklist = document.getElementById('ct-onboarding-checklist');
        if ( ! checklist ) return;

        const onboarding  = CS.onboarding || {};
        const nonce       = onboarding.nonce || '';
        const total       = parseInt( checklist.getAttribute('data-total'), 10 ) || 8;
        const completeWrap = checklist.querySelector('.ct-onboarding-complete-wrap');
        const completeBtn  = document.getElementById('ct-onboarding-complete-btn');
        const progressFill = checklist.querySelector('.ct-onboarding-progress__fill');
        const countEl      = checklist.querySelector('.ct-onboarding-count');

        function getCheckedCount() {
            return checklist.querySelectorAll('.ct-onboarding-checkbox:checked').length;
        }

        function updateProgress() {
            const checked = getCheckedCount();
            const pct     = total > 0 ? Math.round( (checked / total) * 100 ) : 0;

            if ( progressFill ) progressFill.style.width = pct + '%';
            if ( countEl )      countEl.textContent = checked;

            if ( completeWrap ) {
                completeWrap.style.display = checked >= total ? '' : 'none';
            }

            // Sync floating panel if present
            if ( window.re7OnboardingPanelSync ) {
                window.re7OnboardingPanelSync( null, null );
            }
        }

        checklist.addEventListener('change', function(e) {
            if ( ! e.target.classList.contains('ct-onboarding-checkbox') ) return;

            // Prevent bubbling into the dirty-tracking / Save Changes handler
            e.stopPropagation();

            const stepId  = e.target.getAttribute('data-step');
            const checked = e.target.checked;
            const stepEl  = checklist.querySelector('.ct-onboarding-step[data-step="' + stepId + '"]');

            if ( stepEl ) {
                stepEl.classList.toggle('ct-onboarding-step--done', checked);
            }

            updateProgress();

            $.post( CS.ajaxUrl, {
                action:   're7_save_onboarding_step',
                nonce:    nonce,
                step_id:  stepId,
                checked:  checked ? '1' : 'false',
            } );

            // Sync floating panel checkbox
            const panelCheckbox = document.querySelector(
                '#ct-onboarding-panel .ct-onboarding-checkbox[data-step="' + stepId + '"]'
            );
            if ( panelCheckbox && panelCheckbox.checked !== checked ) {
                panelCheckbox.checked = checked;
                const panelStep = panelCheckbox.closest('.ct-panel__step');
                if ( panelStep ) panelStep.classList.toggle('ct-panel__step--done', checked);
            }
        });

        if ( completeBtn ) {
            completeBtn.addEventListener('click', function() {
                completeBtn.disabled = true;
                completeBtn.textContent = completeBtn.textContent.replace(/.*/, function() {
                    return ctSettings && ctSettings.strings ? '' : 'Completing…';
                });

                $.post( CS.ajaxUrl, {
                    action: 're7_complete_onboarding',
                    nonce:  nonce,
                }, function(response) {
                    if ( response.success ) {
                        window.location.href = response.data.redirect || ( CS.ajaxUrl.replace('admin-ajax.php', '') + 'admin.php?page=ct_options' );
                    }
                });
            });
        }
    }

    // =========================================================================
    // Utilities
    // =========================================================================
    function debounce(fn, wait) {
        let timer;
        return function (...args) {
            clearTimeout(timer);
            timer = setTimeout(() => fn.apply(this, args), wait);
        };
    }

    // =========================================================================
    // Boot
    // =========================================================================
    $(document).ready(init);

}(jQuery));
