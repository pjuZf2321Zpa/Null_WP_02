/**
 * CT Settings — Customizer Live Preview
 *
 * Runs inside the Customizer preview iframe. Handles postMessage transport
 * for all CT theme settings, applying CSS changes instantly without a
 * full page reload.
 *
 * Strategy:
 *  - color_rgba fields: inject/update a <style> block using a hardcoded CSS map
 *    that mirrors CT_Dynamic_CSS::explicit_css()
 *  - typography fields:  rebuild CSS from the compound value + update Google Font link
 *  - logo media fields:  swap <img> src in header
 *  - custom CSS:         replace a sibling <style> tag
 *
 * @package WP Pro Real Estate 7
 */

/* global wp, ctCustomizerPreview */
( function ( $ ) {
    'use strict';

    var api        = wp.customize;
    var optName    = ctCustomizerPreview.optName || 'ct_options';
    var outputMaps = ctCustomizerPreview.outputMaps || {};

    // -------------------------------------------------------------------------
    // Utility: safe JSON parse (defined first so all helpers can use it)
    // -------------------------------------------------------------------------

    function tryParse( str ) {
        try { return JSON.parse( str ); } catch ( e ) { return null; }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Get a managed <style> tag by ID, creating it if needed.
     */
    function getLiveStyleTag( id ) {
        var el = document.getElementById( id );
        if ( ! el ) {
            el = document.createElement( 'style' );
            el.id = id;
            el.type = 'text/css';
            document.head.appendChild( el );
        }
        return el;
    }

    /**
     * Given a color_rgba value (object or scalar), return the CSS color string.
     */
    function resolveColor( val ) {
        if ( ! val ) return '';
        if ( typeof val === 'string' ) return val;
        if ( typeof val === 'object' ) {
            var alpha = parseFloat( val.alpha );
            if ( ! isNaN( alpha ) && alpha < 1 && val.rgba ) return val.rgba;
            return val.color || '';
        }
        return '';
    }

    /**
     * Build a CSS rgba() string from hex + alpha, or return hex when alpha === 1.
     */
    function buildRgba( hex, alpha ) {
        if ( ! hex || typeof hex !== 'string' ) return '';
        var m = hex.match( /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i );
        if ( ! m ) return hex;
        alpha = parseFloat( alpha );
        if ( isNaN( alpha ) ) alpha = 1;
        if ( alpha >= 1 ) return hex;
        return 'rgba(' + parseInt( m[1], 16 ) + ',' + parseInt( m[2], 16 ) + ',' + parseInt( m[3], 16 ) + ',' + alpha + ')';
    }

    /**
     * Inject or update a CSS rule block.
     * @param {string} styleId  ID of the <style> element to write into.
     * @param {string} fieldId  Used to scope the CSS comment for easier debugging.
     * @param {string} css      The CSS string to write.
     */
    function injectCSS( styleId, fieldId, css ) {
        var tag     = getLiveStyleTag( styleId );
        var marker  = '/* ct:' + fieldId + ' */';
        var block   = css ? marker + css + marker : '';
        var content = tag.textContent || tag.innerHTML;

        // Replace existing block for this field, or append
        var re = new RegExp(
            '/\\* ct:' + fieldId.replace( /[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&' ) + ' \\*/[\\s\\S]*?' +
            '/\\* ct:' + fieldId.replace( /[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&' ) + ' \\*/',
            'g'
        );

        if ( re.test( content ) ) {
            tag.textContent = content.replace( re, block );
        } else {
            tag.textContent = content + block;
        }
    }

    // -------------------------------------------------------------------------
    // Color / RGBA live preview
    // -------------------------------------------------------------------------

    /**
     * CSS map: field_id → array of { selectors, property, important }
     * Mirrors CT_Dynamic_CSS::explicit_css() exactly.
     */
    var colorCSSMap = {
        // Top Bar
        ct_header_bar_color:                  [{ sel: '#topbar-wrap', prop: 'background', imp: true }],
        ct_header_bar_border_color:           [
            { sel: '#topbar-wrap', prop: 'border-bottom-color', imp: true },
            { sel: '#topbar-wrap .container', prop: 'border-bottom-color' },
            { sel: '#topbar-wrap .social li:first-child a', prop: 'border-left-color' },
            { sel: '#topbar-wrap .social a', prop: 'border-right-color' }
        ],
        ct_header_bar_text_color:             [{ sel: '#topbar-wrap,#topbar-wrap .container,#topbar-wrap a,#topbar-wrap a:visited', prop: 'color', imp: true }],
        ct_header_bar_user_bg_color:          [{ sel: '#topbar-wrap li.user-logged-in a,#topbar-wrap ul.user-drop', prop: 'background' }],
        ct_header_bar_user_link_color:        [{ sel: '#topbar-wrap li.user-logged-in a', prop: 'color' }],
        ct_header_bar_user_btm_border_color:  [{ sel: '#topbar-wrap li.user-logged-in a,#topbar-wrap ul.user-drop li', prop: 'border-bottom-color' }],
        // Main Header
        ct_header_background:                 [{ sel: '#header-wrap', prop: 'background' }],
        ct_text_logo_color:                   [{ sel: 'header #logo h2, header #logo h2 a', prop: 'color' }],
        ct_header_user_trigger_bg:            [{ sel: '.user-frontend li.user-logged-in > a', prop: 'background-color', imp: true }],
        ct_header_user_name_color:            [{ sel: '.user-frontend li.user-logged-in span.user-name', prop: 'color', imp: true }],
        ct_header_user_drop_bg:               [{ sel: '.user-frontend ul.user-drop', prop: 'background-color', imp: true }],
        ct_header_user_drop_link_color:       [{ sel: '.user-frontend ul.user-drop a', prop: 'color', imp: true }],
        ct_header_user_drop_icon_color:       [{ sel: '.user-frontend ul.user-drop li svg', prop: 'fill', imp: true }],
        ct_header_user_drop_separator:        [{ sel: '.user-frontend ul.user-drop li', prop: 'border-bottom-color', imp: true }],
        // Navigation
        ct_header_nav_font_color:             [{ sel: '.ct-menu > li > a,.user-frontend li.login-register a', prop: 'color' }],
        ct_header_nav_hover_color:            [{ sel: 'header .ct-menu > li > a:hover,header .ct-menu li.current-menu-item > a,header .ct-menu li.current-menu-ancestor > a,header .ct-menu li.current_page_parent > a', prop: 'color', imp: true }],
        ct_header_nav_current_bg:             [{ sel: '.ct-menu li.current-menu-item a,.ct-menu li.current_page_parent a', prop: 'border-top-color', imp: true }],
        ct_header_nav_hover_border_color:     [{ sel: 'nav > ul.ct-menu > li:hover > a,.ct-menu li.current-menu-item > a,.ct-menu li.current-menu-ancestor > a', prop: 'border-top-color', imp: true }],
        ct_header_nav_btn_outline:            [{ sel: 'a.btn-outline,.header-style-three .user-frontend.not-logged-in li a.btn-outline', prop: 'color', imp: true }, { sel: 'a.btn-outline,.header-style-three .user-frontend.not-logged-in li a.btn-outline', prop: 'border-color', imp: true }],
        ct_header_sub_nav_font_color:         [{ sel: '.ct-menu .sub-menu > li > a', prop: 'color', imp: true }],
        ct_header_sub_nav_hover_font_color:   [{ sel: '.ct-menu .sub-menu > li > a:hover', prop: 'color', imp: true }],
        ct_header_sub_nav_background_color:   [{ sel: '.ct-menu .sub-menu,.ct-menu .multicolumn > .sub-menu,.ct-menu .sub-menu > li,.ct-menu .sub-menu > li > a', prop: 'background-color', imp: true }],
        ct_header_sub_nav_hover_background_color: [{ sel: '.ct-menu .sub-menu > li > a:hover', prop: 'background-color', imp: true }],
        ct_header_sub_nav_items_border_bottom_color: [{ sel: '.ct-menu .sub-menu > li > a', prop: 'border-bottom-color', imp: true }],
        ct_header_sub_nav_current_background_color:  [{ sel: '.ct-menu .sub-menu > li > a.current', prop: 'background-color', imp: true }],
        ct_header_sub_nav_current_text_color:        [{ sel: '.ct-menu .sub-menu > li > a.current', prop: 'color', imp: true }],
        ct_header_sub_nav_mega_menu_title_font_color:[{ sel: '.ct-menu .sub-menu .mega-menu-column > a', prop: 'color', imp: true }],
        // Header Style 2
        ct_header_two_nav_background:         [{ sel: '#nav-full-width', prop: 'background' }],
        ct_header_two_nav_link_color:         [{ sel: '#nav-full-width .ct-menu > li > a', prop: 'color', imp: true }],
        ct_header_two_nav_link_hover_color:   [{ sel: '#nav-full-width .ct-menu > li > a:hover', prop: 'color', imp: true }],
        ct_header_two_info_bg:                [{ sel: '.header-info', prop: 'background-color' }],
        ct_header_two_info_border:            [{ sel: '.header-info', prop: 'border-top-color', imp: true }],
        ct_header_two_info_icon_color:        [{ sel: '.header-info i', prop: 'color', imp: true }],
        ct_header_two_info_title_color:       [{ sel: '.header-info h5', prop: 'color', imp: true }],
        ct_header_two_info_text_color:        [{ sel: '.header-info p.muted', prop: 'color', imp: true }],
        // Header Style 3
        ct_header_three_login_border_color:   [{ sel: '.header-style-three .user-frontend li a.btn-outline', prop: 'border-color', imp: true }],
        ct_header_three_user_text_color:      [{ sel: '.header-style-three .user-frontend li.user-logged-in > a,.header-style-three .user-frontend li.user-logged-in span.user-name', prop: 'color', imp: true }],
        // Sticky & Transparent
        ct_header_sticky_background:          [{ sel: '#home.home #header-wrap.trans-header.sticky,.page #header-wrap.trans-header.sticky,#header-wrap.sticky', prop: 'background', imp: true }],
        ct_header_sticky_nav_font_color:      [{ sel: '.home #header-wrap.trans-header.sticky nav li > a,.page #header-wrap.trans-header.sticky nav li > a', prop: 'color', imp: true }],
        ct_header_trans_home_nav_font_color:  [{ sel: '.home #header-wrap.trans-header nav li > a,.page #header-wrap.trans-header nav li > a', prop: 'color' }],
        ct_header_trans_user_name_color:      [{ sel: '.home #header-wrap.trans-header .user-frontend li.user-logged-in span.user-name,.page #header-wrap.trans-header .user-frontend li.user-logged-in span.user-name', prop: 'color', imp: true }],
        // Search Bar
        ct_header_search_bar_bg:              [{ sel: '#header-search-wrap', prop: 'background', imp: true }, { sel: '#header-search-wrap', prop: 'border-top-color' }, { sel: '#header-search-wrap', prop: 'border-bottom-color' }],
        ct_header_search_suggestion_bg:       [{ sel: '#suggestion-box,#hero-suggestion-box,#suggestion-box .listing-records,#hero-suggestion-box .listing-records', prop: 'background', imp: true }],
        // Header Style 4 — Overlay
        ct_header_four_overlay_bg:               [{ sel: '#ct-nav-overlay', prop: 'background-color' }],
        ct_header_four_overlay_link_color:       [{ sel: '#ct-nav-overlay .ct-overlay-menu a', prop: 'color', imp: true }],
        ct_header_four_overlay_link_hover_color: [{ sel: '#ct-nav-overlay .ct-overlay-menu a:hover', prop: 'color', imp: true }, { sel: '.ct-overlay-hamburger:hover .hamburger-line', prop: 'background-color', imp: true }, { sel: '.ct-overlay-nav li.open > a .ct-overlay-submenu-toggle i', prop: 'color', imp: true }, { sel: '.ct-overlay-nav ul.ct-overlay-menu > li > a:hover .ct-overlay-submenu-toggle i', prop: 'color', imp: true }],
        // Mobile
        ct_mobile_btn_bg_color:               [{ sel: '.show-hide', prop: 'background-color', imp: true }],
        ct_mobile_btn_icon_color:             [{ sel: '.show-hide', prop: 'color', imp: true }],
        ct_mobile_menu_bg_color:              [{ sel: '.cbp-spmenu,.cbp-spmenu a', prop: 'background-color', imp: true }],
        ct_mobile_menu_link_color:            [{ sel: '.cbp-spmenu a', prop: 'color', imp: true }],
        ct_mobile_menu_link_border_bottom_color: [{ sel: '.cbp-spmenu a', prop: 'border-bottom-color', imp: true }],
        ct_mobile_menu_link_hover_color:      [{ sel: '.cbp-spmenu a:hover', prop: 'color', imp: true }],
        ct_mobile_menu_link_hover_bg_color:   [{ sel: '.cbp-spmenu a:hover', prop: 'background', imp: true }],
        ct_mobile_menu_sub_arrow_color:       [{ sel: '.cbp-spmenu .sub-arrow', prop: 'color', imp: true }],
        // Body text & brand
        ct_body_text_color:                   [{ sel: 'body,p', prop: 'color' }],
        ct_secondary_bg_color:                [{ sel: '.user-frontend ul.user-drop a:hover,.user-frontend ul.user-drop a.current', prop: 'background-color', imp: true }, { sel: 'ul.user-nav li a:hover', prop: 'background-color', imp: true }],
        ct_secondary_text_color:              [{ sel: '.user-frontend ul.user-drop a:hover,.user-frontend ul.user-drop a.current', prop: 'color', imp: true }, { sel: 'ul.user-nav li a:hover', prop: 'color', imp: true }],
        ct_dark_overlay_background:           [{ sel: '.dark-overlay', prop: 'background-color' }],
        // Form inputs
        ct_input_background_color:            [{ sel: 'input[type=text],input[type=email],input[type=tel],input[type=number],input[type=search],input[type=password],input[type=url],select,textarea', prop: 'background-color', imp: true }],
        ct_input_border_color:                [{ sel: 'input[type=text],input[type=email],input[type=tel],input[type=number],input[type=search],input[type=password],input[type=url],select,textarea', prop: 'border-color', imp: true }],
        // Links
        ct_link_color:                        [{ sel: 'a,.more,.pagination .current,.flex-direction-nav a i', prop: 'color' }],
        ct_visited_color:                     [{ sel: 'a:visited', prop: 'color' }],
        ct_hover_color:                       [{ sel: 'a:hover,.more:hover,.pagination a:hover', prop: 'color' }],
        ct_active_color:                      [{ sel: 'a:active,.more:active,.pagination a:active', prop: 'color' }],
        // Listings
        ct_listing_font_color:                [{ sel: 'li.listing,.propinfo .muted,article.listing', prop: 'color' }],
        ct_listing_background_color:          [{ sel: 'li.listing,article.listing', prop: 'background-color' }],
        ct_listing_border_bottom_color:       [{ sel: '.propinfo li.row,.agent-info li.row', prop: 'border-bottom-color' }],
        ct_listing_heading_font_color:        [{ sel: '.single-listings header.listing-location h2', prop: 'color' }],
        ct_price_bg:                          [{ sel: '.flex-caption p.price,.grid-listing-info .price,.list-listing-info .price,.single-listings article .price,.infobox .price', prop: 'background' }],
        ct_price_text_color:                  [{ sel: '.flex-caption p.price,.grid-listing-info .price,.list-listing-info .price', prop: 'color' }],
        ct_listing_view_btn_bg:               [{ sel: 'li.listing.modern .search-view-listing.btn,li.listing.modern_two .search-view-listing.btn', prop: 'background', imp: true }, { sel: 'li.listing.modern .search-view-listing.btn,li.listing.modern_two .search-view-listing.btn', prop: 'border-color', imp: true }],
        ct_listing_view_btn_text:             [{ sel: 'li.listing.modern .search-view-listing.btn,li.listing.modern_two .search-view-listing.btn', prop: 'color', imp: true }],
        ct_status_snipe_color:                [{ sel: 'h6.snipe.status span', prop: 'background', imp: true }],
        ct_status_featured_color:             [{ sel: 'h6.snipe.featured span', prop: 'background', imp: true }],
        ct_map_toggle:                        [{ sel: 'span.map-toggle a,span.search-toggle a,.listing-tools li a.btn', prop: 'background-color', imp: true }],
        ct_featured_view_all:                 [{ sel: '.featured-listings a.view-all', prop: 'background-color', imp: true }],
        // Widgets & user sidebar
        ct_widget_header_bg_color:            [{ sel: '.widget h5,.aq-block-aq_widgets_block .widget h2,.aq-block-aq_widgets_block .widget h5', prop: 'background-color', imp: true }],
        ct_user_sidebar_bg:                   [{ sel: 'aside#user-nav', prop: 'background-color', imp: true }],
        ct_user_sidebar_link_bg:              [{ sel: 'ul.user-nav li a', prop: 'background-color', imp: true }],
        ct_user_sidebar_link_color:           [{ sel: 'ul.user-nav li a', prop: 'color', imp: true }],
        ct_user_sidebar_current_bg:           [{ sel: 'ul.user-nav li a.current', prop: 'background-color', imp: true }],
        ct_user_sidebar_current_color:        [{ sel: 'ul.user-nav li a.current', prop: 'color', imp: true }],
        ct_user_sidebar_icon_color:           [{ sel: '.user-nav svg *', prop: 'fill', imp: true }],
        ct_user_sidebar_menu_item_border_bottom_color: [{ sel: 'ul.user-nav li', prop: 'border-bottom-color', imp: true }],
        ct_map_toggle_text_color:             [{ sel: 'span.map-toggle a,span.search-toggle a', prop: 'color', imp: true }],
        // Footer colors
        ct_footer_background:                 [{ sel: 'footer', prop: 'background', imp: true }],
        ct_footer_border_top_color:           [{ sel: 'footer#site-footer', prop: 'border-top-color', imp: true }],
        ct_footer_link_color:                 [{ sel: 'footer,footer nav ul li a,footer nav ul li a:visited,footer a,footer a:visited', prop: 'color', imp: true }],
        ct_footer_widget_background:          [{ sel: '#footer-widgets', prop: 'background', imp: true }],
        ct_footer_widget_heading_color:       [{ sel: '#footer-widgets h5', prop: 'color', imp: true }],
        ct_footer_widget_font_color:          [{ sel: '#footer-widgets .widget,#footer-widgets .widget a,#footer-widgets .widget a:visited,#footer-widgets .widget li', prop: 'color', imp: true }],
        ct_footer_widget_link_hover_color:    [{ sel: '#footer-widgets .widget a:hover', prop: 'color', imp: true }],
        ct_footer_widget_border_color:        [{ sel: '#footer-widgets .widget li', prop: 'border-bottom-color', imp: true }],
    };

    /**
     * Build a CSS string from a rules array + a color value.
     */
    function buildColorCSS( rules, colorVal ) {
        if ( ! colorVal || ! rules || ! rules.length ) return '';
        var css = '';
        rules.forEach( function ( rule ) {
            css += rule.sel + '{' + rule.prop + ':' + colorVal + ( rule.imp ? ' !important' : '' ) + ';}';
        } );
        return css;
    }

    /**
     * Register a postMessage binding for a color_rgba field.
     */
    function bindColorField( fieldId ) {
        var settingId = optName + '[' + fieldId + ']';
        var rules     = colorCSSMap[ fieldId ];
        if ( ! rules ) return;

        api( settingId, function ( setting ) {
            setting.bind( function ( newVal ) {
                var colorVal = resolveColor( newVal );
                var css      = buildColorCSS( rules, colorVal );
                injectCSS( 'ct-customizer-live-css', fieldId, css );
            } );
        } );
    }

    // Register all color field bindings
    Object.keys( colorCSSMap ).forEach( bindColorField );

    // -------------------------------------------------------------------------
    // Typography live preview
    // -------------------------------------------------------------------------

    var typographyOutputSelectors = {
        ct_body_typography:    'body',
        ct_heading_typography: 'h1,h2,h3,h4,h5,h6',
        ct_heading_one_size:   'h1',
        ct_heading_two_size:   'h2',
        ct_heading_three_size: 'h3',
        ct_heading_four_size:  'h4',
        ct_heading_five_size:  'h5',
        ct_heading_six_size:   'h6',
    };

    // Merge output selectors from PHP-localized outputMaps
    Object.keys( outputMaps ).forEach( function ( id ) {
        var map = outputMaps[ id ];
        if ( map.type === 'typography' && Array.isArray( map.output ) ) {
            typographyOutputSelectors[ id ] = map.output.join( ',' );
        }
    } );

    function buildTypographyCSS( val, selectors ) {
        if ( ! val || typeof val !== 'object' || ! selectors ) return '';
        var props = [];
        if ( val['font-family'] ) {
            var family = val['font-family'].indexOf( ' ' ) !== -1 ? "'" + val['font-family'] + "'" : val['font-family'];
            props.push( 'font-family:' + family + ( val['font-backup'] ? ',' + val['font-backup'] : '' ) + ';' );
        }
        if ( val['font-size']       ) props.push( 'font-size:'       + val['font-size'] + ';' );
        if ( val['font-weight']     ) props.push( 'font-weight:'     + val['font-weight'] + ';' );
        if ( val['font-style']      ) props.push( 'font-style:'      + val['font-style'] + ';' );
        if ( val['line-height']     ) props.push( 'line-height:'     + val['line-height'] + ';' );
        if ( val['letter-spacing']  ) props.push( 'letter-spacing:'  + val['letter-spacing'] + ';' );
        if ( val['text-align']      ) props.push( 'text-align:'      + val['text-align'] + ';' );
        if ( val['text-transform']  ) props.push( 'text-transform:'  + val['text-transform'] + ';' );
        if ( val['text-decoration'] ) props.push( 'text-decoration:' + val['text-decoration'] + ';' );
        if ( val['color']           ) props.push( 'color:'           + val['color'] + ';' );
        if ( ! props.length ) return '';
        return selectors + '{' + props.join( '' ) + '}';
    }

    Object.keys( typographyOutputSelectors ).forEach( function ( fieldId ) {
        var settingId = optName + '[' + fieldId + ']';
        var selectors = typographyOutputSelectors[ fieldId ];

        api( settingId, function ( setting ) {
            setting.bind( function ( newVal ) {
                var val = typeof newVal === 'string' ? tryParse( newVal ) : newVal;
                var css = buildTypographyCSS( val, selectors );
                injectCSS( 'ct-customizer-live-css', fieldId, css );

                // Reload Google Font if family changed and it's a Google font
                if ( val && val['font-family'] && val['google'] ) {
                    swapGoogleFont( fieldId + '-gf', val['font-family'] );
                }
            } );
        } );
    } );

    // -------------------------------------------------------------------------
    // Simple font select fields (ct_heading_font, ct_body_font)
    // -------------------------------------------------------------------------

    api( optName + '[ct_heading_font]', function ( setting ) {
        setting.bind( function ( newVal ) {
            if ( ! newVal ) return;
            injectCSS( 'ct-customizer-live-css', 'ct_heading_font',
                'h1,h2,h3,h4,h5,h6{font-family:\'' + newVal + '\',sans-serif !important;}' );
            swapGoogleFont( 'ct-heading-font-gf', newVal );
        } );
    } );

    api( optName + '[ct_body_font]', function ( setting ) {
        setting.bind( function ( newVal ) {
            if ( ! newVal ) return;
            injectCSS( 'ct-customizer-live-css', 'ct_body_font',
                'body,p{font-family:\'' + newVal + '\',sans-serif !important;}' );
            swapGoogleFont( 'ct-body-font-gf', newVal );
        } );
    } );

    // -------------------------------------------------------------------------
    // Slider fields (text_logo_font_size, logo_max_width)
    // -------------------------------------------------------------------------

    api( optName + '[ct_text_logo_font_size]', function ( setting ) {
        setting.bind( function ( newVal ) {
            var size = parseInt( newVal, 10 );
            if ( ! size ) return;
            injectCSS( 'ct-customizer-live-css', 'ct_text_logo_font_size',
                'header #logo h2,header #logo h2 a{font-size:' + size + 'px !important;}' );
        } );
    } );

    api( optName + '[ct_logo_max_width]', function ( setting ) {
        setting.bind( function ( newVal ) {
            var w = parseInt( newVal, 10 );
            if ( ! w ) return;
            injectCSS( 'ct-customizer-live-css', 'ct_logo_max_width',
                'header#masthead .logo-wrap img{max-width:' + w + 'px !important;width:auto !important;}' );
        } );
    } );

    // -------------------------------------------------------------------------
    // Logo media fields — swap image src in header
    // -------------------------------------------------------------------------

    /**
     * Extract a URL from a media value that may be a plain object, a
     * JSON-encoded string, or a plain URL string.
     */
    function extractLogoUrl( newVal ) {
        var val = ( newVal && typeof newVal === 'string' ) ? tryParse( newVal ) : newVal;
        if ( val && typeof val === 'object' ) return val.url || '';
        return '';
    }

    /**
     * Field-specific selectors so each logo field updates only the right <img>.
     *
     * ct_logo        — the main (non-transparent, non-sticky) logo image.
     *                  Lives in .logo-wrap > a:not(.sticky-logo) and is visible
     *                  whenever the header is NOT in transparent mode.
     * ct_logo_trans  — shown inside the same anchor when the transparent header
     *                  is active on the front page.  Because both share the same
     *                  element we target all non-sticky logo imgs so either mode
     *                  shows the preview correctly.
     * ct_logo_highres — the srcset 2× version; update src to reflect change.
     * ct_logo_sticky  — the logo used inside the sticky anchor (.sticky-logo).
     */
    var logoSelectors = {
        ct_logo:        'header#masthead .logo-wrap a:not(.sticky-logo) img.logo',
        ct_logo_highres:'header#masthead .logo-wrap a:not(.sticky-logo) img.logo',
        ct_logo_trans:  'header#masthead .logo-wrap a:not(.sticky-logo) img.logo',
        ct_logo_sticky: 'header#masthead .logo-wrap a.sticky-logo img.logo',
    };

    [ 'ct_logo', 'ct_logo_highres', 'ct_logo_trans', 'ct_logo_sticky' ].forEach( function ( fieldId ) {
        api( optName + '[' + fieldId + ']', function ( setting ) {
            setting.bind( function ( newVal ) {
                var url = extractLogoUrl( newVal );
                if ( ! url ) return;
                $( logoSelectors[ fieldId ] || 'header#masthead .logo-wrap img.logo' )
                    .attr( 'src', url )
                    .removeAttr( 'srcset' ); // clear srcset so the new src is used
            } );
        } );
    } );

    // -------------------------------------------------------------------------
    // Custom CSS
    // -------------------------------------------------------------------------

    api( optName + '[ct_custom_css]', function ( setting ) {
        setting.bind( function ( newVal ) {
            getLiveStyleTag( 'ct-customizer-custom-css' ).textContent = newVal || '';
        } );
    } );

    // -------------------------------------------------------------------------
    // Layout — boxed / full-width body class swap
    // -------------------------------------------------------------------------

    api( optName + '[ct_boxed]', function ( setting ) {
        setting.bind( function ( newVal ) {
            $( '#wrapper' )
                .removeClass( 'boxed full-width-two' )
                .addClass( newVal === 'boxed' ? 'boxed' : ( newVal === 'full-width-two' ? 'full-width-two' : '' ) );
        } );
    } );

    // -------------------------------------------------------------------------
    // RTL layout toggle
    // -------------------------------------------------------------------------

    api( optName + '[ct_rtl]', function ( setting ) {
        setting.bind( function ( newVal ) {
            if ( newVal === 'yes' ) {
                $( 'html' ).attr( 'dir', 'rtl' );
                $( 'body' ).addClass( 'rtl' );
            } else {
                $( 'html' ).attr( 'dir', 'ltr' );
                $( 'body' ).removeClass( 'rtl' );
            }
        } );
    } );

    // -------------------------------------------------------------------------
    // Transparent header class toggle
    // -------------------------------------------------------------------------

    api( optName + '[ct_trans_header]', function ( setting ) {
        setting.bind( function ( newVal ) {
            var $hw = $( '#header-wrap' );
            var $mc = $( '#main-content' );
            if ( newVal === 'yes' ) {
                $hw.addClass( 'trans-header' );
                $mc.addClass( 'trans-header' );
            } else {
                $hw.removeClass( 'trans-header' );
                $mc.removeClass( 'trans-header' );
            }
        } );
    } );

    // -------------------------------------------------------------------------
    // Sticky header class toggle
    // -------------------------------------------------------------------------

    api( optName + '[ct_sticky_header]', function ( setting ) {
        setting.bind( function ( newVal ) {
            if ( newVal === 'yes' ) {
                $( '#header-wrap' ).addClass( 'sticky-header' );
            } else {
                $( '#header-wrap' ).removeClass( 'sticky-header' );
            }
        } );
    } );

    // -------------------------------------------------------------------------
    // Top bar show / hide
    // -------------------------------------------------------------------------

    api( optName + '[ct_top_bar]', function ( setting ) {
        setting.bind( function ( newVal ) {
            $( '#topbar-wrap' ).toggle( newVal === 'yes' );
        } );
    } );

    // -------------------------------------------------------------------------
    // Text logo vs image logo toggle
    // -------------------------------------------------------------------------

    api( optName + '[ct_text_logo]', function ( setting ) {
        setting.bind( function ( newVal ) {
            if ( newVal === 'yes' ) {
                $( '.logo-wrap img.logo, header #logo img.logo' ).hide();
                $( 'header #logo h2, .logo-wrap h2' ).show();
            } else {
                $( '.logo-wrap img.logo, header #logo img.logo' ).show();
                $( 'header #logo h2, .logo-wrap h2' ).hide();
            }
        } );
    } );

    // -------------------------------------------------------------------------
    // Logo advanced sizing toggle (enables the max-width CSS)
    // -------------------------------------------------------------------------

    api( optName + '[ct_logo_advanced_sizing]', function ( setting ) {
        setting.bind( function ( newVal ) {
            if ( newVal !== 'yes' ) {
                injectCSS( 'ct-customizer-live-css', 'ct_logo_max_width', '' );
            }
            // When enabled, the ct_logo_max_width slider handler injects the rule
        } );
    } );

    // -------------------------------------------------------------------------
    // Footer widgets show / hide
    // -------------------------------------------------------------------------

    api( optName + '[ct_footer_widget]', function ( setting ) {
        setting.bind( function ( newVal ) {
            $( '#footer-widgets' ).toggle( newVal === 'yes' );
        } );
    } );

    // -------------------------------------------------------------------------
    // Footer copyright text
    // -------------------------------------------------------------------------

    api( optName + '[ct_footer_text]', function ( setting ) {
        setting.bind( function ( newVal ) {
            $( 'p.footer-copyright' ).html( newVal || '' );
        } );
    } );

    // -------------------------------------------------------------------------
    // Back-to-top button show / hide
    // -------------------------------------------------------------------------

    api( optName + '[ct_footer_back_to_top]', function ( setting ) {
        setting.bind( function ( newVal ) {
            $( '#back-to-top' ).toggle( newVal === 'yes' );
        } );
    } );

    // -------------------------------------------------------------------------
    // Body background (compound: color, image, repeat, size, position, attachment)
    // -------------------------------------------------------------------------

    api( optName + '[ct_background]', function ( setting ) {
        setting.bind( function ( newVal ) {
            var val = typeof newVal === 'string' ? tryParse( newVal ) : newVal;
            if ( ! val || typeof val !== 'object' ) return;
            var parts = [];
            if ( val['background-color']      ) parts.push( 'background-color:'      + val['background-color']      + ';' );
            if ( val['background-image']      ) parts.push( 'background-image:url('  + val['background-image']      + ');' );
            if ( val['background-repeat']     ) parts.push( 'background-repeat:'     + val['background-repeat']     + ';' );
            if ( val['background-position']   ) parts.push( 'background-position:'   + val['background-position']   + ';' );
            if ( val['background-size']       ) parts.push( 'background-size:'       + val['background-size']       + ';' );
            if ( val['background-attachment'] ) parts.push( 'background-attachment:' + val['background-attachment'] + ';' );
            var css = parts.length ? 'body{' + parts.join( '' ) + '}' : '';
            injectCSS( 'ct-customizer-live-css', 'ct_background', css );
        } );
    } );

    // -------------------------------------------------------------------------
    // Footer background image
    // -------------------------------------------------------------------------

    api( optName + '[ct_footer_background_img]', function ( setting ) {
        setting.bind( function ( newVal ) {
            var val = typeof newVal === 'string' ? tryParse( newVal ) : newVal;
            var url = ( val && typeof val === 'object' ) ? ( val.url || '' ) : ( val || '' );
            var css = url ? 'footer#site-footer{background-image:url(' + url + ');}' : '';
            injectCSS( 'ct-customizer-live-css', 'ct_footer_background_img', css );
        } );
    } );

    // -------------------------------------------------------------------------
    // Google Font swap helper
    // -------------------------------------------------------------------------

    var fontLinkCache = {};

    function swapGoogleFont( linkId, family ) {
        if ( ! family ) return;
        // Try to find existing Google Fonts link (theme-enqueued)
        var mainLink = document.getElementById( 'redux-google-fonts-ct_options-css' ) ||
                       document.querySelector( 'link[href*="fonts.googleapis.com"]' );

        var url = 'https://fonts.googleapis.com/css?family=' + encodeURIComponent( family.replace( / /g, '+' ) ) + '&display=swap';

        // Use a per-field <link> tag so we don't clobber the main fonts link
        var link = document.getElementById( 'ct-gf-' + linkId );
        if ( ! link ) {
            link = document.createElement( 'link' );
            link.id  = 'ct-gf-' + linkId;
            link.rel = 'stylesheet';
            document.head.appendChild( link );
        }
        link.href = url;
    }

} )( jQuery );
