/**
 * CT Settings — Customizer Controls Panel JS
 *
 * Runs in the Customizer sidebar (controls panel), not the preview iframe.
 * Initializes interactive behavior for all custom CT control types:
 *
 *  - CT_Customize_Color_Rgba_Control  — WP Iris color picker + alpha slider
 *  - CT_Customize_Typography_Control  — live preview bar + font datalist
 *  - CT_Customize_Slider_Control      — range ↔ number input sync
 *  - CT_Customize_Switch_Control      — toggle label text update
 *  - CT_Customize_Media_Control       — WP media modal integration
 *  - CT_Customize_Background_Control  — background color picker + media modal
 *
 * @package WP Pro Real Estate 7
 */

/* global wp, jQuery */
( function ( $ ) {
    'use strict';

    var api = wp.customize;

    // =========================================================================
    // Entry point
    // =========================================================================

    api.bind( 'ready', function () {
        initColorRGBA();
        initTypography();
        initSliders();
        initSwitches();
        initMediaControls();
        initBackgroundControls();
        initImageSelect();

        // Re-init when panels/sections open (controls rendered lazily by WP)
        api.section.each( function ( section ) {
            section.expanded.bind( function ( expanded ) {
                if ( expanded ) {
                    initColorRGBA();
                    initTypography();
                    initSliders();
                    initSwitches();
                    initMediaControls();
                    initBackgroundControls();
                    initImageSelect();
                }
            } );
        } );
    } );

    // =========================================================================
    // Color RGBA Control
    // =========================================================================

    function initColorRGBA() {
        $( '.ct-rgba-wrap:not(.ct-initialized)' ).each( function () {
            var $wrap      = $( this );
            $wrap.addClass( 'ct-initialized' );

            var settingId  = $wrap.data( 'setting' );
            var $hexInput  = $wrap.find( '.ct-rgba-hex-input' );
            var $swatch    = $wrap.find( '.ct-rgba-swatch' );
            var $popout    = $wrap.find( '.ct-rgba-picker-popout' );
            var $colorHid  = $wrap.find( '.ct-rgba-color' );
            var $alphaHid  = $wrap.find( '.ct-rgba-alpha' );
            var $rgbaHid   = $wrap.find( '.ct-rgba-rgba' );
            var $alphaSlider = $wrap.find( '.ct-rgba-alpha-slider' );
            var $alphaNum  = $wrap.find( '.ct-rgba-alpha-number' );
            var $hexDisplay = $wrap.find( '.ct-rgba-hex-display' );

            // Open / close popout on swatch click
            $swatch.on( 'click', function ( e ) {
                e.stopPropagation();
                var open = $popout.is( ':visible' );
                $( '.ct-rgba-picker-popout' ).hide(); // close others
                if ( ! open ) $popout.show();
            } );

            $( document ).on( 'click', function ( e ) {
                if ( ! $wrap.is( e.target ) && $wrap.has( e.target ).length === 0 ) {
                    $popout.hide();
                }
            } );

            // Init WP Iris color picker
            if ( $.fn.wpColorPicker ) {
                $hexInput.wpColorPicker( {
                    defaultColor: $hexInput.data( 'default-color' ) || '',
                    change: function ( event, ui ) {
                        var hex   = ui.color.toString();
                        var alpha = parseFloat( $alphaHid.val() ) || 1;
                        updateRGBA( hex, alpha );
                    },
                    clear: function () {
                        updateRGBA( '', 1 );
                    },
                } );
            }

            // Alpha slider ↔ number sync
            $alphaSlider.on( 'input change', function () {
                var a = parseFloat( $( this ).val() );
                $alphaNum.val( a );
                var hex = $colorHid.val();
                updateRGBA( hex, a );
            } );

            $alphaNum.on( 'input change', function () {
                var a = parseFloat( $( this ).val() );
                a = Math.max( 0, Math.min( 1, a ) );
                $alphaSlider.val( a );
                var hex = $colorHid.val();
                updateRGBA( hex, a );
            } );

            function updateRGBA( hex, alpha ) {
                var rgba = '';
                if ( hex ) {
                    var m = hex.match( /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i );
                    if ( m ) {
                        rgba = 'rgba(' + parseInt( m[1], 16 ) + ',' + parseInt( m[2], 16 ) + ',' + parseInt( m[3], 16 ) + ',' + alpha + ')';
                    }
                }

                $colorHid.val( hex );
                $alphaHid.val( alpha );
                $rgbaHid.val( rgba );
                $hexDisplay.text( hex );

                // Update swatch preview
                var display = alpha < 1 ? rgba : hex;
                if ( display ) {
                    $swatch.css( 'background', display ).removeClass( 'ct-rgba-swatch--empty' );
                } else {
                    $swatch.css( 'background', '' ).addClass( 'ct-rgba-swatch--empty' );
                }

                // Notify WP Customizer API
                notifySetting( settingId, { color: hex, alpha: alpha, rgba: rgba } );
            }
        } );
    }

    // =========================================================================
    // Typography Control
    // =========================================================================

    function initTypography() {
        $( '.ct-typography-wrap:not(.ct-initialized)' ).each( function () {
            var $wrap     = $( this );
            $wrap.addClass( 'ct-initialized' );

            var settingId = $wrap.data( 'setting' );
            var $preview  = $wrap.find( '.ct-typography-preview' );

            var $family   = $wrap.find( '.ct-typo-family' );
            var $size     = $wrap.find( '.ct-typo-size' );
            var $weight   = $wrap.find( '.ct-typo-weight' );
            var $style    = $wrap.find( '.ct-typo-style' );
            var $lh       = $wrap.find( '.ct-typo-line-height' );
            var $ls       = $wrap.find( '.ct-typo-letter-spacing' );
            var $align    = $wrap.find( '.ct-typo-text-align' );
            var $trans    = $wrap.find( '.ct-typo-text-transform' );
            var $color    = $wrap.find( '.ct-typo-color' );
            var $google   = $wrap.find( '.ct-typo-google' );
            var $subsets  = $wrap.find( '.ct-typo-subsets' );
            var $backup   = $wrap.find( '.ct-typo-font-backup' );

            // Color picker for typography color sub-field
            if ( $.fn.wpColorPicker ) {
                $color.wpColorPicker( {
                    change: function () { emitTypography(); },
                    clear: function ()  { emitTypography(); },
                } );
            }

            $wrap.on( 'input change', 'input, select', function () {
                updatePreview();
                emitTypography();
            } );

            function updatePreview() {
                var f = $family.val();
                var s = $size.val();
                var w = $weight.val();
                var c = $color.val();
                var l = $lh.val();
                var css = '';
                if ( f ) css += "font-family:'" + f + "';";
                if ( s ) css += 'font-size:' + s + ';';
                if ( w ) css += 'font-weight:' + w + ';';
                if ( c ) css += 'color:' + c + ';';
                if ( l ) css += 'line-height:' + l + ';';
                $preview.attr( 'style', css );
            }

            function emitTypography() {
                notifySetting( settingId, buildTypographyValue() );
            }

            function buildTypographyValue() {
                var val = {};
                var f = $family.val(); if ( f ) val['font-family']     = f;
                var s = $size.val();   if ( s ) val['font-size']       = s;
                var w = $weight.val(); if ( w ) val['font-weight']     = w;
                var st = $style.val(); if ( st ) val['font-style']     = st;
                var l = $lh.val();     if ( l ) val['line-height']     = l;
                var ls = $ls.val();    if ( ls ) val['letter-spacing'] = ls;
                var a = $align.val();  if ( a ) val['text-align']      = a;
                var t = $trans.val();  if ( t ) val['text-transform']  = t;
                var c = $color.val();  if ( c ) val['color']           = c;
                val['google']       = $google.is( ':checked' );
                val['subsets']      = $subsets.val() || 'latin';
                val['font-backup']  = $backup.val() || '';
                return val;
            }
        } );
    }

    // =========================================================================
    // Slider Control
    // =========================================================================

    function initSliders() {
        $( '.ct-slider-wrap:not(.ct-initialized)' ).each( function () {
            var $wrap    = $( this );
            $wrap.addClass( 'ct-initialized' );

            var settingId = $wrap.data( 'setting' );
            var $range   = $wrap.find( '.ct-slider-range' );
            var $number  = $wrap.find( '.ct-slider-number' );

            $range.on( 'input', function () {
                $number.val( $( this ).val() );
                notifySetting( settingId, parseInt( $( this ).val(), 10 ) );
            } );

            $number.on( 'input change', function () {
                var v = parseInt( $( this ).val(), 10 );
                $range.val( v );
                notifySetting( settingId, v );
            } );
        } );
    }

    // =========================================================================
    // Switch / Toggle Control
    // =========================================================================

    function initSwitches() {
        $( '.ct-switch-wrap:not(.ct-initialized)' ).each( function () {
            var $wrap     = $( this );
            $wrap.addClass( 'ct-initialized' );

            var settingId = $wrap.data( 'setting' );
            var $checkbox = $wrap.find( '.ct-toggle-checkbox' );
            var $status   = $wrap.find( '.ct-toggle-status' );

            $checkbox.on( 'change', function () {
                var val = $( this ).is( ':checked' ) ? 'yes' : 'no';
                $status.text( val === 'yes' ? 'On' : 'Off' );
                notifySetting( settingId, val );
            } );
        } );
    }

    // =========================================================================
    // Media Control
    // =========================================================================

    function initMediaControls() {
        $( '.ct-media-wrap:not(.ct-initialized)' ).each( function () {
            var $wrap     = $( this );
            $wrap.addClass( 'ct-initialized' );

            var settingId = $wrap.data( 'setting' );
            var allowed   = $wrap.data( 'allowed' ) || 'image';
            var $url      = $wrap.find( '.ct-media-url' );
            var $id       = $wrap.find( '.ct-media-id' );
            var $width    = $wrap.find( '.ct-media-width' );
            var $height   = $wrap.find( '.ct-media-height' );
            var $thumb    = $wrap.find( '.ct-media-thumb' );
            var $preview  = $wrap.find( '.ct-media-preview-img' );
            var $urlDisp  = $wrap.find( '.ct-media-url-display' );
            var $removeBtn = $wrap.find( '.ct-media-remove-btn' );

            $wrap.find( '.ct-media-upload-btn' ).on( 'click', function () {
                var frame = wp.media( {
                    title:    'Select Image',
                    button:   { text: 'Use this image' },
                    multiple: false,
                    library:  { type: allowed === 'image' ? 'image' : undefined },
                } );

                frame.on( 'select', function () {
                    var attachment = frame.state().get( 'selection' ).first().toJSON();
                    var url   = attachment.url || '';
                    var thumb = ( attachment.sizes && attachment.sizes.thumbnail )
                        ? attachment.sizes.thumbnail.url : url;

                    $url.val( url );
                    $id.val( attachment.id || 0 );
                    $width.val( attachment.width || '' );
                    $height.val( attachment.height || '' );
                    $thumb.val( thumb );

                    if ( $preview.length ) {
                        $preview.attr( 'src', thumb ).show();
                    } else {
                        $wrap.find( '.ct-media-preview' ).html( '<img class="ct-media-preview-img" src="' + thumb + '" alt="" />' );
                    }
                    $urlDisp.text( url ).show();
                    $removeBtn.show();

                    notifySetting( settingId, {
                        url: url, id: attachment.id,
                        width: attachment.width || '',
                        height: attachment.height || '',
                        thumbnail: thumb,
                    } );
                } );

                frame.open();
            } );

            $removeBtn.on( 'click', function () {
                $url.val( '' ); $id.val( 0 ); $width.val( '' ); $height.val( '' ); $thumb.val( '' );
                $wrap.find( '.ct-media-preview' ).empty();
                $urlDisp.text( '' ).hide();
                $( this ).hide();
                notifySetting( settingId, { url: '', id: 0, width: '', height: '', thumbnail: '' } );
            } );
        } );
    }

    // =========================================================================
    // Background Control
    // =========================================================================

    function initBackgroundControls() {
        $( '.ct-bg-wrap:not(.ct-initialized)' ).each( function () {
            var $wrap     = $( this );
            $wrap.addClass( 'ct-initialized' );

            var settingId = $wrap.data( 'setting' );
            var $bgColor  = $wrap.find( '.ct-bg-color' );
            var $bgImage  = $wrap.find( '.ct-bg-image-url' );
            var $mediaId  = $wrap.find( '.ct-bg-media-id' );
            var $repeat   = $wrap.find( '.ct-bg-repeat' );
            var $size     = $wrap.find( '.ct-bg-size' );
            var $position = $wrap.find( '.ct-bg-position' );
            var $attach   = $wrap.find( '.ct-bg-attachment' );
            var $preview  = $wrap.find( '.ct-bg-preview-img' );
            var $removeBtn = $wrap.find( '.ct-bg-remove-btn' );

            if ( $.fn.wpColorPicker ) {
                $bgColor.wpColorPicker( {
                    change: function () { emitBg(); },
                    clear:  function () { emitBg(); },
                } );
            }

            $wrap.on( 'change', 'select', function () { emitBg(); } );

            $wrap.find( '.ct-bg-upload-btn' ).on( 'click', function () {
                var frame = wp.media( { title: 'Select Background Image', button: { text: 'Use this image' }, multiple: false } );
                frame.on( 'select', function () {
                    var att   = frame.state().get( 'selection' ).first().toJSON();
                    var url   = att.url || '';
                    var thumb = ( att.sizes && att.sizes.thumbnail ) ? att.sizes.thumbnail.url : url;
                    $bgImage.val( url );
                    $mediaId.val( att.id || 0 );
                    if ( $preview.length ) $preview.attr( 'src', thumb ).show();
                    else $wrap.find( '.ct-media-preview' ).html( '<img class="ct-bg-preview-img" src="' + thumb + '" alt="" />' );
                    $removeBtn.show();
                    emitBg();
                } );
                frame.open();
            } );

            $removeBtn.on( 'click', function () {
                $bgImage.val( '' ); $mediaId.val( 0 );
                $wrap.find( '.ct-media-preview' ).empty();
                $( this ).hide();
                emitBg();
            } );

            function emitBg() {
                notifySetting( settingId, {
                    'background-color':      $bgColor.val() || '',
                    'background-image':      $bgImage.val() || '',
                    'background-repeat':     $repeat.val()   || 'no-repeat',
                    'background-size':       $size.val()     || 'cover',
                    'background-position':   $position.val() || 'center center',
                    'background-attachment': $attach.val()   || 'scroll',
                    'media': { id: parseInt( $mediaId.val(), 10 ) || 0, thumbnail: $bgImage.val() || '' },
                } );
            }
        } );
    }

    // =========================================================================
    // Image Select Control
    // =========================================================================

    function initImageSelect() {
        $( '.ct-image-select-wrap:not(.ct-initialized)' ).each( function () {
            var $wrap     = $( this );
            $wrap.addClass( 'ct-initialized' );

            var settingId = $wrap.data( 'setting' );

            $wrap.find( '.ct-image-select-radio' ).on( 'change', function () {
                $wrap.find( '.ct-image-select-option' ).removeClass( 'selected' );
                $( this ).closest( '.ct-image-select-option' ).addClass( 'selected' );
                notifySetting( settingId, $( this ).val() );
            } );
        } );
    }

    // =========================================================================
    // Utility: notify WP Customize API of a setting change
    // =========================================================================

    /**
     * Notify WP's Customizer API that a setting has changed.
     *
     * settingId  — the bare field ID (e.g. 'ct_logo') stored in data-setting.
     * WP setting IDs are registered as 'ct_options[fieldId]', so we build that
     * full key first and fall back to the bare ID if needed.
     */
    function notifySetting( settingId, value ) {
        var fullId = 'ct_options[' + settingId + ']';

        // Prefer the full compound key; fall through to bare ID as a safety net.
        try {
            api( fullId ).set( value );
            return;
        } catch ( e ) { /* setting not found under fullId */ }

        try {
            api( settingId ).set( value );
        } catch ( e2 ) { /* setting not found at all — ignore */ }
    }

} )( jQuery );
