/**
 * CT Onboarding Panel — Floating global checklist
 *
 * Appears on all wp-admin pages while onboarding is incomplete.
 * Hides when the active CT Options section is "getting-started".
 * Syncs state bidirectionally with the inline Getting Started checklist.
 *
 * @package WP Pro Real Estate 7
 */
(function () {
    'use strict';

    var panel      = null;
    var config     = window.re7OnboardingPanel || {};
    var nonce      = config.nonce     || '';
    var ajaxUrl    = config.ajaxUrl   || '';
    var steps      = config.steps     || {};
    var stepsConfig = config.steps_config || [];
    var total      = stepsConfig.length;
    var storageKey = 're7_onboarding_panel_collapsed';

    // =========================================================================
    // Init
    // =========================================================================
    function init() {
        panel = document.getElementById('ct-onboarding-panel');
        if ( ! panel ) return;

        // Restore collapsed state; always sync icon to current state
        var isCollapsed = localStorage.getItem(storageKey) === '1';
        if ( isCollapsed ) {
            panel.classList.add('ct-panel--collapsed');
        }
        updateToggleIcon(isCollapsed);

        // Reveal panel (rendered hidden in PHP to prevent flash),
        // then immediately apply hash-based visibility rule.
        panel.style.display = '';
        applyVisibility();

        // ct-settings.js fires 'ct:sectionchange' via replaceState (no native hashchange).
        // Listen to both so we catch all navigation paths.
        window.addEventListener('ct:sectionchange', applyVisibility);
        window.addEventListener('hashchange', applyVisibility);

        // Toggle expand/collapse
        var header = panel.querySelector('.ct-panel__header');
        if (header) header.addEventListener('click', function(e) {
            if ( e.target.closest('.ct-panel__complete-btn') ) return;
            toggleCollapse();
        });

        // Checkboxes
        panel.addEventListener('change', function(e) {
            if ( ! e.target.classList.contains('ct-onboarding-checkbox') ) return;
            onCheckboxChange(e.target);
        });

        // Complete button
        var completeBtn = panel.querySelector('.ct-panel__complete-btn');
        if (completeBtn) {
            completeBtn.addEventListener('click', function() {
                onComplete(completeBtn);
            });
        }

        updateProgress();

        // Expose sync hook for the inline ct-settings.js checklist
        window.re7OnboardingPanelSync = syncFromInline;
    }

    // =========================================================================
    // Visibility: hide on getting-started section
    // =========================================================================
    function isOnGettingStarted() {
        var params = new URLSearchParams(window.location.search);
        if ( params.get('page') !== 'ct_options' ) return false;
        var hash = window.location.hash.replace('#', '');
        return hash === 'getting-started';
    }

    function applyVisibility() {
        if ( ! panel ) return;
        if ( isOnGettingStarted() ) {
            panel.classList.add('ct-panel--hidden');
        } else {
            panel.classList.remove('ct-panel--hidden');
        }
    }

    // =========================================================================
    // Collapse / expand
    // =========================================================================
    function toggleCollapse() {
        var collapsed = panel.classList.toggle('ct-panel--collapsed');
        updateToggleIcon(collapsed);
        localStorage.setItem(storageKey, collapsed ? '1' : '0');
    }

    function updateToggleIcon(collapsed) {
        var btn = panel.querySelector('.ct-panel__toggle');
        if ( ! btn ) return;
        btn.setAttribute('aria-label', collapsed ? 'Expand checklist' : 'Collapse checklist');
        btn.innerHTML = collapsed
            ? '<span class="dashicons dashicons-arrow-down-alt2"></span>'
            : '<span class="dashicons dashicons-arrow-up-alt2"></span>';
    }

    // =========================================================================
    // Progress
    // =========================================================================
    function getCheckedCount() {
        return panel.querySelectorAll('.ct-onboarding-checkbox:checked').length;
    }

    function updateProgress() {
        var checked     = getCheckedCount();
        var pct         = total > 0 ? Math.round( (checked / total) * 100 ) : 0;
        var fill        = panel.querySelector('.ct-panel__progress-fill');
        var label       = panel.querySelector('.ct-panel__progress-label');
        var footer      = panel.querySelector('.ct-panel__footer');
        var completeBtn = panel.querySelector('.ct-panel__complete-btn');

        if (fill)  fill.style.width = pct + '%';
        if (label) label.innerHTML  = '<strong>' + checked + '</strong> of ' + total + ' complete';

        if (footer) footer.style.display = checked >= total ? '' : 'none';
        if (completeBtn) completeBtn.disabled = false;
    }

    // =========================================================================
    // Checkbox interaction
    // =========================================================================
    function onCheckboxChange(checkbox) {
        var stepId  = checkbox.getAttribute('data-step');
        var checked = checkbox.checked;
        var stepEl  = panel.querySelector('.ct-panel__step[data-step="' + stepId + '"]');

        if (stepEl) stepEl.classList.toggle('ct-panel__step--done', checked);

        updateProgress();

        // Persist via AJAX
        var formData = new FormData();
        formData.append('action',  're7_save_onboarding_step');
        formData.append('nonce',   nonce);
        formData.append('step_id', stepId);
        formData.append('checked', checked ? '1' : 'false');

        fetch(ajaxUrl, { method: 'POST', body: formData });

        // Sync inline checklist (ct-settings page)
        syncToInline(stepId, checked);
    }

    // =========================================================================
    // Bidirectional sync with the inline Getting Started checklist
    // =========================================================================
    function syncToInline(stepId, checked) {
        var inlineCheckbox = document.querySelector(
            '#ct-onboarding-checklist .ct-onboarding-checkbox[data-step="' + stepId + '"]'
        );
        if ( ! inlineCheckbox || inlineCheckbox.checked === checked ) return;

        inlineCheckbox.checked = checked;
        var stepEl = inlineCheckbox.closest('.ct-onboarding-step');
        if (stepEl) stepEl.classList.toggle('ct-onboarding-step--done', checked);

        // Trigger inline progress update (ct-settings.js listens on 'change' but we
        // changed programmatically, so we dispatch a synthetic event)
        inlineCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Called by ct-settings.js initOnboarding() via window.re7OnboardingPanelSync
    function syncFromInline(stepId, checked) {
        if ( stepId === null ) {
            // Full refresh — rebuild from inline DOM
            var inlineChecklist = document.getElementById('ct-onboarding-checklist');
            if ( ! inlineChecklist ) return;
            inlineChecklist.querySelectorAll('.ct-onboarding-checkbox').forEach(function(cb) {
                var sid      = cb.getAttribute('data-step');
                var panelCb  = panel.querySelector('.ct-onboarding-checkbox[data-step="' + sid + '"]');
                if ( panelCb && panelCb.checked !== cb.checked ) {
                    panelCb.checked = cb.checked;
                    var stepEl = panelCb.closest('.ct-panel__step');
                    if (stepEl) stepEl.classList.toggle('ct-panel__step--done', cb.checked);
                }
            });
            updateProgress();
            return;
        }

        var panelCb = panel.querySelector('.ct-onboarding-checkbox[data-step="' + stepId + '"]');
        if ( panelCb ) {
            panelCb.checked = !! checked;
            var stepEl = panelCb.closest('.ct-panel__step');
            if (stepEl) stepEl.classList.toggle('ct-panel__step--done', !! checked);
            updateProgress();
        }
    }

    // =========================================================================
    // Complete
    // =========================================================================
    function onComplete(btn) {
        btn.disabled    = true;
        btn.textContent = 'Completing…';

        var formData = new FormData();
        formData.append('action', 're7_complete_onboarding');
        formData.append('nonce',  nonce);

        fetch(ajaxUrl, { method: 'POST', body: formData })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.success) {
                    panel.remove();
                    window.location.href = (data.data && data.data.redirect)
                        ? data.data.redirect
                        : ajaxUrl.replace('admin-ajax.php', 'admin.php?page=ct_options');
                } else {
                    btn.disabled    = false;
                    btn.textContent = 'Complete Setup';
                }
            })
            .catch(function() {
                btn.disabled    = false;
                btn.textContent = 'Complete Setup';
            });
    }

    // =========================================================================
    // Boot
    // =========================================================================
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

}());
