<?php
/**
 * CT Settings — Import / Export Field
 *
 * Export produces the same JSON structure as Redux's export (raw ct_options array).
 * Import accepts Redux-compatible JSON and merges with existing options.
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Import_Export extends CT_Field_Base {

    public function render(): void {
        echo '<div class="ct-import-export-wrap"' . $this->field_data_attr() . '>';

        // Export section
        echo '<div class="ct-ie-section">';
        echo '<h4>' . __( 'Export Settings', 'contempo' ) . '</h4>';
        echo '<p class="description">' . __( 'Download a JSON backup of all current settings. Compatible with Redux export format.', 'contempo' ) . '</p>';
        echo '<button type="button" class="button button-secondary ct-export-btn" id="ct-export-btn">'
            . __( 'Export Settings', 'contempo' )
            . '</button>';
        echo '</div>';

        echo '<hr />';

        // Import section
        echo '<div class="ct-ie-section">';
        echo '<h4>' . __( 'Import Settings', 'contempo' ) . '</h4>';
        echo '<p class="description">' . __( 'Paste exported JSON or upload a settings file. Existing settings not in the import will be preserved.', 'contempo' ) . '</p>';
        echo '<textarea id="ct-import-data" class="large-text code" rows="6" placeholder=\'{"ct_header_style":"one",...}\'></textarea>';
        echo '<br />';
        echo '<button type="button" class="button button-primary ct-import-btn" id="ct-import-btn">'
            . __( 'Import Settings', 'contempo' )
            . '</button>';
        echo '<span class="ct-import-status" id="ct-import-status"></span>';
        echo '</div>';

        echo '</div>'; // .ct-import-export-wrap
    }
}
