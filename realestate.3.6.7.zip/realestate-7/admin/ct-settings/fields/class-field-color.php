<?php
/**
 * CT Settings — Color Field (WP Iris)
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Color extends CT_Field_Base {

    public function render(): void {
        $value = is_string( $this->value ) ? $this->value : '';

        echo '<input'
            . ' type="text"'
            . ' id="' . $this->field_id() . '"'
            . ' name="' . $this->field_name() . '"'
            . $this->field_data_attr()
            . ' class="ct-color-picker"'
            . ' value="' . esc_attr( $value ) . '"'
            . ' placeholder="#rrggbb"'
            . ' data-default-color="' . esc_attr( $this->field['default'] ?? '' ) . '"'
            . ' />';
    }
}
