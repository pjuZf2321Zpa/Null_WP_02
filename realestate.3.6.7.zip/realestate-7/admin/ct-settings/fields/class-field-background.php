<?php
/**
 * CT Settings — Background Composite Field
 *
 * Stores: ['background-color' => '', 'background-image' => '', 'background-repeat' => '',
 *          'background-attachment' => '', 'background-position' => '', 'background-size' => '',
 *          'media' => ['id' => 0, 'thumbnail' => '']]
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Background extends CT_Field_Base {

    public function render(): void {
        $id  = $this->field['id'] ?? '';
        $val = is_array( $this->value ) ? $this->value : [];

        $bg_color      = isset( $val['background-color'] ) && is_string( $val['background-color'] )
            ? CT_Settings::normalize_code( $val['background-color'] )
            : ( $val['background-color'] ?? '' );
        $bg_image      = $val['background-image']      ?? '';
        $bg_repeat     = $val['background-repeat']     ?? '';
        $bg_attachment = $val['background-attachment'] ?? '';
        $bg_position   = $val['background-position']   ?? '';
        $bg_size       = $val['background-size']       ?? '';
        $media         = $val['media']                 ?? [];
        $media_id      = (int) ( $media['id'] ?? 0 );
        $media_thumb   = esc_url( $media['thumbnail'] ?? '' );

        $p = 'ct_settings_fields[' . esc_attr( $id ) . ']';

        $has_bg        = $bg_color || $bg_image;
        $preview_style = $bg_color ? 'background-color:' . esc_attr( $bg_color ) . ';' : '';
        if ( $bg_image ) $preview_style .= 'background-image:url(' . esc_attr( $bg_image ) . ');background-size:' . esc_attr( $bg_size ?: 'cover' ) . ';background-position:' . esc_attr( $bg_position ?: 'center center' ) . ';';
        $preview_class = 'ct-bg-preview' . ( $has_bg ? ' ct-bg-active' : '' );

        $badge_labels = [
            'repeat'     => [ 'no-repeat' => 'No Repeat', 'repeat' => 'Repeat', 'repeat-x' => 'Repeat X', 'repeat-y' => 'Repeat Y' ],
            'size'       => [ 'auto' => 'Auto', 'cover' => 'Cover', 'contain' => 'Contain', '100%' => '100%' ],
            'position'   => [
                'center center' => 'Center Center', 'center top' => 'Center Top', 'center bottom' => 'Center Bottom',
                'left top' => 'Left Top', 'left center' => 'Left Center', 'left bottom' => 'Left Bottom',
                'right top' => 'Right Top', 'right center' => 'Right Center', 'right bottom' => 'Right Bottom',
            ],
            'attachment' => [ 'scroll' => 'Scroll', 'fixed' => 'Fixed', 'local' => 'Local' ],
        ];
        $initial_badges = array_filter( [
            $badge_labels['repeat'][ $bg_repeat ] ?? '',
            $badge_labels['size'][ $bg_size ] ?? '',
            $badge_labels['position'][ $bg_position ] ?? '',
            $badge_labels['attachment'][ $bg_attachment ] ?? '',
        ] );

        echo '<div class="ct-bg-wrap"' . $this->field_data_attr() . '>';

        // Mini preview — layout styles live in ct-settings.css; only dynamic bg styles inline
        echo '<div class="' . esc_attr( $preview_class ) . '"' . ( $preview_style ? ' style="' . esc_attr( $preview_style ) . '"' : '' ) . '>';
        echo '<div class="ct-bg-badges">';
        foreach ( $initial_badges as $badge ) {
            echo '<span class="ct-bg-badge">' . esc_html( $badge ) . '</span>';
        }
        echo '</div>';
        echo '</div>';

        echo '<div class="ct-bg-controls">';

        // Background color
        echo '<div class="ct-bg-row"><label>' . __( 'Background Color', 'contempo' ) . '</label>';
        echo '<input type="text" class="ct-color-picker" name="' . esc_attr( $p ) . '[background-color]" value="' . esc_attr( $bg_color ) . '" /></div>';

        // Background image
        echo '<div class="ct-bg-row"><label>' . __( 'Background Image', 'contempo' ) . '</label>';
        echo '<div class="ct-media-wrap">';
        echo '<input type="hidden" name="' . esc_attr( $p ) . '[background-image]" class="ct-bg-image-url ct-media-url" value="' . esc_url( $bg_image ) . '" />';
        echo '<input type="hidden" name="' . esc_attr( $p ) . '[media][id]" class="ct-media-id" value="' . esc_attr( $media_id ) . '" />';
        echo '<input type="hidden" name="' . esc_attr( $p ) . '[media][thumbnail]" class="ct-media-thumb" value="' . esc_url( $media_thumb ) . '" />';
        if ( $bg_image ) {
            echo '<div class="ct-media-preview"><img src="' . ( $media_thumb ?: esc_url( $bg_image ) ) . '" alt="" class="ct-media-preview-img" /></div>';
        }
        echo '<button type="button" class="button ct-media-upload-btn">' . __( 'Upload / Select Image', 'contempo' ) . '</button>';
        echo '<button type="button" class="button ct-media-remove-btn"' . ( $bg_image ? '' : ' style="display:none;"' ) . '>' . __( 'Remove', 'contempo' ) . '</button>';
        echo '</div></div>';

        // Background repeat
        echo '<div class="ct-bg-row"><label>' . __( 'Repeat', 'contempo' ) . '</label>';
        echo '<select name="' . esc_attr( $p ) . '[background-repeat]">';
        foreach ( [ '' => '— Default —', 'no-repeat' => 'No Repeat', 'repeat' => 'Repeat', 'repeat-x' => 'Repeat X', 'repeat-y' => 'Repeat Y' ] as $v => $l ) {
            echo '<option value="' . esc_attr( $v ) . '"' . selected( $bg_repeat, $v, false ) . '>' . esc_html( $l ) . '</option>';
        }
        echo '</select></div>';

        // Background attachment
        echo '<div class="ct-bg-row"><label>' . __( 'Attachment', 'contempo' ) . '</label>';
        echo '<select name="' . esc_attr( $p ) . '[background-attachment]">';
        foreach ( [ '' => '— Default —', 'scroll' => 'Scroll', 'fixed' => 'Fixed', 'local' => 'Local' ] as $v => $l ) {
            echo '<option value="' . esc_attr( $v ) . '"' . selected( $bg_attachment, $v, false ) . '>' . esc_html( $l ) . '</option>';
        }
        echo '</select></div>';

        // Background position
        echo '<div class="ct-bg-row"><label>' . __( 'Position', 'contempo' ) . '</label>';
        echo '<select name="' . esc_attr( $p ) . '[background-position]">';
        foreach ( [ '' => '— Default —', 'center center' => 'Center Center', 'center top' => 'Center Top', 'center bottom' => 'Center Bottom', 'left top' => 'Left Top', 'left center' => 'Left Center', 'left bottom' => 'Left Bottom', 'right top' => 'Right Top', 'right center' => 'Right Center', 'right bottom' => 'Right Bottom' ] as $v => $l ) {
            echo '<option value="' . esc_attr( $v ) . '"' . selected( $bg_position, $v, false ) . '>' . esc_html( $l ) . '</option>';
        }
        echo '</select></div>';

        // Background size
        echo '<div class="ct-bg-row"><label>' . __( 'Size', 'contempo' ) . '</label>';
        echo '<select name="' . esc_attr( $p ) . '[background-size]">';
        foreach ( [ '' => '— Default —', 'auto' => 'Auto', 'cover' => 'Cover', 'contain' => 'Contain', '100%' => '100%' ] as $v => $l ) {
            echo '<option value="' . esc_attr( $v ) . '"' . selected( $bg_size, $v, false ) . '>' . esc_html( $l ) . '</option>';
        }
        echo '</select></div>';

        echo '</div>'; // .ct-bg-controls
        echo '</div>'; // .ct-bg-wrap
    }
}
