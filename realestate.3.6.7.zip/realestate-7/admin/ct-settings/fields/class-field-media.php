<?php
/**
 * CT Settings — Media Field (WP Media Modal)
 *
 * Stores: ['url' => 'https://...', 'id' => 123, 'width' => ..., 'height' => ..., 'thumbnail' => '...']
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Media extends CT_Field_Base {

    public function render(): void {
        $val = $this->value;
        if ( ! is_array( $val ) ) {
            $val = [ 'url' => is_string( $val ) ? $val : '', 'id' => 0, 'width' => '', 'height' => '', 'thumbnail' => '' ];
        }

        $url       = esc_url( $val['url'] ?? '' );
        $media_id  = (int) ( $val['id'] ?? 0 );
        $thumb     = esc_url( $val['thumbnail'] ?? $url );
        $allowed   = $this->field['mode'] ?? 'all';

        echo '<div class="ct-media-wrap"' . $this->field_data_attr() . '>';

        // Hidden fields
        echo '<input type="hidden" name="' . $this->field_name() . '[url]"       class="ct-media-url"    value="' . $url . '" />';
        echo '<input type="hidden" name="' . $this->field_name() . '[id]"        class="ct-media-id"     value="' . esc_attr( $media_id ) . '" />';
        echo '<input type="hidden" name="' . $this->field_name() . '[width]"     class="ct-media-width"  value="' . esc_attr( $val['width'] ?? '' ) . '" />';
        echo '<input type="hidden" name="' . $this->field_name() . '[height]"    class="ct-media-height" value="' . esc_attr( $val['height'] ?? '' ) . '" />';
        echo '<input type="hidden" name="' . $this->field_name() . '[thumbnail]" class="ct-media-thumb"  value="' . esc_url( $val['thumbnail'] ?? '' ) . '" />';

        // Preview
        echo '<div class="ct-media-preview">';
        if ( $url ) {
            echo '<img src="' . ( $thumb ?: $url ) . '" class="ct-media-preview-img" alt="" />';
        }
        echo '</div>';

        // Buttons
        echo '<div class="ct-media-actions">';
        echo '<button type="button" class="button ct-media-upload-btn" data-allowed="' . esc_attr( $allowed ) . '">' . __( 'Upload / Select', 'contempo' ) . '</button>';
        echo '<button type="button" class="button ct-media-remove-btn"' . ( $url ? '' : ' style="display:none;"' ) . '>' . __( 'Remove', 'contempo' ) . '</button>';
        echo '</div>';

        if ( $url ) {
            echo '<span class="ct-media-url-display">' . esc_html( $url ) . '</span>';
        }

        echo '</div>'; // .ct-media-wrap
    }
}
