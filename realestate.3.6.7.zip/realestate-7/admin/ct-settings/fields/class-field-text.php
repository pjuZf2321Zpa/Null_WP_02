<?php
/**
 * CT Settings — Text / Textarea Field
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Text extends CT_Field_Base {

    public function render(): void {
        $id          = $this->field['id'] ?? '';
        $type_hint   = $this->field['type'] ?? 'text';
        $placeholder = $this->field['placeholder'] ?? '';
        $value       = CT_Settings::normalize_code( is_string( $this->value ) ? $this->value : '' );

        if ( $type_hint === 'textarea' ) {
            echo '<textarea'
                . ' id="' . $this->field_id() . '"'
                . ' name="' . $this->field_name() . '"'
                . $this->field_data_attr()
                . ' class="ct-field-textarea large-text"'
                . ' placeholder="' . esc_attr( $placeholder ) . '"'
                . ' rows="6">'
                . esc_textarea( $value )
                . '</textarea>';
        } else {
            echo '<input'
                . ' type="text"'
                . ' id="' . $this->field_id() . '"'
                . ' name="' . $this->field_name() . '"'
                . $this->field_data_attr()
                . ' class="ct-field-input-text regular-text"'
                . ' placeholder="' . esc_attr( $placeholder ) . '"'
                . ' value="' . esc_attr( $value ) . '"'
                . ' />';
        }
    }
}
