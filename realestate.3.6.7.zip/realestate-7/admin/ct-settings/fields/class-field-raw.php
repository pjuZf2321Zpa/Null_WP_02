<?php
/**
 * CT Settings — Raw HTML Field
 *
 * Supports both inline 'content' and file-path via 'content_path'.
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Raw extends CT_Field_Base {

    public function render(): void {
        if ( isset( $this->field['content_callback'] ) && is_callable( $this->field['content_callback'] ) ) {
            call_user_func( $this->field['content_callback'] );
            return;
        }
        $content_path = $this->field['content_path'] ?? '';
        $content      = $this->field['content'] ?? '';

        if ( $content_path && file_exists( $content_path ) ) {
            // Inject companion stylesheet scoped to this container only.
            // Using wp_enqueue_style() would pollute the entire admin with
            // front-end rules (e.g. .active, .for-sale) from the docs CSS.
            $css_file = dirname( $content_path ) . '/custom.css';
            if ( file_exists( $css_file ) ) {
                $css_raw = file_get_contents( $css_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
                if ( $css_raw ) {
                    // Prefix every selector with .ct-field-raw-wrap to scope it
                    $id_slug  = sanitize_title( $this->field['id'] ?? 'raw-field' );
                    $scope    = '.ct-raw-scope-' . $id_slug;
                    echo '<style id="ct-raw-css-' . esc_attr( $id_slug ) . '">';
                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                    echo self::scope_css( $css_raw, $scope );
                    echo '</style>';
                }
            }

            echo '<div class="ct-field-raw-wrap ct-raw-scope-' . esc_attr( sanitize_title( $this->field['id'] ?? 'raw-field' ) ) . '">';
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            echo file_get_contents( $content_path );
            echo '</div>';
            return;
        }

        if ( $content !== '' ) {
            echo '<div class="ct-field-raw-wrap">';
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            echo $content;
            echo '</div>';
        }
    }

    /**
     * Naively prefix every CSS rule selector with $scope so companion
     * stylesheets cannot bleed outside their container.
     */
    private static function scope_css( string $css, string $scope ): string {
        // Strip @charset and BOM if present
        $css = preg_replace( '/^@charset[^;]+;/i', '', $css );

        // Split on closing braces, then re-prefix each selector block
        $blocks = preg_split( '/(?<=\})/', $css );
        $out    = '';
        foreach ( $blocks as $block ) {
            $block = trim( $block );
            if ( $block === '' ) continue;

            // Skip at-rules (@media, @keyframes, @font-face etc.) — leave as-is
            if ( preg_match( '/^\s*@/', $block ) ) {
                $out .= $block . ' ';
                continue;
            }

            // Find where the { is — everything before it is the selector list
            $brace = strpos( $block, '{' );
            if ( $brace === false ) {
                $out .= $block;
                continue;
            }

            $selectors   = substr( $block, 0, $brace );
            $declaration = substr( $block, $brace );

            // Prefix each comma-separated selector
            $prefixed = implode( ', ', array_map(
                fn( $s ) => $scope . ' ' . trim( $s ),
                explode( ',', $selectors )
            ) );

            $out .= $prefixed . ' ' . $declaration . "\n";
        }

        return $out;
    }
}
