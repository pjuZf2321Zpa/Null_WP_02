<?php
/**
 * CT Settings — Select / Image Select Field
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Select extends CT_Field_Base {

    public function render(): void {
        $type    = $this->field['type'] ?? 'select';
        $options = $this->field['options'] ?? [];
        $value   = $this->value;

        // Resolve 'data' => 'pages' into a live WP pages list
        $data_source = $this->field['data'] ?? '';
        if ( empty( $options ) && $data_source === 'pages' ) {
            $options = $this->get_pages_options();
        }

        if ( $type === 'image_select' ) {
            $this->render_image_select( $options, $value );
        } else {
            $this->render_select( $options, $value );
        }
    }

    /**
     * Returns an associative array of [ post_id => title ] for all published pages,
     * with a blank "— Select —" placeholder prepended.
     */
    private function get_pages_options(): array {
        $pages = get_pages( [
            'sort_column' => 'post_title',
            'sort_order'  => 'ASC',
            'post_status' => 'publish',
        ] );

        $options = [ '' => '— Select a page —' ];
        foreach ( $pages as $page ) {
            $options[ (string) $page->ID ] = $page->post_title;
        }

        return $options;
    }

    private function render_select( array $options, mixed $value ): void {
        $value_str = (string) $value;

        echo '<select'
            . ' id="' . $this->field_id() . '"'
            . ' name="' . $this->field_name() . '"'
            . $this->field_data_attr()
            . ' class="ct-field-select">';

        foreach ( $options as $key => $label ) {
            echo '<option value="' . esc_attr( $key ) . '"' . selected( $value_str, (string) $key, false ) . '>'
                . esc_html( $label )
                . '</option>';
        }

        echo '</select>';
    }

    private function render_image_select( array $options, mixed $value ): void {
        echo '<div class="ct-image-select-wrap"' . $this->field_data_attr() . '>';

        echo '<input type="hidden"'
            . ' id="' . $this->field_id() . '"'
            . ' name="' . $this->field_name() . '"'
            . ' value="' . esc_attr( $value ) . '"'
            . ' />';

        foreach ( $options as $key => $option ) {
            $img   = is_array( $option ) ? ( $option['img'] ?? '' ) : $option;
            $label = is_array( $option ) ? ( $option['title'] ?? self::prettify_key( $key ) ) : self::prettify_key( $key );
            $selected = ( $value === $key ) ? ' ct-image-select-item--selected' : '';

            echo '<label class="ct-image-select-item' . esc_attr( $selected ) . '" data-value="' . esc_attr( $key ) . '">';
            if ( $img ) {
                echo '<img src="' . esc_url( $img ) . '" alt="' . esc_attr( $label ) . '" />';
            }
            echo '<span>' . esc_html( $label ) . '</span>';
            echo '</label>';
        }

        echo '</div>';
    }

    /**
     * Convert a hyphen/underscore-separated key into a human-readable label.
     *
     * "listings-five"  → "Listings 5"
     * "agent-wide"     → "Agent Wide"
     * "grid-two-col"   → "Grid 2 Col"
     */
    private static function prettify_key( string $key ): string {
        static $number_words = [
            'zero'     => '0',  'one'    => '1',  'two'    => '2',
            'three'    => '3',  'four'   => '4',  'five'   => '5',
            'six'      => '6',  'seven'  => '7',  'eight'  => '8',
            'nine'     => '9',  'ten'    => '10', 'eleven' => '11',
            'twelve'   => '12',
        ];

        // Split on hyphens and underscores
        $words = preg_split( '/[-_]+/', $key );

        $words = array_map( static function ( string $word ) use ( $number_words ): string {
            $lower = strtolower( $word );
            // Swap number words for digits; title-case everything else
            return isset( $number_words[ $lower ] ) ? $number_words[ $lower ] : ucfirst( $lower );
        }, $words );

        return implode( ' ', $words );
    }
}
