<?php
/**
 * CT Settings — Switch (Toggle) Field
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Switch extends CT_Field_Base {

    public function render(): void {
        $id      = $this->field['id'] ?? '';
        $options = $this->field['options'] ?? [ 'yes' => __( 'On', 'contempo' ), 'no' => __( 'Off', 'contempo' ) ];
        $value   = $this->value;
        $is_on   = in_array( $value, [ 'yes', 'true', '1', 1, true ], true );

        echo '<div class="ct-switch-wrap"' . $this->field_data_attr() . '>';

        // Hidden input always present so unchecked value is still submitted
        echo '<input type="hidden" name="' . $this->field_name() . '" value="no" />';

        echo '<label class="ct-switch">';
        echo '<input type="checkbox"'
            . ' id="' . $this->field_id() . '"'
            . ' name="' . $this->field_name() . '"'
            . ' value="yes"'
            . ( $is_on ? ' checked' : '' )
            . ' />';
        echo '<span class="ct-switch-slider"></span>';
        echo '</label>';

        $label_on  = reset( $options );
        $label_off = end( $options );
        echo '<span class="ct-switch-label"'
            . ' data-on="' . esc_attr( $label_on ) . '"'
            . ' data-off="' . esc_attr( $label_off ) . '">'
            . esc_html( $is_on ? $label_on : $label_off )
            . '</span>';
        echo '</div>';
    }
}
