<?php
/**
 * CT Settings — Page Picker Field
 *
 * Renders a search-as-you-type multi-page selector. Selected pages appear as
 * removable chips. Stores an array of page IDs serialised as JSON in a single
 * hidden input, compatible with collectFormData() in ct-settings.js.
 *
 * Usage in re7-config.php:
 *   array(
 *     'id'    => 'my_option',
 *     'type'  => 'page_picker',
 *     'title' => 'Hide on Pages',
 *     'desc'  => 'Select pages to hide this element.',
 *   )
 *
 * Saved value: PHP array of integer page IDs, e.g. [5, 12, 33].
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Page_Picker extends CT_Field_Base {

	public function render(): void {
		$saved = $this->normalize_saved( $this->value );

		$pages = get_pages( [
			'sort_column' => 'post_title',
			'sort_order'  => 'ASC',
			'post_status' => 'publish',
		] );

		$all_pages = [];
		foreach ( $pages as $page ) {
			$all_pages[] = [ 'id' => $page->ID, 'title' => $page->post_title ];
		}

		$selected_map = [];
		foreach ( $all_pages as $p ) {
			if ( in_array( $p['id'], $saved, true ) ) {
				$selected_map[ $p['id'] ] = $p['title'];
			}
		}

		echo '<div'
			. ' class="ct-page-picker"'
			. ' id="' . $this->field_id() . '_wrap"'
			. $this->field_data_attr()
			. ' data-pages="' . esc_attr( wp_json_encode( $all_pages ) ) . '">';

		echo '<input type="hidden"'
			. ' id="' . $this->field_id() . '"'
			. ' name="' . $this->field_name() . '"'
			. ' value="' . esc_attr( wp_json_encode( $saved ) ) . '"'
			. ' />';

		echo '<div class="ct-pp-search-wrap">'
			. '<input type="text"'
			. ' class="ct-pp-search"'
			. ' placeholder="' . esc_attr__( 'Search pages…', 'contempo' ) . '"'
			. ' autocomplete="off"'
			. ' />'
			. '<ul class="ct-pp-results" hidden></ul>'
			. '</div>';

		echo '<ul class="ct-pp-chips">';
		foreach ( $selected_map as $id => $title ) {
			echo '<li class="ct-pp-chip" data-id="' . esc_attr( $id ) . '">'
				. '<span>' . esc_html( $title ) . '</span>'
				. '<button type="button" class="ct-pp-chip-remove" aria-label="'
				. esc_attr__( 'Remove', 'contempo' ) . '">&times;</button>'
				. '</li>';
		}
		echo '</ul>';

		echo '</div>';
	}

	/**
	 * Normalise the saved value to a plain array of integer IDs.
	 * Handles: clean PHP array, JSON string, legacy Redux format.
	 */
	private function normalize_saved( mixed $value ): array {
		if ( is_string( $value ) && trim( $value ) !== '' ) {
			$decoded = json_decode( $value, true );
			$value   = is_array( $decoded ) ? $decoded : [];
		}

		if ( ! is_array( $value ) ) {
			return [];
		}

		$ids = [];
		foreach ( $value as $item ) {
			if ( is_array( $item ) ) {
				$id = absint( $item['id'] ?? $item['value'] ?? 0 );
			} else {
				$id = absint( $item );
			}
			if ( $id > 0 ) {
				$ids[] = $id;
			}
		}

		return array_values( array_unique( $ids ) );
	}
}
