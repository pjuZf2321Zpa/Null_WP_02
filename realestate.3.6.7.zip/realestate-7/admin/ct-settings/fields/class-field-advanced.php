<?php
/** Optional secondary preferences, using the shared RE7 Options field renderer. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once __DIR__ . '/class-field-base.php';
class CT_Field_Advanced extends CT_Field_Base {
    public function render(): void {
        echo '<details class="ct-module-advanced"><summary>' . esc_html( $this->field['title'] ?? __( 'Advanced preferences', 'contempo' ) ) . '</summary>';
        $options = CT_Settings::get_options( 'ct_options' );
        foreach ( $this->field['fields'] ?? array() as $field ) {
            CT_Settings_Page::render_field_row( $field, $options );
        }
        echo '</details>';
    }
}
