<?php
/**
 * CT Settings — Slider Field
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Slider extends CT_Field_Base {

    public function render(): void {
        $min   = (int) ( $this->field['min'] ?? 0 );
        $max   = (int) ( $this->field['max'] ?? 100 );
        $step  = (int) ( $this->field['step'] ?? 1 );
        $value = (int) ( $this->value ?? $this->field['default'] ?? $min );
        $unit  = $this->field['unit'] ?? '';

        echo '<div class="ct-slider-wrap"' . $this->field_data_attr() . '>';
        echo '<input'
            . ' type="range"'
            . ' id="' . $this->field_id() . '"'
            . ' name="' . $this->field_name() . '"'
            . ' class="ct-field-slider"'
            . ' min="' . esc_attr( $min ) . '"'
            . ' max="' . esc_attr( $max ) . '"'
            . ' step="' . esc_attr( $step ) . '"'
            . ' value="' . esc_attr( $value ) . '"'
            . ' />';
        echo '<input'
            . ' type="number"'
            . ' class="ct-slider-number"'
            . ' min="' . esc_attr( $min ) . '"'
            . ' max="' . esc_attr( $max ) . '"'
            . ' step="' . esc_attr( $step ) . '"'
            . ' value="' . esc_attr( $value ) . '"'
            . ' aria-label="' . esc_attr( $this->field['title'] ?? '' ) . '"'
            . ' />';
        if ( $unit ) {
            echo '<span class="ct-slider-unit">' . esc_html( $unit ) . '</span>';
        }
        echo '</div>';
    }
}
