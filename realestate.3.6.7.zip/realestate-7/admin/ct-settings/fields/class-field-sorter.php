<?php
/**
 * CT Settings — Sorter Field (Drag-and-Drop)
 *
 * Stores: ['enabled' => ['placebo' => 'placebo', 'city' => 'City', ...], 'disabled' => ['placebo' => 'placebo']]
 * The 'placebo' sentinel is preserved in saved data for backward compatibility.
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Sorter extends CT_Field_Base {

    public function render(): void {
        $id  = $this->field['id'] ?? '';
        $val = $this->value;

        // Get configured items from field definition
        $options_enabled  = $this->field['options']['enabled']  ?? [];
        $options_disabled = $this->field['options']['disabled'] ?? [];

        // Merge with saved state
        if ( is_array( $val ) ) {
            $enabled  = $val['enabled']  ?? [ 'placebo' => 'placebo' ];
            $disabled = $val['disabled'] ?? [ 'placebo' => 'placebo' ];
        } else {
            // Default: all items enabled
            $enabled  = array_merge( [ 'placebo' => 'placebo' ], $options_enabled );
            $disabled = [ 'placebo' => 'placebo' ];
        }

        $name_prefix = 'ct_settings_fields[' . esc_attr( $id ) . ']';

        echo '<div class="ct-sorter-wrap"' . $this->field_data_attr() . '>';

        echo '<div class="ct-sorter-columns">';

        // Enabled column
        echo '<div class="ct-sorter-column">';
        echo '<h4 class="ct-sorter-heading">' . __( 'Enabled', 'contempo' ) . '</h4>';
        echo '<ul class="ct-sorter-list ct-sorter-enabled" data-bucket="enabled">';
        foreach ( $enabled as $key => $label ) {
            if ( $key === 'placebo' ) {
                echo '<input type="hidden" name="' . esc_attr( $name_prefix ) . '[enabled][placebo]" value="placebo" />';
                continue;
            }
            $label = is_string( $label ) ? CT_Settings::normalize_code( $label ) : $label;
            echo '<li class="ct-sorter-item" data-key="' . esc_attr( $key ) . '">';
            echo '<span class="ct-sorter-handle dashicons dashicons-menu"></span>';
            echo '<span class="ct-sorter-label">' . esc_html( $label ) . '</span>';
            echo '<input type="hidden" name="' . esc_attr( $name_prefix ) . '[enabled][' . esc_attr( $key ) . ']" value="' . esc_attr( $label ) . '" />';
            echo '</li>';
        }
        echo '</ul></div>';

        // Disabled column
        echo '<div class="ct-sorter-column">';
        echo '<h4 class="ct-sorter-heading">' . __( 'Disabled', 'contempo' ) . '</h4>';
        echo '<ul class="ct-sorter-list ct-sorter-disabled" data-bucket="disabled">';
        foreach ( $disabled as $key => $label ) {
            if ( $key === 'placebo' ) {
                echo '<input type="hidden" name="' . esc_attr( $name_prefix ) . '[disabled][placebo]" value="placebo" />';
                continue;
            }
            $label = is_string( $label ) ? CT_Settings::normalize_code( $label ) : $label;
            echo '<li class="ct-sorter-item" data-key="' . esc_attr( $key ) . '">';
            echo '<span class="ct-sorter-handle dashicons dashicons-menu"></span>';
            echo '<span class="ct-sorter-label">' . esc_html( $label ) . '</span>';
            echo '<input type="hidden" name="' . esc_attr( $name_prefix ) . '[disabled][' . esc_attr( $key ) . ']" value="' . esc_attr( $label ) . '" />';
            echo '</li>';
        }
        echo '</ul></div>';

        echo '</div>'; // .ct-sorter-columns
        echo '</div>'; // .ct-sorter-wrap
    }
}
