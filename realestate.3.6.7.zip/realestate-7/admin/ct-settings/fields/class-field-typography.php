<?php
/**
 * CT Settings — Typography Field
 *
 * Stores: ['font-family' => 'Lato', 'font-size' => '16px', 'font-weight' => '400',
 *          'line-height' => '1.6', 'color' => '#333', 'google' => true,
 *          'subsets' => 'latin', 'letter-spacing' => '', ...]
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Typography extends CT_Field_Base {

    private static array $google_fonts = [];
    private static bool  $fonts_loaded = false;

    public function render(): void {
        $id    = $this->field['id'] ?? '';
        $val = is_array( $this->value ) ? $this->value : [];
        foreach ( $val as $tk => $tv ) {
            if ( is_string( $tv ) ) {
                $val[ $tk ] = CT_Settings::normalize_code( $tv );
            }
        }

        $family      = $val['font-family']    ?? '';
        $size        = $val['font-size']       ?? '';
        $weight      = $val['font-weight']     ?? '';
        $style       = $val['font-style']      ?? '';
        $line_height = $val['line-height']     ?? '';
        $letter_sp   = $val['letter-spacing']  ?? '';
        $text_align  = $val['text-align']      ?? '';
        $text_trans  = $val['text-transform']  ?? '';
        $color       = $val['color']           ?? '';
        $is_google   = ! empty( $val['google'] );
        $subsets     = $val['subsets']         ?? 'latin';
        $font_backup = $val['font-backup']     ?? '';

        $all_fonts  = $this->get_font_list();
        $all_weights = [
            '100' => '100 — Thin',
            '200' => '200 — Extra Light',
            '300' => '300 — Light',
            '400' => '400 — Normal',
            '500' => '500 — Medium',
            '600' => '600 — Semi Bold',
            '700' => '700 — Bold',
            '800' => '800 — Extra Bold',
            '900' => '900 — Black',
        ];

        // Live preview styles
        $preview_style = '';
        if ( $family ) $preview_style .= "font-family:'{$family}';";
        if ( $size )   $preview_style .= "font-size:{$size};";
        if ( $weight ) $preview_style .= "font-weight:{$weight};";
        if ( $color )  $preview_style .= "color:{$color};";
        if ( $line_height ) $preview_style .= "line-height:{$line_height};";

        $name_prefix = 'ct_settings_fields[' . esc_attr( $id ) . ']';

        echo '<div class="ct-typography-wrap"' . $this->field_data_attr() . '>';

        // Live preview bar
        echo '<div class="ct-typography-preview" style="' . esc_attr( $preview_style ) . '">';
        echo __( 'The quick brown fox jumps over the lazy dog', 'contempo' );
        echo '</div>';

        echo '<div class="ct-typography-controls">';

        // Font family
        echo '<div class="ct-typography-row">';
        echo '<label>' . __( 'Font Family', 'contempo' ) . '</label>';
        echo '<input type="text" class="ct-typo-family regular-text" name="' . esc_attr( $name_prefix ) . '[font-family]" value="' . esc_attr( $family ) . '" list="ct_typo_datalist_' . esc_attr( $id ) . '" autocomplete="off" />';
        echo '<datalist id="ct_typo_datalist_' . esc_attr( $id ) . '">';
        foreach ( array_slice( $all_fonts, 0, 200 ) as $f ) {
            echo '<option value="' . esc_attr( $f ) . '">';
        }
        echo '</datalist>';

        echo '<label class="ct-typo-google-label">';
        echo '<input type="checkbox" name="' . esc_attr( $name_prefix ) . '[google]" value="1" class="ct-typo-google"' . checked( $is_google, true, false ) . ' />';
        echo ' Google Font</label>';
        echo '</div>';

        // Font size
        echo '<div class="ct-typography-row">';
        echo '<label>' . __( 'Size', 'contempo' ) . '</label>';
        echo '<input type="text" class="small-text" name="' . esc_attr( $name_prefix ) . '[font-size]" value="' . esc_attr( $size ) . '" placeholder="e.g. 16px" />';
        echo '</div>';

        // Font weight
        echo '<div class="ct-typography-row">';
        echo '<label>' . __( 'Weight', 'contempo' ) . '</label>';
        echo '<select name="' . esc_attr( $name_prefix ) . '[font-weight]" class="ct-typo-weight">';
        echo '<option value="">' . __( '— Default —', 'contempo' ) . '</option>';
        foreach ( $all_weights as $w => $label ) {
            echo '<option value="' . esc_attr( $w ) . '"' . selected( $weight, $w, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select>';
        echo '</div>';

        // Font style
        echo '<div class="ct-typography-row">';
        echo '<label>' . __( 'Style', 'contempo' ) . '</label>';
        echo '<select name="' . esc_attr( $name_prefix ) . '[font-style]">';
        foreach ( [ '' => __( '— Default —', 'contempo' ), 'normal' => 'Normal', 'italic' => 'Italic', 'oblique' => 'Oblique' ] as $v => $l ) {
            echo '<option value="' . esc_attr( $v ) . '"' . selected( $style, $v, false ) . '>' . esc_html( $l ) . '</option>';
        }
        echo '</select>';
        echo '</div>';

        // Line height
        echo '<div class="ct-typography-row">';
        echo '<label>' . __( 'Line Height', 'contempo' ) . '</label>';
        echo '<input type="text" class="small-text" name="' . esc_attr( $name_prefix ) . '[line-height]" value="' . esc_attr( $line_height ) . '" placeholder="e.g. 1.6" />';
        echo '</div>';

        // Letter spacing
        echo '<div class="ct-typography-row">';
        echo '<label>' . __( 'Letter Spacing', 'contempo' ) . '</label>';
        echo '<input type="text" class="small-text" name="' . esc_attr( $name_prefix ) . '[letter-spacing]" value="' . esc_attr( $letter_sp ) . '" placeholder="e.g. 0.05em" />';
        echo '</div>';

        // Text align
        echo '<div class="ct-typography-row">';
        echo '<label>' . __( 'Text Align', 'contempo' ) . '</label>';
        echo '<select name="' . esc_attr( $name_prefix ) . '[text-align]">';
        foreach ( [ '' => __( '— Default —', 'contempo' ), 'left' => 'Left', 'center' => 'Center', 'right' => 'Right', 'justify' => 'Justify' ] as $v => $l ) {
            echo '<option value="' . esc_attr( $v ) . '"' . selected( $text_align, $v, false ) . '>' . esc_html( $l ) . '</option>';
        }
        echo '</select>';
        echo '</div>';

        // Text transform
        echo '<div class="ct-typography-row">';
        echo '<label>' . __( 'Text Transform', 'contempo' ) . '</label>';
        echo '<select name="' . esc_attr( $name_prefix ) . '[text-transform]">';
        foreach ( [ '' => __( '— Default —', 'contempo' ), 'none' => 'None', 'uppercase' => 'Uppercase', 'lowercase' => 'Lowercase', 'capitalize' => 'Capitalize' ] as $v => $l ) {
            echo '<option value="' . esc_attr( $v ) . '"' . selected( $text_trans, $v, false ) . '>' . esc_html( $l ) . '</option>';
        }
        echo '</select>';
        echo '</div>';

        // Color
        echo '<div class="ct-typography-row">';
        echo '<label>' . __( 'Color', 'contempo' ) . '</label>';
        echo '<input type="text" class="ct-color-picker" name="' . esc_attr( $name_prefix ) . '[color]" value="' . esc_attr( $color ) . '" />';
        echo '</div>';

        // Subsets (hidden, preserved)
        echo '<input type="hidden" name="' . esc_attr( $name_prefix ) . '[subsets]" value="' . esc_attr( $subsets ) . '" />';

        // Font backup (hidden, preserved)
        echo '<input type="hidden" name="' . esc_attr( $name_prefix ) . '[font-backup]" value="' . esc_attr( $font_backup ) . '" />';

        echo '</div>'; // .ct-typography-controls
        echo '</div>'; // .ct-typography-wrap
    }

    private function get_font_list(): array {
        // Common Google Fonts + system fonts
        return [
            'Arial', 'Helvetica', 'Georgia', 'Times New Roman', 'Courier New', 'Verdana', 'Trebuchet MS',
            'Abel', 'Abril Fatface', 'Alegreya', 'Aleo', 'Arimo', 'Arvo', 'Asap', 'Bitter', 'Cabin',
            'Cinzel', 'Crete Round', 'Crimson Text', 'Dancing Script', 'Domine', 'Dosis', 'EB Garamond',
            'Exo', 'Exo 2', 'Fira Sans', 'Frank Ruhl Libre', 'Gelasio', 'Gentium Book Basic', 'Gudea',
            'Headland One', 'Hind', 'Hind Siliguri', 'IBM Plex Sans', 'IBM Plex Serif', 'Inconsolata',
            'Inter', 'Josefin Sans', 'Josefin Slab', 'Jost', 'Karla', 'Lato', 'Libre Baskerville',
            'Libre Franklin', 'Lobster', 'Lora', 'Merriweather', 'Merriweather Sans', 'Montserrat',
            'Mukta', 'Noto Sans', 'Noto Serif', 'Nunito', 'Nunito Sans', 'Open Sans', 'Oswald',
            'Oxygen', 'PT Sans', 'PT Serif', 'Pacifico', 'Playfair Display', 'Poppins', 'Quicksand',
            'Raleway', 'Roboto', 'Roboto Condensed', 'Roboto Mono', 'Roboto Slab', 'Rubik',
            'Source Code Pro', 'Source Sans 3', 'Source Serif 4', 'Titillium Web', 'Ubuntu',
            'Urbanist', 'Varela Round', 'Work Sans', 'Yantramanav', 'Zilla Slab',
        ];
    }
}
