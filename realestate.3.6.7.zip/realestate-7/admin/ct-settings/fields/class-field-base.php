<?php
/**
 * CT Settings — Abstract Field Base
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

abstract class CT_Field_Base {

    protected array $field;
    protected mixed $value;

    public function __construct( array $field, mixed $value ) {
        $this->field = $field;
        $this->value = $value;
    }

    abstract public function render(): void;

    protected function field_name(): string {
        $id = $this->field['id'] ?? '';
        return 'ct_settings_fields[' . esc_attr( $id ) . ']';
    }

    protected function field_id(): string {
        return 'ct_field_' . esc_attr( $this->field['id'] ?? '' );
    }

    protected function field_data_attr(): string {
        $id = $this->field['id'] ?? '';
        return ' data-field-key="' . esc_attr( $id ) . '"';
    }
}
