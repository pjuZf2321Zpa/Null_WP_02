<?php
/**
 * CT Settings — Color RGBA Field
 *
 * Stores: ['color' => '#hex', 'alpha' => 0.8, 'rgba' => 'rgba(...)']
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Color_RGBA extends CT_Field_Base {

    /**
     * Return '#ffffff' or '#1e2939' depending on which gives better contrast
     * against the given hex color + alpha. Transparent swatches default to dark text.
     */
    private static function contrast_color( string $hex, float $alpha ): string {
        if ( $alpha < 0.4 || strlen( $hex ) < 7 ) {
            return '#1e2939';
        }
        $hex = ltrim( $hex, '#' );
        if ( strlen( $hex ) !== 6 ) {
            return '#1e2939';
        }
        $r          = hexdec( substr( $hex, 0, 2 ) );
        $g          = hexdec( substr( $hex, 2, 2 ) );
        $b          = hexdec( substr( $hex, 4, 2 ) );
        $brightness = ( $r * 299 + $g * 587 + $b * 114 ) / 1000;
        return $brightness > 128 ? '#1e2939' : '#ffffff';
    }

    public function render(): void {
        $id = $this->field['id'] ?? '';

        // Normalise value — promote legacy plain hex string saved by old color fields
        $val = $this->value;
        if ( is_string( $val ) && $val !== '' ) {
            $hex = sanitize_hex_color( $val ) ?? '';
            $m   = [];
            if ( $hex && preg_match( '/^#([0-9a-f]{6})$/i', $hex, $m ) ) {
                $r   = hexdec( substr( $m[1], 0, 2 ) );
                $g   = hexdec( substr( $m[1], 2, 2 ) );
                $b   = hexdec( substr( $m[1], 4, 2 ) );
                $val = [ 'color' => $hex, 'alpha' => 1.0, 'rgba' => "rgba({$r},{$g},{$b},1)" ];
            } else {
                $val = [ 'color' => $hex, 'alpha' => 1.0, 'rgba' => $hex ];
            }
        }
        if ( ! is_array( $val ) ) {
            $val = [ 'color' => '', 'alpha' => 1, 'rgba' => '' ];
        }

        $color = sanitize_hex_color( $val['color'] ?? '' ) ?? '';
        $alpha = (float) ( $val['alpha'] ?? 1 );
        $rgba  = $val['rgba'] ?? '';

        $is_empty    = ( $color === '' );
        $preview_bg  = $is_empty ? '' : ( $rgba ?: $color );
        $text_color  = $is_empty ? '' : self::contrast_color( $color, $alpha );
        $swatch_class = 'ct-rgba-swatch' . ( $is_empty ? ' ct-rgba-swatch--empty' : '' );
        $swatch_style = $is_empty ? '' : ( 'background:' . esc_attr( $preview_bg ) . ';color:' . esc_attr( $text_color ) . ';' );

        echo '<div class="ct-rgba-wrap"' . $this->field_data_attr() . '>';

        // Hidden sub-fields — JS keeps these updated
        echo '<input type="hidden" name="' . $this->field_name() . '[color]" value="' . esc_attr( $color ) . '" class="ct-rgba-color" />';
        echo '<input type="hidden" name="' . $this->field_name() . '[alpha]" value="' . esc_attr( $alpha ) . '" class="ct-rgba-alpha" />';
        echo '<input type="hidden" name="' . $this->field_name() . '[rgba]"  value="' . esc_attr( $rgba )  . '" class="ct-rgba-rgba" />';

        // Visual picker wrapper
        echo '<div class="ct-rgba-picker-wrap">';
        echo '<div class="' . esc_attr( $swatch_class ) . '"' . ( $swatch_style ? ' style="' . $swatch_style . '"' : '' ) . '>';
        echo '<span class="ct-rgba-hex-display">' . esc_html( $color ) . '</span>';
        echo '</div>';
        echo '<div class="ct-rgba-picker-popout" style="display:none;">';
        // WP Iris color picker for hex
        $default_raw   = $this->field['default'] ?? '';
        $default_color = is_array( $default_raw ) ? ( $default_raw['color'] ?? '' ) : (string) $default_raw;
        echo '<input type="text" class="ct-color-picker ct-rgba-hex-input" value="' . esc_attr( $color ) . '" data-default-color="' . esc_attr( $default_color ) . '" placeholder="#rrggbb" autocomplete="off" spellcheck="false" maxlength="7" />';
        // Alpha slider
        echo '<div class="ct-rgba-alpha-wrap">';
        echo '<label>' . __( 'Opacity', 'contempo' ) . '</label>';
        echo '<input type="range" class="ct-rgba-alpha-slider" min="0" max="1" step="0.01" value="' . esc_attr( $alpha ) . '" />';
        echo '<input type="number" class="ct-rgba-alpha-number" min="0" max="1" step="0.01" value="' . esc_attr( $alpha ) . '" />';
        echo '</div>'; // .ct-rgba-alpha-wrap
        echo '</div>'; // .ct-rgba-picker-popout
        echo '</div>'; // .ct-rgba-picker-wrap

        echo '</div>'; // .ct-rgba-wrap
    }
}
