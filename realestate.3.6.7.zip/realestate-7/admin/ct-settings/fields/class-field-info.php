<?php
/**
 * CT Settings — Info / Section Display Field
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Info extends CT_Field_Base {

    public function render(): void {
        $style = $this->field['style'] ?? 'normal';
        $desc  = $this->field['desc'] ?? '';
        $title = $this->field['title'] ?? '';
        $type  = $this->field['type'] ?? 'info';

        if ( $type === 'section' ) {
            echo '<div class="ct-field-section-divider">';
            if ( $title ) echo '<h3>' . esc_html( $title ) . '</h3>';
            if ( $desc )  echo '<p>' . wp_kses_post( $desc ) . '</p>';
            echo '</div>';
            return;
        }

        if ( ! $title && ! $desc ) {
            return;
        }

        $class = 'ct-field-info-banner';
        if ( $style === 'warning' ) $class .= ' ct-field-info-banner--warning';
        if ( $style === 'success' ) $class .= ' ct-field-info-banner--success';
        if ( $style === 'critical' ) $class .= ' ct-field-info-banner--error';

        echo '<div class="' . esc_attr( $class ) . '">';
        if ( $title ) echo '<strong>' . esc_html( $title ) . '</strong> ';
        echo wp_kses_post( $desc );
        echo '</div>';
    }
}
