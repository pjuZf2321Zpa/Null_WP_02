<?php
/**
 * CT Settings — Ace Editor Field (CodeMirror via WP Core)
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-field-base.php';

class CT_Field_Ace_Editor extends CT_Field_Base {

    public function render(): void {
        $id       = $this->field['id'] ?? '';
        $value    = CT_Settings::normalize_code( is_string( $this->value ) ? $this->value : '' );
        $mode     = $this->field['mode'] ?? 'css'; // css, javascript, html, php
        $theme    = $this->field['theme'] ?? 'default';
        $height   = $this->field['height'] ?? '250px';

        // Map Redux mode names to CodeMirror MIME types
        $mime_map = [
            'css'        => 'text/css',
            'javascript' => 'text/javascript',
            'html'       => 'text/html',
            'php'        => 'application/x-httpd-php',
            'json'       => 'application/json',
        ];
        $mime = $mime_map[ $mode ] ?? 'text/css';

        echo '<div class="ct-ace-wrap"' . $this->field_data_attr() . '>';

        echo '<textarea'
            . ' id="' . $this->field_id() . '"'
            . ' name="' . $this->field_name() . '"'
            . ' class="ct-ace-editor"'
            . ' data-codemirror-mode="' . esc_attr( $mime ) . '"'
            . ' data-codemirror-theme="' . esc_attr( $theme ) . '"'
            . ' style="height:' . esc_attr( $height ) . ';font-family:monospace;"'
            . ' rows="10">'
            . esc_textarea( $value )
            . '</textarea>';

        echo '</div>';
    }
}
