<?php
    /**
     * Theme Options Config — CT Settings Framework
     *
     * Migrated from Redux Framework to CT_Settings (built into RE7 v3.5.9+).
     * API calls changed from Redux::setSection() to CT_Settings::set_section().
     * All option IDs, field definitions, output arrays, and defaults are unchanged.
     *
     * @package WP Pro Real Estate 7
     * @subpackage Admin
     */

    if ( ! class_exists( 'CT_Settings' ) ) {
        return;
    }

    /**
     * Returns the ordered onboarding step definitions.
     * Defined here (re7-config.php) because this file loads before theme-functions.php.
     * The Currency step is omitted for en_US sites since USD is the default.
     */
    if ( ! function_exists( 're7_get_onboarding_steps_config' ) ) {
        function re7_get_onboarding_steps_config() {
            $steps = array(
                array(
                    'id'      => 'logo',
                    'label'   => __( 'Logo', 'contempo' ),
                    'desc'    => __( 'Upload your logo', 'contempo' ),
                    'section' => 'logo',
                    'nav'     => __( 'General &rarr; Logo', 'contempo' ),
                ),
                array(
                    'id'      => 'contact',
                    'label'   => __( 'Contact Info', 'contempo' ),
                    'desc'    => __( 'Set your phone number and email address', 'contempo' ),
                    'section' => 'contact',
                    'nav'     => __( 'General &rarr; Contact', 'contempo' ),
                ),
                array(
                    'id'      => 'google-maps',
                    'label'   => __( 'Google Maps API Key', 'contempo' ),
                    'desc'    => __( 'Required for map features', 'contempo' ),
                    'section' => 'google-maps',
                    'nav'     => __( 'Integrations &rarr; Google Maps', 'contempo' ),
                ),
                array(
                    'id'      => 'color-scheme',
                    'label'   => __( 'Color Scheme', 'contempo' ),
                    'desc'    => __( 'Choose Original or Minimal skin', 'contempo' ),
                    'section' => 'create-a-skin-secondary-colors',
                    'nav'     => __( 'Appearance &rarr; Color Scheme', 'contempo' ),
                ),
                array(
                    'id'      => 'typography',
                    'label'   => __( 'Heading &amp; Body Fonts', 'contempo' ),
                    'desc'    => __( 'Set your site fonts', 'contempo' ),
                    'section' => 'typography',
                    'nav'     => __( 'Appearance &rarr; Typography', 'contempo' ),
                ),
                array(
                    'id'      => 'currency',
                    'label'   => __( 'Currency Symbol', 'contempo' ),
                    'desc'    => __( 'Configure the currency displayed on listings', 'contempo' ),
                    'section' => 'listings',
                    'nav'     => __( 'Listings', 'contempo' ),
                ),
                array(
                    'id'      => 'login-registration',
                    'label'   => __( 'Login &amp; Registration', 'contempo' ),
                    'desc'    => __( 'Enable user accounts for lead capture', 'contempo' ),
                    'section' => 'front-end-login-registration',
                    'nav'     => __( 'User Accounts &rarr; Front End Login', 'contempo' ),
                ),
                array(
                    'id'      => 'recaptcha',
                    'label'   => __( 'reCAPTCHA', 'contempo' ),
                    'desc'    => __( 'Protect your forms from spam', 'contempo' ),
                    'section' => 'google-recaptcha',
                    'nav'     => __( 'Integrations &rarr; Google reCAPTCHA', 'contempo' ),
                ),
                array(
                    'id'       => 'elementor-pages',
                    'label'    => __( 'Customize Pages', 'contempo' ),
                    'desc'     => __( 'Replace demo content with your own using Elementor', 'contempo' ),
                    'section'  => '',
                    'nav'      => __( 'Pages &rarr; All Pages', 'contempo' ),
                    'url'      => 'edit.php?post_type=page',
                    'docs_url' => 'https://contempothemes.com/docs/elementor/',
                    'docs_nav' => __( 'Elementor Docs ↗', 'contempo' ),
                ),
            );

            // US English sites default to USD — the currency step adds no value.
            if ( get_locale() === 'en_US' ) {
                $steps = array_values( array_filter( $steps, function( $step ) {
                    return $step['id'] !== 'currency';
                } ) );
            }

            return $steps;
        }
    }

    $opt_name = 'ct_options';

    CT_Settings::set_args( $opt_name, array(
        'opt_name'       => $opt_name,
        'display_name'   => __( 'Real Estate 7 Options', 'contempo' ),
        'display_version'=> REALESTATE7_SL_THEME_VERSION,
        'menu_title'     => __( 'Real Estate 7 Options', 'contempo' ),
        'page_title'     => __( 'Real Estate 7 Options', 'contempo' ),
        'menu_icon'      => 'dashicons-admin-home',
        'menu_position'  => 2.5,
        'global_variable'=> 'ct_options',
        'save_defaults'  => true,
        'output'         => true,
    ) );

    /*--------------------------------------*/
    /* Snazzy Maps
    /*--------------------------------------

    function ct_get_snazzy_map_styles() {
        $ct_snazzy_maps_url = 'https://snazzymaps.com/explore.json?key=b34b7779-0dac-4182-9f5c-c07a7966b30a';
        $ct_snazzy_content = file_get_contents($ct_snazzy_maps_url);
        $ct_snazzy_json = json_decode($ct_snazzy_content, true);



        return apply_filters('ct_get_snazzy_map_styles', $ct_snazzy_json);
    }

    /*--------------------------------------*/
    /* Font Awesome
    /*--------------------------------------*/

    function ct_font_awesome() {
        $font_awesome_icons = array( 'fa-500px' => '500px', 'fa-adjust' => 'Adjust', 'fa-adn' => 'Adn', 'fa-align-center' => 'Align center', 'fa-align-justify' => 'Align justify', 'fa-align-left' => 'Align left', 'fa-align-right' => 'Align right', 'fa-amazon' => 'Amazon', 'fa-ambulance' => 'Ambulance', 'fa-anchor' => 'Anchor', 'fa-android' => 'Android', 'fa-angellist' => 'Angellist', 'fa-angle-double-down' => 'Angle double down', 'fa-angle-double-left' => 'Angle double left', 'fa-angle-double-right' => 'Angle double right', 'fa-angle-double-up' => 'Angle double up', 'fa-angle-down' => 'Angle down', 'fa-angle-left' => 'Angle left', 'fa-angle-right' => 'Angle right', 'fa-angle-up' => 'Angle up', 'fa-apple' => 'Apple', 'fa-archive' => 'Archive', 'fa-area-chart' => 'Area chart', 'fa-arrow-circle-down' => 'Arrow circle down', 'fa-arrow-circle-left' => 'Arrow circle left', 'fa-arrow-circle-o-down' => 'Arrow circle o down', 'fa-arrow-circle-o-left' => 'Arrow circle o left', 'fa-arrow-circle-o-right' => 'Arrow circle o right', 'fa-arrow-circle-o-up' => 'Arrow circle o up', 'fa-arrow-circle-right' => 'Arrow circle right', 'fa-arrow-circle-up' => 'Arrow circle up', 'fa-arrow-down' => 'Arrow down', 'fa-arrow-left' => 'Arrow left', 'fa-arrow-right' => 'Arrow right', 'fa-arrow-up' => 'Arrow up', 'fa-arrows' => 'Arrows', 'fa-arrows-alt' => 'Arrows alt', 'fa-arrows-h' => 'Arrows h', 'fa-arrows-v' => 'Arrows v', 'fa-asterisk' => 'Asterisk', 'fa-at' => 'At', 'fa-backward' => 'Backward', 'fa-balance-scale' => 'Balance scale', 'fa-ban' => 'Ban', 'fa-bar-chart' => 'Bar chart', 'fa-barcode' => 'Barcode', 'fa-bars' => 'Bars', 'fa-battery-empty' => 'Battery empty', 'fa-battery-full' => 'Battery full', 'fa-battery-half' => 'Battery half', 'fa-battery-quarter' => 'Battery quarter', 'fa-battery-three-quarters' => 'Battery three quarters', 'fa-bed' => 'Bed', 'fa-beer' => 'Beer', 'fa-behance' => 'Behance', 'fa-behance-square' => 'Behance square', 'fa-bell' => 'Bell', 'fa-bell-o' => 'Bell o', 'fa-bell-slash' => 'Bell slash', 'fa-bell-slash-o' => 'Bell slash o', 'fa-bicycle' => 'Bicycle', 'fa-binoculars' => 'Binoculars', 'fa-birthday-cake' => 'Birthday cake', 'fa-bitbucket' => 'Bitbucket', 'fa-bitbucket-square' => 'Bitbucket square', 'fa-black-tie' => 'Black tie', 'fa-bold' => 'Bold', 'fa-bolt' => 'Bolt', 'fa-bomb' => 'Bomb', 'fa-book' => 'Book', 'fa-bookmark' => 'Bookmark', 'fa-bookmark-o' => 'Bookmark o', 'fa-briefcase' => 'Briefcase', 'fa-btc' => 'Btc', 'fa-bug' => 'Bug', 'fa-building' => 'Building', 'fa-building-o' => 'Building o', 'fa-bullhorn' => 'Bullhorn', 'fa-bullseye' => 'Bullseye', 'fa-bus' => 'Bus', 'fa-buysellads' => 'Buysellads', 'fa-calculator' => 'Calculator', 'fa-calendar' => 'Calendar', 'fa-calendar-check-o' => 'Calendar check o', 'fa-calendar-minus-o' => 'Calendar minus o', 'fa-calendar-o' => 'Calendar o', 'fa-calendar-plus-o' => 'Calendar plus o', 'fa-calendar-times-o' => 'Calendar times o', 'fa-camera' => 'Camera', 'fa-camera-retro' => 'Camera retro', 'fa-car' => 'Car', 'fa-caret-down' => 'Caret down', 'fa-caret-left' => 'Caret left', 'fa-caret-right' => 'Caret right', 'fa-caret-square-o-down' => 'Caret square o down', 'fa-caret-square-o-left' => 'Caret square o left', 'fa-caret-square-o-right' => 'Caret square o right', 'fa-caret-square-o-up' => 'Caret square o up', 'fa-caret-up' => 'Caret up', 'fa-cart-arrow-down' => 'Cart arrow down', 'fa-cart-plus' => 'Cart plus', 'fa-cc' => 'Cc', 'fa-cc-amex' => 'Cc amex', 'fa-cc-diners-club' => 'Cc diners club', 'fa-cc-discover' => 'Cc discover', 'fa-cc-jcb' => 'Cc jcb', 'fa-cc-mastercard' => 'Cc mastercard', 'fa-cc-paypal' => 'Cc paypal', 'fa-cc-stripe' => 'Cc stripe', 'fa-cc-visa' => 'Cc visa', 'fa-certificate' => 'Certificate', 'fa-chain-broken' => 'Chain broken', 'fa-check' => 'Check', 'fa-check-circle' => 'Check circle', 'fa-check-circle-o' => 'Check circle o', 'fa-check-square' => 'Check square', 'fa-check-square-o' => 'Check square o', 'fa-chevron-circle-down' => 'Chevron circle down', 'fa-chevron-circle-left' => 'Chevron circle left', 'fa-chevron-circle-right' => 'Chevron circle right', 'fa-chevron-circle-up' => 'Chevron circle up', 'fa-chevron-down' => 'Chevron down', 'fa-chevron-left' => 'Chevron left', 'fa-chevron-right' => 'Chevron right', 'fa-chevron-up' => 'Chevron up', 'fa-child' => 'Child', 'fa-chrome' => 'Chrome', 'fa-circle' => 'Circle', 'fa-circle-o' => 'Circle o', 'fa-circle-o-notch' => 'Circle o notch', 'fa-circle-thin' => 'Circle thin', 'fa-clipboard' => 'Clipboard', 'fa-clock-o' => 'Clock o', 'fa-clone' => 'Clone', 'fa-cloud' => 'Cloud', 'fa-cloud-download' => 'Cloud download', 'fa-cloud-upload' => 'Cloud upload', 'fa-code' => 'Code', 'fa-code-fork' => 'Code fork', 'fa-codepen' => 'Codepen', 'fa-coffee' => 'Coffee', 'fa-cog' => 'Cog', 'fa-cogs' => 'Cogs', 'fa-columns' => 'Columns', 'fa-comment' => 'Comment', 'fa-comment-o' => 'Comment o', 'fa-commenting' => 'Commenting', 'fa-commenting-o' => 'Commenting o', 'fa-comments' => 'Comments', 'fa-comments-o' => 'Comments o', 'fa-compass' => 'Compass', 'fa-compress' => 'Compress', 'fa-connectdevelop' => 'Connectdevelop', 'fa-contao' => 'Contao', 'fa-copyright' => 'Copyright', 'fa-creative-commons' => 'Creative commons', 'fa-credit-card' => 'Credit card', 'fa-crop' => 'Crop', 'fa-crosshairs' => 'Crosshairs', 'fa-css3' => 'Css3', 'fa-cube' => 'Cube', 'fa-cubes' => 'Cubes', 'fa-cutlery' => 'Cutlery', 'fa-dashcube' => 'Dashcube', 'fa-database' => 'Database', 'fa-delicious' => 'Delicious', 'fa-desktop' => 'Desktop', 'fa-deviantart' => 'Deviantart', 'fa-diamond' => 'Diamond', 'fa-digg' => 'Digg', 'fa-dot-circle-o' => 'Dot circle o', 'fa-download' => 'Download', 'fa-dribbble' => 'Dribbble', 'fa-dropbox' => 'Dropbox', 'fa-drupal' => 'Drupal', 'fa-eject' => 'Eject', 'fa-ellipsis-h' => 'Ellipsis h', 'fa-ellipsis-v' => 'Ellipsis v', 'fa-empire' => 'Empire', 'fa-envelope' => 'Envelope', 'fa-envelope-o' => 'Envelope o', 'fa-envelope-square' => 'Envelope square', 'fa-eraser' => 'Eraser', 'fa-eur' => 'Eur', 'fa-exchange' => 'Exchange', 'fa-exclamation' => 'Exclamation', 'fa-exclamation-circle' => 'Exclamation circle', 'fa-exclamation-triangle' => 'Exclamation triangle', 'fa-expand' => 'Expand', 'fa-expeditedssl' => 'Expeditedssl', 'fa-external-link' => 'External link', 'fa-external-link-square' => 'External link square', 'fa-eye' => 'Eye', 'fa-eye-slash' => 'Eye slash', 'fa-eyedropper' => 'Eyedropper', 'fa-facebook' => 'Facebook', 'fa-facebook-official' => 'Facebook official', 'fa-facebook-square' => 'Facebook square', 'fa-fast-backward' => 'Fast backward', 'fa-fast-forward' => 'Fast forward', 'fa-fax' => 'Fax', 'fa-female' => 'Female', 'fa-fighter-jet' => 'Fighter jet', 'fa-file' => 'File', 'fa-file-archive-o' => 'File archive o', 'fa-file-audio-o' => 'File audio o', 'fa-file-code-o' => 'File code o', 'fa-file-excel-o' => 'File excel o', 'fa-file-image-o' => 'File image o', 'fa-file-o' => 'File o', 'fa-file-pdf-o' => 'File pdf o', 'fa-file-powerpoint-o' => 'File powerpoint o', 'fa-file-text' => 'File text', 'fa-file-text-o' => 'File text o', 'fa-file-video-o' => 'File video o', 'fa-file-word-o' => 'File word o', 'fa-files-o' => 'Files o', 'fa-film' => 'Film', 'fa-filter' => 'Filter', 'fa-fire' => 'Fire', 'fa-fire-extinguisher' => 'Fire extinguisher', 'fa-firefox' => 'Firefox', 'fa-flag' => 'Flag', 'fa-flag-checkered' => 'Flag checkered', 'fa-flag-o' => 'Flag o', 'fa-flask' => 'Flask', 'fa-flickr' => 'Flickr', 'fa-floppy-o' => 'Floppy o', 'fa-folder' => 'Folder', 'fa-folder-o' => 'Folder o', 'fa-folder-open' => 'Folder open', 'fa-folder-open-o' => 'Folder open o', 'fa-font' => 'Font', 'fa-fonticons' => 'Fonticons', 'fa-forumbee' => 'Forumbee', 'fa-forward' => 'Forward', 'fa-foursquare' => 'Foursquare', 'fa-frown-o' => 'Frown o', 'fa-futbol-o' => 'Futbol o', 'fa-gamepad' => 'Gamepad', 'fa-gavel' => 'Gavel', 'fa-gbp' => 'Gbp', 'fa-genderless' => 'Genderless', 'fa-get-pocket' => 'Get pocket', 'fa-gg' => 'Gg', 'fa-gg-circle' => 'Gg circle', 'fa-gift' => 'Gift', 'fa-git' => 'Git', 'fa-git-square' => 'Git square', 'fa-github' => 'Github', 'fa-github-alt' => 'Github alt', 'fa-github-square' => 'Github square', 'fa-glass' => 'Glass', 'fa-globe' => 'Globe', 'fa-google' => 'Google', 'fa-google-plus' => 'Google plus', 'fa-google-plus-square' => 'Google plus square', 'fa-google-wallet' => 'Google wallet', 'fa-graduation-cap' => 'Graduation cap', 'fa-gratipay' => 'Gratipay', 'fa-h-square' => 'H square', 'fa-hacker-news' => 'Hacker news', 'fa-hand-lizard-o' => 'Hand lizard o', 'fa-hand-o-down' => 'Hand o down', 'fa-hand-o-left' => 'Hand o left', 'fa-hand-o-right' => 'Hand o right', 'fa-hand-o-up' => 'Hand o up', 'fa-hand-paper-o' => 'Hand paper o', 'fa-hand-peace-o' => 'Hand peace o', 'fa-hand-pointer-o' => 'Hand pointer o', 'fa-hand-rock-o' => 'Hand rock o', 'fa-hand-scissors-o' => 'Hand scissors o', 'fa-hand-spock-o' => 'Hand spock o', 'fa-hdd-o' => 'Hdd o', 'fa-header' => 'Header', 'fa-headphones' => 'Headphones', 'fa-heart' => 'Heart', 'fa-heart-o' => 'Heart o', 'fa-heartbeat' => 'Heartbeat', 'fa-history' => 'History', 'fa-home' => 'Home', 'fa-hospital-o' => 'Hospital o', 'fa-hourglass' => 'Hourglass', 'fa-hourglass-end' => 'Hourglass end', 'fa-hourglass-half' => 'Hourglass half', 'fa-hourglass-o' => 'Hourglass o', 'fa-hourglass-start' => 'Hourglass start', 'fa-houzz' => 'Houzz', 'fa-html5' => 'Html5', 'fa-i-cursor' => 'I cursor', 'fa-ils' => 'Ils', 'fa-inbox' => 'Inbox', 'fa-indent' => 'Indent', 'fa-industry' => 'Industry', 'fa-info' => 'Info', 'fa-info-circle' => 'Info circle', 'fa-inr' => 'Inr', 'fa-instagram' => 'Instagram', 'fa-internet-explorer' => 'Internet explorer', 'fa-ioxhost' => 'Ioxhost', 'fa-italic' => 'Italic', 'fa-joomla' => 'Joomla', 'fa-jpy' => 'Jpy', 'fa-jsfiddle' => 'Jsfiddle', 'fa-key' => 'Key', 'fa-keyboard-o' => 'Keyboard o', 'fa-krw' => 'Krw', 'fa-language' => 'Language', 'fa-laptop' => 'Laptop', 'fa-lastfm' => 'Lastfm', 'fa-lastfm-square' => 'Lastfm square', 'fa-leaf' => 'Leaf', 'fa-leanpub' => 'Leanpub', 'fa-lemon-o' => 'Lemon o', 'fa-level-down' => 'Level down', 'fa-level-up' => 'Level up', 'fa-life-ring' => 'Life ring', 'fa-lightbulb-o' => 'Lightbulb o', 'fa-line-chart' => 'Line chart', 'fa-link' => 'Link', 'fa-linkedin' => 'Linkedin', 'fa-linkedin-square' => 'Linkedin square', 'fa-linux' => 'Linux', 'fa-list' => 'List', 'fa-list-alt' => 'List alt', 'fa-list-ol' => 'List ol', 'fa-list-ul' => 'List ul', 'fa-location-arrow' => 'Location arrow', 'fa-lock' => 'Lock', 'fa-long-arrow-down' => 'Long arrow down', 'fa-long-arrow-left' => 'Long arrow left', 'fa-long-arrow-right' => 'Long arrow right', 'fa-long-arrow-up' => 'Long arrow up', 'fa-magic' => 'Magic', 'fa-magnet' => 'Magnet', 'fa-male' => 'Male', 'fa-map' => 'Map', 'fa-map-marker' => 'Map marker', 'fa-map-o' => 'Map o', 'fa-map-pin' => 'Map pin', 'fa-map-signs' => 'Map signs', 'fa-mars' => 'Mars', 'fa-mars-double' => 'Mars double', 'fa-mars-stroke' => 'Mars stroke', 'fa-mars-stroke-h' => 'Mars stroke h', 'fa-mars-stroke-v' => 'Mars stroke v', 'fa-maxcdn' => 'Maxcdn', 'fa-meanpath' => 'Meanpath', 'fa-medium' => 'Medium', 'fa-medkit' => 'Medkit', 'fa-meh-o' => 'Meh o', 'fa-mercury' => 'Mercury', 'fa-microphone' => 'Microphone', 'fa-microphone-slash' => 'Microphone slash', 'fa-minus' => 'Minus', 'fa-minus-circle' => 'Minus circle', 'fa-minus-square' => 'Minus square', 'fa-minus-square-o' => 'Minus square o', 'fa-mobile' => 'Mobile', 'fa-money' => 'Money', 'fa-moon-o' => 'Moon o', 'fa-motorcycle' => 'Motorcycle', 'fa-mouse-pointer' => 'Mouse pointer', 'fa-music' => 'Music', 'fa-neuter' => 'Neuter', 'fa-newspaper-o' => 'Newspaper o', 'fa-object-group' => 'Object group', 'fa-object-ungroup' => 'Object ungroup', 'fa-odnoklassniki' => 'Odnoklassniki', 'fa-odnoklassniki-square' => 'Odnoklassniki square', 'fa-opencart' => 'Opencart', 'fa-openid' => 'Openid', 'fa-opera' => 'Opera', 'fa-optin-monster' => 'Optin monster', 'fa-outdent' => 'Outdent', 'fa-pagelines' => 'Pagelines', 'fa-paint-brush' => 'Paint brush', 'fa-paper-plane' => 'Paper plane', 'fa-paper-plane-o' => 'Paper plane o', 'fa-paperclip' => 'Paperclip', 'fa-paragraph' => 'Paragraph', 'fa-pause' => 'Pause', 'fa-paw' => 'Paw', 'fa-paypal' => 'Paypal', 'fa-pencil' => 'Pencil', 'fa-pencil-square' => 'Pencil square', 'fa-pencil-square-o' => 'Pencil square o', 'fa-phone' => 'Phone', 'fa-phone-square' => 'Phone square', 'fa-picture-o' => 'Picture o', 'fa-pie-chart' => 'Pie chart', 'fa-pied-piper' => 'Pied piper', 'fa-pied-piper-alt' => 'Pied piper alt', 'fa-pinterest' => 'Pinterest', 'fa-pinterest-p' => 'Pinterest p', 'fa-pinterest-square' => 'Pinterest square', 'fa-plane' => 'Plane', 'fa-play' => 'Play', 'fa-play-circle' => 'Play circle', 'fa-play-circle-o' => 'Play circle o', 'fa-plug' => 'Plug', 'fa-plus' => 'Plus', 'fa-plus-circle' => 'Plus circle', 'fa-plus-square' => 'Plus square', 'fa-plus-square-o' => 'Plus square o', 'fa-power-off' => 'Power off', 'fa-print' => 'Print', 'fa-puzzle-piece' => 'Puzzle piece', 'fa-qq' => 'Qq', 'fa-qrcode' => 'Qrcode', 'fa-question' => 'Question', 'fa-question-circle' => 'Question circle', 'fa-quote-left' => 'Quote left', 'fa-quote-right' => 'Quote right', 'fa-random' => 'Random', 'fa-rebel' => 'Rebel', 'fa-recycle' => 'Recycle', 'fa-reddit' => 'Reddit', 'fa-reddit-square' => 'Reddit square', 'fa-refresh' => 'Refresh', 'fa-registered' => 'Registered', 'fa-renren' => 'Renren', 'fa-repeat' => 'Repeat', 'fa-reply' => 'Reply', 'fa-reply-all' => 'Reply all', 'fa-retweet' => 'Retweet', 'fa-road' => 'Road', 'fa-rocket' => 'Rocket', 'fa-rss' => 'Rss', 'fa-rss-square' => 'Rss square', 'fa-rub' => 'Rub', 'fa-safari' => 'Safari', 'fa-scissors' => 'Scissors', 'fa-search' => 'Search', 'fa-search-minus' => 'Search minus', 'fa-search-plus' => 'Search plus', 'fa-sellsy' => 'Sellsy', 'fa-server' => 'Server', 'fa-share' => 'Share', 'fa-share-alt' => 'Share alt', 'fa-share-alt-square' => 'Share alt square', 'fa-share-square' => 'Share square', 'fa-share-square-o' => 'Share square o', 'fa-shield' => 'Shield', 'fa-ship' => 'Ship', 'fa-shirtsinbulk' => 'Shirtsinbulk', 'fa-shopping-cart' => 'Shopping cart', 'fa-sign-in' => 'Sign in', 'fa-sign-out' => 'Sign out', 'fa-signal' => 'Signal', 'fa-simplybuilt' => 'Simplybuilt', 'fa-sitemap' => 'Sitemap', 'fa-skyatlas' => 'Skyatlas', 'fa-skype' => 'Skype', 'fa-slack' => 'Slack', 'fa-sliders' => 'Sliders', 'fa-slideshare' => 'Slideshare', 'fa-smile-o' => 'Smile o', 'fa-sort' => 'Sort', 'fa-sort-alpha-asc' => 'Sort alpha asc', 'fa-sort-alpha-desc' => 'Sort alpha desc', 'fa-sort-amount-asc' => 'Sort amount asc', 'fa-sort-amount-desc' => 'Sort amount desc', 'fa-sort-asc' => 'Sort asc', 'fa-sort-desc' => 'Sort desc', 'fa-sort-numeric-asc' => 'Sort numeric asc', 'fa-sort-numeric-desc' => 'Sort numeric desc', 'fa-soundcloud' => 'Soundcloud', 'fa-space-shuttle' => 'Space shuttle', 'fa-spinner' => 'Spinner', 'fa-spoon' => 'Spoon', 'fa-spotify' => 'Spotify', 'fa-square' => 'Square', 'fa-square-o' => 'Square o', 'fa-stack-exchange' => 'Stack exchange', 'fa-stack-overflow' => 'Stack overflow', 'fa-star' => 'Star', 'fa-star-half' => 'Star half', 'fa-star-half-o' => 'Star half o', 'fa-star-o' => 'Star o', 'fa-steam' => 'Steam', 'fa-steam-square' => 'Steam square', 'fa-step-backward' => 'Step backward', 'fa-step-forward' => 'Step forward', 'fa-stethoscope' => 'Stethoscope', 'fa-sticky-note' => 'Sticky note', 'fa-sticky-note-o' => 'Sticky note o', 'fa-stop' => 'Stop', 'fa-street-view' => 'Street view', 'fa-strikethrough' => 'Strikethrough', 'fa-stumbleupon' => 'Stumbleupon', 'fa-stumbleupon-circle' => 'Stumbleupon circle', 'fa-subscript' => 'Subscript', 'fa-subway' => 'Subway', 'fa-suitcase' => 'Suitcase', 'fa-sun-o' => 'Sun o', 'fa-superscript' => 'Superscript', 'fa-table' => 'Table', 'fa-tablet' => 'Tablet', 'fa-tachometer' => 'Tachometer', 'fa-tag' => 'Tag', 'fa-tags' => 'Tags', 'fa-tasks' => 'Tasks', 'fa-taxi' => 'Taxi', 'fa-television' => 'Television', 'fa-tencent-weibo' => 'Tencent weibo', 'fa-terminal' => 'Terminal', 'fa-text-height' => 'Text height', 'fa-text-width' => 'Text width', 'fa-th' => 'Th', 'fa-th-large' => 'Th large', 'fa-th-list' => 'Th list', 'fa-thumb-tack' => 'Thumb tack', 'fa-thumbs-down' => 'Thumbs down', 'fa-thumbs-o-down' => 'Thumbs o down', 'fa-thumbs-o-up' => 'Thumbs o up', 'fa-thumbs-up' => 'Thumbs up', 'fa-ticket' => 'Ticket', 'fa-times' => 'Times', 'fa-times-circle' => 'Times circle', 'fa-times-circle-o' => 'Times circle o', 'fa-tint' => 'Tint', 'fa-toggle-off' => 'Toggle off', 'fa-toggle-on' => 'Toggle on', 'fa-trademark' => 'Trademark', 'fa-train' => 'Train', 'fa-transgender' => 'Transgender', 'fa-transgender-alt' => 'Transgender alt', 'fa-trash' => 'Trash', 'fa-trash-o' => 'Trash o', 'fa-tree' => 'Tree', 'fa-trello' => 'Trello', 'fa-tripadvisor' => 'Tripadvisor', 'fa-trophy' => 'Trophy', 'fa-truck' => 'Truck', 'fa-try' => 'Try', 'fa-tty' => 'Tty', 'fa-tumblr' => 'Tumblr', 'fa-tumblr-square' => 'Tumblr square', 'fa-twitch' => 'Twitch', 'fa-twitter' => 'Twitter', 'fa-twitter-square' => 'Twitter square', 'fa-umbrella' => 'Umbrella', 'fa-underline' => 'Underline', 'fa-undo' => 'Undo', 'fa-university' => 'University', 'fa-unlock' => 'Unlock', 'fa-unlock-alt' => 'Unlock alt', 'fa-upload' => 'Upload', 'fa-usd' => 'Usd', 'fa-user' => 'User', 'fa-user-md' => 'User md', 'fa-user-plus' => 'User plus', 'fa-user-secret' => 'User secret', 'fa-user-times' => 'User times', 'fa-users' => 'Users', 'fa-venus' => 'Venus', 'fa-venus-double' => 'Venus double', 'fa-venus-mars' => 'Venus mars', 'fa-viacoin' => 'Viacoin', 'fa-video-camera' => 'Video camera', 'fa-vimeo' => 'Vimeo', 'fa-vimeo-square' => 'Vimeo square', 'fa-vine' => 'Vine', 'fa-vk' => 'Vk', 'fa-volume-down' => 'Volume down', 'fa-volume-off' => 'Volume off', 'fa-volume-up' => 'Volume up', 'fa-weibo' => 'Weibo', 'fa-weixin' => 'Weixin', 'fa-whatsapp' => 'Whatsapp', 'fa-wheelchair' => 'Wheelchair', 'fa-wifi' => 'Wifi', 'fa-wikipedia-w' => 'Wikipedia w', 'fa-windows' => 'Windows', 'fa-wordpress' => 'Wordpress', 'fa-wrench' => 'Wrench', 'fa-xing' => 'Xing', 'fa-xing-square' => 'Xing square', 'fa-y-combinator' => 'Y combinator', 'fa-yahoo' => 'Yahoo', 'fa-yelp' => 'Yelp', 'fa-youtube' => 'Youtube', 'fa-youtube-play' => 'Youtube play', 'fa-youtube-square' => 'Youtube square', );

        return apply_filters('ct_font_awesome', $font_awesome_icons);
    }

    /*--------------------------------------*/
    /* Google Fonts
    /*--------------------------------------*/

    function ct_get_fonts() {
        
        $custom_fonts = array( 'Abel' => 'Abel','Abril Fatface' => 'Abril Fatface','Aclonica' => 'Aclonica','Actor' => 'Actor','Adamina' => 'Adamina','Aguafina Script' => 'Aguafina Script','Aladin' => 'Aladin','Albert Sans' => 'Albert Sans','Aldrich' => 'Aldrich','Alegreya' => 'Alegreya','Alegreya Sans' => 'Alegreya Sans','Alice' => 'Alice','Alike' => 'Alike','Alike Angular' => 'Alike Angular','Allan' => 'Allan','Allerta' => 'Allerta','Allerta Stencil' => 'Allerta Stencil','Amaranth' => 'Amaranth','Amatic SC' => 'Amatic SC','Andada' => 'Andada','Andika' => 'Andika','Annie Use Your Telescope' => 'Annie Use Your Telescope','Anonymous Pro' => 'Anonymous Pro','Antic' => 'Antic','Anton' => 'Anton','Arapey' => 'Arapey','Architects Daughter' => 'Architects Daughter','Archivo' => 'Archivo','Archivo Narrow' => 'Archivo Narrow','Arimo' => 'Arimo','Artifika' => 'Artifika','Arvo' => 'Arvo','Asset' => 'Asset','Astloch' => 'Astloch','Atomic Age' => 'Atomic Age','Aubrey' => 'Aubrey','Azeret Mono' => 'Azeret Mono','Bangers' => 'Bangers','Barlow' => 'Barlow','Barlow Condensed' => 'Barlow Condensed','Barlow Semi Condensed' => 'Barlow Semi Condensed','Be Vietnam Pro' => 'Be Vietnam Pro','Bentham' => 'Bentham','Bevan' => 'Bevan','Bigshot One' => 'Bigshot One','BioRhyme' => 'BioRhyme','Bitter' => 'Bitter','Black Ops One' => 'Black Ops One','Bowlby One' => 'Bowlby One','Bowlby One SC' => 'Bowlby One SC','Brawler' => 'Brawler','Bricolage Grotesque' => 'Bricolage Grotesque','Bubblegum Sans' => 'Bubblegum Sans','Buda' => 'Buda','Butcherman Caps' => 'Butcherman Caps','Cabin' => 'Cabin','Cabin Condensed' => 'Cabin Condensed','Cabin Sketch' => 'Cabin Sketch','Cagliostro' => 'Cagliostro','Calligraffitti' => 'Calligraffitti','Candal' => 'Candal','Cantarell' => 'Cantarell','Cardo' => 'Cardo','Carme' => 'Carme','Carter One' => 'Carter One','Caudex' => 'Caudex','Cedarville' => 'Cedarville','Chakra Petch' => 'Chakra Petch','Changa One' => 'Changa One','Cherry Cream Soda' => 'Cherry Cream Soda','Chewy' => 'Chewy','Chicle' => 'Chicle','Chivo' => 'Chivo','Coda' => 'Coda','Coda Caption' => 'Coda Caption','Comfortaa' => 'Comfortaa','Coming Soon' => 'Coming Soon','Contrail One' => 'Contrail One','Convergence' => 'Convergence','Cookie' => 'Cookie','Copse' => 'Copse','Corben' => 'Corben','Cormorant' => 'Cormorant','Cormorant Garamond' => 'Cormorant Garamond','Cousine' => 'Cousine','Coustard' => 'Coustard','Covered By Your Grace' => 'Covered By Your Grace','Crafty Girls' => 'Crafty Girls','Creepster Caps' => 'Creepster Caps','Crimson Text' => 'Crimson Text','Crushed' => 'Crushed','Cuprum' => 'Cuprum','Damion' => 'Damion','Dancing Script' => 'Dancing Script','Dawning of a New Day' => 'Dawning of a New Day','Days One' => 'Days One','Delius' => 'Delius','Delius Swash Caps' => 'Delius Swash Caps','Delius Unicase' => 'Delius Unicase','Devonshire' => 'Devonshire','Didact Gothic' => 'Didact Gothic','DM Sans' => 'DM Sans','DM Serif Display' => 'DM Serif Display','DM Serif Text' => 'DM Serif Text','Dorsa' => 'Dorsa','Dosis' => 'Dosis','Dr Sugiyama' => 'Dr Sugiyama','Droid Sans' => 'Droid Sans','Droid Sans Mono' => 'Droid Sans Mono','Droid Serif' => 'Droid Serif','Eater Caps' => 'Eater Caps','EB Garamond' => 'EB Garamond','Epilogue' => 'Epilogue','Exo 2' => 'Exo 2','Expletus Sans' => 'Expletus Sans','Familjen Grotesk' => 'Familjen Grotesk','Fanwood Text' => 'Fanwood Text','Federant' => 'Federant','Federo' => 'Federo','Figtree' => 'Figtree','Fira Code' => 'Fira Code','Fira Sans' => 'Fira Sans','Fira Sans Condensed' => 'Fira Sans Condensed','Fjord One' => 'Fjord One','Fondamento' => 'Fondamento','Fontdiner Swanky' => 'Fontdiner Swanky','Forum' => 'Forum','Francois One' => 'Francois One','Fraunces' => 'Fraunces','Gentium Basic' => 'Gentium Basic','Gentium Book Basic' => 'Gentium Book Basic','Geo' => 'Geo','Geostar' => 'Geostar','Geostar Fill' => 'Geostar Fill','Give You Glory' => 'Give You Glory','Gloria Hallelujah' => 'Gloria Hallelujah','Goblin One' => 'Goblin One','Gochi Hand' => 'Gochi Hand','Goudy Bookletter 1911' => 'Goudy Bookletter 1911','Gravitas One' => 'Gravitas One','Gruppo' => 'Gruppo','Hammersmith One' => 'Hammersmith One','Herr Von Muellerhoff' => 'Herr Von Muellerhoff','Holtwood One SC' => 'Holtwood One SC','Homemade Apple' => 'Homemade Apple','IBM Plex Mono' => 'IBM Plex Mono','IBM Plex Sans' => 'IBM Plex Sans','IBM Plex Serif' => 'IBM Plex Serif','IM Fell Double Pica' => 'IM Fell Double Pica','IM Fell Double Pica SC' => 'IM Fell Double Pica SC','IM Fell DW Pica' => 'IM Fell DW Pica','IM Fell DW Pica SC' => 'IM Fell DW Pica SC','IM Fell English' => 'IM Fell English','IM Fell English SC' => 'IM Fell English SC','IM Fell French Canon' => 'IM Fell French Canon','IM Fell French Canon SC' => 'IM Fell French Canon SC','IM Fell Great Primer' => 'IM Fell Great Primer','IM Fell Great Primer SC' => 'IM Fell Great Primer SC','Iceland' => 'Iceland','Inconsolata' => 'Inconsolata','Indie Flower' => 'Indie Flower','Inknut Antiqua' => 'Inknut Antiqua','Instrument Sans' => 'Instrument Sans','Instrument Serif' => 'Instrument Serif','Inter' => 'Inter','Irish Grover' => 'Irish Grover','Istok Web' => 'Istok Web','JetBrains Mono' => 'JetBrains Mono','Jockey One' => 'Jockey One','Josefin Sans' => 'Josefin Sans','Josefin Slab' => 'Josefin Slab','Jost' => 'Jost','Judson' => 'Judson','Julee' => 'Julee','Jura' => 'Jura','Just Another Hand' => 'Just Another Hand','Just Me Again Down Here' => 'Just Me Again Down Here','Kameron' => 'Kameron','Kanit' => 'Kanit','Karla' => 'Karla','Kelly Slab' => 'Kelly Slab','Kenia' => 'Kenia','Knewave' => 'Knewave','Kranky' => 'Kranky','Kreon' => 'Kreon','Kristi' => 'Kristi','La Belle Aurore' => 'La Belle Aurore','Lancelot' => 'Lancelot','Lato' => 'Lato','League Script' => 'League Script','Leckerli One' => 'Leckerli One','Lekton' => 'Lekton','Lemon' => 'Lemon','Lexend' => 'Lexend','Lexend Deca' => 'Lexend Deca','Libre Baskerville' => 'Libre Baskerville','Libre Franklin' => 'Libre Franklin','Limelight' => 'Limelight','Linden Hill' => 'Linden Hill','Literata' => 'Literata','Lobster' => 'Lobster','Lobster Two' => 'Lobster Two','Lora' => 'Lora','Love Ya Like A Sister' => 'Love Ya Like A Sister','Loved by the King' => 'Loved by the King','Luckiest Guy' => 'Luckiest Guy','Maiden Orange' => 'Maiden Orange','Mako' => 'Mako','Manrope' => 'Manrope','Marck Script' => 'Marck Script','Marvel' => 'Marvel','Mate' => 'Mate','Mate SC' => 'Mate SC','Maven Pro' => 'Maven Pro','Meddon' => 'Meddon','MedievalSharp' => 'MedievalSharp','Megrim' => 'Megrim','Merienda One' => 'Merienda One','Merriweather' => 'Merriweather','Metrophobic' => 'Metrophobic','Michroma' => 'Michroma','Miltonian' => 'Miltonian','Miltonian Tattoo' => 'Miltonian Tattoo','Miss Fajardose' => 'Miss Fajardose','Miss Saint Delafield' => 'Miss Saint Delafield','Modern Antiqua' => 'Modern Antiqua','Molengo' => 'Molengo','Monofett' => 'Monofett','Monoton' => 'Monoton','Monsieur La Doulaise' => 'Monsieur La Doulaise','Montez' => 'Montez','Montserrat' => 'Montserrat','Mountains of Christmas' => 'Mountains of Christmas','Mr Bedford' => 'Mr Bedford','Mr Dafoe' => 'Mr Dafoe','Mr De Haviland' => 'Mr De Haviland','Mrs Sheppards' => 'Mrs Sheppards','Muli' => 'Muli','Mulish' => 'Mulish','Neucha' => 'Neucha','Neuton' => 'Neuton','News Cycle' => 'News Cycle','Newsreader' => 'Newsreader','Niconne' => 'Niconne','Nixie One' => 'Nixie One','Nobile' => 'Nobile','Nosifer Caps' => 'Nosifer Caps','Nothing You Could Do' => 'Nothing You Could Do','Noto Sans' => 'Noto Sans','Noto Serif' => 'Noto Serif','Nova Cut' => 'Nova Cut','Nova Flat' => 'Nova Flat','Nova Mono' => 'Nova Mono','Nova Oval' => 'Nova Oval','Nova Round' => 'Nova Round','Nova Script' => 'Nova Script','Nova Slim' => 'Nova Slim','Nova Square' => 'Nova Square','Numans' => 'Numans','Nunito' => 'Nunito','Nunito Sans' => 'Nunito Sans','Old Standard TT' => 'Old Standard TT','Onest' => 'Onest','Open Sans' => 'Open Sans','Open Sans Condensed' => 'Open Sans Condensed','Orbitron' => 'Orbitron','Oswald' => 'Oswald','Outfit' => 'Outfit','Over the Rainbow' => 'Over the Rainbow','Overpass' => 'Overpass','Ovo' => 'Ovo','Pacifico' => 'Pacifico','Passero One' => 'Passero One','Patrick Hand' => 'Patrick Hand','Paytone One' => 'Paytone One','Permanent Marker' => 'Permanent Marker','Petrona' => 'Petrona','Philosopher' => 'Philosopher','Piedra' => 'Piedra','Pinyon Script' => 'Pinyon Script','Play' => 'Play','Playfair Display' => 'Playfair Display','Plus Jakarta Sans' => 'Plus Jakarta Sans','Podkova' => 'Podkova','Poller One' => 'Poller One','Poly' => 'Poly','Pompiere' => 'Pompiere','Poppins' => 'Poppins','Prata' => 'Prata','Prociono' => 'Prociono','Proza Libre' => 'Proza Libre','PT Sans' => 'PT Sans','PT Sans Caption' => 'PT Sans Caption','PT Sans Narrow' => 'PT Sans Narrow','PT Serif' => 'PT Serif','PT Serif Caption' => 'PT Serif Caption','Puritan' => 'Puritan','Quattrocento' => 'Quattrocento','Quattrocento Sans' => 'Quattrocento Sans','Questrial' => 'Questrial','Quicksand' => 'Quicksand','Radley' => 'Radley','Rajdhani' => 'Rajdhani','Raleway' => 'Raleway','Rammetto One' => 'Rammetto One','Rancho' => 'Rancho','Rationale' => 'Rationale','Red Hat Display' => 'Red Hat Display','Red Hat Mono' => 'Red Hat Mono','Red Hat Text' => 'Red Hat Text','Redressed' => 'Redressed','Reenie Beanie' => 'Reenie Beanie','Ribeye' => 'Ribeye','Ribeye Marrow' => 'Ribeye Marrow','Righteous' => 'Righteous','Roboto' => 'Roboto','Roboto Condensed' => 'Roboto Condensed','Roboto Mono' => 'Roboto Mono','Roboto Serif' => 'Roboto Serif','Rochester' => 'Rochester','Rock Salt' => 'Rock Salt','Rokkitt' => 'Rokkitt','Rosario' => 'Rosario','Rufina' => 'Rufina','Ruslan Display' => 'Ruslan Display','Salsa' => 'Salsa','Sancreek' => 'Sancreek','Sansita One' => 'Sansita One','Satisfy' => 'Satisfy','Schoolbell' => 'Schoolbell','Shadows Into Light' => 'Shadows Into Light','Shanti' => 'Shanti','Short Stack' => 'Short Stack','Sigmar One' => 'Sigmar One','Signika' => 'Signika','Signika Negative' => 'Signika Negative','Six Caps' => 'Six Caps','Slackey' => 'Slackey','Smokum' => 'Smokum','Smythe' => 'Smythe','Sniglet' => 'Sniglet','Snippet' => 'Snippet','Sora' => 'Sora','Sorts Mill Goudy' => 'Sorts Mill Goudy','Source Code Pro' => 'Source Code Pro','Source Sans 3' => 'Source Sans 3','Source Sans Pro' => 'Source Sans Pro','Source Serif 4' => 'Source Serif 4','Space Grotesk' => 'Space Grotesk','Space Mono' => 'Space Mono','Special Elite' => 'Special Elite','Spectral' => 'Spectral','Spinnaker' => 'Spinnaker','Spirax' => 'Spirax','Stardos Stencil' => 'Stardos Stencil','Sue Ellen Francisco' => 'Sue Ellen Francisco','Sunshiney' => 'Sunshiney','Supermercado One' => 'Supermercado One','Swanky and Moo Moo' => 'Swanky and Moo Moo','Syncopate' => 'Syncopate','Syne' => 'Syne','Tangerine' => 'Tangerine','Tenor Sans' => 'Tenor Sans','Terminal Dosis' => 'Terminal Dosis','The Girl Next Door' => 'The Girl Next Door','Tienne' => 'Tienne','Tinos' => 'Tinos','Tulpen One' => 'Tulpen One','Ubuntu' => 'Ubuntu','Ubuntu Condensed' => 'Ubuntu Condensed','Ubuntu Mono' => 'Ubuntu Mono','Ultra' => 'Ultra','UnifrakturCook' => 'UnifrakturCook','UnifrakturMaguntia' => 'UnifrakturMaguntia','Unkempt' => 'Unkempt','Unlock' => 'Unlock','Unna' => 'Unna','Urbanist' => 'Urbanist','Varela' => 'Varela','Varela Round' => 'Varela Round','Vast Shadow' => 'Vast Shadow','Vibur' => 'Vibur','Vidaloka' => 'Vidaloka','Volkhov' => 'Volkhov','Vollkorn' => 'Vollkorn','Voltaire' => 'Voltaire','VT323' => 'VT323','Waiting for the Sunrise' => 'Waiting for the Sunrise','Wallpoet' => 'Wallpoet','Walter Turncoat' => 'Walter Turncoat','Wire One' => 'Wire One','Wix Madefor Display' => 'Wix Madefor Display','Wix Madefor Text' => 'Wix Madefor Text','Work Sans' => 'Work Sans','Yanone Kaffeesatz' => 'Yanone Kaffeesatz','Yellowtail' => 'Yellowtail','Yeseva One' => 'Yeseva One','Zeyada' => 'Zeyada','Zilla Slab' => 'Zilla Slab');
        
        return apply_filters('ct_get_fonts', $custom_fonts);

    }

    /*--------------------------------------*/
    /* Country Codes
    /*--------------------------------------*/

    function ct_country_codes() {

        $ct_countries = array(
            'AF' => 'Afghanistan', 'AX' => 'Aland Islands', 'AL' => 'Albania', 'DZ' => 'Algeria', 'AS' => 'American Samoa', 'AD' => 'Andorra', 'AO' => 'Angola', 'AI' => 'Anguilla', 'AQ' => 'Antarctica', 'AG' => 'Antigua And Barbuda', 'AR' => 'Argentina', 'AM' => 'Armenia', 'AW' => 'Aruba', 'AU' => 'Australia', 'AT' => 'Austria', 'AZ' => 'Azerbaijan', 'BS' => 'Bahamas', 'BH' => 'Bahrain', 'BD' => 'Bangladesh', 'BB' => 'Barbados', 'BY' => 'Belarus', 'BE' => 'Belgium', 'BZ' => 'Belize', 'BJ' => 'Benin', 'BM' => 'Bermuda', 'BT' => 'Bhutan', 'BO' => 'Bolivia', 'BA' => 'Bosnia And Herzegovina', 'BW' => 'Botswana', 'BV' => 'Bouvet Island', 'BR' => 'Brazil', 'IO' => 'British Indian Ocean Territory', 'BN' => 'Brunei Darussalam', 'BG' => 'Bulgaria', 'BF' => 'Burkina Faso', 'BI' => 'Burundi', 'KH' => 'Cambodia', 'CM' => 'Cameroon', 'CA' => 'Canada', 'CV' => 'Cape Verde', 'KY' => 'Cayman Islands', 'CF' => 'Central African Republic', 'TD' => 'Chad', 'CL' => 'Chile', 'CN' => 'China', 'CX' => 'Christmas Island', 'CC' => 'Cocos (Keeling) Islands', 'CO' => 'Colombia', 'KM' => 'Comoros', 'CG' => 'Congo', 'CD' => 'Congo, Democratic Republic', 'CK' => 'Cook Islands', 'CR' => 'Costa Rica', 'CI' => 'Cote D\'Ivoire', 'HR' => 'Croatia', 'CU' => 'Cuba', 'CY' => 'Cyprus', 'CZ' => 'Czech Republic', 'DK' => 'Denmark', 'DJ' => 'Djibouti', 'DM' => 'Dominica', 'DO' => 'Dominican Republic', 'EC' => 'Ecuador', 'EG' => 'Egypt', 'SV' => 'El Salvador', 'GQ' => 'Equatorial Guinea', 'ER' => 'Eritrea', 'EE' => 'Estonia', 'ET' => 'Ethiopia', 'FK' => 'Falkland Islands (Malvinas)', 'FO' => 'Faroe Islands', 'FJ' => 'Fiji', 'FI' => 'Finland', 'FR' => 'France', 'GF' => 'French Guiana', 'PF' => 'French Polynesia', 'TF' => 'French Southern Territories', 'GA' => 'Gabon', 'GM' => 'Gambia', 'GE' => 'Georgia', 'DE' => 'Germany', 'GH' => 'Ghana', 'GI' => 'Gibraltar', 'GR' => 'Greece', 'GL' => 'Greenland', 'GD' => 'Grenada', 'GP' => 'Guadeloupe', 'GU' => 'Guam', 'GT' => 'Guatemala', 'GG' => 'Guernsey', 'GN' => 'Guinea', 'GW' => 'Guinea-Bissau', 'GY' => 'Guyana', 'HT' => 'Haiti', 'HM' => 'Heard Island & Mcdonald Islands', 'VA' => 'Holy See (Vatican City State)', 'HN' => 'Honduras', 'HK' => 'Hong Kong', 'HU' => 'Hungary', 'IS' => 'Iceland', 'IN' => 'India', 'ID' => 'Indonesia', 'IR' => 'Iran, Islamic Republic Of', 'IQ' => 'Iraq', 'IE' => 'Ireland', 'IM' => 'Isle Of Man', 'IL' => 'Israel', 'IT' => 'Italy', 'JM' => 'Jamaica', 'JP' => 'Japan', 'JE' => 'Jersey', 'JO' => 'Jordan', 'KZ' => 'Kazakhstan', 'KE' => 'Kenya', 'KI' => 'Kiribati', 'KR' => 'Korea', 'KW' => 'Kuwait', 'KG' => 'Kyrgyzstan', 'LA' => 'Lao People\'s Democratic Republic', 'LV' => 'Latvia', 'LB' => 'Lebanon', 'LS' => 'Lesotho', 'LR' => 'Liberia', 'LY' => 'Libyan Arab Jamahiriya', 'LI' => 'Liechtenstein', 'LT' => 'Lithuania', 'LU' => 'Luxembourg', 'MO' => 'Macao', 'MK' => 'Macedonia', 'MG' => 'Madagascar', 'MW' => 'Malawi', 'MY' => 'Malaysia', 'MV' => 'Maldives', 'ML' => 'Mali', 'MT' => 'Malta', 'MH' => 'Marshall Islands', 'MQ' => 'Martinique', 'MR' => 'Mauritania', 'MU' => 'Mauritius', 'YT' => 'Mayotte', 'MX' => 'Mexico', 'FM' => 'Micronesia, Federated States Of', 'MD' => 'Moldova', 'MC' => 'Monaco', 'MN' => 'Mongolia', 'ME' => 'Montenegro', 'MS' => 'Montserrat', 'MA' => 'Morocco', 'MZ' => 'Mozambique', 'MM' => 'Myanmar', 'NA' => 'Namibia', 'NR' => 'Nauru', 'NP' => 'Nepal', 'NL' => 'Netherlands', 'AN' => 'Netherlands Antilles', 'NC' => 'New Caledonia', 'NZ' => 'New Zealand', 'NI' => 'Nicaragua', 'NE' => 'Niger', 'NG' => 'Nigeria', 'NU' => 'Niue', 'NF' => 'Norfolk Island', 'MP' => 'Northern Mariana Islands', 'NO' => 'Norway', 'OM' => 'Oman', 'PK' => 'Pakistan', 'PW' => 'Palau', 'PS' => 'Palestinian Territory, Occupied', 'PA' => 'Panama', 'PG' => 'Papua New Guinea', 'PY' => 'Paraguay', 'PE' => 'Peru', 'PH' => 'Philippines', 'PN' => 'Pitcairn', 'PL' => 'Poland', 'PT' => 'Portugal', 'PR' => 'Puerto Rico', 'QA' => 'Qatar', 'RE' => 'Reunion', 'RO' => 'Romania', 'RU' => 'Russian Federation', 'RW' => 'Rwanda', 'BL' => 'Saint Barthelemy', 'SH' => 'Saint Helena', 'KN' => 'Saint Kitts And Nevis', 'LC' => 'Saint Lucia', 'MF' => 'Saint Martin', 'PM' => 'Saint Pierre And Miquelon', 'VC' => 'Saint Vincent And Grenadines', 'WS' => 'Samoa', 'SM' => 'San Marino', 'ST' => 'Sao Tome And Principe', 'SA' => 'Saudi Arabia', 'SN' => 'Senegal', 'RS' => 'Serbia', 'SC' => 'Seychelles', 'SL' => 'Sierra Leone', 'SG' => 'Singapore', 'SK' => 'Slovakia', 'SI' => 'Slovenia', 'SB' => 'Solomon Islands', 'SO' => 'Somalia', 'ZA' => 'South Africa', 'GS' => 'South Georgia And Sandwich Isl.', 'ES' => 'Spain', 'LK' => 'Sri Lanka', 'SD' => 'Sudan', 'SR' => 'Suriname', 'SJ' => 'Svalbard And Jan Mayen', 'SZ' => 'Swaziland', 'SE' => 'Sweden', 'CH' => 'Switzerland', 'SY' => 'Syrian Arab Republic', 'TW' => 'Taiwan', 'TJ' => 'Tajikistan', 'TZ' => 'Tanzania', 'TH' => 'Thailand', 'TL' => 'Timor-Leste', 'TG' => 'Togo', 'TK' => 'Tokelau', 'TO' => 'Tonga', 'TT' => 'Trinidad And Tobago', 'TN' => 'Tunisia', 'TR' => 'Turkey', 'TM' => 'Turkmenistan', 'TC' => 'Turks And Caicos Islands', 'TV' => 'Tuvalu', 'UG' => 'Uganda', 'UA' => 'Ukraine', 'AE' => 'United Arab Emirates', 'GB' => 'United Kingdom', 'US' => 'United States', 'UM' => 'United States Outlying Islands', 'UY' => 'Uruguay', 'UZ' => 'Uzbekistan', 'VU' => 'Vanuatu', 'VE' => 'Venezuela', 'VN' => 'Viet Nam', 'VG' => 'Virgin Islands, British', 'VI' => 'Virgin Islands, U.S.', 'WF' => 'Wallis And Futuna', 'EH' => 'Western Sahara', 'YE' => 'Yemen', 'ZM' => 'Zambia', 'ZW' => 'Zimbabwe',
        );
        return apply_filters('ct_country_codes', $ct_countries);
    }

    /*--------------------------------------*/
    /* Start Fields
     *
     * Section groups — each section carries a 'group' key matching:
     *   Getting Started | General | Appearance | Listings |
     *   Integrations    | User Accounts | Security | Advanced
     *
     * To find a group's sections, search for: 'group' => 'Group Name'
     /*--------------------------------------*/

    /* =========================================================================
     * GROUP: Getting Started
     * ========================================================================= */

 if ( get_option( 're7_show_onboarding', false ) && ! get_option( 're7_onboarding_complete', false ) ) :

    $re7_onboarding_steps_config = re7_get_onboarding_steps_config();

    $re7_saved_steps  = get_option( 're7_onboarding_steps', array() );
    $re7_checked_count = 0;
    foreach ( $re7_onboarding_steps_config as $re7_step ) {
        if ( ! empty( $re7_saved_steps[ $re7_step['id'] ] ) ) {
            $re7_checked_count++;
        }
    }
    $re7_total_steps = count( $re7_onboarding_steps_config );
    $re7_progress_pct = $re7_total_steps > 0 ? round( ( $re7_checked_count / $re7_total_steps ) * 100 ) : 0;

    ob_start();
    ?>
    <div class="ct-onboarding-checklist" id="ct-onboarding-checklist" data-total="<?php echo esc_attr( $re7_total_steps ); ?>">

        <div class="ct-onboarding-progress">
            <div class="ct-onboarding-progress__bar">
                <div class="ct-onboarding-progress__fill" style="width:<?php echo esc_attr( $re7_progress_pct ); ?>%"></div>
            </div>
            <span class="ct-onboarding-progress__label">
                <span class="ct-onboarding-count"><?php echo esc_html( $re7_checked_count ); ?></span><?php echo ' ' . esc_html( sprintf( __( 'of %d complete', 'contempo' ), $re7_total_steps ) ); ?>
            </span>
        </div>

        <ul class="ct-onboarding-steps">
            <?php foreach ( $re7_onboarding_steps_config as $re7_step ) :
                $is_checked = ! empty( $re7_saved_steps[ $re7_step['id'] ] );
            ?>
            <li class="ct-onboarding-step<?php echo $is_checked ? ' ct-onboarding-step--done' : ''; ?>" data-step="<?php echo esc_attr( $re7_step['id'] ); ?>">
                <label class="ct-onboarding-step__check">
                    <input
                        type="checkbox"
                        class="ct-onboarding-checkbox"
                        data-step="<?php echo esc_attr( $re7_step['id'] ); ?>"
                        <?php checked( $is_checked ); ?>
                    />
                </label>
                <?php
                $re7_nav_href   = ! empty( $re7_step['url'] )
                    ? esc_url( admin_url( $re7_step['url'] ) )
                    : '#' . esc_attr( $re7_step['section'] );
                // Only open a new tab for genuinely external URLs (docs, etc.).
                // Internal admin URLs navigate in the same tab.
                $re7_url_is_external = ! empty( $re7_step['url'] ) && str_starts_with( $re7_step['url'], 'http' );
                $re7_nav_target      = $re7_url_is_external ? ' target="_blank" rel="noopener"' : '';
                ?>
                <div class="ct-onboarding-step__content">
                    <span class="ct-onboarding-step__name"><?php echo wp_kses_post( $re7_step['label'] ); ?></span>
                    <div class="ct-onboarding-step__links">
                        <a href="<?php echo $re7_nav_href; ?>"<?php echo $re7_nav_target; ?> class="ct-onboarding-step__nav"><?php echo wp_kses_post( $re7_step['nav'] ); ?></a>
                        <?php if ( ! empty( $re7_step['docs_url'] ) ) : ?>
                            <a href="<?php echo esc_url( $re7_step['docs_url'] ); ?>" class="ct-onboarding-step__docs" target="_blank" rel="noopener"><?php echo wp_kses_post( $re7_step['docs_nav'] ); ?></a>
                        <?php endif; ?>
                    </div>
                    <span class="ct-onboarding-step__desc"><?php echo esc_html( $re7_step['desc'] ); ?></span>
                </div>
                <a href="<?php echo $re7_nav_href; ?>"<?php echo $re7_nav_target; ?> class="ct-onboarding-step__go-btn"><?php esc_html_e( 'Configure', 'contempo' ); ?> &rarr;</a>
            </li>
            <?php endforeach; ?>
        </ul>

        <div class="ct-onboarding-complete-wrap" style="<?php echo $re7_checked_count < $re7_total_steps ? 'display:none;' : ''; ?>">
            <button type="button" class="ct-onboarding-complete-btn" id="ct-onboarding-complete-btn">
                <?php esc_html_e( 'Complete Setup &amp; Hide This Page', 'contempo' ); ?>
            </button>
        </div>

    </div>
    <?php
    $re7_checklist_html = ob_get_clean();

    CT_Settings::set_section( $opt_name, array(
        'title'  => __( 'Getting Started', 'contempo' ),
        'id'     => 'getting-started',
        'group'  => 'Getting Started',
        'icon'   => 'fas fa-rocket',
        'fields' => array(

            array(
                'id'    => 'info_getting_started_welcome',
                'type'  => 'info',
                'style' => 'info',
                'title' => __( 'Welcome to Real Estate 7!', 'contempo' ),
                'desc'  => __( 'Check off each item below as you configure your site.', 'contempo' ),
            ),
            array(
                'id'       => 'info_getting_started_checklist',
                'type'     => 'raw',
                'markdown' => false,
                'content'  => $re7_checklist_html,
            ),

        ),
    ) );

endif;

    /* =========================================================================
     * GROUP: General
     * Sections: General Settings, Header Layout, Logo, Top Bar, Homepage
     * ========================================================================= */

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'General Settings', 'contempo' ),
        'id'               => 'general-settings',
        'group'            => 'General',
        'icon'             => 'fas fa-cogs',
        'fields'           => array(
            array (
                'desc' => 'Choose if you would like to a full width or boxed layout.',
                'id' => 'ct_boxed',
                'type' => 'select',
                'options' => array (
                    'full-width' => 'Full Width (1240px Max)',
                    'full-width-two' => 'Full Width Two (90% of Browser Width)',
                    'boxed' => 'Boxed',
                ),
                'title' => 'Full Width or Boxed Layout?',
                'default' => 'full-width',
            ),
            array (
                    'desc' => 'Select a pre-made skin either original or minimal.',
                    'id' => 'ct_skin',
                    'type' => 'select',
                    'options' => array (
                        'original' => 'Original',
                        'minimal' => 'Minimal',
                    ),
                    'title' => 'Select a Skin',
                    'default' => 'minimal',
            ),
            array (
                'desc' => 'Activate the RTL (Right to Left) layout only if your website needs to support languages read from right to left, such as Arabic or Hebrew. This changes the website\'s layout direction. Use this option carefully to avoid unintended layout reversal.',
                'id' => 'ct_rtl',
                'type' => 'switch',
                'title' => 'Enable RTL',
                'default' => 'no',
            ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Header Layout', 'contempo' ),
        'id'               => 'header',
        'group'            => 'General',
        'icon'             => 'fas fa-columns',
        'fields'           => array(
            array (
                'desc' => 'Choose if you would like the header to stick to the top of the browser when a user scrolls your site.',
                'id' => 'ct_sticky_header',
                'type' => 'switch',
                'title' => 'Sticky Header?',
                'default' => 'yes',
            ),
            array (
                'desc' => 'Choose if you would like the header to always stick to the top of the browser or only show sticky when the user is scrolling back up.',
                'id' => 'ct_sticky_header_type',
                'type' => 'select',
                'options' => array (
                    'always_sticky' => 'Always Sticky',
                    'only_on_scroll_up' => 'Only Sticky on Scroll Up',
                ),
                'required' => array('ct_sticky_header','=','yes'),
                'title' => 'Sticky Header Type',
                'default' => 'always_sticky',
            ),
            array (
                'desc' => 'Choose if you would like the header to be transparent this ONLY applies to the homepage.',
                'id' => 'ct_trans_header',
                'type' => 'switch',
                'title' => 'Transparent Header on Homepage?',
                'default' => 'no',
            ),
            array (
                    //'desc' => 'Select left, center, right logo alignment or none.',
                    'id' => 'ct_header_style',
                    'type' => 'image_select',
                    'options' => array (
                        'one'   => array( 'title' => 'Style 1', 'img' => get_template_directory_uri() . '/admin/images/header-one.png' ),
                        'two'   => array( 'title' => 'Style 2', 'img' => get_template_directory_uri() . '/admin/images/header-two.png' ),
                        'three' => array( 'title' => 'Style 3', 'img' => get_template_directory_uri() . '/admin/images/header-three.png' ),
                        'four'  => array( 'title' => 'Style 4', 'img' => get_template_directory_uri() . '/admin/images/header-four.png' ),
                    ),
                    'title' => 'Header Style',
                    'default' => 'one',
            ),
            array (
                    'desc' => 'Select left, center, right logo alignment or none. <strong>NOTE:</strong> This only applies to Header Style One.',
                    'id' => 'ct_header_layout',
                    'type' => 'select',
                    'options' => array (
                        'left' => 'Logo Left',
                        'center' => 'Logo Center',
                        'right' => 'Logo Right',
                        'none' => 'None',
                    ),
                    'required' => array( 
                        array( 'ct_header_style', '!=', 'two' ), 
                        array( 'ct_header_style', '!=', 'three' ), 
                        array( 'ct_header_style', '!=', 'four' ), 
                    ),
                    'title' => 'Header Layout for Style One',
                    'default' => 'left',
            ),
            array(
                'id' => 'info_header_search_note',
                'type' => 'info',
                'style' => 'info',
                'title' => __('', 'contempo'),
                'desc' => __('To enable/configure the header search bar, see <strong>Listings &rarr; Advanced Search &rarr; Header</strong>.', 'contempo')
            ),
            array(
                'id' => 'header-info-one',
                'type' => 'section',
                'title' => __('Column One', 'contempo'),
                'subtitle' => 'First column of information displayed to the right of the logo.',
                'required' => array( 
                    array( 'ct_header_style', '!=', 'one' ), 
                    array( 'ct_header_style', '!=', 'three' ), 
                    array( 'ct_header_style', '!=', 'four' ), 
                ),
                'indent' => true 
            ),
                array (
                    'desc' => '',
                    'id' => 'ct_header_info_one_title',
                    'type' => 'text',
                    'title' => 'Title',
                    'default' => 'Contact Us',
                ),
                array (
                    'desc' => '',
                    'id' => 'ct_header_info_one_text',
                    'type' => 'text',
                    'title' => 'Text',
                    'default' => '1-888-555-7896',
                ),
                array(
                    'id'=>'ct_header_info_one_icon',
                    'type' => 'select', 
                    'title' => __('Icon', 'contempo'),
                    'default'     => 'fa-phone',
                    'options' => ct_font_awesome(),
                ),
            array(
                'id' => 'header-info-one-end',
                'type' => 'section',
                'indent' => false 
            ),
            array(
                'id' => 'header-info-two',
                'type' => 'section',
                'title' => __('Column Two', 'contempo'),
                'subtitle' => 'Second column of information displayed to the right of the logo.',
                'required' => array( 
                    array( 'ct_header_style', '!=', 'one' ), 
                    array( 'ct_header_style', '!=', 'three' ), 
                    array( 'ct_header_style', '!=', 'four' ), 
                ),
                'indent' => true 
            ),
                array (
                    'desc' => '',
                    'id' => 'ct_header_info_two_title',
                    'type' => 'text',
                    'title' => 'Title',
                    'default' => '101 First Ave',
                ),
                array (
                    'desc' => '',
                    'id' => 'ct_header_info_two_text',
                    'type' => 'text',
                    'title' => 'Text',
                    'default' => 'San Diego, CA',
                ),
                array(
                    'id'=>'ct_header_info_two_icon',
                    'type' => 'select',   
                    'title' => __('Icon', 'contempo'),
                    'default'     => 'fa-map-marker',
                    'options' => ct_font_awesome(),
                ),
            array(
                'id' => 'header-info-two-end',
                'type' => 'section',
                'indent' => false 
            ),
            array(
                'id' => 'header-info-three',
                'type' => 'section',
                'title' => __('Column Three', 'contempo'),
                'subtitle' => 'Third column of information displayed to the right of the logo.',
                'required' => array( 
                    array( 'ct_header_style', '!=', 'one' ), 
                    array( 'ct_header_style', '!=', 'three' ), 
                    array( 'ct_header_style', '!=', 'four' ), 
                ),
                'indent' => true 
            ),
                array (
                    'desc' => '',
                    'id' => 'ct_header_info_three_title',
                    'type' => 'text',
                    'title' => 'Title',
                    'default' => '8AM-5PM',
                ),
                array (
                    'desc' => '',
                    'id' => 'ct_header_info_three_text',
                    'type' => 'text',
                    'title' => 'Text',
                    'default' => 'Monday-Friday',
                ),
                array(
                    'id'=>'ct_header_info_three_icon',
                    'type' => 'select',  
                    'title' => __('Icon', 'contempo'),
                    'default'     => 'fa-clock-o',
                    'options' => ct_font_awesome(),
                ),
             array(
                'id' => 'header-info-three-end',
                'type' => 'section',
                'indent' => false 
            ),

            array(
                'id'       => 'ct_header_info_text_color',
                'type'     => 'color_rgba',
                'title'    => __( 'Header Info Text Color', 'contempo' ),
                'desc'     => __( 'Color for the title, text, and icon in the header info columns. Leave blank to use the theme default (white on dark headers, dark on the minimal skin).', 'contempo' ),
                'required' => array(
                    array( 'ct_header_style', '!=', 'one' ),
                    array( 'ct_header_style', '!=', 'three' ),
                    array( 'ct_header_style', '!=', 'four' ),
                ),
            ),

            // ── Header Style 4 Overlay Options ────────────────────────────────────
            array(
                'id'       => 'header-four-overlay',
                'type'     => 'section',
                'title'    => __( 'Overlay Options', 'contempo' ),
                'subtitle' => 'Colors and logo for the full-screen nav overlay (Style 4 only).',
                'required' => array( 'ct_header_style', '=', 'four' ),
                'indent'   => true,
            ),
                array(
                    'id'      => 'ct_header_four_overlay_bg',
                    'type'    => 'color_rgba',
                    'title'   => 'Overlay Background Color',
                    'desc'    => 'Background color of the full-screen navigation overlay.',
                    'default' => array( 'color' => '#121212', 'alpha' => '1', 'rgba' => 'rgba(18,18,18,1)' ),
                    'required' => array( 'ct_header_style', '=', 'four' ),
                ),
                array(
                    'id'      => 'ct_header_four_overlay_link_color',
                    'type'    => 'color_rgba',
                    'title'   => 'Overlay Nav Link Color',
                    'desc'    => 'Text color of navigation links inside the overlay.',
                    'default' => array( 'color' => '#ffffff', 'alpha' => '1', 'rgba' => 'rgba(255,255,255,1)' ),
                    'required' => array( 'ct_header_style', '=', 'four' ),
                ),
                array(
                    'id'      => 'ct_header_four_overlay_link_hover_color',
                    'type'    => 'color_rgba',
                    'title'   => 'Overlay Nav Link Hover Color',
                    'desc'    => 'Text color of navigation links on hover inside the overlay.',
                    'default' => array( 'color' => '#b4a078', 'alpha' => '1', 'rgba' => 'rgba(180,160,120,1)' ),
                    'required' => array( 'ct_header_style', '=', 'four' ),
                ),
                array(
                    'id'       => 'ct_header_four_overlay_logo',
                    'type'     => 'media',
                    'title'    => 'Nav Overlay Logo',
                    'desc'     => 'Upload a logo for the overlay — a light or white version works best on dark backgrounds. Falls back to your standard logo if not set.',
                    'url'      => true,
                    'required' => array( 'ct_header_style', '=', 'four' ),
                ),
                array(
                    'id'       => 'ct_header_four_overlay_logo_highres',
                    'type'     => 'media',
                    'title'    => 'Nav Overlay Logo @2x',
                    'desc'     => 'Upload a @2x version of the overlay logo for high-resolution displays.',
                    'url'      => true,
                    'required' => array( 'ct_header_style', '=', 'four' ),
                ),
            array(
                'id'     => 'header-four-overlay-end',
                'type'   => 'section',
                'indent' => false,
            ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Logo', 'contempo' ),
        'id'               => 'logo',
        'group'            => 'General',
        'subsection'       => true,
        'fields'           => array(

            // ── Logo Type ─────────────────────────────────────────────────────────
            array(
                'id'      => 'ct_text_logo',
                'type'    => 'switch',
                'title'   => 'Use Text Logo?',
                'desc'    => 'Use the site title (set in WP Settings > General) in place of an image logo.',
                'default' => 'no',
            ),
            array(
                'id'      => 'ct_text_logo_font_size',
                'type'    => 'slider',
                'title'   => 'Text Logo Font Size',
                'desc'    => 'Font size for the site title logo.',
                'min'     => 16,
                'max'     => 60,
                'step'    => 1,
                'unit'    => 'px',
                'default' => 28,
                'required' => array('ct_text_logo','equals','yes'),
            ),

            // ── Image Logo ────────────────────────────────────────────────────────
            array(
                'id'       => 'ct_logo',
                'type'     => 'media',
                'title'    => 'Logo',
                'desc'     => 'Upload a logo here — recommend using a PNG.',
                'url'      => true,
                'required' => array('ct_text_logo','!=','yes'),
            ),
            array(
                'id'       => 'ct_logo_highres',
                'type'     => 'media',
                'title'    => 'Logo @2x',
                'desc'     => 'Upload a @2x logo for high resolution displays — recommend using a PNG. <a href="https://line25.com/tutorials/how-to-create-retina-graphics-for-your-web-designs" target="_blank">More Information on Creating @2x Images</a>',
                'url'      => true,
                'required' => array('ct_text_logo','!=','yes'),
            ),
            array(
                'id'       => 'ct_logo_trans',
                'type'     => 'media',
                'title'    => 'Logo (Transparent Header)',
                'desc'     => 'Upload a logo here — recommend using a PNG. Only used for the transparent header option.',
                'url'      => true,
                'required' => array( array('ct_text_logo','!=','yes'), array('ct_trans_header','equals','yes') ),
            ),
            array(
                'id'       => 'ct_logo_highres_trans',
                'type'     => 'media',
                'title'    => 'Logo @2x (Transparent Header)',
                'desc'     => 'Upload a @2x logo for high resolution displays — recommend using a PNG. Only used for the transparent header option. <a href="https://line25.com/tutorials/how-to-create-retina-graphics-for-your-web-designs" target="_blank">More Information on Creating @2x Images</a>',
                'url'      => true,
                'required' => array( array('ct_text_logo','!=','yes'), array('ct_trans_header','equals','yes') ),
            ),
            array(
                'id'       => 'ct_logo_sticky',
                'type'     => 'media',
                'title'    => 'Logo (Sticky Header > Active)',
                'desc'     => 'Optionally upload a logo for the sticky header active state — recommend using a PNG. Falls back to the default logo if not set.',
                'url'      => true,
                'required' => array( array('ct_text_logo','!=','yes'), array('ct_sticky_header','equals','yes') ),
            ),
            array(
                'id'       => 'ct_logo_highres_sticky',
                'type'     => 'media',
                'title'    => 'Logo @2x (Sticky Header > Active)',
                'desc'     => 'Optionally upload a @2x logo for high resolution displays for the sticky header active state — recommend using a PNG. Falls back to the default logo if not set. <a href="https://line25.com/tutorials/how-to-create-retina-graphics-for-your-web-designs" target="_blank">More Information on Creating @2x Images</a>',
                'url'      => true,
                'required' => array( array('ct_text_logo','!=','yes'), array('ct_sticky_header','equals','yes') ),
            ),

            // ── Advanced Logo Sizing ──────────────────────────────────────────────
            array(
                'id'       => 'ct_logo_advanced_sizing',
                'type'     => 'switch',
                'title'    => 'Advanced Logo Sizing',
                'desc'     => 'Enable to manually cap the logo image width. Constrains the logo without affecting the header bar height.',
                'default'  => 'no',
                'required' => array('ct_text_logo','!=','yes'),
            ),
            array( 'id' => 'logo-size-start', 'type' => 'section',
                   'required' => array( array('ct_text_logo','!=','yes'), array('ct_logo_advanced_sizing','equals','yes') ),
                   'indent' => true ),
            array(
                'id'      => 'ct_logo_max_width',
                'type'    => 'slider',
                'title'   => 'Logo Max Width',
                'desc'    => 'Maximum width of the logo image in pixels. Default is 228px (full container width). Reduce to shrink the logo without changing the header bar size.',
                'min'     => 50,
                'max'     => 228,
                'step'    => 2,
                'unit'    => 'px',
                'default' => 228,
            ),
            array( 'id' => 'logo-size-end', 'type' => 'section', 'indent' => false ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
    'title'            => __( 'Top Bar', 'contempo' ),
    'id'               => 'top-bar',
    'subsection'       => true,
    'fields'           => array(

            array (
                'desc' => 'The top bar displays contact and social links above the header.',
                'id' => 'ct_top_bar',
                'type' => 'switch',
                'title' => 'Display Top Bar?',
                'default' => 'yes',
            ),
            array(
                'id' => 'phone-section-start',
                'type' => 'section',
                'title' => __('Contact Info', 'contempo'),
                'subtitle' => __('Shows in the top left of the top bar.', 'contempo'),
                'required' => array('ct_top_bar','=','yes'),
                'indent' => true 
            ),
                array (
                    'desc' => 'Select whether or not you\'d like to display the contact information.',
                    'id' => 'ct_header_contact_info_top_bar_display',
                    'type' => 'switch',
                    'title' => 'Display Contact Info?',
                    'default' => 'yes',
                ),
                array (
                    'desc' => 'Choose if you would like to display an icon.',
                    'id' => 'ct_contact_phone_header_display_icon',
                    'type' => 'switch',
                    'title' => 'Display Icon?',
                    'default' => 'yes',
                    'required' => array('ct_header_contact_info_top_bar_display','=','yes'),
                ),
                array(
                    'id'=>'ct_contact_phone_header_icon',
                    'type' => 'select', 
                    'title' => __('Icon', 'contempo'),
                    'subtitle'  => __('Select an icon.', 'contempo'),
                    'default'     => 'fa-mobile',
                    'options' => ct_font_awesome(),
                    'required' => array('ct_contact_phone_header_display_icon','=','yes'),
                ),
                array (
                    'desc' => 'Enter your Contact Phone Number Here, or anything else you\'d like company slogan, site description, etc&hellip;',
                    'id' => 'ct_contact_phone_header',
                    'type' => 'text',
                    'title' => 'Text',
                    'default' => 'Call Us Today: 1-888-999-5454',
                    'required' => array('ct_header_contact_info_top_bar_display','=','yes'),
                ),
            array(
                'id' => 'phone-section-end',
                'type' => 'section',
                'indent' => false 
            ),
            array(
                'id' => 'social-icons-section-start',
                'type' => 'section',
                'title' => __('Social Icons', 'contempo'),
                'subtitle' => __('Shows in the top right of the top bar.', 'contempo'),
                'required' => array('ct_top_bar','=','yes'),
                'indent' => true 
            ),
                array (
                    'desc' => 'Select whether or not you\'d like to display the social links.',
                    'id' => 'ct_header_social',
                    'type' => 'switch',
                    'title' => 'Display Social Links?',
                    'default' => 'yes',
                ),
                array (
                    'desc' => 'Choose if you would like the social links to open in a new tab.',
                    'id' => 'ct_social_new_tab',
                    'type' => 'switch',
                    'title' => 'Open in New Tab?',
                    'required' => array('ct_header_social','=','yes'),
                    'default' => 'no',
                ),
                array (
                    'desc' => 'Enter your Facebook URL.',
                    'id' => 'ct_fb_url',
                    'type' => 'text',
                    'title' => 'Facebook',
                    'required' => array('ct_header_social','=','yes'),
                ),
                array (
                    'desc' => 'Enter your Instagram URL.',
                    'id' => 'ct_instagram_url',
                    'type' => 'text',
                    'title' => 'Instagram',
                    'required' => array('ct_header_social','=','yes'),
                ),
                array (
                    'desc' => 'Enter your Twitter URL.',
                    'id' => 'ct_twitter_url',
                    'type' => 'text',
                    'title' => 'Twitter',
                    'required' => array('ct_header_social','=','yes'),
                ),
                array (
                    'desc' => 'Enter your LinkedIn URL.',
                    'id' => 'ct_linkedin_url',
                    'type' => 'text',
                    'title' => 'LinkedIn',
                    'required' => array('ct_header_social','=','yes'),
                ),
                array (
                    'desc' => 'Enter your YouTube URL.',
                    'id' => 'ct_youtube_url',
                    'type' => 'text',
                    'title' => 'YouTube',
                    'required' => array('ct_header_social','=','yes'),
                ),
                array (
                    'desc' => 'Enter your Pinterest URL.',
                    'id' => 'ct_pinterest_url',
                    'type' => 'text',
                    'title' => 'Pinterest',
                    'required' => array('ct_header_social','=','yes'),
                ),
                array (
                    'desc' => 'Select your contact page.',
                    'id' => 'ct_top_bar_contact_page_id',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'Contact Page',
                    'default' => '',
                    'required' => array('ct_header_social','=','yes'),
                ),
            array(
                'id' => 'social-icons-section-end',
                'type' => 'section',
                'indent' => false 
            ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Homepage', 'contempo' ),
        'id'               => 'homepage',
        'group'            => 'General',
        'icon'             => 'fas fa-home',
        //'desc'             => '',
        'fields'           => array(

            array (
                'desc' => 'Select a page.',
                'id' => 'ct_home_elementor_id',
                'type' => 'select',
                'data' => 'pages',
                'title' => '"Home - Content" Page',
                'default' => '',
                //'subtitle' => 'Select a page.',
                'desc' => 'This comes pre-configured with any of the prebuilt site designs imported from the setup wizard, but please see <a href="https://contempothemes.com/docs/homepage-setup/">Homepage Setup</a> for more information.',
            ),
            
        )
    ) );

    /* =========================================================================
     * GROUP: Appearance
     * Sections: Appearance (parent), Typography, Body Background,
     *           Header Colors, Mobile Navigation, Secondary Colors, Links,
     *           Footer Colors
     * ========================================================================= */

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Appearance', 'contempo' ),
        'id'               => 'appearance',
        'group'            => 'Appearance',
        'icon'             => 'fas fa-paint-brush',
        'fields'           => array(

            array(
                'id' => 'info_appearance_intro',
                'type' => 'info',
                'style' => 'info',
                'title' => __('', 'contempo'),
                'desc' => __('Customize your site\'s colors, typography, and visual style. All changes apply site-wide.', 'contempo')
            ),

            array(
                'id' => 'info_appearance_nav',
                'type' => 'raw',
                'markdown' => false,
                'content' => '
<div class="ct-getting-started-checklist" style="padding:10px 0;">
  <ol style="line-height:2.2em;font-size:14px;">
    <li><strong>Typography &amp; Fonts</strong> — <a href="#typography">Appearance &rarr; Typography</a> — Set heading &amp; body fonts and enable advanced type controls.</li>
    <li><strong>Body Background</strong> — <a href="#create-a-skin-body-background">Appearance &rarr; Body Background</a> — Set the site-wide background color or image.</li>
    <li><strong>Header Colors</strong> — <a href="#create-a-skin-header">Appearance &rarr; Header Colors</a> — Nav font color, background, sub-menu, and hover states.</li>
    <li><strong>Mobile Navigation</strong> — <a href="#create-a-skin-mobile-navigation">Appearance &rarr; Mobile Navigation</a> — Mobile menu background and link colors.</li>
    <li><strong>Secondary / Brand Colors</strong> — <a href="#create-a-skin-secondary-colors">Appearance &rarr; Secondary Colors</a> — Primary brand accent color used on buttons, badges, and highlights.</li>
    <li><strong>Links</strong> — <a href="#create-a-skin-links">Appearance &rarr; Links</a> — Link, visited, hover, and active colors.</li>
    <li><strong>Footer Colors</strong> — <a href="#create-a-skin-footer">Appearance &rarr; Footer Colors</a> — Footer background, widget headings, and link colors.</li>
  </ol>
</div>',
            ),

        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Typography', 'contempo' ),
        'id'               => 'typography',
        'group'            => 'Appearance',
        'subsection'       => true,
        'fields'          => array(

            array(
                'id' => 'info_typography_scope',
                'type' => 'info',
                'style' => 'info',
                'title' => __('', 'contempo'),
                'desc' => __('These settings apply as theme-wide defaults. On Elementor-built pages, Elementor\'s own typography controls take precedence. Use these to style non-Elementor content such as blog posts, listing pages, and widget areas.', 'contempo')
            ),

            array (
                'desc' => 'Select a Google Font for all headings (H1–H6) across the site.',
                'id' => 'ct_heading_font',
                'type' => 'select',
                'options' => ct_get_fonts(),
                'title' => 'Heading Font',
                'default' => 'Montserrat',
            ),
            array (
                'desc' => 'Select a Google Font for body text across the site.',
                'id' => 'ct_body_font',
                'type' => 'select',
                'options' => ct_get_fonts(),
                'title' => 'Body Font',
                'default' => 'Lato',
            ),

            array (
                'desc' => 'Turn on to set custom sizes, colors, and fine-grained typography settings.',
                'id' => 'ct_use_typostyles',
                'type' => 'switch',
                'title' => 'Enable Advanced Typography Controls?',
                'default' => false,
            ),
            array (
                'id'          => 'ct_body_typography',
                'type'        => 'typography', 
                'title'       => __('Body', 'contempo'),
                'google'      => true, 
                'font-backup' => true,
                'output'      => array('body'),
                'units'       =>'px',
                //'subtitle'    => __('Typography option with each property can be called individually.', 'contempo'),
                'default'     => array(
                    'color'       => '#191919', 
                    'font-style'  => 'Normal', 
                    'font-family' => 'Lato', 
                    'google'      => true,
                    'font-size'   => '16px', 
                    'line-height' => '30px'
                ),
                'required' => array('ct_use_typostyles','=','yes')
            ),
            array (
                'id'          => 'ct_heading_typography',
                'type'        => 'typography', 
                'title'       => __('Headings', 'contempo'),
                'google'      => true, 
                'font-backup' => true,
                'font-size'   => false,
                'line-height' => false,
                'output'      => array('h1,h2,h3,h4,h5,h6'),
                'units'       =>'px',
                //'subtitle'    => __('Typography option with each property can be called individually.', 'contempo'),
                'default'     => array(
                    'color'       => '#191919', 
                    'font-style'  => 'Normal', 
                    'font-family' => 'Montserrat', 
                    'google'      => true,
                ),
                'required' => array('ct_use_typostyles','=','yes')
            ),
            array (
                'id'          => 'ct_heading_one_size',
                'type'        => 'typography', 
                'title'       => __('H1', 'contempo'),
                'google'      => false, 
                'font-backup' => false,
                'font-family' => false,
                'font-size'   => true,
                'font-style'   => false,
                'font-weight'   => false,
                'output'      => array('h1'),
                'units'       =>'em',
                //'subtitle'    => __('Typography option with each property can be called individually.', 'contempo'),
                'default'     => array(
                    'color'       => '#191919', 
                    'font-size'   => '2.875em', 
                    'line-height' => '1.25em'
                ),
                'required' => array('ct_use_typostyles','=','yes')
            ),
            array (
                'id'          => 'ct_heading_two_size',
                'type'        => 'typography', 
                'title'       => __('H2', 'contempo'),
                'google'      => false, 
                'font-backup' => false,
                'font-family' => false,
                'font-size'   => true,
                'font-style'   => false,
                'font-weight'   => false,
                'output'      => array('h2'),
                'units'       =>'em',
                //'subtitle'    => __('Typography option with each property can be called individually.', 'contempo'),
                'default'     => array(
                    'color'       => '#191919', 
                    'font-size'   => '2.1875em', 
                    'line-height' => '1.25em'
                ),
                'required' => array('ct_use_typostyles','=','yes')
            ),
            array (
                'id'          => 'ct_heading_three_size',
                'type'        => 'typography', 
                'title'       => __('H3', 'contempo'),
                'google'      => false, 
                'font-backup' => false,
                'font-family' => false,
                'font-size'   => true,
                'font-style'   => false,
                'font-weight'   => false,
                'output'      => array('h3'),
                'units'       =>'em',
                //'subtitle'    => __('Typography option with each property can be called individually.', 'contempo'),
                'default'     => array(
                    'color'       => '#191919', 
                    'font-size'   => '1.75em', 
                    'line-height' => '1.25em'
                ),
                'required' => array('ct_use_typostyles','=','yes')
            ),
            array (
                'id'          => 'ct_heading_four_size',
                'type'        => 'typography', 
                'title'       => __('H4', 'contempo'),
                'google'      => false, 
                'font-backup' => false,
                'font-family' => false,
                'font-size'   => true,
                'font-style'   => false,
                'font-weight'   => false,
                'output'      => array('h4'),
                'units'       =>'em',
                //'subtitle'    => __('Typography option with each property can be called individually.', 'contempo'),
                'default'     => array(
                    'color'       => '#191919', 
                    'font-size'   => '1.3125em', 
                    'line-height' => '1.25em'
                ),
                'required' => array('ct_use_typostyles','=','yes')
            ),
            array (
                'id'          => 'ct_heading_five_size',
                'type'        => 'typography', 
                'title'       => __('H5', 'contempo'),
                'google'      => false, 
                'font-backup' => false,
                'font-family' => false,
                'font-size'   => true,
                'font-style'   => false,
                'font-weight'   => false,
                'output'      => array('h5'),
                'units'       =>'em',
                //'subtitle'    => __('Typography option with each property can be called individually.', 'contempo'),
                'default'     => array(
                    'color'       => '#191919', 
                    'font-size'   => '1.0625em', 
                    'line-height' => '1.25em'
                ),
                'required' => array('ct_use_typostyles','=','yes')
            ),
            array (
                'id'          => 'ct_heading_six_size',
                'type'        => 'typography', 
                'title'       => __('H6', 'contempo'),
                'google'      => false, 
                'font-backup' => false,
                'font-family' => false,
                'font-size'   => true,
                'font-style'   => false,
                'font-weight'   => false,
                'output'      => array('h6'),
                'units'       =>'em',
                //'subtitle'    => __('Typography option with each property can be called individually.', 'contempo'),
                'default'     => array(
                    'color'       => '#191919', 
                    'font-size'   => '0.875em', 
                    'line-height' => '1.25em'
                ),
                'required' => array('ct_use_typostyles','=','yes')
            )
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Body Background', 'contempo' ),
        'id'               => 'create-a-skin-body-background',
        'group'            => 'Appearance',
        'subsection'       => true,
        'fields'           => array(
             array (
                'desc' => 'Pick a background color, image, etc&hellip;.',
                'id' => 'ct_background',
                'type' => 'background',
                'title' => 'Body Background',
            ),
            
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Header Colors', 'contempo' ),
        'id'               => 'create-a-skin-header',
        'group'            => 'Appearance',
        'subsection'       => true,
        'fields'           => array(

            array(
                'id' => 'info_critical_header',
                'type' => 'info',
                'style' => 'info',
                'title' => __('', 'contempo'),
                'desc' => ''
            ),

            // ── Top Bar ──────────────────────────────────────────────────────
            array( 'id' => 'section_header_topbar', 'type' => 'section', 'title' => 'Top Bar' ),

            array (
                'desc' => 'Pick a background color for the header top bar.',
                'id' => 'ct_header_bar_color',
                'type' => 'color_rgba',
                'title' => 'Background Color',
            ),
            array (
                'desc' => 'Pick a border color for the header top bar.',
                'id' => 'ct_header_bar_border_color',
                'type' => 'color_rgba',
                'title' => 'Border Color',
            ),
            array (
                'desc' => 'Pick a text and link color for the header top bar.',
                'id' => 'ct_header_bar_text_color',
                'type' => 'color_rgba',
                'title' => 'Text & Link Color',
            ),
            array (
                'desc' => 'Pick a background color for the user login area in the top bar.',
                'id' => 'ct_header_bar_user_bg_color',
                'type' => 'color_rgba',
                'title' => 'User Login Background Color',
            ),
            array (
                'desc' => 'Pick a link color for the user login area in the top bar.',
                'id' => 'ct_header_bar_user_link_color',
                'type' => 'color_rgba',
                'title' => 'User Login Link Color',
            ),
            array (
                'desc' => 'Pick a bottom border color for user login links in the top bar.',
                'id' => 'ct_header_bar_user_btm_border_color',
                'type' => 'color_rgba',
                'title' => 'User Login Link Bottom Border Color',
            ),

            // ── Header Bar ───────────────────────────────────────────────────
            array( 'id' => 'section_header_bar', 'type' => 'section', 'title' => 'Header Bar' ),

            array(
                'id'       => 'ct_text_logo_color',
                'type'     => 'color_rgba',
                'title'    => 'Text Logo Color',
                'desc'     => 'Pick a color for the site title text logo.',
                'required' => array('ct_text_logo','equals','yes'),
                'output'   => array(
                    'color' => 'header #logo h2 a, header #logo h2 a:visited',
                ),
            ),
            array (
                'desc' => 'Pick a background color for the main header bar.',
                'id' => 'ct_header_background',
                'type' => 'color_rgba',
                'output' => array(
                    'background-color' => '#header-wrap, #home.home #header-wrap.trans-header.sticky, .page #header-wrap.trans-header.sticky',
                    'border-top-color' => '.cbp-tm-menu > li > a'
                ),
                'title' => 'Header Background Color',
            ),
            array (
                'desc' => 'Pick a background color for the full-width nav bar used in Header Style 2.',
                'id' => 'ct_header_two_nav_background',
                'type' => 'color_rgba',
                'required' => array('ct_header_style','equals','two'),
                'output' => array(
                    'background-color' => '#nav-full-width',
                ),
                'title' => 'Header Nav Background Color',
            ),

            // ── User Login Area ───────────────────────────────────────────────
            array( 'id' => 'section_header_user_area', 'type' => 'section', 'title' => 'User Login Area' ),

            array(
                'id'    => 'ct_header_user_trigger_bg',
                'type'  => 'color_rgba',
                'title' => 'User Area Background',
                'desc'  => 'Background color for the logged-in user trigger (name + avatar area in the header bar).',
            ),
            array(
                'id'    => 'ct_header_user_name_color',
                'type'  => 'color_rgba',
                'title' => 'User Name Color',
                'desc'  => 'Text color for the logged-in user name displayed in the header bar.',
            ),
            array(
                'id'    => 'ct_header_user_drop_bg',
                'type'  => 'color_rgba',
                'title' => 'Dropdown Background',
                'desc'  => 'Background color for the user dropdown panel.',
            ),
            array(
                'id'    => 'ct_header_user_drop_link_color',
                'type'  => 'color_rgba',
                'title' => 'Dropdown Link Color',
                'desc'  => 'Text color for links inside the user dropdown panel.',
            ),
            array(
                'id'    => 'ct_header_user_drop_icon_color',
                'type'  => 'color_rgba',
                'title' => 'Dropdown Icon Color',
                'desc'  => 'Fill color for the SVG icons inside the user dropdown items.',
            ),
            array(
                'id'    => 'ct_header_user_drop_separator',
                'type'  => 'color_rgba',
                'title' => 'Dropdown Separator Color',
                'desc'  => 'Color for the divider lines between items in the user dropdown. Hover and active states automatically use your Secondary Brand Color.',
            ),

            // ── Style 2: Info Blocks ──────────────────────────────────────────
            array( 'id' => 'section_header_two_info', 'type' => 'section', 'title' => 'Style 2 — Header Info Blocks',
                   'required' => array('ct_header_style','equals','two') ),

            array (
                'desc' => 'Pick a background color for each header info block (icon + text columns to the right of the logo).',
                'id' => 'ct_header_two_info_bg',
                'type' => 'color_rgba',
                'required' => array('ct_header_style','equals','two'),
                'title' => 'Info Block Background Color',
            ),
            array (
                'desc' => 'Pick a border color for the top edge of each info block (visible at tablet/mobile breakpoints).',
                'id' => 'ct_header_two_info_border',
                'type' => 'color_rgba',
                'required' => array('ct_header_style','equals','two'),
                'title' => 'Info Block Border Color',
            ),
            array (
                'desc' => 'Pick a color for the FontAwesome icon in each header info block.',
                'id' => 'ct_header_two_info_icon_color',
                'type' => 'color_rgba',
                'required' => array('ct_header_style','equals','two'),
                'title' => 'Info Block Icon Color',
            ),
            array (
                'desc' => 'Pick a color for the title text in each header info block.',
                'id' => 'ct_header_two_info_title_color',
                'type' => 'color_rgba',
                'required' => array('ct_header_style','equals','two'),
                'title' => 'Info Block Title Color',
            ),
            array (
                'desc' => 'Pick a color for the subtext (second line) in each header info block.',
                'id' => 'ct_header_two_info_text_color',
                'type' => 'color_rgba',
                'required' => array('ct_header_style','equals','two'),
                'title' => 'Info Block Subtext Color',
            ),

            // ── Style 2: Full-Width Nav Bar ───────────────────────────────────
            array( 'id' => 'section_header_two_nav', 'type' => 'section', 'title' => 'Style 2 — Full-Width Nav Bar',
                   'required' => array('ct_header_style','equals','two') ),

            array (
                'desc' => 'Pick a text color for links in the full-width nav bar.',
                'id' => 'ct_header_two_nav_link_color',
                'type' => 'color_rgba',
                'required' => array('ct_header_style','equals','two'),
                'title' => 'Nav Bar Link Color',
            ),
            array (
                'desc' => 'Pick a hover text color for links in the full-width nav bar.',
                'id' => 'ct_header_two_nav_link_hover_color',
                'type' => 'color_rgba',
                'required' => array('ct_header_style','equals','two'),
                'title' => 'Nav Bar Link Hover Color',
            ),

            // ── Style 3: Header Login Area ────────────────────────────────────
            array( 'id' => 'section_header_three_login', 'type' => 'section', 'title' => 'Style 3 — Header Login Area',
                   'required' => array('ct_header_style','equals','three') ),

            array (
                'desc' => 'Pick a border color for the outlined login/register button embedded in the Style 3 header.',
                'id' => 'ct_header_three_login_border_color',
                'type' => 'color_rgba',
                'required' => array('ct_header_style','equals','three'),
                'title' => 'Login Button Outline Color',
            ),
            array (
                'desc' => 'Pick a text color for the logged-in user name and account link shown in the Style 3 header.',
                'id' => 'ct_header_three_user_text_color',
                'type' => 'color_rgba',
                'required' => array('ct_header_style','equals','three'),
                'title' => 'User Name / Link Text Color',
            ),

            // ── Main Navigation ──────────────────────────────────────────────
            array( 'id' => 'section_header_nav', 'type' => 'section', 'title' => 'Main Navigation' ),

            array (
                'desc' => 'Pick a font color for the main nav links.',
                'id' => 'ct_header_nav_font_color',
                'type' => 'color_rgba',
                'title' => 'Nav Link Color',
            ),
            array (
                'desc' => 'Pick a text color for main nav links on hover.',
                'id' => 'ct_header_nav_hover_color',
                'type' => 'color_rgba',
                'title' => 'Nav Link Hover Color',
            ),
            array (
                'desc' => 'Pick a top border color for the active/current nav item.',
                'id' => 'ct_header_nav_current_bg',
                'type' => 'color_rgba',
                'title' => 'Nav Current Item Top Border Color',
            ),
            array (
                'desc' => 'Pick a top border color for the nav item hover state.',
                'id' => 'ct_header_nav_hover_border_color',
                'type' => 'color_rgba',
                'title' => 'Nav Hover Top Border Color',
            ),
            array (
                'desc' => 'Pick a color for the outlined button in the nav.',
                'id' => 'ct_header_nav_btn_outline',
                'type' => 'color_rgba',
                'title' => 'Nav Button Outline Color',
            ),

            // ── Sub Navigation ───────────────────────────────────────────────
            array( 'id' => 'section_header_subnav', 'type' => 'section', 'title' => 'Sub Navigation (Dropdown)' ),

            array (
                'desc' => 'Pick a background color for dropdown sub-nav items.',
                'id' => 'ct_header_sub_nav_background_color',
                'type' => 'color_rgba',
                'title' => 'Sub Nav Background Color',
            ),
            array (
                'desc' => 'Pick a font color for dropdown sub-nav links.',
                'id' => 'ct_header_sub_nav_font_color',
                'type' => 'color_rgba',
                'title' => 'Sub Nav Link Color',
            ),
            array (
                'desc' => 'Pick a background color for a sub-nav item on hover.',
                'id' => 'ct_header_sub_nav_hover_background_color',
                'type' => 'color_rgba',
                'title' => 'Sub Nav Hover Background Color',
            ),
            array (
                'desc' => 'Pick a font color for a sub-nav link on hover.',
                'id' => 'ct_header_sub_nav_hover_font_color',
                'type' => 'color_rgba',
                'title' => 'Sub Nav Hover Link Color',
            ),
            array (
                'desc' => 'Pick a background color for the active/current sub-nav item.',
                'id' => 'ct_header_sub_nav_current_background_color',
                'type' => 'color_rgba',
                'output' => array(
                    'background-color' => 'nav ul.ct-menu .sub-menu li:hover > a, .ct-menu .sub-menu li.current-menu-ancestor > a, .ct-menu .sub-menu li.current-menu-parent > a, .ct-menu .sub-menu li.current-menu-item > a',
                ),
                'title' => 'Sub Nav Current Item Background Color',
            ),
            array (
                'desc' => 'Pick a text color for the active/current sub-nav item.',
                'id' => 'ct_header_sub_nav_current_text_color',
                'type' => 'color_rgba',
                'output' => array(
                    'color' => 'nav ul.ct-menu .sub-menu li:hover > a, .ct-menu .sub-menu li.current-menu-ancestor > a, .ct-menu .sub-menu li.current-menu-parent > a, .ct-menu .sub-menu li.current-menu-item > a',
                ),
                'title' => 'Sub Nav Current Item Text Color',
            ),
            array (
                'desc' => 'Pick a border bottom color for sub-nav item separators.',
                'id' => 'ct_header_sub_nav_items_border_bottom_color',
                'type' => 'color_rgba',
                'title' => 'Sub Nav Item Border Color',
            ),
            array (
                'desc' => 'Pick a font color for mega menu column titles.',
                'id' => 'ct_header_sub_nav_mega_menu_title_font_color',
                'type' => 'color_rgba',
                'output' => array(
                    'color' => '.ct-menu .multicolumn .col-title',
                ),
                'title' => 'Mega Menu Column Title Color',
            ),

            // ── Transparent & Sticky Header ──────────────────────────────────
            array( 'id' => 'section_header_sticky', 'type' => 'section', 'title' => 'Transparent & Sticky Header' ),

            array (
                'desc' => 'Pick a font color for nav links when the transparent header is active.',
                'id' => 'ct_header_trans_home_nav_font_color',
                'required' => array('ct_trans_header','equals','yes'),
                'output' => array(
                    'color' => '.home #header-wrap.trans-header nav li > a, .page #header-wrap.trans-header nav li > a',
                ),
                'type' => 'color_rgba',
                'title' => 'Transparent Header Nav Color',
            ),
            array (
                'desc' => 'Pick a text color for nav links on hover when the transparent header is active.',
                'id' => 'ct_header_trans_nav_hover_color',
                'required' => array('ct_trans_header','equals','yes'),
                'output' => array(
                    'color' => '.home #header-wrap.trans-header nav li > a:hover, .page #header-wrap.trans-header nav li > a:hover',
                ),
                'type' => 'color_rgba',
                'title' => 'Transparent Header Nav Hover Color',
            ),
            array (
                'desc' => 'Pick a text color for the logged-in user name when the transparent header is active. Defaults to white.',
                'id' => 'ct_header_trans_user_name_color',
                'required' => array('ct_trans_header','equals','yes'),
                'type' => 'color_rgba',
                'title' => 'Transparent Header User Name Color',
            ),
            array (
                'desc' => 'Pick a background color for the header when it becomes sticky on scroll. Defaults to white.',
                'id' => 'ct_header_sticky_background',
                'type' => 'color_rgba',
                'title' => 'Sticky Header Background Color',
            ),
            array (
                'desc' => 'Pick a text color for nav links in the sticky state. Useful when a transparent header uses white text that needs to switch to dark when sticky.',
                'id' => 'ct_header_sticky_nav_font_color',
                'type' => 'color_rgba',
                'title' => 'Sticky Header Nav Text Color',
            ),
            array (
                'desc' => 'Pick a text color for nav links on hover in the sticky state.',
                'id' => 'ct_header_sticky_nav_hover_color',
                'type' => 'color_rgba',
                'title' => 'Sticky Header Nav Hover Text Color',
            ),

            // ── Header Search Bar ────────────────────────────────────────────
            array( 'id' => 'section_header_search', 'type' => 'section', 'title' => 'Header Search Bar' ),

            array (
                'desc' => 'Pick a background color for the header search bar band.',
                'id' => 'ct_header_search_bar_bg',
                'type' => 'color_rgba',
                'title' => 'Search Bar Background',
            ),
            array (
                'desc' => 'Pick a background color for the autocomplete suggestion dropdown.',
                'id' => 'ct_header_search_suggestion_bg',
                'type' => 'color_rgba',
                'title' => 'Autocomplete Dropdown Background',
            ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Mobile Navigation', 'contempo' ),
        'id'               => 'create-a-skin-mobile-navigation',
        'group'            => 'Appearance',
        'subsection'       => true,
        'fields'           => array(

            array(
                'id' => 'info_critical_mobile_nav',
                'type' => 'info',
                'style' => 'info',
                'title' => __('', 'contempo'),
                'desc' => ''
            ),

            // ── Toggle Button ─────────────────────────────────────────────────
            array( 'id' => 'section_mobile_button', 'type' => 'section', 'title' => 'Toggle Button' ),

            array (
                'desc' => 'Pick a background color for the button that opens the mobile menu.',
                'id' => 'ct_mobile_btn_bg_color',
                'type' => 'color_rgba',
                'title' => 'Button Background Color',
                'output' => array(
                    'background-color' => '.show-hide',
                ),
            ),
            array (
                'desc' => 'Pick an icon/hamburger color for the mobile menu button.',
                'id' => 'ct_mobile_btn_icon_color',
                'type' => 'color_rgba',
                'title' => 'Button Icon Color',
            ),

            // ── Menu Panel ────────────────────────────────────────────────────
            array( 'id' => 'section_mobile_menu', 'type' => 'section', 'title' => 'Menu Panel' ),

            array (
                'desc' => 'Pick a background color for the mobile navigation slide-out panel.',
                'id' => 'ct_mobile_menu_bg_color',
                'type' => 'color_rgba',
                'title' => 'Menu Background Color',
            ),
            array (
                'desc' => 'Pick a link color for mobile menu items.',
                'id' => 'ct_mobile_menu_link_color',
                'type' => 'color_rgba',
                'title' => 'Menu Link Color',
                'output' => array(
                    'color' => '.cbp-spmenu a',
                ),
            ),
            array (
                'desc' => 'Pick a border color for the separator line between mobile menu links.',
                'id' => 'ct_mobile_menu_link_border_bottom_color',
                'type' => 'color_rgba',
                'title' => 'Menu Link Border Color',
                'output' => array(
                    'border-bottom-color' => '.cbp-spmenu-vertical a',
                ),
            ),
            array (
                'desc' => 'Pick a text color for mobile menu links on hover.',
                'id' => 'ct_mobile_menu_link_hover_color',
                'type' => 'color_rgba',
                'title' => 'Menu Link Hover Color',
                'output' => array(
                    'color' => '.cbp-spmenu a:hover',
                ),
            ),
            array (
                'desc' => 'Pick a background color for mobile menu links on hover.',
                'id' => 'ct_mobile_menu_link_hover_bg_color',
                'type' => 'color_rgba',
                'title' => 'Menu Link Hover Background Color',
            ),

            // ── Sub Menu ──────────────────────────────────────────────────────
            array( 'id' => 'section_mobile_submenu', 'type' => 'section', 'title' => 'Sub Menu' ),

            array (
                'desc' => 'Pick a color for the arrow icon that expands mobile sub-menus.',
                'id' => 'ct_mobile_menu_sub_arrow_color',
                'type' => 'color_rgba',
                'title' => 'Sub Menu Arrow Color',
                'output' => array(
                    'color' => '.sub-menu .fa-angle-right',
                ),
            ),

        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Secondary Colors', 'contempo' ),
        'id'               => 'create-a-skin-secondary-colors',
        'group'            => 'Appearance',
        'subsection'       => true,
        'fields'           => array(

            array(
                'id' => 'info_critical_secondary_colors',
                'type' => 'info',
                'style' => 'info',
                'title' => __('', 'contempo'),
                'desc' => ''
            ),

            // ── Brand Colors ──────────────────────────────────────────────────
            array( 'id' => 'section_secondary_brand', 'type' => 'section', 'title' => 'Brand Colors' ),

            array (
                'desc' => 'Pick the secondary background color, e.g. buttons, advanced search, slider, agents, etc.',
                'id' => 'ct_secondary_bg_color',
                'type' => 'color_rgba',
                'output' => array(
                    'background-color' => '.advanced-search h4, .switch-input:checked + .switch-label::before, span.search-params, .featured-listings header.masthead, .listing .listing-imgs-attached, .advanced-search h3, .flex-caption p, a.btn, .btn, .ct-hvp__form-button button, #reply-title small a, .featured-listings a.view-all, .comment-reply-link, .ctlp .search-btn, .user-drop .my-listings-count, .user-drop .user-data-count, .ct-radio-group:checked + label, .grid figcaption a, input.btn, .flex-direction-nav a, .partners h5 span, .schedule-calendar .schedule-date .schedule-daytext, .advanced-search h4, .featured-listings header.masthead, .listing .listing-imgs-attached, .advanced-search h3, .flex-caption p, a.btn, .btn, .lrg-icon, .listing-info .price, #reply-title small a, .featured-listings a.view-all, .comment-reply-link, .grid figcaption a, input.btn, input[type="submit"], input[type="reset"], input[type="button"], input[type="btn"], button, .flex-direction-nav a, .user-listing-count, #compare-panel-btn, span.map-toggle, span.search-toggle, .pagination span.current, #progress-bar li.active:before, #progress-bar li.active:after, #progress-bar li.active:before, #progress-bar li.active:after, .pagination .current a, .package-posts .popular-heading, input[type="checkbox"].custom-select:checked + span:before, input[type="checkbox"].custom-select:checked + span:after, .schedule-calendar .schedule-date .schedule-daytext, .partners h5 span, #topbar-wrap li.login-register a, .user-listing-count, .aq-block-aq_widgets_block .widget h5, .home .advanced-search.idx form, #page .featured-map #map, .cta, .searching-on.search-style-two, .search-style-two .search-params, .ui-slider-handle .amount, .listing-submit, .placeholder, ul.user-nav li a, .no-registration, thead, .single-listings #listing-sections, .ajaxSubmit, a.btn:hover, .btn:hover, button:hover, #reply-title small a:hover, .ui-widget-header, .comment-reply-link:hover, .grid figcaption a:hover, input[type="submit"]:hover, input[type="reset"]:hover, input[type="button"]:hover, input[type="btn"]:hover, .select2-container--default .select2-results__option--highlighted[aria-selected], .user-drop .user-data-count-alert, .user-drop .ctidxpp-favorites-count, .user-drop .ctidxpp-saved-search-count, .user-drop .ctidxpp-recently-viewed-count',
                    'color' => '.packages-container .price, .single-listings #listings-three-header h4.price, #search-results-layout-toggle button.current, #search-results-layout-toggle-mobile button.current, .single-listings #listings-four-header h4.price, .single-listings #listings-five-header h4.price, .widget_ct_listingbookshowing .owl-item.active.center .schedule-day, .single-listings .fa-check, .ctlp .btn-dropdown, .save-this-btn.btn a, .save-this-btn.btn i, .user-frontend ul.user-drop a:hover',
                    'border-color' => '.ctlp .btn-dropdown, .user-frontend li.user-logged-in figure, .ui-slider-handle .amount, .save-this-btn.btn, .user-drop .user-data-count, .user-drop .user-data-count-alert, .user-drop .ctidxpp-favorites-count, .user-drop .ctidxpp-saved-search-count, .user-drop .ctidxpp-recently-viewed-count',
                    'border-bottom-color' => '.ui-slider-handle .amount:after',
                    'border-left-color' => '.cbp-spmenu-vertical .sub-menu a',
                ),
                'title' => 'Secondary Background Color',
            ),
             array (
                'desc' => 'Pick a secondary text color.',
                'id' => 'ct_secondary_text_color',
                'type' => 'color_rgba',
                'output' => array(
                    'color' => '.advanced-search h4, .featured-listings header.masthead, .listing .listing-imgs-attached, .advanced-search h3, .flex-caption p, a.btn, .btn, .lrg-icon, .listing-info .price, #reply-title small a, .featured-listings a.view-all, li.listing.modern .search-view-listing.btn, .comment-reply-link, .grid figcaption a, input.btn, input[type="submit"], .ct-radio-group:checked + label, input[type="reset"], input[type="button"], input[type="btn"], button, .flex-direction-nav a, .user-listing-count, span.search-params, #compare-panel-btn, span.map-toggle, span.search-toggle, .infobox .price, .pagination span.current, #progress-bar li.active:before, #progress-bar li.active:after, #progress-bar li.active:before, #progress-bar li.active:after, .pagination .current a, .package-posts .popular-heading, .partners h5 span, #topbar-wrap li.login-register a, .user-listing-count, .aq-block-aq_widgets_block .widget h5, .home .advanced-search.idx form, #page .featured-map #map, .cta, .searching-on.search-style-two, .search-style-two .search-params, .listing-submit, .placeholder, ul.user-nav li a, .no-registration, thead, .single-listings #listing-sections, .ajaxSubmit, .single-listings #listing-sections li.listing-nav-icon, .single-listings #listing-sections li a, .single-listings #listing-sections li a:visited',
                    'border-right-color' => '.single-listings #listing-sections li.listing-nav-icon',
                ),
                'title' => 'Secondary Text Color',
            ),
            // ── Global / Body ─────────────────────────────────────────────────
            array( 'id' => 'section_secondary_global', 'type' => 'section', 'title' => 'Global & Body' ),

            array (
                'desc' => 'Pick a base text color for body copy and paragraphs site-wide.',
                'id' => 'ct_body_text_color',
                'type' => 'color_rgba',
                'title' => 'Body Text Color',
            ),
            array (
                'desc' => 'Pick a background color make sure to use some transparency (.95 is default) so the background image shows through. Used on Call to Action sections, page header images, and the footer widget area.',
                'id' => 'ct_dark_overlay_background',
                'type' => 'color_rgba',
                'output' => array(
                    'background-color' => '.dark-overlay, #footer-widgets .dark-overlay'
                ),
                'title' => 'Dark Overlay Background Color',
            ),

            // ── Forms ─────────────────────────────────────────────────────────
            array( 'id' => 'section_secondary_forms', 'type' => 'section', 'title' => 'Forms & Inputs' ),

            array (
                'desc' => 'Pick a background color for text inputs, selects, and textareas.',
                'id' => 'ct_input_background_color',
                'type' => 'color_rgba',
                'title' => 'Input Background Color',
            ),
            array (
                'desc' => 'Pick a border color for text inputs, selects, and textareas.',
                'id' => 'ct_input_border_color',
                'type' => 'color_rgba',
                'title' => 'Input Border Color',
            ),
            array (
                'desc' => 'Pick a text color for typed content inside inputs, selects, and textareas. Useful when using a light input background with a light body text color.',
                'id' => 'ct_input_text_color',
                'type' => 'color_rgba',
                'title' => 'Input Text Color',
            ),

            // ── Listings ──────────────────────────────────────────────────────
            array( 'id' => 'section_secondary_listings', 'type' => 'section', 'title' => 'Listings' ),

            array (
                'desc' => 'Pick a font color for listings single page heading.',
                'id' => 'ct_listing_heading_font_color',
                'type' => 'color_rgba',
                'title' => 'Listing Single Heading Color',
            ),
            array (
                'desc' => 'Pick a font color for the listing property info area.',
                'id' => 'ct_listing_font_color',
                'type' => 'color_rgba',
                'title' => 'Listing Property Info Font Color',
            ),
            array (
                'desc' => 'Pick a background color for the listing property info area.',
                'id' => 'ct_listing_background_color',
                'type' => 'color_rgba',
                'title' => 'Listing Property Info Background Color',
            ),
            array (
                'desc' => 'Pick a bottom border color for listing property info rows.',
                'id' => 'ct_listing_border_bottom_color',
                'type' => 'color_rgba',
                'title' => 'Listing Property Info Border Color',
            ),
            array (
                'desc' => 'Pick a font color for the listings request more info area.',
                'id' => 'ct_listing_more_info_font_color',
                'type' => 'color_rgba',
                'title' => 'Listing Single Request More Info Color',
            ),
            array (
                'desc' => 'Pick a background color for price badges on listing cards and the single listing page.',
                'id' => 'ct_price_bg',
                'type' => 'color_rgba',
                'output' => array(
                    'background-color' => ' .price, .grid-listing-info .price, .list-listing-info .price, .single-listings article .price, .saved-listings .fav-listing .price',
                    'color' => 'li.listing.modern .price'
                ),
                'title' => 'Price Badge Background Color',
            ),
            array (
                'desc' => 'Pick a text color for price badges.',
                'id' => 'ct_price_text_color',
                'type' => 'color_rgba',
                'output' => array(
                    'color' => '.price, .packages-container .price, .infobox h4.price, .infobox h4.price a, .infobox h4.price a:visited, .single-listings #listings-three-header h4.price, .single-listings #listings-four-header h4.price, .single-listings #listings-five-header h4.price, .single-listings .fa-check-square, li.listing.modern .price, li.listing.modern_two .price, li.listing.modern_two .price a, li.listing.modern_two .price a:visited, .grid-listing-info .price, .list-listing-info .price, .single-listings article .price, .saved-listings .fav-listing .price, #ct-listing-single-modal #ajax-single-listing-price-wrap .price'
                ),
                'title' => 'Price Badge Text Color',
            ),

            // ── Listing Cards ─────────────────────────────────────────────────
            array( 'id' => 'section_secondary_cards', 'type' => 'section', 'title' => 'Listing Cards' ),

            array (
                'desc' => 'Pick a background color for the "View Listing" button on modern listing cards.',
                'id' => 'ct_listing_view_btn_bg',
                'type' => 'color_rgba',
                'title' => 'View Listing Button Background',
            ),
            array (
                'desc' => 'Pick a text color for the "View Listing" button on modern listing cards.',
                'id' => 'ct_listing_view_btn_text',
                'type' => 'color_rgba',
                'title' => 'View Listing Button Text Color',
            ),
            array (
                'desc' => 'Pick a background color for the status pill shown on listing cards (e.g. Active, Sold, Pending).',
                'id' => 'ct_status_snipe_color',
                'type' => 'color_rgba',
                'title' => 'Status Pill Background',
            ),
            array (
                'desc' => 'Pick a background color for the Featured pill shown on listing cards.',
                'id' => 'ct_status_featured_color',
                'type' => 'color_rgba',
                'title' => 'Featured Pill Background',
            ),
            array (
                'desc' => 'Pick a background color for the featured listings "View All" button on the homepage.',
                'id' => 'ct_featured_view_all',
                'type' => 'color_rgba',
                'title' => 'Featured View All Button Background',
            ),

            // ── Search & Map ──────────────────────────────────────────────────
            array( 'id' => 'section_secondary_search', 'type' => 'section', 'title' => 'Search & Map' ),

            array (
                'desc' => 'Pick a background color for the map toggle and frontend listing tool buttons in search results.',
                'id' => 'ct_map_toggle',
                'type' => 'color_rgba',
                'title' => 'Map Toggle & Tools Button Background',
            ),
            array (
                'desc' => 'Pick a text color for the map toggle and frontend listing tool buttons.',
                'id' => 'ct_map_toggle_text_color',
                'type' => 'color_rgba',
                'output' => array(
                    'color' => 'span.map-toggle a, span.search-toggle a, .listing-tools li a.btn'
                ),
                'title' => 'Map Toggle & Tools Button Text Color',
            ),

            // ── Filter Pills ──────────────────────────────────────────────────
            array( 'id' => 'section_secondary_filter_pills', 'type' => 'section', 'title' => 'Search Filter Pills' ),

            array (
                'desc'  => 'Background color for the active search filter chips shown on the manually entered listings search page.',
                'id'    => 'ct_filter_pill_bg',
                'type'  => 'color_rgba',
                'title' => 'Filter Pill Background',
            ),
            array (
                'desc'  => 'Text color for the active search filter chips.',
                'id'    => 'ct_filter_pill_text',
                'type'  => 'color_rgba',
                'title' => 'Filter Pill Text Color',
            ),
            array (
                'desc'  => 'Color for the × dismiss icon on each active search filter chip.',
                'id'    => 'ct_filter_pill_remove_color',
                'type'  => 'color_rgba',
                'title' => 'Filter Pill Dismiss Icon Color',
            ),

            // ── Widgets & Sidebar ─────────────────────────────────────────────
            array( 'id' => 'section_secondary_widgets', 'type' => 'section', 'title' => 'Widgets & Sidebar' ),

            array (
                'desc' => 'Pick a background color for sidebar widget cards.',
                'id' => 'ct_sidebar_widget_bg',
                'type' => 'color_rgba',
                'title' => 'Sidebar Widget Background',
            ),
            array (
                'desc' => 'Pick a link color for items listed inside sidebar widgets.',
                'id' => 'ct_sidebar_widget_link_color',
                'type' => 'color_rgba',
                'title' => 'Sidebar Widget Link Color',
            ),
            array (
                'desc' => 'Pick a hover color for links inside sidebar widgets.',
                'id' => 'ct_sidebar_widget_link_hover_color',
                'type' => 'color_rgba',
                'title' => 'Sidebar Widget Link Hover Color',
            ),
            array (
                'desc' => 'Pick a background color for widget header bars.',
                'id' => 'ct_widget_header_bg_color',
                'type' => 'color_rgba',
                'title' => 'Widget Header Background Color',
            ),
            array (
                'desc' => 'Pick a border color for the user sidebar menu item separators.',
                'id' => 'ct_user_sidebar_menu_item_border_bottom_color',
                'type' => 'color_rgba',
                'title' => 'User Sidebar Menu Item Border Color',
                'output' => array(
                    'border-bottom-color' => 'aside ul.user-nav li',
                ),
            ),

            // ── User Sidebar Navigation ───────────────────────────────────────
            array( 'id' => 'section_secondary_user_sidebar', 'type' => 'section', 'title' => 'User Sidebar Navigation' ),

            array(
                'id'    => 'ct_user_sidebar_bg',
                'type'  => 'color_rgba',
                'title' => 'Sidebar Background',
                'desc'  => 'Background color for the sidebar navigation container.',
            ),
            array(
                'id'    => 'ct_user_sidebar_link_bg',
                'type'  => 'color_rgba',
                'title' => 'Nav Item Background',
                'desc'  => 'Background color for sidebar navigation links. Overrides the global Secondary Background Color for the sidebar specifically.',
            ),
            array(
                'id'    => 'ct_user_sidebar_link_color',
                'type'  => 'color_rgba',
                'title' => 'Nav Item Text Color',
                'desc'  => 'Text color for sidebar navigation links. Overrides the global Secondary Text Color for the sidebar specifically.',
            ),
            array(
                'id'    => 'ct_user_sidebar_current_bg',
                'type'  => 'color_rgba',
                'title' => 'Active Item Background',
                'desc'  => 'Background color for the currently active sidebar navigation item.',
            ),
            array(
                'id'    => 'ct_user_sidebar_current_color',
                'type'  => 'color_rgba',
                'title' => 'Active Item Text Color',
                'desc'  => 'Text color for the currently active sidebar navigation item.',
            ),
            array(
                'id'    => 'ct_user_sidebar_icon_color',
                'type'  => 'color_rgba',
                'title' => 'Icon & Badge Color',
                'desc'  => 'Fill color for SVG icons and count badge text/border in the sidebar navigation. Hover states automatically use your Secondary Brand Color.',
            ),

        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Links', 'contempo' ),
        'id'               => 'create-a-skin-links',
        'group'            => 'Appearance',
        'subsection'       => true,
        'fields'           => array(

            array(
                'id' => 'info_critical_links',
                'type' => 'info',
                'style' => 'info',
                'title' => __('', 'contempo'),
                'desc' => ''
            ),

            array (
                'id' => 'ct_link_color',
                'type' => 'color_rgba',
                'title' => 'Link Color',
            ),
            array (
                'id' => 'ct_visited_color',
                'type' => 'color_rgba',
                'title' => 'Visited Link Color',
            ),
            array (
                'id' => 'ct_hover_color',
                'type' => 'color_rgba',
                'title' => 'Hover Link Color',
            ),
            array (
                'id' => 'ct_active_color',
                'type' => 'color_rgba',
                'title' => 'Active Link Color',
            ),
            
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Footer', 'contempo' ),
        'id'               => 'create-a-skin-footer',
        'group'            => 'Appearance',
        'subsection'       => true,
        'fields'           => array(

            array(
                'id' => 'info_critical_footer',
                'type' => 'info',
                'style' => 'info',
                'title' => __('', 'contempo'),
                'desc' => ''
            ),

            // ── Footer Bar ────────────────────────────────────────────────────
            array( 'id' => 'section_footer_bar', 'type' => 'section', 'title' => 'Footer Bar' ),

            array (
                'desc' => 'Pick a background color for the main footer bar.',
                'id' => 'ct_footer_background',
                'type' => 'color_rgba',
                'title' => 'Footer Background Color',
            ),
            array (
                'desc' => 'Pick a color for the top border line of the footer bar.',
                'id' => 'ct_footer_border_top_color',
                'type' => 'color_rgba',
                'title' => 'Footer Top Border Color',
            ),
            array (
                'desc' => 'Pick a color for footer text, copyright notice, and nav links.',
                'id' => 'ct_footer_link_color',
                'type' => 'color_rgba',
                'title' => 'Footer Text & Link Color',
            ),
            array (
                'desc' => 'Pick a hover color for footer nav links.',
                'id' => 'ct_footer_link_hover_color',
                'type' => 'color_rgba',
                'title' => 'Footer Nav Link Hover Color',
            ),

            // ── Widget Area ───────────────────────────────────────────────────
            array( 'id' => 'section_footer_widgets', 'type' => 'section', 'title' => 'Widget Area' ),

            array (
                'desc' => 'Pick a background color for the footer widget area.',
                'id' => 'ct_footer_widget_background',
                'type' => 'color_rgba',
                'title' => 'Widget Area Background Color',
            ),
            array (
                'desc' => 'Upload a background image for the footer widget area.',
                'id' => 'ct_footer_background_img',
                'type' => 'media',
                'title' => 'Widget Area Background Image',
                'url' => true,
            ),
            array (
                'desc' => 'Pick a font color for footer widget headings.',
                'id' => 'ct_footer_widget_heading_color',
                'type' => 'color_rgba',
                'title' => 'Widget Heading Color',
            ),
            array (
                'desc' => 'Pick a font color for footer widget body text.',
                'id' => 'ct_footer_widget_font_color',
                'type' => 'color_rgba',
                'title' => 'Widget Text Color',
            ),
            array (
                'desc' => 'Pick a hover color for links inside footer widgets. Useful when the footer background is dark.',
                'id' => 'ct_footer_widget_link_hover_color',
                'type' => 'color_rgba',
                'title' => 'Widget Link Hover Color',
            ),
            array (
                'desc' => 'Pick a border color for list item separators inside footer widgets.',
                'id' => 'ct_footer_widget_border_color',
                'type' => 'color_rgba',
                'title' => 'Widget Item Border Color',
            ),
            
        )
    ) );

    /* =========================================================================
     * GROUP: Listings
     * Sections: Agents, Profile, Agent Single, Brokerages, Advanced Search,
     *           Off-Market Listings, Listing Images, Single Detail,
     *           Listings (non-IDX), Images, Search, Listing Alerts,
     *           Favorite Listings
     * ========================================================================= */

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Agents', 'contempo' ),
        'id'               => 'agents',
        'group'            => 'Listings',
        'icon'             => 'fas fa-users',
        'fields'           => array(
            array (
                'desc' => 'Select Yes if you\'d only like admins to be able to assign a user as an agent via their user profile, otherwise the user can manage this setting themseleves. Useful for sites that have open registration.',
                'id' => 'ct_agents_assign',
                'type' => 'switch',
                'title' => 'Only Admin Level can assign User as Agent?',
                'default' => 'no',
            ),
            array (
                'desc' => 'Select whether or not you\'d like to manually order agents when using the Agents page template, if Yes then an order number needs to be set by Users > Profile > Agent Order > 1, 2, 3&hellip; <a href="https://cl.ly/3a0C3H2p1Y0u" target="_blank">Screenshot</a>.',
                'id' => 'ct_agents_ordering',
                'type' => 'switch',
                'title' => 'Manually Order Agents?',
                'default' => 'no',
            ),
            array (
                'desc' => '',
                'id' => 'ct_agent_layout',
                'type' => 'image_select',
                'options' => array (
                    'agent-wide' => get_template_directory_uri() . '/admin/images/agent-wide.png',
                    'agent-grid' => get_template_directory_uri() . '/admin/images/agent-grid.png',
                ),
                'title' => 'Select a layout',
                'default' => 'agent-wide',
            ),
            array (
                'desc' => 'Select whether or not you\'d like to enable the agent search form with pagination, great for when you have a lot of agents and brokers on the site.',
                'id' => 'ct_agents_search',
                'type' => 'switch',
                'title' => 'Enable Agents Search?',
                'default' => 'no',
            ),
            array (
                'desc' => 'Drag and drop manager, to quickly choose which fields you\'d like to display.',
                'id' => 'ct_agents_search_fields',
                'type' => 'sorter',
                'title' => 'Agents Search Fields',
                'required' => array('ct_agents_search','=','yes'),
                'options' => array (
                    'disabled' => array (
                        'placebo' => 'placebo',
                    ),
                    'enabled' => array (
                        'placebo' => 'placebo',
                        'city' => 'City',
                        'state' => 'State',
                        'zipcode' => 'Zipcode',
                        //'keyword' => 'Keyword',
                    ),
                ),
            ),
            array (
                'desc' => 'Select the roles you\'d like to include in the agents search.',
                'id' => 'ct_agents_search_roles',
                'required' => array('ct_agents_search','=','yes'),
                'type' => 'select',
                'multi'    => true,
                'data' => 'roles',
                /*'options' => array (
                    'no' => 'No',
                    'yes' => 'Yes',
                ),*/
                'title' => 'Roles to Include in Search?',
                'default' => array('agent', 'broker', 'administrator', 'editor', 'author', 'contributor'),
            ),
            array (
                'desc' => 'Enter the number of agents you\'d like to show per page, to show all enter -1',
                'id' => 'ct_agents_per_page',
                'type' => 'text',
                'title' => 'Number of Agents Per Page',
                'default' => '-1',
            ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'User Profile Fields', 'contempo' ),
        'id'               => 'profile',
        'group'            => 'Listings',
        'subsection'       => true,
        'fields'           => array(

            array (
                'desc' => 'Includes Twitter, Facebook, Instagram, LinkedIn & YouTube.',
                'id' => 'ct_social_profile_info',
                'type' => 'switch',
                'title' => 'Display Social Profile Information Section?',
                'default' => 'yes',
            ),

            array (
                'desc' => 'Includes mark as agent, agent order, profile image, mobile #, fax #, Title, Tagline & Agent License # fields.',
                'id' => 'ct_extra_profile_info',
                'type' => 'switch',
                'title' => 'Display Extra Profile Information Section?',
                'default' => 'yes',
            ),

            array (
                'desc' => 'Includes agent testimonials textarea.',
                'id' => 'ct_agent_testimonials',
                'type' => 'switch',
                'title' => 'Display Agent Testimonials Section?',
                'default' => 'yes',
            ),

            array (
                'desc' => 'Includes personal logo, brokerage, brokerage license #, office #, street address, city, state or province & postal code fields.',
                'id' => 'ct_office_information',
                'type' => 'switch',
                'title' => 'Display Office Information Section?',
                'default' => 'yes',
            ),

            array (
                'desc' => 'Choose whether you\'d like to use the default input field (Global) or a select (US Only).',
                'id' => 'ct_profile_state_select',
                'type' => 'switch',
                'title' => 'Use State Select?',
                'default' => 'no',
            ),

        )
    ) );
    
    if (!class_exists('Contempo\IDXPro\Admin\SettingsPage')) {
        CT_Settings::set_section( $opt_name, array(
            'title'            => __( 'Agent Single', 'contempo' ),
            'id'               => 'agent-single',
            'group'            => 'Listings',
            'subsection'       => true,
            'fields'           => array(
                array (
                    'desc' => '',
                    'id' => 'ct_agent_single_layout',
                    'type' => 'image_select',
                    'options' => array (
                        'agent-wide' => get_template_directory_uri() . '/admin/images/agent-single-wide.png',
                        'agent-sidebar' => get_template_directory_uri() . '/admin/images/agent-single-sidebar.png',
                    ),
                    'title' => 'Select a Single Agent layout',
                    'default' => 'agent-wide',
                ),
                array (
                    'desc' => 'Set the slug for agent profile pages here to whatever you\'d like (all lowercase, no spaces, dashes are allowed). <strong>IMPORTANT:</strong> Once you done that save > then go to Settings > Permalinks > Save Settings, and you\'ll be good to go, <strong><em>if you don\'t you\'ll get 404 errors for all your agent profile pages</em></strong>.',
                    'id' => 'ct_agent_single_slug',
                    'type' => 'text',
                    'title' => 'Agents Single Slug',
                    'default' => 'agents',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to use the default modal form or a simple "mailto:" link which will trigger the users default email provider. Can be useful to use the "Mailto Link" option if your server/hosting provider doesn\'t allow for, or is blocking wp_mail() functions.',
                    'id' => 'ct_agent_single_form_or_mailto',
                    'type' => 'select',
                    'options' => array (
                        'form' => 'Form',
                        'mailto' => 'Mailto Link',
                    ),
                    'title' => 'Contact Type',
                    'default' => 'form',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to display the agents listings or not.',
                    'id' => 'ct_agent_single_listings',
                    'type' => 'switch',
                    'title' => 'Disable Listings?',
                    'default' => 'no',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to hide the agents sold listings or not.',
                    'id' => 'ct_agent_single_listings_hide_solds',
                    'type' => 'switch',
                    'title' => 'Hide Solds?',
                    'default' => 'no',
                ),
                array (
                    'desc' => 'Enter the number of agents listings you\'d like to show per page, to show all enter -1',
                    'id' => 'ct_agents_listings_per_page',
                    'type' => 'text',
                    'title' => 'Number of Agent Listings Per Page',
                    'default' => '9',
                ),
            )
        ) );
    } else {
        CT_Settings::set_section( $opt_name, array(
            'title'            => __( 'Agent Single', 'contempo' ),
            'id'               => 'agent-single-idx',
            'group'            => 'Listings',
            'subsection'       => true,
            'fields'           => array(
                array (
                    'desc' => '',
                    'id' => 'ct_agent_single_layout',
                    'type' => 'image_select',
                    'options' => array (
                        'agent-wide' => get_template_directory_uri() . '/admin/images/agent-single-wide.png',
                        'agent-sidebar' => get_template_directory_uri() . '/admin/images/agent-single-sidebar.png',
                    ),
                    'title' => 'Select a Single Agent layout',
                    'default' => 'agent-wide',
                ),
                array (
                    'desc' => 'Set the slug for agent profile pages here to whatever you\'d like (all lowercase, no spaces, dashes are allowed). <strong>IMPORTANT:</strong> Once you done that save > then go to Settings > Permalinks > Save Settings, and you\'ll be good to go, <strong><em>if you don\'t you\'ll get 404 errors for all your agent profile pages</em></strong>.',
                    'id' => 'ct_agent_single_slug',
                    'type' => 'text',
                    'title' => 'Agents Single Slug',
                    'default' => 'agents',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to use the default modal form or a simple "mailto:" link which will trigger the users default email provider. Can be useful to use the "Mailto Link" option if your server/hosting provider doesn\'t allow for, or is blocking wp_mail() functions.',
                    'id' => 'ct_agent_single_form_or_mailto',
                    'type' => 'select',
                    'options' => array (
                        'form' => 'Form',
                        'mailto' => 'Mailto Link',
                    ),
                    'title' => 'Contact Type',
                    'default' => 'form',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to display the agents listings or not.',
                    'id' => 'ct_agent_single_listings',
                    'type' => 'switch',
                    'title' => 'Disable Listings?',
                    'default' => 'no',
                ),
            )
        ) );
    }
    
    // Only show if CT IDX Pro+ is not active
    if (!class_exists('Contempo\IDXPro\Admin\SettingsPage')) {

        CT_Settings::set_section( $opt_name, array(
            'title'            => __( 'Brokerages', 'contempo' ),
            'id'               => 'brokerages',
            'group'            => 'Listings',
            'icon'             => 'fas fa-building',
            'fields'           => array(
                array (
                    'desc' => '',
                    'id' => 'ct_brokerage_layout',
                    'type' => 'image_select',
                    'options' => array (
                        'brokerage-wide' => get_template_directory_uri() . '/admin/images/brokerage-wide.png',
                        'brokerage-grid' => get_template_directory_uri() . '/admin/images/brokerage-grid.png',
                    ),
                    'title' => 'Select a layout',
                    'default' => 'brokerage-wide',
                ),
            )
        ) );

    }

    /* =========================================================================
     * GROUP: Integrations
     * Sections: Google Maps, Google reCAPTCHA, Analytics, WalkScore,
     *           MailChimp, Follow Up Boss, Zapier, Yelp, Lofty
     * ========================================================================= */

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Google Maps', 'contempo' ),
        'id'               => 'google-maps',
        'group'            => 'Integrations',
        'icon'             => 'fas fa-map',
        'fields'           => array(
            array (
                'desc' => 'To get your API key please see <a href="https://contempothemes.com/docs/google-maps/" target="_blank">Google Maps</a> in the documentation.',
                'id' => 'ct_google_maps_api_key',
                'type' => 'text',
                'title' => 'Google Maps API Key',
                'default' => '',
            ),
            array (
                'desc' => 'Choose your map display type. NOTE: This applies sitewide.',
                'id' => 'ct_contact_map_type',
                'type' => 'select',
                'options' => array (
                    'ROADMAP' => 'Roadmap',
                    'SATELLITE' => 'Satellite',
                    'HYBRID' => 'Hybrid',
                    'TERRAIN' => 'Terrain',
                ),
                'title' => 'Google Map Type?',
                'default' => 'ROADMAP',
            ),
            array (
                'desc' => 'Select whether you\'d like to use custom map styles or default sitewide.',
                'id' => 'ct_google_maps_style',
                'type' => 'select',
                'options' => array (
                    'custom' => 'Custom',
                    'default' => 'Default',
                ),
                'title' => 'Custom or Default Google Maps Styles',
                'default' => 'custom',
            ),
            array (
                'desc' => 'Enter your own style from <a href="https://snazzymaps.com/">Snazzy Maps</a>, or take the easier route and use the free <a href="https://snazzymaps.com/plugins/wordpress">Snazzy Maps WordPress plugin</a>.',
                'id' => 'ct_google_maps_snazzy_style',
                'type' => 'textarea',
                'title' => 'Add your own style from Snazzy Maps',
                'default' => '[{"featureType":"water","stylers":[{"visibility":"on"},{"color":"#acbcc9"}]},{"featureType":"landscape","stylers":[{"color":"#f2e5d4"}]},{"featureType":"administrative","stylers":[{"visibility":"on"},{"lightness":33}]},{"featureType":"road"},[],{"featureType":"road","stylers":[{"lightness":20}]}]',
            ),
        )
    ) );
    
    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Google reCAPTCHA', 'contempo' ),
        'id'               => 'google-recaptcha',
        'group'            => 'Integrations',
        'icon'             => 'fab fa-google',
        'desc'   => __( 'To get your recaptcha public and secret keys you must first <a href="https://www.google.com/recaptcha/admin/create" target="_blank">register your site</a> with Google reCAPTCHA.', 'contempo' ),
        'fields'           => array(
            array (
                'desc' => 'Select whether you\'d like to use Google reCAPTCHA for all the themes built-in forms.',
                'id' => 'ct_use_google_recaptcha',
                'type' => 'switch',
                'title' => 'Use Google reCAPTCHA?',
                'default' => 'no',
            ),
            array (
                'desc' => 'Enter your Google reCAPTCHA public key here.',
                'id' => 'ct_google_recaptcha_public_key',
                'type' => 'text',
                'title' => 'Site Key',
                'default' => '',
                'required' => array('ct_use_google_recaptcha','equals','yes'),
            ),       
            array (
                'desc' => 'Enter your Google reCAPTCHA secret key here.',
                'id' => 'ct_google_recaptcha_secret_key',
                'type' => 'text',
                'title' => 'Secret Key',
                'default' => '',
                'required' => array('ct_use_google_recaptcha','equals','yes'),
            ),
        )
    ) );

    // Only show if CT IDX Pro+ is not active
    if (!class_exists('Contempo\IDXPro\Admin\SettingsPage')) {
        CT_Settings::set_section( $opt_name, array(
            'title'            => __( 'Advanced Search', 'contempo' ),
            'id'               => 'advanced-search',
            'group'            => 'Listings',
            'subsection'       => false,
            'icon'             => 'fas fa-search',
            'fields'           => array(

                $fields = array(
                'id' => 'section-global-search',
                'type' => 'section',
                'title' => __('Global Options', 'contempo'),
                //'subtitle' => __('These options apply globally.', 'contempo'),
                'indent' => true 
                ),

                    array (
                        'subtitle' => 'Drag and drop manager, to quickly organize your advanced search fields, this affects the "More" expanded area.',
                        'id' => 'ct_home_adv_search_fields',
                        'type' => 'sorter',
                        'title' => 'Listings Search Field Manager',
                        'options' => array (
                            'disabled' => array (
                                'placebo' => 'placebo',
                                'type_multi' => 'Type (multi)',
                                'status_multi' => 'Status (multi)',
                                'additional_features' => 'Additional Features',
                                'popular_features' => 'Popular Features',
                                'beds_plus' => 'Beds +',
                                'baths_plus' => 'Baths +',
                                'brokerage' => 'Brokerage',
                                'country' => 'Country',
                                'county' => 'County',
                                'community' => 'Community',
                                'school_district' => 'School District',
                                'mls' => 'Property ID',
                                'numguests' => 'Num of Guests',
                                'price_from_to_slider' => 'Price Slider',
                                'sqft_from' => 'Size From',
                                'sqft_to' => 'Size To',
                                'sqft_from_to_slider' => 'Size Slider',
                                'lotsize_from' => 'Lot Size From',
                                'lotsize_to' => 'Lot Size To',
                                'lotsize_from_to_slider' => 'Lot Size Slider',
                                'year_from' => 'Year From',
                                'year_to' => 'Year To',
                            ),
                            'enabled' => array (
                                'placebo' => 'placebo',
                                'type' => 'Type',
                                'city' => 'City',
                                'state' => 'State',
                                'zipcode' => 'Zipcode',
                                'beds' => 'Beds',
                                'baths' => 'Baths',
                                'status' => 'Status',
                                'price_from' => 'Price From',
                                'price_to' => 'Price To',
                            ),
                        ),
                    ),

                    array (
                        'desc' => 'Choose the style you\'d like to use for the "More" filters header area. <strong>Note:</strong> If you choose to enable the "Field Name (multi)", "Bed +", "Bath +" or "Additional" fields in the "Listings Search Field Manager" this will automatically default to style two.',
                        'id' => 'ct_adv_search_more_layout',
                        'type' => 'image_select',
                        'options' => array (
                            'adv-search-more-one' => get_template_directory_uri() . '/admin/images/adv-search-more-one-small.png',
                            'adv-search-more-two' => get_template_directory_uri() . '/admin/images/adv-search-more-two-small.png',
                        ),
                        'title' => 'More Search Options Layout',
                        'default' => 'adv-search-more-one',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to enable the Advanced Search page which shows all search fields no matter what is chosen above in the layout manager <a href="https://cl.ly/3w091l1B1i0d" target="_blank">Example Screenshot</a>.',
                        'id' => 'ct_enable_adv_search_page',
                        'type' => 'switch',
                        'title' => 'Enable Separate Advanced Search Page?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select the page you\'ve created and applied the "Advanced Search" page template to.',
                        'id' => 'ct_adv_search_page',
                        'type' => 'select',
                        'data' => 'pages',
                        'title' => 'Advanced Search Page',
                        'required' => array('ct_enable_adv_search_page','equals','yes'),
                        'default' => '',
                    ),

                    array( 
                        'id'       => 'ct_price_min_max_heading',
                        'type'     => 'raw',
                        'title'    => __('', 'contempo'),
                        'content'  => '<h3 style="margin-top: 60px; border-bottom: none;">Price Slider Min/Max</h3>'
                    ),

                    array (
                        'id' => 'ct_adv_search_price_slider_min_value',
                        'type'      => 'text',
                        'title'     => 'Min Value',
                        'desc'      => 'The minimum value for the "Price Slider" search field.',
                        'default'   => 10000,
                    ),

                    array (
                        'id' => 'ct_adv_search_price_slider_max_value',
                        'type'      => 'text',
                        'title'     => 'Max Value',
                        'desc'      => 'The maximum value for the "Price Slider" search field. Set this to the highest listing price in your market.',
                        'default'   => 5000000,
                    ),

                    array( 
                        'id'       => 'ct_size_min_max_heading',
                        'type'     => 'raw',
                        'title'    => __('', 'contempo'),
                        'content'  => '<h3 style="border-bottom: none;">Size Slider Min/Max</h3>'
                    ),

                    array (
                        'id' => 'ct_adv_search_size_slider_min_value',
                        'type'      => 'text',
                        'title'     => 'Min Value',
                        'desc'      => 'The minimum value for the "Size Slider" search field.',
                        'default'   => 100,
                    ),

                    array (
                        'id' => 'ct_adv_search_size_slider_max_value',
                        'type'      => 'text',
                        'title'     => 'Max Value',
                        'desc'      => 'The maximum value for the "Size Slider" search field.',
                        'default'   => 10000,
                    ),

                    array( 
                        'id'       => 'ct_lot_size_min_max_heading',
                        'type'     => 'raw',
                        'title'    => __('', 'contempo'),
                        'content'  => '<h3 style="border-bottom: none;">Lot Size Slider Min/Max</h3>'
                    ),

                    array (
                        'id' => 'ct_adv_search_lot_size_slider_min_value',
                        'type'      => 'text',
                        'title'     => 'Min Value',
                        'desc'      => 'The minimum value for the "Lot Size Slider" search field.',
                        'default'   => 1,
                    ),

                    array (
                        'id' => 'ct_adv_search_lot_size_slider_max_value',
                        'type'      => 'text',
                        'title'     => 'Max Value',
                        'desc'      => 'The maximum value for the "Lot Size Slider" search field.',
                        'default'   => 100,
                    ),

                array(
                    'id'     => 'section-global-search-end',
                    'type'   => 'section',
                    'indent' => false,
                ),
                )
            ) );

            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'Header Search', 'contempo' ),
                //'desc'             => __( 'These options apply to the header advanced search if its enabled.', 'contempo'),
                'id'               => 'advanced-search-header',
            'group'            => 'Listings',
                'subsection'       => true,
                'fields'           => array(

                    array (
                        'desc' => 'Choose if you would like to enable the header listing search.',
                        'id' => 'ct_header_listing_search',
                        'type' => 'switch',
                        'title' => 'Header Listing Search?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Choose if you would like to hide the header listing search only for the homepage, all other interior pages it\'ll be shown.',
                        'id' => 'ct_header_listing_search_hide_homepage',
                        'type' => 'switch',
                        'title' => 'Hide Header Search on Homepage?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Choose specific pages you would like to hide the header listing search.',
                        'id' => 'ct_header_listing_search_hide_specific_pages',
                        'type' => 'page_picker',
                        'title' => 'Hide Header Search on Specific Pages',
                    ),

                    array (
                        'desc' => 'Choose if you would like to hide the header listing search for seller, agent &amp; broker roles logged-in pages, includes dashboard, activity, leads, analytics, my listings, submit listing, edit listing, membership, invoices, and account settings.',
                        'id' => 'ct_header_listing_search_hide_user_loggedin',
                        'type' => 'switch',
                        'title' => 'Hide Header Search on User Logged-in Pages?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select yes if you want to display suggested results while typing in the street, city, state or zip search field.',
                        'id' => 'ct_keyword_suggested_results',
                        'type' => 'switch',
                        'title' => 'Display Street, City, State, or Zip > Suggested Results?',
                        'default' => 'yes',
                    ),

                   /*array (
                        'desc' => 'Select yes if you want the state and city to be disabled until a country is selected.',
                        'id' => 'ct_header_listing_search_ajaxify_country_state_city',
                        'type' => 'switch',
                        'title' => 'Use Country / State / City hierarchy?',
                        'default' => 'no',
                    ),*/

                    array (
                        'subtitle' => 'Drag and drop manager, these are the fields that will be visible in the header search area, maximum of 4.<br /><br />The rest of the fields set in the Advanced Search > Global Options > Listings Search Field Manager will be displayed in the expandable area when clicking "More" on the right of the search button.',
                        'id' => 'ct_header_adv_search_fields',
                        'type' => 'sorter',
                        'title' => 'Header Search Field Manager',
                        'required' => array('ct_header_listing_search','equals','yes'),
                        'options' => array (
                            'disabled' => array (
                                'header_type' => 'Type',
                                'header_beds' => 'Beds',
                                'header_baths' => 'Baths',
                                'header_beds_plus' => 'Beds +',
                                'header_baths_plus' => 'Baths +',
                                'header_status' => 'Status',
                                'header_status_multi' => 'Status (multi)',
                                'header_price_from' => 'Price From',
                                'header_price_to' => 'Price To',
                                'header_price_from_to_slider' => 'Price Slider',
                                'header_additional_features' => 'Additional Features',
                                'header_brokerage' => 'Brokerage',
                                'header_city_multi' => 'City (multi)',
                                //'header_state_multi' => 'State (multi)',
                                'header_country' => 'Country',
                                'header_county' => 'County',
                                //'header_county_multi' => 'County (multi)',
                                'header_community' => 'Community',
                                'header_mls' => 'Property ID',
                                'header_numguests' => 'Num of Guests',
                                'header_sqft_from' => 'Size From',
                                'header_sqft_to' => 'Size To',
                                'header_size_from_to_slider' => 'Size Slider',
                                'header_lotsize_from' => 'Lot Size From',
                                'header_lotsize_to' => 'Lot Size To',
                                'header_lotsize_from_to_slider' => 'Lot Size Slider',
                                'header_year_from' => 'Year From',
                                'header_year_to' => 'Year To',
                            ),
                            'enabled' => array (
                                'header_keyword' => 'Street, City…',
                                'header_city' => 'City',
                                'header_state' => 'State',
                                'header_zipcode' => 'Zipcode',
                            ),
                        ),
                    ),

                )
            ) );

            if(did_action('elementor/loaded')) {
                CT_Settings::set_section( $opt_name, array(
                    'title'            => __( 'Elementor Search Module', 'contempo' ),
                    //'desc'             => __( 'These options apply to the header advanced search if its enabled.', 'contempo'),
                    'id'               => 'advanced-search-elementor',
            'group'            => 'Listings',
                    'subsection'       => true,
                    'fields'           => array(

                        array (
                            'desc' => 'Drag and drop manager, these are the fields that will be visible in the Elementor Listings Search Module, max of 4.',
                            'id' => 'ct_elementor_adv_search_fields',
                            'type' => 'sorter',
                            'title' => 'Elementor Search Module Field Manager',
                            'subtitle' => 'Only visible fields, max of 4',
                            'options' => array (
                                'disabled' => array (
                                    'header_type' => 'Type',
                                    'header_state' => 'State',
                                    'header_beds' => 'Beds',
                                    'header_baths' => 'Baths',
                                    'header_beds_plus' => 'Beds +',
                                    'header_baths_plus' => 'Baths +',
                                    'header_price_from' => 'Price From',
                                    'header_price_to' => 'Price To',
                                    'header_price_from_to_slider' => 'Price Slider',
                                    'header_additional_features' => 'Additional Features',
                                    'header_country' => 'Country',
                                    'header_county' => 'County',
                                    'header_community' => 'Community',
                                    'header_mls' => 'Property ID',
                                    'header_numguests' => 'Num of Guests',
                                    'header_sqft_from' => 'Size From',
                                    'header_sqft_to' => 'Size To',
                                    'header_size_from_to_slider' => 'Size Slider',
                                    'header_lotsize_from' => 'Lot Size From',
                                    'header_lotsize_to' => 'Lot Size To',
                                    'header_lotsize_from_to_slider' => 'Lot Size Slider',
                                    'header_year_from' => 'Year From',
                                    'header_year_to' => 'Year To',
                                ),
                                'enabled' => array (
                                    'header_keyword' => 'Keyword',
                                    'header_status' => 'Status',
                                    'header_city' => 'City',
                                    'header_zipcode' => 'Zipcode',
                                ),
                            ),
                        ),

                    )
                ) );
            }

        }

        if (class_exists('Contempo\IDXPro\Admin\SettingsPage')) {

            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'Off-Market Listings', 'contempo' ),
                'id'               => 'off-market-listings',
            'group'            => 'Listings',
                'icon'             => 'fas fa-sign',
                'fields'           => array(
                    array(
                        'id' => 'info_critical_off_market_listings',
                        'type' => 'info',
                        'style' => 'info',
                        'title' => __('', 'contempo'),
                        'desc' => __('<strong>IMPORTANT:</strong> This panel\'s settings apply only to off-market listings that have been <a href="https://contempothemes.com/docs/ct-idx-pro-plus#12-toc-title" target="_blank">manually entered</a>. They do NOT affect listings from the MLS via CT IDX Pro+.', 'contempo')
                    ),

                    array (
                        'desc' => 'This default style applies to <a href="https://contempothemes.com/docs/elementor" target="_blank">Elementor</a> CT Listings modules on static pages. You can individually adjust the style for each module within your pages as needed.',
                        'id' => 'ct_search_results_listing_style',
                        'type' => 'select',
                        'options' => array (
                            'standard' => 'Standard Grid',
                            'modern' => 'Modern Grid',
                            'modern_two' => 'Modern Grid 2',
                            'minimal' => 'Minimal Grid',
                            'list' => 'List',
                        ),
                        'title' => 'Default Layout Style',
                        'default' => 'modern_two',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to disable the listing title formatting which converts the first character of each word to uppercase.',
                        'id' => 'ct_listings_title_formatting',
                        'type' => 'switch',
                        'title' => 'Disable Listing Title Formatting?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Set the slug for off-market listings here to whatever you\'d like (all lowercase, no spaces, dashes are allowed).<br><strong>IMPORTANT:</strong> Set your slug > Save Changes > then go to Settings > Permalinks > Save Settings <br><br><em>If you don\'t reset your permalinks all off-market (manually entered) listings will show a 404 error</em>.',
                        'id' => 'ct_listings_slug',
                        'type' => 'text',
                        'title' => 'Custom Slug',
                        'default' => 'listings',
                    ),
                )
            ) );

            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'Images', 'contempo' ),
                'id'               => 'listing-images',
            'group'            => 'Listings',
                'subsection'       => true,
                'fields'           => array(
                    array(
                        'id' => 'info_critical_off_market_listing_images',
                        'type' => 'info',
                        'style' => 'info',
                        'title' => __('', 'contempo'),
                        'desc' => __('<strong>IMPORTANT:</strong> This panel\'s settings apply only to off-market listings that have been <a href="https://contempothemes.com/docs/adding-managing-listings/" target="_blank">manually entered</a>. They do NOT affect listings from the MLS via CT IDX Pro+.', 'contempo')
                    ),

                    array (
                        'desc' => '<p></p>',
                        'id' => 'ct_listing_featured_image_cropping',
                        'type' => 'switch',
                        'title' => 'Crop Featured Image?',
                        'default' => 'yes',
                    ),

                    array(
                        'id' => 'info_critical_off_market_listing_images',
                        'type' => 'info',
                        'style' => 'info',
                        'title' => __('', 'contempo'),
                        'desc' => __('<p>Crops off-market listing images to 818&times;540 for a consistent look across your site.</p><p><strong>To apply:</strong> Install the <strong>Regenerate Thumbnails</strong> plugin, then run it via <strong>Tools &rarr; Regen. Thumbnails</strong>. Once complete, clear any caching plugin or CDN cache to see the updated images.</p>', 'contempo')
                    ),
                )
            ) );

            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'Single Detail', 'contempo' ),
                'id'               => 'off-market-single-detail',
            'group'            => 'Listings',
                'subsection'       => true,
                'fields'           => array(
                    array(
                        'id' => 'info_critical_off_market_listings_single_detail',
                        'type' => 'info',
                        'style' => 'info',
                        'title' => __('', 'contempo'),
                        'desc' => __('<strong>IMPORTANT:</strong> This panel\'s settings apply only to off-market listings that have been <a href="https://contempothemes.com/docs/ct-idx-pro-plus#12-toc-title" target="_blank">manually entered</a>. They do NOT affect listings from the MLS via CT IDX Pro+.', 'contempo')
                    ),

                    array (
                        'desc' => '<strong>NOTE:</strong> The second layout option really only <em>works best if your listings ALL have Multiple images</em> otherwise you\'ll get one large single image displayed full screen which doesn\'t work well for usability. If this is the case the first option works great for single image or multi-image listings.',
                        'id' => 'ct_listing_single_layout',
                        'type' => 'image_select',
                        'options' => array (
                            'listings-one' => get_template_directory_uri() . '/admin/images/listings-one.png',
                            'listings-two' => get_template_directory_uri() . '/admin/images/listings-two.png',
                            'listings-three' => get_template_directory_uri() . '/admin/images/listings-three.png',
                            'listings-four' => get_template_directory_uri() . '/admin/images/listings-four.png',
                            'listings-five' => get_template_directory_uri() . '/admin/images/listings-five.png',
                        ),
                        'title' => 'Listings Single layout',
                        'default' => 'listings-five',
                    ),

                    array (
                        'desc' => 'Select whether you\'d like the listing single content with a sidebar or full width.',
                        'id' => 'ct_listing_single_content_layout',
                        'type' => 'select',
                        'options' => array (
                            'sidebar' => 'w/Sidebar',
                            'full-width' => 'Full Width',
                        ),
                        'title' => 'Listing Single Content w/Sidebar or Full Width?',
                        'default' => 'sidebar',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like have a sticky sidebar which will stay with the user on scroll.',
                        'id' => 'ct_listing_single_sticky_sidebar',
                        'type' => 'switch',
                        'title' => 'Sticky Sidebar?',
                        'default' => 'no',
                        'required' => array('ct_listing_single_content_layout','equals','sidebar'),
                    ),

                    array (
                        'desc' => 'Drag and drop layout manager, to quickly organize your listing single main layout modules.',
                        'id' => 'ct_single_listing_main_layout',
                        'type' => 'sorter',
                        'title' => 'Main Layout Blocks',
                        'options' => array (
                            'disabled' => array (
                                'listing_creation_date' => 'Creation Date',
                            ),
                            'enabled' => array (
                                'listing_header' => 'Header',
                                'listing_price' => 'Price',
                                'listing_est_payment' => 'Est Payment',
                                'listing_prop_info' => 'Listing Info',
                                'listing_lead_media' => 'Image/Slider',
                                'listing_nav' => 'Section Nav Bar',
                                'listing_content' => 'Content',
                                'listing_contact' => 'Contact',
                                'listing_brokerage' => 'Brokerage',
                                'ct_affordability_calculator' => 'Affordability',
                                'listing_sub_listings' => 'Sub Listings',
                            ),
                        ),
                    ),

                    array (
                        'desc' => 'Drag and drop layout manager, to quickly organize your listing single header layout modules.',
                        'id' => 'ct_single_listing_header_layout',
                        'type' => 'sorter',
                        'title' => 'Header Layout',
                        'options' => array (
                            'disabled' => array (
                            ),
                            'enabled' => array (
                                'listing_status' => 'Status',
                                'listing_title' => 'Title/Address',
                                'listing_city_state_zip' => 'City/State/Post',
                                'listing_map_btn' => 'Map Button',
                                'listing_save_btn' => 'Save Button',
                            ),
                        ),
                    ),

                    array(
                    'id' => 'section-start',
                    'type' => 'section',
                    'title' => __('Estimated Payment', 'contempo'),
                    'subtitle' => __('If you have the "Est Payment" module enabled under the "Main Layout Blocks" manager, these are the assumptions settings used to display it.', 'contempo'),
                    'indent' => true 
                    ),

                        array (
                            'desc' => 'Select the assumed down payment percentage.',
                            'id' => 'ct_listing_est_payment_percent_down',
                            'type' => 'slider',
                            'title' => 'Down Payment %',
                            'default' => '20',
                            'min' => '1',
                            'max' => '100',
                            'step' => '1',
                        ),

                        array (
                            'desc' => 'Select the assumed interest rate.',
                            'id' => 'ct_listing_est_payment_interest_rate',
                            'type' => 'slider',
                            'title' => 'Interest Rate %',
                            'default' => '3',
                            'min' => '1',
                            'max' => '100',
                            'step' => '.1',
                            'resolution' => 0.01,
                        ),

                        array (
                            'desc' => 'Select the assumed annual property tax rate percentage.',
                            'id' => 'ct_listing_est_payment_tax_rate',
                            'type' => 'slider',
                            'title' => 'Annual Property Tax Rate %',
                            'default' => 0.78,
                            'min' => 0.1,
                            'max' => 100,
                            'step' => 0.1,
                            'resolution' => 0.01,
                        ),

                        array (
                            'desc' => 'Enter the amount of property insurance paid for each year.',
                            'id' => 'ct_listing_est_payment_home_insurance',
                            'type' => 'text',
                            'title' => 'Home Insurance',
                            'default' => 900,
                            'min' => 0,
                            'max' => 1000000,
                            'step' => 1,
                        ),

                        array (
                            'desc' => 'Select the term in years.',
                            'id' => 'ct_listing_est_payment_term',
                            'type' => 'slider',
                            'title' => 'Term',
                            'default' => '30',
                            'min' => '1',
                            'max' => '30',
                            'step' => '1',
                        ),

                    array(
                        'id'     => 'section-end',
                        'type'   => 'section',
                        'indent' => false,
                    ),

                    array(
                    'id' => 'section-start-get-prequalified',
                    'type' => 'section',
                    'title' => __('Get Pre-Qualified', 'contempo'),
                    'subtitle' => __('If you have the "Affordability" module enabled under the "Main Layout Blocks" manager, you can use this to display a button to "Get Pre-Qualified". This is perfect if you own your own mortgage company, have a partnership with one, or to use as an affiliate link for lead referrals.', 'contempo'),
                    'indent' => true 
                    ),

                        array (
                            'desc' => 'Select the link type: Disabled (button won\'t be displayed), Internal Page or External URL.',
                            'id' => 'ct_single_listing_get_prequalified_link_type',
                            'type' => 'select',
                            'options' => array (
                                'disabled' => 'Disabled',
                                'internal_page' => 'Internal Page',
                                'external_url' => 'External URL',
                            ),
                            'title' => 'Link Type',
                            'default' => 'disabled',
                        ),

                        array (
                            'desc' => 'Select the page you\'d like the button to link to.',
                            'id' => 'ct_single_listing_get_prequalified_page',
                            'title' => 'Internal Page',
                            'type' => 'select',
                            'data' => 'pages',
                            'required' => array('ct_single_listing_get_prequalified_link_type','equals','internal_page'),
                        ),

                        array (
                            'desc' => 'Enter the external URL you\'d like the button to link to.',
                            'id' => 'ct_single_listing_get_prequalified_external_url',
                            'title' => 'External URL',
                            'type' => 'text',
                            'placeholder' => 'https://your-lender-partner.com',
                            'required' => array('ct_single_listing_get_prequalified_link_type','equals','external_url'),
                        ),

                        array (
                            'desc' => 'Select the link target: New Window/Tab (just as it sounds), or Self (opens in same window/tab, default).',
                            'id' => 'ct_single_listing_get_prequalified_link_target',
                            'type' => 'select',
                            'options' => array (
                                '_blank' => 'New Window/Tab',
                                '_self' => 'Self',
                            ),
                            'title' => 'Link Type',
                            'required' => array('ct_single_listing_get_prequalified_link_type','!=','disabled'),
                        ),

                    array(
                        'id'     => 'section-end-get-prequalified',
                        'type'   => 'section',
                        'indent' => false,
                    ),

                    array (
                        'desc' => 'Select which content layout you\'d like to use, default (all visible), tabbed or accordion.',
                        'id' => 'ct_single_listing_content_layout_type',
                        'type' => 'select',
                        'options' => array (
                            'default' => 'Default',
                            'tabbed' => 'Tabbed',
                            'accordion' => 'Accordion',
                        ),
                        'title' => 'Content Style',
                        'default' => 'default',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to require login/registration to view listing content.',
                        'id' => 'ct_listing_single_require_login_register_for_content',
                        'type' => 'switch',
                        'title' => 'Only Allow Logged In Users to View Listing Content?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Drag and drop layout manager, to quickly organize your listing single contents.',
                        'id' => 'ct_single_listing_content_layout',
                        'type' => 'sorter',
                        'title' => 'Content Layout',
                        'options' => array (
                            'disabled' => array (
                                'listing_booking_calendar' => 'Booking Calendar',
                                'listing_energy_efficiency' => 'Energy Efficiency',
                                'listing_reviews' => 'Reviews',
                            ),
                            'enabled' => array (
                                'listing_content' => 'Content',
                                'listing_open_house' => 'Open House',
                                'listing_floorplans' => 'Multi-Floorplan',
                                'listing_rental_info' => 'Rental Info',
                                'listing_features' => 'Features',
                                'listing_attachments' => 'Attachments',
                                'listing_video' => 'Video',
                                'listing_virtual_tour' => 'Virtual Tour',
                                'listing_map' => 'Map',
                                'listing_yelp' => 'Whats Nearby',
                            ),
                        ),
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to display the "Read More" button for the single listing content, it\'ll collapse the verbiage down and allow the user to click to show the entire contents.',
                        'id' => 'ct_listing_single_content_show_more',
                        'type' => 'switch',
                        'title' => 'Content "Read More" Button?',
                        'default' => 'no',
                    ),

                    array(
                        'id' => 'info_yelp_moved',
                        'type' => 'info',
                        'style' => 'info',
                        'title' => __('', 'contempo'),
                        'desc' => __('Yelp "What\'s Nearby" settings have been moved to <strong>Integrations &rarr; Yelp</strong>.', 'contempo')
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to only allow logged in users to view listing files and documents (attachments), great for private information like financials, memorandoms, etc…',
                        'id' => 'ct_listing_attachment_logged_in',
                        'type' => 'switch',
                        'title' => 'Only Allow Logged In Users to View Attachments?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to only allow logged in users to view agent contact details, if not logged in the details will be hidden asking them to login/register great for lead capture.',
                        'id' => 'ct_listing_agent_contact_logged_in',
                        'type' => 'switch',
                        'title' => 'Only Allow Logged In Users to View Agent Contact Info?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Drag and drop layout manager, to quickly organize your listing single agent details contents.',
                        'id' => 'ct_single_listing_agent_details_layout',
                        'type' => 'sorter',
                        'title' => 'Agent Details Layout',
                        'options' => array (
                            'disabled' => array (
                            ),
                            'enabled' => array (
                                'listing_agent_name' => 'Agent Name',
                                'listing_agent_image' => 'Agent Image',
                                'listing_agent_info' => 'Agent Info',
                                'listing_agent_specialties' => 'Agent Specialties',
                                'listing_agent_social' => 'Agent Social',
                            ),
                        ),
                    ),

                    array (
                        'desc' => 'Enable the co-listing agent field on listings, allowing a second agent to be assigned and displayed on the listing detail page.',
                        'id' => 'ct_co_listing_agent_enabled',
                        'type' => 'switch',
                        'title' => 'Enable Co-Listing Agent?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to disable the driving directions underneath the listing map.',
                        'id' => 'ct_driving_directions',
                        'type' => 'switch',
                        'title' => 'Disable Driving Directions?',
                        'default' => 'no',
                    ),

                    array(
                    'id' => 'sub-listings-start',
                    'type' => 'section',
                    'title' => __('Sub Listings', 'contempo'),
                    //'subtitle' => __('If you have the "Est Payment" module enabled under the "Main Layout Blocks" manager, these are the assumptions settings used to display it.', 'contempo'),
                    'indent' => true 
                ),

                    array (
                        'desc' => 'Select whether or not you\'d like to exclude sold data from sub listings.',
                        'id' => 'ct_sub_listings_exclude_sold',
                        'type' => 'switch',
                        'title' => 'Exclude Sold from Sub Listings?',
                        'default' => 'yes',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to show sub listings as a carousel.',
                        'id' => 'ct_sub_listings_carousel',
                        'type' => 'switch',
                        'title' => 'Show Sub Listings as Carousel?',
                        'default' => 'yes',
                    ),

                    array (
                        'desc' => 'Enter the max number of sub listings you\'d like to show.',
                        'id' => 'ct_sub_listings_carousel_max_num',
                        'type' => 'text',
                        'title' => 'Sub Listings Carousel Max Number',
                        'default' => '9',
                        'required' => array('ct_sub_listings_carousel','equals','yes'),
                    ),

                    array(
                        'id'     => 'sub-listings-end',
                        'type'   => 'section',
                        'indent' => false,
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to enable the vacation rentals/booking fields and capabilities.',
                        'id' => 'ct_rentals_booking',
                        'type' => 'switch',
                        'title' => 'Enable Vacation Rentals/Booking Fields?',
                        'default' => 'no',
                    ),
                    array (
                        'desc' => 'Select whether or not you\'d like to enable the Multi-Floorplan fields and capabilities. Includes repeatable fields for floorplans, pricing &amp; descriptions commonly used for apartment buildings, condo sales, housing development sites, etc&hellip;',
                        'id' => 'ct_multi_floorplan',
                        'type' => 'switch',
                        'title' => 'Enable Multi-Floorplan &amp; Pricing Fields?',
                        'default' => 'no',
                    ),
                    array (
                        'desc' => 'Select whether or not you\'d like to show the listing tools (social share, print, etc&hellip;) on single listing view.',
                        'id' => 'ct_listing_tools',
                        'type' => 'switch',
                        'title' => 'Show Listing Tools?',
                        'default' => 'yes',
                    ),   
                    array (
                        'desc' => 'Drag and drop layout manager, to quickly organize your listing tools.',
                        'id' => 'ct_single_listing_tools_layout',
                        'required' => array('ct_listing_tools','equals','yes'),
                        'type' => 'sorter',
                        'title' => 'Tools Layout',
                        'options' => array (
                            'disabled' => array (
                            ),
                            'enabled' => array (
                                'listing_twitter' => 'Twitter',
                                'listing_facebook' => 'Facebook',
                                'listing_linkedin' => 'LinkedIn',
                                'listing_whatsapp' => 'WhatsApp',
                                'listing_pinterest' => 'Pinterest',
                                'listing_print' => 'Print',
                            ),
                        ),
                    ),
                    
                )
            ) );

            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'WalkScore', 'contempo' ),
                'id'               => 'listings-walkscore',
            'group'            => 'Integrations',
                'group'            => 'Integrations',
                'subsection'       => true,
                'desc'   => __( 'Walk Score is the only international measure of walkability and the leading provider of neighborhood maps to the real estate industry. More than 30,000 websites use the Walk Score Neighborhood Map and we serve over 20 million scores each day. <a href="https://www.walkscore.com/professional/api-sign-up.php" target="_blank">Get your API Key</a>!.', 'contempo' ),
                'fields'           => array(
                    array (
                        'desc' => 'Select whether or not you\'d like to enable Walk Score for listings.',
                        'id' => 'ct_enable_walkscore',
                        'type' => 'switch',
                        'title' => 'Enable Walk Score for Listings?',
                        'default' => 'no',
                    ),
                    array (
                        'desc' => 'Enter your Walk Score API Key here, don\'t have one get one <a href="https://www.walkscore.com/professional/api-sign-up.php" target="_blank">here</a>.',
                        'id' => 'ct_walkscore_apikey',
                        'type' => 'text',
                        'title' => 'Walk Score API Key',
                        'required' => array('ct_listing_lat_long','equals','on'),
                        'default' => '',
                    ),
                    array (
                        'desc' => 'Walk Score depends on latitude and longitude to work properly, turn this on unless you want to manually enter lat/long coordinates for your listings.',
                        'id' => 'ct_listing_lat_long',
                        'type' => 'select',
                        'options' => array (
                            'on' => 'On',
                            'off' => 'Off',
                        ),
                        'title' => 'Automatic latitude & longitude',
                        'default' => 'off',
                        'required' => array('ct_enable_walkscore','equals','yes'),
                    ),
                )
            ) );

        }

        // Only show if CT IDX Pro+ is not active
        if (!class_exists('Contempo\IDXPro\Admin\SettingsPage')) {
            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'Listings', 'contempo' ),
                'id'               => 'listings',
            'group'            => 'Listings',
                'icon'             => 'fas fa-sign',
                'fields'           => array(
                    array (
                        'desc' => 'Select which listing style you\'d like to use, standard, modern, minimal or list.',
                        'id' => 'ct_search_results_listing_style',
                        'type' => 'select',
                        'options' => array (
                            'standard' => 'Standard Grid',
                            'modern' => 'Modern Grid',
                            'modern_two' => 'Modern Grid 2',
                            'minimal' => 'Minimal Grid',
                            'list' => 'List',
                        ),
                        'title' => 'Listing Layout Style',
                        'default' => 'modern_two',
                    ),
                    array (
                        'desc' => 'Select whether or not you\'d like to require users to login or register after viewing X amount of listings, great for lead capture.',
                        'id' => 'ct_listings_login_register_after_x_views',
                        'type' => 'switch',
                        'title' => 'Require Users to Login/Register after X amount of Listing Views?',
                        'default' => 'no',
                    ), 
                    array (
                        'desc' => 'Enter the number of views you\'d like to allow before requiring a user to login/register.',
                        'id' => 'ct_listings_login_register_after_x_views_num',
                        'type' => 'text',
                        'title' => 'Number of Listings Views',
                        'placeholder' => '4',
                        'required' => array('ct_listings_login_register_after_x_views','equals','yes'),
                    ),
                    array (
                        'desc' => 'Enter your currency symbol here, US dollars is default.',
                        'id' => 'ct_currency',
                        'type' => 'text',
                        'title' => 'Currency',
                        'default' => '$',
                    ),
                    array (
                        'desc' => 'Select whether you\'d like the currency symbol to appear before the price or after.',
                        'id' => 'ct_currency_placement',
                        'type' => 'select',
                        'options' => array (
                            'before' => 'Before',
                            'after' => 'After',
                        ),
                        'title' => 'Currency Placement',
                        'default' => 'before',
                    ),
                    array (
                        'desc' => 'Select how many decimal points.',
                        'id' => 'ct_currency_decimal',
                        'type' => 'select',
                        'options' => array (
                            '0' => '0',
                            '2' => '2',
                        ),
                        'title' => 'Decimal Points',
                        'default' => '0',
                    ),
                    array (
                        'desc' => 'Select whether or not you\'d like to disable the listing title formatting which converts the first character of each word to uppercase.',
                        'id' => 'ct_listings_title_formatting',
                        'type' => 'switch',
                        'title' => 'Disable Listing Title Formatting?',
                        'default' => 'no',
                    ),
                    array (
                        'desc' => 'Select whether or not you\'d like to disable the front end display of your listings property types.',
                        'id' => 'ct_listings_propinfo_property_type',
                        'type' => 'switch',
                        'title' => 'Disable Property Type?',
                        'default' => 'no',
                    ),
                    array (
                        'desc' => 'Select whether or not you\'d like to disable the front end display of your listings price per sq ft/meters.',
                        'id' => 'ct_listings_propinfo_price_per',
                        'type' => 'switch',
                        'title' => 'Disable Price Per Sq Ft/Meters?',
                        'default' => 'no',
                    ),
                    array (
                        'desc' => 'Leave this on, you can manually override this setting on a per listing basis with the "Skip Address Geocoding" option in the edit listing panel.',
                        'id' => 'ct_listing_lat_long',
                        'type' => 'select',
                        'options' => array (
                            'on' => 'On',
                            'off' => 'Off',
                        ),
                        'title' => 'Automatic latitude & longitude based on listing address',
                        'default' => 'off',
                    ),
                    array (
                        'desc' => 'Select whether or not you\'d like to use icons or text for listing features (beds, baths, guests, etc&hellip;).',
                        'id' => 'ct_use_propinfo_icons',
                        'type' => 'select',
                        'options' => array (
                            'icons' => 'Icons',
                            'text' => 'Text',
                        ),
                        'title' => 'Use Icons or Text for Listing Info?',
                        'default' => 'text',
                    ),
                    array (
                        'desc' => 'Select if you would like to use Sq Ft, Sq Meters or Area for the dwelling size.',
                        'id' => 'ct_sq',
                        'type' => 'select',
                        'options' => array (
                            'sqft' => 'Sq Ft',
                            'sqmeters' => 'Sq Meters',
                            'area' => 'Area',
                        ),
                        'title' => 'Sq Ft, Sq Meters or Area?',
                        'default' => 'sqft',
                    ),
                    array (
                        'desc' => 'Select if you would like to use Acres, Sq Ft, Sq Meters or Area for the lot size.',
                        'id' => 'ct_acres',
                        'type' => 'select',
                        'options' => array (
                            'acres' => 'Acres',
                            'sqft' => 'Sq Ft',
                            'sqmeters' => 'Sq Meters',
                            'area' => 'Area',
                        ),
                        'title' => 'Acres, Sq Ft, Sq Meters or Area?',
                        'default' => 'acres',
                    ),
                    array (
                        'desc' => 'Select whether or not you\'d like to enable number formatting for the lot size, (e.g. 1,200 instead of 1200).',
                        'id' => 'ct_listings_lotsize_format',
                        'type' => 'switch',
                        'title' => 'Enable Lot Size Number Formatting?',
                        'default' => 'no',
                    ),
                    array (
                        'desc' => 'Select whether you\'d like to use Bed, Beds, Bedrooms or Rooms.',
                        'id' => 'ct_bed_beds_or_bedrooms',
                        'type' => 'select',
                        'options' => array (
                            'bed' => 'Bed',
                            'beds' => 'Beds',
                            'bedrooms' => 'Bedrooms',
                            'rooms' => 'Rooms',
                        ),
                        'title' => 'Bed, Beds, Bedrooms or Rooms?',
                        'default' => 'bed',
                    ),
                    array (
                        'desc' => 'Select whether you\'d like to use Bath, Baths or Bathrooms.',
                        'id' => 'ct_bath_baths_or_bathrooms',
                        'type' => 'select',
                        'options' => array (
                            'bath' => 'Bath',
                            'baths' => 'Baths',
                            'bathrooms' => 'Bathrooms',
                        ),
                        'title' => 'Bath, Baths or Bathrooms?',
                        'default' => 'bath',
                    ),
                    array (
                        'desc' => 'Select whether you\'d like to use City, Town or Village.',
                        'id' => 'ct_city_town_or_village',
                        'type' => 'select',
                        'options' => array (
                            'city' => 'City',
                            'town' => 'Town',
                            'village' => 'Village',
                        ),
                        'title' => 'City, Town or Village?',
                        'default' => 'city',
                    ),
                    array (
                        'desc' => 'Select whether you\'d like to use State, Area, Suburb or Province.',
                        'id' => 'ct_state_or_area',
                        'type' => 'select',
                        'options' => array (
                            'state' => 'State',
                            'area' => 'Area',
                            'suburb' => 'Suburb',
                            'province' => 'Province',
                            'region' => 'Region',
                            'parish' => 'Parish',
                        ),
                        'title' => 'State, Area, Suburb, Province, Region or Parish?',
                        'default' => 'state',
                    ),
                    array (
                        'desc' => 'Select whether you\'d like to use Zipcode, Postcode or Postal Code.',
                        'id' => 'ct_zip_or_post',
                        'type' => 'select',
                        'options' => array (
                            'zipcode' => 'Zipcode',
                            'postcode' => 'Postcode',
                            'postalcode' => 'Postal Code',
                        ),
                        'title' => 'Zipcode, Postcode or Postal Code?',
                        'default' => 'zipcode',
                    ),
                    array (
                        'desc' => 'Select whether you\'d like to use Community, Municipality, Neighborhood, Suburb, District, School District, Building, Complex, Borough or Sector.',
                        'id' => 'ct_community_neighborhood_or_district',
                        'type' => 'select',
                        'options' => array (
                            'community' => 'Community',
                            'municipality' => 'Municipality',
                            'neighborhood' => 'Neighborhood',
                            'suburb' => 'Suburb',
                            'district' => 'District',
                            'schooldistrict' => 'School District',
                            'building' => 'Building',
                            'complex' => 'Complex',
                            'borough' => 'Borough',
                            'sector' => 'Sector',
                        ),
                        'title' => 'Community, Municipality, Neighborhood, Suburb, District, School District, Building, Complex, Borough or Sector?',
                        'default' => 'community',
                    ),
                    
                    array (
                        'desc' => 'Set the slug for listings here to whatever you\'d like (all lowercase, no spaces, dashes are allowed).<br><strong>IMPORTANT:</strong> Set your slug > Save Changes > then go to Settings > Permalinks > Save Settings — <strong><em>if you don\'t all listings will show a 404 error</em></strong>.',
                        'id' => 'ct_listings_slug',
                        'type' => 'text',
                        'title' => 'Listings Custom Slug',
                        'default' => 'listings',
                    ),

                    array (
                        'desc' => 'If you\'re having trouble with coordinates or importing listings via CSV, this option allows you to generate/update the coordinates for all your listings based on their address information. To use this option, set it to "Yes," go into the Listings > Select any one listing > click "Edit" > then "Update", let it run (when finished it\'ll show the normal "Post Updated" notification). This process could take a moment or two depending on the size of your database and server resources.<br><strong>IMPORTANT:</strong> Once you\'re done, set this to No > Save Changes, you do not want to leave this enabled.',
                        'id' => 'ct_bulk_update_listing_coords',
                        'type' => 'switch',
                        'title' => 'Enable Bulk Updating Listing Coordinates?',
                        'default' => 'no',
                    ),
                )
            ) );

            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'Images', 'contempo' ),
                'id'               => 'images',
                'group'            => 'Listings',
                'subsection'       => true,
                'fields'           => array(
                    array (
                        'desc' => '<p>Crops listing featured images to 818&times;540 for a consistent look across your site.</p><p><strong>To apply:</strong> Install the <strong>Regenerate Thumbnails</strong> plugin, then run it via <strong>Tools &rarr; Regen. Thumbnails</strong>. Once complete, clear any caching plugin or CDN cache to see the updated images.</p>',
                        'id' => 'ct_listing_featured_image_cropping',
                        'type' => 'switch',
                        'title' => 'Crop Featured Image?',
                        'default' => 'yes',
                    ),
                )
            ) );
    
            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'Search', 'contempo' ),
                'id'               => 'search',
            'group'            => 'Listings',
                'subsection'       => true,
                'fields'           => array(

                    array (
                        'desc' => 'Select whether or not you\'d like to disable Google Maps on Search Results.',
                        'id' => 'ct_disable_google_maps_search',
                        'type' => 'switch',
                        'title' => 'Disable Google Maps on Search Results?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to disable the advanced search area on listing search results pages, best used in conjunction with the Header Listing Search option, under Header > Header Listing Search? > set to Yes.',
                        'id' => 'ct_disable_listing_search_results_adv_search',
                        'type' => 'switch',
                        'title' => 'Disable Advanced Search on Listing Search Results?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select which search results layout you\'d like to use, stacked map and results or side by side map and results.',
                        'id' => 'ct_search_results_layout',
                        'type' => 'select',
                        'options' => array (
                            'stacked' => 'Stacked',
                            'sidebyside' => 'Side by Side',
                        ),
                        'title' => 'Search Results Layout',
                        'default' => 'stacked',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to have the map or grid as the default view. This is only for initial load, once the user chooses their own view that will persist state with a cookie.',
                        'id' => 'ct_search_default_view',
                        'type' => 'select',
                        'options' => array (
                            'map' => 'Map',
                            'grid' => 'Grid',
                        ),
                        'title' => 'Map or Grid as Default View?',
                        'default' => 'map',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to enable the modal view for listings when clicked similar to Zillow, this will pop the listing up directly over the search results instead of directing the user to a new page.',
                        'id' => 'ct_enable_modal_view',
                        'type' => 'switch',
                        'title' => 'Enable Modal View?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to open the listing single detail view in a new tab similar to Trulia, this vastly improves the users overall experience by eliminating unnecessary page reloads when they click back into the search results, they\'re already loaded.',
                        'id' => 'ct_listing_single_new_tab',
                        'type' => 'switch',
                        'title' => 'Open Listing Single Detail in New Tab?',
                        'default' => 'no',
                        'required' => array('ct_enable_modal_view','equals','no'),
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to disable the geolocation feature, this allows users to pinpoint and search for listings around their location based off IP address.',
                        'id' => 'ct_disable_geolocation',
                        'type' => 'switch',
                        'title' => 'Disable Geolocation?',
                        'default' => 'no',
                    ),

                    array (
                        'desc'        => 'Enter a city, region, or address to use as the default map center when a manually entered listings search returns no results (e.g. London, UK or Sydney, Australia or Toronto, Canada). Works for any location worldwide. Leave blank to fall back to the center of the United States.',
                        'id'          => 'ct_map_fallback_location',
                        'type'        => 'text',
                        'title'       => 'Fallback Map Location',
                        'default'     => '',
                        'placeholder' => 'e.g. San Diego, CA',
                    ),

                    array(
                        'desc'        => 'Default title shown in the browser tab and search engines when a visitor arrives on the listings search page with no active filters. When filters are applied (status, beds, property type, location, etc.) the title updates automatically — e.g. "3+ Bedroom Condos for Rent in San Diego, CA". Leave blank to use "Real Estate Listings Search" as the default.',
                        'id'          => 'ct_search_listings_page_title',
                        'type'        => 'text',
                        'title'       => 'Listings Search Page Title',
                        'default'     => '',
                        'placeholder' => 'Real Estate Listings Search',
                    ),

                    array(
                        'desc'        => 'Default meta description shown to search engines when a visitor arrives on the listings search page with no active filters. When filters are applied the description updates automatically to reflect the active search. Keep between 150-160 characters for best results. Leave blank to output no description tag on unfiltered searches.',
                        'id'          => 'ct_search_listings_meta_description',
                        'type'        => 'textarea',
                        'title'       => 'Listings Search Meta Description',
                        'default'     => '',
                        'placeholder' => 'Browse homes for sale and rent. Filter by beds, price, location, and more.',
                    ),

                    array (
                        'desc' => 'Set the maximum zoom level the map will use when automatically fitting to listings. Prevents over-zooming on single listings or listings in a small area. Set to 20 to allow the map to zoom as close as possible.',
                        'id' => 'ct_map_max_auto_zoom',
                        'type' => 'slider',
                        'title' => 'Map Maximum Auto-Zoom',
                        'default' => '14',
                        'min' => '8',
                        'max' => '20',
                        'step' => '1',
                    ),

                    array (
                        'desc' => 'Enter the amount of listings you want displayed per page when searching.',
                        'id' => 'ct_listing_search_num',
                        'type' => 'text',
                        'title' => 'Listing Search Results Per Page',
                        'default' => '6',
                    ),

                    array (
                        'desc' => 'Select the display size of the map markers.',
                        'id' => 'ct_listing_marker_svg_size',
                        'type' => 'slider',
                        'title' => 'Map Marker Size',
                        'default' => '10',
                        'min' => '1',
                        'max' => '20',
                        'step' => '1',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to show prices for each of the listing map markers.',
                        'id' => 'ct_enable_marker_price',
                        'type' => 'switch',
                        'title' => 'Enable Marker Price Display?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Enter the IDs you\'d like to exclude from the search results.',
                        'id' => 'ct_listing_search_exclude_mls_ids',
                        'type' => 'text',
                        'title' => 'Exclude IDs from Search Results',
                        'default' => '',
                        'placeholder' => '123456, 589784, 987451',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to exclude pending listings from search results.',
                        'id' => 'ct_exclude_pending_listing_search',
                        'type' => 'switch',
                        'title' => 'Exclude Pending from Search Results?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to exclude off market listings from search results.',
                        'id' => 'ct_exclude_off_market_listing_search',
                        'type' => 'switch',
                        'title' => 'Exclude Off Market from Search Results?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to exclude sold listings from search results.',
                        'id' => 'ct_exclude_sold_listing_search',
                        'type' => 'switch',
                        'title' => 'Exclude Sold from Search Results?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Enter the listing description excerpt length used on search results. If "0" then no excerpt will be shown.',
                        'id' => 'ct_excerpt_length',
                        'type' => 'text',
                        'title' => 'Listing Excerpt Length',
                        'default' => '25',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to display a secondary image when a user hovers, automatically uses second image from slider images section if available.',
                        'id' => 'ct_listing_display_secondary_image_on_hover',
                        'type' => 'switch',
                        'title' => 'Show Secondary Image on Hover?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to display the listings virtual tour badge if one is available.',
                        'id' => 'ct_listing_virtual_tour_badge',
                        'type' => 'switch',
                        'title' => 'Enable Listing Virtual Tour Badge?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to display the listings upcoming open houses.',
                        'id' => 'ct_listing_upcoming_open_house',
                        'type' => 'switch',
                        'title' => 'Enable Listing Upcoming Open House?',
                        'default' => 'yes',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to display the agent info for listings in search results.".',
                        'id' => 'ct_listing_agent_grid_information',
                        'type' => 'switch',
                        'title' => 'Enable Listing Agent Name & Profile Image?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to display the creation elapsed time for listings, e.g. "5 hours ago", "3 days ago", "2 weeks ago", "4 months ago".',
                        'id' => 'ct_listing_creation_date',
                        'type' => 'switch',
                        'title' => 'Enable Listing Creation Date?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to display the brokerage name on listing search results, uses the "Brokerage Name" field under Users > User > Edit Profile.',
                        'id' => 'ct_listing_brokerage_name',
                        'type' => 'switch',
                        'title' => 'Enable Listing Brokerage Name?',
                        'default' => 'no',
                    ),
                    
                )
            ) );

            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'Single Detail', 'contempo' ),
                'id'               => 'single-detail',
            'group'            => 'Listings',
                'subsection'       => true,
                'fields'           => array(

                    array (
                        'desc' => '<strong>NOTE:</strong> The second layout option really only <em>works best if your listings ALL have Multiple images</em> otherwise you\'ll get one large single image displayed full screen which doesn\'t work well for usability. If this is the case the first option works great for single image or multi-image listings.',
                        'id' => 'ct_listing_single_layout',
                        'type' => 'image_select',
                        'options' => array (
                            'listings-one' => get_template_directory_uri() . '/admin/images/listings-one.png',
                            'listings-two' => get_template_directory_uri() . '/admin/images/listings-two.png',
                            'listings-three' => get_template_directory_uri() . '/admin/images/listings-three.png',
                            'listings-four' => get_template_directory_uri() . '/admin/images/listings-four.png',
                            'listings-five' => get_template_directory_uri() . '/admin/images/listings-five.png',
                        ),
                        'title' => 'Listings Single layout',
                        'default' => 'listings-five',
                    ),

                    array (
                        'desc' => 'Select whether you\'d like the listing single content with a sidebar or full width.',
                        'id' => 'ct_listing_single_content_layout',
                        'type' => 'select',
                        'options' => array (
                            'sidebar' => 'w/Sidebar',
                            'full-width' => 'Full Width',
                        ),
                        'title' => 'Listing Single Content w/Sidebar or Full Width?',
                        'default' => 'sidebar',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like have a sticky sidebar which will stay with the user on scroll.',
                        'id' => 'ct_listing_single_sticky_sidebar',
                        'type' => 'switch',
                        'title' => 'Sticky Sidebar?',
                        'default' => 'no',
                        'required' => array('ct_listing_single_content_layout','equals','sidebar'),
                    ),

                    array (
                        'desc' => 'Drag and drop layout manager, to quickly organize your listing single main layout modules.',
                        'id' => 'ct_single_listing_main_layout',
                        'type' => 'sorter',
                        'title' => 'Main Layout Blocks',
                        'options' => array (
                            'disabled' => array (
                                
                            ),
                            'enabled' => array (
                                'listing_header' => 'Header',
                                'listing_price' => 'Price',
                                'listing_est_payment' => 'Est Payment',
                                'listing_prop_info' => 'Listing Info',
                                'listing_lead_media' => 'Image/Slider',
                                //'listing_lead_media_with_contact' => 'Slider w/Contact',
                                'listing_nav' => 'Section Nav Bar',
                                'listing_content' => 'Content',
                                'listing_contact' => 'Contact',
                                'listing_creation_date' => 'Creation Date',
                                'listing_brokerage' => 'Brokerage',
                                'ct_affordability_calculator' => 'Affordability',
                                'listing_sub_listings' => 'Sub Listings',
                            ),
                        ),
                    ),

                    array (
                        'desc' => 'Drag and drop layout manager, to quickly organize your listing single header layout modules.',
                        'id' => 'ct_single_listing_header_layout',
                        'type' => 'sorter',
                        'title' => 'Header Layout',
                        'options' => array (
                            'disabled' => array (
                            ),
                            'enabled' => array (
                                'listing_status' => 'Status',
                                'listing_title' => 'Title/Address',
                                'listing_city_state_zip' => 'City/State/Post',
                                'listing_map_btn' => 'Map Button',
                                'listing_save_btn' => 'Save Button',
                            ),
                        ),
                    ),

                    array(
                        'id' => 'flexslider-section-start',
                        'type' => 'section',
                        'title' => __('Image Slider', 'contempo'),
                        'subtitle' => __('Customize various settings of the image slider in this section.', 'contempo'),
                        'indent' => true,
                        'required' => array('ct_listing_single_layout','equals',array('listings-one', 'listings-two', 'listings-three', 'listings-four')),
                    ),

                        array (
                            'desc' => 'Select your animation type.',
                            'id' => 'ct_flex_animation',
                            'type' => 'select',
                            'options' => array (
                                'fade' => 'Fade',
                                'slide' => 'Slide',
                            ),
                            'title' => 'Animation',
                            'default' => 'fade',
                        ),
                        array (
                            'desc' => 'Select sliding direction.',
                            'id' => 'ct_flex_direction',
                            'type' => 'select',
                            'options' => array (
                                'horizontal' => 'Horizontal',
                                'vertical' => 'Vertical',
                            ),
                            'title' => 'Slide Direction',
                            'default' => 'horizontal',
                        ),
                        array (
                            'desc' => 'Set the speed of the slideshow cycling, in milliseconds.',
                            'id' => 'ct_flex_speed',
                            'type' => 'text',
                            'title' => 'Slideshow Speed',
                            'default' => '7000',
                        ),
                        array (
                            'desc' => 'Set the speed of animations, in milliseconds.',
                            'id' => 'ct_flex_duration',
                            'type' => 'text',
                            'title' => 'Animation Duration',
                            'default' => '600',
                        ),
                        array (
                            'desc' => 'If you want your slides to automatically start without having to click next/previous however the navigation still also works.',
                            'id' => 'ct_flex_autoplay',
                            'type' => 'select',
                            'options' => array (
                                'false' => 'False',
                                'true' => 'True',
                            ),
                            'title' => 'Autoplay Slides?',
                            'default' => 'true',
                        ),
                        array (
                            'desc' => 'Randomize slide order.',
                            'id' => 'ct_flex_randomize',
                            'type' => 'select',
                            'options' => array (
                                'false' => 'False',
                                'true' => 'True',
                            ),
                            'title' => 'Randomize Slides?',
                            'default' => 'false',
                        ),

                    array(
                        'id'     => 'flexslider-section-end',
                        'type'   => 'section',
                        'indent' => false,
                    ),

                    array(
                        'id' => 'section-start',
                        'type' => 'section',
                        'title' => __('Estimated Payment', 'contempo'),
                        'subtitle' => __('If you have the "Est Payment" module enabled under the "Main Layout Blocks" manager, these are the assumptions settings used to display it.', 'contempo'),
                        'indent' => true 
                    ),

                        array (
                            'desc' => 'Select the assumed down payment percentage.',
                            'id' => 'ct_listing_est_payment_percent_down',
                            'type' => 'slider',
                            'title' => 'Down Payment %',
                            'default' => '20',
                            'min' => '1',
                            'max' => '100',
                            'step' => '1',
                        ),

                        array (
                            'desc' => 'Select the assumed interest rate.',
                            'id' => 'ct_listing_est_payment_interest_rate',
                            'type' => 'slider',
                            'title' => 'Interest Rate %',
                            'default' => '3',
                            'min' => '1',
                            'max' => '100',
                            'step' => '.1',
                            'resolution' => 0.01,
                        ),

                        array (
                            'desc' => 'Select the assumed annual property tax rate percentage.',
                            'id' => 'ct_listing_est_payment_tax_rate',
                            'type' => 'slider',
                            'title' => 'Annual Property Tax Rate %',
                            'default' => 0.78,
                            'min' => 0.1,
                            'max' => 100,
                            'step' => 0.1,
                            'resolution' => 0.01,
                        ),

                        array (
                            'desc' => 'Enter the amount of property insurance paid for each year.',
                            'id' => 'ct_listing_est_payment_home_insurance',
                            'type' => 'text',
                            'title' => 'Home Insurance',
                            'default' => 900,
                            'min' => 0,
                            'max' => 1000000,
                            'step' => 1,
                        ),

                        array (
                            'desc' => 'Select the term in years.',
                            'id' => 'ct_listing_est_payment_term',
                            'type' => 'slider',
                            'title' => 'Term',
                            'default' => '30',
                            'min' => '1',
                            'max' => '30',
                            'step' => '1',
                        ),

                    array(
                        'id'     => 'section-end',
                        'type'   => 'section',
                        'indent' => false,
                    ),

                    array(
                    'id' => 'section-start-get-prequalified',
                    'type' => 'section',
                    'title' => __('Get Pre-Qualified', 'contempo'),
                    'subtitle' => __('If you have the "Affordability" module enabled under the "Main Layout Blocks" manager, you can use this to display a button to "Get Pre-Qualified". This is perfect if you own your own mortgage company, have a partnership with one, or to use as an affiliate link for lead referrals.', 'contempo'),
                    'indent' => true 
                    ),

                        array (
                            'desc' => 'Select the link type: Disabled (button won\'t be displayed), Internal Page or External URL.',
                            'id' => 'ct_single_listing_get_prequalified_link_type',
                            'type' => 'select',
                            'options' => array (
                                'disabled' => 'Disabled',
                                'internal_page' => 'Internal Page',
                                'external_url' => 'External URL',
                            ),
                            'title' => 'Link Type',
                            'default' => 'disabled',
                        ),

                        array (
                            'desc' => 'Select the page you\'d like the button to link to.',
                            'id' => 'ct_single_listing_get_prequalified_page',
                            'title' => 'Internal Page',
                            'type' => 'select',
                            'data' => 'pages',
                            'required' => array('ct_single_listing_get_prequalified_link_type','equals','internal_page'),
                        ),

                        array (
                            'desc' => 'Enter the external URL you\'d like the button to link to.',
                            'id' => 'ct_single_listing_get_prequalified_external_url',
                            'title' => 'External URL',
                            'type' => 'text',
                            'placeholder' => 'https://your-lender-partner.com',
                            'required' => array('ct_single_listing_get_prequalified_link_type','equals','external_url'),
                        ),

                        array (
                            'desc' => 'Select the link target: New Window/Tab (just as it sounds), or Self (opens in same window/tab, default).',
                            'id' => 'ct_single_listing_get_prequalified_link_target',
                            'type' => 'select',
                            'options' => array (
                                '_blank' => 'New Window/Tab',
                                '_self' => 'Self',
                            ),
                            'title' => 'Link Type',
                            'required' => array('ct_single_listing_get_prequalified_link_type','!=','disabled'),
                        ),

                    array(
                        'id'     => 'section-end-get-prequalified',
                        'type'   => 'section',
                        'indent' => false,
                    ),

                    array (
                        'desc' => 'Select which content layout you\'d like to use, default (all visible), tabbed or accordion.',
                        'id' => 'ct_single_listing_content_layout_type',
                        'type' => 'select',
                        'options' => array (
                            'default' => 'Default',
                            'tabbed' => 'Tabbed',
                            'accordion' => 'Accordion',
                        ),
                        'title' => 'Content Style',
                        'default' => 'default',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to require login/registration to view listing content.',
                        'id' => 'ct_listing_single_require_login_register_for_content',
                        'type' => 'switch',
                        'title' => 'Only Allow Logged In Users to View Listing Content?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Drag and drop layout manager, to quickly organize your listing single contents.',
                        'id' => 'ct_single_listing_content_layout',
                        'type' => 'sorter',
                        'title' => 'Content Layout',
                        'options' => array (
                            'disabled' => array (
                                'listing_ct_idx_pro_info' => 'IDX Info',
                            ),
                            'enabled' => array (
                                'listing_content' => 'Content',
                                'listing_open_house' => 'Open House',
                                'listing_floorplans' => 'Multi-Floorplan',
                                'listing_energy_efficiency' => 'Energy Efficiency',
                                'listing_rental_info' => 'Rental Info',
                                'listing_features' => 'Features',
                                'listing_booking_calendar' => 'Booking Calendar',
                                'listing_attachments' => 'Attachments',
                                'listing_video' => 'Video',
                                'listing_virtual_tour' => 'Virtual Tour',
                                'listing_map' => 'Map',
                                'listing_yelp' => 'Whats Nearby',
                                'listing_reviews' => 'Reviews',
                            ),
                        ),
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to display the "Read More" button for the single listing content, it\'ll collapse the verbiage down and allow the user to click to show the entire contents.',
                        'id' => 'ct_listing_single_content_show_more',
                        'type' => 'switch',
                        'title' => 'Content "Read More" Button?',
                        'default' => 'no',
                    ),

                    array(
                    'id' => 'section-start-idx',
                    'type' => 'section',
                    'title' => __('IDX', 'contempo'),
                    'subtitle' => __('These options are for use with our <a href="https://contempothemes.com/docs/ct-idx-pro/" target="_blank">CT IDX Pro</a> plugin.', 'contempo'),
                    'indent' => true 
                    ),

                        array (
                            'desc' => 'Drag and drop layout manager, to quickly organize your listing single IDX data.',
                            'id' => 'ct_single_listing_idx_layout',
                            'type' => 'sorter',
                            'title' => 'Info Layout',
                            'options' => array (
                                'disabled' => array (
                                ),
                                'enabled' => array (
                                    'listing_idx_overview' => 'Overview',
                                    'listing_idx_schools' => 'Schools',
                                    'listing_idx_listing_history' => 'Listing History',
                                ),
                            ),
                        ),

                        array (
                            'desc' => 'Select whether or not you\'d like to display the MLS compliance information under the listing description. This is optional and only required if your MLS requests it.',
                            'id' => 'ct_listing_idx_mls_compliance_info',
                            'type' => 'switch',
                            'title' => 'Show MLS Compliance Information?',
                            'default' => 'no',
                        ),

                        array (
                            'desc' => 'Select whether or not you\'d like to display the Brokerage Phone Number under the MLS compliance information. This is optional and only required if your MLS requests it.',
                            'id' => 'ct_listing_idx_mls_compliance_info_brokerage_phone',
                            'type' => 'switch',
                            'title' => 'Show MLS Compliance Information > Brokerage Phone Number?',
                            'default' => 'no',
                            'required' => array('ct_listing_idx_mls_compliance_info','equals','yes'),
                        ),

                        array (
                            'desc' => 'Select whether or not you\'d like to display the Brokerage Info & Phone Number in the listing header. This is optional and only required if your MLS requests it.',
                            'id' => 'ct_listing_idx_mls_compliance_info_header',
                            'type' => 'switch',
                            'title' => 'Show MLS Compliance Brokerage Information in Listing Header?',
                            'default' => 'no',
                            'required' => array('ct_listing_idx_mls_compliance_info','equals','yes'),
                        ),

                    array(
                        'id'     => 'section-end-idx',
                        'type'   => 'section',
                        'indent' => false,
                    ),

                    array(
                        'id' => 'info_yelp_moved_idx',
                        'type' => 'info',
                        'style' => 'info',
                        'title' => __('', 'contempo'),
                        'desc' => __('Yelp "What\'s Nearby" settings have been moved to <strong>Integrations &rarr; Yelp</strong>.', 'contempo')
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to only allow logged in users to view listing files and documents (attachments), great for private information like financials, memorandoms, etc…',
                        'id' => 'ct_listing_attachment_logged_in',
                        'type' => 'switch',
                        'title' => 'Only Allow Logged In Users to View Attachments?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to only allow logged in users to view agent contact details, if not logged in the details will be hidden asking them to login/register great for lead capture.',
                        'id' => 'ct_listing_agent_contact_logged_in',
                        'type' => 'switch',
                        'title' => 'Only Allow Logged In Users to View Agent Contact Info?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Drag and drop layout manager, to quickly organize your listing single agent details contents.',
                        'id' => 'ct_single_listing_agent_details_layout',
                        'type' => 'sorter',
                        'title' => 'Agent Details Layout',
                        'options' => array (
                            'disabled' => array (
                            ),
                            'enabled' => array (
                                'listing_agent_name' => 'Agent Name',
                                'listing_agent_image' => 'Agent Image',
                                'listing_agent_info' => 'Agent Info',
                                'listing_agent_specialties' => 'Agent Specialties',
                                'listing_agent_social' => 'Agent Social',
                            ),
                        ),
                    ),

                    array (
                        'desc' => 'Enable the co-listing agent field on listings, allowing a second agent to be assigned and displayed on the listing detail page.',
                        'id' => 'ct_co_listing_agent_enabled',
                        'type' => 'switch',
                        'title' => 'Enable Co-Listing Agent?',
                        'default' => 'no',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to disable the driving directions underneath the listing map.',
                        'id' => 'ct_driving_directions',
                        'type' => 'switch',
                        'title' => 'Disable Driving Directions?',
                        'default' => 'no',
                    ),

                    array(
                        'id' => 'sub-listings-start',
                        'type' => 'section',
                        'title' => __('Sub Listings', 'contempo'),
                        //'subtitle' => __('If you have the "Est Payment" module enabled under the "Main Layout Blocks" manager, these are the assumptions settings used to display it.', 'contempo'),
                        'indent' => true 
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to exclude sold data from sub listings.',
                        'id' => 'ct_sub_listings_exclude_sold',
                        'type' => 'switch',
                        'title' => 'Exclude Sold from Sub Listings?',
                        'default' => 'yes',
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to show sub listings as a carousel.',
                        'id' => 'ct_sub_listings_carousel',
                        'type' => 'switch',
                        'title' => 'Show Sub Listings as Carousel?',
                        'default' => 'yes',
                    ),

                    array (
                        'desc' => 'Enter the max number of sub listings you\'d like to show.',
                        'id' => 'ct_sub_listings_carousel_max_num',
                        'type' => 'text',
                        'title' => 'Sub Listings Carousel Max Number',
                        'default' => '9',
                        'required' => array('ct_sub_listings_carousel','equals','yes'),
                    ),

                    array(
                        'id'     => 'sub-listings-end',
                        'type'   => 'section',
                        'indent' => false,
                    ),

                    array (
                        'desc' => 'Select whether or not you\'d like to enable the vacation rentals/booking fields and capabilities.',
                        'id' => 'ct_rentals_booking',
                        'type' => 'switch',
                        'title' => 'Enable Vacation Rentals/Booking Fields?',
                        'default' => 'no',
                    ),
                    array (
                        'desc' => 'Select whether or not you\'d like to enable the Multi-Floorplan fields and capabilities. Includes repeatable fields for floorplans, pricing &amp; descriptions commonly used for apartment buildings, condo sales, housing development sites, etc&hellip;',
                        'id' => 'ct_multi_floorplan',
                        'type' => 'switch',
                        'title' => 'Enable Multi-Floorplan &amp; Pricing Fields?',
                        'default' => 'no',
                    ),
                    array (
                        'desc' => 'Select whether or not you\'d like to show the listing tools (social share, print, etc&hellip;) on single listing view.',
                        'id' => 'ct_listing_tools',
                        'type' => 'switch',
                        'title' => 'Show Listing Tools?',
                        'default' => 'yes',
                    ),   
                    array (
                        'desc' => 'Drag and drop layout manager, to quickly organize your listing tools.',
                        'id' => 'ct_single_listing_tools_layout',
                        'required' => array('ct_listing_tools','equals','yes'),
                        'type' => 'sorter',
                        'title' => 'Tools Layout',
                        'options' => array (
                            'disabled' => array (
                            ),
                            'enabled' => array (
                                'listing_twitter' => 'Twitter',
                                'listing_facebook' => 'Facebook',
                                'listing_linkedin' => 'LinkedIn',
                                'listing_whatsapp' => 'WhatsApp',
                                'listing_pinterest' => 'Pinterest',
                                'listing_print' => 'Print',
                            ),
                        ),
                    ),
                    
                )
            ) );

        // Theme-first compatibility until Core 3.8.1 supplies the consolidated panels.
        if ( ! class_exists( 'CT_RE7_Listing_Modules' ) ) {
        if (function_exists('ctea_show_alert_creation')) { 

            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'Alerts', 'contempo' ),
                'id'               => 'listing-alerts',
            'group'            => 'Listings',
                'subsection'       => true,
                'fields'           => array(
                    array (
                        'id' => 'saved-listings-info',
                        'type' => 'info',
                        'raw' => 'Create a Page > Select the Listing Alerts Page Template > Publish, come back here and set the page below.',
                    ),
                    array (
                        'desc' => 'Select your alerts page here.',
                        'id' => 'ct_listing_email_alerts_page_id',
                        'type' => 'select',
                        'data' => 'pages',
                        'title' => 'Listing Alerts Page',
                        'default' => '',
                    ),
                    array (
                        'desc' => 'Select how often you\'d like to send out the email alerts.',
                        'id' => 'ct_listing_email_alerts_interval',
                        'type' => 'select',
                        'options' => array (
                            'weekly' => 'Weekly',
                            'daily' => 'Daily',
                            'hourly' => 'Hourly',
                        ),
                        'title' => 'Email Interval',
                        'default' => 'daily',
                    ),
                    array(
                        'id' => 'alerts-email-content-start',
                        'type' => 'section',
                        'title' => __('Email Content', 'contempo'),
                        'indent' => true 
                    ),
                    array (
                        'desc' => 'This is the text displayed in the header of your email alert. (<strong>HTML Allowed:</strong> h1-h6, p, a, strong, em, br, img)',
                        'id' => 'ct_email_alerts_header_content',
                        'type' => 'textarea',
                        'allowed_html' => array(
                            'a' => array(
                                'href' => array(),
                                'title' => array()
                            ),
                            'img' => array(
                                'src' => array(),
                                'alt' => array()
                            ),
                            'br' => array(),
                            'em' => array(),
                            'strong' => array(),
                            'h1' => array(),
                            'h2' => array(),
                            'h3' => array(),
                            'h4' => array(),
                            'h5' => array(),
                            'h6' => array(),
                            'p' => array(),
                        ),
                        'title' => 'Header',
                        'placeholder' => '<h1>A New Listing Matching Your Criteria has been Added!</h1>',
                    ),
                    array (
                        'desc' => 'This is the text displayed in the footer of your email alert. (<strong>HTML Allowed:</strong> h1-h6, p, a, strong, em, br, img)',
                        'id' => 'ct_email_alerts_footer_content',
                        'type' => 'textarea',
                        'allowed_html' => array(
                            'a' => array(
                                'href' => array(),
                                'title' => array()
                            ),
                            'img' => array(
                                'src' => array(),
                                'alt' => array()
                            ),
                            'br' => array(),
                            'em' => array(),
                            'strong' => array(),
                            'h1' => array(),
                            'h2' => array(),
                            'h3' => array(),
                            'h4' => array(),
                            'h5' => array(),
                            'h6' => array(),
                            'p' => array(),
                        ),
                        'title' => 'Footer',
                        'placeholder' => '<p>You\'re receiving this email from our secure server at Realty Company Inc., because you signed up for listing email alerts.</p>',
                    ),
                    array (
                        'desc' => 'This is the company info displayed in the footer of your email alert. (<strong>HTML Allowed:</strong> h1-h6, p, a, strong, em, br, img)',
                        'id' => 'ct_email_alerts_footer_company_info',
                        'type' => 'textarea',
                        'allowed_html' => array(
                            'a' => array(
                                'href' => array(),
                                'title' => array()
                            ),
                            'img' => array(
                                'src' => array(),
                                'alt' => array()
                            ),
                            'br' => array(),
                            'em' => array(),
                            'strong' => array(),
                            'h1' => array(),
                            'h2' => array(),
                            'h3' => array(),
                            'h4' => array(),
                            'h5' => array(),
                            'h6' => array(),
                            'p' => array(),
                        ),
                        'title' => 'Company Info',
                        'placeholder' => '<p>&copy; 2021, Realty Company Inc., 250 First Ave. San Diego, CA 92101</p>',
                    ),
                    array(
                        'id'     => 'alerts-email-content-end',
                        'type'   => 'section',
                        'indent' => false,
                    ),
                )
            ) );

            do_action( 'ct_register_options_section_email_alerts', $opt_name );

        }

        if (function_exists('wpfp_link')) { 

            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'Favorites', 'contempo' ),
                'id'               => 'favorite-listings',
            'group'            => 'Listings',
                'subsection'       => true,
                'fields'           => array(
                    array (
                        'desc' => 'Select whether or not you\'d like to only let registered users to favorite listings.',
                        'id' => 'ct_fav_only_reg_users',
                        'type' => 'switch',
                        'title' => 'Only Allow Registered Users to Favorite?',
                        'default' => 'no',
                    ),
                    array (
                            'id' => 'favorite-listings-info',
                            'type' => 'info',
                            'raw' => 'Create a Page > Select the Favorite Listings Page Template > Publish > Search and select the page below, once thats complete a link will appear in the top bar of the site.',
                        ),
                    array (
                        'desc' => 'Select your favorite listings page here.',
                        'id' => 'ct_saved_listings',
                        'type' => 'select',
                        'data' => 'pages',
                        'title' => 'Favorite Listings Page',
                        'default' => '632',
                    ),
                    array (
                        'desc' => 'Enter the contact email you\'d like to have the "Request More Information on All Favorites" sent to, this includes user information along with links to said users favorite listings.',
                        'id' => 'ct_favorite_posts_contact_email',
                        'type' => 'text',
                        'title' => 'Contact Email for "Request More Info on All Favorites"',
                        'default' => '',
                    ),
                )
            ) );
        }

        if(shortcode_exists('ct_listing_analytics')) {

            CT_Settings::set_section( $opt_name, array(
                'title'            => __( 'Analytics', 'contempo' ),
                'id'               => 'analytics',
            'group'            => 'Integrations',
                'subsection'       => true,
                'fields'           => array(
                    array (
                        'desc' => 'Select the Listing Analytics page here, this is automatically created when the Contempo Listings Analytics plugin is installed and activated.',
                        'id' => 'ct_listing_analytics',
                        'type' => 'select',
                        'data' => 'pages',
                        'title' => 'Listing Analytics Page',
                        //'default' => '632',
                    ),
                    array (
                        'desc' => 'This is the small graph icon displayed overlaying the featured image on the frontend.',
                        'id' => 'ct_listing_stats_on_off',
                        'type' => 'switch',
                        'title' => 'Display Listing Analytics?',
                        'default' => 'no',
                    ),
                )
            ) );

        }

        }

        CT_Settings::set_section( $opt_name, array(
            'title'            => __( 'WalkScore', 'contempo' ),
            'id'               => 'walkscore',
            'group'            => 'Integrations',
            'subsection'       => true,
            'desc'   => __( 'Walk Score is the only international measure of walkability and the leading provider of neighborhood maps to the real estate industry. More than 30,000 websites use the Walk Score Neighborhood Map and we serve over 20 million scores each day. <a href="https://www.walkscore.com/professional/api-sign-up.php" target="_blank">Get your API Key</a>!.', 'contempo' ),
            'fields'           => array(
                array (
                    'desc' => 'Select whether or not you\'d like to enable Walk Score for listings.',
                    'id' => 'ct_enable_walkscore',
                    'type' => 'switch',
                    'title' => 'Enable Walk Score for Listings?',
                    'default' => 'no',
                ),
                array (
                    'desc' => 'Enter your Walk Score API Key here, don\'t have one get one <a href="https://www.walkscore.com/professional/api-sign-up.php" target="_blank">here</a>.',
                    'id' => 'ct_walkscore_apikey',
                    'type' => 'text',
                    'title' => 'Walk Score API Key',
                    'required' => array('ct_listing_lat_long','equals','on'),
                    'default' => '',
                ),
                array (
                    'desc' => 'Walk Score depends on latitude and longitude to work properly, turn this on unless you want to manually enter lat/long coordinates for your listings.',
                    'id' => 'ct_listing_lat_long',
                    'type' => 'select',
                    'options' => array (
                        'on' => 'On',
                        'off' => 'Off',
                    ),
                    'title' => 'Automatic latitude & longitude',
                    'default' => 'off',
                    'required' => array('ct_enable_walkscore','equals','yes'),
                ),
            )
        ) );

    }

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'MailChimp', 'contempo' ),
        'id'               => 'mailchimp',
        'group'            => 'Integrations',
        'icon'             => 'fab fa-mailchimp',
        'desc'   => __( 'Send user registrations directly to your MailChimp list, <a href="https://us5.admin.mailchimp.com/account/api/" target="_blank">get your API key</a>.', 'contempo' ),
        'fields'           => array(
            array (
                'desc' => 'Select whether or not you\'d like to enable MailChimp.',
                'id' => 'ct_enable_mailchimp',
                'type' => 'switch',
                'title' => 'Enable MailChimp?',
                'default' => 'no',
            ),
            array (
                'desc' => 'Enter your MailChimp API Key here, get that <a href="https://us5.admin.mailchimp.com/account/api/" target="_blank">here</a> then click on Create A Key and your new API key will be created.',
                'id' => 'ct_mailchimp_apikey',
                'type' => 'text',
                'title' => 'API Key',
                'default' => '',
                'required' => array('ct_enable_mailchimp','=','yes')
            ),
            array (
                'desc' => 'Enter your MailChimp List ID here, login to <a href="https://login.mailchimp.com/" target="_blank">Mailchimp</a>, go to Lists then click on the list title, then in list menu Settings > List name and defaults..',
                'id' => 'ct_mailchimp_list_id',
                'type' => 'text',
                'title' => 'List ID',
                'required' => array('ct_enable_mailchimp','=','yes'),
                'default' => '',
            ),
            array (
                'desc' => 'Select whether or not you\'d like to send all existing users to MailChimp.',
                'id' => 'ct_mailchimp_send_existing_users',
                'type' => 'switch',
                'title' => 'Send Existing Users to List?',
                'default' => 'no',
                'required' => array('ct_enable_mailchimp','=','yes')
            ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Follow Up Boss', 'contempo' ),
        'id'               => 'followupboss',
        'group'            => 'Integrations',
        'icon'             => 'fa fa-user-plus',
        'desc'   => __( 'Directly sync user registrations, forms, and lead activity to your Follow Up Boss account, <a href="https://contempothemes.com/docs/follow-up-boss/" target="_blank">documentation</a>.', 'contempo' ),
        'fields'           => array(
            array (
                'desc' => 'Select whether or not you\'d like to enable the Follow Up Boss connection.',
                'id' => 'ct_enable_fub_connection',
                'type' => 'switch',
                'title' => 'Enable Follow Up Boss?',
                'default' => 'no',
            ),

            array (
                'desc' => 'Enter your Follow Up Boss API Key here.',
                'id' => 'ct_fub_api_key',
                'type' => 'text',
                'title' => 'API Key',
                'default' => '',
                'required' => array('ct_enable_fub_connection','=','yes')
            ),
            
            array (
                'desc' => 'Enter your pixel code here.',
                'id' => 'ct_fub_pixel_code',
                'type' => 'ace_editor',
                'title' => 'Pixel Code',
                'required' => array('ct_enable_fub_connection','=','yes')
            ),

        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Zapier', 'contempo' ),
        'id'               => 'zapier',
        'group'            => 'Integrations',
        'icon'             => 'fa fa-bolt',
        'desc'   => __( 'Use webhooks to send form data to Zapier, <a href="https://contempothemes.com/docs/zapier/" target="_blank">documentation</a>.', 'contempo' ),
        'fields'           => array(
            array (
                'desc' => 'Select whether or not you\'d like to enable Webhooks for Zapier.',
                'id' => 'ct_enable_zapier_webhooks',
                'type' => 'switch',
                'title' => 'Enable Webhooks?',
                'default' => 'no',
            ),
            array (
                'desc' => 'Enter your Webhook URL here.',
                'id' => 'ct_zapier_webhook_url',
                'type' => 'text',
                'title' => 'Webhook URL',
                'default' => '',
                'required' => array('ct_enable_zapier_webhooks','=','yes')
            ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Yelp', 'contempo' ),
        'id'               => 'yelp',
        'group'            => 'Integrations',
        'icon'             => 'fab fa-yelp',
        'desc'   => __( 'Display Yelp "What\'s Nearby" information on listing detail pages. <a href="https://www.yelp.com/developers/v3/manage_app" target="_blank">Create a Yelp app</a> to get your API credentials.', 'contempo' ),
        'fields'           => array(
            array (
                'desc' => 'Select whether or not you\'d like to enable Yelp "What\'s Nearby" for listings.',
                'id' => 'ct_enable_yelp_nearby',
                'type' => 'switch',
                'title' => 'Enable Yelp "What\'s Nearby?"',
                'default' => false,
            ),
            array (
                'desc' => 'Enter your Yelp Client ID here, don\'t have one get one <a href="https://www.yelp.com/developers/v3/manage_app" target="_blank">here</a>.',
                'id' => 'ct_yelp_client_id',
                'type' => 'text',
                'title' => 'Yelp Client ID',
                'default' => '',
                'required' => array('ct_enable_yelp_nearby','=','yes'),
            ),
            array (
                'desc' => 'Enter your Yelp API Key here, don\'t have one get one <a href="https://www.yelp.com/developers/v3/manage_app" target="_blank">here</a>.',
                'id' => 'ct_yelp_api_key',
                'type' => 'text',
                'title' => 'Yelp API Key',
                'default' => '',
                'required' => array('ct_enable_yelp_nearby','=','yes'),
            ),
            array (
                'desc' => 'Drag and drop manager to organize the nearby amenities you\'d like to display.',
                'id' => 'ct_yelp_amenities',
                'type' => 'sorter',
                'title' => 'Nearby Amenities Manager',
                'required' => array('ct_enable_yelp_nearby','=','yes'),
                'options' => array (
                    'disabled' => array (
                        'placebo' => 'placebo',
                        'banks' => 'Banks',
                        'bars' => 'Bars',
                        'store' => 'Stores',
                        'convenience_store' => 'Convenience Stores',
                        'shopping_mall' => 'Shopping Malls',
                        'gas_station' => 'Gas Stations',
                        'transit_station' => 'Transit Stations',
                        'hospitals' => 'Hospitals',
                        'veterinary_care' => 'Veterinary Care',
                        'pet_store' => 'Pet Store',
                        'park' => 'Park',
                    ),
                    'enabled' => array (
                        'placebo' => 'placebo',
                        'restaurant' => 'Restaurants',
                        'coffee_shops' => 'Coffee Shops',
                        'grocery' => 'Grocery',
                        'schools' => 'Schools',
                    ),
                ),
            ),
            array (
                'desc' => 'Enter the number of results you\'d like to show per amenity.',
                'id' => 'ct_yelp_limit',
                'type' => 'text',
                'title' => 'Number of Results',
                'default' => '3',
                'required' => array('ct_enable_yelp_nearby','=','yes'),
            ),
            array (
                'desc' => 'Select whether you\'d like to use miles or kilometers for the distance.',
                'id' => 'ct_yelp_miles_kilometers',
                'type' => 'select',
                'options' => array (
                    'mi' => 'Miles',
                    'km' => 'Kilometers',
                ),
                'title' => 'Miles or Kilometers?',
                'default' => 'mi',
                'required' => array('ct_enable_yelp_nearby','=','yes'),
            ),
            array (
                'desc' => 'Select whether you\'d like for amenity links to open in a new tab or not.',
                'id' => 'ct_yelp_links',
                'type' => 'select',
                'options' => array (
                    '_self' => 'No',
                    '_blank' => 'Yes',
                ),
                'title' => 'Open links in new tab?',
                'default' => '_self',
                'required' => array('ct_enable_yelp_nearby','=','yes'),
            ),
            array (
                'desc' => 'Select your site\'s country so that linked content is localized.',
                'id' => 'ct_yelp_cc',
                'type' => 'select',
                'options' => ct_country_codes(),
                'title' => 'Country',
                'default' => 'US',
                'required' => array('ct_enable_yelp_nearby','=','yes'),
            ),
        )
    ) );

    /* =========================================================================
     * GROUP: User Accounts
     * Sections: Front End Login & Registration, Front End Submission,
     *           Submit Listing Form
     * ========================================================================= */

    // Remove Unnecessary when CT IDX Pro+ is active
    if (class_exists('Contempo\IDXPro\Admin\SettingsPage')) {

        CT_Settings::set_section( $opt_name, array(
            'title'            => __( 'Front End Login & Registration', 'contempo' ),
            'id'               => 'front-end-login-registration-idx',
            'group'            => 'User Accounts',
            'icon'             => 'fas fa-id-badge',
            'fields'           => array(
                array (
                    'desc' => 'Select whether or not you\'d like to disable the front end admin bar for all non-admin level users.',
                    'id' => 'ct_disable_admin_bar',
                    'type' => 'switch',
                    'title' => 'Disable the Admin Bar for non-Admins only?',
                    'default' => 'no',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to display text "Login/Register" or an icon.',
                    'id' => 'ct_front_end_login_registration_text_or_icon',
                    'type' => 'select',
                    'options' => array (
                        'text' => 'Text',
                        'icon' => 'Icon',
                    ),
                    'title' => 'Display Text or Icon for Login & Registration?',
                    'default' => 'text',
                ),
                array (
                    'desc' => 'Select the "User Dashboard" page here, this applies to sellers, agents, brokers and any default WordPress role above subscriber.',
                    'id' => 'ct_user_dashboard',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'User Dashboard Page',
                    'default' => '',
                ),
                array (
                    'desc' => 'Select your edit profile page here.',
                    'id' => 'ct_profile',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'Edit User Profile Page',
                    'default' => '614',
                    'required' => array('ct_enable_front_end_login','equals','yes'),
                ),
                array (
                    'desc' => 'Select the page you\'d like to use for displaying terms and conditions.',
                    'id' => 'ct_registration_terms_conditions_page',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'Terms & Conditions Page',
                    'default' => '',
                    'required' => array('ct_enable_front_end_registration','equals','yes'),
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to allow users to delete their account from their front end settings page.',
                    'id' => 'ct_enable_front_end_account_delete',
                    'type' => 'switch',
                    'title' => 'Enable "Delete Account" button in Edit Profile Page?',
                    'default' => 'no',
                ),
            )
        ) );

    } else {

        CT_Settings::set_section( $opt_name, array(
            'title'            => __( 'Front End Login & Registration', 'contempo' ),
            'id'               => 'front-end-login-registration',
            'group'            => 'User Accounts',
            'icon'             => 'fas fa-id-badge',
            'fields'           => array(
                array (
                    'desc' => 'Select whether or not you\'d like to enable users to login to your site.',
                    'id' => 'ct_enable_front_end_login',
                    'type' => 'switch',
                    'title' => 'Enable Front End Login?',
                    'default' => 'yes',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to display text "Login/Register" or an icon.',
                    'id' => 'ct_front_end_login_registration_text_or_icon',
                    'type' => 'select',
                    'options' => array (
                        'text' => 'Text',
                        'icon' => 'Icon',
                    ),
                    'title' => 'Display Text or Icon for Login & Registration?',
                    'default' => 'text',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to disable the front end admin bar for all non-admin level users.',
                    'id' => 'ct_disable_admin_bar',
                    'type' => 'switch',
                    'title' => 'Disable the Admin Bar for non-Admins only?',
                    'default' => 'no',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to redirect the user to a specific page chosen by you, or their current URL from where they logged in from.',
                    'id' => 'ct_login_redirect_page_or_url',
                    'type' => 'select',
                    'options' => array (
                        'page' => 'Page',
                        'current_url' => 'Current URL',
                    ),
                    'title' => 'Redirect to Specific Page or Current URL on Login?',
                    'default' => 'page',
                ),
                array (
                    'desc' => 'Select the page you\'d like to redirect users to upon logging in here.',
                    'id' => 'ct_login_redirect_page',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'Redirect Page Upon Login',
                    'default' => '',
                    'required' => array('ct_login_redirect_page_or_url','equals','page'),
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to enable users to register for your site.',
                    'id' => 'ct_enable_front_end_registration',
                    'type' => 'switch',
                    'title' => 'Enable Front End Registration?',
                    'default' => 'yes',
                ),
                array (
                    'desc' => 'Select the role you\'d like for users registering from the front end of the site. More on WordPress User Roles &amp; Capabilities can be found at <a href="https://codex.wordpress.org/Roles_and_Capabilities" target="_blank">https://codex.wordpress.org/Roles_and_Capabilities</a>.<br><br><strong>NOTE:</strong> If the Front End Submission option is set to "Yes" a select will be added to the registration form so the user can choose from "Buyer", "Seller" or "Agent" themselves and this option is overridden.',
                    'id' => 'ct_registered_user_role',
                    'type' => 'select',
                    'options' => array (
                        'subscriber' => 'Subscriber',
                        'contributor' => 'Contributor',
                        'author' => 'Author',
                        'editor' => 'Editor',
                        'agent' => 'Agent',
                        'broker' => 'Broker',
                        'buyer' => 'Buyer',
                        'seller' => 'Seller',
                    ),
                    'title' => 'User Role Upon Registering',
                    'default' => 'buyer',
                    'required' => array('ct_enable_front_end_registration','equals','yes'),
                ),
                array (
                    'desc' => 'Select the page you\'d like to redirect users to after registering here.',
                    'id' => 'ct_registration_redirect_page',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'Redirect Page Upon Registration',
                    'default' => '',
                    'required' => array('ct_enable_front_end_registration','equals','yes'),
                ),
                array (
                    'desc' => 'Select the "User Dashboard" page here, this applies to sellers, agents, brokers and any default WordPress role above subscriber.',
                    'id' => 'ct_user_dashboard',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'User Dashboard Page',
                    'default' => '',
                ),
                array (
                    'desc' => 'Select your edit profile page here.',
                    'id' => 'ct_profile',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'Edit User Profile Page',
                    'default' => '614',
                    'required' => array('ct_enable_front_end_login','equals','yes'),
                ),
                array (
                    'desc' => 'Select the page you\'d like to use for displaying terms and conditions.',
                    'id' => 'ct_registration_terms_conditions_page',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'Terms & Conditions Page',
                    'default' => '',
                    'required' => array('ct_enable_front_end_registration','equals','yes'),
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to allow users to delete their account from their front end settings page.',
                    'id' => 'ct_enable_front_end_account_delete',
                    'type' => 'switch',
                    'title' => 'Enable "Delete Account" button in Edit Profile Page?',
                    'default' => 'no',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to enable the Elementor template area, this will add a column to the login/registration modal where you can add your own custom content. Keep in mind you\'re designing for a max-width of 479px for this column.<br><br>To give you a head start grab our premade template from <a href="https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-login-registration-template.json">here</a> (right-click > save as), then you can import that via your sites WordPress Admin > Templates > Import Templates area.<br><br><strong>NOTE: This option requires <a href="https://elementor.com/?ref=5056" target="_blank">Elementor Pro</a>.</strong>',
                    'id' => 'ct_enable_front_end_registration_elementor_template_area',
                    'type' => 'switch',
                    'title' => 'Enable Elementor Template Area?',
                    'default' => 'no',
                ),
                array (
                    'desc' => 'Enter the Elementor template ID here.',
                    'id' => 'ct_front_end_registration_elementor_template_area_id',
                    'type' => 'text',
                    'title' => 'Elementor Template ID',
                    'default' => '',
                    'placeholder' => '1234',
                    'required' => array('ct_enable_front_end_registration_elementor_template_area','equals','yes'),
                ),
            )
        ) );

    }

    // Only show if CT IDX Pro+ is not active
    if (!class_exists('Contempo\IDXPro\Admin\SettingsPage')) {

        CT_Settings::set_section( $opt_name, array(
            'title'            => __( 'Front End Submission', 'contempo' ),
            'id'               => 'front-end-submission',
            'group'            => 'User Accounts',
            'icon'             => 'fas fa-file-invoice-dollar',
            'fields'           => array(
                array (
                    'desc' => 'Select whether or not you\'d like to enable users to submit listings from the front end of your site.',
                    'id' => 'ct_enable_front_end',
                    'type' => 'switch',
                    'title' => 'Enable Front End Submission?',
                    'default' => 'no',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to auto approve listings users submit from the front end of your site. If set to "No" an admin will need to review and manually publish the listing from the admin.',
                    'id' => 'ct_auto_publish',
                    'type' => 'select',
                    'options' => array (
                        'pending' => 'No',
                        'publish' => 'Yes',
                    ),
                    'title' => 'Auto Publish Submissions?',
                    'default' => 'pending',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like automatically generate a listing ID or allow the users to input their own.',
                    'id' => 'ct_generate_listing_id',
                    'type' => 'switch',
                    'title' => 'Automatically Generate Listing ID?',
                    'default' => 'no',
                ),
                array (
                    'desc' => 'Select whether or not you\'d like to show the optional Rental Information fields on the Submit &amp; Edit Listing pages?',
                    'id' => 'ct_submit_rental_info',
                    'type' => 'switch',
                    'title' => 'Show Rental Information Fields on Submit &amp; Edit Listing pages?',
                    'default' => 'no',
                ),
                array (
                    'id' => 'login-register-info',
                    'type' => 'info',
                    'raw' => 'Set the pages below for the front end submission system, the Login/Register modal is automatic if the front end login is enabled under the "Front End Login & Registration" panel.',
                ),
                array (
                    'desc' => 'Select the submit page here.',
                    'id' => 'ct_submit',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'Listing Submit Page',
                    'default' => '623',
                ),
                array (
                    'desc' => 'Select the edit page here.',
                    'id' => 'ct_edit',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'Listing Edit Page',
                    'default' => '626',
                ),
                array (
                    'desc' => 'Select the "My Listings" page here.',
                    'id' => 'ct_view',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'Listings View Page',
                    'default' => '629',
                ),
                array (
                    'desc' => 'Select the "Terms & Conditions" page here.',
                    'id' => 'ct_terms_conditions',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => 'Terms & Conditions Page',
                    'default' => '',
                    'required' => array('ct_enable_front_end_paid_per_listing_or_mebership_packages','equals','membership-packages'),
                ),
            )
        ) );

        CT_Settings::set_section( $opt_name, array(
            'title'            => __( 'Submit Listing Form', 'contempo' ),
            'id'               => 'submit-listing-form',
            'group'            => 'User Accounts',
            'icon'             => 'fas fa-bars',
            'subsection'       => true,
            'fields'           => array(

                $fields = array(
                'id' => 'section-price-description',
                'type' => 'section',
                'title' => __('Price & Description', 'contempo'),
                'subtitle' => __('Select which fields you\'d like to be required.', 'contempo'),
                'indent' => true 
                ),

                array (
                    'id' => 'ct_front_submit_street_address',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Street Address',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_alt_title',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Alternate Title',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_type',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Type',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_status',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Status',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_price',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Price',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_price_prefix',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Price Prefix',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_price_postfix',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Price Postfix',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_price_postfix',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Price Postfix',
                    'default' => 'not_required',
                ),

                $fields = array(
                'id' => 'section-details',
                'type' => 'section',
                'title' => __('Details', 'contempo'),
                'subtitle' => __('Select which fields you\'d like to be required.', 'contempo'),
                'indent' => true 
                ),

                array (
                    'id' => 'ct_front_submit_beds',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Beds',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_baths',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Baths',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_size',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Sq Ft/Sq Meters',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_size',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Sq Ft/Sq Meters',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_lot_size',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Lot Size',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_property_id',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Property ID',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_video_url',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Video URL',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_open_house_date',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Open House Date',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_open_house_start_time',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Open House Start Time',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_open_house_end_time',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Open House End Time',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_additional_features',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Additional Features',
                    'default' => 'not_required',
                ),

                $fields = array(
                'id' => 'section-rental-info',
                'type' => 'section',
                'title' => __('Rental Info', 'contempo'),
                'subtitle' => __('Select which fields you\'d like to be required, these are only shown if enabled via Listings > Listing Single > Enable Vacation Rentals/Booking Fields.', 'contempo'),
                'indent' => true 
                ),

                array (
                    'id' => 'ct_front_submit_max_guests',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Max-number of Guests',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_min_stay',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Minimum Stay',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_check_in',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Check In Time',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_check_out',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Check Out Time',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_extra_person',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Extra Person Charge',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_cleaning_fee',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Cleaning Fee',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_cancellation_fee',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Cancellation Fee',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_security_deposit',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Security Deposit',
                    'default' => 'not_required',
                ),

                $fields = array(
                'id' => 'section-location',
                'type' => 'section',
                'title' => __('Location', 'contempo'),
                'subtitle' => __('Select which fields you\'d like to be required.', 'contempo'),
                'indent' => true 
                ),

                array (
                    'id' => 'ct_front_submit_address',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Address',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_city',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'City',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_state',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'State',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_zip_post',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Zip/Postal Code',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_county',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'County',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_country',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Country',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_community',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Community',
                    'default' => 'not_required',
                ),
                array (
                    'id' => 'ct_front_submit_lat_long',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Latitude & Longitude',
                    'default' => 'not_required',
                ),

                $fields = array(
                'id' => 'section-private-notes',
                'type' => 'section',
                'title' => __('Private Notes', 'contempo'),
                'subtitle' => __('Select which fields you\'d like to be required.', 'contempo'),
                'indent' => true 
                ),

                array (
                    'id' => 'ct_front_submit_private_notes',
                    'type' => 'select',
                    'options' => array (
                        'not_required' => 'Not Required',
                        'required' => 'Required',
                    ),
                    'title' => 'Private Notes',
                    'default' => 'not_required',
                ),
            )
        ) );
    }

    // Use to add custom options section for extensions
    do_action('ct_register_options_section', $opt_name);

    /* =========================================================================
     * GROUP: General — Content Pages (Blog, Single Post, Contact, Footer)
     * ========================================================================= */

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Blog', 'contempo' ),
        'id'               => 'blog-archive',
        'group'            => 'General',
        'icon'             => 'fas fa-archive',
        'fields'           => array(
           array (
                'desc' => 'Choose to either display a sidebar or use a full-width layout for the archive.',
                'id' => 'ct_archive_layout',
                'type' => 'select',
                'options' => array (
                    'sidebar' => 'Sidebar',
                    'full-width' => 'Full Width',
                ),
                'title' => 'Archive Layout',
                'default' => 'sidebar',
            ),
            array (
                'desc' => 'Choose if you want to display the archive header for categories, tags, and similar blog views.',
                'id' => 'ct_archive_header',
                'type' => 'switch',
                'title' => 'Display Archive Header?',
                'default' => 'yes',
            ),
            array (
                'desc' => 'Choose whether to display posts in full width or in a grid layout on the blog archive page.',
                'id' => 'ct_post_archive_layout',
                'type' => 'select',
                'options' => array (
                    'full-width' => 'Full Width',
                    'grid' => 'Grid',
                ),
                'title' => 'Archive Post Layout',
                'default' => 'full-width',
            ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Single Post', 'contempo' ),
        'id'               => 'single-post',
        'group'            => 'General',
        'subsection'       => true,
        'fields'           => array(
           array (
                'desc' => 'Choose whether to display a sidebar or to have the post span the full width of the page.',
                'id' => 'ct_post_layout',
                'type' => 'select',
                'options' => array (
                    'sidebar' => 'Sidebar',
                    'full-width' => 'Full Width',
                ),
                'title' => 'Sidebar or Full Width?',
                'default' => 'sidebar',
            ),
            array (
                'desc' => 'Choose if you want to show the author\'s image/avatar. You can upload an author image in the user profile section. If no image is uploaded, the user\'s Gravatar will be shown instead. If you don\'t have a Gravatar, you can get one <a href=\"https://gravatar.com\" target=\"_blank\">here</a>.',
                'id' => 'ct_author_img',
                'type' => 'switch',
                'title' => 'Display Author Image?',
                'default' => 'yes',
            ),
            array (
                'desc' => 'Choose whether to display the post metadata.',
                'id' => 'ct_post_meta',
                'type' => 'switch',
                'title' => 'Display Post Meta?',
                'default' => 'yes',
            ),
            array (
                'desc' => 'Choose whether to display social media links at the end of your posts.',
                'id' => 'ct_post_social',
                'type' => 'switch',
                'title' => 'Display Social Links?',
                'default' => 'yes',
            ),
            array (
                'desc' => 'Choose whether to display tags at the end of your posts.',
                'id' => 'ct_post_tags',
                'type' => 'switch',
                'title' => 'Display Tags?',
                'default' => 'yes',
            ),
            array (
                'desc' => 'Choose whether to display the \"About the Author\" information at the end of your posts.',
                'id' => 'ct_author_info',
                'type' => 'switch',
                'title' => 'Display "About the Author" info?',
                'default' => 'yes',
            ),
            array (
                'desc' => 'Choose whether to display related posts.',
                'id' => 'ct_related_posts',
                'type' => 'switch',
                'title' => 'Display Related Posts?',
                'default' => 'yes',
            ),
            array (
                'desc' => 'Choose whether to display post navigation at the end of your posts.',
                'id' => 'ct_post_nav',
                'type' => 'switch',
                'title' => 'Display Post Navigation?',
                'default' => 'yes',
            ),
            array (
                'desc' => 'Choose whether to enable or disable comments for all posts globally.',
                'id' => 'ct_post_comments',
                'type' => 'switch',
                'title' => 'Display Comments?',
                'default' => 'yes',
            ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Contact', 'contempo' ),
        'id'               => 'contact',
        'group'            => 'General',
        'icon'             => 'fas fa-envelope',
        'fields'           => array(
            array (
                    'id' => 'contact-info',
                    'type' => 'info',
                    'style' => 'info',
                    'desc' => '<strong>IMPORTANT:</strong> The settings below only apply when using the "Contact" or "Contact No Form" page templates. For more control we suggest using <a href="https://contempothemes.com/docs/elementor" target="_blank">Elementor</a> to build out your page however you see fit.',
                ),
            array (
                'desc' => 'Select whether or not you\'d like to display a Google map of your location.',
                'id' => 'ct_contact_map',
                'type' => 'switch',
                'title' => 'Display Google Map?',
                'default' => 'yes',
            ),
            array (
                'desc' => '',
                'id' => 'ct_contact_map_location',
                'type' => 'text',
                'title' => 'Address',
                'default' => '849 West Harbor Dr. San Diego, CA 92101',
            ),
            
        )
    ) );

    /* =========================================================================
     * GROUP: Security
     * Sections: Bot Protection
     * ========================================================================= */

    CT_Settings::set_section( $opt_name, array(
        'title'  => __( 'Bot Protection', 'contempo' ),
        'id'     => 'bot-protection',
        'group'  => 'Security',
        'icon'   => 'fas fa-shield-alt',
        'desc'   => __( 'Multi-layer bot and spam protection for all theme forms. Works out of the box — configure only if you need to tune the defaults. For advanced firewall rules, country blocking, and login hardening consider a dedicated plugin such as Wordfence.', 'contempo' ),
        'fields' => array(

            array(
                'id'      => 'ct_bp_enabled',
                'type'    => 'switch',
                'title'   => __( 'Enable Bot Protection', 'contempo' ),
                'desc'    => __( 'Activates all bot protection layers for theme forms and AJAX endpoints. When CT IDX Pro+ is active its forms are covered automatically too.', 'contempo' ),
                'default' => 'yes',
            ),

            array(
                'id'    => 'section-bp-honeypot',
                'type'  => 'section',
                'title' => __( 'Honeypot &amp; Timing', 'contempo' ),
                'indent' => true,
            ),

            array(
                'id'       => 'ct_bp_honeypot_enabled',
                'type'     => 'switch',
                'title'    => __( 'Enable Honeypot Fields', 'contempo' ),
                'desc'     => __( 'Injects a hidden field and a page-load timestamp into every form. Bots that fill in the hidden field or submit in under the minimum time are rejected silently.', 'contempo' ),
                'default'  => 'yes',
                'required' => array( 'ct_bp_enabled', 'equals', 'yes' ),
            ),

            array(
                'id'       => 'ct_bp_min_submit_time',
                'type'     => 'text',
                'title'    => __( 'Minimum Submit Time (seconds)', 'contempo' ),
                'desc'     => __( 'Submissions that arrive faster than this value (in seconds) after the page loads are treated as bots. Default: 2.', 'contempo' ),
                'default'  => '2',
                'required' => array( 'ct_bp_honeypot_enabled', 'equals', 'yes' ),
            ),

            array(
                'id'    => 'section-bp-ratelimit',
                'type'  => 'section',
                'title' => __( 'Rate Limiting', 'contempo' ),
                'indent' => true,
            ),

            array(
                'id'       => 'ct_bp_rate_limit_enabled',
                'type'     => 'switch',
                'title'    => __( 'Enable Rate Limiting', 'contempo' ),
                'desc'     => __( 'Limits how many form submissions a single IP address can make within a time window. Uses WordPress transients — no extra database tables required.', 'contempo' ),
                'default'  => 'yes',
                'required' => array( 'ct_bp_enabled', 'equals', 'yes' ),
            ),

            array(
                'id'       => 'ct_bp_rate_limit_max',
                'type'     => 'text',
                'title'    => __( 'Max Submissions per Window', 'contempo' ),
                'desc'     => __( 'Maximum number of form submissions allowed from a single IP within the time window below. Default: 5.', 'contempo' ),
                'default'  => '5',
                'required' => array( 'ct_bp_rate_limit_enabled', 'equals', 'yes' ),
            ),

            array(
                'id'       => 'ct_bp_rate_limit_window',
                'type'     => 'text',
                'title'    => __( 'Time Window (seconds)', 'contempo' ),
                'desc'     => __( 'The rolling time window in seconds used for rate limiting. Default: 60 (one minute).', 'contempo' ),
                'default'  => '60',
                'required' => array( 'ct_bp_rate_limit_enabled', 'equals', 'yes' ),
            ),

            array(
                'id'    => 'section-bp-recaptcha',
                'type'  => 'section',
                'title' => __( 'reCAPTCHA v3 Score', 'contempo' ),
                'indent' => true,
            ),

            array(
                'id'       => 'ct_bp_recaptcha_min_score',
                'type'     => 'text',
                'title'    => __( 'Minimum Score Threshold', 'contempo' ),
                'desc'     => __( 'Google reCAPTCHA v3 scores range from 0.0 (likely a bot) to 1.0 (likely a human). Submissions scoring below this value are rejected. Default: 0.7. Only applies when reCAPTCHA is enabled under <strong>Integrations &rarr; Google reCAPTCHA</strong>.', 'contempo' ),
                'default'  => '0.7',
                'required' => array( 'ct_bp_enabled', 'equals', 'yes' ),
            ),

            array(
                'id'    => 'section-bp-reglimit',
                'type'  => 'section',
                'title' => __( 'Registration Rate Limit', 'contempo' ),
                'indent' => true,
            ),

            array(
                'id'       => 'ct_bp_reg_limit_hourly',
                'type'     => 'text',
                'title'    => __( 'Max Registrations per Hour (per IP)', 'contempo' ),
                'desc'     => __( 'Maximum new account registrations from a single IP address per hour. Default: 2.', 'contempo' ),
                'default'  => '2',
                'required' => array( 'ct_bp_enabled', 'equals', 'yes' ),
            ),

            array(
                'id'       => 'ct_bp_reg_limit_daily',
                'type'     => 'text',
                'title'    => __( 'Max Registrations per Day (per IP)', 'contempo' ),
                'desc'     => __( 'Maximum new account registrations from a single IP address per 24 hours. Default: 5.', 'contempo' ),
                'default'  => '5',
                'required' => array( 'ct_bp_enabled', 'equals', 'yes' ),
            ),

            array(
                'id'    => 'section-bp-whitelist',
                'type'  => 'section',
                'title' => __( 'IP Whitelist', 'contempo' ),
                'indent' => true,
            ),

            array(
                'id'      => 'ct_bp_ip_whitelist',
                'type'    => 'textarea',
                'title'   => __( 'Whitelisted IP Addresses', 'contempo' ),
                'desc'    => __( 'Enter one IP address per line. Whitelisted IPs bypass all bot protection checks — useful for your own office, testing environments, or trusted integrations.', 'contempo' ),
                'default' => '',
            ),

            array(
                'id'    => 'section-bp-logging',
                'type'  => 'section',
                'title' => __( 'Security Log', 'contempo' ),
                'indent' => true,
            ),

            array(
                'id'       => 'ct_bp_logging_enabled',
                'type'     => 'switch',
                'title'    => __( 'Enable Security Log', 'contempo' ),
                'desc'     => __( 'Records all form submissions — accepted and blocked — in the database. Search and map requests are excluded to avoid noise. View the log under Security &rarr; Security Log. Disable to stop data collection.', 'contempo' ),
                'default'  => 'yes',
                'required' => array( 'ct_bp_enabled', 'equals', 'yes' ),
            ),

            array(
                'id'       => 'ct_bp_log_retention',
                'type'     => 'select',
                'title'    => __( 'Retention Period', 'contempo' ),
                'desc'     => __( 'Entries older than this are automatically deleted once per day.', 'contempo' ),
                'default'  => '30',
                'options'  => array(
                    '7'  => __( '7 days',  'contempo' ),
                    '14' => __( '14 days', 'contempo' ),
                    '30' => __( '30 days', 'contempo' ),
                    '90' => __( '90 days', 'contempo' ),
                ),
                'required' => array( 'ct_bp_logging_enabled', 'equals', 'yes' ),
            ),

        ),
    ) );

    /* =========================================================================
     * GROUP: Advanced
     * Sections: Footer, Custom CSS, Custom JS, Import/Export,
     *           Documentation, Changelog
     * ========================================================================= */

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Custom CSS', 'contempo' ),
        'id'               => 'custom-css',
        'group'            => 'Advanced',
        'icon'             => 'fab fa-css3',
        'fields'           => array(
            array (
                'desc' => 'Quickly add some CSS to your theme by adding it to this block.',
                'id' => 'ct_custom_css',
                'type' => 'ace_editor',
                'title' => 'Custom CSS',
            ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Custom JS', 'contempo' ),
        'id'               => 'custom-js',
        'group'            => 'Advanced',
        'icon'             => 'fas fa-code',
        'fields'           => array(
            array (
                'desc' => 'Recommended for Advanced Users only, one small hiccup in this code can bring your site down.',
                'id' => 'ct_custom_js',
                'type' => 'ace_editor',
                'title' => 'Custom JS',
            ),
        )
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'  => __( 'Performance', 'contempo' ),
        'id'     => 'performance',
        'group'  => 'Advanced',
        'icon'   => 'fas fa-tachometer-alt',
        'fields' => array(
            array(
                'id'    => 'ct_preload_hero_image',
                'type'  => 'media',
                'title' => 'Preload Hero Image',
                'desc'  => 'Upload the URL of your above-the-fold hero/banner image. A '
                         . '<code>&lt;link rel="preload" as="image"&gt;</code> tag will be injected '
                         . 'into <code>&lt;head&gt;</code> to improve Lighthouse LCP score. '
                         . 'Recommended when the image is a CSS background (e.g. an Elementor section). '
                         . '<strong>Note:</strong> Update this field whenever you change your hero image. '
                         . 'If your host serves WebP automatically, paste the WebP URL here instead.',
                'url'   => true,
            ),
        ),
    ) );

    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Footer', 'contempo' ),
        'id'               => 'footer',
        'group'            => 'General',
        'icon'             => 'fas fa-th',
        'fields'           => array(
            array (
                'desc' => 'Select whether or not you\'d like to display the widget ready area.',
                'id' => 'ct_footer_widget',
                'type' => 'switch',
                'title' => 'Display Widget Area?',
                'default' => 'yes',
            ),
            array (
                'desc' => 'Choose the footer widget area style you\'d like here.',
                'id' => 'ct_footer_widget_style',
                'type' => 'select',
                'options' => array (
                    '1' => 'One',
                    '2' => 'Two',
                ),
                'title' => 'Footer Widget Area Style',
                'required' => array('ct_footer_widget','equals','yes'),
                'default' => '1',
            ),
            array (
                'desc' => 'Enter your custom footer text here.',
                'id' => 'ct_footer_text',
                'type' => 'textarea',
                'title' => 'Footer Text',
            ),
            array (
                'desc' => 'Show a floating Back to Top button in the bottom-right corner. The button appears after scrolling down and automatically lifts above the footer bar.',
                'id' => 'ct_footer_back_to_top',
                'type' => 'switch',
                'title' => 'Enable Back To Top Button?',
                'default' => 'yes',
            ),
        )
    ) );


    CT_Settings::set_section( $opt_name, array(
        'title'            => __( 'Import/Export', 'contempo' ),
        'id'               => 'import-export',
        'group'            => 'Advanced',
        'icon'             => 'fas fa-sync',
        'fields'           => array(

            array(
                'id'            => 'opt-import-export',
                'type'          => 'import_export',
                'title'         => 'Import / Export',
                'subtitle'      => 'Save and restore your theme options',
                'full_width'    => false,
            ),

        )
    ) );

    if ( file_exists( dirname( __FILE__ ) . '/../theme-documentation/index.html' ) ) {
        $section = array(
            'id'     => 'documentation',
            'icon'   => 'fas fa-university',
            'title'  => __( 'Documentation', 'contempo' ),
            'fields' => array(
                array(
                    'id'           => 'documentation_raw',
                    'type'         => 'raw',
                    'markdown'     => false,
                    'content_path' => dirname( __FILE__ ) . '/../theme-documentation/index.html',
                ),
            ),
        );
        CT_Settings::set_section( $opt_name, $section );
    }

    if ( file_exists( dirname( __FILE__ ) . '/../theme-changelog/index.html' ) ) {
        $section = array(
            'id'     => 'changelog',
            'icon'   => 'fas fa-code',
            'title'  => __( 'Changelog', 'contempo' ),
            'fields' => array(
                array(
                    'id'           => 'changelog_raw',
                    'type'         => 'raw',
                    'markdown'     => false,
                    'content_path' => dirname( __FILE__ ) . '/../theme-changelog/index.html',
                ),
            ),
        );
        CT_Settings::set_section( $opt_name, $section );
    }

    /*
     * <--- END SECTIONS
     */


    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */

    /*
    *
    * --> Action hook examples
    *
    */

    // If Redux is running as a plugin, this will remove the demo notice and links
    //add_action( 'redux/loaded', 'remove_demo' );

    // Function to test the compiler hook and demo CSS output.
    // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
    //add_filter('redux/options/' . $opt_name . '/compiler', 'compiler_action', 10, 3);

    // Change the arguments after they've been declared, but before the panel is created
    //add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );

    // Change the default value of a field after it's been set, but before it's been useds
    //add_filter('redux/options/' . $opt_name . '/defaults', 'change_defaults' );

    // Dynamically add a section. Can be also used to modify sections/fields
    //add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');

    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $return['error'] = $field;
                $field['msg']    = 'your custom error message';
            }

            if ( $warning == true ) {
                $return['warning'] = $field;
                $field['msg']      = 'your custom warning message';
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => __( 'Section via hook', 'contempo' ),
                'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'contempo' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }
    }

    if ( !function_exists( 'wbc_filter_title' ) ) {
        /**
         * Filter for changing demo title in options panel so it's not folder name.
         *
         * @param [string] $title name of demo data folder
         *
         * @return [string] return title for demo name.
         */
        function wbc_filter_title( $title ) {
            return trim( ucfirst( str_replace( "-", " ", $title ) ) );
        }
        // Uncomment the below
        add_filter( 'wbc_importer_directory_title', 'wbc_filter_title', 10 );
    }

    if ( !function_exists( 'wbc_extended_example' ) ) {
        function wbc_extended_example( $demo_active_import , $demo_directory_path ) {
            reset( $demo_active_import );
            $current_key = key( $demo_active_import );
            /************************************************************************
            * Import slider(s) for the current demo being imported
            *************************************************************************/
            if ( class_exists( 'RevSlider' ) ) {
                //If it's demo3 or demo5
                $wbc_sliders_array = array(
                    'multi-listing' => 'home-realestate.zip', //Set slider zip name
                    'vacation-rentals' => 'home-vacation.zip', //Set slider zip name
                );
                if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_sliders_array ) ) {
                    $wbc_slider_import = $wbc_sliders_array[$demo_active_import[$current_key]['directory']];
                    if ( file_exists( $demo_directory_path.$wbc_slider_import ) ) {
                        $slider = new RevSlider();
                        $slider->importSliderFromPost( true, true, $demo_directory_path.$wbc_slider_import );
                    }
                }
            }
            /************************************************************************
            * Setting Menus
            *************************************************************************/
            // If it's demo1 - demo6
            $wbc_menu_array = array( 'landing-page', 'multi-listing', 'vacation-rentals');
            if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && in_array( $demo_active_import[$current_key]['directory'], $wbc_menu_array ) ) {
                $primary = get_term_by( 'name', 'Primary', 'nav_menu' );
                $footer = get_term_by( 'name', 'Footer', 'nav_menu' );
                if ( isset( $primary->term_id ) ) {
                    set_theme_mod( 'nav_menu_locations', array(
                            'primary_left' => $primary->term_id,
                            'primary_right'  => $primary->term_id,
                            'primary_full_width'  => $primary->term_id,
                            'mobile'  => $primary->term_id,
                            'footer'  => $footer->term_id
                        )
                    );
                }
            }
            /************************************************************************
            * Set HomePage
            *************************************************************************/
            // array of demos/homepages to check/select from
            $wbc_home_pages = array(
                'landing-page' => 'Home',
                'multi-listing' => 'Home',
                'vacation-rentals' => 'Home'
            );
            if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_home_pages ) ) {
                $page = get_page_by_title( $wbc_home_pages[$demo_active_import[$current_key]['directory']] );
                if ( isset( $page->ID ) ) {
                    update_option( 'page_on_front', $page->ID );
                    update_option( 'show_on_front', 'page' );
                }
            }
        }
        add_action( 'wbc_importer_after_content_import', 'wbc_extended_example', 10, 2 );
    }

require_once __DIR__ . '/listing-modules-options.php';
