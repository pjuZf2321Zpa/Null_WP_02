<?php
/** Optional manual-listing features supplied by Contempo Real Estate Core 3.8.1+. */
if ( ! defined( 'ABSPATH' ) || ! class_exists( 'CT_RE7_Listing_Modules' ) ) { return; }
// Visibility only: IDX never changes the stored module preferences or data.
if ( CT_RE7_Listing_Modules::idx_active() ) { return; }

$alert_email_defaults = CT_RE7_Listing_Modules::alert_email_defaults();

$module_sections = array(
    'favorites' => array( 'id' => 'favorite-listings', 'title' => __( 'Favorite Listings', 'contempo' ), 'fields' => array(
        array( 'id' => 'ct_fav_only_reg_users', 'type' => 'switch', 'title' => __( 'Only Allow Registered Users to Favorite?', 'contempo' ), 'default' => 'no' ),
        array( 'id' => 'ct_saved_listings', 'type' => 'select', 'data' => 'pages', 'title' => __( 'Favorite Listings Page', 'contempo' ), 'default' => '' ),
        array( 'id' => 'ct_favorite_posts_contact_email', 'type' => 'text', 'title' => __( 'Contact Email for Request More Info on All Favorites', 'contempo' ), 'default' => '' ),
    ) ),
    'compare' => array( 'id' => 'compare-listings', 'title' => __( 'Compare Listings', 'contempo' ), 'fields' => array(
        array( 'id' => 'ct_compare_page', 'type' => 'select', 'data' => 'pages', 'title' => __( 'Compare Listings Page', 'contempo' ), 'default' => '' ),
        array( 'id' => 'ct_compare_alike_theme_select', 'type' => 'select', 'title' => __( 'Comparison Style', 'contempo' ), 'options' => array( 'one' => 'Style One', 'two' => 'Style Two' ), 'default' => 'one' ),
        array( 'id' => 'ct_compare_thumbnail_size_w', 'type' => 'slider', 'title' => __( 'Thumbnail Width', 'contempo' ), 'min' => 1, 'max' => 1200, 'default' => 400 ),
        array( 'id' => 'ct_compare_thumbnail_size_h', 'type' => 'slider', 'title' => __( 'Thumbnail Height', 'contempo' ), 'min' => 1, 'max' => 1200, 'default' => 300 ),
        array( 'id' => 'ct_compare_thumbnail_crop', 'type' => 'select', 'title' => __( 'Crop Thumbnails?', 'contempo' ), 'options' => array( '1' => 'Yes', '0' => 'No' ), 'default' => '1' ),
        array( 'id' => 'ct_compare_max_compare', 'type' => 'slider', 'title' => __( 'Maximum Listings to Compare', 'contempo' ), 'min' => 2, 'max' => 10, 'default' => 4 ),
        array( 'id' => 'ct_compare_data', 'type' => 'compare_fields', 'content_callback' => array( 'CT_RE7_Listing_Modules', 'render_comparison_fields' ) ),
    ) ),
    'analytics' => array( 'id' => 'analytics', 'title' => __( 'Listing Analytics', 'contempo' ), 'fields' => array(
        array( 'id' => 'ct_analytics_license_info', 'type' => 'info', 'style' => 'normal', 'desc' => __( 'Available with an active Real Estate 7 Yearly license.', 'contempo' ) ),
        array( 'id' => 'ct_listing_analytics', 'type' => 'select', 'data' => 'pages', 'title' => __( 'Listing Analytics Page', 'contempo' ), 'default' => '' ),
        array( 'id' => 'ct_listing_stats_on_off', 'type' => 'switch', 'title' => __( 'Display Listing Analytics on Listings?', 'contempo' ), 'desc' => __( 'Controls the frontend display separately from analytics collection.', 'contempo' ), 'default' => 'no' ),
    ) ),
    'alerts' => array( 'id' => 'listing-alerts', 'title' => __( 'Saved Searches & Email Alerts', 'contempo' ), 'fields' => array(
        array( 'id' => 'ct_listing_email_alerts_page_id', 'type' => 'select', 'data' => 'pages', 'title' => __( 'Listing Alerts Page', 'contempo' ), 'default' => '' ),
        array( 'id' => 'ct_listing_email_alerts_interval', 'type' => 'select', 'title' => __( 'Email Interval', 'contempo' ), 'options' => array( 'hourly' => 'Hourly', 'daily' => 'Daily', 'weekly' => 'Weekly' ), 'default' => 'daily' ),
        array( 'id' => 'ct_email_alerts_subject', 'type' => 'text', 'title' => __( 'Email Subject', 'contempo' ), 'default' => $alert_email_defaults['ct_email_alerts_subject'] ),
        array( 'id' => 'ct_email_alerts_intro', 'type' => 'textarea', 'title' => __( 'Email Introduction', 'contempo' ), 'default' => $alert_email_defaults['ct_email_alerts_intro'] ),
        array( 'id' => 'ct_email_alerts_tools', 'type' => 'raw', 'content_callback' => array( 'CT_RE7_Listing_Modules', 'render_alert_email_tools' ) ),
        array( 'id' => 'ct_email_alerts_advanced', 'type' => 'advanced', 'title' => __( 'Email appearance and delivery', 'contempo' ), 'fields' => array(
            array( 'id' => 'ct_email_alerts_preheader', 'type' => 'text', 'title' => __( 'Inbox Preview Text', 'contempo' ), 'default' => $alert_email_defaults['ct_email_alerts_preheader'] ),
            array( 'id' => 'ct_email_alerts_sender_name', 'type' => 'text', 'title' => __( 'Sender Name', 'contempo' ), 'default' => $alert_email_defaults['ct_email_alerts_sender_name'] ),
            array( 'id' => 'ct_email_alerts_reply_to', 'type' => 'text', 'validate' => 'email', 'title' => __( 'Reply-To Email', 'contempo' ), 'default' => '' ),
            array( 'id' => 'ct_email_alerts_accent', 'type' => 'color', 'title' => __( 'Email Accent Color', 'contempo' ), 'default' => $alert_email_defaults['ct_email_alerts_accent'] ),
            array( 'id' => 'ct_email_alerts_max_listings', 'type' => 'slider', 'title' => __( 'Maximum Properties Per Email', 'contempo' ), 'desc' => __( 'Additional matches remain available through the link in the email.', 'contempo' ), 'min' => 1, 'max' => 50, 'default' => 10 ),
            array( 'id' => 'ct_email_alerts_header_content', 'type' => 'textarea', 'allowed_html' => wp_kses_allowed_html( 'post' ), 'title' => __( 'Custom Email Header', 'contempo' ), 'default' => '' ),
            array( 'id' => 'ct_email_alerts_footer_content', 'type' => 'textarea', 'allowed_html' => wp_kses_allowed_html( 'post' ), 'title' => __( 'Custom Email Footer', 'contempo' ), 'default' => '' ),
            array( 'id' => 'ct_email_alerts_footer_company_info', 'type' => 'textarea', 'allowed_html' => wp_kses_allowed_html( 'post' ), 'title' => __( 'Company Information', 'contempo' ), 'default' => '' ),
        ) ),
    ) ),
);

// Existing icon/HTML and asset preferences are retained in storage, not exposed as setup work.
$module_sections['favorites']['fields'][] = array(
    'id' => 'ct_favorites_advanced', 'type' => 'advanced', 'title' => __( 'Advanced preferences', 'contempo' ),
    'fields' => array(
        array( 'id' => 'ct_favorites_post_per_page', 'type' => 'slider', 'title' => __( 'Favorites Per Page', 'contempo' ), 'min' => 1, 'max' => 100, 'default' => 20 ),
        array( 'id' => 'ct_favorites_statistics', 'type' => 'select', 'title' => __( 'Count How Often Listings Are Favorited?', 'contempo' ), 'options' => array( '1' => 'Yes', '0' => 'No' ), 'default' => 1 ),
        array( 'id' => 'ct_favorites_favorites_empty', 'type' => 'text', 'title' => __( 'No Favorites Message', 'contempo' ), 'default' => 'Favorite list is empty.' ),
    ),
);
foreach ( $module_sections as $module => $section ) {
    $flag = CT_RE7_Listing_Modules::flag( $module );
    $fields = array( array( 'id' => $flag, 'type' => 'switch', 'title' => sprintf( __( 'Enable %s?', 'contempo' ), $section['title'] ), 'default' => 'no' ) );
    foreach ( $section['fields'] as $field ) {
        $field['required'] = array( $flag, 'equals', 'yes' );
        $fields[] = $field;
    }
    CT_Settings::set_section( 'ct_options', array( 'title' => $section['title'], 'id' => $section['id'], 'group' => 'Listings', 'subsection' => true, 'fields' => $fields ) );
}
if ( CT_RE7_Listing_Modules::enabled( 'alerts' ) ) { do_action( 'ct_register_options_section_email_alerts', 'ct_options' ); }
unset( $alert_email_defaults, $module_sections, $module, $section, $fields, $field, $flag, $key, $default );
