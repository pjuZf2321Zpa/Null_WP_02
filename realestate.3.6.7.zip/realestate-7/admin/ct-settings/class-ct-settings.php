<?php
/**
 * CT Settings Framework — Core
 *
 * Purpose-built settings API for Real Estate 7, replacing Redux Framework.
 * Stores options in wp_options under 'ct_options', exposes global $ct_options.
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class CT_Settings {

    /** @var array<string, array> Registered section groups per opt_name */
    private static array $sections = [];

    /** @var array<string, array> Registered args per opt_name */
    private static array $args = [];

    /** @var array<string, mixed>|null Cached flat field list per opt_name */
    private static array $fields_cache = [];

    /** @var array<string, mixed>|null Cached defaults per opt_name */
    private static array $defaults_cache = [];

    // -------------------------------------------------------------------------
    // Registration API (mirrors Redux surface)
    // -------------------------------------------------------------------------

    public static function set_args( string $opt_name, array $args ): void {
        self::$args[ $opt_name ] = $args;
    }

    public static function set_section( string $opt_name, array $section ): void {
        self::$sections[ $opt_name ][] = $section;
        // Bust caches when sections change
        unset( self::$fields_cache[ $opt_name ], self::$defaults_cache[ $opt_name ] );
    }

    public static function get_args( string $opt_name ): array {
        return self::$args[ $opt_name ] ?? [];
    }

    public static function get_sections( string $opt_name ): array {
        return self::$sections[ $opt_name ] ?? [];
    }

    // -------------------------------------------------------------------------
    // Options Access
    // -------------------------------------------------------------------------

    /**
     * Return all registered field definitions as a flat array for a given opt_name.
     */
    public static function get_all_fields( string $opt_name ): array {
        if ( isset( self::$fields_cache[ $opt_name ] ) ) {
            return self::$fields_cache[ $opt_name ];
        }

        $fields = [];
        foreach ( self::get_sections( $opt_name ) as $section ) {
            foreach ( $section['fields'] ?? [] as $field ) {
                if ( ! empty( $field['id'] ) ) {
                    $fields[ $field['id'] ] = $field;
                }
                // Handle nested fields (e.g. inside a group/accordion)
                foreach ( $field['fields'] ?? [] as $sub ) {
                    if ( ! empty( $sub['id'] ) ) {
                        $fields[ $sub['id'] ] = $sub;
                    }
                }
            }
        }

        self::$fields_cache[ $opt_name ] = $fields;
        return $fields;
    }

    /**
     * Collect all default values from registered fields.
     */
    public static function get_defaults( string $opt_name ): array {
        if ( isset( self::$defaults_cache[ $opt_name ] ) ) {
            return self::$defaults_cache[ $opt_name ];
        }

        $defaults = [];
        foreach ( self::get_all_fields( $opt_name ) as $id => $field ) {
            if ( array_key_exists( 'default', $field ) ) {
                $defaults[ $id ] = $field['default'];
            }
        }

        self::$defaults_cache[ $opt_name ] = $defaults;
        return $defaults;
    }

    /**
     * Load options from DB, merged with defaults.
     * Used to populate global $ct_options with every key always present.
     */
    public static function get_options( string $opt_name ): array {
        $saved    = get_option( $opt_name, false );
        $defaults = self::get_defaults( $opt_name );

        if ( $saved === false ) {
            // First ever load — write defaults to DB
            add_option( $opt_name, $defaults, '', 'yes' );
            return $defaults;
        }

        return wp_parse_args( $saved, $defaults );
    }

    /**
     * Write options directly (used by Merlin importer and import/export).
     */
    public static function set_options( string $opt_name, array $data ): bool {
        $result = update_option( $opt_name, $data );
        // Refresh global if this is the primary opt_name
        $args = self::get_args( $opt_name );
        $global_var = $args['global_variable'] ?? str_replace( '-', '_', $opt_name );
        if ( $global_var ) {
            $GLOBALS[ $global_var ] = self::get_options( $opt_name );
        }
        return $result;
    }

    // -------------------------------------------------------------------------
    // CSS Helper
    // -------------------------------------------------------------------------

    /**
     * Escape a value for use inside a CSS declaration.
     * Replaces the ct_esc_css() function formerly in custom-stylesheet.php.
     */
    public static function esc_css( mixed $value ): string {
        if ( ! is_string( $value ) ) return '';
        return esc_html( $value );
    }

    /**
     * Normalize a code field value by stripping accumulated legacy slashes.
     *
     * Old Redux installations ran addslashes() on values before saving,
     * compounding with WP magic quotes so each save doubled the backslashes.
     * This strips slashes iteratively until the string is stable — safe for
     * CSS/JS code because intentional backslashes (e.g. unicode escapes) are
     * far less common than the legacy escaping artifact.
     */
    public static function normalize_code( string $value ): string {
        $prev = null;
        while ( $prev !== $value ) {
            $prev  = $value;
            $value = stripslashes( $value );
        }
        return $value;
    }

    // -------------------------------------------------------------------------
    // Bootstrap
    // -------------------------------------------------------------------------

    /**
     * Boot the framework: populate $ct_options global, register hooks.
     * Called on after_setup_theme priority 1 from functions.php.
     */
    public static function boot( string $opt_name = 'ct_options' ): void {
        // Note: hydrate_global() is called directly in functions.php immediately after
        // re7-config.php registers all sections. The wp fallback below catches edge cases
        // (REST API, WP-CLI, or any context where the direct call was bypassed).
        //
        // In the Customizer preview frame, WP applies its pre_option_{option} filter at
        // wp_loaded (after our init@2 hydration). We must unconditionally re-hydrate here
        // so CT_Dynamic_CSS::output() and all template code see the previewed values.
        add_action( 'wp', function() use ( $opt_name ) {
            $args       = self::get_args( $opt_name );
            $global_var = $args['global_variable'] ?? str_replace( '-', '_', $opt_name );
            if ( is_customize_preview() || empty( $GLOBALS[ $global_var ] ) || ! is_array( $GLOBALS[ $global_var ] ) ) {
                self::hydrate_global( $opt_name );
            }
        }, 1 );

        // Admin: register page, save handler
        if ( is_admin() ) {
            require_once __DIR__ . '/class-ct-settings-page.php';
            require_once __DIR__ . '/class-ct-settings-save.php';
            add_action( 'admin_menu',    [ 'CT_Settings_Page', 'register_menu' ],           5 );
            add_action( 'admin_menu',    [ 'CT_Settings_Page', 'register_submenu' ],       20 );
            add_action( 'admin_head',    [ 'CT_Settings_Page', 'suppress_active_submenu' ]    );
            add_action( 'admin_bar_menu',[ 'CT_Settings_Page', 'register_admin_bar' ],     50 );
            add_action( 'admin_init',    [ 'CT_Settings_Save', 'register_ajax' ] );
            add_action( 'admin_enqueue_scripts', [ 'CT_Settings_Page', 'register_assets' ] );
        }

        // Customizer integration — fires when the Customizer is active (panel or preview)
        add_action( 'customize_register', function( \WP_Customize_Manager $wp_customize ) use ( $opt_name ) {
            require_once __DIR__ . '/class-ct-settings-sanitize.php';
            require_once __DIR__ . '/customizer/class-ct-customizer-controls.php';
            require_once __DIR__ . '/class-ct-customizer.php';
            CT_Customizer::register( $wp_customize, $opt_name );
        } );

        // After Customizer save, refresh the global so any subsequent PHP reads are current
        add_action( 'customize_save_after', function() use ( $opt_name ) {
            self::hydrate_global( $opt_name );
        } );

        // Front-end: dynamic CSS output
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_google_fonts' ], 10 );
        add_action( 'wp_head',            [ __CLASS__, 'output_dynamic_css' ], 150 );
    }

    /**
     * Populate the global options variable.
     * Runs on init@3, after re7-config.php has registered all sections (init@2).
     */
    public static function hydrate_global( string $opt_name ): void {
        $args       = self::get_args( $opt_name );
        $global_var = $args['global_variable'] ?? str_replace( '-', '_', $opt_name );

        if ( empty( $global_var ) ) return;

        $options = self::get_options( $opt_name );

        // Allow plugins (CT IDX Pro+, CT Real Estate Core, etc.) to filter
        $options = apply_filters( 'ct_settings/options', $options, $opt_name );

        // Legacy Redux slash accumulation on plain text fields (contact success, etc.)
        if ( isset( $options['ct_contact_success'] ) && is_string( $options['ct_contact_success'] ) ) {
            $options['ct_contact_success'] = self::normalize_code( $options['ct_contact_success'] );
        }

        $GLOBALS[ $global_var ] = $options;

        // Keep the legacy global in sync
        if ( $global_var !== $opt_name ) {
            $GLOBALS[ $opt_name ] = $options;
        }
    }

    // -------------------------------------------------------------------------
    // Dynamic CSS
    // -------------------------------------------------------------------------

    /**
     * Enqueue Google Fonts for all typography fields that use them.
     * Runs on wp_enqueue_scripts @ 10.
     */
    public static function enqueue_google_fonts(): void {
        require_once __DIR__ . '/class-ct-dynamic-css.php';
        CT_Dynamic_CSS::enqueue_google_fonts( 'ct_options' );
    }

    /**
     * Output the unified dynamic <style> block.
     * Runs on wp_head @ 150 — replaces both custom-stylesheet.php and Redux output arrays.
     */
    public static function output_dynamic_css(): void {
        require_once __DIR__ . '/class-ct-dynamic-css.php';
        CT_Dynamic_CSS::output( 'ct_options' );
    }

    // -------------------------------------------------------------------------
    // Upgrade Routine
    // -------------------------------------------------------------------------

    /**
     * Silently deactivate and delete Redux Framework when upgrading to v3.5.9+.
     * Runs once per site on admin_init.
     */
    public static function maybe_remove_redux(): void {
        $last    = get_option( 'ct_theme_version', '0' );
        $current = REALESTATE7_SL_THEME_VERSION;

        if ( version_compare( $last, '3.5.9', '<' ) && version_compare( $current, '3.5.9', '>=' ) ) {
            self::remove_redux_plugin();
        }

        if ( $last !== $current ) {
            update_option( 'ct_theme_version', $current );
        }
    }

    private static function remove_redux_plugin(): void {
        $plugin = 'redux-framework/redux-framework.php';

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';

        if ( is_plugin_active( $plugin ) ) {
            deactivate_plugins( $plugin );
        }

        if ( file_exists( WP_PLUGIN_DIR . '/' . $plugin ) ) {
            WP_Filesystem();
            delete_plugins( [ $plugin ] );
        }

        update_option( 'ct_redux_removed', true );
    }
}
