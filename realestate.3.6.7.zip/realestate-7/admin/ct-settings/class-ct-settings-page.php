<?php
/**
 * CT Settings — Admin Page Renderer
 *
 * Left sidebar (grouped + searchable) + right content area.
 * Sticky header with logo/version/save button, hash-based navigation.
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class CT_Settings_Page {

    private static string $opt_name = 'ct_options';
    private static string $page_slug = 'ct_options';

    // -------------------------------------------------------------------------
    // Registration
    // -------------------------------------------------------------------------

    public static function register_menu(): void {
        add_menu_page(
            __( 'Real Estate 7 Options', 'contempo' ),
            __( 'Real Estate 7 Options', 'contempo' ),
            'manage_options',
            self::$page_slug,
            [ __CLASS__, 'render' ],
            'dashicons-admin-home',
            2.5
        );
    }

    public static function register_submenu(): void {
        global $submenu;

        if ( ! current_user_can( 'manage_options' ) ) return;

        $base     = admin_url( 'admin.php?page=' . self::$page_slug . '#' );
        $sections = CT_Settings::get_sections( self::$page_slug );

        foreach ( $sections as $section ) {
            if ( empty( $section['id'] ) || empty( $section['title'] ) ) continue;
            if ( ! empty( $section['subsection'] ) ) continue;

            $submenu[ self::$page_slug ][] = [
                wp_strip_all_tags( $section['title'] ),
                'manage_options',
                $base . $section['id'],
            ];
        }
    }

    /**
     * Hide the expanded submenu when the user is actively on the CT Options
     * page so the submenu only appears as a hover flyout, not a persistent
     * sidebar list.  WordPress adds .opensub to the hovered item, so we
     * show it only then.
     */
    public static function suppress_active_submenu(): void {
        $slug = self::$page_slug;
        ?>
        <style id="ct-submenu-flyout-only">
            /* Show submenu only as a flyout on hover, never as an expanded sidebar list */
            #adminmenu #toplevel_page_<?php echo esc_attr( $slug ); ?>.wp-has-current-submenu:not(.opensub) > .wp-submenu,
            #adminmenu #toplevel_page_<?php echo esc_attr( $slug ); ?>.wp-menu-open:not(.opensub) > .wp-submenu {
                display: none !important;
                opacity: 0 !important;
                pointer-events: none !important;
            }
        </style>
        <?php
    }

    public static function register_admin_bar( WP_Admin_Bar $bar ): void {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $bar->add_node( [
            'id'    => 'ct_options',
            'title' => '<span class="ab-icon dashicons dashicons-admin-home" style="font-size:18px;line-height:30px;"></span>'
                     . __( 'Real Estate 7 Options', 'contempo' ),
            'href'  => admin_url( 'admin.php?page=' . self::$page_slug ),
            'meta'  => [ 'title' => __( 'Real Estate 7 Options', 'contempo' ) ],
        ] );
    }

    public static function register_assets(): void {
        $screen = get_current_screen();
        if ( ! $screen || strpos( $screen->id, self::$page_slug ) === false ) return;

        // Inject critical CSS in <head> before any content renders so the blank
        // WP admin page is covered immediately, even before our stylesheet loads.
        add_action( 'admin_head', [ __CLASS__, 'print_critical_css' ] );

        $base = get_template_directory_uri() . '/admin/ct-settings/assets/';
        $ver  = REALESTATE7_SL_THEME_VERSION;

        wp_enqueue_style( 'ct-settings', $base . 'ct-settings.css', [ 'wp-color-picker' ], $ver );
        wp_enqueue_style( 'wp-color-picker' );

        // Code editor (ace via CodeMirror-based WP core)
        wp_enqueue_script( 'code-editor' );
        wp_enqueue_style( 'code-editor' );

        wp_enqueue_media();

        wp_enqueue_script(
            'ct-settings',
            $base . 'ct-settings.js',
            [ 'jquery', 'wp-color-picker', 'jquery-ui-sortable' ],
            $ver,
            true
        );

        // Pass data to JS
        $sections   = CT_Settings::get_sections( self::$opt_name );
        $saved_opts = CT_Settings::get_options( self::$opt_name );

        $sections_for_js = [];
        foreach ( $sections as $section ) {
            $fields_for_js = [];
            foreach ( $section['fields'] ?? [] as $field ) {
                $fields_for_js[] = [
                    'id'       => $field['id'] ?? '',
                    'type'     => $field['type'] ?? '',
                    'required' => $field['required'] ?? null,
                ];
            }
            $sections_for_js[] = [
                'id'     => $section['id'] ?? '',
                'fields' => $fields_for_js,
            ];
        }

        wp_localize_script( 'ct-settings', 'ctSettings', [
            'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
            'nonce'      => wp_create_nonce( 'ct_settings_save' ),
            'optName'    => self::$opt_name,
            'saved'      => $saved_opts,
            'sections'   => $sections_for_js,
            'strings'    => [
                'saved'           => __( 'Settings saved', 'contempo' ),
                'saving'          => __( 'Saving…', 'contempo' ),
                'error'           => __( 'Save failed. Please try again.', 'contempo' ),
                'unsaved'         => __( 'You have unsaved changes', 'contempo' ),
                'restore_draft'   => __( 'You have unsaved changes from your last session. Restore?', 'contempo' ),
                'restore_yes'     => __( 'Restore', 'contempo' ),
                'restore_dismiss' => __( 'Dismiss', 'contempo' ),
                'reset_section'   => __( 'Reset section to defaults?', 'contempo' ),
            ],
            'onboarding' => [
                'steps' => get_option( 're7_onboarding_steps', [] ),
                'nonce' => wp_create_nonce( 're7_onboarding' ),
            ],
        ] );
    }

    /**
     * Print critical above-the-fold CSS inline so the blank WP admin page
     * is covered before our external stylesheet arrives. Also provides fallback
     * spinner styles for the same reason.
     */
    public static function print_critical_css(): void {
        $screen = get_current_screen();
        if ( ! $screen || strpos( $screen->id, self::$page_slug ) === false ) return;
        ?>
        <style id="ct-settings-critical">
            /* Remove WP admin chrome padding that creates the blank white gap */
            #wpcontent { padding-left: 0 !important; }
            #wpbody-content { padding-bottom: 0 !important; background: #f0f0f1; }
            #wpbody-content > .wrap { margin: 0 !important; padding: 0 !important; }
            /* Spinner fallback — visible before our CSS file loads */
            #ct-settings-loading {
                position: absolute; inset: 0; z-index: 9999;
                display: flex; flex-direction: column;
                align-items: center; justify-content: center; gap: 16px;
                background: #f0f0f1;
            }
            #ct-settings-loading.ct-loading-hidden { opacity: 0; visibility: hidden; pointer-events: none; }
            .ct-spinner {
                width: 44px; height: 44px;
                border: 3px solid #e5e7eb; border-top-color: #2271b1;
                border-radius: 50%; animation: ct-spin 0.7s linear infinite;
            }
            @keyframes ct-spin { to { transform: rotate(360deg); } }
        </style>
        <?php
    }


    // -------------------------------------------------------------------------
    // Page Renderer
    // -------------------------------------------------------------------------

    public static function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $opt_name    = self::$opt_name;
        $sections    = CT_Settings::get_sections( $opt_name );
        $saved_opts  = CT_Settings::get_options( $opt_name );
        $args        = CT_Settings::get_args( $opt_name );
        $theme       = wp_get_theme( get_template() );
        $version     = $theme->get( 'Version' );

        // Group definitions for sidebar
        $groups = self::get_section_groups( $sections );
        ?>
        <div id="ct-settings-wrap" class="ct-settings-wrap">

            <!-- Loading Spinner -->
            <div id="ct-settings-loading" aria-live="polite" aria-label="<?php esc_attr_e( 'Loading settings…', 'contempo' ); ?>">
                <div class="ct-spinner" role="status"></div>
                <span class="ct-spinner-label"><?php _e( 'Loading settings…', 'contempo' ); ?></span>
            </div>
            <?php
            // Flush the spinner to the browser immediately so it appears while
            // the remaining PHP (sidebar nav + section HTML) is still rendering.
            if ( ob_get_level() > 0 ) { ob_flush(); }
            flush();
            ?>

            <!-- Sticky Header -->
            <div class="ct-settings-header" id="ct-settings-header">
                <div class="ct-settings-header__left">
                    <span class="ct-settings-logo dashicons dashicons-admin-home"></span>
                    <span class="ct-settings-title"><?php _e( 'Real Estate 7 Options', 'contempo' ); ?></span>
                    <span class="ct-settings-version"><?php echo esc_html( $version ); ?></span>
                </div>
                <div class="ct-settings-header__right">
                    <span class="ct-settings-unsaved-dot" id="ct-unsaved-dot" title="<?php _e( 'Unsaved changes', 'contempo' ); ?>"></span>
                    <button type="button" id="ct-save-btn" class="ct-settings-save-btn">
                        <?php _e( 'Save Changes', 'contempo' ); ?>
                    </button>
                </div>
            </div>

            <!-- Draft Restore Banner -->
            <div class="ct-settings-draft-banner" id="ct-draft-banner" style="display:none;">
                <span class="ct-draft-banner__text"></span>
                <div class="ct-draft-banner__actions">
                    <button type="button" class="button button-primary" id="ct-draft-restore"></button>
                    <button type="button" class="button" id="ct-draft-dismiss"></button>
                </div>
            </div>

            <div class="ct-settings-body">

                <!-- Left Sidebar -->
                <aside class="ct-settings-sidebar" id="ct-settings-sidebar">
                    <div class="ct-settings-search-wrap">
                        <input type="search"
                               id="ct-settings-search"
                               class="ct-settings-search"
                               placeholder="<?php esc_attr_e( 'Search settings…', 'contempo' ); ?>"
                               autocomplete="off" />
                        <span class="ct-settings-search-icon dashicons dashicons-search"></span>
                    </div>
                    <nav class="ct-settings-nav" id="ct-settings-nav">
                        <?php self::render_sidebar_nav( $sections, $groups ); ?>
                    </nav>
                </aside>

                <!-- Mobile sidebar toggle -->
                <button type="button" class="ct-sidebar-toggle" id="ct-sidebar-toggle" aria-label="<?php esc_attr_e( 'Toggle sidebar', 'contempo' ); ?>">
                    <span class="dashicons dashicons-menu"></span>
                </button>

                <!-- Main Content -->
                <main class="ct-settings-content" id="ct-settings-content">
                    <!-- Search results panel — shown instead of section panels while a search is active -->
                    <div id="ct-search-results" class="ct-search-results" style="display:none;" aria-live="polite" aria-label="<?php esc_attr_e( 'Search results', 'contempo' ); ?>"></div>
                    <?php self::render_sections( $sections, $saved_opts ); ?>
                </main>

            </div><!-- /.ct-settings-body -->

            <!-- Snackbar -->
            <div class="ct-settings-snackbar" id="ct-settings-snackbar" aria-live="polite"></div>

        </div><!-- /#ct-settings-wrap -->
        <?php
    }

    // -------------------------------------------------------------------------
    // Sidebar Nav
    // -------------------------------------------------------------------------

    private static function render_sidebar_nav( array $sections, array $groups ): void {
        // Map section id → section data
        $section_map = [];
        foreach ( $sections as $section ) {
            $id = $section['id'] ?? sanitize_title( $section['title'] ?? '' );
            $section_map[ $id ] = $section;
        }

        foreach ( $groups as $group_label => $section_ids ) {
            // Build a parent→children tree for this group.
            // Sections with subsection:true are children of the preceding non-subsection.
            $tree        = []; // [ ['id' => ..., 'children' => [...]], ... ]
            $last_parent = null;

            foreach ( $section_ids as $sid ) {
                if ( ! isset( $section_map[ $sid ] ) ) continue;
                $section = $section_map[ $sid ];
                $is_sub  = ! empty( $section['subsection'] );

                if ( $is_sub && $last_parent !== null ) {
                    $tree[ $last_parent ]['children'][] = $sid;
                } else {
                    $tree[ $sid ] = [ 'children' => [] ];
                    $last_parent  = $sid;
                }
            }

            echo '<div class="ct-nav-group" data-group="' . esc_attr( sanitize_title( $group_label ) ) . '">';
            echo '<button type="button" class="ct-nav-group__toggle">';
            echo '<span class="ct-nav-group__label">' . esc_html( $group_label ) . '</span>';
            echo '<span class="ct-nav-group__arrow dashicons dashicons-arrow-down-alt2"></span>';
            echo '</button>';
            echo '<ul class="ct-nav-group__items">';

            foreach ( $tree as $sid => $node ) {
                $section  = $section_map[ $sid ];
                $title    = $section['title'] ?? $sid;
                $icon     = $section['icon'] ?? '';
                $children = $node['children'];
                $has_sub  = ! empty( $children );

                $item_class = 'ct-nav-item' . ( $has_sub ? ' ct-nav-item--has-children' : '' );

                echo '<li class="' . esc_attr( $item_class ) . '" data-section="' . esc_attr( $sid ) . '">';
                echo '<a href="#' . esc_attr( $sid ) . '" class="ct-nav-link">';
                if ( $icon ) echo '<span class="ct-nav-icon ' . esc_attr( $icon ) . '"></span>';
                echo '<span class="ct-nav-text">' . esc_html( $title ) . '</span>';
                echo '<span class="ct-nav-dirty-dot" style="display:none;"></span>';
                if ( $has_sub ) {
                    echo '<span class="ct-nav-submenu-arrow dashicons dashicons-arrow-right-alt2"></span>';
                }
                echo '</a>';

                if ( $has_sub ) {
                    echo '<ul class="ct-nav-submenu">';
                    foreach ( $children as $child_sid ) {
                        if ( ! isset( $section_map[ $child_sid ] ) ) continue;
                        $child_section = $section_map[ $child_sid ];
                        $child_title   = $child_section['title'] ?? $child_sid;
                        echo '<li class="ct-nav-item ct-nav-item--sub" data-section="' . esc_attr( $child_sid ) . '">';
                        echo '<a href="#' . esc_attr( $child_sid ) . '" class="ct-nav-link">';
                        echo '<span class="ct-nav-text">' . esc_html( $child_title ) . '</span>';
                        echo '<span class="ct-nav-dirty-dot" style="display:none;"></span>';
                        echo '</a></li>';
                    }
                    echo '</ul>';
                }

                echo '</li>';
            }

            echo '</ul></div>';
        }
    }

    // -------------------------------------------------------------------------
    // Section Panels
    // -------------------------------------------------------------------------

    private static function render_sections( array $sections, array $saved_opts ): void {
        foreach ( $sections as $index => $section ) {
            $id     = $section['id'] ?? 'section-' . $index;
            $title  = $section['title'] ?? '';
            $fields = $section['fields'] ?? [];

            echo '<section class="ct-settings-section" id="section-' . esc_attr( $id ) . '" data-section="' . esc_attr( $id ) . '" style="display:none;">';
            echo '<div class="ct-section-header">';
            echo '<h2 class="ct-section-title">' . esc_html( $title ) . '</h2>';
            echo '<button type="button" class="ct-section-reset button button-secondary" data-section="' . esc_attr( $id ) . '">' . __( 'Reset to defaults', 'contempo' ) . '</button>';
            echo '</div>';
            echo '<div class="ct-section-fields">';

            $inherited_required = null;

            foreach ( $fields as $field ) {
                $type = $field['type'] ?? 'text';

                if ( $type === 'section' ) {
                    if ( ! empty( $field['indent'] ) && ! empty( $field['required'] ) ) {
                        $inherited_required = $field['required'];
                    } elseif ( isset( $field['indent'] ) && $field['indent'] === false ) {
                        $inherited_required = null;
                    }
                } elseif ( $type !== 'info' && $inherited_required !== null ) {
                    $parent_conds = is_array( $inherited_required[0] ) ? $inherited_required : [ $inherited_required ];
                    if ( empty( $field['required'] ) ) {
                        $field['required'] = $parent_conds;
                    } else {
                        $own_conds         = is_array( $field['required'][0] ) ? $field['required'] : [ $field['required'] ];
                        $field['required'] = array_merge( $parent_conds, $own_conds );
                    }
                }

                self::render_field_row( $field, $saved_opts );
            }

            echo '</div></section>';
        }
    }

    public static function render_field_row( array $field, array $saved_opts ): void {
        $type = $field['type'] ?? 'text';

        if ( $type === 'info' ) {
            $title = $field['title'] ?? '';
            $desc  = $field['desc'] ?? '';
            if ( ! $title && ! $desc ) {
                return;
            }
            $style = $field['style'] ?? 'normal';
            $class = 'ct-field-info-banner';
            if ( $style === 'warning' )  $class .= ' ct-field-info-banner--warning';
            if ( $style === 'success' )  $class .= ' ct-field-info-banner--success';
            if ( $style === 'critical' ) $class .= ' ct-field-info-banner--error';
            echo '<div class="' . esc_attr( $class ) . '">';
            if ( $title ) echo '<strong>' . esc_html( $title ) . '</strong> ';
            echo wp_kses_post( $desc );
            echo '</div>';
            return;
        }
        if ( $type === 'section' ) {
            $title    = $field['title'] ?? '';
            $desc     = $field['desc'] ?? '';
            $required = $field['required'] ?? null;

            // Pure closing/indent markers (no title, no desc, no required) have no
            // visual output — skip them entirely rather than emitting an empty row.
            if ( ! $title && ! $desc && ! $required ) {
                return;
            }

            $req_attr = $required ? ' data-required="' . esc_attr( wp_json_encode( $required ) ) . '"' : '';
            echo '<div class="ct-field-row ct-field-section-divider"' . $req_attr . '>';
            if ( $title ) echo '<h3>' . wp_kses_post( $title ) . '</h3>';
            if ( $desc )  echo '<p>' . wp_kses_post( $desc ) . '</p>';
            echo '</div>';
            return;
        }

        $id          = $field['id'] ?? '';
        $title       = $field['title'] ?? '';
        $desc        = $field['desc'] ?? '';
        $required    = $field['required'] ?? null;
        $saved_value = $saved_opts[ $id ] ?? ( $field['default'] ?? '' );

        // Build required attributes for JS visibility engine
        $req_attr = '';
        if ( $required ) {
            $req_attr = ' data-required="' . esc_attr( wp_json_encode( $required ) ) . '"';
        }

        $type      = $field['type'] ?? 'text';
        $full_row  = in_array( $type, [ 'raw', 'compare_fields', 'advanced' ], true );
        $row_class = 'ct-field-row' . ( $full_row ? ' ct-field-row--full' : '' );

        echo '<div class="' . $row_class . '" data-field-id="' . esc_attr( $id ) . '"' . $req_attr . '>';

        if ( ! $full_row ) {
            echo '<div class="ct-field-label">';
            if ( $title ) echo '<label for="ct_field_' . esc_attr( $id ) . '">' . esc_html( $title ) . '</label>';
            if ( $desc )  echo '<p class="ct-field-desc">' . wp_kses_post( $desc ) . '</p>';
            echo '</div>';
        }

        echo '<div class="ct-field-input">';

        self::render_field_input( $field, $saved_value );

        echo '</div></div>';
    }

    private static function render_field_input( array $field, mixed $saved_value ): void {
        require_once __DIR__ . '/fields/class-field-base.php';

        $type = $field['type'] ?? 'text';
        $map  = [
            'text'          => 'CT_Field_Text',
            'textarea'      => 'CT_Field_Text',
            'switch'        => 'CT_Field_Switch',
            'select'        => 'CT_Field_Select',
            'image_select'  => 'CT_Field_Select',
            'info'          => 'CT_Field_Info',
            'section'       => 'CT_Field_Info',
            'raw'           => 'CT_Field_Raw',
            'advanced'      => 'CT_Field_Advanced',
            'compare_fields'=> 'CT_Field_Raw',
            'color'         => 'CT_Field_Color',
            'color_rgba'    => 'CT_Field_Color_RGBA',
            'slider'        => 'CT_Field_Slider',
            'media'         => 'CT_Field_Media',
            'typography'    => 'CT_Field_Typography',
            'sorter'        => 'CT_Field_Sorter',
            'ace_editor'    => 'CT_Field_Ace_Editor',
            'background'    => 'CT_Field_Background',
            'import_export' => 'CT_Field_Import_Export',
            'page_picker'   => 'CT_Field_Page_Picker',
        ];

        $class_name = $map[ $type ] ?? 'CT_Field_Text';
        $file       = strtolower( str_replace( [ 'CT_Field_', '_' ], [ 'class-field-', '-' ], $class_name ) ) . '.php';

        $path = __DIR__ . '/fields/' . $file;
        if ( ! file_exists( $path ) ) {
            // Fallback to text if file not found
            $path       = __DIR__ . '/fields/class-field-text.php';
            $class_name = 'CT_Field_Text';
        }

        require_once $path;

        if ( class_exists( $class_name ) ) {
            /** @var CT_Field_Base $instance */
            $instance = new $class_name( $field, $saved_value );
            $instance->render();
        }
    }

    // -------------------------------------------------------------------------
    // Section Groups
    // -------------------------------------------------------------------------

    /**
     * Define sidebar group → section IDs mapping.
     * Each section can declare 'group' key, or we use defaults.
     */
    private static function get_section_groups( array $sections ): array {
        $groups = [
            'Getting Started' => [],
            'General'         => [],
            'Appearance'      => [],
            'Listings'        => [],
            'Integrations'    => [],
            'User Accounts'   => [],
            'Security'        => [],
            'Advanced'        => [],
        ];

        // Explicit section ID → group assignments for all RE7 core sections.
        // Plugin-added sections fall back to keyword matching below.
        $id_map = [
            // Getting Started
            'getting-started'               => 'Getting Started',
            // General
            'general-settings'              => 'General',
            'header'                        => 'General',
            'logo'                          => 'General',
            'top-bar'                       => 'General',
            'homepage'                      => 'General',
            'blog-archive'                  => 'General',
            'single-post'                   => 'General',
            'contact'                       => 'General',
            'footer'                        => 'General',
            // Appearance (formerly Colors + Typography)
            'appearance'                    => 'Appearance',
            'create-a-skin-body-background' => 'Appearance',
            'create-a-skin-header'          => 'Appearance',
            'create-a-skin-mobile-navigation' => 'Appearance',
            'create-a-skin-secondary-colors'=> 'Appearance',
            'create-a-skin-links'           => 'Appearance',
            'create-a-skin-footer'          => 'Appearance',
            'typography'                    => 'Appearance',
            // Listings
            'agents'                        => 'Listings',
            'profile'                       => 'Listings',
            'agent-single'                  => 'Listings',
            'agent-single-idx'              => 'Listings',
            'brokerages'                    => 'Listings',
            'advanced-search'               => 'Listings',
            'advanced-search-header'        => 'Listings',
            'advanced-search-elementor'     => 'Listings',
            'off-market-listings'           => 'Listings',
            'listing-images'                => 'Listings',
            'single-detail'                 => 'Listings',
            'off-market-single-detail'      => 'Listings',
            'listings'                      => 'Listings',
            'images'                        => 'Listings',
            'search'                        => 'Listings',
            'listing-alerts'                => 'Listings',
            'favorite-listings'             => 'Listings',
            'compare-listings'              => 'Listings',
            // Integrations
            'google-maps'                   => 'Integrations',
            'google-recaptcha'              => 'Integrations',
            'analytics'                     => 'Listings',
            'walkscore'                     => 'Integrations',
            'listings-walkscore'            => 'Integrations',
            'mailchimp'                     => 'Integrations',
            'followupboss'                  => 'Integrations',
            'zapier'                        => 'Integrations',
            'yelp'                          => 'Integrations',
            'lofty'                         => 'Integrations',
            // User Accounts
            'front-end-login-registration'      => 'User Accounts',
            'front-end-login-registration-idx'  => 'User Accounts',
            'front-end-submission'              => 'User Accounts',
            'submit-listing-form'               => 'User Accounts',
            // Security
            'bot-protection'                => 'Security',
            // Advanced
            'custom-css'                    => 'Advanced',
            'custom-js'                     => 'Advanced',
            'import-export'                 => 'Advanced',
            'documentation'                 => 'Advanced',
            'changelog'                     => 'Advanced',
        ];

        // Keyword fallback for extension-added sections not in the id map above.
        $keyword_map = [
            'Appearance'   => [ 'create-a-skin', 'appearance', 'color', 'colours', 'skin', 'typography', 'font' ],
            'Integrations' => [ 'idx', 'recaptcha', 'zapier', 'mailchimp', 'crm',
                                'followup', 'smtp', 'analytics', 'google-map', 'api', 'yelp' ],
            'Listings'     => [ 'listing', 'agent', 'brokerage', 'mortgage',
                                'calculator', 'single-detail', 'off-market', 'search' ],
            'User Accounts' => [ 'user', 'login', 'register', 'registration', 'profile',
                                'lead', 'account', 'dashboard' ],
            'Advanced'     => [ 'custom-css', 'custom-js', 'performance', 'gdpr', 'cookie',
                                'import', 'export', 'documentation', 'changelog' ],
        ];

        foreach ( $sections as $section ) {
            $id = $section['id'] ?? sanitize_title( $section['title'] ?? '' );

            // 1. Explicit 'group' key on the section definition
            if ( ! empty( $section['group'] ) && isset( $groups[ $section['group'] ] ) ) {
                $groups[ $section['group'] ][] = $id;
                continue;
            }

            // 2. Known section ID lookup
            if ( isset( $id_map[ $id ] ) ) {
                $groups[ $id_map[ $id ] ][] = $id;
                continue;
            }

            // 3. Keyword fallback for plugin-added sections
            $assigned = false;
            foreach ( $keyword_map as $group => $keywords ) {
                foreach ( $keywords as $kw ) {
                    if ( str_contains( $id, $kw ) ) {
                        $groups[ $group ][] = $id;
                        $assigned = true;
                        break 2;
                    }
                }
            }

            if ( ! $assigned ) {
                $groups['General'][] = $id;
            }
        }

        return array_filter( $groups, fn( $ids ) => ! empty( $ids ) );
    }
}
