<?php
/**
 * CT Settings — WordPress Customizer Integration
 *
 * Registers Customizer panels, sections, settings and controls that mirror
 * the critical subset of ct-settings theme options (branding, layout,
 * typography, colors). Settings write to the same ct_options wp_options row
 * as the admin panel — both interfaces are always in sync.
 *
 * Entry point: CT_Customizer::register() called from customize_register hook.
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class CT_Customizer {

    private static string               $opt_name   = 'ct_options';
    private static \WP_Customize_Manager $manager;
    private static array                $defaults   = [];
    private static array                $all_fields = [];
    private static int                  $priority   = 10;

    // -------------------------------------------------------------------------
    // Boot
    // -------------------------------------------------------------------------

    public static function register( \WP_Customize_Manager $wp_customize, string $opt_name ): void {
        self::$opt_name   = $opt_name;
        self::$manager    = $wp_customize;
        self::$defaults   = CT_Settings::get_defaults( $opt_name );
        self::$all_fields = CT_Settings::get_all_fields( $opt_name );

        self::register_panels();
        self::register_sections();
        self::register_branding_controls();
        self::register_layout_controls();
        self::register_typography_controls();
        self::register_header_color_controls();
        self::register_body_color_controls();
        self::register_footer_controls();
        self::register_custom_css_control();

        add_action( 'customize_preview_init',             [ __CLASS__, 'enqueue_preview_scripts' ] );
        add_action( 'customize_controls_enqueue_scripts', [ __CLASS__, 'enqueue_control_scripts' ] );
    }

    // -------------------------------------------------------------------------
    // Panels
    // -------------------------------------------------------------------------

    private static function register_panels(): void {
        $panels = [
            'ct_branding'      => [ 'title' => __( 'Branding & Logo', 'contempo' ),               'priority' => 25 ],
            'ct_layout'        => [ 'title' => __( 'Layout & Structure', 'contempo' ),             'priority' => 30 ],
            'ct_typography'    => [ 'title' => __( 'Typography', 'contempo' ),                     'priority' => 35 ],
            'ct_header_colors' => [ 'title' => __( 'Header & Navigation Colors', 'contempo' ),     'priority' => 40 ],
            'ct_body_colors'   => [ 'title' => __( 'Body & Link Colors', 'contempo' ),             'priority' => 45 ],
            'ct_footer'        => [ 'title' => __( 'Footer', 'contempo' ),                         'priority' => 50 ],
        ];

        foreach ( $panels as $id => $args ) {
            self::$manager->add_panel( $id, $args );
        }
    }

    // -------------------------------------------------------------------------
    // Sections
    // -------------------------------------------------------------------------

    private static function register_sections(): void {
        $sections = [
            // Branding
            'ct_logo_section'           => [ 'panel' => 'ct_branding',      'title' => __( 'Logo & Identity', 'contempo' ),           'priority' => 10 ],
            // Layout
            'ct_layout_general'         => [ 'panel' => 'ct_layout',        'title' => __( 'General Layout', 'contempo' ),             'priority' => 10 ],
            'ct_layout_header'          => [ 'panel' => 'ct_layout',        'title' => __( 'Header Style', 'contempo' ),               'priority' => 20 ],
            'ct_layout_topbar'          => [ 'panel' => 'ct_layout',        'title' => __( 'Top Bar', 'contempo' ),                    'priority' => 30 ],
            'ct_layout_footer'          => [ 'panel' => 'ct_layout',        'title' => __( 'Footer Structure', 'contempo' ),           'priority' => 40 ],
            // Typography
            'ct_typography_main'        => [ 'panel' => 'ct_typography',    'title' => __( 'Fonts & Typography', 'contempo' ),         'priority' => 10 ],
            // Header colors
            'ct_header_bar_colors'      => [ 'panel' => 'ct_header_colors', 'title' => __( 'Top Bar', 'contempo' ),                    'priority' => 10 ],
            'ct_header_main_colors'     => [ 'panel' => 'ct_header_colors', 'title' => __( 'Main Header & User Area', 'contempo' ),    'priority' => 20 ],
            'ct_header_nav_colors'      => [ 'panel' => 'ct_header_colors', 'title' => __( 'Navigation', 'contempo' ),                 'priority' => 30 ],
            'ct_header_style2_colors'   => [ 'panel' => 'ct_header_colors', 'title' => __( 'Header Style 2 Colors', 'contempo' ),      'priority' => 40 ],
            'ct_header_style3_colors'   => [ 'panel' => 'ct_header_colors', 'title' => __( 'Header Style 3 Colors', 'contempo' ),      'priority' => 50 ],
            'ct_header_sticky_colors'   => [ 'panel' => 'ct_header_colors', 'title' => __( 'Sticky & Transparent Header', 'contempo' ),'priority' => 60 ],
            'ct_header_search_colors'   => [ 'panel' => 'ct_header_colors', 'title' => __( 'Header Search Bar', 'contempo' ),          'priority' => 70 ],
            'ct_mobile_nav_colors'      => [ 'panel' => 'ct_header_colors', 'title' => __( 'Mobile Navigation', 'contempo' ),          'priority' => 80 ],
            // Body colors
            'ct_body_bg_section'        => [ 'panel' => 'ct_body_colors',   'title' => __( 'Body Background', 'contempo' ),            'priority' => 10 ],
            'ct_body_text_colors'       => [ 'panel' => 'ct_body_colors',   'title' => __( 'Text & Brand Colors', 'contempo' ),        'priority' => 20 ],
            'ct_form_colors'            => [ 'panel' => 'ct_body_colors',   'title' => __( 'Form Inputs', 'contempo' ),                'priority' => 30 ],
            'ct_links_section'          => [ 'panel' => 'ct_body_colors',   'title' => __( 'Link Colors', 'contempo' ),                'priority' => 40 ],
            'ct_listing_colors'         => [ 'panel' => 'ct_body_colors',   'title' => __( 'Listing Card Colors', 'contempo' ),        'priority' => 50 ],
            'ct_widget_colors'          => [ 'panel' => 'ct_body_colors',   'title' => __( 'Widgets & User Sidebar', 'contempo' ),     'priority' => 60 ],
            // Footer
            'ct_footer_structure'       => [ 'panel' => 'ct_footer',        'title' => __( 'Footer Structure', 'contempo' ),           'priority' => 10 ],
            'ct_footer_colors_section'  => [ 'panel' => 'ct_footer',        'title' => __( 'Footer Colors', 'contempo' ),              'priority' => 20 ],
            // Custom CSS (no panel — appears at bottom of Customizer)
            'ct_custom_css'             => [ 'title' => __( 'Custom CSS', 'contempo' ),                                                'priority' => 200 ],
        ];

        foreach ( $sections as $id => $args ) {
            self::$manager->add_section( $id, $args );
        }
    }

    // -------------------------------------------------------------------------
    // Branding Controls
    // -------------------------------------------------------------------------

    private static function register_branding_controls(): void {
        $s = 'ct_logo_section';
        self::reset_priority();

        self::add_media( 'ct_logo',                $s, __( 'Logo', 'contempo' ) );
        self::add_media( 'ct_logo_highres',        $s, __( 'Logo (Retina 2x)', 'contempo' ) );
        self::add_media( 'ct_logo_trans',          $s, __( 'Logo (Transparent Header)', 'contempo' ) );
        self::add_media( 'ct_logo_sticky',         $s, __( 'Logo (Sticky Header)', 'contempo' ) );

        self::add_switch( 'ct_text_logo',          $s, __( 'Use Text Logo', 'contempo' ), 'postMessage' );
        self::add_slider( 'ct_text_logo_font_size',$s, __( 'Text Logo Font Size (px)', 'contempo' ), 'postMessage',
            [ 'min' => 12, 'max' => 80, 'step' => 1, 'unit' => 'px' ] );

        self::add_switch( 'ct_logo_advanced_sizing', $s, __( 'Enable Advanced Logo Sizing', 'contempo' ), 'postMessage' );
        self::add_slider( 'ct_logo_max_width',     $s, __( 'Logo Max Width (px)', 'contempo' ), 'postMessage',
            [ 'min' => 50, 'max' => 500, 'step' => 1, 'unit' => 'px' ] );
    }

    // -------------------------------------------------------------------------
    // Layout Controls
    // -------------------------------------------------------------------------

    private static function register_layout_controls(): void {
        // General Layout
        self::reset_priority();
        $s = 'ct_layout_general';
        self::add_select( 'ct_boxed', $s, __( 'Layout Width', 'contempo' ), 'postMessage' );
        self::add_select( 'ct_skin',  $s, __( 'Visual Skin', 'contempo' ),  'refresh',
            null, __( 'Switching skins reloads the preview page.', 'contempo' ) );
        self::add_switch( 'ct_rtl',   $s, __( 'Enable RTL Layout', 'contempo' ), 'postMessage' );

        // Header Style
        self::reset_priority();
        $s = 'ct_layout_header';
        self::add_select( 'ct_header_style',       $s, __( 'Header Style', 'contempo' ),          'refresh' );
        self::add_select( 'ct_header_layout',      $s, __( 'Header Layout', 'contempo' ),         'refresh' );
        self::add_switch( 'ct_sticky_header',      $s, __( 'Sticky Header', 'contempo' ),         'postMessage' );
        self::add_select( 'ct_sticky_header_type', $s, __( 'Sticky Header Type', 'contempo' ),    'refresh' );
        self::add_switch( 'ct_trans_header',       $s, __( 'Transparent Header', 'contempo' ),    'postMessage' );

        // Top Bar
        self::reset_priority();
        $s = 'ct_layout_topbar';
        self::add_switch( 'ct_top_bar', $s, __( 'Show Top Bar', 'contempo' ), 'postMessage' );

        // Footer Structure
        self::reset_priority();
        $s = 'ct_footer_structure';
        self::add_switch( 'ct_footer_widget',        $s, __( 'Show Footer Widgets', 'contempo' ), 'postMessage' );
        self::add_select( 'ct_footer_widget_style',  $s, __( 'Footer Widget Style', 'contempo' ), 'refresh' );
        self::add_text(   'ct_footer_text',          $s, __( 'Footer Copyright Text', 'contempo' ), 'postMessage', 'textarea' );
        self::add_switch( 'ct_footer_back_to_top',   $s, __( 'Show Back to Top Button', 'contempo' ), 'postMessage' );
    }

    // -------------------------------------------------------------------------
    // Typography Controls
    // -------------------------------------------------------------------------

    private static function register_typography_controls(): void {
        self::reset_priority();
        $s = 'ct_typography_main';

        // Gate toggle — shown first so users understand why changes may not appear
        self::add_switch( 'ct_use_typostyles', $s, __( 'Enable Advanced Typography Styles', 'contempo' ), 'refresh',
            __( 'Must be enabled for custom typography CSS to output on the front end.', 'contempo' ) );

        // Simple font family selects
        self::add_select( 'ct_heading_font', $s, __( 'Heading Font Family', 'contempo' ), 'postMessage' );
        self::add_select( 'ct_body_font',    $s, __( 'Body Font Family', 'contempo' ),    'postMessage' );

        // Compound typography fields
        self::add_typography( 'ct_body_typography',     $s, __( 'Body Typography', 'contempo' ) );
        self::add_typography( 'ct_heading_typography',  $s, __( 'Heading Typography (H1–H6)', 'contempo' ) );
        self::add_typography( 'ct_heading_one_size',    $s, __( 'H1 Size', 'contempo' ) );
        self::add_typography( 'ct_heading_two_size',    $s, __( 'H2 Size', 'contempo' ) );
        self::add_typography( 'ct_heading_three_size',  $s, __( 'H3 Size', 'contempo' ) );
        self::add_typography( 'ct_heading_four_size',   $s, __( 'H4 Size', 'contempo' ) );
        self::add_typography( 'ct_heading_five_size',   $s, __( 'H5 Size', 'contempo' ) );
        self::add_typography( 'ct_heading_six_size',    $s, __( 'H6 Size', 'contempo' ) );
    }

    // -------------------------------------------------------------------------
    // Header Color Controls
    // -------------------------------------------------------------------------

    private static function register_header_color_controls(): void {
        // Top Bar
        self::reset_priority();
        $s = 'ct_header_bar_colors';
        self::add_rgba( 'ct_header_bar_color',                $s, __( 'Top Bar Background', 'contempo' ) );
        self::add_rgba( 'ct_header_bar_border_color',         $s, __( 'Top Bar Border Color', 'contempo' ) );
        self::add_rgba( 'ct_header_bar_text_color',           $s, __( 'Top Bar Text Color', 'contempo' ) );
        self::add_rgba( 'ct_header_bar_user_bg_color',        $s, __( 'Top Bar User Dropdown Background', 'contempo' ) );
        self::add_rgba( 'ct_header_bar_user_link_color',      $s, __( 'Top Bar User Link Color', 'contempo' ) );
        self::add_rgba( 'ct_header_bar_user_btm_border_color',$s, __( 'Top Bar User Item Border', 'contempo' ) );

        // Main Header & User Area
        self::reset_priority();
        $s = 'ct_header_main_colors';
        self::add_rgba( 'ct_header_background',        $s, __( 'Header Background', 'contempo' ) );
        self::add_rgba( 'ct_text_logo_color',          $s, __( 'Text Logo Color', 'contempo' ) );
        self::add_rgba( 'ct_header_user_trigger_bg',   $s, __( 'User Menu Trigger Background', 'contempo' ) );
        self::add_rgba( 'ct_header_user_name_color',   $s, __( 'User Name Color', 'contempo' ) );
        self::add_rgba( 'ct_header_user_drop_bg',      $s, __( 'User Dropdown Background', 'contempo' ) );
        self::add_rgba( 'ct_header_user_drop_link_color', $s, __( 'User Dropdown Link Color', 'contempo' ) );
        self::add_rgba( 'ct_header_user_drop_icon_color', $s, __( 'User Dropdown Icon Color', 'contempo' ) );
        self::add_rgba( 'ct_header_user_drop_separator',  $s, __( 'User Dropdown Separator Color', 'contempo' ) );

        // Navigation
        self::reset_priority();
        $s = 'ct_header_nav_colors';
        self::add_rgba( 'ct_header_nav_font_color',                 $s, __( 'Nav Link Color', 'contempo' ) );
        self::add_rgba( 'ct_header_nav_hover_color',                $s, __( 'Nav Link Hover Color', 'contempo' ) );
        self::add_rgba( 'ct_header_nav_current_bg',                 $s, __( 'Nav Current Item Accent', 'contempo' ) );
        self::add_rgba( 'ct_header_nav_hover_border_color',         $s, __( 'Nav Hover Border Color', 'contempo' ) );
        self::add_rgba( 'ct_header_nav_btn_outline',                $s, __( 'Nav Button Outline Color', 'contempo' ) );
        self::add_rgba( 'ct_header_sub_nav_font_color',             $s, __( 'Sub-Nav Link Color', 'contempo' ) );
        self::add_rgba( 'ct_header_sub_nav_hover_font_color',       $s, __( 'Sub-Nav Hover Color', 'contempo' ) );
        self::add_rgba( 'ct_header_sub_nav_background_color',       $s, __( 'Sub-Nav Background', 'contempo' ) );
        self::add_rgba( 'ct_header_sub_nav_hover_background_color', $s, __( 'Sub-Nav Hover Background', 'contempo' ) );
        self::add_rgba( 'ct_header_sub_nav_items_border_bottom_color', $s, __( 'Sub-Nav Item Border Color', 'contempo' ) );
        self::add_rgba( 'ct_header_sub_nav_current_background_color',  $s, __( 'Sub-Nav Current Background', 'contempo' ) );
        self::add_rgba( 'ct_header_sub_nav_current_text_color',        $s, __( 'Sub-Nav Current Text Color', 'contempo' ) );
        self::add_rgba( 'ct_header_sub_nav_mega_menu_title_font_color', $s, __( 'Mega Menu Title Color', 'contempo' ) );

        // Header Style 2
        self::reset_priority();
        $s = 'ct_header_style2_colors';
        self::add_rgba( 'ct_header_two_nav_background',       $s, __( 'Full-Width Nav Bar Background', 'contempo' ) );
        self::add_rgba( 'ct_header_two_nav_link_color',       $s, __( 'Full-Width Nav Link Color', 'contempo' ) );
        self::add_rgba( 'ct_header_two_nav_link_hover_color', $s, __( 'Full-Width Nav Link Hover Color', 'contempo' ) );
        self::add_rgba( 'ct_header_two_info_bg',              $s, __( 'Info Block Background', 'contempo' ) );
        self::add_rgba( 'ct_header_two_info_border',          $s, __( 'Info Block Border Color', 'contempo' ) );
        self::add_rgba( 'ct_header_two_info_icon_color',      $s, __( 'Info Block Icon Color', 'contempo' ) );
        self::add_rgba( 'ct_header_two_info_title_color',     $s, __( 'Info Block Title Color', 'contempo' ) );
        self::add_rgba( 'ct_header_two_info_text_color',      $s, __( 'Info Block Subtext Color', 'contempo' ) );

        // Header Style 3
        self::reset_priority();
        $s = 'ct_header_style3_colors';
        self::add_rgba( 'ct_header_three_login_border_color', $s, __( 'Login Button Border Color', 'contempo' ) );
        self::add_rgba( 'ct_header_three_user_text_color',    $s, __( 'Logged-In User Text Color', 'contempo' ) );

        // Sticky & Transparent
        self::reset_priority();
        $s = 'ct_header_sticky_colors';
        self::add_rgba( 'ct_header_sticky_background',       $s, __( 'Sticky Header Background', 'contempo' ) );
        self::add_rgba( 'ct_header_sticky_nav_font_color',   $s, __( 'Sticky Header Nav Color', 'contempo' ) );
        self::add_rgba( 'ct_header_trans_home_nav_font_color',$s, __( 'Transparent Header Nav Color', 'contempo' ) );
        self::add_rgba( 'ct_header_trans_user_name_color',   $s, __( 'Transparent Header User Name Color', 'contempo' ) );

        // Search Bar
        self::reset_priority();
        $s = 'ct_header_search_colors';
        self::add_rgba( 'ct_header_search_bar_bg',         $s, __( 'Search Bar Background', 'contempo' ) );
        self::add_rgba( 'ct_header_search_suggestion_bg',  $s, __( 'Search Suggestion Box Background', 'contempo' ) );

        // Mobile Navigation
        self::reset_priority();
        $s = 'ct_mobile_nav_colors';
        self::add_rgba( 'ct_mobile_btn_bg_color',                  $s, __( 'Mobile Menu Button Background', 'contempo' ) );
        self::add_rgba( 'ct_mobile_btn_icon_color',                $s, __( 'Mobile Menu Button Icon Color', 'contempo' ) );
        self::add_rgba( 'ct_mobile_menu_bg_color',                 $s, __( 'Mobile Menu Background', 'contempo' ) );
        self::add_rgba( 'ct_mobile_menu_link_color',               $s, __( 'Mobile Menu Link Color', 'contempo' ) );
        self::add_rgba( 'ct_mobile_menu_link_border_bottom_color', $s, __( 'Mobile Menu Link Border Color', 'contempo' ) );
        self::add_rgba( 'ct_mobile_menu_link_hover_color',         $s, __( 'Mobile Menu Link Hover Color', 'contempo' ) );
        self::add_rgba( 'ct_mobile_menu_link_hover_bg_color',      $s, __( 'Mobile Menu Link Hover Background', 'contempo' ) );
        self::add_rgba( 'ct_mobile_menu_sub_arrow_color',          $s, __( 'Mobile Submenu Arrow Color', 'contempo' ) );
    }

    // -------------------------------------------------------------------------
    // Body Color Controls
    // -------------------------------------------------------------------------

    private static function register_body_color_controls(): void {
        // Body Background
        self::reset_priority();
        $s = 'ct_body_bg_section';
        self::add_background( 'ct_background', $s, __( 'Body Background', 'contempo' ) );

        // Text & Brand
        self::reset_priority();
        $s = 'ct_body_text_colors';
        self::add_rgba( 'ct_body_text_color',        $s, __( 'Body Text Color', 'contempo' ) );
        self::add_rgba( 'ct_secondary_bg_color',     $s, __( 'Brand Accent Background', 'contempo' ) );
        self::add_rgba( 'ct_secondary_text_color',   $s, __( 'Brand Accent Text Color', 'contempo' ) );
        self::add_rgba( 'ct_dark_overlay_background',$s, __( 'Dark Overlay Background', 'contempo' ) );

        // Form Inputs
        self::reset_priority();
        $s = 'ct_form_colors';
        self::add_rgba( 'ct_input_background_color', $s, __( 'Input Background Color', 'contempo' ) );
        self::add_rgba( 'ct_input_border_color',     $s, __( 'Input Border Color', 'contempo' ) );

        // Links
        self::reset_priority();
        $s = 'ct_links_section';
        self::add_rgba( 'ct_link_color',    $s, __( 'Link Color', 'contempo' ) );
        self::add_rgba( 'ct_visited_color', $s, __( 'Visited Link Color', 'contempo' ) );
        self::add_rgba( 'ct_hover_color',   $s, __( 'Link Hover Color', 'contempo' ) );
        self::add_rgba( 'ct_active_color',  $s, __( 'Link Active Color', 'contempo' ) );

        // Listing Cards
        self::reset_priority();
        $s = 'ct_listing_colors';
        self::add_rgba( 'ct_listing_font_color',       $s, __( 'Listing Card Text Color', 'contempo' ) );
        self::add_rgba( 'ct_listing_background_color', $s, __( 'Listing Card Background', 'contempo' ) );
        self::add_rgba( 'ct_listing_border_bottom_color', $s, __( 'Listing Detail Row Border', 'contempo' ) );
        self::add_rgba( 'ct_listing_heading_font_color',  $s, __( 'Listing Single Heading Color', 'contempo' ) );
        self::add_rgba( 'ct_price_bg',                 $s, __( 'Price Background', 'contempo' ) );
        self::add_rgba( 'ct_price_text_color',         $s, __( 'Price Text Color', 'contempo' ) );
        self::add_rgba( 'ct_listing_view_btn_bg',      $s, __( 'View Listing Button Background', 'contempo' ) );
        self::add_rgba( 'ct_listing_view_btn_text',    $s, __( 'View Listing Button Text Color', 'contempo' ) );
        self::add_rgba( 'ct_status_snipe_color',       $s, __( 'Status Snipe Pill Color', 'contempo' ) );
        self::add_rgba( 'ct_status_featured_color',    $s, __( 'Featured Snipe Pill Color', 'contempo' ) );
        self::add_rgba( 'ct_map_toggle',               $s, __( 'Map Toggle Button Color', 'contempo' ) );
        self::add_rgba( 'ct_featured_view_all',        $s, __( 'Featured View All Button', 'contempo' ) );
        self::add_rgba( 'ct_filter_pill_bg',           $s, __( 'Filter Pill Background', 'contempo' ) );
        self::add_rgba( 'ct_filter_pill_text',         $s, __( 'Filter Pill Text Color', 'contempo' ) );
        self::add_rgba( 'ct_filter_pill_remove_color', $s, __( 'Filter Pill Dismiss Icon Color', 'contempo' ) );

        // Widgets & User Sidebar
        self::reset_priority();
        $s = 'ct_widget_colors';
        self::add_rgba( 'ct_widget_header_bg_color',               $s, __( 'Widget Heading Background', 'contempo' ) );
        self::add_rgba( 'ct_user_sidebar_bg',                      $s, __( 'User Sidebar Background', 'contempo' ) );
        self::add_rgba( 'ct_user_sidebar_link_bg',                 $s, __( 'User Sidebar Link Background', 'contempo' ) );
        self::add_rgba( 'ct_user_sidebar_link_color',              $s, __( 'User Sidebar Link Color', 'contempo' ) );
        self::add_rgba( 'ct_user_sidebar_current_bg',              $s, __( 'User Sidebar Current Background', 'contempo' ) );
        self::add_rgba( 'ct_user_sidebar_current_color',           $s, __( 'User Sidebar Current Color', 'contempo' ) );
        self::add_rgba( 'ct_user_sidebar_icon_color',              $s, __( 'User Sidebar Icon Color', 'contempo' ) );
        self::add_rgba( 'ct_user_sidebar_menu_item_border_bottom_color', $s, __( 'User Sidebar Item Border', 'contempo' ) );
        self::add_rgba( 'ct_map_toggle_text_color',                $s, __( 'Map Toggle Text Color', 'contempo' ) );
    }

    // -------------------------------------------------------------------------
    // Footer Controls
    // -------------------------------------------------------------------------

    private static function register_footer_controls(): void {
        // Colors
        self::reset_priority();
        $s = 'ct_footer_colors_section';
        self::add_rgba( 'ct_footer_background',            $s, __( 'Footer Background', 'contempo' ) );
        self::add_rgba( 'ct_footer_border_top_color',      $s, __( 'Footer Top Border Color', 'contempo' ) );
        self::add_rgba( 'ct_footer_link_color',            $s, __( 'Footer Link Color', 'contempo' ) );
        self::add_rgba( 'ct_footer_widget_background',     $s, __( 'Footer Widget Area Background', 'contempo' ) );
        self::add_rgba( 'ct_footer_widget_heading_color',  $s, __( 'Footer Widget Heading Color', 'contempo' ) );
        self::add_rgba( 'ct_footer_widget_font_color',     $s, __( 'Footer Widget Text Color', 'contempo' ) );
        self::add_rgba( 'ct_footer_widget_link_hover_color', $s, __( 'Footer Widget Link Hover Color', 'contempo' ) );
        self::add_rgba( 'ct_footer_widget_border_color',   $s, __( 'Footer Widget Item Border Color', 'contempo' ) );
        self::add_media( 'ct_footer_background_img',       $s, __( 'Footer Background Image', 'contempo' ), 'postMessage' );
    }

    // -------------------------------------------------------------------------
    // Custom CSS
    // -------------------------------------------------------------------------

    private static function register_custom_css_control(): void {
        $opt_key = self::$opt_name . '[ct_custom_css]';

        self::$manager->add_setting( $opt_key, [
            'type'               => 'option',
            'capability'         => 'manage_options',
            'default'            => self::$defaults['ct_custom_css'] ?? '',
            'transport'          => 'postMessage',
            'sanitize_callback'  => [ 'CT_Settings_Sanitize', 'field' ],
        ] );

        self::$manager->add_control(
            new WP_Customize_Code_Editor_Control(
                self::$manager,
                'ct_ctrl_ct_custom_css',
                [
                    'label'       => __( 'Custom CSS', 'contempo' ),
                    'description' => __( 'Add custom CSS rules. Applied after all theme styles.', 'contempo' ),
                    'section'     => 'ct_custom_css',
                    'settings'    => $opt_key,
                    'code_type'   => 'text/css',
                    'priority'    => 10,
                ]
            )
        );
    }

    // -------------------------------------------------------------------------
    // Script Enqueue
    // -------------------------------------------------------------------------

    /**
     * Enqueue the live preview script inside the Customizer preview iframe.
     */
    public static function enqueue_preview_scripts(): void {
        $base = get_template_directory_uri() . '/admin/ct-settings/assets/';

        wp_enqueue_script(
            'ct-customizer-preview',
            $base . 'ct-customizer-preview.js',
            [ 'customize-preview', 'jquery' ],
            REALESTATE7_SL_THEME_VERSION,
            true
        );

        // Build output-array map for fields that declare `output` keys
        $output_maps = [];
        foreach ( self::$all_fields as $id => $field ) {
            if ( ! empty( $field['output'] ) ) {
                $output_maps[ $id ] = [
                    'type'   => $field['type'] ?? 'text',
                    'mode'   => $field['mode'] ?? 'color',
                    'output' => $field['output'],
                ];
            }
        }

        wp_localize_script( 'ct-customizer-preview', 'ctCustomizerPreview', [
            'optName'    => self::$opt_name,
            'outputMaps' => $output_maps,
        ] );
    }

    /**
     * Enqueue scripts and styles for the Customizer controls panel.
     */
    public static function enqueue_control_scripts(): void {
        $base = get_template_directory_uri() . '/admin/ct-settings/assets/';

        // Color picker dependencies (WP Iris)
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );

        wp_enqueue_script(
            'ct-customizer-controls',
            $base . 'ct-customizer-controls.js',
            [ 'customize-controls', 'jquery', 'wp-color-picker' ],
            REALESTATE7_SL_THEME_VERSION,
            true
        );

        // Inline styles for custom controls
        wp_add_inline_style( 'customize-controls', self::get_control_styles() );
    }

    // -------------------------------------------------------------------------
    // Helper: Add Setting + Control Pairs
    // -------------------------------------------------------------------------

    private static function add_setting( string $id, array $args ): void {
        self::$manager->add_setting( self::$opt_name . '[' . $id . ']', array_merge( [
            'type'       => 'option',
            'capability' => 'manage_options',
            'default'    => self::$defaults[ $id ] ?? null,
            'transport'  => 'refresh',
        ], $args ) );
    }

    private static function add_rgba( string $id, string $section, string $label, string $desc = '' ): void {
        self::add_setting( $id, [
            'transport'         => 'postMessage',
            'sanitize_callback' => [ 'CT_Settings_Sanitize', 'color_rgba' ],
        ] );

        self::$manager->add_control( new CT_Customize_Color_Rgba_Control(
            self::$manager,
            'ct_ctrl_' . $id,
            [
                'settings'    => self::$opt_name . '[' . $id . ']',
                'section'     => $section,
                'label'       => $label,
                'description' => $desc,
                'priority'    => self::next_priority(),
            ]
        ) );
    }

    private static function add_typography( string $id, string $section, string $label, string $desc = '' ): void {
        self::add_setting( $id, [
            'transport'         => 'postMessage',
            'sanitize_callback' => [ 'CT_Settings_Sanitize', 'typography' ],
        ] );

        self::$manager->add_control( new CT_Customize_Typography_Control(
            self::$manager,
            'ct_ctrl_' . $id,
            [
                'settings'    => self::$opt_name . '[' . $id . ']',
                'section'     => $section,
                'label'       => $label,
                'description' => $desc,
                'priority'    => self::next_priority(),
            ]
        ) );
    }

    private static function add_media( string $id, string $section, string $label, string $transport = 'postMessage' ): void {
        self::add_setting( $id, [
            'transport'         => $transport,
            'sanitize_callback' => [ 'CT_Settings_Sanitize', 'media' ],
        ] );

        self::$manager->add_control( new CT_Customize_Media_Control(
            self::$manager,
            'ct_ctrl_' . $id,
            [
                'settings'  => self::$opt_name . '[' . $id . ']',
                'section'   => $section,
                'label'     => $label,
                'priority'  => self::next_priority(),
                'allowed'   => 'image',
            ]
        ) );
    }

    private static function add_background( string $id, string $section, string $label, string $transport = 'postMessage' ): void {
        self::add_setting( $id, [
            'transport'         => $transport,
            'sanitize_callback' => [ 'CT_Settings_Sanitize', 'background' ],
        ] );

        self::$manager->add_control( new CT_Customize_Background_Control(
            self::$manager,
            'ct_ctrl_' . $id,
            [
                'settings' => self::$opt_name . '[' . $id . ']',
                'section'  => $section,
                'label'    => $label,
                'priority' => self::next_priority(),
            ]
        ) );
    }

    private static function add_switch( string $id, string $section, string $label, string $transport = 'refresh', string $desc = '' ): void {
        self::add_setting( $id, [
            'transport'         => $transport,
            'sanitize_callback' => [ 'CT_Settings_Sanitize', 'toggle' ],
        ] );

        self::$manager->add_control( new CT_Customize_Switch_Control(
            self::$manager,
            'ct_ctrl_' . $id,
            [
                'settings'    => self::$opt_name . '[' . $id . ']',
                'section'     => $section,
                'label'       => $label,
                'description' => $desc,
                'priority'    => self::next_priority(),
            ]
        ) );
    }

    private static function add_select( string $id, string $section, string $label, string $transport = 'refresh', ?array $choices = null, string $desc = '' ): void {
        // Pull choices from registered field definition if not provided
        if ( $choices === null ) {
            $choices = self::$all_fields[ $id ]['options'] ?? [];
        }

        self::add_setting( $id, [
            'transport'         => $transport,
            'sanitize_callback' => 'sanitize_text_field',
        ] );

        self::$manager->add_control(
            'ct_ctrl_' . $id,
            [
                'type'        => 'select',
                'settings'    => self::$opt_name . '[' . $id . ']',
                'section'     => $section,
                'label'       => $label,
                'description' => $desc,
                'choices'     => $choices,
                'priority'    => self::next_priority(),
            ]
        );
    }

    private static function add_text( string $id, string $section, string $label, string $transport = 'refresh', string $type = 'text', string $desc = '' ): void {
        self::add_setting( $id, [
            'transport'         => $transport,
            'sanitize_callback' => $type === 'textarea' ? 'sanitize_textarea_field' : 'sanitize_text_field',
        ] );

        self::$manager->add_control(
            'ct_ctrl_' . $id,
            [
                'type'        => $type,
                'settings'    => self::$opt_name . '[' . $id . ']',
                'section'     => $section,
                'label'       => $label,
                'description' => $desc,
                'priority'    => self::next_priority(),
            ]
        );
    }

    private static function add_slider( string $id, string $section, string $label, string $transport = 'postMessage', array $slider_args = [] ): void {
        $field_def = self::$all_fields[ $id ] ?? [];

        self::add_setting( $id, [
            'transport'         => $transport,
            'sanitize_callback' => 'absint',
        ] );

        self::$manager->add_control( new CT_Customize_Slider_Control(
            self::$manager,
            'ct_ctrl_' . $id,
            array_merge(
                [
                    'settings' => self::$opt_name . '[' . $id . ']',
                    'section'  => $section,
                    'label'    => $label,
                    'priority' => self::next_priority(),
                    'min'      => (int) ( $field_def['min'] ?? 0 ),
                    'max'      => (int) ( $field_def['max'] ?? 100 ),
                    'step'     => (int) ( $field_def['step'] ?? 1 ),
                ],
                $slider_args
            )
        ) );
    }

    // -------------------------------------------------------------------------
    // Priority Counter
    // -------------------------------------------------------------------------

    private static function reset_priority( int $start = 10 ): void {
        self::$priority = $start;
    }

    private static function next_priority(): int {
        $p = self::$priority;
        self::$priority += 10;
        return $p;
    }

    // -------------------------------------------------------------------------
    // Inline Control Styles
    // -------------------------------------------------------------------------

    private static function get_control_styles(): string {
        return '
/* CT Customizer — Color RGBA Control */
.ct-rgba-wrap { position:relative; }
.ct-rgba-picker-wrap { display:flex; align-items:center; gap:8px; }
.ct-rgba-swatch {
    display:inline-flex; align-items:center; gap:6px;
    padding:5px 10px; border-radius:4px; cursor:pointer;
    border:1px solid #ddd; min-width:90px; font-size:12px;
    background:#f0f0f1;
}
.ct-rgba-swatch--empty { background:#f0f0f1 !important; color:#888 !important; }
.ct-rgba-picker-popout {
    position:absolute; top:100%; left:0; z-index:9999;
    background:#fff; border:1px solid #ddd; border-radius:4px;
    padding:12px; box-shadow:0 4px 12px rgba(0,0,0,.15); min-width:220px;
}
.ct-rgba-alpha-wrap { display:flex; align-items:center; gap:8px; margin-top:8px; }
.ct-rgba-alpha-wrap label { font-size:11px; color:#666; min-width:50px; }
.ct-rgba-alpha-slider { flex:1; }
.ct-rgba-alpha-number { width:55px; }

/* CT Customizer — Typography Control */
.ct-typography-wrap { border:1px solid #ddd; border-radius:4px; overflow:hidden; }
.ct-typography-preview {
    padding:10px 12px; background:#f9f9f9;
    border-bottom:1px solid #ddd; font-size:14px; line-height:1.5;
}
.ct-typography-controls { padding:8px; }
.ct-typography-row { display:flex; align-items:center; gap:8px; padding:4px 0; }
.ct-typography-row label { min-width:90px; font-size:11px; color:#666; }
.ct-typography-row input, .ct-typography-row select { flex:1; }
.ct-typo-google-label { display:flex; align-items:center; gap:4px; font-size:11px; }

/* CT Customizer — Slider Control */
.ct-slider-wrap { display:flex; align-items:center; gap:8px; flex-wrap:nowrap; }
.ct-slider-range { flex:1 1 auto; min-width:0; }
.ct-slider-number { width:60px !important; min-width:60px !important; flex:0 0 60px !important; box-sizing:border-box; }
.ct-slider-unit { font-size:11px; color:#666; flex-shrink:0; white-space:nowrap; }

/* CT Customizer — Switch / Toggle */
.ct-switch-wrap .customize-control-title { display:block; }
.ct-toggle-label { display:inline-flex; align-items:center; gap:8px; cursor:pointer; }
.ct-toggle-checkbox { display:none; }
.ct-toggle-slider {
    position:relative; width:36px; height:20px;
    background:#ccc; border-radius:10px; transition:background .2s;
}
.ct-toggle-slider:before {
    content:""; position:absolute;
    width:16px; height:16px; border-radius:50%;
    background:#fff; top:2px; left:2px; transition:transform .2s;
    box-shadow:0 1px 3px rgba(0,0,0,.2);
}
.ct-toggle-checkbox:checked + .ct-toggle-slider { background:#007cba; }
.ct-toggle-checkbox:checked + .ct-toggle-slider:before { transform:translateX(16px); }
.ct-toggle-status { font-size:12px; color:#666; }

/* CT Customizer — Image Select */
.ct-image-select-wrap { display:flex; flex-wrap:wrap; gap:8px; }
.ct-image-select-option {
    display:flex; flex-direction:column; align-items:center;
    gap:4px; cursor:pointer; padding:6px;
    border:2px solid transparent; border-radius:4px; font-size:11px;
}
.ct-image-select-option.selected,
.ct-image-select-option:has(input:checked) { border-color:#007cba; }
.ct-image-select-option img { max-width:80px; border-radius:3px; }
.ct-image-select-radio { display:none; }

/* CT Customizer — Media Control */
.ct-media-wrap .ct-media-preview img { max-width:100%; border-radius:4px; margin-bottom:8px; }
.ct-media-actions { display:flex; gap:6px; }

/* CT Customizer — Background Control */
.ct-bg-wrap { border:1px solid #ddd; border-radius:4px; padding:8px; }
.ct-bg-row { display:flex; align-items:center; gap:8px; padding:4px 0; }
.ct-bg-row label { min-width:100px; font-size:11px; color:#666; }
.ct-bg-row select { flex:1; }
';
    }
}
