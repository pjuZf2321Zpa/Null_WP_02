<?php
/**
 * CT Settings — Shared Sanitization Utilities
 *
 * Extracted from CT_Settings_Save so the Customizer integration
 * (CT_Customizer) can use the same sanitizers as WP_Customize_Setting
 * callbacks without depending on the admin-only save class.
 *
 * All methods are public static so they can be passed as callbacks:
 *   [ 'CT_Settings_Sanitize', 'color_rgba' ]
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class CT_Settings_Sanitize {

    // -------------------------------------------------------------------------
    // Dispatch
    // -------------------------------------------------------------------------

    /**
     * Sanitize a value by field type.
     * Mirrors the logic formerly private in CT_Settings_Save::sanitize_field().
     *
     * @param string $type  Field type string (e.g. 'color_rgba', 'switch').
     * @param array  $field Full field definition array (used for context where needed).
     * @param mixed  $value Raw value from POST or Customizer.
     * @return mixed        Sanitized value ready to store.
     */
    public static function field( string $type, array $field, mixed $value ): mixed {
        return match ( $type ) {
            'compare_fields' => CT_RE7_Listing_Modules::sanitize_compare_data( is_string( $value ) ? json_decode( $value, true ) : $value ),
            'text'         => isset( $field['allowed_html'] ) ? wp_kses( CT_Settings::normalize_code( (string) $value ), $field['allowed_html'] ) : sanitize_text_field( CT_Settings::normalize_code( (string) $value ) ),
            'textarea'     => isset( $field['allowed_html'] ) ? wp_kses( CT_Settings::normalize_code( (string) $value ), $field['allowed_html'] ) : sanitize_textarea_field( CT_Settings::normalize_code( (string) $value ) ),
            'ace_editor'   => CT_Settings::normalize_code( (string) $value ),
            'switch'       => self::toggle( $value ),
            'select',
            'image_select' => sanitize_text_field( CT_Settings::normalize_code( (string) $value ) ),
            'slider'       => (int) $value,
            'color_rgba'   => self::color_rgba( $value ),
            'typography'   => self::typography( $value ),
            'background'   => self::background( $value ),
            'sorter'       => self::sorter( $value ),
            'media'        => self::media( $value ),
            'import_export'=> [],
            'page_picker'  => self::page_picker( $value ),
            default        => sanitize_text_field( CT_Settings::normalize_code( (string) $value ) ),
        };
    }

    // -------------------------------------------------------------------------
    // Per-type sanitizers (public — usable as WP_Customize_Setting callbacks)
    // -------------------------------------------------------------------------

    /**
     * Sanitize a switch/toggle value → 'yes' | 'no'.
     */
    public static function toggle( mixed $value ): string {
        return in_array( $value, [ 'yes', 'true', '1', 1, true, 'on' ], true ) ? 'yes' : 'no';
    }

    /**
     * Sanitize a color_rgba compound value.
     * Accepts:
     *   - array  ['color' => '#hex', 'alpha' => 0.8, 'rgba' => '...']  (normal save)
     *   - string plain hex ('#rrggbb') — legacy migration
     *   - string JSON-encoded object (from Customizer POST transport)
     *
     * @return array ['color' => string, 'alpha' => float, 'rgba' => string]
     */
    public static function color_rgba( mixed $value ): array {
        // Decode JSON string from Customizer transport
        if ( is_string( $value ) && str_starts_with( trim( $value ), '{' ) ) {
            $decoded = json_decode( $value, true );
            if ( is_array( $decoded ) ) {
                $value = $decoded;
            }
        }

        // Promote legacy plain hex string
        if ( is_string( $value ) && $value !== '' ) {
            $hex   = sanitize_hex_color( $value ) ?? '';
            $value = [ 'color' => $hex, 'alpha' => 1.0, 'rgba' => '' ];
        }

        if ( ! is_array( $value ) ) {
            return [ 'color' => '', 'alpha' => 1, 'rgba' => '' ];
        }

        $color = sanitize_hex_color( $value['color'] ?? '' ) ?? '';
        $alpha = (float) ( $value['alpha'] ?? 1 );
        $alpha = max( 0.0, min( 1.0, $alpha ) );

        $rgba = '';
        if ( $color ) {
            [ $r, $g, $b ] = sscanf( $color, '#%02x%02x%02x' );
            $rgba = "rgba({$r},{$g},{$b},{$alpha})";
        }

        return [ 'color' => $color, 'alpha' => $alpha, 'rgba' => $rgba ];
    }

    /**
     * Sanitize a typography compound value.
     * Accepts array or JSON-encoded string (Customizer transport).
     *
     * @return array
     */
    public static function typography( mixed $value ): array {
        // Decode JSON string from Customizer transport
        if ( is_string( $value ) && str_starts_with( trim( $value ), '{' ) ) {
            $decoded = json_decode( $value, true );
            if ( is_array( $decoded ) ) {
                $value = $decoded;
            }
        }

        if ( ! is_array( $value ) ) return [];

        $allowed_keys = [
            'font-family', 'font-size', 'font-weight', 'font-style',
            'line-height', 'letter-spacing', 'text-align', 'color',
            'text-transform', 'text-decoration',
            'google', 'subsets', 'font-backup', 'font-options',
            'shadow-color', 'shadow-horizontal', 'shadow-vertical', 'shadow-blur',
        ];

        $sanitized = [];
        foreach ( $allowed_keys as $key ) {
            if ( ! array_key_exists( $key, $value ) ) continue;
            $v = $value[ $key ];
            if ( $key === 'google' ) {
                $sanitized[ $key ] = (bool) $v;
            } elseif ( $key === 'color' ) {
                $sanitized[ $key ] = sanitize_hex_color( (string) $v ) ?? '';
            } else {
                $sanitized[ $key ] = sanitize_text_field( CT_Settings::normalize_code( (string) $v ) );
            }
        }

        return $sanitized;
    }

    /**
     * Sanitize a background compound value.
     * Accepts array or JSON-encoded string (Customizer transport).
     *
     * @return array
     */
    public static function background( mixed $value ): array {
        // Decode JSON string from Customizer transport
        if ( is_string( $value ) && str_starts_with( trim( $value ), '{' ) ) {
            $decoded = json_decode( $value, true );
            if ( is_array( $decoded ) ) {
                $value = $decoded;
            }
        }

        if ( ! is_array( $value ) ) return [];

        $text_keys = [
            'background-color', 'background-repeat', 'background-attachment',
            'background-position', 'background-clip', 'background-origin', 'background-size',
        ];
        $sanitized = [];

        foreach ( $text_keys as $k ) {
            if ( array_key_exists( $k, $value ) ) {
                $sanitized[ $k ] = sanitize_text_field( CT_Settings::normalize_code( (string) $value[ $k ] ) );
            }
        }

        if ( isset( $value['background-image'] ) ) {
            $sanitized['background-image'] = esc_url_raw( (string) $value['background-image'] );
        }

        if ( isset( $value['media'] ) && is_array( $value['media'] ) ) {
            $sanitized['media'] = [
                'id'        => (int) ( $value['media']['id'] ?? 0 ),
                'width'     => (int) ( $value['media']['width'] ?? 0 ),
                'height'    => (int) ( $value['media']['height'] ?? 0 ),
                'thumbnail' => esc_url_raw( (string) ( $value['media']['thumbnail'] ?? '' ) ),
            ];
        }

        return $sanitized;
    }

    /**
     * Sanitize a sorter compound value.
     *
     * @return array
     */
    public static function sorter( mixed $value ): array {
        if ( ! is_array( $value ) ) {
            return [ 'enabled' => [ 'placebo' => 'placebo' ], 'disabled' => [ 'placebo' => 'placebo' ] ];
        }

        $sanitized = [];
        foreach ( [ 'enabled', 'disabled' ] as $bucket ) {
            $items = $value[ $bucket ] ?? [];
            $out   = [ 'placebo' => 'placebo' ];
            if ( is_array( $items ) ) {
                foreach ( $items as $k => $v ) {
                    if ( $k === 'placebo' ) continue;
                    $out[ sanitize_key( $k ) ] = sanitize_text_field( CT_Settings::normalize_code( (string) $v ) );
                }
            }
            $sanitized[ $bucket ] = $out;
        }

        return $sanitized;
    }

    /**
     * Sanitize a media compound value.
     * Accepts array or JSON-encoded string (Customizer transport).
     *
     * @return array
     */
    public static function media( mixed $value ): array {
        // Decode JSON string from Customizer transport
        if ( is_string( $value ) && str_starts_with( trim( $value ), '{' ) ) {
            $decoded = json_decode( $value, true );
            if ( is_array( $decoded ) ) {
                $value = $decoded;
            }
        }

        if ( ! is_array( $value ) ) {
            return [ 'url' => '', 'id' => 0, 'width' => '', 'height' => '', 'thumbnail' => '' ];
        }

        return [
            'url'       => esc_url_raw( $value['url'] ?? '' ),
            'id'        => (int) ( $value['id'] ?? 0 ),
            'width'     => sanitize_text_field( CT_Settings::normalize_code( (string) ( $value['width'] ?? '' ) ) ),
            'height'    => sanitize_text_field( CT_Settings::normalize_code( (string) ( $value['height'] ?? '' ) ) ),
            'thumbnail' => esc_url_raw( $value['thumbnail'] ?? '' ),
        ];
    }

    /**
     * Sanitize a page_picker compound value.
     * Accepts JSON string or PHP array of page IDs; returns a clean array of ints.
     *
     * @return int[]
     */
    public static function page_picker( mixed $value ): array {
        if ( is_string( $value ) && trim( $value ) !== '' ) {
            $decoded = json_decode( $value, true );
            $value   = is_array( $decoded ) ? $decoded : [];
        }

        if ( ! is_array( $value ) ) {
            return [];
        }

        $ids = array_map( 'absint', $value );
        $ids = array_values( array_unique( array_filter( $ids ) ) );

        return $ids;
    }

    /**
     * Sanitize an unknown / unregistered value.
     */
    public static function unknown( mixed $value ): mixed {
        if ( is_array( $value ) ) {
            $out = [];
            foreach ( $value as $k => $v ) {
                $out[ sanitize_key( (string) $k ) ] = self::unknown( $v );
            }
            return $out;
        }
        if ( is_string( $value ) ) {
            return sanitize_text_field( CT_Settings::normalize_code( $value ) );
        }
        return $value;
    }

    /**
     * Validate a field value and return an error string, or null on pass.
     */
    public static function validate( array $field, mixed $value ): ?string {
        $rule = $field['validate'] ?? '';

        if ( $rule === 'email' ) {
            $check = is_string( $value ) ? CT_Settings::normalize_code( $value ) : $value;
            if ( ! empty( $check ) && ! is_email( $check ) ) {
                return $field['msg'] ?? __( 'Please enter a valid email address.', 'contempo' );
            }
        }

        return null;
    }
}
