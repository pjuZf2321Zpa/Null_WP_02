<?php

/**
 * CT Plugin Manager Registration
 *
 * Registers required and optional plugins for Real Estate 7.
 *
 * @package WP Pro Real Estate 7
 * @version 2.6.1-ct
 */

add_action( 'ct_plugins_register', 'ct_register_required_plugins' );

if ( ! function_exists( 'ct_register_required_plugins' ) ) {
	function ct_register_required_plugins() {
		$updater             = CT_Theme_Updater_Admin::getInstance();
		$item_id             = $updater->get_license_item_id();
		$exclusives_available = in_array( $item_id, [ 9797, 2867 ] );
		$license_key         = trim( get_option( 'realestate-7_license_key', '' ) );

		if ( $exclusives_available ) {

		$plugins = array(

			array(
				'name'               => __( 'CT Real Estate Core', 'contempo' ),
				'slug'               => 'ct-real-estate-core',
				'description'        => __( 'Core functionality required by the RE7 theme — listing post types, shortcodes, and theme integrations.', 'contempo' ),
				'source'             => 'https://contempothemes.com/?edd_action=download&item_id=182173',
				'required'           => true,
				'version'            => '3.8.1',
				'force_activation'   => false,
				'force_deactivation' => false,
				'external_url'       => '',
			),

			array(
				'name'        => __( 'Elementor Page Builder', 'contempo' ),
				'slug'        => 'elementor',
				'description' => __( 'Drag-and-drop page builder used to build RE7 demo layouts and custom pages.', 'contempo' ),
				'required'    => true,
			),

			array(
				'name'        => __( 'Nextend Social Login', 'contempo' ),
				'slug'        => 'nextend-facebook-connect',
				'description' => __( 'Let visitors register and log in using Google, Facebook, or Apple accounts.', 'contempo' ),
				'required'    => false,
			),

		array(
			'name'               => __( 'CT Leads Pro', 'contempo' ),
				'slug'               => 'ct-leads-pro',
				'description'        => __( 'AI-powered real estate CRM — manage leads, automate follow-ups, and track conversations.', 'contempo' ),
				'source'             => add_query_arg(
					[
						'edd_action' => 'download',
						'item_id'    => '6726',
						'license'    => $license_key,
					],
					'https://contempothemes.com/'
				),
				'required'           => false,
				'force_activation'   => false,
				'force_deactivation' => false,
				'version'            => '2.2.9',
				'external_url'       => '',
			),





			array(
				'name'               => __( 'CT SMS Alerts', 'contempo' ),
				'slug'               => 'ct-sms-alerts',
				'description'        => __( 'Get instant SMS notifications for new leads and inquiries via Twilio.', 'contempo' ),
				'source'             => add_query_arg(
					[
						'edd_action' => 'download',
						'item_id'    => '185931',
						'license'    => $license_key,
					],
					'https://contempothemes.com/'
				),
				'required'           => false,
				'version'            => '1.0.4',
				'force_activation'   => false,
				'force_deactivation' => false,
				'external_url'       => '',
			),

		);

	} else {

		$plugins = array(

			array(
				'name'               => __( 'CT Real Estate Core', 'contempo' ),
				'slug'               => 'ct-real-estate-core',
				'description'        => __( 'Core functionality required by the RE7 theme — listing post types, shortcodes, and theme integrations.', 'contempo' ),
				'source'             => 'https://contempothemes.com/?edd_action=download&item_id=182173',
				'required'           => true,
				'version'            => '3.8.1',
				'force_activation'   => false,
				'force_deactivation' => false,
				'external_url'       => '',
			),

			array(
				'name'        => __( 'Elementor Page Builder', 'contempo' ),
				'slug'        => 'elementor',
				'description' => __( 'Drag-and-drop page builder used to build RE7 demo layouts and custom pages.', 'contempo' ),
				'required'    => true,
			),

			array(
				'name'        => __( 'Nextend Social Login', 'contempo' ),
				'slug'        => 'nextend-facebook-connect',
				'description' => __( 'Let visitors register and log in using Google, Facebook, or Apple accounts.', 'contempo' ),
				'required'    => false,
			),




		);

		}

		/*-----------------------------------------------------------------------------------*/
		/* Configuration settings                                                            */
		/*-----------------------------------------------------------------------------------*/

		$config = array(
			'id'           => 'realestate-7',
			'default_path' => '',
			'menu'         => 'ct-install-plugins',
			'has_notices'  => false,
			'dismissable'  => true,
			'dismiss_msg'  => '',
			'is_automatic' => false,
			'message'      => '',
		);

		ct_plugins( $plugins, $config );
	}
}
