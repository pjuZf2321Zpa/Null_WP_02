<?php

/**
 * CT RE7 Plugin Manager
 *
 * Handles the "RE7 Plugins" admin page, native WP update injection for
 * packaged/hosted plugins, AJAX install/activate handlers, and a lean
 * install-only admin notice for missing required plugins.
 *
 * Replaces the old CTCoreTGMPAUpdater class.
 *
 * @package WP Pro Real Estate 7
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'CT_RE7_Plugin_Manager' ) ) {

	class CT_RE7_Plugin_Manager {

		/**
		 * Singleton instance.
		 *
		 * @var CT_RE7_Plugin_Manager
		 */
		private static $instance = null;

		/**
		 * Cached list of plugins from CT_Plugin_Activation.
		 *
		 * @var array|null
		 */
		private $plugins = null;

		/**
		 * Admin page hook suffix, set after add_theme_page() is called.
		 *
		 * @var string|false
		 */
		private $page_hook = false;

		/**
		 * Upsell plugin definitions.
		 * Icons are inline SVG strings pulled directly from each plugin's admin menu.
		 *
		 * @var array
		 */
		private $upsell_plugins = [
			'ct-idx-pro-plus' => [
				'name'    => 'CT IDX Pro+',
				'tagline' => 'MLS property search',
				'url'     => 'https://contempothemes.com/real-estate-idx/',
				'source'  => 'edd',
				// Building icon — source: ct-idx-pro-plus settings header (24x24 Heroicon)
				'icon'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="21" height="21" fill="none" aria-hidden="true" class="ct-upsell-icon"><path d="M8.25 21v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21m0 0h4.5V3.545M12.75 21h7.5V10.75M2.25 21h1.5m18 0h-18M2.25 9l4.5-1.636M18.75 3l-1.5.545m0 6.205 3 1m1.5.5-1.5-.5M6.75 7.364V3h-3v18m3-13.636 10.5-3.819" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
				'requires_yearly' => false,
			],
			'ct-automated-home-valuations' => [
				'name'      => 'CT Automated Home Valuations',
				'tagline'   => 'Seller lead capture',
				'url'       => 'https://contempothemes.com/automated-home-valuation-plugin/',
				'source'    => 'edd',
				// Main plugin file does not follow the slug/slug.php convention.
				'file_path' => 'ct-automated-home-valuations/ct-hvp.php',
				// Line chart icon — matches the plugin's dashicons-chart-line admin menu icon
				'icon'      => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="21" height="21" fill="none" aria-hidden="true" class="ct-upsell-icon"><polyline points="2,18 7,12 11,16 18,8 22,12" stroke="white" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="2" cy="18" r="1.5" fill="white"/><circle cx="7" cy="12" r="1.5" fill="white"/><circle cx="11" cy="16" r="1.5" fill="white"/><circle cx="18" cy="8" r="1.5" fill="white"/><circle cx="22" cy="12" r="1.5" fill="white"/></svg>',
				'requires_yearly' => false,
			],
			'ct-leads-pro' => [
				'name'    => 'CT Leads Pro',
				'tagline' => 'AI-first real estate CRM',
				'url'     => 'https://contempothemes.com/real-estate-crm/',
				'source'  => 'edd',
				// Rocket-launch icon — source: ct-leads-pro AdminMenu::menuIcon() (24x24 Heroicon)
				'icon'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="21" height="21" fill="none" aria-hidden="true" class="ct-upsell-icon"><path d="M15.59 14.37a6 6 0 0 1-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 0 0 6.16-12.12A14.98 14.98 0 0 0 9.631 8.41m5.96 5.96a14.926 14.926 0 0 1-5.841 2.58m-.119-8.54a6 6 0 0 0-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 0 0-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 0 1-2.448-2.448 14.9 14.9 0 0 1 .06-.312m-2.24 2.39a4.493 4.493 0 0 0-1.757 4.306 4.493 4.493 0 0 0 4.306-1.758M16.5 9a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
				'requires_yearly' => true,
			],
			'chatspark' => [
				'name'    => 'ChatSpark',
				'tagline' => '24/7 AI lead agent',
				'url'     => 'https://chatspark.io/benefits/real-estate-agents',
				'source'  => 'wporg',
				// Bolt icon — source: chatspark.php admin menu (36x36 viewBox)
				'icon'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 36" width="21" height="21" aria-hidden="true" class="ct-upsell-icon"><polygon fill="white" points="18.4,6.3 13.7,20 7.9,20"/><path fill="white" d="M29,15.3L29,15.3c-0.4-0.7-1.1-1.2-2-1.2h-4.5v3.6h1.9l-7.2,10.6v-5.9h-3.6v10.4c0,1,0.6,1.8,1.6,2.1c0.2,0.1,0.4,0.1,0.6,0.1c0.7,0,1.4-0.4,1.8-1l11.1-16.5C29.3,16.8,29.4,16,29,15.3z"/><path fill="white" d="M21.3,19.3V2.9c0-0.8-0.5-1.6-1.3-1.8s-1.6,0.1-2.1,0.7L6.8,18.3c-0.4,0.6-0.4,1.3-0.1,1.9c0.3,0.6,1,1,1.7,1h11.1C20.5,21.2,21.3,20.4,21.3,19.3z M18.4,6.3v12h-8.1L18.4,6.3z"/></svg>',
				'requires_yearly' => false,
			],
		];

		/**
		 * Private constructor — use get_instance().
		 */
		private function __construct() {}

		/**
		 * Boot the singleton.
		 *
		 * @return CT_RE7_Plugin_Manager
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
				self::$instance->init();
			}
			return self::$instance;
		}

		/**
		 * Register all hooks after instance is created.
		 */
		private function init() {
		// Native WP updater injection for packaged/hosted plugins.
		// Priority 20 ensures we run after EDD and other per-plugin updaters (default 10).
		add_filter( 'site_transient_update_plugins', [ $this, 'inject_updates' ], 20 );
			add_filter( 'plugins_api', [ $this, 'plugin_info' ], 20, 3 );

			// Admin page registration — priority 10 registers it, priority 11 hides the background page.
			add_action( 'admin_menu', [ $this, 'register_admin_page' ], 10 );
			add_action( 'admin_menu', [ $this, 'hide_background_installer' ], 11 );

			// Enqueue assets scoped to our page only.
			add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );

			// Install-only notice for missing required plugins.
			add_action( 'admin_notices', [ $this, 'missing_plugins_notice' ] );
			add_action( 'wp_ajax_ct_dismiss_plugins_notice', [ $this, 'ajax_dismiss_notice' ] );

		// AJAX handlers for one-click install / activate / update.
		add_action( 'wp_ajax_ct_install_plugin',  [ $this, 'ajax_install_plugin' ] );
		add_action( 'wp_ajax_ct_activate_plugin', [ $this, 'ajax_activate_plugin' ] );
		add_action( 'wp_ajax_ct_update_plugin',   [ $this, 'ajax_update_plugin' ] );
		}

		/* -----------------------------------------------------------------------
		 * Plugin data helpers
		 * -------------------------------------------------------------------- */

		/**
		 * Get the list of external/packaged plugins from CT_Plugin_Activation,
		 * filtering to only those with a custom source (not WP.org).
		 *
		 * @return array
		 */
		private function get_managed_plugins() {
			if ( ! is_null( $this->plugins ) ) {
				return $this->plugins;
			}

			$cached = get_transient( 'ct_plugins_cache' );
			if ( false !== $cached ) {
				$this->plugins = $cached;
				return $this->plugins;
			}

			if ( ! class_exists( 'CT_Plugin_Activation' ) ) {
				$this->plugins = [];
				return $this->plugins;
			}

			do_action( 'ct_plugins_register' );
			$manager = CT_Plugin_Activation::get_instance();
			$manager->populate_file_path();

			$plugins = [];
			foreach ( $manager->plugins as $slug => $plugin ) {
				if ( isset( $plugin['source_type'] ) && 'external' === $plugin['source_type'] ) {
					$plugins[ $slug ] = $plugin;
				}
			}

			set_transient( 'ct_plugins_cache', $plugins, 12 * HOUR_IN_SECONDS );
			$this->plugins = $plugins;
			return $this->plugins;
		}

		/**
		 * Get all registered plugins (both WP.org and external) for the admin page.
		 *
		 * @return array
		 */
		private function get_all_registered_plugins() {
			if ( ! class_exists( 'CT_Plugin_Activation' ) ) {
				return [];
			}

			do_action( 'ct_plugins_register' );
			$manager = CT_Plugin_Activation::get_instance();
			$manager->populate_file_path();

			return $manager->plugins;
		}

		/**
		 * Determine install status for a plugin slug.
		 *
		 * @param string $file_path  Plugin file path (slug/slug.php).
		 * @return string  'active' | 'inactive' | 'not_installed'
		 */
		private function get_plugin_status( $file_path ) {
			if ( is_plugin_active( $file_path ) ) {
				return 'active';
			}
			$installed = array_keys( get_plugins() );
			if ( in_array( $file_path, $installed, true ) ) {
				return 'inactive';
			}
			return 'not_installed';
		}

		/**
		 * Check whether an update is available for an installed plugin.
		 *
		 * @param string $file_path Plugin file path.
		 * @return bool
		 */
		private function has_update( $file_path ) {
			$transient = get_site_transient( 'update_plugins' );
			return isset( $transient->response[ $file_path ] );
		}

		/* -----------------------------------------------------------------------
		 * Native WP update injection
		 * -------------------------------------------------------------------- */

		/**
		 * Inject packaged/hosted plugin update entries into the native WP
		 * update transient so they appear on plugins.php like any other update.
		 *
		 * Skips plugins whose own EDD updater has already handled them.
		 *
		 * @param object $transient
		 * @return object
		 */
	public function inject_updates( $transient ) {
		// Build a minimal transient object when WP has not run its own check yet (returns
		// false/null) so we can still inject our managed plugin data. Without this, Plugin_Upgrader
		// would fail to find the package URL and report the plugin as up to date.
		if ( ! is_object( $transient ) ) {
			$transient = new stdClass();
		}

		// Ensure the standard buckets exist even when WP hasn't completed its own check yet.
		if ( ! isset( $transient->response ) ) {
			$transient->response = [];
		}
		if ( ! isset( $transient->no_update ) ) {
			$transient->no_update = [];
		}

		$plugins           = $this->get_managed_plugins();
		$installed_plugins = get_plugins();
		$installed_paths   = array_keys( $installed_plugins );

			foreach ( $plugins as $plugin ) {
				$plugin = (object) $plugin;

			if ( ! in_array( $plugin->file_path, $installed_paths, true ) ) {
				continue;
			}

			$plugin_version = $plugin->version ?? '';
			if ( empty( $plugin_version ) ) {
				continue;
			}

			// Skip only when another updater has already queued a proper update for this
			// plugin — meaning it is fully handled elsewhere (e.g. EDD with a valid license).
			if ( isset( $transient->response[ $plugin->file_path ] ) ) {
				continue;
			}

			$installed_version = $installed_plugins[ $plugin->file_path ]['Version'] ?? '0.0.0';

			$response              = new stdClass();
			$response->slug        = $plugin->slug;
			$response->plugin      = $plugin->file_path;
			$response->new_version = $plugin_version;
			$response->package     = $plugin->source;

			// Always clear any stale no_update entry from another updater (e.g. EDD on a
			// demo site without an active license may mark the plugin as no_update even
			// when a newer version is registered here) and inject the authoritative result.
			unset( $transient->no_update[ $plugin->file_path ] );

			if ( version_compare( $installed_version, $plugin_version, '<' ) ) {
				$transient->response[ $plugin->file_path ] = $response;
			} else {
				$transient->no_update[ $plugin->file_path ] = $response;
			}
			}

			return $transient;
		}

		/**
		 * Provide richer plugin information for the "View details" modal in the
		 * native WP updater for our managed plugins.
		 *
		 * @param false|object|array $response
		 * @param string             $action
		 * @param object             $args
		 * @return false|object|array
		 */
		public function plugin_info( $response, $action, $args ) {
			if ( 'plugin_information' !== $action || empty( $args->slug ) ) {
				return $response;
			}

			$plugins = $this->get_managed_plugins();

			if ( ! array_key_exists( $args->slug, $plugins ) ) {
				return $response;
			}

			$plugin = (object) $plugins[ $args->slug ];

			$info                = new stdClass();
			$info->name          = $plugin->name ?? $args->slug;
			$info->slug          = $args->slug;
			$info->version       = $plugin->version ?? '';
			$info->download_link = $plugin->source ?? '';
			$info->trunk         = $plugin->source ?? '';
			$info->author        = '<a href="https://contempothemes.com">Contempo Themes</a>';
			$info->homepage      = 'https://contempothemes.com';
			$info->requires      = '5.8';
			$info->tested        = '6.8';
			$info->sections      = [
				'description' => $plugin->name ?? '',
			];

			return $info;
		}

		/* -----------------------------------------------------------------------
		 * Admin page
		 * -------------------------------------------------------------------- */

		/**
		 * Register the "RE7 Plugins" page under Appearance.
		 */
		public function register_admin_page() {
			$this->page_hook = add_theme_page(
				__( 'RE7 Plugins', 'contempo' ),
				__( 'RE7 Plugins', 'contempo' ),
				'install_plugins',
				'ct-re7-plugins',
				[ $this, 'render_page' ]
			);
		}

		/**
		 * Hide the background CT Plugins installer page from the Appearance nav.
		 * It still functions as an HTTP endpoint for Merlin's bulk installer.
		 */
		public function hide_background_installer() {
			remove_submenu_page( 'themes.php', 'ct-install-plugins' );
		}

		/**
		 * Enqueue styles and scripts scoped to the RE7 Plugins page only.
		 *
		 * @param string $hook_suffix
		 */
		public function enqueue_assets( $hook_suffix ) {
			if ( $hook_suffix !== $this->page_hook ) {
				return;
			}

			$base = get_template_directory_uri() . '/admin/';
			$ver  = wp_get_theme()->get( 'Version' );

			// Register ct-settings if it hasn't been registered yet (it normally only
			// registers on the CT Settings admin page). We must register before we
			// declare it as a dependency, otherwise WP throws an "unregistered dependency"
			// notice and neither stylesheet loads.
			if ( ! wp_style_is( 'ct-settings', 'registered' ) ) {
				wp_register_style(
					'ct-settings',
					$base . 'ct-settings/assets/ct-settings.css',
					[],
					$ver
				);
			}

			// Enqueue ct-settings so design tokens are available, then our stylesheet.
			wp_enqueue_style( 'ct-settings' );

			wp_enqueue_style(
				'ct-re7-plugins',
				$base . 'plugins/assets/ct-re7-plugins.css',
				[ 'ct-settings' ],
				$ver
			);

			wp_enqueue_script(
				'ct-re7-plugins',
				$base . 'plugins/assets/ct-re7-plugins.js',
				[],
				$ver,
				true
			);

			wp_localize_script( 'ct-re7-plugins', 'ctRE7Plugins', [
				'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
				'nonce'         => wp_create_nonce( 'ct_re7_plugins' ),
				'pluginsUrl'    => admin_url( 'plugins.php' ),
			'strings'       => [
				'installing'  => __( 'Installing…', 'contempo' ),
				'activating'  => __( 'Activating…', 'contempo' ),
				'updating'    => __( 'Updating…', 'contempo' ),
				'installed'   => __( 'Installed!', 'contempo' ),
				'activated'   => __( 'Activated!', 'contempo' ),
				'updated'     => __( 'Updated!', 'contempo' ),
				'active'      => __( 'Active', 'contempo' ),
				'error'       => __( 'Something went wrong. Please try again.', 'contempo' ),
			],
			] );
		}

		/* -----------------------------------------------------------------------
		 * Admin notice (install-only, no update mentions)
		 * -------------------------------------------------------------------- */

		/**
		 * Show a dismiss-able warning notice when any required plugins are not installed.
		 * Never mentions updates — links only to the RE7 Plugins page for install/activate.
		 */
		public function missing_plugins_notice() {
			$screen = get_current_screen();
			if ( ! $screen ) {
				return;
			}

			// Only on main dashboard screens, not on our own page.
			$allowed_screens = [ 'dashboard', 'themes', 'plugins', 'appearance_page_ct-re7-plugins' ];
			if ( ! in_array( $screen->id, $allowed_screens, true ) ) {
				return;
			}

			$user_id  = get_current_user_id();
			$meta_key = 'ct_dismissed_notice_required_plugins';
			if ( get_user_meta( $user_id, $meta_key, true ) ) {
				return;
			}

			$plugins = $this->get_all_registered_plugins();
			if ( empty( $plugins ) ) {
				return;
			}

			$missing = [];
			foreach ( $plugins as $slug => $plugin ) {
				if ( ! empty( $plugin['required'] ) && isset( $plugin['file_path'] ) ) {
					$status = $this->get_plugin_status( $plugin['file_path'] );
					if ( 'not_installed' === $status ) {
						$missing[] = esc_html( $plugin['name'] );
					}
				}
			}

			if ( empty( $missing ) ) {
				return;
			}

			$page_url   = admin_url( 'themes.php?page=ct-re7-plugins' );
			$dismiss_url = wp_nonce_url(
				admin_url( 'admin-ajax.php?action=ct_dismiss_plugins_notice' ),
				'ct_dismiss_plugins_notice'
			);
			$plugin_list = implode( ', ', $missing );

			?>
			<div class="notice notice-warning is-dismissible ct-re7-notice" data-dismiss-url="<?php echo esc_url( $dismiss_url ); ?>">
				<p>
					<strong><?php esc_html_e( 'RE7 Plugins:', 'contempo' ); ?></strong>
					<?php
					printf(
						/* translators: 1: plugin name list, 2: page URL */
						__( 'The following required %1$s not yet installed: %2$s. <a href="%3$s">Install now &rarr;</a>', 'contempo' ),
						count( $missing ) === 1 ? __( 'plugin is', 'contempo' ) : __( 'plugins are', 'contempo' ),
						'<strong>' . $plugin_list . '</strong>',
						esc_url( $page_url )
					);
					?>
				</p>
			</div>
			<script>
			(function(){
				document.addEventListener('DOMContentLoaded', function(){
					var notice = document.querySelector('.ct-re7-notice');
					if (!notice) return;
					notice.addEventListener('click', function(e){
						if (e.target.classList.contains('notice-dismiss')) {
							fetch(notice.dataset.dismissUrl, { method:'POST', credentials:'same-origin' });
						}
					});
				});
			})();
			</script>
			<?php
		}

		/**
		 * AJAX handler: persist the notice dismissal.
		 */
		public function ajax_dismiss_notice() {
			check_ajax_referer( 'ct_dismiss_plugins_notice' );
			update_user_meta( get_current_user_id(), 'ct_dismissed_notice_required_plugins', 1 );
			wp_die();
		}

		/* -----------------------------------------------------------------------
		 * AJAX: install plugin
		 * -------------------------------------------------------------------- */

		/**
		 * Install a plugin via the native WordPress Plugin_Upgrader.
		 * Accepts `source` (a package URL) or `wporg_slug` for WP.org plugins.
		 */
		public function ajax_install_plugin() {
			check_ajax_referer( 'ct_re7_plugins', 'nonce' );

			if ( ! current_user_can( 'install_plugins' ) ) {
				wp_send_json_error( [ 'message' => __( 'Permission denied.', 'contempo' ) ], 403 );
			}

			$source     = isset( $_POST['source'] ) ? esc_url_raw( wp_unslash( $_POST['source'] ) ) : '';
			$wporg_slug = isset( $_POST['wporg_slug'] ) ? sanitize_text_field( wp_unslash( $_POST['wporg_slug'] ) ) : '';

			if ( empty( $source ) && empty( $wporg_slug ) ) {
				wp_send_json_error( [ 'message' => __( 'No plugin source provided.', 'contempo' ) ] );
			}

			// For WP.org plugins, fetch the download URL via the plugins_api.
			if ( ! empty( $wporg_slug ) && empty( $source ) ) {
				if ( ! function_exists( 'plugins_api' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
				}
				$api = plugins_api( 'plugin_information', [
					'slug'   => $wporg_slug,
					'fields' => [ 'download_link' => true ],
				] );
				if ( is_wp_error( $api ) ) {
					wp_send_json_error( [ 'message' => $api->get_error_message() ] );
				}
				$source = $api->download_link;
			}

			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';

			WP_Filesystem();

			$skin     = new WP_Ajax_Upgrader_Skin();
			$upgrader = new Plugin_Upgrader( $skin );
			$result   = $upgrader->install( $source );

			if ( is_wp_error( $result ) ) {
				wp_send_json_error( [ 'message' => $result->get_error_message() ] );
			}

			if ( is_wp_error( $skin->result ) ) {
				wp_send_json_error( [ 'message' => $skin->result->get_error_message() ] );
			}

		if ( null === $result ) {
			wp_send_json_error( [ 'message' => __( 'Install failed. WordPress could not write to the filesystem — check that the plugins directory is writable.', 'contempo' ) ] );
		}

			delete_transient( 'ct_plugins_cache' );
			wp_send_json_success( [ 'message' => __( 'Installed!', 'contempo' ) ] );
		}

		/* -----------------------------------------------------------------------
		 * AJAX: update plugin
		 * -------------------------------------------------------------------- */

		/**
		 * Update an installed plugin via the native WordPress Plugin_Upgrader.
		 * The download package is resolved automatically from the update_plugins
		 * transient — populated by inject_updates() for our managed plugins and
		 * by WordPress itself for WP.org plugins.
		 */
	public function ajax_update_plugin() {
		check_ajax_referer( 'ct_re7_plugins', 'nonce' );

		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'contempo' ) ], 403 );
		}

		$file_path = isset( $_POST['file_path'] )
			? plugin_basename( sanitize_text_field( wp_unslash( $_POST['file_path'] ) ) )
			: '';

		if ( empty( $file_path ) ) {
			wp_send_json_error( [ 'message' => __( 'No plugin specified.', 'contempo' ) ] );
		}

		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';

		// Explicitly seed the update_plugins transient so Plugin_Upgrader::upgrade() can
		// locate the download package. The inject_updates filter may not have fired yet in
		// the AJAX context, so we write the entry directly before handing off to the upgrader.
		$managed     = $this->get_managed_plugins();
		$new_version = '';
		foreach ( $managed as $p ) {
			if ( isset( $p['file_path'] ) && $p['file_path'] === $file_path && ! empty( $p['source'] ) ) {
				$new_version = $p['version'] ?? '';
				$current     = get_site_transient( 'update_plugins' );
				if ( ! is_object( $current ) ) {
					$current = new stdClass();
				}
				if ( ! isset( $current->response ) ) {
					$current->response = [];
				}
				$entry              = new stdClass();
				$entry->slug        = $p['slug'] ?? dirname( $file_path );
				$entry->plugin      = $file_path;
				$entry->new_version = $new_version;
				$entry->package     = $p['source'];
				$current->response[ $file_path ] = $entry;
				set_site_transient( 'update_plugins', $current );
				break;
			}
		}

		// Capture active state before the upgrade so we can restore it afterwards.
		$was_active = is_plugin_active( $file_path );

		WP_Filesystem();

		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );
		$result   = $upgrader->upgrade( $file_path );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( [ 'message' => $result->get_error_message() ] );
		}

		if ( is_wp_error( $skin->result ) ) {
			wp_send_json_error( [ 'message' => $skin->result->get_error_message() ] );
		}

		if ( false === $result ) {
			wp_send_json_error( [ 'message' => __( 'Update could not be applied. The plugin may already be up to date, or the update package was unavailable. Try refreshing the page.', 'contempo' ) ] );
		}

		// Reactivate the plugin if it was active before the update.
		if ( $was_active && ! is_plugin_active( $file_path ) ) {
			$activate = activate_plugin( $file_path, '', is_multisite() );
			if ( is_wp_error( $activate ) ) {
				delete_transient( 'ct_plugins_cache' );
				delete_site_transient( 'update_plugins' );
				wp_send_json_success( [
					'message'     => __( 'Updated, but could not reactivate automatically. Please activate the plugin manually.', 'contempo' ),
					'reactivated' => false,
					'new_version' => $new_version,
				] );
			}
		}

		delete_transient( 'ct_plugins_cache' );
		delete_site_transient( 'update_plugins' );
		wp_send_json_success( [
			'message'     => __( 'Updated!', 'contempo' ),
			'reactivated' => $was_active,
			'new_version' => $new_version,
		] );
	}

		/* -----------------------------------------------------------------------
		 * AJAX: activate plugin
		 * -------------------------------------------------------------------- */

		/**
		 * Activate an already-installed plugin.
		 */
		public function ajax_activate_plugin() {
			check_ajax_referer( 'ct_re7_plugins', 'nonce' );

			if ( ! current_user_can( 'activate_plugins' ) ) {
				wp_send_json_error( [ 'message' => __( 'Permission denied.', 'contempo' ) ], 403 );
			}

			$file_path = isset( $_POST['file_path'] ) ? sanitize_text_field( wp_unslash( $_POST['file_path'] ) ) : '';

			if ( empty( $file_path ) ) {
				wp_send_json_error( [ 'message' => __( 'No plugin specified.', 'contempo' ) ] );
			}

			require_once ABSPATH . 'wp-admin/includes/plugin.php';

			$result = activate_plugin( $file_path );

			if ( is_wp_error( $result ) ) {
				wp_send_json_error( [ 'message' => $result->get_error_message() ] );
			}

			wp_send_json_success( [ 'message' => __( 'Activated!', 'contempo' ) ] );
		}

		/* -----------------------------------------------------------------------
		 * Page render
		 * -------------------------------------------------------------------- */

		/**
		 * Render the "RE7 Plugins" admin page.
		 */
		public function render_page() {
			$all_plugins = $this->get_all_registered_plugins();
			$required    = [];
			$optional    = [];

			// These plugins are superseded by CT IDX Pro+ which ships its own equivalents.
			$idx_superseded = [
				'ct-sms-alerts',
			];

			$idx_status = $this->get_plugin_status( 'ct-idx-pro-plus/ct-idx-pro-plus.php' );
			$idx_installed = in_array( $idx_status, [ 'active', 'inactive' ], true );

			foreach ( $all_plugins as $slug => $plugin ) {
				if ( ! isset( $plugin['file_path'] ) ) {
					continue;
				}
				// Hide plugins superseded by CT IDX Pro+ when that plugin is present.
				if ( $idx_installed && in_array( $slug, $idx_superseded, true ) ) {
					continue;
				}
				if ( ! empty( $plugin['required'] ) ) {
					$required[ $slug ] = $plugin;
				} else {
					$optional[ $slug ] = $plugin;
				}
			}

			// Check overall health for the all-healthy banner.
			$all_healthy = true;
			foreach ( $all_plugins as $slug => $plugin ) {
				if ( empty( $plugin['required'] ) ) {
					continue;
				}
				if ( isset( $plugin['file_path'] ) && 'active' !== $this->get_plugin_status( $plugin['file_path'] ) ) {
					$all_healthy = false;
					break;
				}
			}

		$theme = wp_get_theme();
		?>
		<div id="ct-settings-wrap">
		<div class="ct-settings-header ct-settings-header--with-desc">
			<div class="ct-settings-header__left">
				<span class="ct-settings-logo dashicons dashicons-admin-plugins"></span>
				<span class="ct-settings-title"><?php esc_html_e( 'Real Estate 7 Plugins', 'contempo' ); ?></span>
				<span class="ct-settings-version"><?php echo esc_html( $theme->get( 'Version' ) ); ?></span>
			</div>
			<p class="ct-settings-desc"><?php esc_html_e( 'Install, activate, and update plugins for your Real Estate 7 theme.', 'contempo' ); ?></p>
		</div>
		<div class="ct-settings-body">
		<main class="ct-settings-content">
		<div class="ct-re7-plugins-wrap">

				<?php if ( $all_healthy ) : ?>
				<div class="ct-field-info-banner ct-field-info-banner--success ct-re7-healthy-banner">
					<?php esc_html_e( 'All required plugins are installed and active.', 'contempo' ); ?>
				</div>
				<?php endif; ?>

				<?php if ( ! empty( $required ) ) : ?>
				<div class="ct-re7-section">
					<h2 class="ct-section-title"><?php esc_html_e( 'Required Plugins', 'contempo' ); ?></h2>
					<div class="ct-plugins-grid">
						<?php foreach ( $required as $slug => $plugin ) :
							$this->render_plugin_card( $plugin );
						endforeach; ?>
					</div>
				</div>
				<?php endif; ?>

				<?php if ( ! empty( $optional ) ) : ?>
				<div class="ct-re7-section">
					<h2 class="ct-section-title"><?php esc_html_e( 'Optional Plugins', 'contempo' ); ?></h2>
					<div class="ct-plugins-grid">
						<?php foreach ( $optional as $slug => $plugin ) :
							$this->render_plugin_card( $plugin );
						endforeach; ?>
					</div>
				</div>
				<?php endif; ?>

			<div class="ct-re7-section">
				<h2 class="ct-section-title"><?php esc_html_e( 'Enhance Your Site', 'contempo' ); ?></h2>
				<div class="ct-plugins-grid">
					<?php foreach ( $this->upsell_plugins as $slug => $upsell ) :
						// Skip any upsell plugin already present in the managed plugins list.
						if ( isset( $all_plugins[ $slug ] ) ) {
							continue;
						}
						$this->render_upsell_card( $slug, $upsell );
				endforeach; ?>
			</div>
		</div>

		</div><!-- /.ct-re7-plugins-wrap -->
		</main><!-- /.ct-settings-content -->
		</div><!-- /.ct-settings-body -->
		</div><!-- /#ct-settings-wrap -->
		<?php
	}

		/**
		 * Render a single managed plugin card.
		 *
		 * @param array $plugin Plugin data from CT_Plugin_Activation.
		 */
		private function render_plugin_card( $plugin ) {
		$file_path          = $plugin['file_path'] ?? '';
		$status             = $file_path ? $this->get_plugin_status( $file_path ) : 'not_installed';
		$source_type        = $plugin['source_type'] ?? 'repo';
		$source_url         = $plugin['source'] ?? '';
		$registered_version = $plugin['version'] ?? '';
		$name               = $plugin['name'] ?? $plugin['slug'];
		$description        = $plugin['description'] ?? '';
		$publisher          = 'external' === $source_type ? 'Contempo' : 'WP.org';

		// Prefer the actual installed version from WordPress over the hardcoded registered
		// version in register.php, so the card accurately reflects what is on disk.
		$installed_version = '';
		if ( $file_path && in_array( $status, [ 'active', 'inactive' ], true ) ) {
			$wp_plugins        = get_plugins();
			$installed_version = $wp_plugins[ $file_path ]['Version'] ?? '';
		}
		$version = $installed_version ?: $registered_version;

		// Prefer the transient-based check (respects WP's update pipeline) but fall back to
	// a direct version comparison so the Update button always appears when the registered
	// version is ahead of what's installed — even before WP has rebuilt its update cache.
	$has_update = false;
	if ( $file_path && 'active' === $status ) {
		$has_update = $this->has_update( $file_path );
		if ( ! $has_update && $installed_version && $registered_version ) {
			$has_update = version_compare( $installed_version, $registered_version, '<' );
		}
	}

			if ( $has_update ) {
				$status = 'update_available';
			}

			$status_labels = [
				'active'           => __( '● Active', 'contempo' ),
				'inactive'         => __( '○ Inactive', 'contempo' ),
				'not_installed'    => __( 'Not Installed', 'contempo' ),
				'update_available' => __( '◆ Update Available', 'contempo' ),
			];

			$status_label = $status_labels[ $status ] ?? $status_labels['not_installed'];

			?>
			<div class="ct-plugin-card" data-slug="<?php echo esc_attr( $plugin['slug'] ); ?>">
				<div class="ct-plugin-card__body">
					<div class="ct-plugin-card__header">
						<div class="ct-plugin-card__info">
							<div class="ct-plugin-card__name"><?php echo esc_html( $name ); ?></div>
							<?php if ( $description ) : ?>
							<div class="ct-plugin-card__desc"><?php echo esc_html( $description ); ?></div>
							<?php endif; ?>
						</div>
						<div class="ct-plugin-card__status ct-status--<?php echo esc_attr( $status ); ?>">
							<?php echo esc_html( $status_label ); ?>
						</div>
					</div>
					<div class="ct-plugin-card__meta">
						<span class="ct-plugin-card__publisher"><?php echo esc_html( $publisher ); ?></span>
						<?php if ( $version ) : ?>
						<span class="ct-plugin-card__version">v<?php echo esc_html( $version ); ?></span>
						<?php endif; ?>
					</div>
				</div>
				<div class="ct-plugin-card__footer">
					<?php $this->render_plugin_action_button( $status, $plugin, $file_path, $source_url ); ?>
				</div>
			</div>
			<?php
		}

		/**
		 * Render the action button for a managed plugin card.
		 *
		 * @param string $status
		 * @param array  $plugin
		 * @param string $file_path
		 * @param string $source_url
		 */
		private function render_plugin_action_button( $status, $plugin, $file_path, $source_url ) {
			switch ( $status ) {
				case 'active':
					echo '<button class="ct-plugin-btn ct-plugin-btn--disabled" disabled>' . esc_html__( 'Active', 'contempo' ) . '</button>';
					break;

				case 'inactive':
					printf(
						'<button class="ct-plugin-btn ct-plugin-btn--primary js-ct-activate" data-file-path="%s">%s</button>',
						esc_attr( $file_path ),
						esc_html__( 'Activate', 'contempo' )
					);
					break;

			case 'update_available':
				printf(
					'<button class="ct-plugin-btn ct-plugin-btn--update js-ct-update" data-file-path="%s">%s</button>',
					esc_attr( $file_path ),
					esc_html__( 'Update', 'contempo' )
				);
				break;

			case 'not_installed':
			default:
				if ( ! empty( $source_url ) ) {
					printf(
						'<button class="ct-plugin-btn ct-plugin-btn--primary js-ct-install" data-source="%s">%s</button>',
						esc_attr( $source_url ),
						esc_html__( 'Install', 'contempo' )
					);
				} elseif ( isset( $plugin['source_type'] ) && 'repo' === $plugin['source_type'] ) {
					printf(
						'<button class="ct-plugin-btn ct-plugin-btn--primary js-ct-install" data-wporg-slug="%s">%s</button>',
						esc_attr( $plugin['slug'] ),
						esc_html__( 'Install', 'contempo' )
					);
				}
				break;
			}
		}

		/**
		 * Render a single upsell card.
		 *
		 * @param string $slug
		 * @param array  $upsell
		 */
		private function render_upsell_card( $slug, $upsell ) {
			$file_path = $upsell['file_path'] ?? ( $slug . '/' . $slug . '.php' );
			$status    = $this->get_plugin_status( $file_path );
			$source    = $upsell['source'];

			$status_labels = [
				'active'        => __( '● Active', 'contempo' ),
				'inactive'      => __( '○ Inactive', 'contempo' ),
				'not_installed' => __( 'Not Installed', 'contempo' ),
			];
			$status_label = $status_labels[ $status ] ?? $status_labels['not_installed'];

			$publisher = 'wporg' === $source ? 'ChatSpark · Premium' : 'Contempo · Premium';

			?>
			<div class="ct-plugin-card ct-plugin-card--upsell" data-slug="<?php echo esc_attr( $slug ); ?>">
				<div class="ct-plugin-card__body">
					<div class="ct-plugin-card__header">
						<?php if ( ! empty( $upsell['icon'] ) ) : ?>
						<span class="ct-plugin-card__icon"><?php echo $upsell['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped — trusted inline SVG ?></span>
						<?php endif; ?>
						<div class="ct-plugin-card__info">
							<div class="ct-plugin-card__name"><?php echo esc_html( $upsell['name'] ); ?></div>
							<div class="ct-plugin-card__tagline"><?php echo esc_html( $upsell['tagline'] ); ?></div>
						</div>
						<div class="ct-plugin-card__status ct-status--<?php echo esc_attr( $status ); ?>">
							<?php echo esc_html( $status_label ); ?>
						</div>
					</div>
					<div class="ct-plugin-card__meta">
						<span class="ct-plugin-card__publisher"><?php echo esc_html( $publisher ); ?></span>
					</div>
				</div>
				<div class="ct-plugin-card__footer ct-plugin-card__footer--upsell">
					<a class="ct-plugin-btn ct-plugin-btn--outline"
					   href="<?php echo esc_url( $upsell['url'] ); ?>"
					   target="_blank"
					   rel="noopener noreferrer">
						<?php esc_html_e( 'Learn More →', 'contempo' ); ?>
					</a>

					<?php if ( 'inactive' === $status ) : ?>
					<button class="ct-plugin-btn ct-plugin-btn--primary js-ct-activate"
					        data-file-path="<?php echo esc_attr( $file_path ); ?>">
						<?php esc_html_e( 'Activate', 'contempo' ); ?>
					</button>

					<?php elseif ( 'active' === $status ) : ?>
					<button class="ct-plugin-btn ct-plugin-btn--disabled" disabled>
						<?php esc_html_e( 'Active', 'contempo' ); ?>
					</button>

					<?php elseif ( 'wporg' === $source && 'not_installed' === $status ) : ?>
					<button class="ct-plugin-btn ct-plugin-btn--primary js-ct-install"
					        data-wporg-slug="<?php echo esc_attr( $slug ); ?>">
						<?php esc_html_e( 'Install Plugin', 'contempo' ); ?>
					</button>

					<?php endif; ?>
				</div>
			</div>
			<?php
		}

	} // end class CT_RE7_Plugin_Manager

	// Boot the singleton on init.
	add_action( 'init', [ 'CT_RE7_Plugin_Manager', 'get_instance' ] );

} // end class_exists check
