/**
 * RE7 Plugins — Admin Page JS
 *
 * Handles one-click install and activate AJAX actions, spinner states,
 * and inline success/error feedback. Vanilla JS — no jQuery dependency.
 *
 * @package WP Pro Real Estate 7
 */

(function () {
	'use strict';

	if (typeof ctRE7Plugins === 'undefined') {
		return;
	}

	var cfg = ctRE7Plugins;

	/* -----------------------------------------------------------------------
	 * Helpers
	 * -------------------------------------------------------------------- */

	function setButtonLoading(btn, label) {
		btn.disabled = true;
		btn.dataset.originalText = btn.textContent;
		btn.innerHTML = '<span class="ct-btn-spinner"></span>' + label;
	}

	function resetButton(btn) {
		btn.disabled = false;
		btn.innerHTML = btn.dataset.originalText || btn.innerHTML;
	}

	function showFeedback(card, type, message) {
		removeFeedback(card);
		var footer = card.querySelector('.ct-plugin-card__footer');
		if (!footer) return;

		var msg = document.createElement('div');
		msg.className = 'ct-plugin-feedback ct-plugin-feedback--' + type;
		msg.textContent = message;
		footer.appendChild(msg);

		setTimeout(function () {
			removeFeedback(card);
		}, 3500);
	}

	function removeFeedback(card) {
		var existing = card.querySelector('.ct-plugin-feedback');
		if (existing) {
			existing.parentNode.removeChild(existing);
		}
	}

	function postAjax(action, data, onSuccess, onError) {
		var body = new FormData();
		body.append('action', action);
		body.append('nonce', cfg.nonce);

		Object.keys(data).forEach(function (key) {
			body.append(key, data[key]);
		});

		fetch(cfg.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: body,
		})
			.then(function (res) {
				return res.json();
			})
			.then(function (json) {
				if (json && json.success) {
					onSuccess(json.data);
				} else {
					var msg = (json && json.data && json.data.message) ? json.data.message : cfg.strings.error;
					onError(msg);
				}
			})
			.catch(function () {
				onError(cfg.strings.error);
			});
	}

	/* -----------------------------------------------------------------------
	 * Install handler
	 * -------------------------------------------------------------------- */

	function handleInstall(btn) {
		var card     = btn.closest('.ct-plugin-card');
		var source   = btn.dataset.source || '';
		var wpSlug   = btn.dataset.wporgSlug || '';

		setButtonLoading(btn, cfg.strings.installing);

		var payload = {};
		if (source)  payload.source      = source;
		if (wpSlug)  payload.wporg_slug  = wpSlug;

		postAjax(
			'ct_install_plugin',
			payload,
			function () {
				resetButton(btn);
				showFeedback(card, 'success', cfg.strings.installed);

				// Swap button to Activate state after install.
				// The file_path is not known client-side; reload the page instead.
				setTimeout(function () {
					window.location.reload();
				}, 1200);
			},
			function (msg) {
				resetButton(btn);
				showFeedback(card, 'error', msg);
			}
		);
	}

	/* -----------------------------------------------------------------------
	 * Activate handler
	 * -------------------------------------------------------------------- */

	function handleActivate(btn) {
		var card     = btn.closest('.ct-plugin-card');
		var filePath = btn.dataset.filePath || '';

		if (!filePath) {
			return;
		}

		setButtonLoading(btn, cfg.strings.activating);

		postAjax(
			'ct_activate_plugin',
			{ file_path: filePath },
			function () {
				showFeedback(card, 'success', cfg.strings.activated);

			// Update button to disabled Active state.
			btn.className   = 'ct-plugin-btn ct-plugin-btn--disabled';
			btn.disabled    = true;
			btn.textContent = cfg.strings.active;

				// Update status pill.
				var pill = card.querySelector('.ct-plugin-card__status');
				if (pill) {
					pill.className   = 'ct-plugin-card__status ct-status--active';
					pill.textContent = '● Active';
				}
			},
			function (msg) {
				resetButton(btn);
				showFeedback(card, 'error', msg);
			}
		);
	}

	/* -----------------------------------------------------------------------
	 * Update handler
	 * -------------------------------------------------------------------- */

	function handleUpdate(btn) {
		var card     = btn.closest('.ct-plugin-card');
		var filePath = btn.dataset.filePath || '';

		if (!filePath) {
			return;
		}

		setButtonLoading(btn, cfg.strings.updating);

		postAjax(
			'ct_update_plugin',
			{ file_path: filePath },
			function (data) {
				showFeedback(card, 'success', cfg.strings.updated);

				// Swap button to disabled Active state — plugin is reactivated by WP after update.
				btn.className   = 'ct-plugin-btn ct-plugin-btn--disabled';
				btn.disabled    = true;
				btn.textContent = cfg.strings.active;

				// Update status pill.
				var pill = card.querySelector('.ct-plugin-card__status');
				if (pill) {
					pill.className   = 'ct-plugin-card__status ct-status--active';
					pill.textContent = '● Active';
				}

				// Refresh the version badge with the newly installed version.
				if (data && data.new_version) {
					var verEl = card.querySelector('.ct-plugin-card__version');
					if (verEl) {
						verEl.textContent = 'v' + data.new_version;
					}
				}
			},
			function (msg) {
				resetButton(btn);
				showFeedback(card, 'error', msg);
			}
		);
	}

	/* -----------------------------------------------------------------------
	 * Event delegation — single listener on the page wrapper
	 * -------------------------------------------------------------------- */

	document.addEventListener('DOMContentLoaded', function () {
		var wrap = document.querySelector('.ct-re7-plugins-wrap');
		if (!wrap) return;

		wrap.addEventListener('click', function (e) {
			var btn = e.target.closest('button, a.ct-plugin-btn');
			if (!btn) return;

			if (btn.classList.contains('js-ct-install')) {
				e.preventDefault();
				handleInstall(btn);
			} else if (btn.classList.contains('js-ct-activate')) {
				e.preventDefault();
				handleActivate(btn);
			} else if (btn.classList.contains('js-ct-update')) {
				e.preventDefault();
				handleUpdate(btn);
			}
		});
	});

})();
