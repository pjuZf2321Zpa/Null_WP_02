<?php
/**
 * Help & Resources
 *
 * @package WP Pro Real Estate 7
 * @subpackage Admin
 */

function ct_load_admin_scripts( $hook ) {

	if ( 'appearance_page_realestate-7-help-resources' !== $hook ) return;

	$theme   = wp_get_theme( 'realestate-7' );
	$version = $theme->get( 'Version' );
	$base    = get_template_directory_uri() . '/admin/';

	if ( ! wp_style_is( 'ct-settings', 'registered' ) ) {
		wp_register_style( 'ct-settings', $base . 'ct-settings/assets/ct-settings.css', [], $version );
	}
	wp_enqueue_style( 'ct-settings' );

	wp_enqueue_script( 'ct-help-resources', $base . 'help-resources/help-resources.js', array( 'jquery' ), $version, true );
	wp_enqueue_style( 'ct-help-resources', $base . 'help-resources/help-resources.css', [ 'ct-settings' ], $version );
}
add_action( 'admin_enqueue_scripts', 'ct_load_admin_scripts' );

class ct_getting_started_admin {

	protected $theme_slug = null;
	protected $version    = null;
	protected $author     = null;
	protected $strings    = null;
	protected $item_name  = null;

	function __construct( $config = array(), $strings = array() ) {

		$config = wp_parse_args( $config, array(
			'remote_api_url' => '',
			'theme_slug'     => get_template(),
			'api_slug'       => get_template() . '-wordpress-theme',
			'item_name'      => '',
			'license'        => '',
			'version'        => '',
			'author'         => '',
			'download_id'    => '',
			'renew_url'      => '',
		) );

		$this->item_name  = $config['item_name'];
		$this->theme_slug = sanitize_key( $config['theme_slug'] );
		$this->version    = $config['version'];
		$this->author     = $config['author'];

		if ( '' == $config['version'] ) {
			$theme         = wp_get_theme( $this->theme_slug );
			$this->version = $theme->get( 'Version' );
		}

		$this->strings = $strings;

		add_action( 'admin_menu', array( $this, 'ct_help_resources_menu' ) );
	}

	function ct_help_resources_menu() {
		$strings = $this->strings;
		add_theme_page(
			$strings['getting-started'],
			$strings['getting-started'],
			'manage_options',
			$this->theme_slug . '-help-resources',
			array( $this, 'ct_help_resources_page' )
		);
	}

	function ct_help_resources_page() {
		$theme           = wp_get_theme( 'realestate-7' );
		$version         = $theme->get( 'Version' );
		$idx_pro_active   = is_plugin_active( 'ct-idx-pro-plus/ct-idx-pro-plus.php' );
		$leads_pro_active = is_plugin_active( 'ct-leads-pro/ct-leads-pro.php' );
		$ahv_active       = is_plugin_active( 'ct-automated-home-valuations/ct-hvp.php' );
		?>
		<div class="hr-wrap">

			<!-- ================================================================
			     Header
			     ============================================================== -->
			<div class="ct-settings-header ct-settings-header--with-desc">
				<div class="ct-settings-header__left">
					<span class="ct-settings-logo dashicons dashicons-sos"></span>
					<span class="ct-settings-title"><?php esc_html_e( 'Help &amp; Resources', 'contempo' ); ?></span>
					<span class="ct-settings-version"><?php echo esc_html( $version ); ?></span>
				</div>
				<p class="ct-settings-desc"><?php esc_html_e( 'Documentation, support, and release notes for Real Estate 7.', 'contempo' ); ?></p>
			</div>

			<!-- ================================================================
			     Tab nav
			     ============================================================== -->
			<nav class="hr-nav">
				<ul class="hr-nav__list">
					<li class="hr-nav__item current"><a class="hr-nav__link" href="#docs"><?php esc_html_e( 'Docs', 'contempo' ); ?></a></li>
					<li class="hr-nav__item"><a class="hr-nav__link" href="#faq-support"><?php esc_html_e( 'FAQ &amp; Support', 'contempo' ); ?></a></li>
					<li class="hr-nav__item"><a class="hr-nav__link" href="#changelog"><?php esc_html_e( 'Changelog', 'contempo' ); ?></a></li>
				</ul>
			</nav>

			<!-- ================================================================
			     Body — content + aside
			     ============================================================== -->
			<div class="hr-body">

				<!-- ============================================================
				     Tab panels
				     ========================================================== -->
				<div class="hr-content">

					<script>
					(function(){
						var hashMap = { '#docs': 0, '#faq-support': 1, '#changelog': 2 };
						var tabMap  = { '#docs': 'docs', '#faq-support': 'faq-support', '#changelog': 'changelog' };
						var hash    = window.location.hash;
						var tab     = tabMap[ hash ] || 'docs';
						var idx     = hashMap.hasOwnProperty( hash ) ? hashMap[ hash ] : 0;
						document.querySelector( '.hr-content' ).setAttribute( 'data-tab', tab );
						var navItems = document.querySelectorAll( '.hr-nav__list li' );
						navItems.forEach( function( li ) { li.classList.remove( 'current' ); } );
						if ( navItems[ idx ] ) { navItems[ idx ].classList.add( 'current' ); }
					})();
					</script>

					<!-- Docs panel -->
					<div class="hr-panel panel-left" id="hr-panel-docs">
						<div class="hr-docs-grid">

							<div class="hr-docs-category">
								<h4 class="hr-docs-category__title"><?php esc_html_e( 'Setup', 'contempo' ); ?></h4>
								<ul class="hr-docs-list">
									<li><a href="https://contempothemes.com/docs/installation-setup-wizard/" target="_blank"><?php esc_html_e( 'Installation &amp; Setup Wizard', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/instructional-videos/" target="_blank"><?php esc_html_e( 'Instructional Videos', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/homepage-setup/" target="_blank"><?php esc_html_e( 'Homepage Setup', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/elementor/" target="_blank"><?php esc_html_e( 'Elementor', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/building-out-your-navigation-find-a-home/" target="_blank"><?php esc_html_e( 'Building Out Your Navigation, "Find A Home"', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/using-mega-menus/" target="_blank"><?php esc_html_e( 'Using Mega Menus', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/setting-up-your-blog/" target="_blank"><?php esc_html_e( 'Setting Up Your Blog', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/using-permalinks/" target="_blank"><?php esc_html_e( 'Using Permalinks', 'contempo' ); ?></a></li>
									<?php if ( $idx_pro_active ) : ?>
									<li><a href="https://contempothemes.com/docs/agents/" target="_blank"><?php esc_html_e( 'Agents', 'contempo' ); ?></a></li>
									<?php endif; ?>
								</ul>
							</div>

							<?php if ( ! $idx_pro_active ) : ?>
							<div class="hr-docs-category">
								<h4 class="hr-docs-category__title"><?php esc_html_e( 'Listings', 'contempo' ); ?></h4>
								<ul class="hr-docs-list">
									<li><a href="https://contempothemes.com/docs/adding-managing-listings/" target="_blank"><?php esc_html_e( 'Adding &amp; Managing Listings', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/listings-advanced-search/" target="_blank"><?php esc_html_e( 'Listings Advanced Search', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/open-houses/" target="_blank"><?php esc_html_e( 'Open Houses', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/agents/" target="_blank"><?php esc_html_e( 'Agents', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/brokerages/" target="_blank"><?php esc_html_e( 'Brokerages', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/co-listing/" target="_blank"><?php esc_html_e( 'Co-listing', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/sub-listings/" target="_blank"><?php esc_html_e( 'Sub Listings', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/front-end-listing-system/" target="_blank"><?php esc_html_e( 'Front End Listing System', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/wp-all-import/" target="_blank"><?php esc_html_e( 'WP All Import', 'contempo' ); ?></a></li>
								</ul>
							</div>
							<?php endif; ?>

							<div class="hr-docs-category">
								<h4 class="hr-docs-category__title"><?php esc_html_e( 'Integrations', 'contempo' ); ?></h4>
								<ul class="hr-docs-list">
									<?php if ( $idx_pro_active ) : ?>
									<li><a href="https://contempothemes.com/docs/ct-idx-pro-plus/" target="_blank"><?php esc_html_e( 'CT IDX Pro+', 'contempo' ); ?></a></li>
									<?php else : ?>
									<li><a href="https://contempothemes.com/docs/idx-plugins-third-party/" target="_blank"><?php esc_html_e( 'IDX Plugins (Third-party)', 'contempo' ); ?></a></li>
									<?php endif; ?>
									<li><a href="https://contempothemes.com/docs/ct-leads-pro-crm/" target="_blank"><?php esc_html_e( 'CT Leads Pro (CRM)', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/ct-automated-home-valuations/" target="_blank"><?php esc_html_e( 'CT Automated Home Valuations', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/follow-up-boss/" target="_blank"><?php esc_html_e( 'Follow Up Boss', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/zapier/" target="_blank"><?php esc_html_e( 'Zapier', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/social-login/" target="_blank"><?php esc_html_e( 'Social Login', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/google-maps/" target="_blank"><?php esc_html_e( 'Google Maps', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/google-recaptcha/" target="_blank"><?php esc_html_e( 'Google reCAPTCHA', 'contempo' ); ?></a></li>
								</ul>
							</div>

							<?php if ( ! $idx_pro_active ) : ?>
							<div class="hr-docs-category">
								<h4 class="hr-docs-category__title"><?php esc_html_e( 'User Features', 'contempo' ); ?></h4>
								<ul class="hr-docs-list">
									<li><a href="https://contempothemes.com/docs/saved-search-listing-alerts/" target="_blank"><?php esc_html_e( 'Saved Search &amp; Listing Alerts', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/lead-listing-alerts/" target="_blank"><?php esc_html_e( 'Lead Listing Alerts', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/sms-alerts/" target="_blank"><?php esc_html_e( 'SMS Alerts', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/favorite-listings/" target="_blank"><?php esc_html_e( 'Favorite Listings', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/compare-listings/" target="_blank"><?php esc_html_e( 'Compare Listings', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/walk-score/" target="_blank"><?php esc_html_e( 'Walk Score', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/setting-up-whats-nearby-for-listings/" target="_blank"><?php esc_html_e( 'Setting Up "What\'s Nearby?" for Listings', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/estimated-payment-affordability-calculator/" target="_blank"><?php esc_html_e( 'Estimated Payment &amp; Affordability Calculator', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/listing-analytics/" target="_blank"><?php esc_html_e( 'Listing Analytics', 'contempo' ); ?></a></li>
								</ul>
							</div>
							<?php endif; ?>

							<div class="hr-docs-category">
								<h4 class="hr-docs-category__title"><?php esc_html_e( 'Developer', 'contempo' ); ?></h4>
								<ul class="hr-docs-list">
									<li><a href="https://contempothemes.com/docs/child-themes/" target="_blank"><?php esc_html_e( 'Child Themes', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/wpml/" target="_blank"><?php esc_html_e( 'WPML', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/translation/" target="_blank"><?php esc_html_e( 'Translation', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/custom-page-templates/" target="_blank"><?php esc_html_e( 'Custom Page Templates', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/widgets/" target="_blank"><?php esc_html_e( 'Widgets', 'contempo' ); ?></a></li>
									<li><a href="https://contempothemes.com/docs/advanced-development/" target="_blank"><?php esc_html_e( 'Advanced Development', 'contempo' ); ?></a></li>
								</ul>
							</div>

						</div><!-- .hr-docs-grid -->
					</div><!-- #hr-panel-docs -->

					<!-- FAQ & Support panel -->
					<div class="hr-panel panel-left" id="hr-panel-support">
						<div class="hr-support-grid">

						<div class="hr-docs-category hr-support-card">
							<h4 class="hr-docs-category__title"><?php esc_html_e( 'Support', 'contempo' ); ?></h4>
							<p><?php
								$ct_docs_url = 'https://contempothemes.com/docs/';
								$ct_kb_url   = 'https://contempothemes.com/docs/';
								printf(
									wp_kses( __( 'Read through the <a href="%1$s" target="_blank">documentation</a> and <a href="%2$s" target="_blank">knowledge base</a> first — most answers are there. Still have questions? We\'re happy to help.', 'contempo' ), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ),
									esc_url( $ct_docs_url ),
									esc_url( $ct_kb_url )
								);
							?></p>
							<?php $ct_support_url = 'https://contempothemes.com/docs/how-do-i-get-support/'; ?>
							<a href="<?php echo esc_url( $ct_support_url ); ?>" target="_blank" class="hr-support-btn"><?php esc_html_e( 'Open a Live Chat', 'contempo' ); ?></a>
						</div>

						<?php if ( $idx_pro_active ) : ?>
						<div class="hr-docs-category">
							<h4 class="hr-docs-category__title"><?php esc_html_e( 'CT IDX Pro+', 'contempo' ); ?></h4>
							<ul class="hr-docs-list">
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/im-missing-mls-data-or-seeing-inaccuracies-with-ct-idx-pro-plus/" target="_blank"><?php esc_html_e( 'I\'m missing MLS data or seeing inaccuracies with CT IDX Pro+?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-update-my-ct-idx-pro-plus-license-key/" target="_blank"><?php esc_html_e( 'How do I update my CT IDX Pro+ license key?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/listing-book-showing-widget-where-does-it-go/" target="_blank"><?php esc_html_e( 'Listing "Book Showing" widget where does it go?', 'contempo' ); ?></a></li>
							</ul>
						</div>
						<?php endif; ?>

						<?php if ( $leads_pro_active || $ahv_active ) : ?>
						<div class="hr-docs-category">
							<h4 class="hr-docs-category__title"><?php esc_html_e( 'Plugins', 'contempo' ); ?></h4>
							<ul class="hr-docs-list">
								<?php if ( $leads_pro_active ) : ?>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-update-my-ct-leads-pro-license-key/" target="_blank"><?php esc_html_e( 'How do I update my CT Leads Pro license key?', 'contempo' ); ?></a></li>
								<?php endif; ?>
								<?php if ( $ahv_active ) : ?>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-update-my-ct-home-valuation-license-key/" target="_blank"><?php esc_html_e( 'How do I update my CT Home Valuation license key?', 'contempo' ); ?></a></li>
								<?php endif; ?>
							</ul>
						</div>
						<?php endif; ?>

						<div class="hr-docs-category">
							<h4 class="hr-docs-category__title"><?php esc_html_e( 'Theme &amp; Setup', 'contempo' ); ?></h4>
							<ul class="hr-docs-list">
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-update-the-theme/" target="_blank"><?php esc_html_e( 'How do I update the theme?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-update-my-theme-license-key/" target="_blank"><?php esc_html_e( 'How do I update my theme license key?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/setup-wizard-finished-but-the-demo-isnt-complete/" target="_blank"><?php esc_html_e( 'Setup wizard finished but the demo isn\'t complete?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/skipped-setup-wizard-how-do-i-get-back/" target="_blank"><?php esc_html_e( 'Skipped setup wizard, how do I get back?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-can-i-easily-duplicate-a-page/" target="_blank"><?php esc_html_e( 'How can I easily duplicate a page?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-change-the-secondary-theme-colors/" target="_blank"><?php esc_html_e( 'How do I change the secondary theme colors?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/im-not-seeing-front-end-changes-on-my-site/" target="_blank"><?php esc_html_e( 'I\'m not seeing front-end changes on my site?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/google-maps-arent-working/" target="_blank"><?php esc_html_e( 'Google Maps aren\'t working?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/mobile-menu-isnt-showing/" target="_blank"><?php esc_html_e( 'Mobile menu isn\'t showing?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-add-a-favicon-to-my-site/" target="_blank"><?php esc_html_e( 'How do I add a favicon to my site?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/override-the-parent-theme-footer-sidebar-area-in-child-theme/" target="_blank"><?php esc_html_e( 'Override parent theme footer in child theme', 'contempo' ); ?></a></li>
							</ul>
						</div>

						<div class="hr-docs-category">
							<h4 class="hr-docs-category__title"><?php esc_html_e( 'Elementor', 'contempo' ); ?></h4>
							<ul class="hr-docs-list">
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/im-seeing-a-flash-of-unstyled-content-when-using-elementor/" target="_blank"><?php esc_html_e( 'Flash of unstyled content with Elementor?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-can-i-change-elementor-designs/" target="_blank"><?php esc_html_e( 'How can I change Elementor designs?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/im-seeing-display-issues-on-mobile-in-elementor-pre-built-pages/" target="_blank"><?php esc_html_e( 'I\'m seeing display issues on mobile in Elementor pre-built pages?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-create-a-full-width-page-using-elementor/" target="_blank"><?php esc_html_e( 'How do I create a Full-Width Page using Elementor?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/imported-elementor-9-and-im-not-seeing-page-header-images/" target="_blank"><?php esc_html_e( 'Imported Elementor 9 and I\'m not seeing page header images?', 'contempo' ); ?></a></li>
							</ul>
						</div>

						<div class="hr-docs-category">
							<h4 class="hr-docs-category__title"><?php esc_html_e( 'Email, Forms &amp; Security', 'contempo' ); ?></h4>
							<ul class="hr-docs-list">
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/im-getting-a-404-page-error/" target="_blank"><?php esc_html_e( 'I\'m getting a 404 page error?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/wordpress-stuck-in-maintenance-mode/" target="_blank"><?php esc_html_e( 'WordPress stuck in maintenance mode?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/im-not-receiving-emails-from-my-site/" target="_blank"><?php esc_html_e( 'I\'m not receiving emails from my site?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/contact-forms-arent-working-or-sending-to-a-404-page/" target="_blank"><?php esc_html_e( 'Contact forms aren\'t working or sending to a 404 page?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-can-i-disable-auto-registration-when-using-contact-forms/" target="_blank"><?php esc_html_e( 'How can I disable auto-registration when using contact forms?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-can-i-reduce-contact-form-spam-on-my-website/" target="_blank"><?php esc_html_e( 'How can I reduce contact form spam on my website?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/missing-strings-in-language-file/" target="_blank"><?php esc_html_e( 'Missing strings in language file?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-can-i-protect-my-wordpress-website-from-bots/" target="_blank"><?php esc_html_e( 'How can I protect my WordPress website from bots?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/docs/bot-protection/" target="_blank"><?php esc_html_e( 'Bot Protection', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-remove-admin-access-for-everyone-but-admins/" target="_blank"><?php esc_html_e( 'How do I remove admin access for everyone but admins?', 'contempo' ); ?></a></li>
							</ul>
						</div>

						<div class="hr-docs-category">
							<h4 class="hr-docs-category__title"><?php esc_html_e( 'Performance, Growth &amp; Hosting', 'contempo' ); ?></h4>
							<ul class="hr-docs-list">
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-can-i-make-my-website-faster/" target="_blank"><?php esc_html_e( 'How can I make my website faster?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-can-i-increase-lead-generation-conversion/" target="_blank"><?php esc_html_e( 'How can I increase lead generation &amp; conversion?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-migrate-my-website-to-cloudways/" target="_blank"><?php esc_html_e( 'How do I migrate my website to Cloudways?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-setup-my-cloudways-hosting-server-application/" target="_blank"><?php esc_html_e( 'How do I setup my Cloudways hosting server &amp; application?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-can-i-build-my-own-custom-header-and-footer/" target="_blank"><?php esc_html_e( 'How can I build my own custom header and footer?', 'contempo' ); ?></a></li>
							</ul>
						</div>

						<?php if ( ! $idx_pro_active ) : ?>
						<div class="hr-docs-category">
							<h4 class="hr-docs-category__title"><?php esc_html_e( 'Listings', 'contempo' ); ?></h4>
							<ul class="hr-docs-list">
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-can-i-create-my-own-single-listing-contact-form/" target="_blank"><?php esc_html_e( 'How can I create my own Single Listing contact form?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-can-i-build-my-own-custom-single-listing-template/" target="_blank"><?php esc_html_e( 'How can I build my own custom single listing template?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-do-i-automatically-publish-listings-to-my-facebook-page/" target="_blank"><?php esc_html_e( 'How do I automatically publish listings to my Facebook page?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/a-quick-guide-on-migrating-to-re7-from-one-of-our-previous-or-other-providers-real-estate-themes/" target="_blank"><?php esc_html_e( 'Migrating to Real Estate 7 from another theme', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/using-wpml-to-translate-the-featured-status/" target="_blank"><?php esc_html_e( 'Using WPML to translate the Featured status', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/listing-markers-are-disappearing-when-using-map-pan-zoom-or-draw/" target="_blank"><?php esc_html_e( 'Listing markers disappearing on map pan/zoom?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/im-being-redirected-back-home-when-trying-to-search-listings/" target="_blank"><?php esc_html_e( 'Being redirected home when searching listings?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/listings-search-is-ignoring-search-parameters/" target="_blank"><?php esc_html_e( 'Listings search is ignoring search parameters?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/header-is-broken-missing-in-listings-search/" target="_blank"><?php esc_html_e( 'Header is broken/missing in Listings Search?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/front-end-registration-isnt-working/" target="_blank"><?php esc_html_e( 'Front end registration isn\'t working?', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/adding-extra-status-flags-in-real-estate-7/" target="_blank"><?php esc_html_e( 'Adding extra status flags in Real Estate 7', 'contempo' ); ?></a></li>
								<li><a href="https://contempothemes.com/wp-real-estate-7/docs/how-can-i-rename-a-custom-field-or-taxonomy/" target="_blank"><?php esc_html_e( 'How can I rename a custom field or taxonomy?', 'contempo' ); ?></a></li>
							</ul>
						</div>
						<?php endif; ?>

					</div><!-- .hr-support-grid -->
					</div><!-- #hr-panel-support -->

					<!-- Changelog panel -->
					<div class="hr-panel panel-left" id="hr-panel-updates">
						<?php
							$wp_filesystem         = new WP_Filesystem_Direct( null );
							$ct_changelog_path     = dirname( __FILE__ ) . '/../theme-changelog/index.html';
							$ct_changelog_contents = $wp_filesystem->get_contents( $ct_changelog_path );
							if ( $ct_changelog_contents ) {
								if ( function_exists( 'ct_sanitize_output' ) ) {
									echo ct_sanitize_output( $ct_changelog_contents );
								} else {
									echo wp_kses_post( $ct_changelog_contents );
								}
							}
						?>
					</div><!-- #hr-panel-updates -->

				</div><!-- .hr-content -->

				<!-- ============================================================
				     Right sidebar
				     ========================================================== -->
				<aside class="hr-aside">

					<div class="hr-aside-card">
						<h4 class="hr-aside-card__title"><?php esc_html_e( 'Need Modifications or Customizations?', 'contempo' ); ?></h4>
						<p><?php
							$ct_setup_url = 'https://contempothemes.com/real-estate-7-pricing/real-estate-website-setup-and-customizations/';
							printf(
								wp_kses( __( 'See <a href="%s" target="_blank">Setup &amp; Customizations Pricing</a>. We\'re available for basic &amp; full site setups, design, maintenance, and development — all direct, never outsourced.', 'contempo' ), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ),
								esc_url( $ct_setup_url )
							);
						?></p>
					</div>

					<div class="hr-aside-card">
						<h4 class="hr-aside-card__title"><?php esc_html_e( 'Hosting Recommendations', 'contempo' ); ?></h4>
						<p><?php
							printf(
								wp_kses( __( 'We recommend <a href="%s" target="_blank">Cloudways</a> — the same platform our demos run on. Very fast, easily scalable, free migration, and great support.', 'contempo' ), array( 'a' => array( 'href' => array(), 'target' => array() ), 'strong' => array() ) ),
								'https://www.cloudways.com/en/?id=128386'
							);
						?></p>
					</div>

				</aside><!-- .hr-aside -->

			</div><!-- .hr-body -->

		</div><!-- .hr-wrap -->
		<?php
	}
}
