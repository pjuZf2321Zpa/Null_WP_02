/**
 * Help & Resources
 *
 * @package WP Pro Real Estate 7
 * @subpackage JavaScript
 */

jQuery( document ).ready( function ( $ ) {

	var $items   = $( '.hr-nav__list li' );
	var $content = $( '.hr-content' );
	var tabs     = [ 'docs', 'faq-support', 'changelog' ];

	function hashToIndex( hash ) {
		var map = { '#docs': 0, '#faq-support': 1, '#changelog': 2 };
		return map.hasOwnProperty( hash ) ? map[ hash ] : 0;
	}

	function activateTab( index ) {
		$items.removeClass( 'current' ).eq( index ).addClass( 'current' );
		$content.attr( 'data-tab', tabs[ index ] );
	}

	// Switch tab on click and push hash to URL without page scroll
	$items.each( function ( i ) {
		$( this ).on( 'click', function ( e ) {
			e.preventDefault();
			var hash = $( this ).find( 'a' ).attr( 'href' );
			history.pushState( null, '', hash );
			activateTab( i );
		} );
	} );

	// Handle browser back/forward navigation
	$( window ).on( 'popstate', function () {
		activateTab( hashToIndex( window.location.hash || '#docs' ) );
	} );

} );
