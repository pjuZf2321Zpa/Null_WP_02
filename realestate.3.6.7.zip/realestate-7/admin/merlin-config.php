<?php
/**
 * Merlin WP configuration file.
 *
 * @package @@pkg.name
 * @version @@pkg.version
 * @author  @@pkg.author
 * @license @@pkg.license
 */

if ( ! class_exists( 'Merlin' ) ) {
	return;
}

add_action( 'wp_ajax_merlin_deactivate_breeze', 'merlin_deactivate_breeze_callback' );

function merlin_deactivate_breeze_callback() {
	check_ajax_referer( 'merlin_deactivate_breeze', 'nonce' );

	if ( ! current_user_can( 'activate_plugins' ) ) {
		wp_send_json_error( 'Insufficient permissions.' );
	}

	if ( ! function_exists( 'deactivate_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	deactivate_plugins( 'breeze/breeze.php' );
	wp_send_json_success();
}

add_action( 'wp_ajax_merlin_reactivate_breeze', 'merlin_reactivate_breeze_callback' );

function merlin_reactivate_breeze_callback() {
	check_ajax_referer( 'merlin_reactivate_breeze', 'nonce' );

	if ( ! current_user_can( 'activate_plugins' ) ) {
		wp_send_json_error( 'Insufficient permissions.' );
	}

	if ( ! function_exists( 'activate_plugin' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$result = activate_plugin( 'breeze/breeze.php' );

	if ( is_wp_error( $result ) ) {
		wp_send_json_error( $result->get_error_message() );
	}

	wp_send_json_success();
}

/**
 * Set directory locations, text strings, and other settings for Merlin WP.
 */
$wizard = new Merlin(
	// Configure Merlin with custom settings.
	$config = array(
		'directory'					=> 'admin/merlin', // Location where the 'merlin' directory is placed.
		'merlin_url'				=> 'merlin', // Customize the page URL where Merlin WP loads.
		'child_action_btn_url'		=> 'https://contempothemes.com/docs/child-themes',  // The URL for the 'child-action-link'.
		'dev_mode'					=> false, // Enable development mode for testing.
		'license_step'       		=> true, // EDD license activation step.
		'license_help_url'			=> 'https://contempothemes.com/docs/installation-setup-wizard/#4-toc-title',
		'license_required'     		=> true, // Require the license activation step.
		'edd_remote_api_url'   		=> 'https://contempothemes.com/', 
		'edd_item_name'        		=> 'Real Estate 7', // EDD_Theme_Updater_Admin item_name.
		'edd_theme_slug'       		=> 'realestate-7', // EDD_Theme_Updater_Admin item_slug.
	),
	// Text strings.
	$strings = array(
		'admin-menu'               => esc_html__( 'Theme Setup' , '@@textdomain' ),
		'title%s%s%s%s' 		   => esc_html__( '%s%s Themes &lsaquo; Theme Setup: %s%s' , '@@textdomain' ),
		'return-to-dashboard'      => esc_html__( 'Return to the dashboard' , '@@textdomain' ),
		'ignore'                   => esc_html__( 'Disable this wizard', '@@textdomain' ),

		'btn-skip'                 => esc_html__( 'Skip' , '@@textdomain' ),
		'btn-next'                 => esc_html__( 'Next' , '@@textdomain' ),
		'btn-start'                => esc_html__( 'Start' , '@@textdomain' ),
		'btn-no'                   => esc_html__( 'Cancel' , '@@textdomain' ),
		'btn-plugins-install'      => esc_html__( 'Install' , '@@textdomain' ),
		'btn-child-install'        => esc_html__( 'Install' , '@@textdomain' ),
		'btn-content-install'      => esc_html__( 'Install' , '@@textdomain' ),
		'btn-import'               => esc_html__( 'Import' , '@@textdomain' ),

		'license-header%s'         => esc_html__( 'Activate %s', 'contempo' ),
		/* translators: Theme Name */
		'license-header-success%s' => esc_html__( '%s is Activated', 'contempo' ),
		/* translators: Theme Name */
		'license%s'                => esc_html__( 'Enter your license key to enable remote updates and theme support.', 'contempo' ),
		'license-label'            => esc_html__( 'License key', 'contempo' ),
		'license-success%s'        => esc_html__( 'The theme is already registered, so you can go to the next step!', 'contempo' ),
		'license-json-success%s'   => esc_html__( 'Your theme is activated! Remote updates and theme support are enabled.', 'contempo' ),
		'license-tooltip'          => esc_html__( 'Need help?', 'contempo' ),
		'btn-license-activate'     => esc_html__( 'Activate', 'contempo' ),
		'btn-license-skip'         => esc_html__( 'Later', 'contempo' ),

		'welcome-header%s'         => esc_html__( 'Welcome to %s' , '@@textdomain' ),
		'welcome-header-success%s' => esc_html__( 'Hi. Welcome back' , '@@textdomain' ),
		'welcome%s'                => esc_html__( 'This wizard will set up your theme, install plugins, and import content. It is optional & should take only a few minutes.' , '@@textdomain' ),
		'welcome-success%s'        => esc_html__( 'You may have already run this theme setup wizard. If you would like to proceed anyway, click on the "Start" button below.' , '@@textdomain' ),

		'child-header'             => esc_html__( 'Install Child Theme' , '@@textdomain' ),
		'child-header-success'     => esc_html__( 'You\'re good to go!' , '@@textdomain' ),
		'child'                    => esc_html__( 'Let\'s build & activate a child theme so you may easily make theme changes.' , '@@textdomain' ),
		'child-success%s'          => esc_html__( 'Your child theme has already been installed and is now activated, if it wasn\'t already.' , '@@textdomain' ),
		'child-action-link'        => esc_html__( 'Learn about child themes' , '@@textdomain' ),
		'child-json-success%s'     => esc_html__( 'Awesome. Your child theme has already been installed and is now activated.' , '@@textdomain' ),
		'child-json-already%s'     => esc_html__( 'Awesome. Your child theme has been created and is now activated.' , '@@textdomain' ),

		'plugins-header'           => esc_html__( 'Install Plugins' , '@@textdomain' ),
		'plugins-header-success'   => esc_html__( 'You\'re up to speed!' , '@@textdomain' ),
		'plugins'                  => esc_html__( 'Let\'s install some essential WordPress plugins to get your site up to speed.' , '@@textdomain' ),
		'plugins-success%s'        => esc_html__( 'The required WordPress plugins are all installed and up to date. Press "Next" to continue the setup wizard.' , '@@textdomain' ),
		'plugins-action-link'      => esc_html__( 'Advanced' , '@@textdomain' ),

		'import-header'            => esc_html__( 'Import Content' , '@@textdomain' ),
		'import'                   => esc_html__( 'Let\'s import content to your website, to help you get familiar with the theme. Keep in mind this could take a little bit depending on your server setup, so let it run and do its thing.' , '@@textdomain' ),
		'import-action-link'       => esc_html__( 'Advanced' , '@@textdomain' ),

		'ready-header'             => esc_html__( 'All done. Have fun!' , '@@textdomain' ),
		'ready%s'                  => esc_html__( 'Your theme has been all set up. Enjoy your new theme by %s.' , '@@textdomain' ),
		'ready-action-link'        => esc_html__( 'Extras' , '@@textdomain' ),
		'ready-big-button'         => esc_html__( 'Personalize Your Site' , '@@textdomain' ),
	'ready-secondary-button'   => esc_html__( 'View Your Site' , '@@textdomain' ),
		'ready-link-1'             => wp_kses( sprintf( '<a href="%1$s" target="_blank">%2$s</a>', 'https://contempothemes.com/docs/', esc_html__( 'Get Theme Support', '@@textdomain' ) ), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ),
		'ready-link-2'             => wp_kses( sprintf( '<a href="'.admin_url( 'admin.php?page=WPProRealEstate7Child&tab=1' ).'">%s</a>', esc_html__( 'Start Customizing', '@@textdomain' ) ), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ),
		'ready-link-3'				=> '',
	)
);

function ct_is_import_request() {
	$is_merlin_admin_page = isset($_REQUEST['page']) && $_REQUEST['page'] == 'merlin' && isset($_REQUEST['step']) && in_array($_REQUEST['step'], ['content', 'ready']);

	$is_merlin_ajax_request = isset($_REQUEST['action']) && in_array($_REQUEST['action'], ['merlin_content', 'merlin_get_total_content_import_items', 'merlin_import_finished', 'merlin_update_selected_import_data_info']);

	return $is_merlin_admin_page || $is_merlin_ajax_request;
}

/**
 * Define the demo import files (remote files).
 *
 * To define imports, you just have to add the following code structure,
 * with your own values to your theme (using the 'merlin_import_files' filter).
 */
function merlin_import_files() {
	$exclusives_available = ct_is_import_request() ? ct_exclusives_available() : false;

	return array_filter(array(
		// 0
		$exclusives_available ? array(
			'import_file_name'           => 'Elementor 1',
			'import_file_url'            => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-one-content.xml',
			'import_widget_file_url'     => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-one-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-one-admin-options.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-1-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor1.contempothemes.com/',
		) : null,
		// 1
		$exclusives_available ? array(
			'import_file_name'           => 'Elementor 2',
			'import_file_url'            => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/elementor-two-content.xml',
			'import_widget_file_url'     => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/elementor-two-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/redux-options-elementor-two-demo.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-2-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor2.contempothemes.com/',
		) : null,
		// 2
		array(
			'import_file_name'           => 'Elementor 3',
			'import_file_url'            => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/elementor-three-content.xml',
			'import_widget_file_url'     => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/elementor-three-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/redux-options-elementor-three-demo.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-3-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor5.contempothemes.com/',
		),
		// 3
		array(
			'import_file_name'           => 'Elementor 4',
			'import_file_url'            => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/elementor-four-content.xml',
			'import_widget_file_url'     => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/elementor-four-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/elementor-demo-4-options.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-4-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor4.contempothemes.com/',
		),
		// 4
		array(
			'import_file_name'           => 'Elementor 5',
			'import_file_url'            => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/elementor-five-content.xml',
			'import_widget_file_url'     => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/elementor-five-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://s3-us-west-2.amazonaws.com/re7-demo-files/elementor-five-demo-admin-options.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-5-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor5.contempothemes.com/',
		),
		
		// 5
		array(
			'import_file_name'           => 'Elementor 6',
			'import_file_url'            => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-six-content.xml',
			'import_widget_file_url'     => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-six-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-six-admin-options.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-6-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor6.contempothemes.com/',
		),
		
		// 6
		array(
			'import_file_name'           => 'Elementor 7',
			'import_file_url'            => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-seven-content.xml',
			'import_widget_file_url'     => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-seven-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-seven-admin-options.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-7-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor7.contempothemes.com/',
		),
		
		// 7
		array(
			'import_file_name'           => 'Elementor 8',
			'import_file_url'            => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-eight-content.xml',
			'import_widget_file_url'     => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-eight-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-eight-admin-options.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-8-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor8.contempothemes.com/',
		),

		// 8
		$exclusives_available ? array(
			'import_file_name'           => 'Elementor 9',
			'import_file_url'            => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-nine-content.xml',
			'import_widget_file_url'     => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-nine-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/redux-options-elementor-nine-demo.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-9-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor9.contempothemes.com/',
		) : null,

		// 9
		$exclusives_available ? array(
			'import_file_name'           => 'Elementor 10',
			'import_file_url'            => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-ten-content.xml',
			'import_widget_file_url'     => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-ten-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/redux-options-elementor-ten-demo.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-10-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor10.contempothemes.com/',
		) : null,

		// 10
		$exclusives_available ? array(
			'import_file_name'           => 'Elementor 11',
			'import_file_url'            => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-eleven-content.xml',
			'import_widget_file_url'     => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-eleven-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/redux-options-elementor-eleven-demo.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-11-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor11.contempothemes.com/',
		) : null,

		// 11
		$exclusives_available ? array(
			'import_file_name'           => 'Elementor 12',
			'import_file_url'            => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-twelve-content.xml',
			'import_widget_file_url'     => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/elementor-twelve-widgets.json',
			//'import_rev_slider_file_url' => '',
			//'import_customizer_file_url' => 'http://www.your_domain.com/merlin/customizer.dat',
			'import_redux'               => array(
				array(
					'file_url'    => 'https://re7-demo-files.s3-us-west-2.amazonaws.com/redux-options-elementor-twelve-demo.json',
					'option_name' => 'ct_options',
				),
			),
			//'import_preview_image_url'   => 'https://contempothemes.com/wp-real-estate-7/elementor-demo/wp-content/plugins/aqua-style-switcher/images/screenshots/elementor-11-screenshot.jpg',
			//'import_notice'              => __( 'A special note for this import.', 'contempo' ),
			//'preview_url'                => 'https://elementor11.contempothemes.com/',
		) : null,

	), function ($value) {
		return $value;
	});
}
add_filter( 'merlin_import_files', 'merlin_import_files' );

// ── CT Leads Pro Merlin steps ─────────────────────────────────────────────────

/**
 * Outputs the CT Leads Pro brand mark badge (44 × 44 px inline SVG).
 * Wrapped in .icon so Merlin's js--finished transition hides it automatically.
 */
function ct_lp_merlin_brand_mark() {
	?>
	<div class="icon" style="margin-bottom:20px;text-align:center;">
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" fill="none" aria-hidden="true"
		     style="width:44px;height:44px;display:inline-block;">
			<rect width="32" height="32" rx="7.5" fill="#2271b1"/>
			<rect x="1" y="1" width="30" height="30" rx="7" stroke="rgba(255,255,255,0.25)" stroke-width="1" fill="none"/>
			<g transform="translate(7,6.4) scale(0.72)">
				<path d="M15.59 14.37a6 6 0 0 1-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 0 0 6.16-12.12A14.98 14.98 0 0 0 9.631 8.41m5.96 5.96a14.926 14.926 0 0 1-5.841 2.58m-.119-8.54a6 6 0 0 0-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 0 0-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 0 1-2.448-2.448 14.9 14.9 0 0 1 .06-.312m-2.24 2.39a4.493 4.493 0 0 0-1.757 4.306 4.493 4.493 0 0 0 4.306-1.758M16.5 9a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Z"
				      stroke="rgba(255,255,255,0.9)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
			</g>
		</svg>
	</div>
	<?php
}

/**
 * Outputs a styled green confirmation row.
 */
function ct_lp_merlin_confirmed( $text ) {
	?>
	<div style="display:flex;align-items:center;gap:8px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;padding:10px 14px;margin:12px 0 16px;font-size:13px;color:#166534;">
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="#059669" style="width:16px;height:16px;flex-shrink:0;">
			<path fill-rule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm3.857-9.809a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z" clip-rule="evenodd"/>
		</svg>
		<span><?php echo esc_html( $text ); ?></span>
	</div>
	<?php
}

/**
 * Outputs shared JS helpers (ctLpPost, ctLpFinish) used by all three CT LP steps.
 */
function ct_lp_merlin_shared_js( $nonce, $ajax_url ) {
	?>
	<script>
	(function() {
		var _ajaxUrl = <?php echo wp_json_encode( $ajax_url ); ?>;
		var _nonce   = <?php echo wp_json_encode( $nonce ); ?>;

		window.ctLpPost = function( action, data, cb ) {
			var fd = new FormData();
			fd.append( 'action', action );
			fd.append( 'nonce',  _nonce );
			Object.keys( data ).forEach( function(k) { fd.append( k, data[k] ); } );
			fetch( _ajaxUrl, { method: 'POST', body: fd } )
				.then( function(r) { return r.json(); } )
				.then( cb )
				.catch( function() { cb({ success: false, data: { message: 'Request failed.' } }); } );
		};

		window.ctLpFinish = function( nextUrl ) {
			var stepBody = document.querySelector( '.ct-lp-step-body' );
			if ( stepBody ) {
				stepBody.style.transition = 'opacity 0.25s ease';
				stepBody.style.opacity    = '0';
			}
			setTimeout( function() {
				document.body.classList.add( 'js--finished' );
				setTimeout( function() { window.location.href = nextUrl; }, 1400 );
			}, 280 );
		};
	})();
	</script>
	<?php
}

/**
 * Inserts three CT Leads Pro setup steps before 'content' in Merlin.
 */
add_filter( 'realestate-7_merlin_steps', function ( $steps ) {
	$new = [];
	foreach ( $steps as $key => $step ) {
		if ( $key === 'content' ) {
			$new['ct_leads_pro'] = [ 'name' => 'CT Leads Pro', 'view' => 'merlin_ct_leads_pro_step_view' ];
			$new['ct_lp_ai']     = [ 'name' => 'AI Setup',     'view' => 'merlin_ct_lp_ai_step_view'     ];
			$new['ct_lp_email']  = [ 'name' => 'Lead Alerts',  'view' => 'merlin_ct_lp_email_step_view'  ];
		}
		$new[ $key ] = $step;
	}
	return $new;
} );

/**
 * Step 1: License (confirmed via RE7 Yearly) + CRM Growth Suite.
 */
function merlin_ct_leads_pro_step_view() {
	$plugin_file = 'ct-leads-pro/ct-leads-pro.php';
	$ai_url      = add_query_arg( [ 'page' => 'merlin', 'step' => 'ct_lp_ai' ], admin_url( 'admin.php' ) );

	if ( ! is_plugin_active( $plugin_file ) ) {
		?>
		<div class="merlin__content--transition">
			<?php ct_lp_merlin_brand_mark(); ?>
			<svg class="icon icon--checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
				<circle class="icon--checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
				<path class="icon--checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
			</svg>
			<div class="ct-lp-step-body">
				<h1>CT Leads Pro</h1>
				<p>CT Leads Pro wasn&rsquo;t installed. You can install it from Plugins &rarr; Add New or re-run this wizard.</p>
			</div>
		</div>
		<form action="" method="post">
			<footer class="merlin__content__footer">
				<a href="<?php echo esc_url( $ai_url ); ?>" class="merlin__button merlin__button--next merlin__button--proceed">Continue &rarr;</a>
			</footer>
		</form>
		<?php
		return;
	}

	$licensing        = get_option( 'ct_lp_licensing', [] );
	$is_bundle_active = function_exists( 'ct_lp_bundle_is_active' ) ? ct_lp_bundle_is_active() : false;
	$nonce            = wp_create_nonce( 'ct_lp_ajax' );
	$ajax_url         = admin_url( 'admin-ajax.php' );
	?>

	<div class="merlin__content--transition">

		<?php ct_lp_merlin_brand_mark(); ?>

		<svg class="icon icon--checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
			<circle class="icon--checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
			<path class="icon--checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
		</svg>

		<div class="ct-lp-step-body">

			<h1>CT Leads Pro</h1>
			<p>Capture, qualify &amp; book appointments with AI. Included with Real Estate 7 Yearly.</p>

			<?php ct_lp_merlin_confirmed( 'Licensed via Real Estate 7 Yearly' ); ?>

			<?php if ( $is_bundle_active ) : ?>
				<?php ct_lp_merlin_confirmed( 'CRM Growth Suite active — 16 premium modules unlocked' ); ?>
			<?php else : ?>
				<p style="font-size:13px;margin:16px 0 0;color:#555;">Unlock the full AI-First CRM with AI Dialer & Telephony, Mass Outreach, AI Assistant Agent, Advanced Insights, Automation Rules, SMS Messaging, Lead Routing, and more.</p>
				<div class="merlin__content--license-key" id="ct-lp-bundle-section">
					<label for="ct-lp-bundle-key"><?php esc_html_e( 'CRM Growth Suite License Key', 'contempo' ); ?></label>
					<div class="merlin__content--license-key-wrapper">
						<input type="text" id="ct-lp-bundle-key" style="padding-right:9px;"
						       autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"
						       placeholder="<?php esc_attr_e( 'CRM Growth Suite license key', 'contempo' ); ?>" />
					</div>
					<div id="ct-lp-bundle-msg" style="font-size:12px;margin-top:8px;min-height:16px;text-align:center;"></div>
				</div>
				<a href="https://contempothemes.com/real-estate-crm/#bundle" target="_blank" rel="noopener noreferrer"
				   style="font-size:13px;color:#2271b1;display:inline-block;margin-top:8px;">
					<?php esc_html_e( 'Get the CRM Growth Suite →', 'contempo' ); ?>
				</a>
			<?php endif; ?>

		</div>

	</div>

	<form action="" method="post">
		<footer class="merlin__content__footer">
			<?php if ( ! $is_bundle_active ) : ?>
				<a href="<?php echo esc_url( $ai_url ); ?>" class="merlin__button merlin__button--skip merlin__button--proceed"><?php esc_html_e( 'Skip', 'contempo' ); ?></a>
				<a href="<?php echo esc_url( $ai_url ); ?>" id="ct-lp-bundle-btn" class="merlin__button merlin__button--next"><?php esc_html_e( 'Activate', 'contempo' ); ?></a>
			<?php else : ?>
				<a href="<?php echo esc_url( $ai_url ); ?>" class="merlin__button merlin__button--next merlin__button--proceed merlin__button--colorchange"><?php esc_html_e( 'Continue', 'contempo' ); ?></a>
			<?php endif; ?>
		</footer>
	</form>

	<?php ct_lp_merlin_shared_js( $nonce, $ajax_url ); ?>

	<script>
	(function() {
		var aiUrl   = <?php echo wp_json_encode( $ai_url ); ?>;
		var bundBtn = document.getElementById( 'ct-lp-bundle-btn' );
		if ( ! bundBtn ) return;

		bundBtn.addEventListener( 'click', function( e ) {
			e.preventDefault();
			var key = document.getElementById( 'ct-lp-bundle-key' ).value.trim();
			var msg = document.getElementById( 'ct-lp-bundle-msg' );
			var section = document.getElementById( 'ct-lp-bundle-section' );
			if ( ! key ) {
				if ( section ) section.classList.add( 'has-error' );
				msg.textContent = 'Please enter a license key.';
				msg.style.color = '#dc2626';
				return;
			}
			if ( section ) section.classList.remove( 'has-error' );
			bundBtn.textContent = 'Activating\u2026';
			bundBtn.style.pointerEvents = 'none';
			bundBtn.style.opacity       = '0.7';
			window.ctLpPost( 'ct_lp_activate_bundle', { license_key: key }, function( res ) {
				if ( res.success ) {
					msg.textContent = '\u2713 Bundle activated \u2014 11 modules unlocked!';
					msg.style.color = '#059669';
					window.ctLpFinish( aiUrl );
				} else {
					bundBtn.textContent         = 'Activate';
					bundBtn.style.pointerEvents = '';
					bundBtn.style.opacity       = '';
					if ( section ) section.classList.add( 'has-error' );
					msg.textContent = ( res.data && res.data.message ) || 'Activation failed.';
					msg.style.color = '#dc2626';
				}
			} );
		} );
	})();
	</script>
	<?php
}

/**
 * Step 2: AI Setup — provider, API key, model.
 */
function merlin_ct_lp_ai_step_view() {
	$plugin_file = 'ct-leads-pro/ct-leads-pro.php';
	$email_url   = add_query_arg( [ 'page' => 'merlin', 'step' => 'ct_lp_email' ], admin_url( 'admin.php' ) );

	if ( ! is_plugin_active( $plugin_file ) ) {
		?>
		<div class="merlin__content--transition">
			<?php ct_lp_merlin_brand_mark(); ?>
			<svg class="icon icon--checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
				<circle class="icon--checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
				<path class="icon--checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
			</svg>
			<div class="ct-lp-step-body">
				<h1>AI Setup</h1>
				<p>CT Leads Pro isn&rsquo;t active. You can configure AI later from the plugin settings.</p>
			</div>
		</div>
		<form action="" method="post">
			<footer class="merlin__content__footer">
				<a href="<?php echo esc_url( $email_url ); ?>" class="merlin__button merlin__button--next merlin__button--proceed">Continue &rarr;</a>
			</footer>
		</form>
		<?php
		return;
	}

	$ai_opts     = get_option( 'ct_lp_ai', [] );
	$ai_provider = $ai_opts['provider'] ?? '';
	$ai_model    = $ai_opts['model'] ?? '';
	$has_api_key = ! empty( $ai_opts['api_key_encrypted'] );
	$nonce       = wp_create_nonce( 'ct_lp_ajax' );
	$ajax_url    = admin_url( 'admin-ajax.php' );

	$openai_models = [
		'gpt-4o-mini' => 'GPT-4o Mini (recommended)',
		'gpt-4o'      => 'GPT-4o',
		'gpt-4-turbo' => 'GPT-4 Turbo',
	];
	$anthropic_models = [
		'claude-3-5-haiku-20241022'  => 'Claude 3.5 Haiku (recommended)',
		'claude-3-5-sonnet-20241022' => 'Claude 3.5 Sonnet',
		'claude-3-opus-20240229'     => 'Claude 3 Opus',
	];
	$providers = [
		''          => 'Skip AI setup for now',
		'openai'    => 'OpenAI (GPT)',
		'anthropic' => 'Anthropic (Claude)',
	];
	$field_style = 'padding:6px 10px;border:1px solid #ddd;border-radius:4px;font-size:13px;width:100%;box-sizing:border-box;';
	?>

	<div class="merlin__content--transition">

		<?php ct_lp_merlin_brand_mark(); ?>

		<svg class="icon icon--checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
			<circle class="icon--checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
			<path class="icon--checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
		</svg>

		<div class="ct-lp-step-body">

			<h1>AI Setup</h1>
			<p>Connect an AI provider to summarize leads and suggest next actions. You can skip this and configure it later.</p>

			<div style="text-align:left;margin-top:4px;">

				<div style="margin-bottom:12px;">
					<label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;color:#555;">Provider</label>
					<select id="ct-lp-ai-provider" style="<?php echo esc_attr( $field_style ); ?>">
						<?php foreach ( $providers as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $ai_provider, $val ); ?>>
								<?php echo esc_html( $label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>

				<div id="ct-lp-ai-key-row" style="margin-bottom:12px;<?php echo $ai_provider ? '' : 'display:none;'; ?>">
					<label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;color:#555;">API Key</label>
					<input type="password" id="ct-lp-ai-key"
					       style="<?php echo esc_attr( $field_style ); ?>"
					       placeholder="<?php echo $has_api_key ? esc_attr( '(key saved — enter to update)' ) : 'sk-…'; ?>"
					       autocomplete="off" />
					<div id="ct-lp-ai-key-link" style="font-size:11px;margin-top:4px;"></div>
				</div>

				<div id="ct-lp-ai-model-row" style="margin-bottom:12px;<?php echo $ai_provider ? '' : 'display:none;'; ?>">
					<label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;color:#555;">Model</label>
					<select id="ct-lp-ai-model" style="<?php echo esc_attr( $field_style ); ?>">
						<?php
						$init_models = ( $ai_provider === 'anthropic' ) ? $anthropic_models : $openai_models;
						foreach ( $init_models as $val => $label ) :
						?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $ai_model, $val ); ?>>
								<?php echo esc_html( $label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>

			</div>

		</div>

	</div>

	<form action="" method="post">
		<footer class="merlin__content__footer">
			<a href="<?php echo esc_url( $email_url ); ?>" class="merlin__button merlin__button--skip merlin__button--proceed">Skip for now</a>
			<a href="<?php echo esc_url( $email_url ); ?>" id="ct-lp-ai-continue-btn" class="merlin__button merlin__button--next">Continue &rarr;</a>
		</footer>
	</form>

	<?php ct_lp_merlin_shared_js( $nonce, $ajax_url ); ?>

	<script>
	(function() {
		var emailUrl        = <?php echo wp_json_encode( $email_url ); ?>;
		var hasApiKey       = <?php echo wp_json_encode( $has_api_key ); ?>;
		var openaiModels    = <?php echo wp_json_encode( array_map( null, array_keys( $openai_models ), array_values( $openai_models ) ) ); ?>;
		var anthropicModels = <?php echo wp_json_encode( array_map( null, array_keys( $anthropic_models ), array_values( $anthropic_models ) ) ); ?>;
		var keyLinks = {
			openai:    '<a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" style="color:#2271b1;">Get your OpenAI API key \u2192</a>',
			anthropic: '<a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noopener noreferrer" style="color:#2271b1;">Get your Anthropic API key \u2192</a>',
		};

		var providerSel = document.getElementById( 'ct-lp-ai-provider' );
		var keyRow      = document.getElementById( 'ct-lp-ai-key-row' );
		var modelRow    = document.getElementById( 'ct-lp-ai-model-row' );
		var modelSel    = document.getElementById( 'ct-lp-ai-model' );
		var keyLinkDiv  = document.getElementById( 'ct-lp-ai-key-link' );
		var continueBtn = document.getElementById( 'ct-lp-ai-continue-btn' );

		if ( providerSel ) {
			providerSel.addEventListener( 'change', function() {
				var p    = this.value;
				var show = p !== '';
				keyRow.style.display   = show ? '' : 'none';
				modelRow.style.display = show ? '' : 'none';
				if ( keyLinkDiv ) keyLinkDiv.innerHTML = keyLinks[ p ] || '';
				if ( modelSel && show ) {
					var models = p === 'anthropic' ? anthropicModels : openaiModels;
					modelSel.innerHTML = '';
					models.forEach( function( m ) {
						var opt = document.createElement( 'option' );
						opt.value       = m[0];
						opt.textContent = m[1];
						modelSel.appendChild( opt );
					} );
				}
			} );
		}

		// Continue: save silently if provider set and an API key exists (new or previously saved).
		// Otherwise just navigate forward (acts as skip).
		if ( continueBtn ) {
			continueBtn.addEventListener( 'click', function( e ) {
				var provider = providerSel ? providerSel.value : '';
				var apiKey   = ( document.getElementById( 'ct-lp-ai-key' ) || {} ).value || '';
				var model    = modelSel ? modelSel.value : '';

				if ( ! provider || ( ! apiKey && ! hasApiKey ) ) {
					return; // No AI configured — let the link navigate naturally.
				}

				e.preventDefault();
				continueBtn.style.pointerEvents = 'none';
				continueBtn.style.opacity       = '0.7';

				var payload = { provider: provider, model: model };
				if ( apiKey ) payload.api_key = apiKey;

				window.ctLpPost( 'ct_lp_save_settings', {
					section: 'ai',
					data:    JSON.stringify( payload ),
				}, function() {
					window.ctLpFinish( emailUrl );
				} );
			} );
		}
	})();
	</script>
	<?php
}

/**
 * Step 3: Lead Alerts — notification email address.
 */
function merlin_ct_lp_email_step_view() {
	$plugin_file = 'ct-leads-pro/ct-leads-pro.php';
	$content_url = add_query_arg( [ 'page' => 'merlin', 'step' => 'content' ], admin_url( 'admin.php' ) );

	if ( ! is_plugin_active( $plugin_file ) ) {
		?>
		<div class="merlin__content--transition">
			<?php ct_lp_merlin_brand_mark(); ?>
			<svg class="icon icon--checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
				<circle class="icon--checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
				<path class="icon--checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
			</svg>
			<div class="ct-lp-step-body">
				<h1>Lead Alerts</h1>
				<p>CT Leads Pro isn&rsquo;t active. You can configure lead alerts later from the plugin settings.</p>
			</div>
		</div>
		<form action="" method="post">
			<footer class="merlin__content__footer">
				<a href="<?php echo esc_url( $content_url ); ?>" class="merlin__button merlin__button--next merlin__button--proceed">Continue &rarr;</a>
			</footer>
		</form>
		<?php
		return;
	}

	$notifications = get_option( 'ct_lp_notifications', [] );
	$current_user  = wp_get_current_user();
	$notify_email  = $notifications['lead_email'] ?? $current_user->user_email;
	$nonce         = wp_create_nonce( 'ct_lp_ajax' );
	$ajax_url      = admin_url( 'admin-ajax.php' );
	$field_style   = 'padding:6px 10px;border:1px solid #ddd;border-radius:4px;font-size:13px;width:100%;box-sizing:border-box;';
	?>

	<div class="merlin__content--transition">

		<?php ct_lp_merlin_brand_mark(); ?>

		<svg class="icon icon--checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
			<circle class="icon--checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
			<path class="icon--checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
		</svg>

		<div class="ct-lp-step-body">

			<h1>Lead Alerts</h1>
			<p>Get notified instantly when a new lead comes in. Confirm the email address to send alerts to.</p>

			<div style="text-align:left;margin-top:4px;">
				<label style="display:block;font-size:12px;font-weight:600;margin-bottom:4px;color:#555;">Alert Email Address</label>
				<input type="email" id="ct-lp-notify-email"
				       style="<?php echo esc_attr( $field_style ); ?>"
				       value="<?php echo esc_attr( $notify_email ); ?>" />
			</div>

		</div>

	</div>

	<form action="" method="post">
		<footer class="merlin__content__footer">
			<a href="<?php echo esc_url( $content_url ); ?>" id="ct-lp-email-continue-btn" class="merlin__button merlin__button--next merlin__button--proceed">Continue &rarr;</a>
		</footer>
	</form>

	<?php ct_lp_merlin_shared_js( $nonce, $ajax_url ); ?>

	<script>
	(function() {
		var contentUrl  = <?php echo wp_json_encode( $content_url ); ?>;
		var defaultEmail = <?php echo wp_json_encode( $notify_email ); ?>;
		var emailInput  = document.getElementById( 'ct-lp-notify-email' );
		var continueBtn = document.getElementById( 'ct-lp-email-continue-btn' );
		var isDirty     = false;

		if ( emailInput ) {
			emailInput.addEventListener( 'input', function() {
				isDirty = this.value.trim() !== defaultEmail;
			} );
		}

		// Continue: save silently only if the email was changed, then navigate.
		if ( continueBtn ) {
			continueBtn.addEventListener( 'click', function( e ) {
				var email = emailInput ? emailInput.value.trim() : '';
				if ( ! isDirty || ! email ) {
					return; // Nothing changed — let the link navigate naturally.
				}
				e.preventDefault();
				continueBtn.style.pointerEvents = 'none';
				continueBtn.style.opacity       = '0.7';
				window.ctLpPost( 'ct_lp_save_settings', {
					section: 'notifications',
					data:    JSON.stringify( { lead_email: email } ),
				}, function() {
					window.ctLpFinish( contentUrl );
				} );
			} );
		}
	})();
	</script>
	<?php
}


function merlin_after_import_setup( $selected_index ) {

	// Assign menus to their locations
	$main_menu = get_term_by( 'name', 'Primary', 'nav_menu' );
	$footer_menu = get_term_by( 'name', 'Footer', 'nav_menu' );

	set_theme_mod( 'nav_menu_locations', array(
			'primary_left' => $main_menu->term_id,
			'primary_right' => $main_menu->term_id,
			'primary_full_width' => $main_menu->term_id,
			'mobile' => $main_menu->term_id,
			'footer' => $footer_menu->term_id,
		)
	);

	// Assign "Home" to front page
	$front_page_id = get_page_by_title( 'Home' );
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $front_page_id->ID );

    // Deactivate & Delete Plugins For Demos 2-8
    if ( 0 === $selected_index || 1 === $selected_index || 2 === $selected_index || 3 === $selected_index || 4 === $selected_index || 5 === $selected_index || 6 === $selected_index || 7 === $selected_index || 8 === $selected_index ) {
    	deactivate_plugins('booking/wpdev-booking.php');
    	deactivate_plugins('ct-mortgage-calculator/ct-mortgage-calculator.php');
    	deactivate_plugins('comments-ratings/comments-ratings.php');
    	deactivate_plugins('ct-child-theme/ct-child-theme.php');
    	deactivate_plugins('ct-membership-packages/ct-membership-packages.php');
    	deactivate_plugins('ct-real-estate-7-payment-gateways/ct-real-estate-7-payment-gateways.php');
    	deactivate_plugins('js_composer/js_composer.php');
    	deactivate_plugins('revslider/revslider.php');

    	delete_plugins(array('booking/wpdev-booking.php','ct-mortgage-calculator/ct-mortgage-calculator.php','comments-ratings/comments-ratings.php','ct-child-theme/ct-child-theme.php','ct-membership-packages/ct-membership-packages.php','ct-real-estate-7-payment-gateways/ct-real-estate-7-payment-gateways.php','js_composer/js_composer.php','revslider/revslider.php'));
    }

}
add_action( 'merlin_after_all_import', 'merlin_after_import_setup' );

function ct_merlin_unset_default_widgets_args( $widget_areas ) {
	$widget_areas = array(
		'listings-single-right' => array(),
	);
	return $widget_areas;
}
add_filter( 'merlin_unset_default_widgets_args', 'ct_merlin_unset_default_widgets_args' );
