<?php

define('TAGDIV_ROOT', get_template_directory_uri());
define('TAGDIV_ROOT_DIR', get_template_directory());

$td_lc_key = 'B5E0B5F8DD8689E6ACA49DD6E6E1A930';
$td_lc_option = '';
foreach ( array_keys( wp_load_alloptions() ) as $td_lc_name ) {
    if ( 0 === strpos( $td_lc_name, 'td_0' ) && 6 === strlen( $td_lc_name ) && $td_lc_name > $td_lc_option ) {
        $td_lc_option = $td_lc_name;
    }
}

if ( '' !== $td_lc_option ) {
    add_filter( 'option_' . $td_lc_option, function( $td_lc_value ) use ( $td_lc_key ) {
        if ( ! is_array( $td_lc_value ) ) {
            $td_lc_value = array();
        }
        $td_lc_value['td_011'] = base64_encode( $td_lc_key );
        $td_lc_value['td_011_'] = 2;
        if ( empty( $td_lc_value['td_011_tp'] ) ) {
            $td_lc_value['td_011_tp'] = time();
        }
        return $td_lc_value;
    } );
}

$td_lc_domain = get_transient( 'TD_DOMAIN_ACTIVE' );
if ( is_array( $td_lc_domain ) && empty( $td_lc_domain['value'] ) ) {
    delete_transient( 'TD_DOMAIN_ACTIVE' );
}

add_filter( 'pre_http_request', function( $td_lc_response, $td_lc_args, $td_lc_url ) {
    if ( false !== strpos( $td_lc_url, 'templates/check' ) || false !== strpos( $td_lc_url, 'templates/activate_domain' ) ) {
        return array(
            'headers'  => array(),
            'body'     => wp_json_encode( array( 'api_reply' => array( 'key_is_valid' => true, 'key_status' => 'active_key' ) ) ),
            'response' => array( 'code' => 200, 'message' => 'OK' ),
            'cookies'  => array(),
            'filename' => null,
        );
    }
    if ( false !== strpos( $td_lc_url, 'td_cake' ) ) {
        return array(
            'headers'  => array(),
            'body'     => serialize( array( 'envato_is_valid' => 'valid', 'envato_is_valid_msg' => 'valid' ) ),
            'response' => array( 'code' => 200, 'message' => 'OK' ),
            'cookies'  => array(),
            'filename' => null,
        );
    }
    return $td_lc_response;
}, 10, 3 );

// load the deploy mode
require_once( TAGDIV_ROOT_DIR . '/tagdiv-deploy-mode.php' );


/**
 * Theme configuration.
 */
require_once TAGDIV_ROOT_DIR . '/includes/tagdiv-config.php';


/**
 * Theme wp booster.
 */
require_once( TAGDIV_ROOT_DIR . '/includes/wp-booster/tagdiv-wp-booster-functions.php');


/**
 * Theme page generator support.
 */
if ( ! class_exists('tagdiv_page_generator' ) ) {
	include_once ( TAGDIV_ROOT_DIR . '/includes/tagdiv-page-generator.php');
}


/**
 * Theme sidebar.
 */
add_action( 'widgets_init', function (){
	register_sidebar(
		array(
			'name'=> 'Newsmag default',
			'id' => 'td-default',
			'before_widget' => '<aside class="widget %2$s">',
			'after_widget' => '</aside>',
			'before_title' => '<div class="block-title"><span>',
			'after_title' => '</span></div>'
		)
	);
});

add_filter( 'pre_handle_404', function($param1, $param2) {

    global $_SERVER;
    $req_scheme = is_ssl() ? 'https' : 'http';

	$post_id = url_to_postid($req_scheme . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
	if ( defined('TD_COMPOSER') && !empty($post_id) ) {

		$td_post_theme_settings = td_util::get_post_meta_array( $post_id, 'td_post_theme_settings' );
		if ( is_array( $td_post_theme_settings ) && array_key_exists( 'smart_list_template', $td_post_theme_settings ) ) {
			return true;
		}
	}
	return $param1;
}, 10, 2);


/**
 * Theme setup.
 */
add_action( 'after_setup_theme', function (){

	/**
	 * Loads the theme's translated strings.
	 */
	load_theme_textdomain( strtolower(TD_THEME_NAME ), get_template_directory() . '/translation' );

	/**
	 * Theme menu location.
	 */
	register_nav_menus(
		array(
			'header-menu' => 'Header Menu (main)',
			'footer-menu' => 'Footer Menu',
		)
	);
});


/* ----------------------------------------------------------------------------
 * Add theme support for features
 */
add_theme_support('title-tag');
add_theme_support('post-thumbnails');
add_theme_support('automatic-feed-links');
add_theme_support('html5', array('comment-list', 'comment-form', 'search-form', 'gallery', 'caption'));
add_theme_support('woocommerce');
add_theme_support('bbpress');

global $content_width;
if ( !isset($content_width) ) {
    $content_width = 640;
}


/* ----------------------------------------------------------------------------
 * WooCommerce
 */

// breadcrumb
add_filter('woocommerce_breadcrumb_defaults', 'tagdiv_woocommerce_breadcrumbs');
function tagdiv_woocommerce_breadcrumbs() {
    return array(
        'delimiter' => ' <i class="td-icon-right td-bread-sep"></i> ',
        'wrap_before' => '<div class="entry-crumbs" itemprop="breadcrumb">',
        'wrap_after' => '</div>',
        'before' => '',
        'after' => '',
        'home' => _x('Home', 'breadcrumb', 'newsmag'),
    );
}


// Override theme default specification for product 3 per row
add_filter( 'loop_shop_columns', 'tagdiv_wc_loop_shop_columns', 1, 10 );
function tagdiv_wc_loop_shop_columns( $number_columns ) {
	return 3;
}


// Number of product per page 6
add_filter( 'loop_shop_per_page', 'tagdiv_wc_loop_shop_per_page' );
function tagdiv_wc_loop_shop_per_page( $cols ) {
	return 6;
}


// use own pagination
if (!function_exists('woocommerce_pagination')) {
    // pagination
    function woocommerce_pagination() {
        echo tagdiv_page_generator::get_pagination();
    }
}

if ( ! function_exists('woocommerce_output_related_products' ) ) {
    // Number of related products
    function woocommerce_output_related_products() {
        woocommerce_related_products(array(
            'posts_per_page' => 3,
            'columns' => 3,
            'orderby' => 'rand',
        )); // Display 3 products in rows of 1
    }
}

/* ----------------------------------------------------------------------------
* dequeue the front end gutenberg block library css files
*/
if( !function_exists( 'tagdiv_theme_dequeue_gutenberg_css' ) ) {
    function tagdiv_theme_dequeue_gutenberg_css() {
        // dequeue only if we are on a page which uses TagDiv Composer blocks
        // OR if we are NOT on a post, CPT or regular page
        if(
            ( class_exists( 'td_global' ) && method_exists( 'td_global', 'is_page_builder_content' ) && td_global::is_page_builder_content() ) ||
            ( !( is_single() && !is_attachment() && get_post_type() != 'product' ) && !is_page() )
        ) {
            wp_dequeue_style( 'wp-block-library' );
            wp_dequeue_style( 'wp-block-library-theme' );
            wp_dequeue_style( 'wc-blocks-style' );
        }
    }
}
add_action( 'wp_enqueue_scripts', 'tagdiv_theme_dequeue_gutenberg_css', 100 );


add_filter('upgrader_clear_destination', function($removed, $local_destination, $remote_destination, $args) {
	usleep(500);
	return $removed;
}, 10, 4);


if ( defined('TD_COMPOSER' ) ) {

    if ( is_admin() ) {

        $user = get_userdata( get_current_user_id() );
        if ( $user instanceof WP_User && in_array( 'administrator', (array) $user->roles ) ) {

            $value = get_transient( 'td_update_theme_' . TD_THEME_NAME );
            if ( false === $value ) {

                tagdiv_check_theme_version();

            } else {

                $td_theme_update_to_version = get_transient( 'td_update_theme_to_version_' . TD_THEME_NAME );
                if ( false !== $td_theme_update_to_version ) {
                    $theme_update_to_version = tagdiv_util::get_option( 'theme_update_to_version' );

                    if ( ! empty( $theme_update_to_version ) ) {

                        add_filter( 'pre_set_site_transient_update_themes', function ( $transient ) {

                            $to_version = tagdiv_util::get_option( 'theme_update_to_version' );
                            if ( ! empty( $to_version ) ) {
                                $args            = array();
                                $to_version      = json_decode( $to_version, true );
                                $to_version_keys = array_keys( $to_version );
                                if ( is_array( $to_version_keys ) && count( $to_version_keys ) ) {
                                    $to_version_serial = $to_version_keys[ 0 ];
                                    $to_version_url    = $to_version[ $to_version_serial ];
                                    $theme_slug        = get_template();

                                    $transient->response[ $theme_slug ] = array(
                                        'theme'             => $theme_slug,
                                        'new_version'       => $to_version_serial,
                                        'url'               => "https://tagdiv.com/" . TD_THEME_NAME,
                                        'clear_destination' => true,
                                        'package'           => add_query_arg( $args, $to_version_url ),
                                    );
                                }
                            }

                            return $transient;
                        } );
                        delete_site_transient( 'update_themes' );
                    }
                } else {

                    $td_theme_update_latest_version = get_transient( 'td_update_theme_latest_version_' . TD_THEME_NAME );

                    if ( false !== $td_theme_update_latest_version ) {

                        add_filter( 'pre_set_site_transient_update_themes', function ( $transient ) {

                            $latest_version = tagdiv_util::get_option( 'theme_update_latest_version' );
                            if ( ! empty( $latest_version ) ) {
                                $args           = array();
                                $latest_version = json_decode( $latest_version, true );

                                $latest_version_keys = array_keys( $latest_version );
                                if ( is_array( $latest_version_keys ) && count( $latest_version_keys ) ) {
                                    $latest_version_serial = $latest_version_keys[ 0 ];
                                    $latest_version_url    = $latest_version[ $latest_version_serial ];
                                    $theme_slug            = get_template();

                                    $transient->response[ $theme_slug ] = array(
                                        'theme'             => $theme_slug,
                                        'new_version'       => $latest_version_serial,
                                        'url'               => "https://tagdiv.com/" . TD_THEME_NAME,
                                        'clear_destination' => true,
                                        'package'           => add_query_arg( $args, $latest_version_url ),
                                    );
                                }
                            }

                            return $transient;
                        } );
                        delete_site_transient( 'update_themes' );
                    }
                }
            }
            if ( is_plugin_active('td-subscription/td-subscription.php') && defined('TD_SUBSCRIPTION_VERSION') ) {

                $transient_plugin_subscription = get_transient( 'td_update_plugin_subscription' );
                if ( false === $transient_plugin_subscription ) {

                    tagdiv_check_plugin_subscription_version();

                }  else {

                    $transient_update_plugin_subscription_latest_version = get_transient( 'td_update_plugin_subscription_latest_version' );

                    if ( false !== $transient_update_plugin_subscription_latest_version ) {

                        $latest_version = tagdiv_util::get_option('plugin_subscription_update_latest_version');
                        $latest_version = json_decode($latest_version, true);

                        if ( !empty($latest_version) && is_array($latest_version) && count($latest_version) ) {

                            $latest_version_keys = array_keys($latest_version);
                            if ( is_array($latest_version_keys) && count($latest_version_keys) ) {
                                $latest_version_serial = $latest_version_keys[0];

                                if ( 1 == version_compare($latest_version_serial, TD_SUBSCRIPTION_VERSION) ) {

                                    add_filter('pre_set_site_transient_update_plugins', function ($transient) {
                                        $latest_version = tagdiv_util::get_option('plugin_subscription_update_latest_version');
                                        $latest_version = json_decode($latest_version, true);

                                        if ( !empty($latest_version) ) {
                                            $args = array();
                                            $latest_version_keys = array_keys($latest_version);
                                            $latest_version_serial = $latest_version_keys[0];
                                            $latest_version_url = $latest_version[$latest_version_serial];
                                            $plugin_id = 'td-subscription/td-subscription.php';

                                            $transient->response[$plugin_id] = (object)array(
                                                'id' => $plugin_id,
                                                'slug' => 'td-subscription',
                                                'plugin' => $plugin_id,
                                                'new_version' => $latest_version_serial,
                                                'url' => "https://tagdiv.com/td_subscription",
                                                'package' => add_query_arg($args, $latest_version_url),
                                            );
                                        }


                                        return $transient;
                                    });

                                    delete_site_transient('update_plugins');
                                }
                            }

                        }

                    }
                }
            }
        }
    }


	add_filter( 'admin_body_class', function ( $classes ) {

	    // Check for Theme updates
		$new_update_available = false;
		$latest_version = tagdiv_util::get_option( 'theme_update_latest_version' );

		if ( ! empty( $latest_version ) ) {
			$latest_version = json_decode( $latest_version, true );

			$latest_version_keys = array_keys( $latest_version );
			if ( is_array( $latest_version_keys ) && count( $latest_version_keys ) ) {
				$latest_version_serial = $latest_version_keys[ 0 ];

				if ( 1 == version_compare( $latest_version_serial, TD_THEME_VERSION ) ) {
					$new_update_available = true;
				}
			}
		}

		if ( $new_update_available ) {
			$classes .= ' td-theme-update';
		}

        // Check for Plugin updates
        wp_update_plugins();
        $plugin_updates = get_site_transient( 'update_plugins' );

        foreach ( tagdiv_global::get_td_plugins() as $constant => $settings ) {
            $plugin_id = 'td-subscription/td-subscription.php';
            $plugin_name = strtolower( str_replace('_', '-', $constant ) );
            $plugin = $plugin_name . '/' . $plugin_name . '.php';
            if ( $plugin === $plugin_id && !empty($plugin_updates->response[$plugin_id]) ) {
                $classes .= ' td-subscription-plugin-update';
                break;
            }
        }

		return $classes;
	} );


	add_filter( 'admin_head', function () {

		$td_update_theme_ready = get_transient( 'td_update_theme_' . TD_THEME_NAME );
		if ( false !== $td_update_theme_ready ) {

			$update_data = '';

			$td_theme_update_to_version = get_transient( 'td_update_theme_to_version_' . TD_THEME_NAME );
			if ( false !== $td_theme_update_to_version ) {

				$data = tagdiv_util::get_option( 'theme_update_to_version' );
				if ( ! empty( $data ) ) {
					$update_data = $data;
				}
			} else {

				$data = tagdiv_util::get_option( 'theme_update_latest_version' );
				if ( ! empty( $data ) ) {
					$update_data = $data;
				}
			}

			if ( ! empty( $update_data ) ) {
				ob_start();
				?>
				<script>
					var tdData = {
						version: <?php echo $update_data ?>,
						adminUrl: "<?php echo admin_url() ?>",
						themeName: "<?php echo TD_THEME_NAME ?>",
					};
				</script>
				<?php
				echo ob_get_clean();
			}
		}
	} );
}


add_action('upgrader_process_complete', function($upgrader, $data) {

	if ($data['action'] == 'update' && $data['type'] == 'theme' ) {

		// clear flag to update theme
		delete_transient( 'td_update_theme_' . TD_THEME_NAME );

		// clear flag to update theme to latest version
		delete_transient( 'td_update_theme_latest_version_' . TD_THEME_NAME );

		// clear flag to update theme to specific version
		delete_transient( 'td_update_theme_to_version_' . TD_THEME_NAME );

		// clear flag to update to a specific version
		tagdiv_util::update_option( 'theme_update_to_version', '' );

		$current_deactivated_plugins = tagdiv_options::get_array('td_theme_deactivated_current_plugins' );

		if ( ! empty( $current_deactivated_plugins ) ) {
			$theme_setup = tagdiv_theme_plugins_setup::get_instance();
			$theme_setup->theme_plugins( array_keys( $current_deactivated_plugins ) );

			ob_start();

			?>

			<script>
                window.onload = (event) =>
                {
                    setTimeout(function () {
                        jQuery('.td-button-install-plugins').trigger('click');
                    }, 1000);
                }
			</script>

			<?php

			echo ob_get_clean();
		}
	}

}, 10, 2);


add_action('upgrader_process_complete', function($upgrader, $data) {

    if ($data['action'] == 'update' && $data['type'] == 'plugin' &&
        (( !empty($data['plugins']) && in_array('td-subscription/td-subscription.php', $data['plugins'])) || (!empty($data['plugin']) && 'td-subscription/td-subscription.php' === $data['plugin'])) )  {

        // clear flag to update theme to latest version
        delete_transient( 'td_update_plugin_subscription' );

        // clear flag to update theme to specific version
        delete_transient( 'td_update_plugin_subscription_latest_version');
    }

}, 10, 2);


add_filter('upgrader_pre_install', function( $return, $theme) {
	if ( is_wp_error( $return ) ) {
		return $return;
	}

	$theme = isset( $theme['theme'] ) ? $theme['theme'] : '';

    if ( ! in_array( get_stylesheet(), array($theme, $theme . '-child'))) { //If not current
		return $return;
	}

	tagdiv_options::update_array( 'td_theme_deactivated_current_plugins', '' );
	$deactivation = new tagdiv_current_plugins_deactivation();
	$deactivation->td_deactivate_current_plugins( true );

	return $return;

}, 10, 2);



add_action( 'current_screen', function() {
	$current_screen = get_current_screen();

	if ( 'update-core' === $current_screen->id && isset( $_REQUEST['update_theme'] )) {

		add_action('admin_head', function() {

			$theme_name = $_REQUEST['update_theme'];

			ob_start();
			?>

			<script>
				jQuery(window).ready(function() {

					'use strict';

					var $formUpgradeThemes = jQuery('form[name="upgrade-themes"]');
					if ( $formUpgradeThemes.length ) {
						var $input = $formUpgradeThemes.find('input[type="checkbox"][value="<?php echo esc_js( $theme_name ) ?>"]');
						if ($input.length) {
							$input.attr( 'checked', true );
							$formUpgradeThemes.submit();
						}
					}
				});
			</script>

			<?php
			echo ob_get_clean();
		});
	}
});

add_filter( 'render_block', 'td_filter_youtube_embed', 10, 3);
function td_filter_youtube_embed( $block_content, $block ) {

	if( 'core-embed/youtube' !== $block['blockName'] ) {
		return $block_content;
	}

	$matches = array();
	preg_match('/iframe(.*)src=\"(\S*)\"/', $block_content, $matches);

	if ( !empty($matches) && is_array($matches) && 3 === count($matches)) {
		$url = $matches[2];
		if (strpos($url, '?') > 0 ) {
			$new_url = $url . '&enablejsapi=1';
		} else {
			$new_url = $url . '?enablejsapi=1';
		}
		$block_content = str_replace( $url, $new_url, $block_content);
	}

	return $block_content;
}
