/**
 * Created by Your Inspiration on 05/04/2016.
 */
jQuery(function ($) {

    $(document).on('click', '.on-off-module .on_off', function () {
        const
            input = $(this),
            wrap = input.closest('.module'),
            module = input.attr('data-module');

        const data = {
            action: 'yith_funds_module_activation_switch',
            security: ywf_admin.nonces.switch_module,
            module,
        };

        // Make sure the WC alert is removed
        window.onbeforeunload = '';


        $.ajax({
            url: ywf_admin.ajax_url,
            data: data,
            type: 'POST',
            dataType: 'json',
            beforeSend: function () {
                wrap.block({
                    message: null,
                    overlayCSS: {
                        background: '#fff',
                        opacity: 0.6,
                    }
                });
            },
            success: function (res) {

                window.onbeforeunload = '';
                window.location.reload();
            }
        });
    });

    $('input, textarea, select,checkbox').on('click', function () {
        window.onbeforeunload = '';
    });

    const defaultModalConfig = {
        allowWpMenu: false,
        allowClosingWithEsc: false,
        footer: false,
        width: 600
    }
    let modal = null;
    let currentFunds;
    $(document).on('click', '#yith-user-list-table table .yith-plugin-fw__action-button--edit-action a', function (event) {
        event.preventDefault();
        const user_id = $(event.target).parents('tr').find('input[name="user_id"]').val();

        let data = {
            action: ywf_admin.actions.edit_funds,
            security: ywf_admin.nonces.edit_funds,
            user_id,
        };
        $.ajax({
            type: 'POST',
            url: ywf_admin.ajax_url,
            data,
            dataType: 'json',
            success(response) {
                if (response.success) {
                    const template = $(response.data);
                    const userName = template.find('#yith-funds-edit-fund-panel').data('username');
                    modal = yith.ui.modal({
                        ...defaultModalConfig,
                        title: ywf_admin.editModal.title.replace('%s', userName),
                        content: template,
                    });

                    currentFunds = template.find('input[name="funds"]').val();
                }
            },
        });

    });
    $(document).on('click', '.yith-funds-edit-action button', function (e) {
        e.preventDefault();
        const form = $(e.target).parents('form'),
            user_id = form.find('input[name="user_id"]').val(),
            funds = form.find('input[name="funds"]').val(),
            desc = form.find('textarea').val();

        let data = {
            action: ywf_admin.actions.save_funds,
            security: ywf_admin.nonces.save_funds,
            user_id,
            funds,
            desc
        };
        $.ajax({
            type: 'POST',
            url: ywf_admin.ajax_url,
            data,
            dataType: 'json',
            success(response) {
                if (response.success) {
                    $(response.data).insertBefore(form);
                    setTimeout(function () {
                            modal.close();
                            location.reload();
                        },
                        1500
                    )

                }
            },
        });
    });
    $(document).on('change', 'input[name="funds"]', function (e) {
        const now = $(this).val(),
            button = $(e.target).parents('form').find('.yith-funds-edit-action button');

        if (typeof currentFunds !== 'undefined' && now != currentFunds) {
            button.removeClass('yith-disabled');
        } else {
            button.addClass('yith-disabled');
        }

    });

    const allSelect = $('.select2-search input.select2-search__field');

    $.each(allSelect,function (index,select){
       let w = $(select).attr('style');
       w = w.split('width:');
      w = w[1].replace(';','!important;');


       $(select).attr( 'style','width:'+ w);
    });


    $('#yith-user-list-table .wc-customer-search').on('change',function (e){
       if( '' === e.target.value){
           window.location.reload();
       }
    })

});
