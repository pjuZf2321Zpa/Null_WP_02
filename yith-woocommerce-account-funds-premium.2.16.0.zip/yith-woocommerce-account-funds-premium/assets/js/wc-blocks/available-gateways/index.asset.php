<?php return array('dependencies' => array('wc-blocks-registry'), 'version' => '964d328cf25da1db9252');
