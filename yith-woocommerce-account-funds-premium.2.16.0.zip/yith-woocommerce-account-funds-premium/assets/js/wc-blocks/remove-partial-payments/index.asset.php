<?php return array('dependencies' => array('react', 'wc-blocks-checkout', 'wp-plugins'), 'version' => '4a3d3673c41b34349f0d');
