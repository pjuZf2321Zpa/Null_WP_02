/**
 * Created by Your Inspiration on 06/04/2016.
 */
jQuery(function ($) {


    const depositInput = $('#yith-funds-add-amount'),
        depositForm = $('.yith-funds-endpoint-charge-account form'),
        min = parseFloat(ywf_frontend.min),
        max = parseFloat(ywf_frontend.max),
        step = parseFloat(ywf_frontend.step),
        errorDiv = $('.yith-funds-add-fund-error'),
        button = $('.yith-funds-add-fund');

    let currentError = false;


    depositInput.on('change', function (e) {
        let value = e.target.value;
        currentError = false;

        if (value !== '') {
            value = parseFloat(value);
            if (value < min) {
                currentError = 'min';
            }

            if (value > max) {
                currentError = 'max';
            }

            if (currentError === false) {
                button.removeClass('disabled');
                errorDiv.hide();
            } else {
                errorDiv.html(ywf_frontend[currentError + 'DepError'].replace('%s', min)).show();
                button.addClass('disabled');
            }
        } else {
            button.addClass('disabled');
        }
    }).trigger('change');


});
