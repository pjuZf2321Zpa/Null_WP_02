<?php
return array(
	'all-modules' => array(
		'modules' => array(
			'type'           => 'custom_tab',
			'action'         => 'yith_funds_modules_tab',
			'show_container' => true,
		),
	),
);