<?php
/**
 * Plugin Options : General options
 *
 * @package YITH\AccountFunds\PluginOptions
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$message   = __( '%1$sCustomize My Account Page%2$s is activated, you can change the title and slug of the endpoint %3$shere%4$s', 'yith-woocommerce-account-funds' );
$admin_url = admin_url( 'admin.php' );
$args      = array(
	'page' => 'yith_wcmap_panel',
	'tab'  => 'endpoints',
);
$page_url  = esc_url( add_query_arg( $args, $admin_url ) );
$message   = sprintf( $message, '<strong>', '</strong>', "<a href='{$page_url}' target='_blank'>", "</a>" );
$currency_symbol = get_woocommerce_currency_symbol();

$settings = array(
	'general-settings' => array(
		'charging_funds_settings_section_start' => array(
			'name' => __( 'Charging account settings', 'yith-woocommerce-account-funds' ),
			'type' => 'title',
		),
		'funds_min_value'                       => array(
			'name'      => sprintf( '%s (%s)', __( 'Minimum deposit amount', 'yith-woocommerce-account-funds' ), get_woocommerce_currency_symbol() ),
			'type'      => 'yith-field',
			'yith-type' => 'number',
			'min'       => 0,
			'step'      => 0.1,
			'default'   => 0,
			'id'        => 'yith_funds_min_value',
			'desc'      => __( 'Set a minimum required amount for deposits.', 'yith-woocommerce-account-funds' ),
		),
		'funds_max_value'                       => array(
			'name'      => sprintf( '%s (%s)', __( 'Maximum deposit amount', 'yith-woocommerce-account-funds' ), get_woocommerce_currency_symbol() ),
			'type'      => 'yith-field',
			'yith-type' => 'number',
			'min'       => 0,
			'step'      => 0.1,
			'default'   => '',
			'id'        => 'yith_funds_max_value',
			'desc'      => __( 'Set the maximum amount for each individual deposit. Leave it blank to make it unlimited.', 'yith-woocommerce-account-funds' ),
			'css'       => 'width:80px;',
		),
		'funds_step_by'                         => array(
			'name'      =>  sprintf( __( 'Amount increments (%s)', 'yith-woocommerce-account-funds' ), $currency_symbol ),
			'desc'      => sprintf( __( 'Choose the increments of the deposit amount. For example, enter 5 if you want to let your users only select increments of %s.', 'yith-woocommerce-account-funds' ),wc_price(5) ),
			'id'        => 'yith_funds_step',
			'type'      => 'yith-field',
			'yith-type' => 'number',
			'min'       => 1,
			'step'      => 1,
			'default'   => '1',
			'css'       => 'width:80px',
		),
		'funds_coupon'                          => array(
			'name'      => __( 'Add discount when depositing funds', 'yith-woocommerce-account-funds' ),
			'desc'      => __( 'If enabled, the customers will get a discount when charge their funds.', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'default'   => 'no',
			'id'        => 'yith_funds_enable_coupon',
		),
		'funds_type_discount'                   => array(
			'name'      => __( 'Discount', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'desc'      => __( 'Set the discount to apply in the cart.', 'yith-woocommerce-account-funds' ),
			'yith-type' => 'inline-fields',
			'fields'    => array(
				'discount_type'  => array(
					'type'    => 'select',
					'options' => array(
						'fixed_cart' => sprintf( __( 'a fixed discount of %s', 'yith-woocommerce-account-funds' ), $currency_symbol ),
						'percentage' => __( 'a % discount of', 'yith-woocommerce-account-funds' ),
					),
					'default' => 'fixed_cart',
				),
				'discount_value' => array(
					'type'    => 'number',
					'min'     => 0,
					'step'    => 0.5,
					'default' => 10,
				)
			),
			'id'        => 'yith_funds_discount_configuration',
			'deps'      => array(
				'id'    => 'yith_funds_enable_coupon',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'select_gateway'                        => array(
			'name'        => __( 'Payment method', 'yith-woocommerce-account-funds' ),
			'desc'        => __( 'Select payment method for deposits. Leave this field empty if you want to allow all gateways enabled in WooCommerce.', 'yith-woocommerce-account-funds' ),
			'type'        => 'yith-field',
			'yith-type'   => 'select-buttons',
			'multiple'    => true,
			'placeholder' => __( 'Select a Payment Method', 'yith-woocommerce-account-funds' ),
			'id'          => 'ywf_select_gateway',
			'options'     => ywf_get_gateway(),
			'default'     => '',

		),
		'charging_funds_settings_section_end'   => array(
			'type' => 'sectionend',
		),
		'using_funds_settings_section_start'    => array(
			'name' => __( 'Using funds settings', 'yith-woocommerce-account-funds' ),
			'type' => 'title',
		),
		'discount_enable_discount'              => array(
			'name'      => __( 'Add discount when using funds', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'default'   => 'no',
			'desc'      => __( 'Apply a discount if customers use their funds to pay.', 'yith-woocommerce-account-funds' ),
			'id'        => 'yith_discount_enable_discount',
		),
		'discount_type_discount'                => array(
			'name'      => __( 'Discount', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'desc'      => __( 'Set the discount to apply in the cart.', 'yith-woocommerce-account-funds' ),
			'yith-type' => 'inline-fields',
			'fields'    => array(
				'discount_type'  => array(
					'type'    => 'select',
					'options' => array(
						'fixed_cart' => sprintf( __( 'a fixed discount of %s', 'yith-woocommerce-account-funds' ), $currency_symbol ),
						'percentage' => __( 'a % discount of', 'yith-woocommerce-account-funds' ),
					),
					'default' => 'fixed_cart',
				),
				'discount_value' => array(
					'type'    => 'number',
					'min'     => 0,
					'step'    => 0.5,
					'default' => 0,
				)
			),
			'id'        => 'yith_discount_configuration',
			'deps'      => array(
				'id'    => 'yith_discount_enable_discount',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'show_discount_message'                 => array(
			'name'      => __( 'Show discount message in', 'yith-woocommerce-account-funds' ),
			'id'        => 'ywf_discount_message_position',
			'type'      => 'yith-field',
			'yith-type' => 'radio',
			'options'   => array(
				'cart'     => __( 'Cart', 'yith-woocommerce-account-funds' ),
				'checkout' => __( 'Checkout', 'yith-woocommerce-account-funds' ),
				'both'     => __( 'Both', 'yith-woocommerce-account-funds' ),
			),
			'deps'      => array(
				'id'    => 'yith_discount_enable_discount',
				'value' => 'yes',
				'type'  => 'hide',
			),
			'desc'      => __( 'Select where you want show the discount message.', 'yith-woocommerce-account-funds' ),
			'default'   => 'cart'
		),
		'discount_message'                      => array(
			'id'            => 'ywf_discount_message',
			'name'          => __( 'Discount message', 'yith-woocommerce-account-funds' ),
			'type'          => 'yith-field',
			'yith-type'     => 'textarea-editor',
			'wpautop'       => false,
			'textarea_rows' => 5,
			'desc'          => __( 'Set the message to show on the Cart or on the Checkout page. Use <code>%amount_discount%</code> to show the discount.', 'yith-woocommerce-account-funds' ),
			'default'       => '<p>'.__( 'Pay the order using your funds and get a <strong>%amount_discount%</strong> discount.', 'yith-woocommerce-account-funds' ).'</p>',
			'deps'          => array(
				'id'    => 'yith_discount_enable_discount',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'discount_message_bg'                   => array(
			'id'        => 'ywf_discount_message_bg',
			'name'      => __( 'Discount message background', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'colorpicker',
			'default'   => '#ffd9bc',
			'desc'      => __( 'Set the background color of the discount message.', 'yith-woocommerce-account-funds' ),
			'deps'      => array(
				'id'    => 'yith_discount_enable_discount',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'payment_enable_partial'                => array(
			'name'      => __( 'Enable partial payments', 'yith-woocommerce-account-funds' ),
			'desc'      => __( 'Allow customers to pay for the order using their available funds and pay the rest using a different payment method.', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'default'   => 'no',
			'id'        => 'yith_enable_partial_payment',
		),
		'partial_payment_message'                      => array(
			'id'            => 'ywf_partial_payment_message',
			'name'          => __( 'Message', 'yith-woocommerce-account-funds' ),
			'type'          => 'yith-field',
			'yith-type'     => 'textarea-editor',
			'wpautop'       => false,
			'textarea_rows' => 5,
			'desc'          => __( 'Set the message to show on the Cart or on the Checkout page. Use <code>%user_funds%</code> to show the customer funds.', 'yith-woocommerce-account-funds' ),
			'default'       => '<p>'.__( 'The available funds you can use for this order: %user_funds%<p>Use your own funds and pay the rest with another payment method!</p>', 'yith-woocommerce-account-funds' ).'</p>',
			'deps'          => array(
				'id'    => 'yith_enable_partial_payment',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'using_funds_settings_section_end'      => array(
			'type' => 'sectionend',
		),
		'endpoint-section-start'                => array(
			'name' => __( 'Funds endpoint', 'yith-woocommerce-account-funds' ),
			'type' => 'title',
			'desc' => __( 'This endpoint will show the balance, funds history, and the form to charge the account.', 'yith-woocommerce-account-funds' ),
		),
		'endpoint-title'                        => array(
			'name'               => __( 'Endpoint title', 'yith-woocommerce-account-funds' ),
			'type'               => 'yith-field',
			'yith-type'          => 'text',
			'default'            => __( 'Funds', 'yith-woocommerce-account-funds' ),
			'desc'               => __( 'Set the endpoint title.', 'yith-woocommerce-account-funds' ),
			'is_option_disabled' => defined( 'YITH_WCMAP_PREMIUM' ),
			'id'                 => 'ywf_funds_endpoint',
		),
		'endpoint-slug'                         => array(
			'name'               => __( 'Endpoint slug', 'yith-woocommerce-account-funds' ),
			'type'               => 'yith-field',
			'yith-type'          => 'text',
			'default'            => 'funds',
			'id'                 => 'ywf_funds_endpoint_slug',
			'is_option_disabled' => defined( 'YITH_WCMAP_PREMIUM' ),
			'desc'               => __( 'Set the endpoint slug. The slug cannot contain spaces or uppercase letters. Leave empty to disable the endpoint.', 'yith-woocommerce-account-funds' ),
		),
		'endpoint_note'                         => array(
			'type'      => 'yith-field',
			'yith-type' => 'html',
			'html'      => defined( 'YITH_WCMAP_PREMIUM' ) ? $message : ''
		),
		'endpoint-show-history'                 => array(
			'name'      => __( 'Show funds history', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'id'        => 'ywf_show_endpoint_history',
			'default'   => 'yes',
			'desc'      => __( 'Enable to show the funds history within the funds endpoint.', 'yith-woocommerce-account-funds' ),
		),
		'endpoint-section-end'                  => array(
			'type' => 'sectionend',
		),
		'dashboard-section-start'               => array(
			'type' => 'title',
			'name' => __( 'My Account dashboard', 'yith-woocommerce-account-funds' ),
		),
		'dashboard-type-content'                => array(
			'id'        => 'yith_funds_dashboard_content',
			'name'      => __( 'Show in dashboard page', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'checkbox-array',
			'options'   => array(
				'balance'   => __( 'User balance', 'yith-woocommerce-account-funds' ),
				'add_funds' => __( 'Add funds form', 'yith-woocommerce-account-funds' ),
				'history'   => __( 'Latest funds history', 'yith-woocommerce-account-funds' ),
			),
			'default'   => array(),
		),
		'dashboard-section-end'                 => array(
			'type' => 'sectionend',
		),
		'privacy_settings_start'                => array(
			'name' => __( 'Privacy settings', 'yith-woocommerce-account-funds' ),
			'type' => 'title',
		),
		'privacy_enable_user_privacy'           => array(
			'name'      => __( 'GDPR compliance', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'id'        => 'ywf_user_privacy',
			'desc'      => __( 'If checked, it allows customers to choose whether to receive emails or not about their funds. This option is visible in \'My Account\' page.', 'yith-woocommerce-account-funds' ),
			'default'   => 'no',
		),
		'privacy_text_user_privacy'             => array(
			'name'      => __( 'Description', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'text',
			'id'        => 'ywf_user_privacy_description',
			'desc'      => __( 'This description will be displayed next to the checkbox.', 'yith-woocommerce-account-funds' ),
			'deps'      => array(
				'id'    => 'ywf_user_privacy',
				'value' => 'yes',
				'type'  => 'hide',
			),
			'default'   => __( 'Yes, I want to receive emails for my funds', 'yith-woocommerce-account-funds' ),
		),
		'privacy_settings_end'                  => array(
			'type' => 'sectionend',
		)
	),
);

return $settings;
