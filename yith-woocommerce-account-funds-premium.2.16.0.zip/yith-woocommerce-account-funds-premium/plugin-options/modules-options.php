<?php
/**
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @author  YITH
 * @package YITH/Account Funds
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.


return array(
	'modules' => array(
		'modules-options' => array(
			'type'     => 'multi_tab',
			'sub-tabs' => apply_filters( 'ywf_module_sub_tabs', array(
				'all-modules' => array(
					'title' => esc_html__( 'All modules', 'yith-woocommerce-account-funds' ),
				),
			),
			),
		),
	),
);


