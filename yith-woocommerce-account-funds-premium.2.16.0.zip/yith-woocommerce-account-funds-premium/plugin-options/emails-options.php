<?php
/**
 * Emails tab array
 *
 * @package YITH\Account Funds\PluginOptions
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

return array(
	'emails' => array(
		'emails-list' => array(
			'type'   => 'custom_tab',
			'action' => 'yith_ywf_print_emails_tab',
		),
	),
);
