<?php
/**
 * This template show the add funds form
 *
 * @var int $step The step.
 * @var int $min The min.
 * @var int $max The max.
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$currency = get_woocommerce_currency();
$symbol = get_woocommerce_currency_symbol();

$default_amount = isset( $_GET['amount'] )  ? sanitize_text_field( wp_unslash( $_GET['amount'] ) ) : '';
?>

<form method="post">
    <div class="yith-funds-add-fund-wrapper yith-funds-shortcode-badge">
        <label for="yith-funds-add-amount"
               class="yith-funds-add-fund-title"><?php esc_html_e( 'Deposit funds', 'yith-woocommerce-account-funds' ); ?></label>
        <div class="yith-funds-add-fund-form">
            <div class="yith-funds-add-fund-currency"><?php echo esc_html( $symbol ); ?></div>
            <div class="yith-funds-add-fund-input">
                <input id="yith-funds-add-amount" type="number"
                       name="amount_deposit"
                       min="<?php echo esc_attr( $min ); ?>"
                       max="<?php echo esc_attr( $max ); ?>"
                       step="<?php echo esc_attr( $step ); ?>"
                       value="<?php echo esc_attr( $default_amount ); ?>"
                       placeholder="<?php esc_html_e( 'Enter amount', 'yith-woocommerce-account-funds' ); ?>"/>
            </div>
        </div>
        <div class="yith-funds-add-fund-error"></div>
        <input type="submit" class="button yith-funds-add-fund disabled"
               value="<?php esc_html_e( 'Add funds', 'yith-woocommerce-account-funds' ); ?>"/>
        <input type="hidden" name="deposit_nonce" value="<?php echo esc_attr( wp_create_nonce( 'add_deposit' ) ); ?>">
        <input type="hidden" name="currency" value="<?php echo esc_attr( $currency ); ?>">
    </div>
</form>
