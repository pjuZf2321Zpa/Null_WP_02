<?php
/**
 * This template show the funds balance shortcode
 *
 * @var float  $funds The available funds.
 * @var string $image The icon.
 * @var string $layout The type.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<?php if ( $funds >= 0 ) : ?>
    <div class="yith-funds-balance-wrapper yith-funds-shortcode-<?php echo esc_attr( $layout ); ?>">
        <div class="yith-funds-balance-icon">
			<?php echo $image; ?>
        </div>
        <div class="yith-funds-balance-message">
			<?php esc_html_e( 'Available funds:', 'yith-woocommerce-account-funds' ); ?>
        </div>
        <div class="yith-funds-balance-total">
			<?php echo wc_price( $funds ); ?>
        </div>
		<?php do_action( 'yith_funds_balance_after_total' ); ?>
    </div>

<?php endif; ?>