<?php
/**
 * This template show the funds balance shortcode
 *
 * @var array  $history The funds history
 * @var array  $filters The funds history filters
 * @var string $current_filter The current filter
 * @var string $page_link The pages link
 * @var string $show_all Show view all link
 * @var string $show_filter Show filters.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$headers = array(
	'log-date'       => __( 'Date', 'yith-woocommerce-account-funds' ),
	'description'    => __( 'Reason', 'yith-woocommerce-account-funds' ),
	'deposit-amount' => __( 'Amount', 'yith-woocommerce-account-funds' ),
);

$show_filter = 'yes' === $show_filter && ( count( $history ) > 0 || ! empty( $current_filter ) );
?>
<form method="get">
    <div class="yith-funds-history-wrapper">

        <div class="yith-funds-history-list">

            <div class="yith-funds-history-header">
                <h3 class=yith-funds-history-filter"><?php esc_html_e( 'Funds history', 'yith-woocommerce-account-funds' ); ?></h3>
				<?php if ( $show_filter ): ?>
                    <div class="yith-funds-history-filter-content">
                        <select id="yith-funds-history-filter" name="funds_history_filter">
                            <option value=""
								<?php selected( '', $current_filter ); ?>><?php esc_html_e( 'Show All', 'yith-woocommerce-account-funds' ); ?></option>
							<?php foreach ( $filters as $key => $filter ): ?>
                                <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $key, $current_filter ); ?>><?php echo esc_html( $filter ); ?></option>
							<?php endforeach; ?>
                        </select>
                        <input type="submit" class="button ywf_history_filter_button"
                               value="<?php esc_attr_e( 'Filter', 'yith-woocommerce-account-funds' ); ?>">
                    </div>
				<?php endif; ?>
				<?php if ( 'yes' === $show_all ): ?>
                    <div class="yith-funds-history-show-all">
                        <a href="<?php echo esc_url( add_query_arg( array( 'show_all_history' => 'yes' ) ) ); ?>"><?php esc_html_e( 'Show all', 'yith-woocommerce-account-funds' ); ?></a>
                    </div>
				<?php endif; ?>
            </div>
			<?php if ( count( $history ) > 0 ): ?>
                <div class="yith-funds-history-table-wrapper">
                    <table class="yith-funds-history-table shop_table shop_table_responsive">
                        <thead>
                        <tr>
							<?php foreach ( $headers as $key => $header ): ?>
                                <th class="yith_funds_history-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $header ); ?></th>
							<?php endforeach; ?>
                        </tr>
                        </thead>
                        <tbody>
						<?php foreach ( $history as $row ): ?>
                            <tr class="yith_funds_history_item">
								<?php foreach ( $headers as $key => $header ):
									$td_class = "yith_funds_history-$key";
									switch ( $key ) {
										case 'log-date':
											$content = sprintf( '<time datetime="%s" title="%s">%s</time>', gmdate( 'Y-m-d', strtotime( $row->date_added ) ), esc_attr( strtotime( $row->date_added ) ), date_i18n( get_option( 'date_format' ), strtotime( $row->date_added ) ) );
											break;
										case 'deposit-amount':
											$fund_user = apply_filters( 'yith_show_used_funds', $row->fund_user );
											$sign      = $row->fund_user > 0 ? '+' : '';
											$content   = sprintf( '<span class="ywf_%s">%s</span>', ! empty( $sign ) ? 'plus' : 'minus', $sign . wc_price( $fund_user ) );
											break;
										default:
											$funds_used = get_post_meta( $row->order_id, '_order_funds', true );

											$order      = wc_get_order( $row->order_id ); // phpcs:ignore
											$order_link = '';
											$item_count = 0;
											if ( $order ) {
												$item_count = $order->get_item_count();
												$order_link = sprintf( '<a href="%s">%s%s</a>', esc_url( $order->get_view_order_url() ), _x( '#', 'hashtag before order number', 'yith-woocommerce-account-funds' ), $order->get_order_number() );
											}
											$reason = '';
											if ( ! empty( $row->description ) ) {
												$reason = sprintf( '%s: %s', __( 'Reason', 'yith-woocommerce-account-funds' ), $row->description );
											}

											if ( 'pay' === $row->type_operation ) {
												/* translators: %s is the amount of item in the order */
												$sub_content = sprintf( _n( '%s item', '%s items', $item_count, 'yith-woocommerce-account-funds' ), $item_count );
												$content     = sprintf( '<p>%s %s %s %s</p>', __( 'Funds used to purchase', 'yith-woocommerce-account-funds' ), $sub_content, __( 'in order', 'yith-woocommerce-account-funds' ), $order_link );

											} elseif ( 'deposit' === $row->type_operation ) {

												$content = sprintf( '<p>%s %s</p>', __( 'Order Credited Funds', 'yith-woocommerce-account-funds' ), $order_link );

											} elseif ( 'restore' === $row->type_operation ) {

												$order_status = $order ? wc_get_order_status_name( $order->get_status() ) : __( 'deleted', 'yith-woocommerce-account-funds' );
												$content      = sprintf( '<p>%s %s %s %s <small>%s</small></p>', __( 'Funds restored because order', 'yith-woocommerce-account-funds' ), $order_link, __( 'switched to', 'yith-woocommerce-account-funds' ), $order_status, $reason );


											} elseif ( 'remove' === $row->type_operation ) {

												$content = sprintf( '<p>%s %s <small>%s</small></p>', __( 'Refunded credits in order', 'yith-woocommerce-account-funds' ), $order_link, $reason );
											} else {

												$content = sprintf( '<p>%s</p>', $row->description );
											}
											break;
									}
									?>
                                    <td class="<?php echo esc_attr( $td_class ); ?>"
                                        data-title="<?php echo esc_attr( $header ); ?>">
										<?php echo wp_kses_post( $content ); ?>
                                    </td>
								<?php endforeach; ?>
                            </tr>
						<?php endforeach; ?>
                        </tbody>
						<?php if ( $page_link ) : ?>
                            <tfoot>
                            <tr class="yith_funds_history_pagination">
                                <td colspan="3"><?php echo wp_kses_post( $page_link ); ?></td>
                            </tr>
                            </tfoot>
						<?php endif; ?>
                    </table>
                </div>
			<?php else: ?>
                <div class="yith-funds-no-history">
					<?php

					esc_html_e( 'No history for this user', 'yith-woocommerce-account-funds' );
					?>
                </div>
			<?php endif; ?>
        </div>
    </div>
</form>
