<?php
/**
 * This is the template for the partial payment box, visible on checkout
 *
 * @var string $text
 * @var string $button_text
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$checkout_url = wc_get_checkout_url();
$args         = array(
	'partial_payment' => wp_create_nonce( 'ywf-apply-partial-payment' ),
);
$checkout_url = esc_url( add_query_arg( $args, $checkout_url ) );
?>
<div class="ywf-partial-payment-box">
    <div class="ywf-partial-payment-box-text">
		<?php echo wp_kses_post( $text ); ?>
    </div>
    <a href="<?php echo esc_url( $checkout_url ); ?>" class="ywf_partial_payment button ghost">
		<?php echo esc_html( $button_text ); ?>
    </a>
</div>
