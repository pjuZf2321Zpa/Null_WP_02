<?php
/**
 * This template allow to edit the user funds
 *
 * @var int $user_id The user id
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$user       = get_user_by( 'id', $user_id );
$fund_user  = new YITH_YWF_Customer( $user_id );
$user_name  = $user->display_name;
$page_title = sprintf( '<h2>%s %s</h2>', __( 'Edit funds for', 'yith-woocommerce-account-funds' ), esc_html( $user_name ) );

?>
<form>
    <div id="yith-funds-edit-fund-panel" data-username="<?php echo esc_attr($user_name);?>">
        <input type="hidden" name="user_id" value="<?php echo esc_attr( $user_id ); ?>"/>
        <div class="yith-funds-edit-fund-row">
            <div class="yith-funds-edit-fund-label">
                <label for="yith-funds">
					<?php
					// translators: %s is the currency
					echo wp_kses_post( sprintf( __( 'Current funds (%s)', 'yith-woocommerce-account-funds' ), get_woocommerce_currency_symbol() ) );
					?>
                </label>
            </div>
            <div class="yith-funds-edit-fund-field">
	            <?php
	            yith_plugin_fw_get_field(
					array(
						'type' => 'number',
						'name'=>'funds',
						'value' => $fund_user->get_funds()
					),
		            true
	            );
	            ?>
	            <div class="yith-funds-edit-desc"><?php esc_html_e('Edit user\'s funds!','yith-woocommerce-account-funds'); ?></div>
            </div>
        </div>
	    <div class="yith-funds-edit-fund-row desc">
		    <div class="yith-funds-edit-fund-label">
			    <label for="yith-funds-description">
				    <?php
				    esc_html_e( 'Description', 'yith-woocommerce-account-funds' ) ;
				    ?>
			    </label>
		    </div>
		    <div class="yith-funds-edit-fund-field">
			    <?php
			    yith_plugin_fw_get_field(
				    array(
					    'type' => 'textarea',
					    'name'=>'description',
					    'cols' => 30,
					    'rows' => 5
				    ),
				    true
			    );
			    ?>
			    <div class="yith-funds-edit-desc"><?php esc_html_e('Enter a brief description','yith-woocommerce-account-funds'); ?></div>
		    </div>
	    </div>
	    <div class="yith-funds-edit-action">
		    <button class="yith-plugin-fw__button--primary yith-plugin-fw__button--xl yith-disabled"><?php esc_html_e( 'Edit funds', 'yith-woocommerce-account-funds' ); ?></button>
	    </div>
    </div>
</form>
