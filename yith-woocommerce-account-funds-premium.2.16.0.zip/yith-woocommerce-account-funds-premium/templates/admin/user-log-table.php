<?php
/**
 * Show in admin the users fund log
 *
 * @package YITH\AccountFunds\Templates\Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$table_dir        = YITH_FUNDS_INC . 'tables/';
$show_log_history = isset( $_GET['user_id'] );
$list_style       = $show_log_history ? 'yith-plugin-ui--classic-wp-list-style' : 'yith-plugin-ui--boxed-wp-list-style';
$list_table_args  = array(
	'id'                   => $show_log_history ? 'yith-log-history-table' : 'yith-user-list-table',
	'type'                 => 'list-table',
	'class'                => 'wp-list-table widefat fixed striped table-view-list',
	'list_table_class'     => $show_log_history ? 'YITH_YWF_Users_Log_Table' : 'YITH_WC_Funds_User_List_Table',
	'list_table_class_dir' => $show_log_history ? $table_dir . 'class.yith-ywf-users-log-table.php' : $table_dir . 'class.yith-ywf-user-list.php'
);

?>
<div class="yith-plugin-fw-wp-page-wrapper yith-plugin-ui <?php echo esc_attr( $list_style ); ?>">
    <form id="posts-filter" method="post">
		<?php yith_plugin_fw_get_field( $list_table_args, true ); ?>
    </form>
</div>
