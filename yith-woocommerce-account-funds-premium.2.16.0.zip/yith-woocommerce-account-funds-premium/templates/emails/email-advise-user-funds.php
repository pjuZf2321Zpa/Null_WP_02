<?php
/**
 * HTML Template Email Funds
 *
 * @var string   $email_heading The heading.
 * @var WC_Email $email The email.
 * @var bool     $sent_to_admin Is this sent to admin?
 * @var bool     $plain_text Is this plain?
 * @var string   $custom_message The email message.
 *
 * @package YITH\AccountFunds\Templates\Emails
 * @since   1.0.0
 * @author YITH <plugins@yithemes.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<?php do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<?php echo wp_kses_post( wpautop( wptexturize( $custom_message ) ) ); ?>

<?php
do_action( 'woocommerce_email_footer', $email );
