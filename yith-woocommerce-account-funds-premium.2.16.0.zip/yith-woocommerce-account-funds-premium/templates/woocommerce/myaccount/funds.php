<?php
/**
 * This file show the Funds endpoint content in My Account page
 *
 * @since 2.0.0
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div class="yith-funds-endpoint-wrapper">
    <h2><?php echo esc_html( yith_account_funds_get_endpoint_title( 'funds' ) ); ?></h2>
    <div class="yith-funds-endpoint-header">
        <div class="yith-funds-endpoint-balance">
			<?php
			echo apply_shortcodes( '[yith_ywf_show_user_fund]' )
			?>
        </div>
        <div class="yith-funds-endpoint-charge-account">
			<?php
			echo apply_shortcodes( '[yith_ywf_make_a_deposit_form]' );
			?>
        </div>
    </div>
	<?php do_action( 'yith_funds_endpoint' ); ?>
</div>
