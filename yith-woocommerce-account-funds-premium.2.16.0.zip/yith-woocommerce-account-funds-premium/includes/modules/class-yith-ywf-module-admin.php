<?php
/**
 * YITH_YWF_Module_Admin Class.
 *
 * Collection of common hooks and methods for the admin section of a module
 *
 * @class   YITH_YWF_Module_Admin
 * @author  YITH
 * @package YITH/Account Funds
 * @version 2.0.0
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.


if ( ! class_exists( 'YITH_YWF_Module_Admin' ) ) {
	/**
	 * Class YITH_YWF_Module_Admin
	 */
	abstract class YITH_YWF_Module_Admin {

		/**
		 * The module ID
		 *
		 * @var string
		 */
		protected $module_id = '';

		/**
		 * Constructor
		 *
		 * @since  1.0.0
		 */
		public function __construct() {
			$this->init();
		}

		/**
		 * Init
		 *
		 * @since  1.0.0
		 */
		protected function init() {

			if ( empty( $this->module_id ) ) {
				return;
			}


			add_filter( 'ywf_module_sub_tabs', array( $this, 'add_tabs' ), 20, 1 );
			add_filter( 'yith_plugin_panel_item_options_path', array( $this, 'module_options_path' ), 10, 4 );
			add_filter( 'yith_plugin_panel_sub_tab_item_options_path', array(
				$this,
				'module_sub_tab_options_path'
			), 10, 4 );
		}

		/**
		 * Register the module options path
		 *
		 * @param string                       $path Absolute options path.
		 * @param string                       $options_path Relative options path.
		 * @param string                       $item Current options item.
		 * @param YIT_Plugin_Panel_WooCommerce $panel Current panel.
		 *
		 * @return string
		 * @since  1.0.0
		 */
		public function module_options_path( $path, $options_path, $item, $panel ) {

			if ( array_key_exists( $item, $this->get_tabs() ) ) {
				$path = $this->get_module_path() . "options/{$item}-options.php";
			}

			return $path;
		}

		/**
		 * Register the module options path
		 *
		 * @param string                       $sub_tab_path Absolute options path.
		 * @param array                        $sub_tabs The sub tabs array.
		 * @param string                       $sub_item Current options item.
		 * @param YIT_Plugin_Panel_WooCommerce $panel Current panel.
		 *
		 * @return string
		 * @since  1.0.0
		 */
		public function module_sub_tab_options_path( $sub_tab_path, $sub_tabs, $sub_item, $panel ) {

			// Get the parent item name.
			$item = str_replace( array(
				$panel->settings['options-path'],
				"{$sub_item}-options.php",
				'/'
			), '', $sub_tab_path );

			if ( 'modules' === $item && 'multi-vendor' === $sub_item ) {
				$sub_tab_path = $this->get_module_path() . "options/{$sub_item}-options.php";
			}


			return $sub_tab_path;
		}

		/**
		 * Add module tabs to the plugin panel
		 *
		 * @param array $tabs The panel tabs array.
		 *
		 * @return array
		 * @since  1.0.0
		 */
		public function add_tabs( $tabs ) {
			$module_tabs = $this->get_tabs();

			if ( ! empty( $module_tabs ) ) {

				$tabs    = array_merge( $tabs, $module_tabs );
			}


			return $tabs;
		}

		/**
		 * Get the module path
		 *
		 * @return string
		 * @since  1.0.0
		 */
		protected function get_module_path() {
			$key      = strtoupper( str_replace( '-', '_', $this->module_id ) );
			$constant = "YITH_FUNDS_{$key}_MODULE_PATH";

			return defined( $constant ) ? constant( $constant ) : YITH_FUNDS_INC . "modules/{$this->module_id}/";
		}


		/**
		 * Get module tabs
		 *
		 * @return array
		 * @since  1.0.0
		 */
		protected function get_tabs() {
			return array();
		}


	}
}
