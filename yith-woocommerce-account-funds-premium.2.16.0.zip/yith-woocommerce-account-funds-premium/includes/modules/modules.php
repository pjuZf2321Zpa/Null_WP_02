<?php
/**
 * Modules list.
 *
 * @author  YITH
 * @package YITH/AI-Search
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

return array(
	'multi-vendor' => array(
		'name'              => 'YITH Multi Vendor/Marketplace',
		'description'       => __( 'Enable to allow vendors to manage funds', 'yith-woocommerce-account-funds' ),
		'plugin_name'       => 'YITH WooCommerce Multi Vendor / Marketplace',
		'landing_uri'       => '//yithemes.com/themes/plugins/yith-woocommerce-multi-vendor/',
		'premium'           => 'YITH_WPV_PREMIUM',
		'installed_version' => 'YITH_WPV_VERSION',
		'min_version'       => '3.7.0',
		'compare'           => '>=',
	),
);
