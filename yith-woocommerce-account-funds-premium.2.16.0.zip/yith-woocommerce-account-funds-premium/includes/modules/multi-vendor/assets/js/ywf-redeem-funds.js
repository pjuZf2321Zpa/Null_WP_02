jQuery(function ($) {

    const redeem_funds = $('form.yith_redeem_funds_form');
    const redeemAction = $('.yith-funds-redeem');

    const popup = {
        blocks :{
            message: null,
            overlayCSS: {
                background: '#fff',
                opacity: 0.6
            }
        },
        main: $('.yith-funds-redeem-popup'),
        wrapper: $('.yith-funds-redeem-popup-wrapper'),
        closeIcon: $('.yith-funds-redeem-popup-icon'),
        button: $('#yith_redeem_button'),
        form: $('.yith-funds-redeem-popup-form-content'),

        init: function () {
            popup.closeIcon.on('click', () => {
                popup.close()
            });
            popup.button.on('click', function (e) {
                e.preventDefault();
                popup.redeem();
            });
            popup.initCloseLink();
        },

        initCloseLink: function () {
            const errors = popup.wrapper.find('.yith-funds-redeem-popup-error p'),
                success = popup.wrapper.find('.yith-funds-redeem-popup-success p');

            let closeLink = popup.wrapper.find('.yith-funds-redeem-close-link');

            if (closeLink.length === 0) {
                closeLink = $('<a>');
                closeLink.addClass('yith-funds-redeem-close-link');
                closeLink.attr('href', '#');
                closeLink.appendTo(popup.wrapper.find('.yith-funds-redeem-popup-container'));

                closeLink.on('click', function (e) {
                    e.preventDefault();
                    popup.close();
                })
            }

            if (errors.length) {
                closeLink.html(ywf_redeem_funds_args.close_links.error);
            } else if (success.length) {
                closeLink.html(ywf_redeem_funds_args.close_links.success);
            }
        },
        open: function () {
            popup.center();
            popup.main.show();
        },
        close: function () {
            popup.main.hide()
            window.location.reload();
        },
        center: function () {
            let
                w = popup.wrapper.outerWidth(),
                h = popup.wrapper.outerHeight(),
                W = popup.main.width(),
                H = popup.main.height();

            const adminBar = $('#wpadminbar');
            if (adminBar.length) {
                h = h - adminBar.height() - 10;
            }

            const top = (H - h) / 2,
                left = (W - w) / 2;
            popup.wrapper.css({
                top,
                left
            });
        },
        redeem: function () {

            const amount = popup.main.find('#yith_redeem_funds').val(),
                lang = popup.main.find('input[name="lang"]').val(),
                security = popup.main.find('#yith-account-funds-redeem-funds-nonce').val();
            $.ajax({
                type: 'POST',
                url: ywf_redeem_funds_args.ajax_url,
                data: {
                    amount,
                    lang,
                    security,
                    action: 'redeem_funds'
                },
                dataType: 'json',
                beforeSend: function () {
                    popup.block();
                },
                success: function (response) {
                    popup.unblock();
                    popup.form.hide();
                    const message = response.data.message,
                        div = $('<div>');

                    div.append($('<p>'));
                    if (response.success) {
                        div.addClass('yith-funds-redeem-popup-success');
                    } else {
                        div.addClass('yith-funds-redeem-popup-error');
                    }
                    div.find('p').html(message);
                    popup.form.parent().append(div);
                    popup.initCloseLink();
                }
            });
        },
        block:function (){
            popup.wrapper.block(popup.blocks);
        },
        unblock:function (){
            popup.wrapper.unblock();
        }
    }

    popup.init();
    $(window).on('resize', function () {
        popup.center()
    });
    redeemAction.on('click', function (e) {
        e.preventDefault();
        popup.open();
    });

});
