jQuery(function ($) {

    const redeemSection = $(document).find('#ywf_min_fund_needs').closest('.yith-plugin-fw__panel__section');
    const redeemEmail =$(document).find('#ywf_redeem_email_enabled').closest('.yith-plugin-fw__panel__section');
    const redeemEndpoint = $(document).find('#ywf_redeem_funds').closest('.yith-plugin-fw__panel__section');
    const canRedeem = $(document).find('#ywf_vendor_can_redeem');
    if( 'no' === ywf_mv_module.hasPayouts ){
        redeemSection.hide();
        redeemEndpoint.hide();
        redeemEmail.hide();
    }else{

        canRedeem.on('change',function (e){
           if( 'yes' === e.target.value) {
               redeemSection.show();
               redeemEndpoint.show();
               redeemEmail.show();
           }else{
               redeemSection.hide();
               redeemEndpoint.hide();
               redeemEmail.hide();
           }
        }).trigger('change');
    }
});