<?php
$folder_name = 'modules/' . basename( dirname( __FILE__ ) );

include_once YITH_FUNDS_INC.$folder_name.'/includes/class-ywf-multivendor-admin.php';
include_once YITH_FUNDS_INC.$folder_name.'/includes/class-ywf-multivendor-redeem-payouts-gateway.php';
include_once YITH_FUNDS_INC.$folder_name.'/includes/class-ywf-multivendor-redeem.php';
include_once YITH_FUNDS_INC.$folder_name.'/includes/class-ywf-multivendor.php';