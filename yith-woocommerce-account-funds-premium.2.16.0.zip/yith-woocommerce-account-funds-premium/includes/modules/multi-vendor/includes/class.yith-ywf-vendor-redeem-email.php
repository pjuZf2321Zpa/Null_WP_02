<?php // phpcs:ignore WordPress.Files.FileName
/**
 * Class that manage the email send to admin when a vendor redeem funds
 *
 * @package YITH\AccountFunds\Classes\Emails
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'YITH_YWF_Vendor_Redeem_Email' ) ) {
	/**
	 * Class YITH_YWF_Vendor_Redeem_Email
	 */
	class  YITH_YWF_Vendor_Redeem_Email extends YITH_YWF_Email {

		/**
		 * The redeem transaction list
		 *
		 * @var array
		 */
		protected $redeem_transactions;

		/**
		 * YITH_YWF_Vendor_Redeem_Email constructor.
		 */
		public function __construct() {

			$this->id = 'ywf_vendor_redeem_email';

			$this->template_base       = YITH_FUNDS_TEMPLATE_PATH;
			$this->template_html       = 'emails/vendor-redeem-funds.php';
			$this->template_plain      = 'emails/plain/vendor-redeem-funds.php';
			$this->redeem_transactions = array();
			add_action( $this->id . '_notification', array( $this, 'trigger' ), 10, 1 );
			add_filter( 'yith_ywf_email_settings_configuration_tab', array( $this, 'add_extra_field' ), 10, 2 );
			parent::__construct();
			$this->customer_email = false;
			$this->placeholders   = array(
				'{site_title}'   => '',
				'{site_address}' => '',
				'{date}'         => ''
			);
		}


		/**
		 * Set default params.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function set_default_params() {
			parent::set_default_params();

			$this->title          = esc_html_x( 'Funds redeemed by vendor', '[Admin panel] Email title', 'yith-woocommerce-account-funds' );
			$this->description    = esc_html_x( 'This email is sent to the administrator when one or more vendors redeem their funds', '[Admin panel] Email description', 'yith-woocommerce-account-funds' );
			$this->heading        = esc_html_x( 'New vendor redeems', '[Admin panel] Email heading/subject', 'yith-woocommerce-account-funds' );
			$this->subject        = esc_html_x( '[{site_title}] Funds redeemed', '[Admin panel] Email heading/subject', 'yith-woocommerce-account-funds' );
			$this->custom_message = esc_html_x( 'The following vendors have redeemed their funds:', '[Admin panel] Email body/message', 'yith-woocommerce-account-funds' );
			$this->recipient      = get_option( 'admin_email' );
		}

		/**
		 * Initialize placeholders before sending.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function init_placeholders_before_sending() {
			$this->placeholders['{site_title}']   = $this->get_blogname();
			$this->placeholders['{site_address}'] = wp_parse_url( home_url(), PHP_URL_HOST );
			$this->placeholders['{site_url}']     = wp_parse_url( home_url(), PHP_URL_HOST );
			if ( $this->object ) {
				$this->placeholders['{date}'] = wc_format_datetime( new WC_DateTime( date( 'Y-m-d' ), new DateTimeZone( 'UTC' ) ) );
			}
		}

		/**
		 * Send the email
		 *
		 * @param array $args The email args.
		 *
		 * @author YITH <plugins@yithemes.com>
		 * @since   1.4.0
		 */
		public function trigger( $args, $output = false ) {

			$this->setup_locale();

			parent::trigger( $args, $output );

			$this->restore_locale();
		}

		/**
		 * Get the email options
		 *
		 * @param array          $options The options.
		 * @param YITH_YWF_Email $email The email.
		 *
		 * @return array
		 * @since  2.0.0
		 */
		public function add_extra_field( $options, $email ) {

			if ( $this->id === $email->id ) {
				$new_opt = array(
					'redeem_email_recipient' => array(
						'title'   => __( 'Recipient(s)', 'yith-woocommerce-account-funds' ),
						'type'    => 'text',
						'default' => get_option( 'admin_email' ),
						'desc'    => sprintf(/* translators: %s are the default emails */
							__( 'Enter recipients (comma separated) for this email. Defaults to %s.', 'yith-woocommerce-account-funds' ),
							'<code>' . esc_attr( get_option( 'admin_email' ) ) . '</code>'
						),
					)
				);
				$options = array_merge( $new_opt, $options );
			}

			return $options;
		}

		/**
		 * Get email heading.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_default_recipient(): string {
			return $this->recipient;
		}

		/**
		 * Get email heading.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_recipient() {

			$recipient  = isset( $this->object['recipient'] ) && ! empty( $this->object['recipient'] ) ? $this->object['recipient'] : $this->get_option( 'recipient', $this->get_default_recipient() );
			$recipient  = apply_filters( 'woocommerce_email_recipient_' . $this->id, $recipient, $this->object, $this );
			$recipients = array_map( 'trim', explode( ',', $recipient ) );
			$recipients = array_filter( $recipients, 'is_email' );

			return implode( ', ', $recipients );
		}

		/**
		 * Initialise settings form fields.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function init_form_fields() {
			parent::init_form_fields();
			$recipient_fields = array(
				'recipient' => array(
					'title'       => esc_html_x( 'Recipient(s)', '[Admin panel] Setting name', 'yith-woocommerce-account-funds' ),
					'type'        => 'text',
					'placeholder' => $this->get_recipient(),
					'default'     => '',
				)
			);

			$index = array_search( 'enabled', array_keys( $this->form_fields ) );

			$old_opts = array_slice( $this->form_fields, 0, $index + 1 ) + $recipient_fields + array_slice( $this->form_fields, $index + 1 );

			$this->form_fields = $old_opts;
		}

		/**
		 * Get content plain.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_content_plain(): string {
			$params = array_merge(
				array(
					'email_heading'       => $this->get_heading(),
					'sent_to_admin'       => ! $this->is_customer_email(),
					'plain_text'          => true,
					'email'               => $this,
					'custom_message'      => $this->get_custom_message(),
					'redeem_transactions' => $this->object['redeem_transactions'] ?? array()
				),
				$this->get_extra_content_params()
			);

			return wc_get_template_html( $this->template_plain, $params, '', $this->template_base );
		}

		/**
		 * Get content html.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_content_html(): string {
			$params = array_merge(
				array(
					'email_heading'       => $this->get_heading(),
					'sent_to_admin'       => ! $this->is_customer_email(),
					'plain_text'          => false,
					'email'               => $this,
					'custom_message'      => $this->get_custom_message(),
					'redeem_transactions' => $this->object['redeem_transactions'] ?? array()
				),
				$this->get_extra_content_params()
			);

			return wc_get_template_html( $this->template_html, $params, '', $this->template_base );
		}

	}
}

return new YITH_YWF_Vendor_Redeem_Email();
