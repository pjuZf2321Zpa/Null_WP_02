<?php
/**
 * This class manage the admin area for the module
 *
 * @since 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class YWF_MultiVendor_Admin extends YITH_YWF_Module_Admin {

	/**
	 * The constructor
	 */
	public function __construct() {
		$this->module_id = 'multi-vendor';
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		parent::__construct();

	}

	/**
	 * Get module tabs
	 *
	 * @return array
	 * @since  1.0.0
	 */
	protected function get_tabs() {
		return array(
			'multi-vendor' => array(
				'title' => __( 'Vendors & Funds', 'yith-woocommerce-account-funds' )
			)
		);
	}

	/**
	 * Enqueue scripts
	 *
	 * @return void
	 */
	public function enqueue_admin_scripts() {

		$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
		$tab  = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
		wp_register_script( 'ywf-multi-vendor', YITH_YWF_Modules::get_module_assets_url('multi-vendor') . '/js/' . yit_load_js_file( 'admin.js' ), array( 'jquery' ), YITH_FUNDS_VERSION, true );

		$args = array(
			'hasPayouts' => defined( 'YITH_PAYOUTS_PREMIUM' ) ? 'yes' : 'no'
		);
		wp_localize_script( 'ywf-multi-vendor', 'ywf_mv_module', $args );

		if ( 'yith_funds_panel' === $page && 'multi-vendor' === $tab ) {
			wp_enqueue_script( 'ywf-multi-vendor' );
		}
	}
}

new YWF_MultiVendor_Admin();