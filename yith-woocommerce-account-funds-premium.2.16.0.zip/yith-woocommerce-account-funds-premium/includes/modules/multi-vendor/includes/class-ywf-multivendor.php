<?php
/**
 * This class manage the MV module
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class YWF_Multivendor {

	public function __construct() {

		add_filter( 'yith_funds_user_is_available', array( $this, 'vendor_can_deposit_funds' ), 20 );

		add_filter( 'yith_fund_product_is_purchasable', array( $this, 'funds_product_is_purchasable' ), 20 );
		add_filter( 'ywf_is_available_fund_gateway', array( $this, 'vendor_funds_gateway_is_available' ), 20 );
		add_filter( 'woocommerce_email_enabled_yith_user_funds_email', array(
			$this,
			'enable_charge_funds_email_for_vendor'
		), 20, 2 );

		add_action( 'init', array( $this, 'init_redeem' ), 30 );


	}

	/**
	 * Init redeem feature
	 *
	 * @return void
	 */
	public function init_redeem() {
		$vendor_can_redeem = get_option( 'ywf_vendor_can_redeem', 'no' );
		if ( 'yes' === $vendor_can_redeem ) {
			add_filter( 'ywf_woocommerce_emails', array( $this, 'add_vendor_redeem_emails' ), 20 );
			add_filter( 'ywf_test_email_args', array( $this, 'add_vendor_redeem_emails_args' ), 20, 2 );

			if ( $this->vendor_can_redeem_funds() && ( $this->is_paypal_payouts_enabled() && YITH_PayOuts_Service()->check_service_configuration() ) ) {

				YWF_Multivendor_Redeem::init();
			}
		}

	}

	/**
	 * Check if a vendor can deposit funds
	 *
	 * @return bool
	 * @since 2.0.0
	 */
	public function vendor_can_deposit_funds( $can_deposit = true ) {
		$vendor           = function_exists( 'yith_wcmv_get_vendor' ) ? yith_wcmv_get_vendor( 'current', 'user' ) : yith_get_vendor( 'current', 'user' );
		$can_make_deposit = get_option( 'ywf_vendor_can_charge', 'no' );

		if ( $vendor->is_valid() && $vendor->is_owner() ) {
			$can_deposit = 'yes' === $can_make_deposit;
		}

		return $can_deposit;
	}

	/**
	 * Check if the funds product is purchasable for vendors
	 *
	 * @param bool $is_purchasable If is purchasable.
	 *
	 * @return bool
	 * @since 2.0.0
	 */
	public function funds_product_is_purchasable( $is_purchasable ) {

		if ( ! $this->vendor_can_deposit_funds() ) {
			$is_purchasable = false;
		}

		return $is_purchasable;
	}

	/**
	 * Check if the vendor can use funds
	 *
	 * @param boolean $is_available Gateway is available
	 *
	 * @return boolean
	 */
	public function vendor_funds_gateway_is_available( $is_available ) {

		if ( ! $this->vendor_can_use_funds() ) {

			$is_available = false;
		}

		return $is_available;
	}

	/**
	 * Check if send or not the charge funds email to vendors
	 *
	 * @param bool    $is_enabled If email is enabled.
	 * @param WP_User $user The user.
	 *
	 * @return bool
	 * @since 2.0.0
	 */
	public function enable_charge_funds_email_for_vendor( $is_enabled, $user ) {

		if ( $user instanceof WP_User ) {
			$vendor = function_exists( 'yith_wcmv_get_vendor' ) ? yith_wcmv_get_vendor( $user->ID, 'user' ) : yith_get_vendor( 'current', 'user' );

			$can_make_deposit = get_option( 'ywf_vendor_can_charge', 'no' );

			if ( $vendor->is_valid() && $vendor->is_owner( $user->ID ) && 'no' === $can_make_deposit ) {
				$is_enabled = false;
			}
		}

		return $is_enabled;
	}

	/**
	 * Check if the vendor can use funds
	 *
	 *
	 * @return bool
	 * @since 2.0.0
	 */
	public function vendor_can_use_funds() {

		$vendor  = function_exists( 'yith_wcmv_get_vendor' ) ? yith_wcmv_get_vendor( 'current', 'user' ) : yith_get_vendor( 'current', 'user' );
		$can_use = true;
		if ( $vendor->is_valid() && $vendor->is_owner() && 'no' === get_option( 'ywf_vendor_can_use', 'no' ) ) {
			$can_use = false;
		}

		return $can_use;
	}

	/**
	 * Check if vendor can redeem funds
	 *
	 * @return bool
	 * @since 2.0.0
	 */
	public function vendor_can_redeem_funds() {

		$vendor  = function_exists( 'yith_wcmv_get_vendor' ) ? yith_wcmv_get_vendor( 'current', 'user' ) : yith_get_vendor( 'current', 'user' );
		$can_use = false;

		if ( $vendor->is_valid() && $vendor->is_owner() ) {
			$can_use = true;
		}

		return $can_use;
	}

	/**
	 * Check if YITH PayPal Payouts plugin is activated
	 *
	 * @return bool
	 * @since 2.0.0
	 */
	public function is_paypal_payouts_enabled() {

		return defined( 'YITH_PAYOUTS_PREMIUM' ) && version_compare( YITH_PAYOUTS_VERSION, '1.0.12', '>=' );
	}

	/**
	 * Add the test argument for the email
	 *
	 * @param array  $args The args.
	 * @param string $email_id The email id.
	 *
	 * @return array
	 */
	public function add_vendor_redeem_emails_args( $args, $email_id ) {

		if ( 'ywf_vendor_redeem_email' === $email_id ) {
			$args['redeem_transactions'] = array(
				array(
					'user_id' => get_current_user_id(),
					'amount'  => wc_price( 10 ),
				)
			);
		}

		return $args;
	}

	/**
	 * Add custom email class
	 *
	 * @param array $emails The WooCommerce emails.
	 *
	 * @return array
	 * @since  2.0.0
	 */
	public function add_vendor_redeem_emails( $emails ) {
		$emails['YITH_YWF_Vendor_Redeem_Email'] = include 'class.yith-ywf-vendor-redeem-email.php';

		return $emails;
	}
}

new YWF_Multivendor();