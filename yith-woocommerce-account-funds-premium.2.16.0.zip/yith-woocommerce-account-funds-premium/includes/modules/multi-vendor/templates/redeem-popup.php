<?php
/**
 * The template to allow vendor to redeem funds
 *
 * @var float  $funds_to_redeem The funds can be redeemed
 * @var float  $min_to_redeem The minimum to redeem.
 * @var string $lang The current language.
 * @var string $error_message The error message to show.
 * @var string $currency_notice The currency notice.
 * @var string $currency_symbol The currency symbol.
 * @var string $button_label The button label.
 * @var int    $user_id The user id.
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="yith-funds-redeem-popup">
    <div class="yith-funds-redeem-popup-wrapper">
        <div class="yith-funds-redeem-popup-container">
            <div class="yith-funds-redeem-popup-header">
                <div class="yith-funds-redeem-popup-icon">
                </div>
                <div class="yith-funds-redeem-popup-title">
                    <h3><?php esc_html_e( 'Redeem your funds', 'yith-woocommerce-account-funds' ); ?></h3>
                </div>
            </div>
            <div class="yith-funds-redeem-popup-content">
				<?php if ( ! empty( $currency_notice ) ): ?>
                    <div class="yith-funds-redeem-popup-notice">
                        <p><?php echo wp_kses_post( $currency_notice ); ?></p>
                    </div>
				<?php endif; ?>
				<?php if ( ! empty( $error_message ) ): ?>
                    <div class="yith-funds-redeem-popup-error">
                        <p><?php echo wp_kses_post( $error_message ); ?></p>
                    </div>
				<?php else: ?>
                    <div class="yith-funds-redeem-popup-form-content">
                        <div class="yith-funds-add-fund-form">
                            <div class="yith-funds-add-fund-currency"><?php echo esc_html( $currency_symbol ); ?></div>
                            <div class="yith-funds-add-fund-input">
                                <input id="yith_redeem_funds" type="number"
                                       min="<?php echo esc_attr( $min_to_redeem ); ?>"
                                       max="<?php echo esc_attr( $funds_to_redeem ); ?>"
                                       name="yith_redeem_funds"
                                       step="0.01"
                                       value="<?php echo esc_attr( $funds_to_redeem ); ?>"
                                       placeholder="<?php esc_html_e( 'Enter amount', 'yith-woocommerce-account-funds' ); ?>"/>
                            </div>
                        </div>
                        <input id="yith_redeem_button" type="submit" class="button yith-funds-redeem-fund"
                               value="<?php echo esc_attr( $button_label ); ?>"/>

                        <input type="hidden" name="lang" value="<?php echo esc_attr( $lang ); ?>">

						<?php wp_nonce_field( 'yith_account_funds-redeem_funds', 'yith-account-funds-redeem-funds-nonce' ); ?>
                    </div>
				<?php endif; ?>
            </div>
        </div>
    </div>
</div>
