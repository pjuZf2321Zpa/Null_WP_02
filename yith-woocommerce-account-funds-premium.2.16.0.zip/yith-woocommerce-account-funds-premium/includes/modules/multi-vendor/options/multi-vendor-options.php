<?php
/**
 * Plugin Options : Vendor multi tab options
 *
 * @package YITH\AccountFunds\PluginOptions
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$payouts_uri = yith_plugin_fw_add_utm_data( '//yithemes.com/themes/plugins/yith-paypal-payouts-for-woocommerce/', 'yith-woocommerce-account-funds', 'multi-vendor' );
$extra_desc  = sprintf(
	__(
		'%3$sRequires%4$s %1$sYITH PayPal Payout for WooCommerce%2$s to use this feature.',
		'yith-woocommerce-account-funds'
	),
	'<a href="' . esc_url( $payouts_uri ) . '">',
	'</a>',
	'<strong>',
	'</strong>'
);


$desc              = sprintf(/* translators: %s is the list of placeholders */
	__( 'Available placeholders: %s', 'yith-woocommerce-account-funds' ),
	'<code>' . implode( '</code>, <code>', array( '{site_title}', '{site_address}', '{date}' ) ) . '</code>'
);
return array(
	'multi-vendor' => array(
		'funds-capabilities'      => array(
			'type' => 'title',
			'name' => __( 'Vendor permission', 'yith-woocommerce-account-funds' ),
		),
		'vendor_can_charge_funds' => array(
			'id'        => 'ywf_vendor_can_charge',
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'name'      => __( 'The vendor can charge funds', 'yith-woocommerce-account-funds' ),
			'default'   => 'no',
			'desc'      => __( 'If enabled, vendor can charge funds like a normal customer', 'yith-woocommerce-account-funds' ),
		),
		'vendor_can_use_funds'    => array(
			'id'        => 'ywf_vendor_can_use',
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'name'      => __( 'The vendor can use funds', 'yith-woocommerce-account-funds' ),
			'default'   => 'no',
			'desc'      => __( 'If enabled, vendor can use funds to purchase products', 'yith-woocommerce-account-funds' ),
		),
		'vendor_can_redeem_funds' => array(
			'id'                 => 'ywf_vendor_can_redeem',
			'type'               => 'yith-field',
			'is_option_disabled' => ! defined( 'YITH_PAYOUTS_PREMIUM' ),
			'yith-type'          => 'onoff',
			'name'               => __( 'The vendor can redeem their funds', 'yith-woocommerce-account-funds' ),
			'default'            => 'no',
			'desc'               => __( 'If enabled, the vendor can request to redeem their funds. They will be sent to their PayPal account.', 'yith-woocommerce-account-funds' ),
		),
		'vendor_can_redeem_note'  => array(
			'type'      => 'yith-field',
			'yith-type' => 'html',
			'html'      => ! defined( 'YITH_PAYOUTS_PREMIUM' ) ? $extra_desc : ''
		),
		'funds-capabilities-end'  => array(
			'type' => 'sectionend',
		),
		'redeeming_section_start'           => array(
			'type' => 'title',
			'name' => __( 'Redeem settings', 'yith-woocommerce-account-funds' ),
		),
		'redeeming_min_fund_needs'          => array(
			'name'      => __( 'Minimum funds to redeem', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'number',
			'id'        => 'ywf_min_fund_needs',
			'min'       => 0,
			'step'      => 0.1,
			'default'   => 50,
			'desc'      => __( 'Set the minimum balance necessary for a vendor to redeem funds', 'yith-woocommerce-account-funds' ),
		),
		'redeeming_max_fund_needs'          => array(
			'name'      => __( 'Maximum funds to redeem', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'number',
			'id'        => 'ywf_max_fund_redeem',
			'min'       => 0,
			'step'      => 0.1,
			'default'   => 100,
			'desc'      => __( 'Set the maximum funds that can be redeemed in a transaction, leave empty to disable this restriction.', 'yith-woocommerce-account-funds' ),
		),
		'redeeming_gateway'                 => array(
			'id'        => 'ywf_redeeming_gateway',
			'type'      => 'yith-field',
			'yith-type' => 'hidden',
			'default'   => 'yith_payout',
		),
		'redeeming_payment_type'            => array(
			'id'        => 'ywf_redeeming_payment_type',
			'name'      => __( 'Automatic Redeem Type', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'radio',
			'options'   => array(
				'none'                => __( 'None', 'yith-woocommerce-account-funds' ),
				'automatic'           => __( 'Automatically when the minimum threshold is reached', 'yith-woocommerce-account-funds' ),
				'automatic_with_date' => __( 'Automatically, on a specific day and when the minimum threshold is reached.', 'yith-woocommerce-account-funds' ),
			),
			'default'   => 'automatic',
		),
		'redeeming_day'                     => array(
			'id'        => 'ywf_redeeming_day',
			'name'      => __( 'Redeem Day', 'yith-woocommerce-account-funds' ),
			'desc'      => __( 'Set a day of the month for redeeming payment funds', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'number',
			'min'       => 1,
			'max'       => 31,
			'default'   => 15,
			'deps'      => array(
				'id'    => 'ywf_redeeming_payment_type',
				'value' => 'automatic_with_date',
				'type'  => 'show',
			),
		),
		'redeeming_fund_manual'             => array(
			'id'        => 'ywf_enable_manual_redeeming',
			'name'      => __( 'Manual Redeem', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'default'   => 'no',
			'desc'      => __( 'If enabled, the vendor can redeem funds from \'My Account\' Page', 'yith-woocommerce-account-funds' ),
		),
		'redeeming_button_label'            => array(
			'id'        => 'ywf_redeeming_button_label',
			'name'      => __( 'Redeem Button', 'yith-woocommerce-account-funds' ),
			'type'      => 'yith-field',
			'yith-type' => 'text',
			'default'   => __( 'Redeem funds!', 'yith-woocommerce-account-funds' ),
			'desc'      => __( 'Set the text for the redeem button visible on \'My Account\' page', 'yith-woocommerce-account-funds' ),
			'deps'      => array(
				'id'    => 'ywf_enable_manual_redeeming',
				'value' => 'yes',
				'type'  => 'show',
			),
		),
		'redeeming_button_text_color'       => array(
			'id'           => 'ywf_redeeming_button_text_color',
			'name'         => __( 'Redeem Button Text Color', 'yith-woocommerce-account-funds' ),
			'type'         => 'yith-field',
			'yith-type'    => 'multi-colorpicker',
			'colorpickers' => array(
				array(
					'name'    => __( 'Default', 'yith-woocommerce-account-funds' ),
					'id'      => 'color',
					'default' => '#fff',
				),
				array(
					'name'    => __( 'Hover', 'yith-woocommerce-account-funds' ),
					'id'      => 'hover_color',
					'default' => '#fff',
				),
			),
			'desc'         => __( 'Set the color for the button text', 'yith-woocommerce-account-funds' ),
			'deps'         => array(
				'id'    => 'ywf_enable_manual_redeeming',
				'value' => 'yes',
				'type'  => 'show',
			),
		),
		'redeeming_button_background_color' => array(
			'id'           => 'ywf_redeeming_button_background_color',
			'name'         => __( 'Redeem Button Color', 'yith-woocommerce-account-funds' ),
			'type'         => 'yith-field',
			'yith-type'    => 'multi-colorpicker',
			'colorpickers' => array(
				array(
					'name'    => __( 'Default', 'yith-woocommerce-account-funds' ),
					'id'      => 'color',
					'default' => 'rgb(1,175,141)',
				),
				array(
					'name'    => __( 'Hover', 'yith-woocommerce-account-funds' ),
					'id'      => 'hover_color',
					'default' => 'rgb(16,119,116)',
				),
			),
			'desc'         => __( 'Set the color for the button background', 'yith-woocommerce-account-funds' ),
			'deps'         => array(
				'id'    => 'ywf_enable_manual_redeeming',
				'value' => 'yes',
				'type'  => 'show',
			),
		),
		'redeeming_section_end'           => array(
			'type' => 'sectionend'
		)
	)
);
