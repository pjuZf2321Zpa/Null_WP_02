<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;


final class YithFunds extends AbstractPaymentMethodType {
	/**
	 * Payment method name/id/slug (matches id in WC_Gateway_BACS in core).
	 *
	 * @var string
	 */
	protected $name = 'yith_funds';

	/**
	 * The gateway instance.
	 *
	 * @var WC_Gateway_YITH_Funds
	 */
	private $gateway;


	/**
	 * Initializes the payment method type.
	 */
	public function initialize() {
		$this->gateway                 = new WC_Gateway_YITH_Funds();
		$this->settings                = get_option( 'woocommerce_yith_funds_settings', [] );
		$this->settings['description'] = $this->gateway->description;
	}

	/**
	 * Returns if this payment method should be active. If false, the scripts will not be enqueued.
	 *
	 * @return boolean
	 */
	public function is_active() {
		return filter_var( $this->get_setting( 'enabled', false ), FILTER_VALIDATE_BOOLEAN );
	}

	/**
	 * Returns an array of scripts/handles to be registered for this payment method.
	 *
	 * @return array
	 */
	public function get_payment_method_script_handles() {
		$scripts = array();

		$deps    = include YITH_FUNDS_DIR . 'assets/js/wc-blocks/payment-method/index.asset.php';
		$scripts = array(
			'yith-gateway-funds-block'
		);

		wp_register_script(
			'yith-gateway-funds-block',
			YITH_FUNDS_ASSETS_URL . 'js/wc-blocks/payment-method/index.js',
			$deps['dependencies'],
			$deps['version'],
			true
		);


			$gateway_args = array(
				'coupon_code'          => YITH_YWF_Cart_Process()->generate_coupon_code(),
				'deposit_coupon_code'  => YITH_YWF_Deposit_Fund_Checkout()->get_deposit_coupon_code(),
				'coupon_note'          => __( 'Discount applied for having used your account funds!', 'yith-woocommerce-account-funds' ),
				'coupon_label'         => __( 'Discount for funds used', 'yith-woocommerce-account-funds' ),
				'deposit_coupon_label' => __( 'Deposit Discount', 'yith-woocommerce-account-funds' ),
			);
			wp_localize_script( 'yith-gateway-funds-block', 'yith_gateway_funds_args', $gateway_args );


		$remove_partial_payments_args = $this->get_remove_partial_payments_args();

		if ( $remove_partial_payments_args ) {
			$scripts[] = 'yith-remove-partial-payments-block';
			$deps      = include YITH_FUNDS_DIR . 'assets/js/wc-blocks/remove-partial-payments/index.asset.php';
			wp_register_script(
				'yith-remove-partial-payments-block',
				YITH_FUNDS_ASSETS_URL . 'js/wc-blocks/remove-partial-payments/index.js',
				$deps['dependencies'],
				$deps['version'],
				true
			);

			wp_localize_script( 'yith-remove-partial-payments-block', 'ywf_remove_partial_payments', $remove_partial_payments_args );
			wp_enqueue_script( 'yith-remove-partial-payments-block' );
		}

		return $scripts;
	}

	/**
	 * Returns an array of key=>value pairs of data made available to the payment methods script.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		return [
			'title'       => $this->get_setting( 'title' ),
			'description' => $this->get_setting( 'description' ),
			'supports'    => $this->get_supported_features(),
		];
	}

	/**
	 * Returns an array of supported features.
	 *
	 * @return string[]
	 */
	public function get_supported_features() {

		$features = array_filter( $this->gateway->supports, array( $this->gateway, 'supports' ) );

		/**
		 * Filter to control what features are available for each payment gateway.
		 *
		 * @param array  $features List of supported features.
		 * @param string $name Gateway name.
		 *
		 * @return array Updated list of supported features.
		 * @example See docs/examples/payment-gateways-features-list.md
		 *
		 * @since 4.4.0
		 *
		 */
		return apply_filters( '__experimental_woocommerce_blocks_payment_gateway_features_list', $features, $this->get_name() );
	}


	/**
	 * Return if is enabled, the remove partial payments script args
	 *
	 * @return array|false
	 */
	public function get_remove_partial_payments_args() {
		$args      = false;
		$fund_used = ! is_null( WC()->session ) ? WC()->session->get( 'ywf_fund_used', false ) : false;
		if ( ywf_partial_payment_enabled() && is_user_logged_in() && false !== $fund_used ) {
			$callback_url = esc_url( add_query_arg( 'remove_yith_funds', true, get_permalink( is_cart() ? wc_get_page_id( 'cart' ) : wc_get_page_id( 'checkout' ) ) ) );
			$args         = array(
				'label'        => __( 'User funds', 'yith-woocommerce-account-funds' ),
				'funds_used'   => wc_price( $fund_used ),
				'callback_url' => $callback_url,
			);
		}

		return $args;
	}
}
