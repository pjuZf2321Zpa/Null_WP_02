<?php
/**
 * Admin modules list
 *
 * @author  YITH
 * @package YITH/AI-Search
 * @version 1.0.0
 * @var array $modules A list of available modules.
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

?>

<div id="modules-container">
	<?php
	foreach ( $modules as $module_id => $module ) :
		$available = YITH_YWF_Modules::is_module_available( $module_id );
		$active = YITH_YWF_Modules::is_module_active( $module_id );
		?>
        <div class="module" data-module="<?php echo esc_attr( $module_id ); ?>">
            <header>
				<?php if ( isset( $module['name'] ) ) : ?>
                    <h3><?php echo esc_html( $module['name'] ); ?></h3>
				<?php endif; ?>
				<?php if ( ! $available ) : ?>
                    <a href="<?php echo isset( $module['landing_uri'] ) ? esc_url( $module['landing_uri'] ) : '#'; ?>"
                       class="yith-plugin-fw__button--primary" target="_blank">
						<?php echo esc_html_x( 'Get it', 'Link label for plugin module landing', 'yith-woocommerce-account-funds' ); ?>
                    </a>
				<?php endif; ?>
            </header>
            <?php if ( ! $available ) : ?>
            <p class="module-required">
		        <?php
		        // translators: %s is the required plugin for activate the module.
		        echo esc_html( sprintf( _x( 'Needs %s', 'Vendor addons: %s is the plugin name requested by the addon', 'yith-woocommerce-account-funds' ), $module['plugin_name'] ) );
		        ?>
            </p>
            <?php endif; ?>
			<?php if ( isset( $module['description'] ) ) : ?>
                <div class="module-description"><?php echo wp_kses_post( $module['description'] ); ?></div>
			<?php endif; ?>
			<?php if ( $available ) : ?>
                <div class="module-activation">
                    <label for="<?php echo esc_attr( $module_id ); ?>_active">
						<?php echo esc_html__( 'Enable module', 'yith-woocommerce-account-funds' ); ?>
                    </label>
					<?php
					yith_plugin_fw_get_field(
						array(
							'id'                => $module_id . '_active',
							'name'              => $module_id . '_active',
							'type'              => 'onoff',
							'default'           => 'no',
							'class'             => 'on-off-module',
							'value'             => YITH_YWF_Modules::is_module_active( $module_id ) ? 'yes' : 'no',
							'custom_attributes' => array( 'data-module' => $module_id ),
						),
						true,
						false
					);
					?>
                </div>
			<?php endif; ?>
        </div>
	<?php endforeach; ?>
</div>
