<?php // phpcs:ignore WordPress.Files.FileName
/**
 * This is the class that manage the endpoints
 *
 * @author YITH <plugins@yithemes.com>
 * @package YITH\AccountFunds\Classes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'YITH_Funds_EndPoints' ) ) {
	/**
	 * Class YITH_Funds_EndPoints
	 */
	class YITH_Funds_EndPoints {
		/**
		 * The query vars
		 *
		 * @var array
		 */
		public $fund_query_vars = array();

		/**
		 * YITH_Funds_EndPoints constructor.
		 */
		public function __construct() {
			$funds = yith_account_funds_get_endpoint_slug( 'funds' );
			add_action( 'wp_loaded', array( $this, 'history_filter' ), 20 );
			if ( ! empty( $funds ) ) {
				add_action( 'init', array( $this, 'init_endpoint' ) );
				add_filter( 'woocommerce_account_menu_items', array( $this, 'funds_account_menu_items' ), 20 );
				add_action( 'woocommerce_account_' . $funds . '_endpoint', array( $this, 'display_funds_endpoint' ) );
				add_action( 'yith_funds_endpoint', array( $this, 'maybe_show_history' ) );
				// Add custom item in YITH MY ACCOUNT MENU.
				add_action( 'yith_myaccount_menu', array( $this, 'add_myaccount_menu' ) );
				add_filter( 'yit_get_myaccount_menu_icon_list', array( $this, 'funds_account_menu_icon_list' ) );
				add_filter( 'yit_get_myaccount_menu_icon_list_fa', array( $this, 'funds_account_menu_icon_list_fa' ) );

                add_filter( 'yith_proteo_myaccount_custom_icon', array( $this, 'customize_my_account_proteo_icon' ), 10, 2 );

			}

			add_action( 'wp_loaded', array( $this, 'maybe_rewrite_rules' ), 30 );
			add_action( 'update_option_ywf_funds_endpoint_slug', array( $this, 'check_rewrite_endpoints' ), 10, 2 );
			add_filter( 'wcml_register_endpoints_query_vars', array( $this, 'register_endpoint' ), 10, 3 );
			add_filter( 'wcml_endpoint_permalink_filter', array( $this, 'endpoint_permalink_filter' ), 10, 2 );
		}


		/**
		 * Init the endpoint
		 *
		 * @return void
		 */
		public function init_endpoint() {

			$funds = yith_account_funds_get_endpoint_slug( 'funds' );
			if ( ! empty( $funds ) ) {
				add_rewrite_endpoint( $funds, EP_ROOT | EP_PAGES );
			}
		}

		/**
		 * Add menu items in my-account menu (WC 2.6)
		 *
		 * @param array $menu_items The menu items.
		 *
		 * @return array
		 * @since 1.0.19
		 */
		public function funds_account_menu_items( $menu_items ) {

			$fund_slug = yith_account_funds_get_endpoint_slug( 'funds' );
			if ( ! empty( $fund_slug ) ) {
				$fund_title = yith_account_funds_get_endpoint_title( 'funds' );

				if ( isset( $menu_items['customer-logout'] ) ) {
					$logout = $menu_items['customer-logout'];
					unset( $menu_items['customer-logout'] );
				}

				$menu_items[ $fund_slug ] = $fund_title;
				$menu_items               = apply_filters( 'yith_account_funds_menu_items', $menu_items );

				if ( isset( $logout ) ) {
					$menu_items['customer-logout'] = $logout;
				}
			}

			return $menu_items;
		}

		/**
		 * Show the funds endpoint
		 *
		 * @return void
		 */
		public function display_funds_endpoint() {

			if ( ! is_user_logged_in() ) {
				wp_safe_redirect( esc_url( wc_get_page_permalink( 'myaccount' ) ) );
				exit;
			}

			wc_get_template( 'woocommerce/myaccount/funds.php', array(), '', YITH_FUNDS_TEMPLATE_PATH );
		}


		/**
		 * Check if is possible show the user log tabel in funds endpoint
		 *
		 * @return void
		 */
		public function maybe_show_history() {

			$show_history = get_option( 'ywf_show_endpoint_history', 'no' );

			if ( yith_plugin_fw_is_true( $show_history ) ) {
				echo apply_shortcodes( '[yith_ywf_show_history pagination="yes"]' );
			}
		}

		/**
		 * Check the current filter log, is empty remove the query arg
		 *
		 * @return void
		 */
		public function history_filter() {
			if ( isset( $_GET['funds_history_filter'] ) ) {
				$current_filter = sanitize_text_field( wp_unslash( $_GET['funds_history_filter'] ) );

				if ( '' === $current_filter ) {
					wp_safe_redirect( remove_query_arg( 'funds_history_filter' ) );
					exit();
				}
			}
		}

		/**
		 * Get the plugin endpoints
		 *
		 * @return array
		 */
		public function get_endpoints() {
			return apply_filters( 'yith_account_funds_endpoints', array(
				'funds'        => yith_account_funds_get_endpoint_slug( 'funds' ),
			) );
		}

		/**
		 * Register endpoint in wpml
		 *
		 * @param array          $query_vars The query vars.
		 * @param array          $wc_vars The wc vars.
		 * @param WCML_Endpoints $obj the WCML object.
		 *
		 *
		 * @since 1.0.19
		 */
		public function register_endpoint( $query_vars, $wc_vars, $obj ) {
			foreach ( $this->get_endpoints() as $key => $name ) {

				$query_vars[ $key ] = $obj->get_endpoint_translation( $key, isset( $wc_vars[ $key ] ) ? $wc_vars[ $key ] : $key );
			}

			return $query_vars;
		}

		/**
		 * Filter the endpoint
		 *
		 * @param array  $endpoint The endpoints.
		 * @param string $key The key.
		 *
		 * @return mixed
		 */
		public function endpoint_permalink_filter( $endpoint, $key ) {

			$endpoints = $this->get_endpoints();
			$keys      = array_keys( $endpoints );
			if ( in_array( $key, $keys, true ) ) {

				$endpoint = $endpoints[ $key ];
			}

			return $endpoint;
		}

		/**
		 * Rewrite the endpoints
		 *
		 * @param string $old The old option.
		 * @param string $new The new option.
		 */
		public function check_rewrite_endpoints( $old, $new ) {
			if ( $old !== $new ) {
				update_option( 'yith_funds_need_rewrite', 'yes' );
			}
		}

		/**
		 * Flush permalinks
		 *
		 * @return void
		 */
		public function maybe_rewrite_rules() {
			$needed = get_option( 'yith_funds_need_rewrite', 'no' );
            $first = get_option( 'yith_funds_need_rewrite_first_time', 'yes' );

			if ( 'yes' === $needed  || 'yes' === $first ) {
				update_option( 'yith_funds_need_rewrite', 'no' );
				update_option( 'yith_funds_need_rewrite_first_time', 'no' );
				flush_rewrite_rules();
			}
		}

		/**
		 * Add funds menu in myaccount
		 *
		 * @param string $myaccount_url The menu.
		 *
		 * @since 1.0.0
		 */
		public function add_myaccount_menu( $myaccount_url ) {

			global $wp;
			if ( is_user_logged_in() ) {
				$slug_make_deposit = yith_account_funds_get_endpoint_slug( 'funds' );

				$funds_url       = wc_get_endpoint_url( $slug_make_deposit, '', $myaccount_url );

				?>
				<li>
					<span class="fa fa-credit-card"></span>
					<a style="display: inline-block;padding-left: 8px;" href="<?php echo esc_url( $funds_url ); ?>" title="<?php esc_attr_e( 'Make a deposit', 'yith-woocommerce-account-funds' ); ?>"<?php echo isset( $wp->query_vars['funds'] ) ? ' class="active"' : ''; ?>><?php esc_html_e( 'Funds', 'yith-woocommerce-account-funds' ); ?></a>
				</li>
				<?php
			}
		}

		/**
		 * Add funds menu with icon
		 *
		 * @param array $icon_list The array.
		 *
		 * @return array
		 * @since 1.0.0
		 */
		public function funds_account_menu_icon_list( $icon_list ) {
			$slug_make_deposit = yith_account_funds_get_endpoint_slug( 'funds' );

			$icon_list[ $slug_make_deposit ] = '&#xe04d;';

			return $icon_list;
		}

		/**
		 * Add fontawesome icon
		 *
		 * @param array $icon_list The icons.
		 *
		 * @return array
		 * @since 1.0.4
		 */
		public function funds_account_menu_icon_list_fa( $icon_list ) {
			$slug_make_deposit = yith_account_funds_get_endpoint_slug( 'funds' );

			$icon_list[ $slug_make_deposit ] = 'fa-money';

			return $icon_list;

		}

		/**
		 * Change the icon inside my account on Proteo Theme
		 *
		 * @param string $icon Icon.
		 * @param string $endpoint Endpoint.
		 *
		 * @return string
		 */
		public function customize_my_account_proteo_icon( $icon, $endpoint ) {
            $my_endpoint = yith_account_funds_get_endpoint_slug( 'funds' );
			if ( $endpoint === $my_endpoint ) {
				return '<span class="yith-proteo-myaccount-icons funds-icon"></span>';
			}

			return $icon;
		}

	}
}

/**
 * Return the instance of the class
 *
 * @return YITH_Funds_EndPoints
 * @since 1.0.0
 */
function YITH_Fund_EndPoints() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName
	return new YITH_Funds_EndPoints();
}

