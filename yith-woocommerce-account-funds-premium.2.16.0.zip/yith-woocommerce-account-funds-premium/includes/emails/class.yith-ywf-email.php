<?php
/**
 * Class YITH_YWF_Email
 *
 * @package YITH\Account Funds\Emails
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

if ( ! class_exists( 'YITH_YWF_Email' ) ) {
	/**
	 * Class YITH_YWF_Email
	 *
	 * @since   2.0.0
	 * @author  YITH <plugins@yithemes.com>
	 * @package YITH\Account Funds\Emails
	 */
	abstract class YITH_YWF_Email extends WC_Email {

		/**
		 * Default custom message.
		 *
		 * @var string
		 */
		public $custom_message = '';

		/**
		 * Default email language
		 *
		 * @var string
		 */
		public $previous_language = '';

		/**
		 * YITH_YWF_Email constructor.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function __construct() {
			$this->customer_email = true;

			$this->placeholders = array_merge(
				array(
					'{customer_name}'      => '',
					'{customer_last_name}' => '',
					'{customer_email}'     => '',
				),
				$this->placeholders
			);


			$this->set_default_params();

			add_action( 'yith_ywf_email_before_sending', array( $this, 'switch_language_to_translate_email' ), 10, 2 );
			add_action( 'yith_ywf_email_after_sending', array( $this, 'switch_language_after_translating_email' ) );
			parent::__construct();
		}


		/**
		 * Override it to set default params.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function set_default_params() {
		}

		/**
		 * Trigger.
		 *
		 * @param array $args_obj The email arguments.
		 * @param bool  $output Check if the function should return a value.
		 *
		 * @return void|bool
		 * @since  2.0.0
		 */
		public function trigger( array $args_obj, bool $output = false ) {

			$this->object = $args_obj;

			$this->maybe_set_recipient();

			if ( ! $this->is_enabled() || ! $this->get_recipient() ) {
				return false;
			}

			/**
			 * DO_ACTION: yith_ywf_email_before_sending
			 *
			 * Adds an action before email is sent.
			 *
			 * @param WC_Email $this The current email.
			 * @param string   $review The customer email.
			 */
			do_action( 'yith_ywf_email_before_sending', $this, $this->customer_email );

			$this->init_placeholders_before_sending();
			$status = $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );

			/**
			 * DO_ACTION: yith_ywf_email_after_sending
			 *
			 * Adds an action after email is sent.
			 *
			 * @param WC_Email $this The current email.
			 * @param string   $review The customer email.
			 */
			do_action( 'yith_ywf_email_after_sending', $this, $this->customer_email );

			if ( $output ) {
				return $status;
			}

		}

		/**
		 * Initialize placeholders before sending.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function init_placeholders_before_sending() {
			if ( isset( $this->object['user'] ) ) {
				$this->placeholders['{customer_name}']      = $this->object['user']['customer_name'];
				$this->placeholders['{customer_last_name}'] = $this->object['user']['customer_last_name'];
				$this->placeholders['{customer_email}']     = $this->object['user']['customer_email'];

				$this->placeholders = apply_filters( 'yith_ywf_email_placeholders', $this->placeholders, $this );
			}
		}

		/**
		 * Maybe set customer recipient email.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		protected function maybe_set_recipient() {
			if ( $this->object ) {
				$this->recipient = $this->customer_email ? $this->object['user']['customer_email'] : get_option( 'admin_email' );
			}
		}

		/**
		 * Get content plain.
		 *
		 * @return string
		 * @since  2.0.0
		 */

		public function get_content_plain(): string {
			$params = array_merge(
				array(
					'email_heading'  => $this->get_heading(),
					'sent_to_admin'  => ! $this->is_customer_email(),
					'plain_text'     => true,
					'email'          => $this,
					'custom_message' => $this->get_custom_message(),
				),
				$this->get_extra_content_params()
			);

			return wc_get_template_html( $this->template_plain, $params, '', $this->template_base );
		}

		/**
		 * Get content html.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_content_html(): string {
			$params = array_merge(
				array(
					'email_heading'  => $this->get_heading(),
					'sent_to_admin'  => ! $this->is_customer_email(),
					'plain_text'     => false,
					'email'          => $this,
					'custom_message' => $this->get_custom_message()
				),
				$this->get_extra_content_params()
			);

			return wc_get_template_html( $this->template_html, $params, '', $this->template_base );
		}

		/**
		 * Do you need extra content params? If so, override me!
		 *
		 * @return array
		 * @since  2.0.0
		 */
		public function get_extra_content_params(): array {
			return array( 'footer_link' => false );
		}

		/**
		 * Get email subject.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_default_subject(): string {
			return $this->subject;
		}
		/**
		 * Get dummy heading.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_dummy_heading(): string {
			$customer   = $this->get_dummy_customer();
			$heading    = $this->get_option( 'heading', $this->get_default_heading());
			$heading    = str_replace('{site_title}', $customer->site_title, $heading);

			return $heading;
		}
		/**
		 * Get dummy subject.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_dummy_subject(): string {
			$customer   = $this->get_dummy_customer();
			$subject    = $this->get_option( 'subject', $this->get_default_subject() );
			$subject    = str_replace('{log_date}', $customer->log_date, $subject);
			$subject    = str_replace('{site_title}', $customer->site_title, $subject);

			return $subject;
		}

		/**
		 * Get email heading.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_default_heading(): string {
			return $this->heading;
		}

		/**
		 * Get email heading.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_heading() {
			if( has_filter('woocommerce_is_email_preview') ){
				return $this->get_dummy_heading();
			}
			$heading = isset( $this->object['heading'] ) && ! empty( $this->object['heading'] ) ? $this->object['heading'] : $this->get_option( 'heading', $this->get_default_heading() );

			return apply_filters( 'woocommerce_email_heading_' . $this->id, $this->format_string( $heading ), $this->object, $this );
		}

		/**
		 * Get email subject
		 *
		 * @return string
		 */
		public function get_subject() {
			if( has_filter('woocommerce_is_email_preview') ){
				return $this->get_dummy_subject();
			}
			$subject = isset( $this->object['subject'] ) && ! empty( $this->object['subject'] ) ? $this->object['subject'] : $this->get_option( 'subject', $this->get_default_subject() );

			return apply_filters( 'woocommerce_email_subject_' . $this->id, $this->format_string( $subject ), $this->object, $this );
		}

		/**
		 * Default content to show below main email content.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_default_custom_message(): string {
			return $this->custom_message;
		}

		/**
		 * Get dummy customer
		 *
		 * @return object the customer object
		 */
		public function get_dummy_customer() {
			$customer                       = new stdClass();
			$customer->site_title           = 'My Online Store';
			$customer->site_address         = '123 Fake Street, Imaginary City';
			$customer->site_url             = 'https://www.myonlinestore.com';
			$customer->store_email          = 'contact@myonlinestore.com';
			$customer->customer_name        = 'John';
			$customer->customer_last_name   = 'Smith';
			$customer->customer_email       = 'john.smith@email.com';
			$customer->before_funds         = 150.00;
			$customer->after_funds          = 120.50;
			$customer->user_funds           = 120.50;
			$customer->log_date             = '2025-06-10 14:32:00';
			$customer->change_reason        = 'Purchase of electronic products';
			$customer->button_charging      = 'Top Up Now';

			return $customer;
		}

		/**
		 * Get dummy email content
		 *
		 * @return bool|object
		 */
		public function get_dummy_email_content() {

			$email_content      = $this->get_option( 'custom_message', $this->get_default_custom_message() );
			$customer           = $this->get_dummy_customer();

			$email_content = str_replace('{site_title}', $customer->site_title, $email_content);
			$email_content = str_replace('{site_address}', $customer->site_address, $email_content);
			$email_content = str_replace('{customer_name}', $customer->customer_name, $email_content);
			$email_content = str_replace('{customer_last_name}', $customer->customer_last_name, $email_content);
			$email_content = str_replace('{customer_email}', $customer->customer_email, $email_content);
			$email_content = str_replace('{before_funds}', number_format($customer->before_funds, 2), $email_content);
			$email_content = str_replace('{store_email}', $customer->store_email, $email_content);
			$email_content = str_replace('{site_url}', $customer->site_url, $email_content);
			$email_content = str_replace('{after_funds}', number_format($customer->after_funds, 2), $email_content);
			$email_content = str_replace('{user_funds}', number_format($customer->user_funds, 2), $email_content);
			$email_content = str_replace('{log_date}', $customer->log_date, $email_content);
			$email_content = str_replace('{change_reason}', $customer->change_reason, $email_content);
			$email_content = str_replace('{button_charging}', $customer->button_charging, $email_content);

			return $email_content;
		}

		/**
		 * Return content from the custom_message field.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_custom_message(): string {
			if( has_filter('woocommerce_is_email_preview') ){
				return $this->get_dummy_email_content();
			}
			$custom_message = isset( $this->object['body'] ) && ! empty( $this->object['body'] ) ? $this->object['body'] : $this->get_option( 'custom_message', $this->get_default_custom_message() );

			return $this->format_string( $custom_message );
		}

		/**
		 * Initialise settings form fields.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function init_form_fields() {
			$this->form_fields = array(
				'enabled'        => array(
					'title'   => esc_html_x( 'Enable/Disable', '[Admin panel] Setting name', 'yith-woocommerce-account-funds' ),
					'type'    => 'checkbox',
					'label'   => esc_html_x( 'Enable this email notification', '[Admin panel] Setting description', 'yith-woocommerce-account-funds' ),
					'default' => 'yes',
				),
				'subject'        => array(
					'title'       => esc_html_x( 'Subject', '[Admin panel] Setting name', 'yith-woocommerce-account-funds' ),
					'type'        => 'text',
					'placeholder' => $this->get_default_subject(),
					'default'     => '',
				),
				'heading'        => array(
					'title'       => esc_html_x( 'Email heading', '[Admin panel] Setting name', 'yith-woocommerce-account-funds' ),
					'type'        => 'text',
					'placeholder' => $this->get_default_heading(),
					'default'     => '',
				),
				'custom_message' => array(
					'title'                   => esc_html_x( 'Message', '[Admin panel] Setting name', 'yith-woocommerce-account-funds' ),
					'type'                    => 'yith_ywf_field',
					'yith_ywf_field_type'     => 'textarea-editor',
					'default'                 => '',
					'teeny'                   => true,
					'media_buttons'           => false,
					'default_content_options' => array(
						'content'          => $this->get_default_custom_message(),
						'edit_text'        => esc_html_x( 'Edit message', '[Admin panel] Edit button text', 'yith-woocommerce-account-funds' ),
						'use_default_text' => esc_html_x( 'Restore default message', '[Admin panel] Restore button text', 'yith-woocommerce-account-funds' ),
					),
					'description'             =>
						'<span class="yith-ywf-emails__email__placeholders">' .
						'<span class="yith-ywf-emails__email__placeholders__label">' . esc_html_x( 'Available placeholders', '[Admin panel] Email placeholder text', 'yith-woocommerce-account-funds' ) . ':</span>' .
						'<code>' . implode( '</code> <code>', array_keys( $this->placeholders ) ) . '</code>' .
						'</span>',
					'desc_tip'                => false,
				),
				'email_type'     => array(
					'title'   => esc_html_x( 'Email type', '[Admin panel] Setting name', 'yith-woocommerce-account-funds' ),
					'type'    => 'select',
					'default' => 'html',
					'class'   => 'email_type wc-enhanced-select',
					'options' => $this->get_email_type_options(),
				),
			);
		}

		/**
		 * Get email custom options.
		 *
		 * @param string     $key The option key.
		 * @param mixed|null $empty_value The empty value (optional).
		 *
		 * @return mixed
		 */
		public function get_custom_option( string $key, $empty_value = null ) {

			$settings = get_option( $this->get_option_key(), null );

			// If there are no settings defined, use defaults.
			if ( ! is_array( $settings ) ) {
				$form_fields = $this->get_email_options( 'content' ) + $this->get_email_options( 'configuration' );

				foreach ( $form_fields as $key_field => $field ) {
					if ( isset( $field['colorpickers'] ) ) {
						foreach ( $field['colorpickers'] as $colorpicker ) {
							$settings[ $key_field ][ $colorpicker['id'] ] = isset( $colorpicker['default'] ) ? $colorpicker['default'] : '';
						}
					} else {
						$settings[ $key_field ] = isset( $field['default'] ) ? $field['default'] : '';
					}
				}
			}

			// Get option default if unset.
			if ( ! isset( $settings[ $key ] ) ) {
				$form_fields      = $this->get_email_options( 'content' ) + $this->get_email_options( 'configuration' );
				$settings[ $key ] = isset( $form_fields[ $key ] ) ? $this->get_field_default( $form_fields[ $key ] ) : '';
			}


			if ( ! is_null( $empty_value ) && '' === $settings[ $key ] ) {
				$settings[ $key ] = $empty_value;
			}

			return maybe_unserialize( $settings[ $key ] );
		}

		/**
		 * Get the email options
		 *
		 * @param string $tab The tab to output.
		 *
		 * @return array
		 * @since  2.0.0
		 */
		public function get_email_options( string $tab ) {


			$content = apply_filters(
				'yith_ywf_email_settings_content_tab',
				array(
					'heading'        => array(
						'title'             => esc_html_x( 'Email heading', '[Admin panel] Setting name', 'yith-woocommerce-account-funds' ),
						'type'              => 'text',
						'custom_attributes' => array(
							'placeholder' => $this->get_default_heading(),
						),
						'default'           => '',
						'class'             => 'mail-heading',
					),
					'custom_message' => array(
						'title'                   => esc_html_x( 'Message', '[Admin panel] Setting name', 'yith-woocommerce-account-funds' ),
						'type'                    => 'textarea-editor',
						'default'                 => '',
						'teeny'                   => true,
						'media_buttons'           => false,
						'default_content_options' => array(
							'content'          => $this->get_default_custom_message(),
							'edit_text'        => esc_html_x( 'Edit message', '[Admin panel] Edit button text', 'yith-woocommerce-account-funds' ),
							'use_default_text' => esc_html_x( 'Restore default message', '[Admin panel] Restore button text', 'yith-woocommerce-account-funds' ),
						),
						'description'             =>
							'<span class="yith-ywf-emails__email__placeholders">' .
							'<span class="yith-ywf-emails__email__placeholders__label">' . esc_html_x( 'Available placeholders', '[Admin panel] Email placeholder text', 'yith-woocommerce-account-funds' ) . ':</span>' .
							'<code>' . implode( '</code> <code>', array_keys( $this->placeholders ) ) . '</code>' .
							'</span>',
						'sanitize_callback'       => array( $this, 'validate_yith_field' ),
					),
				),
				$this
			);

			$configuration = apply_filters(
				'yith_ywf_email_settings_configuration_tab',
				array(
					'subject'    => array(
						'title'             => esc_html_x( 'Subject', '[Admin panel] Setting name', 'yith-woocommerce-account-funds' ),
						'type'              => 'text',
						'custom_attributes' => array(
							'placeholder' => $this->get_default_subject(),
						),
						'default'           => '',
					),
					'email_type' => array(
						'title'   => esc_html_x( 'Email type', '[Admin panel] Setting name', 'yith-woocommerce-account-funds' ),
						'type'    => 'select',
						'default' => 'html',
						'class'   => 'wc-enhanced-select',
						'options' => $this->get_email_type_options(),
					),
				),
				$this
			);


			$tabs = array(
				'content'       => $content,
				'configuration' => $configuration,
			);

			return $tabs[ $tab ];
		}

		/**
		 * Processes and saves options.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function process_admin_options() {

			$post_data = $this->get_post_data();
			$settings  = array();

			if ( isset( $post_data['ywf_panel'] ) && 'yes' === $post_data['ywf_panel'] ) {
				$fields = $this->get_email_options( 'content' ) + $this->get_email_options( 'configuration' );

				foreach ( $fields as $key => $field ) {
					if ( 'title' !== $this->get_field_type( $field ) ) {
						try {
							$settings[ $key ] = $this->get_field_value( $key, $field, $post_data );
						} catch ( Exception $e ) {

							$this->add_error( $e->getMessage() );
						}
					}
				}

				$option_key = $this->get_option_key();
				do_action( 'woocommerce_update_option', array( 'id' => $option_key ) );
				update_option( $option_key, apply_filters( 'woocommerce_settings_api_sanitized_fields_' . $this->id, $settings ), 'yes' );
			} else {
				parent::process_admin_options();
			}
			// Save templates.
			if ( isset( $post_data['template_html_code'] ) ) {
				$this->save_template( $post_data['template_html_code'], $this->template_html );
			}
			if ( isset( $post_data['template_plain_code'] ) ) {
				$this->save_template( $post_data['template_plain_code'], $this->template_plain );
			}
		}

		/**
		 * Serialize array if needed
		 *
		 * @param string $key The option key.
		 * @param mixed  $value The option value.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function validate_yith_ywf_field_field( $key, $value ): string {
			return maybe_serialize( $value );
		}

		/**
		 * Serialize value if needed
		 *
		 * @param mixed $value The option value.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function validate_yith_field( $value ): string {
			return maybe_serialize( $value );
		}

		/**
		 * Email type options.
		 * Allow only HTML and Multipart
		 *
		 * @return array
		 * @since  2.0.0
		 */
		public function get_email_type_options(): array {
			$types = parent::get_email_type_options();

			if ( isset( $types['plain'] ) ) {
				unset( $types['plain'] );
			}

			return $types;
		}

		/**
		 * Return email type.
		 * Allow only HTML and Multipart
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_email_type(): string {
			$type = parent::get_email_type();

			return 'plain' !== $type ? $type : 'html';
		}

		/**
		 * Return the description to be shown in settings list.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function get_description_to_show_in_settings_list(): string {
			return $this->description;
		}

		/**
		 * Generate custom fields by using YITH framework fields.
		 *
		 * @param string $key The key of the field.
		 * @param array  $data The attributes of the field as an associative array.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function generate_yith_ywf_field_html( string $key, array $data ): string {
			$field_key = $this->get_field_key( $key );
			$value     = isset( $data['value'] ) ? $data['value'] : $this->get_custom_option( $key );
			$defaults  = array(
				'title'                   => '',
				'label'                   => '',
				'yith_ywf_field_type'     => 'text',
				'description'             => '',
				'desc_tip'                => false,
				'default_content_options' => array(),
				'deps'                    => '',
			);

			wp_enqueue_script( 'yith-plugin-fw-fields' );
			wp_enqueue_style( 'yith-plugin-fw-fields' );

			$data = wp_parse_args( $data, $defaults );

			$default_content_options                     = $data['default_content_options'];
			$default_content_options['content']          = $default_content_options['content'] ?? '';
			$default_content_options['edit_text']        = $default_content_options['edit_text'] ?? esc_html_x( 'Edit', '[Global] Generic edit button text', 'yith-woocommerce-account-funds' );
			$default_content_options['use_default_text'] = $default_content_options['use_default_text'] ?? esc_html_x( 'Restore default message', '[Admin panel] Restore button text', 'yith-woocommerce-account-funds' );
			$default_content                             = $default_content_options['content'];

			$field          = $data;
			$field['type']  = $data['yith_ywf_field_type'];
			$field['name']  = $field_key;
			$field['value'] = $value;
			$private_keys   = array(
				'label',
				'title',
				'description',
				'yith_ywf_field_type',
				'default_content_options'
			);

			foreach ( $private_keys as $private_key ) {
				unset( $field[ $private_key ] );
			}

			$row_classes = implode(
				' ',
				array_filter(
					array(
						'yith-ywf-email-field__row',
						! ! $value ? '' : 'yith-ywf-email-field__row--empty-value',
					)
				)
			);

			$row_classes .= ! empty( $data['deps'] ) ? ' ' . $data['deps'] : '';

			ob_start();
			?>
			<tr valign="top" class="<?php echo esc_attr( $row_classes ); ?>"
			    data-default-content="<?php echo esc_attr( $default_content ); ?>">
				<th scope="row" class="titledesc">
					<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
				</th>
				<td class="forminp yith-plugin-ui">
					<fieldset>
						<legend class="screen-reader-text"><span><?php echo wp_kses_post( $data['title'] ); ?></span>
						</legend>
						<?php if ( $default_content && 'textarea-editor' === $field['type'] ) : ?>
							<div class="yith-ywf-email-field__default-content">
								<?php
								echo wp_kses_post( nl2br( $default_content ) );
								yith_plugin_fw_get_component(
									array(
										'class'  => 'yith-ywf-email-field__edit',
										'type'   => 'action-button',
										'action' => 'edit',
										'icon'   => 'edit',
										'title'  => $default_content_options['edit_text'],
										'url'    => '#',
									),
									true
								);
								?>
							</div>
							<div class="yith-ywf-email-field__field">
								<?php yith_plugin_fw_get_field( $field, true, true ); ?>
							</div>
						<?php else : ?>
							<?php yith_plugin_fw_get_field( $field, true, true ); ?>
						<?php endif; ?>
						<?php echo wp_kses_post( $this->get_description_html( $data ) ); ?>
						<?php if ( $default_content && 'textarea-editor' === $field['type'] ) : ?>
							<span class="yith-ywf-email-field__use-default">
								<?php echo esc_html( $default_content_options['use_default_text'] ); ?>
							</span>
						<?php endif; ?>
					</fieldset>
				</td>
			</tr>
			<?php

			return ob_get_clean();
		}

		/**
		 * Generate custom fields in WooCommerce email settings.
		 *
		 * @param string $key The key of the field.
		 * @param array  $data The attributes of the field as an associative array.
		 *
		 * @return string
		 * @since  2.0.0
		 */
		public function generate_fields_html( string $key, array $data ): string {
			$field_key = $this->get_field_key( $key );
			$value     = isset( $data['value'] ) ? $data['value'] : $this->get_custom_option( $key );
			$defaults  = array(
				'description'             => '',
				'default_content_options' => array(),
			);

			wp_enqueue_script( 'yith-plugin-fw-fields' );
			wp_enqueue_style( 'yith-plugin-fw-fields' );

			$data = wp_parse_args( $data, $defaults );

			$default_content_options                     = $data['default_content_options'];
			$default_content_options['content']          = $default_content_options['content'] ?? '';
			$default_content_options['edit_text']        = $default_content_options['edit_text'] ?? esc_html_x( 'Edit', '[Global] Generic edit button text', 'yith-woocommerce-account-funds' );
			$default_content_options['use_default_text'] = $default_content_options['use_default_text'] ?? esc_html_x( 'Restore default message', '[Admin panel] Restore button text', 'yith-woocommerce-account-funds' );
			$default_content                             = $default_content_options['content'];

			$field          = $data;
			$field['id']    = $field_key;
			$field['name']  = $field_key;
			$field['value'] = $value;
			$private_keys   = array( 'description', 'default_content_options' );

			foreach ( $private_keys as $private_key ) {
				unset( $field[ $private_key ] );
			}

			ob_start();

			$row_classes = array(
				'yith-plugin-fw__panel__option',
				'yith-plugin-fw__panel__option--' . $field['type'],
				'yith-ywf-email-field__row',
				! ! $value ? '' : 'yith-ywf-email-field__row--empty-value',
				isset( $field['group'] ) ? $field['group'] : '',
			);
			$row_classes = implode( ' ', array_filter( $row_classes ) );

			?>
			<div class="<?php echo esc_attr( $row_classes ); ?>" <?php echo wp_kses_post( yith_field_deps_data( $field ) ); ?>
			     data-default-content="<?php echo esc_attr( $default_content ); ?>">
				<?php if ( isset( $field['title'] ) && '' !== $field['title'] ) : ?>
					<div class="yith-plugin-fw__panel__option__label">
						<label for="<?php echo esc_attr( ( $field_key ) ); ?>"><?php echo wp_kses_post( $field['title'] ); ?></label>
					</div>
				<?php endif; ?>
				<div class="yith-plugin-fw__panel__option__content">
					<?php if ( 'textarea-editor' === $field['type'] ) : ?>
						<fieldset>
							<legend class="screen-reader-text">
								<span><?php echo wp_kses_post( $data['title'] ); ?></span></legend>
							<?php if ( $default_content ) : ?>
								<div class="yith-ywf-email-field__default-content">
									<?php
									echo wp_kses_post( nl2br( $default_content ) );
									yith_plugin_fw_get_component(
										array(
											'class'  => 'yith-ywf-email-field__edit',
											'type'   => 'action-button',
											'action' => 'edit',
											'icon'   => 'edit',
											'title'  => $default_content_options['edit_text'],
											'url'    => '#',
										),
										true
									);
									?>
								</div>
								<div class="yith-ywf-email-field__field">
									<?php yith_plugin_fw_get_field( $field, true, true ); ?>
								</div>
							<?php else : ?>
								<?php yith_plugin_fw_get_field( $field, true, true ); ?>
							<?php endif; ?>
							<?php echo wp_kses_post( $data['description'] ); ?>
							<?php if ( $default_content ) : ?>
								<span class="yith-ywf-email-field__use-default">
								<?php echo esc_html( $default_content_options['use_default_text'] ); ?>
							</span>
							<?php endif; ?>
						</fieldset>
					<?php else : ?>
						<?php yith_plugin_fw_get_field( $field, true, true ); ?>
					<?php endif; ?>
				</div>
				<?php if ( ! empty( $field['desc'] ) ) : ?>
					<div class="yith-plugin-fw__panel__option__description">
						<?php echo wp_kses_post( $field['desc'] ); ?>
					</div>
				<?php endif; ?>
			</div>
			<?php

			return ob_get_clean();
		}

		/**
		 * Switch language to translate the email.
		 *
		 * @param YITH_YWF_Email $email The email.
		 * @param bool           $is_customer_email Customer email flag.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function switch_language_to_translate_email( $email, $is_customer_email ) {
			global $sitepress;

			if ( $is_customer_email && $sitepress ) {
				$language = $email->object['language'] ?? false;
				if ( $language ) {
					$current_language = $sitepress->get_current_language();

					if ( $language !== $current_language ) {
						$email->previous_language = $current_language;
						$sitepress->switch_lang( $language );
						$email->set_default_params();
					}
				}
			}
		}

		/**
		 * Switch language to the previous language.
		 *
		 * @param YITH_YWAR_Email $email The email.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function switch_language_after_translating_email( $email ) {
			global $sitepress;

			if ( $email->previous_language && $sitepress ) {
				$sitepress->switch_lang( $email->previous_language );
				$email->previous_language = '';
			}
		}
	}
}
