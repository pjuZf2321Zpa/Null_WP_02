<?php // phpcs:ignore WordPress.Files.FileName
/**
 * Class that manage the email send to customer when the funds are under a threshold
 *
 * @package YITH\AccountFunds\Classes\Emails
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'YITH_YWF_Customer_Email' ) ) {
	/**
	 * Class YITH_YWF_Customer_Email
	 */
	class YITH_YWF_Customer_Email extends YITH_YWF_Email {


		/**
		 * YITH_YWF_Customer_Email constructor.
		 */
		public function __construct() {
			$this->id             = 'yith_user_funds_email';
			$this->customer_email = true;
			$this->template_base  = YITH_FUNDS_TEMPLATE_PATH;
			$this->template_html  = 'emails/email-user-funds.php';
			$this->template_plain = 'emails/plain/email-user-funds.php';
			$this->placeholders   = array(
				'{user_funds}'      => '',
				'{button_charging}' => '',
			);

			// Triggers for this email.
			add_action( 'ywf_send_user_fund_email_notification', array( $this, 'trigger' ), 10, 2 );
			add_filter( 'yith_ywf_email_settings_configuration_tab', array( $this, 'add_extra_field' ), 20, 2 );
			add_filter( 'woocommerce_email_styles', array( $this, 'add_custom_styles' ), 9999, 2 );
			parent::__construct();
		}

		/**
		 * Set default params.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function set_default_params() {
			parent::set_default_params();

			$this->title          = esc_html_x( 'Top-up', '[Admin panel] Email title', 'yith-woocommerce-account-funds' );
			$this->description    = esc_html_x( 'This email is sent to the customers when their funds fall below a certain threshold.', '[Admin panel] Email description', 'yith-woocommerce-account-funds' );
			$this->heading        = esc_html_x( 'Your funds in our shop are draining down!', '[Admin panel] Email heading/subject', 'yith-woocommerce-account-funds' );
			$this->subject        = esc_html_x( '{site_title} You are running out of funds!', '[Admin panel] Email heading/subject', 'yith-woocommerce-account-funds' );
			$this->custom_message = esc_html_x(
				"Hi {customer_name} {customer_last_name}, \n\nIt seems you're going to run out of funds on {site_title} :(\n\n{user_funds}\n\nTop up your account to be able to quickly place new orders and forget about card numbers and codes.\n\n{button_charging}\n\n\n\nRegards\n\n{site_title}",
				'[Admin panel] Email content',
				'yith-woocommerce-account-funds'
			);
		}


		/**
		 * Initialize placeholders before sending.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function init_placeholders_before_sending() {
			parent::init_placeholders_before_sending();

			if ( $this->object ) {
				$endpoint = yith_account_funds_get_endpoint_slug( 'funds' );
				$url      = esc_url( wc_get_page_permalink( 'myaccount' ) . $endpoint );
				$link     = sprintf( '<a class="ywf-email-add-deposit" href="%1$s" target="_blank" >%2$s</a>', $url, __( 'Deposit funds now', 'yith-woocommerce-account-funds' ) );

				$this->placeholders['{user_funds}']      = $this->get_user_funds_content();
				$this->placeholders['{button_charging}'] = $link;
			}
		}

		/**
		 * Return the funds template
		 *
		 * @return string
		 */
		protected function get_user_funds_content() {
			$product_id = get_option( '_ywf_deposit_id' );
			$product    = wc_get_product( $product_id );
			$image      = $product->get_image( 'full' );

			$content = "<div class='ywf-email-user-funds'>";
			$content .= "<div class='ywf-email-user-funds-image'>";
			$content .= $image;
			$content .= "</div>";
			$content .= "<div class='ywf-email-user-funds-content'>";
			$content .= '<p>' . esc_html__( 'Your available funds:', 'yith-woocommerce-account-funds' ) . '</p>';
			$content .= "<div class='ywf-email-user-funds-formatted'>";
			$content .= $this->object['user_funds']['funds_formatted'];
			$content .= '</div>';
			$content .= "</div>";
			$content .= "</div>";

			return $content;
		}

		/**
		 * Trigger.
		 *
		 * @param array $args_obj The email arguments.
		 * @param bool  $output Check if the function should return a value.
		 *
		 * @return void|bool
		 * @since  2.0.0
		 */
		public function trigger( $args_obj, $output = false ) {
			$this->setup_locale();
			$user_id       = $args_obj['user']['user_id'] ?? '';
			$email_is_sent = get_user_meta( $user_id, '_user_mail_send', true );
			$limit         = $this->get_option( 'mail_amount_limit' );
			$current_funds = $args_obj['user_funds']['funds'];
			if ( $current_funds < $limit && ( empty( $email_is_sent ) || 'no' === $email_is_sent ) && apply_filters( 'ywf_send_email', true, $user_id ) ) {

				$send       = parent::trigger( $args_obj, true );
				$meta_value = $send ? 'yes' : 'no';

				update_user_meta( $user_id, '_user_mail_send', $meta_value );

				if ( $output ) {
					return $send;
				}
			}
			$this->restore_locale();
		}

		/**
		 * Get the email options
		 *
		 * @param array          $options The options.
		 * @param YITH_YWF_Email $email The email.
		 *
		 * @return array
		 * @since  2.0.0
		 */
		public function add_extra_field( $options, $email ) {

			if ( $email->id === $this->id ) {

				$new_opt = array(
					'mail_amount_limit' => array(
						'title'   => sprintf( '%s (%s)', __( 'User funds threshold', 'yith-woocommerce-account-funds' ), get_woocommerce_currency_symbol() ),
						'type'    => 'number',
						'min'     => 0,
						'step'    => 0.5,
						'default' => 0,
						'desc'    => __( 'Set a minimum threshold when an email is sent to customers to invite them to deposit more funds', 'yith-woocommerce-account-funds' )

					)
				);
				$options = array_merge( $new_opt, $options );
			}

			return $options;
		}


		/**
		 * @param string         $css The css.
		 * @param YITH_YWF_Email $email The email.
		 *
		 * @return string
		 */
		public function add_custom_styles( $css, $email ) {
			if ( $this->id === $email->id ) {
				$base = get_option( 'woocommerce_email_base_color' ) ;
				$base_text = wc_light_or_dark( $base, '#202020', '#ffffff' );
				$css .= 'a.ywf-email-add-deposit{
				background:' . $base. ';
				display: block;
				text-decoration: none;
				text-align:center;
				padding:10px;
				color:' . $base_text . ';
				}
				.ywf-email-user-funds{
					display:flex;
					background: #f6f6f6;
				    align-items: center;
				    padding: 20px;
				    margin-top: 20px;
                    margin-bottom: 20px;
				    gap:20px;
				}
				.ywf-email-user-funds-image{
					max-width:40px;
				}
				.ywf-email-user-funds-content{
					display: flex;
	                flex-direction: column;
	                gap:5px;
				}
				.ywf-email-user-funds-content p{
					margin:0!important;
				}
				.ywf-email-user-funds-formatted{
					color: red;
	                font-size: 20px;
				}
				';
			}

			return $css;
		}
	}
}

return new YITH_YWF_Customer_Email();
