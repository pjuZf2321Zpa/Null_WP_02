<?php // phpcs:ignore WordPress.Files.FileName
/**
 * Class that manage the email send to customer when the admin change the customer funds in backend
 *
 * @package YITH\AccountFunds\Classes\Emails
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'YITH_YWF_Advise_Customer_Email' ) ) {
	/**
	 * Class YITH_YWF_Advise_Customer_Email
	 */
	class YITH_YWF_Advise_Customer_Email extends YITH_YWF_Email {
		/**
		 * YITH_YWF_Advise_Customer_Email constructor.
		 */
		public function __construct() {
			$this->id             = 'yith_advise_user_funds_email';
			$this->customer_email = true;
			$this->template_base  = YITH_FUNDS_TEMPLATE_PATH;
			$this->template_html  = 'emails/email-advise-user-funds.php';
			$this->template_plain = 'emails/plain/email-advise-user-funds.php';

			$this->placeholders = array(
				'{before_funds}'  => '',
				'{after_funds}'   => '',
				'{log_date}'      => '',
				'{change_reason}' => '',
			);

			add_action( 'ywf_send_advise_user_fund_email_notification', array( $this, 'trigger' ), 10, 2 );
			parent::__construct();
		}


		/**
		 * Set default params.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function set_default_params() {
			parent::set_default_params();

			$this->title          = esc_html_x( 'Customer funds note', '[Admin panel] Email title', 'yith-woocommerce-account-funds' );
			$this->description    = esc_html_x( 'This email is sent to the customers when the administrator changes the amount of their available funds.', '[Admin panel] Email description', 'yith-woocommerce-account-funds' );
			$this->heading        = esc_html_x( 'Funds edited by the admin!', '[Admin panel] Email heading/subject', 'yith-woocommerce-account-funds' );
			$this->subject        = esc_html_x( 'The Administrator has changed your funds on {log_date}', '[Admin panel] Email heading/subject', 'yith-woocommerce-account-funds' );
			$this->custom_message = esc_html_x(
				"Dear {customer_name},\n\nThe administrator has changed your funds from {before_funds} to {after_funds} for the following reason:\n\n{change_reason}\n\nBest regards {site_title}\n",
				'[Admin panel] Email content',
				'yith-woocommerce-account-funds'
			);
		}


		/**
		 * Initialize placeholders before sending.
		 *
		 * @return void
		 * @since  2.0.0
		 */
		public function init_placeholders_before_sending() {
			parent::init_placeholders_before_sending();
			if ( $this->object ) {

				$this->placeholders['{log_date}']      = $this->object['user_funds']['log_date'];
				$this->placeholders['{change_reason}'] = $this->object['user_funds']['change_reason'];
				$this->placeholders['{before_funds}']  = $this->object['user_funds']['before_funds_formatted'];
				$this->placeholders['{after_funds}']   = $this->object['user_funds']['after_funds_formatted'];

			}
		}

		/**
		 * Trigger.
		 *
		 * @param array $args_obj The email arguments.
		 * @param bool  $output Check if the function should return a value.
		 *
		 * @return void|bool
		 * @since  2.0.0
		 */
		public function trigger( $args_obj, $output = false ) {

			if ( empty( $args_obj ) ) {
				return;
			}

			$this->setup_locale();
			if ( apply_filters( 'ywf_send_email', true, $args_obj['user']['user_id'] ) ) {

				parent::trigger( $args_obj, $output );
			}


			$this->restore_locale();
		}
	}
}

return new YITH_YWF_Advise_Customer_Email();
