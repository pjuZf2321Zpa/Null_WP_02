<?php // phpcs:ignore WordPress.Files.FileName
/**
 * Class manage plugin shortcodes
 *
 * @package YITH\AccountFunds\Classes\Shortcodes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'YITH_YWF_Shortcodes' ) ) {
	/**
	 * Class YITH_YWF_Shortcodes
	 */
	class YITH_YWF_Shortcodes {
		/**
		 * Show the  funds history
		 *
		 * @param array $atts The shortcode attrs.
		 * @param null  $content The content.
		 *
		 * @return string
		 * @since 1.0.0
		 * @author YITH <plugins@yithemes.com>
		 */
		public static function show_user_deposit_log( $atts, $content = null ) {

			$atts = shortcode_atts(
				array(
					'per_page'    => apply_filters( 'ywf_show_log_per_page', 10 ),
					'pagination'  => 'no',
					'show_all'    => 'no',
					'show_filter' => 'yes',
				),
				$atts
			);

			extract( $atts ); //phpcs:ignore WordPress.PHP.DontExtract

			$query_args = array();
			if ( isset( $_GET['funds_history_filter'] ) ) {
				$query_args['type_operation'] = sanitize_text_field( wp_unslash( $_GET['funds_history_filter'] ) );

			}


			$count = YWF_Log()->count_log( $query_args );

			if ( isset( $_GET['show_all_history'] ) ) {
				$per_page    = - 1;
				$show_all    = 'no';
				$show_filter = 'yes';
			}
			$page_links = false;
			if ( $per_page > 0 && $count > $per_page ) {

				global $post;

				if ( is_account_page() ) {
					$endpoint     = yith_account_funds_get_endpoint_slug( 'funds' );
					$current_page = max( 1, get_query_var( $endpoint ) );
					$base_url     = wc_get_endpoint_url( $endpoint, '%#%' );

					$format = '%#%';

				} else {
					$current_page = max( 1, get_query_var( 'paged' ) );
					$base_url     = esc_url( add_query_arg( array( 'paged' => '%#%' ), get_the_permalink( $post->ID ) ) );
					$format       = '?paged=%#%';
				}

				$pages = ceil( $count / $per_page );

				if ( $current_page > $pages ) {
					$current_page = $pages;
				}

				$offset = ( $current_page - 1 ) * $per_page;

				if ( $pages > 1 && 'yes' === $pagination ) {
					$page_links = paginate_links(
						array(
							'base'     => $base_url,
							'format'   => $format,
							'current'  => $current_page,
							'total'    => $pages,
							'show_all' => true,
						)
					);
				}

				$query_args['limit']  = $per_page;
				$query_args['offset'] = $offset;

			}

			$query_args['user_id'] = get_current_user_id();

			$additional_params = array(
				'history'        => YWF_Log()->get_log( $query_args ),
				'filters'        => ywf_get_operation_type(),
				'current_filter' => $query_args['type_operation'] ?? '',
				'show_all'       => $show_all,
				'show_filter'    => $show_filter,
				'page_link'      => $page_links ?? false,
			);

			$atts = array_merge( $atts, $additional_params );

			$atts['atts'] = $atts;
			if ( ! wp_style_is( 'ywf-shortcodes' ) ) {
				wp_enqueue_style( 'ywf-shortcodes' );
			}
			ob_start();
			wc_get_template( 'shortcodes/history.php', $atts, '', YITH_FUNDS_TEMPLATE_PATH );
			$template = ob_get_contents();
			ob_end_clean();

			return $template;
		}

		/**
		 * Show the users fund
		 *
		 * @param array $atts The shortcode attrs.
		 * @param null  $content The content.
		 *
		 * @return string
		 * @since 1.0.0
		 */
		public static function show_user_fund( $atts, $content = null ) {

			$atts = shortcode_atts(
				array(
					'layout' => 'badge',
				),
				$atts
			);

			$user_id = is_user_logged_in() ? get_current_user_id() : 0;
			$user    = get_user_by( 'id', $user_id );
			if ( $user ) {
				if ( ! wp_style_is( 'ywf-shortcodes' ) ) {
					wp_enqueue_style( 'ywf-shortcodes' );
				}
				$customer   = new YITH_YWF_Customer( $user_id );
				$funds      = apply_filters( 'yith_show_available_funds', $customer->get_funds() );
				$product_id = get_option( '_ywf_deposit_id' );
				$product    = wc_get_product( $product_id );
				$image      = $product->get_image( 'full' );

				ob_start();
				wc_get_template( 'shortcodes/user-balance.php', array(
					'funds'  => $funds,
					'image'  => $image,
					'layout' => $atts['layout'],
				), '', YITH_FUNDS_TEMPLATE_PATH );
				$template = ob_get_contents();
				ob_end_clean();

				return $template;
			}

			return '';
		}

		/**
		 * Show the deposit form
		 *
		 * @param array $atts The shortcode attrs.
		 * @param null  $content The content.
		 *
		 * @return string
		 * @since 1.0.0
		 */
		public static function make_a_deposit_form( $atts, $content = null ) {

			if ( ! apply_filters( 'yith_funds_user_is_available', true ) ) {
				return '';
			}

			if ( ! wp_style_is( 'ywf-shortcodes' ) ) {
				wp_enqueue_style( 'ywf-shortcodes' );
			}

			if ( ! wp_script_is( 'ywf_script' ) ) {
				wp_enqueue_script( 'ywf_script' );
			}
			$args = array(
				'min'  => get_option( 'yith_funds_min_value', 1 ),
				'max'  => get_option( 'yith_funds_max_value', '' ),
				'step' => get_option( 'yith_funds_step', 1 ),
			);
			ob_start();
			wc_get_template( 'shortcodes/add-funds.php', $args, '', YITH_FUNDS_TEMPLATE_PATH );
			$template = ob_get_contents();
			ob_end_clean();

			return $template;
		}


		/**
		 * Show the short make a deposit form
		 *
		 * @param array $atts The shortcode attrs.
		 * @param null  $content The content.
		 */
		public static function make_a_deposit_small( $atts, $content = null ) {
			global $post;
			$atts = shortcode_atts(
				array(
					'text'   => __( 'Deposit', 'yith-woocommerce-account-funds' ),
					'type'   => 'button',
					'amount' => 0,
				),
				$atts
			);

			extract( $atts ); //phpcs:ignore WordPress.PHP.DontExtract
			$url = get_permalink( $post->ID );

			$url = add_query_arg(
				array(
					'ywf-add-deposit' => wc_format_decimal( $amount )
				),
				$url
			);
			switch ( $type ) {

				case 'button':
				case 'link':
					$class   = 'button' === $type ? 'button' : '';
					$content = sprintf( '<a href="%s" class="%s">%s</a>', esc_url( $url ), $class, $text );
					break;
				default:
					$endpoint = apply_filters( 'ywf_make_deposit_slug', yith_account_funds_get_endpoint_slug( 'make-a-deposit' ) );
					$content  = sprintf( '<span>%s</span>', esc_url( add_query_arg( array( 'amount' => $amount ), wc_get_page_permalink( 'myaccount' ) . $endpoint ) ) );
					break;
			}

			return $content;

		}

		/**
		 * Show the discount message
		 *
		 * @param array $atts The shortcode attrs.
		 * @param null  $content The content.
		 *
		 * @return false|string
		 * @since 1.0.0
		 */
		public static function show_discount_message( $atts, $content = null ) {

			ob_start();
			YITH_YWF_Cart_Process()->show_discount_message();

			return ob_get_clean();
		}

		/**
		 * Show redeem vendor endpoint
		 *
		 * @return string
		 * @since 1.0.0
		 */
		public static function redeem_vendor_funds() {

			return self::show_user_fund( array() );

		}

	}
}

add_shortcode( 'yith_ywf_show_history', array( 'YITH_YWF_Shortcodes', 'show_user_deposit_log' ) );
add_shortcode( 'yith_ywf_show_user_fund', array( 'YITH_YWF_Shortcodes', 'show_user_fund' ) );
add_shortcode( 'yith_ywf_make_a_deposit_form', array( 'YITH_YWF_Shortcodes', 'make_a_deposit_form' ) );
add_shortcode( 'yith_ywf_make_a_deposit_small', array( 'YITH_YWF_Shortcodes', 'make_a_deposit_small' ) );
add_shortcode( 'yith_ywf_show_discount_message', array( 'YITH_YWF_Shortcodes', 'show_discount_message' ) );
add_shortcode( 'yith_ywf_redeem_vendor_funds', array( 'YITH_YWF_Shortcodes', 'redeem_vendor_funds' ) );

