<?php // phpcs:ignore WordPress.Files.FileName
/**
 * Class that manage the compatibility with YITH Multi Vendor Plugin
 *
 * @package YITH\AccountFunds\Classes\Compatibility
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'YITH_FUNDS_MultiVendor' ) ) {
	/**
	 * Class YITH_FUNDS_MultiVendor
	 */
	class YITH_FUNDS_MultiVendor {
		/**
		 * YITH_FUNDS_MultiVendor constructor.
		 */
		public function __construct() {

			add_action( 'yith_wcmv_suborder_created', array( $this, 'add_funds_in_sub_orders' ), 20, 3 );
			add_filter( 'yith_account_funds_show_order_metabox', array( $this, 'show_fund_editor_metabox' ), 10, 3 );
			add_filter( 'ywf_operation_type', array( $this, 'add_commission_type' ), 10, 1 );

		}

		/**
		 * Add funds information in suborders
		 *
		 * @param int $suborder_id The suborder id.
		 * @param int $parent_order_id The parent order id.
		 * @param int $vendor_id The vendor id.
		 *
		 * @throws Exception The exception.
		 * @author YITH <plugins@yithemes.com>
		 */
		public function add_funds_in_sub_orders( $suborder_id, $parent_order_id, $vendor_id ) {

			$parent_order   = wc_get_order( $parent_order_id );
			$order_total    = $parent_order->get_total( 'edit' );
			$suborder       = wc_get_order( $suborder_id );
			$suborder_total = $suborder->get_total();

			$partial_payment    = $parent_order->get_meta( 'ywf_partial_payment' );
			$funds_used         = $parent_order->get_meta( '_order_funds' );
			$order_fund_removed = $parent_order->get_meta( '_order_fund_removed' );

			if ( ! empty( $funds_used ) ) {

				if ( 'yes' === $partial_payment ) {
					$suborder->update_meta_data( 'ywf_partial_payment', 'yes' );
				}

				$suborder_funds = round( ( $funds_used * $suborder_total ) / ( $order_total + $funds_used ), 2 );

				$suborder->update_meta_data( '_order_funds', $suborder_funds );

				$suborder->set_total( $suborder_total - $suborder_funds );
				$suborder->update_meta_data( '_order_fund_removed', $order_fund_removed );

				$suborder->save();
			}
		}

		/**
		 * Show the fund information in suborder
		 *
		 * @param bool     $show Can show the fund info.
		 * @param string   $is_partial Is partial payment.
		 * @param WC_Order $order The order object.
		 *
		 */
		public function show_fund_editor_metabox( $show, $is_partial, $order ) {

			$vendor_can_refund = get_option( 'yith_wpv_vendors_option_order_refund_synchronization' );
			$vendor_can_refund = 'yes' === $vendor_can_refund;
			$order_id          = $order->get_id();

			$vendor = function_exists( 'yith_wcmv_get_vendor' ) ? yith_wcmv_get_vendor( 'current', 'user' ) : yith_get_vendor( 'current', 'user' );

			if ( $vendor->is_valid() && $vendor->has_limited_access() ) {
				if ( 0 !== intval( wp_get_post_parent_id( $order_id ) ) ) {
					if ( 'yes' === $is_partial && ! $vendor_can_refund ) {
						$show = false;
					}
				}
			}

			return $show;
		}

		/**
		 * Add in the commission , custom operations
		 *
		 * @param array $operations The old commission operations.
		 *
		 * @return array
		 */
		public function add_commission_type( $operations ) {
			$vendor = function_exists( 'yith_wcmv_get_vendor' ) ? yith_wcmv_get_vendor( 'current', 'user' ) : yith_get_vendor( 'current', 'user' );

			if ( $vendor->is_valid() && $vendor->has_limited_access() ) {
				$operations['commission']        = __( 'Commission', 'yith-woocommerce-account-funds' );
				$operations['commission_refund'] = __( 'Commission Refunded', 'yith-woocommerce-account-funds' );

			}

			return $operations;
		}
	}
}

new YITH_FUNDS_MultiVendor();
