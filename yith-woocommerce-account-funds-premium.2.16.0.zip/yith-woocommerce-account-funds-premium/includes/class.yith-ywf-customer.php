<?php // phpcs:ignore WordPress.Files.FileName
/**
 * This is the class that manage customer actions
 *
 * @author  YITH <plugins@yithemes.com>
 * @package YITH\AccountFunds\Classes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'YITH_YWF_Customer' ) ) {
	/**
	 * Class YITH_YWF_Customer
	 */
	class YITH_YWF_Customer {

		/**
		 * The customer id
		 *
		 * @var int
		 */
		protected $customer_id;
		/**
		 * The meta key
		 *
		 * @var string
		 */
		protected $meta_key;

		/**
		 * YITH_YWF_Customer constructor.
		 *
		 * @param int $customer_id The user id.
		 */
		public function __construct( $customer_id ) {
			$this->customer_id = $customer_id;
			$this->meta_key    = '_customer_fund';
		}

		/**
		 * Static function for get customer fund
		 *
		 * @return float
		 * @since  1.0.0
		 */
		public function get_funds() {
			$funds = get_user_meta( $this->customer_id, $this->meta_key, true );

			return empty( $funds ) ? 0 : floatval( $funds );
		}

		/**
		 * Set a new funds for customer
		 *
		 * @param float            $funds the funds.
		 * @param WC_Order|boolean $order The order.
		 *
		 * @return boolean True on success, false otherwise.
		 * @since  1.0.0
		 */
		public function set_funds( $funds, $order = false ) {

			global $sitepress;

			if ( ! update_user_meta( $this->customer_id, $this->meta_key, $funds ) ) {
				return false;
			}

			$user = get_user_by( 'id', $this->customer_id );
			$lang = false;
			if ( $order instanceof WC_Order ) {
				$currency = $order->get_currency();
				$lang     = $sitepress ? $order->get_meta( 'wpml_language' ) : false;
			} else {
				$order_id = ywf_get_user_currency( $this->customer_id );
				$currency = get_post_meta( $order_id, '_order_currency', true );
			}

			$email_funds = apply_filters( 'yith_fund_into_customer_email', $funds, $currency );

			$email_data = array(
				'user'       => array(
					'customer_name'      => $user->get( 'billing_first_name' ),
					'customer_last_name' => $user->get( 'billing_last_name' ),
					'customer_email'     => $user->get( 'billing_email' ),
					'user_id'            => $this->customer_id,
				),
				'user_funds' => array(
					'funds_formatted' => wc_price( $email_funds, array( 'currency' => $currency ) ),
					'funds'           => $funds
				),
				'language'   => $lang
			);
			WC()->mailer();
			do_action( 'ywf_send_user_fund_email_notification', $email_data );

			return true;
		}

		/**
		 * Add the transaction in the log
		 *
		 * @param float $new_funds The funds.
		 * @param array $args_log The log args.
		 *
		 * @since  1.0.0
		 */
		public function add_funds_with_log( $new_funds, $args_log = array() ) {

			$this->add_funds( $new_funds );

			$fund_log_args = array(
				'user_id'        => $this->customer_id,
				'fund_user'      => $new_funds,
				'type_operation' => '',
				'description'    => '',
				'order_id'       => '',
			);

			$fund_log_args = wp_parse_args( $args_log, $fund_log_args );
			do_action( 'ywf_add_user_log', $fund_log_args );
		}

		/**
		 * Increase the customer funds
		 *
		 * @param float $new_funds The new funds.
		 *
		 * @return boolean True on success, false otherwise or if the value is the same of the old one.
		 * @since  1.0.0
		 */
		public function add_funds( $new_funds ) {
			$old_funds = $this->get_funds();
			$old_funds += floatval( $new_funds );

			return $this->set_funds( $old_funds );
		}

		/**
		 * Decrement the customer funds
		 *
		 * @param float            $new_funds The new funds.
		 * @param WC_Order|boolean $the_order The order.
		 *
		 * @return boolean True on success, false otherwise or if the value is the same of the old one.
		 * @since  1.0.0
		 */
		public function decrement_funds( $new_funds, $the_order = false ) {
			$old_funds = $this->get_funds();
			$old_funds -= floatval( $new_funds );

			return $this->set_funds( $old_funds, $the_order );
		}

	}
}
