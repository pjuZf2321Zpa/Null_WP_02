<?php // phpcs:ignore WordPress.Files.FileName
/**
 * This class manage the privacy policy
 *
 * @package YITH\AccountFunds\Classes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'YITH_Funds_Privacy_Policy' ) && class_exists( 'YITH_Privacy_Plugin_Abstract' ) ) {
	/**
	 * Class YITH_Funds_Privacy_Policy
	 */
	class YITH_Funds_Privacy_Policy extends YITH_Privacy_Plugin_Abstract {
		/**
		 * YITH_Funds_Privacy_Policy constructor.
		 */
		public function __construct() {
			parent::__construct( YITH_FUNDS_PLUGIN_NAME );
		}


		/**
		 * Get the privacy message
		 *
		 * @param string $section the section.
		 * @return string
		 */
		public function get_privacy_message( $section ) {

			$privacy_content_path = YITH_FUNDS_TEMPLATE_PATH . 'privacy/html-policy-content-' . $section . '.php';

			if ( file_exists( $privacy_content_path ) ) {

				ob_start();
				include $privacy_content_path;

				return ob_get_clean();
			}

			return '';
		}
	}

	new YITH_Funds_Privacy_Policy();
}
