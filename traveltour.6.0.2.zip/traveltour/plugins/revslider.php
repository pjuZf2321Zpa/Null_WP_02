<?php
	
	add_filter('revslider_getUsedFonts', 'traveltour_revslider_getUsedFonts');
	if( !function_exists('traveltour_revslider_getUsedFonts') ){
		function traveltour_revslider_getUsedFonts( $used_font ){

			global $gdlr_core_font_loader;
			if( empty($gdlr_core_font_loader) ){
				$gdlr_core_font_loader = new gdlr_core_font_loader();
			}

			$theme_fonts = $gdlr_core_font_loader->get_google_font('used-font');
			if( !empty($theme_fonts) ){
				foreach( $theme_fonts as $font_family => $val ){
					unset($used_font[$font_family]);
				}
			}
			return $used_font;
		}
	}
	
	// the slider plugin draws a slider made with its older editor (the demo content files) only when the
	// slider has an entry in its option 'sliderrevolution-v7-slide-map'. the entry is added for an admin only,
	// when the slider is opened in its editor, so a slider that was just imported showed an empty hero and
	// a "Cannot convert undefined or null to object" script error on the front end. add it after the import.
	add_action('revslider_slider_imported', 'traveltour_revslider_slider_imported');
	if( !function_exists('traveltour_revslider_slider_imported') ){
		function traveltour_revslider_slider_imported( $slider_id ){
			if( empty($slider_id) || !class_exists('RevSliderFunctions') ) return;

			$functions = new RevSliderFunctions();
			if( method_exists($functions, 'get_v7_slider_map') ){
				$functions->get_v7_slider_map($slider_id);
			}
		}
	}
