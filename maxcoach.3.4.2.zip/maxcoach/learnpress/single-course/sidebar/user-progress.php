<?php
/**
 * Template for displaying progress of single course.
 *
 * @author   ThimPress
 * @package  Learnpress/Templates
 * @version  4.0.3
 */

use LearnPress\Models\QuizPostModel;
use LearnPress\Models\UserItems\UserCourseModel;

defined( 'ABSPATH' ) || exit();

if ( ! isset( $user ) || ! isset( $course ) || ! isset( $course_data ) || ! isset( $course_results ) ) {
	return;
}

$passing_condition = $course->get_passing_condition();
$evaluation_label  = '';
$course_result     = round( (float) $course_results['result'], 2 );
$progress_percent  = $course_result;

if ( class_exists( UserCourseModel::class ) && $user->get_id() > 0 ) {
	try {
		$user_course_model = UserCourseModel::find( $user->get_id(), $course->get_id(), true );

		if ( $user_course_model ) {
			$course_model     = $user_course_model->get_course_model();
			$calculate        = $user_course_model->calculate_course_results();
			$total_items      = $course_model->count_items();
			$evaluation_type  = $course_model::get_evaluation_types( $course_model->get_evaluation_type() );
			$evaluation_label = isset( $evaluation_type['label'] ) ? $evaluation_type['label'] : '';

			if ( 'evaluate_final_quiz' === $course_model->get_evaluation_type() ) {
				$final_quiz = $course_model->get_final_quiz();

				if ( $final_quiz ) {
					$quiz_model = QuizPostModel::find( $final_quiz, true );

					if ( $quiz_model ) {
						$passing_condition = $quiz_model->get_passing_grade();
					}
				}
			}

			$progress_percent = round( $total_items > 0 ? $calculate['completed_items'] * 100 / $total_items : 0, 2 );
			$progress_percent = min( $progress_percent, 100 );
		}
	} catch ( Throwable $e ) {
		$progress_percent = $course_result;
	}
}
?>

<div class="course-results-progress">
	<?php
	if ( ! empty( $course_results['items'] ) && $course_results['items']['lesson']['total'] ) :
		?>
		<div class="items-progress">
			<h4 class="items-progress__heading">
				<?php esc_html_e( 'Lessons completed:', 'maxcoach' ); ?>
			</h4>
			<span
				class="number"><?php echo esc_html( sprintf( '%1$d/%2$d', $course_results['items']['lesson']['completed'], $course_results['items']['lesson']['total'] ) ); ?></span>

			<div class="learn-press-progress lp-course-progress">
				<div class="progress-bg lp-progress-bar">
					<?php
					$lessons_complete_percent = Maxcoach_Helper::calculate_percentage( $course_results['items']['lesson']['completed'], $course_results['items']['lesson']['total'] );
					?>
					<div class="progress-active lp-progress-value" style="left: <?php echo esc_attr( $lessons_complete_percent ); ?>%;">
					</div>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<?php
	if ( ! empty( $course_results['items'] ) && $course_results['items']['quiz']['total'] ) :
		$quiz_false = $course_results['items']['quiz']['completed'] - $course_results['items']['quiz']['passed'];
		?>
		<div class="items-progress">
			<h4 class="items-progress__heading">
				<?php esc_html_e( 'Quizzes finished:', 'maxcoach' ); ?>
			</h4>
			<span class="number"
				<?php /* translators: 1: number of failed quizzes, 2: number of passed quizzes. */ ?>
				title="<?php echo esc_attr( sprintf( __( 'Failed %1$d, Passed %2$d', 'maxcoach' ), $quiz_false, $course_results['items']['quiz']['passed'] ) ); ?>"><?php echo esc_html( sprintf( '%1$d/%2$d', $course_results['items']['quiz']['completed'], $course_results['items']['quiz']['total'] ) ); ?></span>

			<div class="learn-press-progress lp-course-progress">
				<div class="progress-bg lp-progress-bar">
					<?php
					$quizzes_complete_percent = Maxcoach_Helper::calculate_percentage( $course_results['items']['quiz']['completed'], $course_results['items']['quiz']['total'] );
					?>
					<div class="progress-active lp-progress-value" style="left: <?php echo esc_attr( $quizzes_complete_percent ); ?>%;">
					</div>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<?php do_action( 'learn-press/user-item-progress', $course_results, $course_data, $user, $course ); ?>

	<div class="course-progress">
		<h4 class="items-progress__heading">
			<?php esc_html_e( 'Course progress:', 'maxcoach' ); ?>
		</h4>
		<div class="lp-course-status">
			<span class="number"><?php echo esc_html( $progress_percent ); ?><span class="percentage-sign">%</span></span>
		</div>

		<div class="learn-press-progress lp-course-progress">
			<div class="progress-bg lp-progress-bar">
				<div class="progress-active lp-progress-value" style="left: <?php echo esc_attr( $progress_percent ); ?>%;">
				</div>
			</div>
		</div>
	</div>

	<div class="course-progress course-passing-grade">
		<h4 class="items-progress__heading">
			<?php esc_html_e( 'Passing grade:', 'maxcoach' ); ?>
			<?php if ( '' !== $evaluation_label ) : ?>
				<?php /* translators: %s: minimum result percent required to pass the course. */ ?>
				<span class="lp-icon-question-circle" title="<?php echo esc_attr( sprintf( '%1$s. %2$s', $evaluation_label, sprintf( __( 'Passing condition: %s%%', 'maxcoach' ), $passing_condition ) ) ); ?>"></span>
			<?php endif; ?>
		</h4>
		<div class="lp-course-status">
			<span class="number"><?php echo esc_html( $course_result ); ?><span class="percentage-sign">%</span></span>
		</div>

		<div class="learn-press-progress lp-course-progress<?php echo $course_data->is_passed() ? ' passed' : ''; ?>"
			data-value="<?php echo esc_attr( $course_result ); ?>"
			data-passing-condition="<?php echo esc_attr( $passing_condition ); ?>"
			title="<?php echo esc_attr( learn_press_translate_course_result_required( $course ) ); ?>">
			<div class="progress-bg lp-progress-bar">
				<div class="progress-active lp-progress-value" style="left: <?php echo esc_attr( $course_result ); ?>%;">
				</div>
			</div>
			<div class="lp-passing-conditional"
				<?php /* translators: %s: minimum result percent required to pass the course. */ ?>
				data-content="<?php echo esc_attr( sprintf( __( 'Passing condition: %s%%', 'maxcoach' ), $passing_condition ) ); ?>"
				style="left: <?php echo esc_attr( $passing_condition ); ?>%;">
			</div>
		</div>
	</div>

</div>
