<?php
/**
 * Content Poup.
 * Use for React Quiz.
 *
 * @author   ThimPress
 * @package  Learnpress/Templates
 * @version  4.0.0
 */

?>

<div id="popup-content">
	<?php
	/**
	 * Show/Hide curriculum button.
	 * LearnPress >= 4.4.9 fires this hook here (moved from popup-header.php),
	 * older versions still fire it in popup-header.php, so skip if already fired.
	 *
	 * @since 4.0.6
	 * @see   single-button-toggle-sidebar - 5
	 */
	if ( ! did_action( 'learn-press/single-button-toggle-sidebar' ) ) {
		do_action( 'learn-press/single-button-toggle-sidebar' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound, WordPress.NamingConventions.ValidHookName.UseUnderscores -- LearnPress hook.
	}

	LP()->template( 'course' )->course_content_item();

	LP()->template( 'course' )->course_item_comments();
	?>
</div>
