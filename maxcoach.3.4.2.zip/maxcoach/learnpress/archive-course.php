<?php
/**
 * Template for displaying content of archive courses page.
 *
 * @author  ThimPress
 * @package LearnPress/Templates
 * @version 4.0.2
 */
defined( 'ABSPATH' ) || exit;

get_header();

global $wp_query;
?>
	<div id="page-content" class="page-content">
		<div class="container">
			<div class="row">

				<?php Maxcoach_Templates::render_sidebar( 'left' ); ?>

				<div class="page-main-content">
					<div class="lp-archive-courses">
						<?php
						do_action( 'lp/template/archive-course/description' );
						do_action( 'learn-press/list-courses/layout' );
						?>
					</div>
				</div>

				<?php Maxcoach_Templates::render_sidebar( 'right' ); ?>

			</div>
		</div>
	</div>
<?php
get_footer();
