<?php
/**
 * Template for displaying course meta level within the loop.
 *
 * @author        ThemeMove
 * @theme-since   2.7.9
 * @theme-version 2.7.9
 */

defined( 'ABSPATH' ) || exit;

$level = learn_press_get_post_level( get_the_ID() );

if ( ! $level || '1' !== Maxcoach::setting( 'course_archive_meta_level_enable' ) ) {
	return;
}
?>

<div class="course-level">
	<span class="meta-icon far fa-signal"></span>
	<span class="meta-value">
		<?php echo esc_html( $level ); ?>
	</span>
</div>

