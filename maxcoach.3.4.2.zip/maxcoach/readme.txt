=== Maxcoach ===

Contributors: thememove
Tags: editor-style, featured-images, microformats, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready

Requires at least: 4.4
Tested up to: 5.x.x
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Maxcoach – Online Learning and Education WordPress Theme

== Description ==

MaxCoach is an exquisite WordPress theme intended for creating an online education and coaching website. Embracing flexible page builders, predefined layouts, powerful custom widgets, and functional features.
MaxCoach proves to be the best assistant for building online portal to distant education, delivering one-on-one tutoring, and teaching/learning any subject from home.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =


== Changelog ==

= 3.4.2 - Oct 28, 2026 =
- Updated:
Updated outdated templates of WooCommerce 11.2.1
Revolution Slider plugin v.6.8.0
- Fixed:
Fix: WooCommerce 11.2.1 compat - Back in stock notifications table on My Account (column labels on mobile, button spacing)
Fix: Missing lesson video and Zoom icons in course curriculum and lesson popup sidebar

= 3.4.1 - Oct 22, 2026 =
- Updated:
Compatible with LearnPress 4.4.11
Updated outdated templates of LearnPress 4.4.11
- Fixed:
Fix: LearnPress 4.4.9+ compat - Show/Hide curriculum button missing on lesson & quiz screen
Fix: LearnPress 4.4.11 compat - Notes & AI Assistant buttons on lesson screen inherit theme button size
Fix: LearnPress 4.4.11 compat - sorting courses by price treats "No enrollment requirement" courses as free
- Note:
After updating, click "Go to Update" in the "Maxcoach update" admin notice to re-sync course sort prices
Courses with "No enrollment requirement" saved before LearnPress 4.4.11 keep their old price in LearnPress data (price filter on course archive) until they are saved again

= 3.4.0 - Sep 27, 2026 =
- Updated:
Compatible with WooCommerce 11.1.2
Support WooCommerce variation galleries on single product (slider, list, single layouts)
Compatible with LearnPress 4.4.8
Support LearnPress - Course Review 4.2 (new rating & reviews layout, write a review popup)
- Fixed:
Fix: Variation image switching on single product (Swiper error, variations loaded via AJAX, images not in product gallery)
Fix: Cart page fatal error when a cart item is not a product
Fix: Empty cart button with plain permalinks, fatal error on REST/admin requests
Fix: Shop sorting warnings, SKU not updated on variation select, fatal error on WooCommerce < 9.7
Fix: Shop page "Show categories" display hides search & filter results
Fix: Mini cart missing WooCommerce hooks (express checkout buttons)
Fix: Cross-sells slider and quick view after cart updated via AJAX
Fix: Quick view variable product options not working
Fix: Product price display (tax display, price suffix, trim zeros, empty price, same price range)
Fix: Elementor grids load more - lost category filter, offset, sorting, hidden products shown
Fix: Review Order page duplicated title
Fix: Division by zero with custom thumbnail cropping
Fix: Coupon error message style on cart & checkout
Fix: PHP 8.1 deprecation notice on empty cart
Fix: LearnPress 4.4.8 compat - button colors on Profile, Checkout & Order received pages
Fix: LearnPress 4.4.8 compat - spacing of notice messages (Profile, Login/Register, Lesson, Checkout)
Fix: LearnPress 4.4.8 compat - Checkout & Order received tables, Profile tables (My Courses, Quizzes, Orders)
Fix: Password Strength settings not applied on LearnPress register forms (Profile & Checkout)
Fix: "Create Events" setting not allowing instructors to create events
Fix: Course Search Form widget not filtering courses
Fix: Button Text of Course, Course List, Course Carousel widgets not working
Fix: Sorting courses by price/popularity in Elementor course grids (numeric order, missing courses, load more)
Fix: Lesson Video field missing on Edit Lesson screen
Fix: LearnPress Course Builder not saving theme fields (Language, Time, Lesson Video, Zoom Meeting ID)
Fix: Title Bar 03 fatal error on empty course archive
Fix: Course rating stars missing on course archive
Fix: Single course sticky sidebar when switching tabs
Fix: Original price hidden when course is on sale to free
- Security:
Elementor grids AJAX pagination (Blog, Course, Portfolio, Product) only accepts signed queries, prevents loading draft/private posts
Quick view only loads visible products
Empty cart link verifies nonce
Escape product gallery image captions
Escape re-filled values of Become a Teacher form
Escape & sanitize Lesson Video field and Zoom Meeting ID
Escape output of LearnPress course widgets and profile header
- Note:
Please clear page cache after updating (load more of cached pages won't work until cache is cleared)
Password Strength settings (LearnPress > Settings > Profile) are now enforced on register forms
LearnPress widget areas "Course Sidebar" & "All Courses" are removed (not displayed by the theme), their widgets move to Inactive Widgets
Removed unused Paid Memberships Pro page templates

= 3.3.7 - Sep 7, 2026 =
- Updated:
Updated outdated templates of WooCommerce 11.1.0
- Fixed:
Fix: WooCommerce single product - restore stock quantity hidden by leftover CSS

= 3.3.6 - Aug 11, 2026 =
- Updated:
Updated outdated templates of WooCommerce 11.0.1
- Fixed:
Fix: LearnPress 4.x compat - regular price decimals filter + escape section title/description
Fix: LearnPress 4.x compat - style the new info-learning block (course progress) on single course

= 3.3.5 - Jul 23, 2026 =
- Updated:
Insight Core plugin v.2.8.4
Revolution Slider plugin v.6.7.58
ThemeMove Addons For Elementor plugin v.2.1.2
Updated outdated templates of LearnPress 4.4.2
- Fixed:
Fix: single event blank layout when no location + support iframe map embed
Fix: LearnPress 4.4 compat - fatal error in Featured/Popular/Recent Courses widgets
Fix: LearnPress 4.4 compat - course progress and passing grade in single course sidebar
Fix: LearnPress 4.4 compat - remove obsolete profile/dashboard template overrides and dead hooks
Fix: missing style for bottom link (Go to Courses) in LearnPress course widgets

= 3.3.4 - Jun 9, 2026 =
- Updated:
Insight Core plugin v.2.8.3
Revolution Slider plugin v.6.7.57
Updated outdated templates of WooCommerce 10.8.0
- Fixed:
Fix: LearnPress 4.3 compat - render offline course with theme single layout

= 3.3.3 - May 20, 2026 =
- Updated:
Insight Core plugin v.2.8.2
Revolution Slider plugin v.6.7.55
- Fixed:
Fix: LearnPress 4.3 compat - rename profile settings filter to lp/settings/profile
Fix: PHP warning, compatible with PHP 8.5
Fix: escape output

= 3.3.2 - Mar 24, 2026 =
- Updated:
Revolution Slider plugin v.6.7.51
- Performance:
Optimize WooCommerce asset enqueuing
Minify CSS files
- Security:
Add nonce verification to public AJAX handlers

= 3.3.1 - Mar 3, 2026 =
- Updated:
Revolution Slider plugin v.6.7.41
Updated outdated templates of WooCommerce 10.5.2
- Fixed:
Fix: Add class existence check for Maxcoach_Meta_Box_File_Input_Field

= 3.3.0 - Jan 13, 2026 =
- Updated:
Insight Core plugin v.2.8.1
Move CSS inline to files
Update language switcher (GTranslate, Translate Press)

= 3.2.9 - Dec 26, 2025 =
- Updated:
Revolution Slider plugin v.6.7.40
Updated outdated templates of WooCommerce 10.3.0

= 3.2.8 - Dec 4, 2025 =
- Updated:
Insight Core plugin v.2.8.0
Revolution Slider plugin v.6.7.39
- Fixed:
Local File Inclusion security

= 3.2.7 - Oct 8, 2025 =
- Updated:
Revolution Slider plugin v.6.7.38
- Fixed:
Fix image placeholder not show when image is not exist
Fix isotope layout broken in Tabs component

= 3.2.6 - August 21, 2025 =
- Updated:
Revolution Slider plugin v.6.7.36
Updated outdated templates of WooCommerce 10.1.0

= 3.2.5 - July 17, 2025 =
- Fixed:
Fix security issue on AJAX action.

= 3.2.4 - July 16, 2025 =
- Updated:
Updated outdated templates of WooCommerce 10.0.0
Refactor archive courses

= 3.2.3 - July 7, 2025 =
- Updated:
ThemeMove Addons For Elementor plugin v.2.1.0
Revolution Slider plugin v.6.7.35

= 3.2.2 - June 24, 2025 =
- Fixed:
Fix outdated templates of LearnPress
Fix text_domain PHP warning

= 3.2.1 - June 11, 2025 =
- Fixed:
Updated outdated templates of WooCommerce 9.8.0

= 3.2.0 - May 29, 2025 =
- Fixed:
Fix security issue on AJAX action.

= 3.1.4 - May 23, 2025 =
- Updated:
Insight Core plugin v.2.7.4
Revolution Slider plugin v.6.7.34

= 3.1.3 - February 27, 2025 =
- Updated:
Revolution Slider plugin v.6.7.30
- Fixed:
Compatible with LearnPress 4.2.8

= 3.1.2 - February 27, 2025 =
- Fixed:
Updated outdated templates of WooCommerce 9.7.0

= 3.1.1 - February 25, 2025 =
- Updated:
Revolution Slider plugin v.6.7.29
- Fixed:
Fix dashicons missing

= 3.1.0 - Feb 18, 2025 =
- Updated:
Insight Core plugin v.2.7.3
- Fixed:
Fix Kirki @font-face load wrong url.

= 3.0.3 - February 14, 2025 =
- Updated:
Insight Core plugin v.2.7.2
- Fixed:
IMPV customize preview loading time

= 3.0.2 - February 13, 2025 =
- Updated:
Revolution Slider plugin v.6.7.28
- Fixed:
PHP warning

= 3.0.1 - January 21, 2025 =
- Updated:
Updated outdated templates of WooCommerce 9.6.0
Revolution Slider plugin v.6.7.25
- Fixed:
Fix LP Gravatar blurry

= 3.0.0 - December 18, 2024 =
- Updated:
Compatible with the latest version of Elementor plugin
Out-date Woocommerce templates

= 2.9.9 - December 13, 2024 =
- Updated:
Revolution Slider plugin v.6.7.23
- Fixed:
Fix theme load text domain

= 2.9.8 - November 15, 2024 =
- Updated:
Updated outdated templates of WooCommerce 9.4.1

= 2.9.7 - November 7, 2024 =
- Updated:
Revolution Slider plugin v.6.7.21
ThemeMove Addons For Elementor plugin v.2.0.1
- Fixed:
Don't update Elementor form to avoid PHP issue
Fix Sale course price duplicate error

= 2.9.6 - Oct 22, 2024 =
- Updated:
Insight Core plugin v.2.7.1
- Fixed:
Fix Profile page style

= 2.9.5 - Oct 11, 2024 =
- Updated:
Revolution Slider plugin v.6.7.20
- Fixed:
Fix Course rating stars
Fix minor style issue

= 2.9.4 - August 27, 2024 =
- Updated:
Revolution Slider plugin v.6.7.18
Updated out-date templates of WooCommerce 9.3.0
- Fixed:
Fix Elementor widgets used waypoint broken in Elementor 2.24.x
Fix lp-deprecated function

2.9.3 - July 17, 2024
- Updated:
LearnPress - Paid Membership Pro Integration plugin - v.4.0.5
Fix Profile Style

2.9.2 - July 16, 2024
- Updated:
Revolution Slider plugin - v.6.7.15
- Fixed:
WooCommerce 9.0.0 out-date templates

2.9.1 - July 1, 2024
- Updated:
Revolution Slider plugin - v.6.7.14
- Fixed:
Fix Course Single Button Toggle Sidebar

2.9.0 - June 24, 2024
- Updated:
Insight Core plugin 2.7.0
Revolution Slider plugin - v.6.7.13
ThemeMove Addons For Elementor plugin - v.2.0.0
- Fixed:
WooCommerce 9.0.0 out-date templates

2.8.9 - April 23, 2024
- Updated:
Revolution Slider plugin - v.6.7.5
- Fixed:
Fix LearnPress Profile Style
WooCommerce out-date templates

2.8.8 - March 15, 2024
- Updated:
Insight Core plugin 2.6.7
- Fixed:
Fix google font not working error.

2.8.7 - March 14, 2024 =
- Fixed:
Fix Quiz not display total number questions.
Fix wrong domain

2.8.6 - February 20, 2024 =
- Fixed:
Fix SEO problem with duplicate h1 tag on blog posts and courses
Fix LearnPress outdated template.
- Added:
'maxcoach/single_post/featured_image_size' filter hook.

2.8.5 - February 16, 2024 =
- Updated:
FontAwesome Pro 6.4.2

2.8.4 - January 12, 2024 =
- Updated:
Revolution Slider plugin - v.6.6.20
ThemeMove Addons For Elementor plugin - v.1.3.2
- Added:
Comments on Single Course

= 2.8.3 - December 19, 2023 =
- Fixed:
Fix items per view setting of Elementor Carousel & Grid widgets not working properly on mobile.

= 2.8.2 - December 6, 2023 =
- Fixed:
Fix PHP waring from Elementor 3.18.0

2.8.1 - November 29, 2023 =
- Updated:
Change the url of the Header login icon to go to the Profile page after logged.
- Fixed:
Fix profile page style

2.8.0 - November 14, 2023 =
- Updated:
Revolution Slider plugin - v.6.6.18
ThemeMove Addons For Elementor plugin - v.1.3.1
- Fixed:
Mobile logo is blurred

2.7.9 - October 14, 2023 =
- Updated:
Revolution Slider plugin - v.6.6.16
Compatible with LearnPress 4.2.4

2.7.8 - August 24, 2023 =
- Updated:
Insight Core plugin - v.2.6.5 (Compatible with WordPress 6.2.0)
Revolution Slider plugin - v.6.6.15

2.7.7 - July 25, 2023 =
- Fixed:
Compatible with LearnPress 4.2.3.2

2.7.6 - July 20, 2023 =
- Fixed:
Compatible with WooCommerce 7.9.0

2.7.5 - July 17, 2023 =
- Updated:
Revolution Slider plugin - v.6.6.14
- Fixed:
Event can't book if Woocommerce is not activated.
Fix Quick Compare Table style
Compatible with WooCommerce 7.8.0

2.7.4 - June 01, 2023 =
- Updated:
Revolution Slider plugin - v.6.6.13
- Fixed:
Profile update not saved when there are any custom fields present.
out-date Elementor hooks.
Minor style of notice messages.

2.7.3 - April 28, 2023 =
- Updated:
ThemeMove Addons For Elementor plugin v.1.3.0
Revolution Slider plugin - v.6.6.12
Tested up LearnPress plugin - 4.2.2.4
- Fixed:
out-date LearnPress templates
header not showing in course page

2.7.2 - March 1, 2023 =
- Updated:
Insight Core plugin - v.2.6.4
Revolution Slider plugin - v.6.6.11
- Fixed:
Fix RTL for Grid layout
Compatible with WooCommerce 7.4.0

2.7.1 - December 08 2022 =
- Updated:
Insight Core plugin - v.2.4.12
out-date Woocommerce templates.

2.7.0 - November 28 2022 =
- Added:
New homepage Sales Coaching.
New homepage Mental Therapy.
- Updated:
Insight Core plugin - v.2.4.11
Revolution Slider plugin - v.6.5.7

= 2.6.5 - September 21 2022 =
- Updated:
Insight Core plugin - v.2.4.9
Revolution Slider plugin - v.6.5.31
Tested up with Elementor 3.7.7
Tested up with Woocommerce 6.9.3
Improvement site performance.
out-date Learnpress templates.

= 2.6.4 - August 03 2022 =
- Updated:
Insight Core plugin - v.2.4.7
- Fixed:
widget Testimonial Carousel 3d not working up to 4 items.

= 2.6.3 - June 29 2022 =
- Updated:
Revolution Slider plugin - v.6.5.25
- Fixed:
Compare popup style
Some jquery migration deprecated
Improvement page loading

= 2.6.2 - May 31 2022 =
- Updated:
Insight Core plugin - v.2.4.6
Revolution Slider plugin - v.6.5.24
Instagram Feed plugin - v.4.0.3
- Fixed:
Tested up with PHP 8.x.x
Shop wishlist popup style
Become a teacher form.
out-date LearnPress templates

= 2.6.1 - March 30 2022 =
- Fixed:
Compatible with latest Elementor plugin 3.6.1

= 2.6.0 - March 30 2022 =
- Updated:
Insight Core plugin - v.2.4.0
Revolution Slider plugin - v.6.5.19
- Fixed:
Compatible with latest Elementor plugin 3.6.1

= 2.5.1 - Jan 20 2022 =
- Fixed :
Sort price not saving properly with latest LearnPress.
Out-date Learnpress templates

= 2.5.1 - Jan 11 2022 =
- Updated :
Insight Core plugin - v.2.2.8
Revolution Slider plugin - v.6.5.14
Paid Membership plugin - v.4.0.1
- Fixed :
Compatible with latest LearnPress

= 2.5.0 - September 09 2021 =
- Updated :
Insight Core plugin - v.2.2.3
Revolution Slider plugin - v.6.5.7
- Fixed :
One-page menu scroll
Contact Form 7 Ajax submitting
Compatible with LearnPress 4.1.3

= 2.4.7 - July 31 2021 =
- Fixed :
Course Archive not showing with Learnpress 4.1.2
Shop Compare Popup not showing

= 2.4.6 - July 15 2021 =
- Fixed :
Jetpack compatible.

= 2.4.5 - July 05 2021 =
- Updated :
Revolution Slider plugin - v.6.5.4
- Fixed :
Widget Typed broken when empty text.
Compatible with LearnPress 4.1.0
Fix Logout page show php code

= 2.4.4 - June 21 2021 =
- Updated :
Revolution Slider plugin - v.6.5.2
- Fixed :
Lesson Video Meta Box Field
Lesson Zoom meeting Meta Box Field
Registration form.
Out-date LearnPress templates v.4.0.8

= 2.4.3 - June 11 2021 =
- Updated :
Insight Core plugin - v.2.2.1
- Fixed :
single Quiz not showing properly.

= 2.4.2 - May 26 2021 =
- Fixed :
Contact Form 7 widget broken layout.
PHP warning error on course pages.

= 2.4.1 - May 24 2021 =
- Fixed :
Course Membership Levels not saved properly.
Guest checkout show empty cart.
Out-date LearnPress templates

= 2.4.0 - May 18 2021 =
- Updated :
Insight Core plugin - v.2.2.0
Revolution Slider plugin - v.6.4.11
LearnPress - Paid Membership Pro plugin - v.4.0.0
ThemeMove Payment Add-ons for LearnPress - v.1.2.0
Compatible with LearnPress plugin 4.0.0
- Fixed :
Jquery migration.
- Improvement:
Single Course page style
Single Lesson page style
Profile page style

= 2.3.2 - April 27 2021 =
- Updated :
Insight Core plugin - v.2.1.1
Revolution Slider plugin - v.6.4.8
- Fixed :
link of Course Continue Button not working properly.
minor style of Course Listing.
out-date Woocommerce template.

= 2.3.1 - April 09 2021 =
- Fixed :
Cart empty messages.
Hosted video not working on lesson page.
- Updated :
Insight Core plugin - v.2.1.0
Instagram Feed plugin - v.4.0.2

= 2.3.0 - March 29 2021 =
- Fixed :
Image Gallery widget causing PHP warning.
Events menu item not showing in Dashboard.
Profile layout broken.
Lesson layout on Safari.
Out-date Woocommerce template.
- Updated:
Revolution Slider plugin - v.6.4.6

= 2.2.0 - March 05 2021 =
- Fixed :
Importer not working properly.
- Updated:
Insight Core plugin - v.2.0.0
Revolution Slider plugin - v.6.4.2

= 2.1.0 - February 25 2021 =
- Fixed :
Stripe payment.
Admin capability for event post type.
- Updated:
Insight Core plugin - v.1.7.9.4
ThemeMove Payment plugin - v.1.1.0

= 2.0.4 - February 17 2021 =
- Fixed :
Minor course review style.
Duplicate login form on checkout page.
Lesson Sidebar broken with latest Learnpress plugin.

= 2.0.3 - February 17 2021 =
- Added :
setting allows instructors create event posts.
Updated:
Insight Core plugin - v.1.7.9.3
ThemeMove Payment plugin - v.1.0.2

= 2.0.2 - February 08 2021 =
Updated:
Insight Core plugin - v.1.7.9.2
Revolution Slider plugin - v.6.3.9

= 2.0.1 - January 14 2021 =
Updated:
Insight Core plugin - v.1.7.9
Revolution Slider plugin - v.6.3.5
Fixed:
Elementor plugin link download broken.

= 2.0.0 - December 28 2020 =
Added: new style 03 for widget Image Box
Added: new header style 12
Added: more caption styles for widget Course.
Added: new style 08 for widget Testimonial Carousel.
Added: new style for widget List.
Added: new style for widget Accordion.
Updated: Insight Core plugin - v.1.7.7
Updated: Revolution Slider plugin - v.6.3.3
Fixed: masonry layout of widget Course.
Improvement: Shapes widget.
Improvement: Mailchimp Form widget.
Improvement: Gradation widget.

= 1.6.0 - November 04 2020 =
Fixed: Pricing widget not working price is 0.
Fixed: Video Zoom Meetings not working properly.

= 1.5.0 - October 02 2020 =
Updated: Insight Core plugin - v.1.7.4
Updated: Instagram Feed plugin - v.4.0.1
Updated: Revolution Slider plugin - v.6.2.23
Updated: out-date Woocommerce templates.
Fixed: Importer broken with latest Elementor version.
Fixed: wrong user e-mail social link

= 1.4.5 - August 19 2020 =
Updated: Insight Core plugin - v.1.7.2
Fixed: Course duration can't be translatable.
Fixed: Event date can't be translatable.

= 1.4.4 - August 13 2020 =
Fixed: Customize not working with WordPress 5.5 (Required update Insight Core)
Updated: Insight Core plugin - v.1.7.1
Updated: Revolution Slider plugin - v.6.2.18
Added: new Instagram Feed plugin - v.3.8.7
Removed: old Instagram widget. Used Instagram Feed plugin instead of.

= 1.4.3 - June 11 2020 =
Updated: Revolution Slider plugin - v.6.2.12

= 1.4.2 - June 04 2020 =
Fixed: logo blurry on retina devices.
Fixed: course price currency template not showing.
Improvement: site performance.

= 1.4.1 - June 03 2020 =
Added: option controls typography for mobile menu sub-items.
Added: badge option for Modern Icon List widget.
Fixed: archive Zoom Meeting style.
Fixed: admin bar search box style.
Fixed: mega menu style.
Updated: Revolution Slider plugin - v.6.2.10

= 1.4.0 - May 27 2020 =
Added: new shortcode tm_zoom_meeting
Added: new Elementor widget Zoom Meeting.
Added: new Elementor widget Contact Form 7.
Added: new Elementor widget Typed Headline.
Added: archive zoom meeting layout.
Added: single zoom meeting layout.
Added: video for lesson post type.
Added: zoom meeting for lesson post type.
Added: content protected feature. Disabled by default. Enable in Customize - Advanced
Added: Font Awesome Duotone to Elementor Icon Manager.
Fixed: style curriculum section header meta.
Fixed: responsive of testimonial style 07.
Fixed: custom font not enqueue for when saved with customize.
Fixed: RTL style.
Updated: missing Arabic translation strings.
Updated: swiper js library - v.5.4.1
Updated: Font Awesome Pro library - v.5.13.0
Updated: ThemeMove Payment Add-ons for LearnPress plugin - v.1.0.1

= 1.3.1 - May 20 2020 =
Improvement: import demo.

= 1.3.0 - May 20 2020 =
Added: 3 new homepages Motivation, Kitchen Coach, Artist.
Added: featured image for single course.
Added: related courses section.
Added: course reviews tab.
Added: new elementor widget Modern Carousel 02.
Added: new option show/hide course thumbnail on single course pages.
Added: arrows shadow option for all Carousel/Slider widget.
Added: text stroke style for primary title of Heading widget.
Added: price style setting for Course widget.
Added: new style for Event widget.
Added: more options for Event Carousel widget.
Added: new caption style for Course widget.
Added: New style + more options for Testimonial Carousel widget.
Added: More distortion style & more settings for Shapes widget.
Tweak: caption style of Blog ZigZag style.
Tweak: caption style of Event Carousel style.
Improvement: WPML config file.
Improvement: responsive style for Testimonial widget.
Fixed: Cookie notice popup style.
Fixed: progress bar style.
Fixed: badge style of Button widget.
Fixed: bubble style of Icon Box widget.
Fixed: wrong condition of view shape of Icon Box widget.
Fixed: gradient color is not working properly with font icons of Icon Box widget.
Fixed: gradient color is not working properly with font icons of Icon widget.
Updated: Revolution Slider plugin - v.6.2.8
Updated: Insight Core plugin - v.1.6.8

= 1.2.5 - May 05 2020 =
Improvement: Demo importer speed.

= 1.2.4 - April 24 2020 =
Added: more settings to controls password strength on register page.

= 1.2.3 - April 17 2020 =
Fixed: popup video not showing on RTL.

= 1.2.2 - April 16 2020 =
Added: stripe payment method for LearnPress.
Added: custom sidebar width & offset for shop archive.
Fixed: minor nice select style.
Fixed: minor blog typography style.
Fixed: header style 06.
Updated: shop full wide column number.
Updated: shop with sidebar column number.

= 1.2.1 - April 10 2020 =
Added: support for social login.
Fixed: Woocommerce checkout page term conditions hidden.
Fixed: Course checkout page style.
Improvement: Membership checkout layout.

= 1.2.0 - April 09 2020 =
Added: Business homepage.
Added: new style for Modern Carousel widget.
Added: new style for Course widget.
Added: new style for Icon Box widget.
Added: new style for Modern Accordion/Toggle widget.
Added: new style for Header.
Added: header login icon for all headers.
Improvement: login/register page.
Improvement: SEO optimize.

= 1.1.0 - April 07 2020 =
Added: Health Coaching homepage.
Added: Gym Coaching homepage.
Added: New style for Event Grid widget.
Added: New caption style 06 + 07 for Course widget.
Added: New slider dot style.
Added: New style for Blog Widget.
Added: New layout for Testimonial Widget.
Added: New widget Mailchimp Form.
Improvement: add more options for Modern Slider widget
Improvement: add more options for Event Grid widget
Fixed: minor single lesson style.
Fixed: caption style 04 of Course widget.
Fixed: course archive tags page.

= 1.0.2 - March 27 2020 =
Updated: content import
Fix: minor RTL style.

= 1.0.1 - March 26 2020 =
Updated: content import

= 1.0.0 - March 26 2020 =
* Initial release

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
