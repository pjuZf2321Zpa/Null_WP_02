<?php
defined( 'ABSPATH' ) || exit;

/**
 * Helper functions
 */
if ( ! class_exists( 'Maxcoach_Helper' ) ) {
	class Maxcoach_Helper {

		static $preloader_style = array();

		function __construct() {
			add_action( 'init', [ $this, 'init_preloader_styles' ] );
		}

		public static function init_preloader_styles() {
			self::$preloader_style = array(
				'rotating-plane'  => esc_attr__( 'Rotating Plane', 'maxcoach' ),
				'double-bounce'   => esc_attr__( 'Double Bounce', 'maxcoach' ),
				'three-bounce'    => esc_attr__( 'Three Bounce', 'maxcoach' ),
				'wave'            => esc_attr__( 'Wave', 'maxcoach' ),
				'wandering-cubes' => esc_attr__( 'Wandering Cubes', 'maxcoach' ),
				'pulse'           => esc_attr__( 'Pulse', 'maxcoach' ),
				'chasing-dots'    => esc_attr__( 'Chasing dots', 'maxcoach' ),
				'circle'          => esc_attr__( 'Circle', 'maxcoach' ),
				'cube-grid'       => esc_attr__( 'Cube Grid', 'maxcoach' ),
				'fading-circle'   => esc_attr__( 'Fading Circle', 'maxcoach' ),
				'folding-cube'    => esc_attr__( 'Folding Cube', 'maxcoach' ),
				'gif-image'       => esc_attr__( 'Gif Image', 'maxcoach' ),
			);
		}

		public static function e( $var = '' ) {
			echo "{$var}";
		}

		public static function get_preloader_list() {
			$list = self::$preloader_style + array( 'random' => esc_attr__( 'Random', 'maxcoach' ) );

			return $list;
		}

		public static function get_post_meta( $name, $default = false ) {
			global $maxcoach_page_options;

			if ( $maxcoach_page_options != false && isset( $maxcoach_page_options[ $name ] ) ) {
				return $maxcoach_page_options[ $name ];
			}

			return $default;
		}

		public static function get_the_post_meta( $options, $name, $default = false ) {
			if ( $options != false && isset( $options[ $name ] ) ) {
				return $options[ $name ];
			}

			return $default;
		}

		/**
		 * @return array
		 */
		public static function get_list_revslider() {
			global $wpdb;
			$revsliders = array(
				'' => esc_attr__( 'Select a slider', 'maxcoach' ),
			);

			if ( function_exists( 'rev_slider_shortcode' ) ) {

				$table_name = $wpdb->prefix . 'revslider_sliders';
				$query      = $wpdb->prepare( "SELECT * FROM $table_name WHERE type != %s ORDER BY title ASC", 'template' );
				$results    = $wpdb->get_results( $query );
				if ( ! empty( $results ) ) {
					foreach ( $results as $result ) {
						$revsliders[ $result->alias ] = $result->title;
					}
				}
			}

			return $revsliders;
		}

		/**
		 * @param bool $default_option
		 *
		 * @return array
		 */
		public static function get_registered_sidebars( $default_option = false, $empty_option = true ) {
			global $wp_registered_sidebars;
			$sidebars = array();
			if ( $empty_option === true ) {
				$sidebars['none'] = esc_html__( 'No Sidebar', 'maxcoach' );
			}
			if ( $default_option === true ) {
				$sidebars['default'] = esc_html__( 'Default', 'maxcoach' );
			}
			foreach ( $wp_registered_sidebars as $sidebar ) {
				$sidebars[ $sidebar['id'] ] = $sidebar['name'];
			}

			return $sidebars;
		}

		/**
		 * Get list sidebar positions
		 *
		 * @return array
		 */
		public static function get_list_sidebar_positions( $default = false ) {
			$positions = array(
				'left'  => esc_html__( 'Left', 'maxcoach' ),
				'right' => esc_html__( 'Right', 'maxcoach' ),
			);


			if ( $default === true ) {
				$positions['default'] = esc_html__( 'Default', 'maxcoach' );
			}

			return $positions;
		}

		/**
		 * Get content of file
		 *
		 * @param string $path
		 *
		 * @return mixed
		 */
		static function get_file_contents( $path = '' ) {
			$content = '';
			if ( $path !== '' ) {
				global $wp_filesystem;

				require_once ABSPATH . '/wp-admin/includes/file.php';
				WP_Filesystem();

				if ( file_exists( $path ) ) {
					$content = $wp_filesystem->get_contents( $path );
				}
			}

			return $content;
		}

		public static function strposa( $haystack, $needle, $offset = 0 ) {
			if ( ! is_array( $needle ) ) {
				$needle = array( $needle );
			}
			foreach ( $needle as $query ) {
				if ( strpos( $haystack, $query, $offset ) !== false ) {
					return true;
				} // stop on first true result
			}

			return false;
		}

		public static function w3c_iframe( $iframe ) {
			$iframe = str_replace( 'frameborder="0"', '', $iframe );
			$iframe = str_replace( 'frameborder="no"', '', $iframe );
			$iframe = str_replace( 'scrolling="no"', '', $iframe );
			$iframe = str_replace( 'gesture="media"', '', $iframe );
			$iframe = str_replace( 'allow="encrypted-media"', '', $iframe );

			return $iframe;
		}

		public static function get_md_media_query() {
			return '@media (max-width: 1199px)';
		}

		public static function get_sm_media_query() {
			return '@media (max-width: 991px)';
		}

		public static function get_xs_media_query() {
			return '@media (max-width: 767px)';
		}

		public static function get_body_font() {
			$font = Maxcoach::setting( 'typography_body' );

			if ( isset( $font['font-family'] ) ) {
				return "{$font['font-family']} Helvetica, Arial, sans-serif";
			}

			return 'Helvetica, Arial, sans-serif';
		}

		/**
		 * Check search page has results
		 *
		 * @return boolean true if has any results
		 */
		public static function is_search_has_results() {
			if ( is_search() ) {
				global $wp_query;
				$result = ( 0 != $wp_query->found_posts ) ? true : false;

				return $result;
			}

			return 0 != $GLOBALS['wp_query']->found_posts;
		}

		public static function get_button_typography_css_selector() {
			$default_selectors = '
				button,
				input[type="button"],
				input[type="reset"],
				input[type="submit"],
				.wp-block-button__link,
				.rev-btn,
				.tm-button,
				.button,
				.elementor-button,
				.pmpro_btn,
				.pmpro_btn:link,
				.pmpro_content_message a,
				.pmpro_content_message a:link,
				.event_auth_button
			';

			$selectors = apply_filters( 'maxcoach_customize_output_button_typography_selectors', [ $default_selectors ] );

			return $selectors;
		}

		public static function get_button_css_selector() {
			$default_selectors = '
				button,
				input[type="button"],
				input[type="reset"],
				input[type="submit"],
				.wp-block-button__link,
				.button,
				.elementor-button,
				.event_auth_button,
				.pmpro_btn, .pmpro_btn:link, .pmpro_content_message a, .pmpro_content_message a:link
				';

			$selectors = apply_filters( 'maxcoach_customize_output_button_selectors', [ $default_selectors ] );

			return $selectors;
		}

		public static function get_button_hover_css_selector() {
			$default_selectors = '
				button:hover,
				input[type="button"]:hover,
				input[type="reset"]:hover,
				input[type="submit"]:hover,
				.wp-block-button__link:hover,
				.button:hover,
				.button:focus,
				.elementor-button:hover,
				.event_auth_button:hover,
				.pmpro_btn:hover, .pmpro_btn:link:hover, .pmpro_content_message a:hover, .pmpro_content_message a:link:hover,
				.learn-press-form-login button[type=submit]:hover, .learn-press-form-register button[type=submit]:hover
				';

			$selectors = apply_filters( 'maxcoach_customize_output_button_hover_selectors', [ $default_selectors ] );

			return $selectors;
		}

		public static function get_form_input_css_selector() {
			$default_selectors = "
				input[type='text'],
				input[type='email'],
				input[type='url'],
				input[type='password'],
				input[type='search'],
				input[type='number'],
				input[type='tel'],
				select,
				textarea,
				.woocommerce .select2-container--default .select2-selection--single,
				.woocommerce .select2-container--default .select2-search--dropdown .select2-search__field,
				.elementor-field-group .elementor-field-textual
			";

			$selectors = apply_filters( 'maxcoach_customize_output_form_input_selectors', [ $default_selectors ] );

			return $selectors;
		}

		public static function get_form_input_focus_css_selector() {
			$default_selectors = "
				input[type='text']:focus,
				input[type='email']:focus,
				input[type='url']:focus,
				input[type='password']:focus,
				input[type='search']:focus,
				input[type='number']:focus,
				input[type='tel']:focus,
				textarea:focus, select:focus,
				select:focus,
				textarea:focus,
				.woocommerce .select2-container--default .select2-search--dropdown .select2-search__field:focus,
				.woocommerce .select2-container--open.select2-container--default .select2-selection--single,
				.woocommerce .select2-container--open.select2-container--default .select2-dropdown,
				.elementor-field-group .elementor-field-textual:focus
			";

			$selectors = apply_filters( 'maxcoach_customize_output_form_input_focus_selectors', [ $default_selectors ] );

			return $selectors;
		}

		public static function is_page_template( $template_file ) {
			$template_full = 'templates/' . $template_file;

			return is_page_template( $template_full );
		}

		public static function calculate_percentage( $value1, $value2 ) {
			$percent = ( $value1 > 0 ) ? ( $value1 * 100 ) / $value2 : 0;

			return $percent;
		}

		/**
		 * Verified grid query of current ajax request.
		 *
		 * @var array|null
		 */
		private static $ajax_grid_query = null;

		/**
		 * Offset of current ajax grid query.
		 *
		 * @var int
		 */
		private static $ajax_query_offset = 0;

		/**
		 * @param string|array $var Data to sanitize.
		 *
		 * @return string|array
		 * @see wc_clean() Function clone from woocommerce.
		 *
		 * Clean variables using sanitize_text_field. Arrays are cleaned recursively.
		 * Non-scalar values are ignored.
		 *
		 */
		public static function data_clean( $var ) {
			if ( is_array( $var ) ) {
				return array_map( array( __CLASS__, 'data_clean' ), $var );
			} else {
				return is_scalar( $var ) ? sanitize_text_field( $var ) : $var;
			}
		}

		/**
		 * Max posts per page of grid queries.
		 * Default is the number grids use for "-1" (show all), first render & ajax pagination must use same limit.
		 *
		 * @return int
		 */
		public static function get_grid_query_max_posts() {
			return max( 1, (int) apply_filters( 'maxcoach_ajax_query_max_posts_per_page', 9999 ) );
		}

		/**
		 * Sign grid query of Elementor grid widgets (added to .maxcoach-query-input json).
		 * Ajax pagination only trusts this data, visitors can't change query vars or settings.
		 *
		 * @param string $post_type  Post type of the grid (ajax loader "{$post_type}_infinite_load").
		 * @param string $source     Query source.
		 * @param array  $query_vars Query vars.
		 * @param array  $settings   Widget settings used by ajax templates.
		 *
		 * @return array
		 */
		public static function get_grid_query_signed_data( $post_type, $source, $query_vars, $settings = array() ) {
			$data = (string) wp_json_encode(
				array(
					'post_type'  => $post_type,
					'source'     => $source,
					'query_vars' => $query_vars,
					'settings'   => $settings,
				)
			);

			return array(
				'query_data'      => $data,
				'query_signature' => self::get_grid_query_signature( $data ),
			);
		}

		/**
		 * @param string $data Json data.
		 *
		 * @return string
		 */
		private static function get_grid_query_signature( $data ) {
			return hash_hmac( 'sha256', 'maxcoach_grid_query|' . $data, wp_salt( 'nonce' ) );
		}

		/**
		 * Get grid query (signed by self::get_grid_query_signed_data()) sent back by ajax pagination.
		 * Send json error if it is invalid. Nonce must be verified by caller.
		 *
		 * @return array { post_type, source, query_vars, settings }
		 */
		public static function get_ajax_grid_query() {
			if ( null !== self::$ajax_grid_query ) {
				return self::$ajax_grid_query;
			}

			// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified by caller.
			$data      = isset( $_POST['query_data'] ) && is_string( $_POST['query_data'] ) ? wp_unslash( $_POST['query_data'] ) : '';
			$signature = isset( $_POST['query_signature'] ) && is_string( $_POST['query_signature'] ) ? wp_unslash( $_POST['query_signature'] ) : '';
			// phpcs:enable

			$grid_query = '' !== $data && hash_equals( self::get_grid_query_signature( $data ), $signature ) ? json_decode( $data, true ) : null;

			if ( ! is_array( $grid_query ) ) {
				wp_send_json_error( null, 403 );
			}

			self::$ajax_grid_query = array(
				'post_type'  => isset( $grid_query['post_type'] ) && is_string( $grid_query['post_type'] ) ? $grid_query['post_type'] : '',
				'source'     => isset( $grid_query['source'] ) && is_string( $grid_query['source'] ) ? $grid_query['source'] : '',
				'query_vars' => isset( $grid_query['query_vars'] ) && is_array( $grid_query['query_vars'] ) ? $grid_query['query_vars'] : array(),
				'settings'   => isset( $grid_query['settings'] ) && is_array( $grid_query['settings'] ) ? $grid_query['settings'] : array(),
			);

			return self::$ajax_grid_query;
		}

		/**
		 * Widget settings of ajax grid query.
		 *
		 * @return array
		 */
		public static function get_ajax_grid_settings() {
			$grid_query = self::get_ajax_grid_query();

			return self::data_clean( $grid_query['settings'] );
		}

		/**
		 * Get query vars for ajax grid pagination (elementor/assets/js/widgets/grid-query.js).
		 * Query vars are signed by server, visitors can only change page, filter & sorting of the grid.
		 * Nonce must be verified by caller.
		 *
		 * @param string $post_type Post type of the grid.
		 *
		 * @return array
		 */
		public static function get_ajax_query_vars( $post_type ) {
			$grid_query = self::get_ajax_grid_query();
			$query_vars = $grid_query['query_vars'];

			// Grid query can only be used by the loader of its post type.
			if ( $post_type !== $grid_query['post_type'] ) {
				wp_send_json_error( null, 403 );
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Verified by caller, each var is validated below.
			$client_vars = isset( $_POST['query_vars'] ) && is_array( $_POST['query_vars'] ) ? wp_unslash( $_POST['query_vars'] ) : array();

			// Only grid with current (main) query can show other post types.
			if ( 'current_query' !== $grid_query['source'] ) {
				$query_vars['post_type'] = $post_type;
			}

			unset(
				$query_vars['perm'],
				$query_vars['post_password'],
				$query_vars['suppress_filters'],
				$query_vars['fields'],
				$query_vars['nopaging'],
				$query_vars['showposts'],
				$query_vars['numberposts'],
				$query_vars['posts_per_archive_page'],
				$query_vars['extra_tax_query']
			);

			$query_vars = self::set_ajax_query_sorting( $query_vars, $client_vars );

			$extra_tax_query = isset( $client_vars['extra_tax_query'] ) ? self::sanitize_extra_tax_query( $client_vars['extra_tax_query'] ) : '';

			if ( '' !== $extra_tax_query ) {
				$query_vars['extra_tax_query'] = $extra_tax_query;
			}

			$max_posts = self::get_grid_query_max_posts();
			$per_page  = isset( $query_vars['posts_per_page'] ) ? (int) $query_vars['posts_per_page'] : 0;

			$query_vars['post_type']      = self::get_ajax_query_post_type( isset( $query_vars['post_type'] ) ? $query_vars['post_type'] : '', $post_type );
			$query_vars['post_status']    = self::get_ajax_query_post_status( isset( $query_vars['post_status'] ) ? $query_vars['post_status'] : '' );
			$query_vars['posts_per_page'] = $per_page > 0 ? min( $per_page, $max_posts ) : $max_posts;
			// Limit page number, offset is calculated from it.
			$query_vars['paged'] = isset( $client_vars['paged'] ) && is_scalar( $client_vars['paged'] ) ? min( 1000000, max( 1, (int) $client_vars['paged'] ) ) : 1;

			// Pagination needs found_posts.
			$query_vars['no_found_rows'] = false;

			// WP_Query ignores paged when offset is set (even "0").
			self::$ajax_query_offset = isset( $query_vars['offset'] ) ? max( 0, (int) $query_vars['offset'] ) : 0;

			if ( self::$ajax_query_offset > 0 ) {
				$query_vars['offset'] = self::$ajax_query_offset + ( $query_vars['paged'] - 1 ) * $query_vars['posts_per_page'];
			} else {
				unset( $query_vars['offset'] );
			}

			return $query_vars;
		}

		/**
		 * Pagination data of ajax grid query, found posts don't include offset of the grid.
		 *
		 * @param WP_Query $query Query made with self::get_ajax_query_vars().
		 *
		 * @return array
		 */
		public static function get_ajax_query_response( $query ) {
			$per_page    = max( 1, (int) $query->get( 'posts_per_page' ) );
			$found_posts = max( 0, (int) $query->found_posts - self::$ajax_query_offset );

			return array(
				'max_num_pages' => (int) ceil( $found_posts / $per_page ),
				'found_posts'   => $found_posts,
				'count'         => (int) $query->post_count,
			);
		}

		/**
		 * Apply sorting changed by grid-query.js (handlerSorting).
		 * Meta key can only be the grid one or sorting ones, so private meta can't be queried.
		 *
		 * @param array $query_vars  Signed query vars.
		 * @param array $client_vars Query vars sent by client.
		 *
		 * @return array
		 */
		private static function set_ajax_query_sorting( $query_vars, $client_vars ) {
			$grid_orderby  = isset( $query_vars['orderby'] ) ? $query_vars['orderby'] : '';
			$grid_meta_key = isset( $query_vars['meta_key'] ) && is_string( $query_vars['meta_key'] ) ? $query_vars['meta_key'] : '';

			$orderby  = isset( $client_vars['orderby'] ) && is_string( $client_vars['orderby'] ) ? $client_vars['orderby'] : null;
			$meta_key = isset( $client_vars['meta_key'] ) && is_string( $client_vars['meta_key'] ) ? $client_vars['meta_key'] : '';

			$allowed_orderby   = array( 'date', 'meta_value', 'meta_value title' );
			$allowed_meta_keys = array( '', '_lp_students', '_lp_sort_price', $grid_meta_key );

			if ( null === $orderby || ! ( $orderby === $grid_orderby || in_array( $orderby, $allowed_orderby, true ) ) || ! in_array( $meta_key, $allowed_meta_keys, true ) ) {
				return $query_vars;
			}

			$query_vars['orderby'] = $orderby;
			$query_vars['order']   = isset( $client_vars['order'] ) && is_string( $client_vars['order'] ) && 'ASC' === strtoupper( $client_vars['order'] ) ? 'ASC' : 'DESC';

			// Meta key without meta sorting would only filter posts that have the meta.
			if ( '' === $meta_key || 0 !== strpos( $orderby, 'meta_value' ) ) {
				unset( $query_vars['meta_key'] );
			} else {
				$query_vars['meta_key'] = $meta_key; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			}

			return $query_vars;
		}

		/**
		 * Filter of grid-query.js (handlerFilter): "taxonomy:slug, taxonomy:slug", only public taxonomies.
		 *
		 * @param mixed $value Filter value sent by client.
		 *
		 * @return string
		 */
		private static function sanitize_extra_tax_query( $value ) {
			if ( ! is_string( $value ) || '' === $value ) {
				return '';
			}

			$terms = array();

			foreach ( explode( ', ', $value ) as $term ) {
				$parts = explode( ':', $term, 2 );

				if ( 2 !== count( $parts ) ) {
					continue;
				}

				$taxonomy  = sanitize_key( $parts[0] );
				$term_slug = sanitize_title( $parts[1] );

				if ( '' !== $term_slug && taxonomy_exists( $taxonomy ) && is_taxonomy_viewable( $taxonomy ) ) {
					$terms[] = $taxonomy . ':' . $term_slug;
				}
			}

			return implode( ', ', $terms );
		}

		/**
		 * Keep post statuses of the grid query, only public ones (e.g. "publish").
		 * Never leave it empty, WP_Query default in admin-ajax adds draft, pending, future.
		 *
		 * @param mixed $requested Post status(es) sent by client.
		 *
		 * @return string|array
		 */
		private static function get_ajax_query_post_status( $requested ) {
			$requested = is_string( $requested ) ? array_map( 'trim', explode( ',', $requested ) ) : array_filter( (array) $requested, 'is_string' );
			$statuses  = array_values( array_intersect( $requested, get_post_stati( array( 'public' => true ) ) ) );

			return empty( $statuses ) ? 'publish' : $statuses;
		}

		/**
		 * Keep post types of the grid query (e.g. Current Query of search results), only public ones.
		 *
		 * @param mixed  $requested         Post type(s) sent by client.
		 * @param string $default_post_type Default post type of the grid.
		 *
		 * @return string|array
		 */
		private static function get_ajax_query_post_type( $requested, $default_post_type ) {
			// WP_Query limits "any" to post types not excluded from search, like the search page.
			if ( 'any' === $requested ) {
				return 'any';
			}

			$post_types = array();

			foreach ( (array) $requested as $name ) {
				$post_type_object = is_string( $name ) ? get_post_type_object( $name ) : null;

				if ( $post_type_object && is_post_type_viewable( $post_type_object ) ) {
					$post_types[] = $post_type_object->name;
				}
			}

			if ( empty( $post_types ) ) {
				return $default_post_type;
			}

			return 1 === count( $post_types ) ? $post_types[0] : $post_types;
		}
	}

	new Maxcoach_Helper();
}
