<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Maxcoach_LP_Lesson' ) ) {
	class Maxcoach_LP_Lesson extends Maxcoach_Post_Type {

		protected static $instance = null;

		const POST_META_VIDEO        = '_lp_video';
		const POST_META_ZOOM_MEETING = '_lp_zoom_meeting_id';

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			if ( ! Maxcoach_LP_Course::instance()->is_activated() ) {
				return;
			}

			add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );

			// Course Builder page does not fire wp_enqueue_scripts, it loads wp.media itself after this hook.
			add_action( 'learn-press/course-builder/head', array( $this, 'enqueue_media_input_script' ) );

			LP()->template( 'course' )->remove( 'learn-press/single-item-summary', 'popup_footer', 40 );
			add_action( 'learn-press/after-course-item-content', LP()->template( 'course' )->func( 'popup_footer_nav' ), 10 );

			add_filter( 'lp/metabox/lesson/lists', [ $this, 'add_lesson_settings' ] );

			// Save theme lesson fields submitted from LearnPress Course Builder (LP 4.3.8+).
			add_action( 'learn-press/course-builder/save-lesson-settings', array( $this, 'save_course_builder_lesson_settings' ), 10, 2 );

			// Add video icon to course section item meta (old curriculum templates).
			add_action( 'learn-press/course-section-item/after-lp_lesson-meta', [ $this, 'lesson_video_meta' ], 20 );
			add_action( 'learn-press/course-section-item/after-lp_lesson-meta', [
				$this,
				'lesson_zoom_meeting_meta',
			], 25 );

			// Curriculum of course tab & lesson popup sidebar is rendered by SingleCourseTemplate, it doesn't fire the hooks above.
			add_filter( 'learn-press/course/html-course-item', array( $this, 'course_item_meta_icons' ), 10, 4 );

			// Add custom video, zoom meeting after lesson title.
			add_action( 'learn-press/before-content-item-summary/lp_lesson', [ $this, 'entry_video' ], 20 );
			add_action( 'learn-press/before-content-item-summary/lp_lesson', [ $this, 'entry_zoom_meeting' ], 30 );
		}

		public function admin_scripts() {
			$screen = get_current_screen();

			if ( ! $screen ) {
				return;
			}

			if ( 'post' === $screen->base && 'lp_lesson' === $screen->id ) {
				$this->enqueue_media_input_script();
			}
		}

		/**
		 * Media picker for the Lesson Video field (wp-admin lesson screen and LearnPress Course Builder).
		 */
		public function enqueue_media_input_script() {
			wp_enqueue_script( 'maxcoach-media-input-field', MAXCOACH_THEME_ASSETS_URI . '/admin/js/media-upload.js', array( 'jquery' ), MAXCOACH_THEME_VERSION, true );
		}

		/**
		 * Save theme lesson fields submitted from LearnPress Course Builder.
		 * LearnPress only saves its own keys, then fires this action with the unslashed data.
		 *
		 * @param object $lesson_model LearnPress LessonPostModel.
		 * @param array  $data         Submitted lesson data.
		 */
		public function save_course_builder_lesson_settings( $lesson_model, $data ) {
			if ( ! is_object( $lesson_model ) || empty( $lesson_model->ID ) || ! is_array( $data ) ) {
				return;
			}

			$lesson_id = absint( $lesson_model->ID );

			if ( ! $lesson_id || ! current_user_can( 'edit_post', $lesson_id ) ) {
				return;
			}

			if ( isset( $data[ self::POST_META_VIDEO ] ) && is_string( $data[ self::POST_META_VIDEO ] ) ) {
				update_post_meta( $lesson_id, self::POST_META_VIDEO, esc_url_raw( trim( $data[ self::POST_META_VIDEO ] ) ) );
			}

			if ( Maxcoach_Zoom_Meeting::instance()->is_activated() && isset( $data[ self::POST_META_ZOOM_MEETING ] ) && is_scalar( $data[ self::POST_META_ZOOM_MEETING ] ) ) {
				update_post_meta( $lesson_id, self::POST_META_ZOOM_MEETING, preg_replace( '/[^0-9]/', '', (string) $data[ self::POST_META_ZOOM_MEETING ] ) );
			}
		}

		public function add_lesson_settings( $settings ) {
			// Add new settings.

			$new_settings = [];

			// Ensure the class file is loaded and parent class exists.
			if ( ! class_exists( 'Maxcoach_Meta_Box_File_Input_Field' ) && class_exists( 'LP_Meta_Box_Field' ) ) {
				require_once MAXCOACH_FRAMEWORK_DIR . '/learnpress/admin/meta-box/file-input.php';
			}

			if ( class_exists( 'Maxcoach_Meta_Box_File_Input_Field' ) ) {
				$new_settings[ self::POST_META_VIDEO ] = new Maxcoach_Meta_Box_File_Input_Field(
					esc_html__( 'Lesson Video', 'maxcoach' ),
					esc_html__( 'Please select a video file or paste video url here.', 'maxcoach' ),
					''
				);
			}

			if ( Maxcoach_Zoom_Meeting::instance()->is_activated() ) {
				$new_settings[ self::POST_META_ZOOM_MEETING ] = new LP_Meta_Box_Text_Field(
					esc_html__( 'Zoom Meeting ID', 'maxcoach' ),
					esc_html__( 'Please input zoom meeting id.', 'maxcoach' ),
					''
				);
			}

			$settings = array_merge( $settings, $new_settings );


			return $settings;
		}

		/**
		 * @param LP_Lesson $item
		 */
		public function lesson_video_meta( $item ) {
			echo wp_kses_post( $this->get_lesson_video_meta_html( $item->get_id() ) );
		}

		/**
		 * @param LP_Lesson $item
		 */
		public function lesson_zoom_meeting_meta( $item ) {
			echo wp_kses_post( $this->get_lesson_zoom_meeting_meta_html( $item->get_id() ) );
		}

		/**
		 * Add video, zoom meeting icons of lesson to curriculum item rendered by SingleCourseTemplate.
		 *
		 * @param array    $item_html Components of item html.
		 * @param mixed    $course_model
		 * @param mixed    $user_model
		 * @param stdClass $item      {item_id, item_order, item_type, title, preview}
		 *
		 * @return array
		 */
		public function course_item_meta_icons( $item_html, $course_model, $user_model, $item ) {
			if ( ! is_array( $item_html ) || ! array_key_exists( 'item_right', $item_html ) || ! $item instanceof stdClass ) {
				return $item_html;
			}

			$item_type = $item->item_type ?? $item->type ?? '';

			if ( LP_LESSON_CPT !== $item_type ) {
				return $item_html;
			}

			$item_id = (int) ( $item->item_id ?? $item->id ?? 0 );

			// .course-item__right is row-reverse, first child is displayed last (reading order): duration, video, zoom meeting.
			$meta_html = $this->get_lesson_zoom_meeting_meta_html( $item_id ) . $this->get_lesson_video_meta_html( $item_id );

			if ( '' === $meta_html ) {
				return $item_html;
			}

			$right = (string) $item_html['item_right'];

			// Lesson has no duration, LearnPress doesn't render the right meta box.
			if ( '' === trim( $right ) ) {
				$item_html['item_right'] = '<div class="course-item__right">' . $meta_html . '</div>';

				return $item_html;
			}

			// Put icons at the start of the right meta box (duration), keep attributes other filters may add to its opening tag.
			$open_tag = $this->get_course_item_right_open_tag( $right );

			if ( '' !== $open_tag ) {
				$item_html['item_right'] = $open_tag . $meta_html . substr( $right, strlen( $open_tag ) );
			}

			return $item_html;
		}

		/**
		 * Get opening tag of the right meta box of curriculum item.
		 * Attribute values may be quoted and contain ">" or class-like text, so read the real class attribute.
		 *
		 * @param string $html
		 *
		 * @return string Empty if $html doesn't start with a div has class course-item__right.
		 */
		protected function get_course_item_right_open_tag( $html ) {
			$attr_pattern = '\s+([^\s"\'>\/=]+)(?:\s*=\s*("[^"]*"|\'[^\']*\'|[^\s"\'=<>`]+))?';

			if ( ! preg_match( '/^\s*<div((?:' . $attr_pattern . ')*)\s*>/i', $html, $tag ) ) {
				return '';
			}

			preg_match_all( '/' . $attr_pattern . '/', $tag[1], $attrs, PREG_SET_ORDER );

			foreach ( $attrs as $attr ) {
				// Browser uses the first class attribute, ignores the duplicates.
				if ( 'class' !== strtolower( $attr[1] ) ) {
					continue;
				}

				$value = isset( $attr[2] ) ? $attr[2] : '';

				if ( '' !== $value && in_array( $value[0], array( '"', "'" ), true ) ) {
					$value = substr( $value, 1, -1 );
				}

				// Browser decodes entities before splitting class tokens, e.g. "course-item__right&#32;extra".
				$value = html_entity_decode( $value, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

				return in_array( 'course-item__right', preg_split( '/\s+/', $value, -1, PREG_SPLIT_NO_EMPTY ), true ) ? $tag[0] : '';
			}

			return '';
		}

		/**
		 * @param int $item_id
		 *
		 * @return string
		 */
		protected function get_lesson_video_meta_html( $item_id ) {
			$video = get_post_meta( $item_id, self::POST_META_VIDEO, true );

			$video_host = array(
				'youtube.com',
				'wordpress.tv',
				'vimeo.com',
				'dailymotion.com',
				'hulu.com',
			);

			if ( empty( $video ) || ! Maxcoach_Helper::strposa( $video, $video_host ) ) {
				return '';
			}

			return '<span class="item-meta item-meta-icon video"><i class="far fa-video"></i></span>';
		}

		/**
		 * @param int $item_id
		 *
		 * @return string
		 */
		protected function get_lesson_zoom_meeting_meta_html( $item_id ) {
			if ( ! Maxcoach_Zoom_Meeting::instance()->is_activated() ) {
				return '';
			}

			$zoom_id = get_post_meta( $item_id, self::POST_META_ZOOM_MEETING, true );

			if ( empty( $zoom_id ) ) {
				return '';
			}

			return '<span class="item-meta item-meta-icon zoom-meeting"><i class="far fa-users-class"></i></span>';
		}

		public function entry_video() {
			$item    = LP_Global::course_item();
			$item_id = $item->get_id();

			$video = get_post_meta( $item_id, self::POST_META_VIDEO, true );

			if ( empty( $video ) ) {
				return;
			}

			$video_host = array(
				'youtube.com',
				'wordpress.tv',
				'vimeo.com',
				'dailymotion.com',
				'hulu.com',
			);
			?>
			<div class="entry-lesson-video">
				<?php if ( wp_oembed_get( $video ) ) { ?>
					<div class="embed-responsive-16by9 embed-responsive">
						<?php echo Maxcoach_Helper::w3c_iframe( wp_oembed_get( $video ) ); ?>
					</div>
				<?php } else { ?>
					<video src="<?php echo esc_url( $video ) ?>" controls class="lesson-video"></video>
				<?php } ?>
			</div>
			<?php
		}

		public function entry_zoom_meeting() {
			if ( ! Maxcoach_Zoom_Meeting::instance()->is_activated() ) {
				return;
			}

			$item    = LP_Global::course_item();
			$item_id = $item->get_id();

			$meeting_id = get_post_meta( $item_id, self::POST_META_ZOOM_MEETING, true );
			$meeting_id = is_scalar( $meeting_id ) ? preg_replace( '/[^0-9]/', '', (string) $meeting_id ) : '';

			if ( empty( $meeting_id ) ) {
				return;
			}

			echo '<div class="entry-lesson-zoom-meeting">';
			echo do_shortcode( '[tm_zoom_meeting meeting_id="' . $meeting_id . '"]' );
			echo '</div>';
		}
	}

	Maxcoach_LP_Lesson::instance()->initialize();
}
