<?php
/**
 * Plugin Registration
 *
 * Handles registration and activation of required and recommended plugins for the Maxcoach theme.
 *
 * @package Maxcoach
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Plugin installation and activation for WordPress themes
 */
if ( ! class_exists( 'Maxcoach_Register_Plugins' ) ) {
	/**
	 * Class Maxcoach_Register_Plugins
	 *
	 * Registers required and recommended plugins for the Maxcoach theme using TGM Plugin Activation.
	 *
	 * @since 1.0.0
	 */
	class Maxcoach_Register_Plugins {

		/**
		 * Google Drive API key for plugin downloads.
		 *
		 * @var string
		 */
		const GOOGLE_DRIVER_API = 'AIzaSyDXOs0Bxx-uBEA4fH4fzgoHtl64g0RWv-g';

		/**
		 * Maxcoach_Register_Plugins constructor.
		 *
		 * Register hook for required plugins.
		 */
		public function __construct() {
		add_filter( 'insight_core_tgm_plugins', array( $this, 'register_required_plugins' ) );
	}

	/**
	 * Register required plugins for the theme.
	 *
	 * @param array $plugins Array of plugins to be registered.
	 *
	 * @return array Modified array of plugins.
	 */
	public function register_required_plugins( $plugins ) {
			/*
			 * Array of plugin arrays. Required keys are name and slug.
			 * If the source is NOT from the .org repo, then source is also required.
			 */
			$new_plugins = array(
				array(
					'name'     => esc_html__( 'Insight Core', 'maxcoach' ),
					'slug'     => 'insight-core',
					'source'   => $this->get_plugin_google_driver_url( '1yqn_qJTkbrbRCQQoQgWRIppMLmBx97TO' ),
					'version'  => '2.8.4',
					'required' => true,
				),
				array(
					'name'     => esc_html__( 'Elementor', 'maxcoach' ),
					'slug'     => 'elementor',
					'required' => true,
				),
				array(
					'name'        => 'ThemeMove Addons For Elementor',
					'description' => 'Additional functions for Elementor',
					'slug'        => 'tm-addons-for-elementor',
					'source'      => $this->get_plugin_google_driver_url( '1HPKaI5nUpbMxwDsuqOhnY2uLcXNEHJIT' ),
					'version'     => '2.1.2',
				),
				array(
					'name'    => esc_html__( 'Revolution Slider', 'maxcoach' ),
					'slug'    => 'revslider',
					'source'  => $this->get_plugin_google_driver_url( '1_GX62buCOFsVjm5TG0jwb6-UlZOXrHdM' ),
					'version' => '6.8.0',
				),
				array(
					'name'    => esc_html__( 'LearnPress – WordPress LMS Plugin', 'maxcoach' ),
					'slug'    => 'learnpress',
				),
				array(
					'name' => esc_html__( 'LearnPress – Course Review', 'maxcoach' ),
					'slug' => 'learnpress-course-review',
				),
				array(
					'name' => esc_html__( 'WP Events Manager', 'maxcoach' ),
					'slug' => 'wp-events-manager',
				),
				array(
					'name' => esc_html__( 'Video Conferencing with Zoom', 'maxcoach' ),
					'slug' => 'video-conferencing-with-zoom-api',
				),
				array(
					'name'     => esc_html__( 'Taxonomy Thumbnail', 'maxcoach' ),
					'slug'     => 'sf-taxonomy-thumbnail',
					'required' => true,
				),
				array(
					'name' => esc_html__( 'Contact Form 7', 'maxcoach' ),
					'slug' => 'contact-form-7',
				),
				array(
					'name' => esc_html__( 'MailChimp for WordPress', 'maxcoach' ),
					'slug' => 'mailchimp-for-wp',
				),
				array(
					'name' => esc_html__( 'WooCommerce', 'maxcoach' ),
					'slug' => 'woocommerce',
				),
				array(
					'name' => esc_html__( 'WPC Smart Compare for WooCommerce', 'maxcoach' ),
					'slug' => 'woo-smart-compare',
				),
				array(
					'name' => esc_html__( 'WPC Smart Wishlist for WooCommerce', 'maxcoach' ),
					'slug' => 'woo-smart-wishlist',
				),
				array(
					'name' => esc_html__( 'WP-PostViews', 'maxcoach' ),
					'slug' => 'wp-postviews',
				),
			);

		return array_merge( $plugins, $new_plugins );
	}

	/**
	 * Generate Google Drive download URL for a plugin file.
	 *
	 * @param string $file_id Google Drive file ID.
	 *
	 * @return string Full Google Drive API download URL.
	 */
	public function get_plugin_google_driver_url( $file_id ) {
			return "https://www.googleapis.com/drive/v3/files/{$file_id}?alt=media&key=" . self::GOOGLE_DRIVER_API;
		}
	}

	new Maxcoach_Register_Plugins();
}
