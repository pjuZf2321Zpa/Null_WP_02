<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Maxcoach_Post_Type' ) ) {
	class Maxcoach_Post_Type {
		protected function build_extra_terms_query( $query_args, $taxonomies ) {
			if ( empty( $taxonomies ) ) {
				return $query_args;
			}

			$terms       = explode( ', ', $taxonomies );
			$tax_queries = array(); // List of taxonomies.

			if ( ! isset( $query_args['tax_query'] ) ) {
				$query_args['tax_query'] = array();

				foreach ( $terms as $term ) {
					$tmp       = explode( ':', $term );
					$taxonomy  = $tmp[0];
					$term_slug = $tmp[1];
					if ( ! isset( $tax_queries[ $taxonomy ] ) ) {
						$tax_queries[ $taxonomy ] = array(
							'taxonomy' => $taxonomy,
							'field'    => 'slug',
							'terms'    => array( $term_slug ),
						);
					} else {
						$tax_queries[ $taxonomy ]['terms'][] = $term_slug;
					}
				}
				$query_args['tax_query']             = array_values( $tax_queries );
				$query_args['tax_query']['relation'] = 'AND';
			} else {
				foreach ( $terms as $term ) {
					$tmp       = explode( ':', $term );
					$taxonomy  = $tmp[0];
					$term_slug = $tmp[1];
					$found     = false;

					// Add term to filter clause of same taxonomy, otherwise add new clause (once).
					foreach ( $query_args['tax_query'] as $key => $query ) {
						if ( is_array( $query ) && isset( $query['filter_key'] ) && $query['filter_key'] === $taxonomy ) {
							$query_args['tax_query'][ $key ]['terms'][] = $term_slug;
							$found                                      = true;
							break;
						}
					}

					if ( ! $found ) {
						$query_args['tax_query'][] = array(
							'filter_key' => $taxonomy,
							'taxonomy'   => $taxonomy,
							'field'      => 'slug',
							'terms'      => array( $term_slug ),
						);
					}
				}
			}

			return $query_args;
		}
	}
}
