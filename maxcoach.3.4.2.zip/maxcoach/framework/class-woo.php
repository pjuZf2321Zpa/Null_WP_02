<?php
defined( 'ABSPATH' ) || exit;

/**
 * Custom functions, filters, actions for WooCommerce.
 */
if ( ! class_exists( 'Maxcoach_Woo' ) ) {
	class Maxcoach_Woo extends Maxcoach_Post_Type {

		protected static $instance = null;

		public static $product_image_size_width = '';
		public static $product_image_size_height = '';
		public static $product_image_crop = true;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function define_constants() {
			define( 'MAXCOACH_WOO_DIR', get_template_directory() . DIRECTORY_SEPARATOR . 'woocommerce' );
			define( 'MAXCOACH_WOO_CORE_DIR', MAXCOACH_FRAMEWORK_DIR . DIRECTORY_SEPARATOR . 'woocommerce' );
		}

		public function initialize() {
			$this->define_constants();

			// Do nothing if Woo plugin not activated.
			if ( ! $this->is_activated() ) {
				return;
			}

			require_once MAXCOACH_WOO_CORE_DIR . '/compare.php';

			add_filter( 'maxcoach_custom_css_primary_color_selectors', [ $this, 'custom_css' ] );

			add_filter( 'woocommerce_add_to_cart_fragments', array( $this, 'header_add_to_cart_fragment' ) );

			/**
			 * Move sale price before regular price.
			 */
			add_filter( 'formatted_woocommerce_price', [ $this, 'formatted_woocommerce_price' ], 10, 5 );
			add_filter( 'wc_price', array( $this, 'plain_text_wc_price' ), 10, 3 );

			// WC 10.8+ Review Order page prints its own heading.
			add_filter( 'maxcoach_title_bar_type', array( $this, 'review_order_title_bar_type' ) );

			add_filter( 'woocommerce_get_price_html', [ $this, 'simple_product_price_html' ], 100, 2 );
			add_filter( 'woocommerce_variable_price_html', [ $this, 'product_minmax_price_html' ], 10, 2 );

			/**
			 * Begin hooks for checkout page.
			 */
			add_filter( 'woocommerce_checkout_fields', array( $this, 'override_checkout_fields' ) );
			/**
			 * End hooks for checkout page.
			 */

			add_action( 'wp_head', array( $this, 'wp_init' ) );

			// Move nav count to link.
			add_filter( 'woocommerce_layered_nav_term_html', array(
				$this,
				'move_layered_nav_count_inside_link',
			), 10, 4 );

			/**
			 * Begin hooks for shop archive.
			 */
			add_filter( 'woocommerce_catalog_orderby', array( $this, 'custom_product_sorting' ) );

			add_filter( 'loop_shop_per_page', array( $this, 'loop_shop_per_page' ), 20 );

			add_filter( 'woocommerce_pagination_args', array( $this, 'override_pagination_args' ) );

			// Hide star rating.
			remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );

			// Add link to the product title of loop.
			remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
			add_action( 'woocommerce_shop_loop_item_title', array(
				$this,
				'template_loop_product_title',
			), 10 );
			/**
			 * End hooks for shop archive.
			 */

			/**
			 * Begin hooks for single product.
			 */
			// Move product rating after product price.
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating' );
			add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 15 );

			// Add sharing list.
			add_action( 'woocommerce_share', array( $this, 'entry_sharing' ) );

			// Remove tab heading in on single product pages.
			add_filter( 'woocommerce_product_description_heading', '__return_empty_string' );
			add_filter( 'woocommerce_product_additional_information_heading', '__return_empty_string' );

			// Change review avatar size.
			add_filter( 'woocommerce_review_gravatar_size', array( $this, 'woocommerce_review_gravatar_size' ) );

			// Hide default smart compare & smart wishlist button.
			add_filter( 'woosw_button_position_archive', '__return_zero_string' );
			add_filter( 'woosw_button_position_single', '__return_zero_string' );

			// Add wishlist button again.
			add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'get_wishlist_button_template' ) );

			/**
			 * End hooks for single product.
			 */

			/**
			 * Begin hooks for cart page.
			 */
			// Check for empty-cart get param to clear the cart.
			add_action( 'init', array( $this, 'woocommerce_clear_cart_url' ) );

			/**
			 * Edit cart empty messages.
			 *
			 * Used filter instead action because last item removed ignore empty messages.
			 */
			add_filter( 'wc_empty_cart_message', [ $this, 'change_empty_cart_messages' ] );

			/**
			 * End hook for cart page.
			 */

			/**
			 * Begin ajax requests.
			 */
			// Load more for widget Product.
			add_action( 'wp_ajax_product_infinite_load', array( $this, 'product_infinite_load' ) );
			add_action( 'wp_ajax_nopriv_product_infinite_load', array( $this, 'product_infinite_load' ) );

			// Quick view feature.
			add_action( 'wp_ajax_product_quick_view', array( $this, 'get_quick_view_content' ) );
			add_action( 'wp_ajax_nopriv_product_quick_view', array( $this, 'get_quick_view_content' ) );
			/**
			 * End ajax requests.
			 */

			add_action( 'after_switch_theme', array( $this, 'change_product_image_size' ), 2 );
			add_action( 'after_setup_theme', array( $this, 'modify_theme_support' ), 10 );

			/**
			 * Fix Cart fragments issue with WC 7.8.0
			 */
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_wc_cart_fragments' ), 99 );

			add_action( 'init', array( $this, 'remove_wc_register_blocks' ), 1 );
		}

		/**
		 * This WC action hook make Customize Preview loading freeze.
		 * Temp remove it in customize preview
		 *
		 * @return void
		 */
		public function remove_wc_register_blocks() {
			if ( is_customize_preview() ) {
				maxcoach_remove_filters_for_anonymous_class( 'init', 'Automattic\WooCommerce\Blocks\BlockTypesController', 'register_blocks' );
			}
		}

		public function enqueue_wc_cart_fragments() {
			wp_enqueue_script( 'wc-cart-fragments' );
		}

		/**
		 * Add span tag wrap around decimal separator
		 *
		 * @param $formatted_price
		 * @param $price
		 * @param $number_decimals
		 * @param $decimals_separator
		 * @param $thousand_separator
		 *
		 * @return mixed|string
		 */
		public function formatted_woocommerce_price( $formatted_price, $price, $number_decimals, $decimals_separator, $thousand_separator ) {
			if ( $number_decimals > 0 && ! empty( $decimals_separator ) ) {
				/*
				 * WC trims zeros after this filter, the span below makes it can't match.
				 * Use same function (store decimal separator) so WC trim again changes nothing.
				 */
				if ( apply_filters( 'woocommerce_price_trim_zeros', false ) ) { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WC core hook.
					$formatted_price = wc_trim_zeros( $formatted_price );
				}

				if ( false === strpos( $formatted_price, $decimals_separator ) ) {
					return $formatted_price;
				}

				$origin_price = str_replace( $decimals_separator, '<span class="decimals-separator">' . $decimals_separator, $formatted_price );
				$origin_price .= '</span>';

				return $origin_price;
			}

			return $formatted_price;
		}

		/**
		 * Remove decimals separator span (added by formatted_woocommerce_price()) when wc_price() is asked for plain text.
		 * For eg: WC Store API checkout errors, cost of goods tooltip.
		 *
		 * @param string $price_html Price HTML markup.
		 * @param string $price      Formatted price.
		 * @param array  $args       Price args.
		 *
		 * @return string
		 */
		public function plain_text_wc_price( $price_html, $price = '', $args = array() ) {
			// Older WC doesn't pass in_span, prices are always HTML there.
			if ( isset( $args['in_span'] ) && ! $args['in_span'] && is_string( $price ) && false !== strpos( $price, 'decimals-separator' ) ) {
				$price_html = str_replace( $price, wp_strip_all_tags( $price ), $price_html );
			}

			return $price_html;
		}

		/**
		 * Hide title bar on WC Review Order page (WC 10.8+), its template prints own heading.
		 *
		 * @param string $type Title bar type.
		 *
		 * @return string
		 */
		public function review_order_title_bar_type( $type ) {
			// Respect title bar option of the page.
			if ( ! is_page() || '' !== Maxcoach_Helper::get_post_meta( 'page_title_bar_layout', '' ) ) {
				return $type;
			}

			$page_id = wc_get_page_id( 'review_order' );

			if ( $page_id > 0 && is_page( $page_id ) ) {
				return 'none';
			}

			return $type;
		}

		/**
		 * Check woocommerce plugin active
		 *
		 * @return boolean true if plugin activated
		 */
		function is_activated() {
			if ( class_exists( 'WooCommerce' ) ) {
				return true;
			}

			return false;
		}

		public function custom_css( $selectors ) {
			$selectors['color'][] = "
				.widget_price_filter .ui-slider,
				.maxcoach-product .woocommerce-loop-product__title a:hover,
				.woocommerce .product-badges .onsale,
				.cart-collaterals .order-total .amount,
				.woocommerce-mini-cart__empty-message .empty-basket,
				.woocommerce .cart_list.product_list_widget a:hover,
				.woocommerce .cart.shop_table td.product-name a:hover,
				.woocommerce ul.product_list_widget li .product-title:hover,
				.entry-product-meta a:hover,
				.popup-product-quick-view .product_title a:hover
			";

			$selectors['background-color'][] = "
				.maxcoach-product.style-grid .woocommerce_loop_add_to_cart_wrap a:hover,
				.maxcoach-product.style-grid .quick-view-icon:hover,
				.maxcoach-product.style-grid .woosw-btn:hover,
				.maxcoach-product.style-grid .woosc-btn:hover,
				.wishlist-btn.style-01 a:hover,
				.compare-btn.style-01 a:hover,
				.woocommerce-info, .woocommerce-message,
				.woocommerce-MyAccount-navigation .is-active a,
				.woocommerce-MyAccount-navigation a:hover
			";

			$selectors['border-color'][] = "
				.wishlist-btn.style-01 a:hover,
				.compare-btn.style-01 a:hover,
				body.woocommerce-cart table.cart td.actions .coupon .input-text:focus,
				.woocommerce div.quantity .qty:focus,
				.woocommerce div.quantity button:hover:before,
				.woocommerce.single-product div.product .images .thumbnails .item img:hover
			";

			$selectors['border-bottom-color'][] = "
				.mini-cart .widget_shopping_cart_content,
				.single-product .woocommerce-tabs li.active,
				.woocommerce .select2-container .select2-choice
			";

			return $selectors;
		}

		/**
		 * Show sale price before regular price.
		 * Use display prices (tax setting) + price suffix like WC, keep WC html for product without price.
		 *
		 * @param string     $price
		 * @param WC_Product $product
		 *
		 * @return string
		 */
		public function simple_product_price_html( $price, $product ) {
			if ( ! $product instanceof WC_Product || ! $product->is_type( 'simple' ) || '' === $product->get_price() ) {
				return $price;
			}

			$display_price = wc_get_price_to_display( $product );

			$html_price  = '<p class="price">';
			$html_price .= '<ins>' . ( $display_price > 0 ? wc_price( $display_price ) : esc_html__( 'Free!', 'maxcoach' ) ) . '</ins>';

			if ( $product->is_on_sale() ) {
				$html_price .= '<del>' . wc_price( wc_get_price_to_display( $product, array( 'price' => $product->get_regular_price() ) ) ) . '</del>';
			}

			$html_price .= $product->get_price_suffix();
			$html_price .= '</p>';

			return $html_price;
		}

		/**
		 * @param                     $price
		 * @param WC_Product_Variable $product
		 *
		 * @return string
		 */
		public function product_minmax_price_html( $price, $product ) {
			$variation_min_price         = $product->get_variation_price( 'min', true );
			$variation_max_price         = $product->get_variation_price( 'max', true );
			$variation_min_regular_price = $product->get_variation_regular_price( 'min', true );
			$variation_max_regular_price = $product->get_variation_regular_price( 'max', true );

			if ( ( $variation_min_price == $variation_min_regular_price ) && ( $variation_max_price == $variation_max_regular_price ) ) {
				$html_min_max_price = $price;
			} else {
				$html_price         = '<p class="price">';
				$html_price         .= '<ins>' . $this->price_range_html( $variation_min_price, $variation_max_price ) . '</ins>';
				$html_price         .= '<del>' . $this->price_range_html( $variation_min_regular_price, $variation_max_regular_price ) . '</del>';
				$html_price         .= $product->get_price_suffix();
				$html_price         .= '</p>';
				$html_min_max_price = $html_price;
			}

			return $html_min_max_price;
		}

		/**
		 * @param float|string $min_price
		 * @param float|string $max_price
		 *
		 * @return string Single price when both are same (eg: all variations have same sale price).
		 */
		private function price_range_html( $min_price, $max_price ) {
			if ( (float) $min_price === (float) $max_price ) {
				return wc_price( $min_price );
			}

			return wc_price( $min_price ) . '-' . wc_price( $max_price );
		}

		function woocommerce_clear_cart_url() {
			// Cart is not loaded on admin, cron & REST requests (WC 11.1+ also treats ?rest_route= as REST).
			if ( ! isset( $_GET['empty-cart'] ) || ! WC()->cart instanceof WC_Cart ) {
				return;
			}

			// Action must start with "woocommerce" so WC binds the nonce to the guest session.
			$nonce = isset( $_GET['_wpnonce'] ) && is_string( $_GET['_wpnonce'] ) ? sanitize_key( wp_unslash( $_GET['_wpnonce'] ) ) : '';

			if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'woocommerce-cart' ) ) {
				return;
			}

			WC()->cart->empty_cart();

			wp_safe_redirect( wc_get_cart_url() );
			exit;
		}

		function change_empty_cart_messages() {
			?>
			<div class="empty-cart-messages">
				<div class="empty-cart-icon">
					<span class="fal fa-shopping-cart"></span>
				</div>
				<h2 class="empty-cart-heading"><?php esc_html_e( 'Your cart is currently empty.', 'maxcoach' ); ?></h2>
				<p class="empty-cart-text"><?php esc_html_e( 'You may check out all the available products and buy some in the shop.', 'maxcoach' ); ?></p>
			</div>
			<?php
			// WC passes the returned message to wp_kses_post(), null is deprecated on PHP 8.1+.
			return '';
		}

		function entry_sharing() {
			if ( Maxcoach::setting( 'single_product_sharing_enable' ) === '1' && class_exists( 'InsightCore' ) ) :
				$social_sharing = Maxcoach::setting( 'social_sharing_item_enable' );
				if ( ! empty( $social_sharing ) ) {
					?>
					<div class="entry-product-share">
						<h6><?php esc_html_e( 'Share:', 'maxcoach' ); ?></h6>
						<div class="inner">
							<?php Maxcoach_Templates::get_sharing_list(); ?>
						</div>
					</div>
					<?php
				}
			endif;
		}

		/*
		 * Change woocommerce product image size on first time switch to this theme.
		 */
		public function change_product_image_size() {
			global $pagenow;

			if ( ! isset( $_GET['activated'] ) || $pagenow != 'themes.php' ) {
				return;
			}

			$count = get_option( 'maxcoach_switch_theme_count' );

			// Do it for first time.
			if ( ! $count || $count < 2 ) {
				// Update single image width
				//update_option( 'woocommerce_single_image_width', 760 );

				// Update thumbnail image width.
				update_option( 'woocommerce_thumbnail_image_width', 480 );

				// Update thumbnail cropping ratio.
				update_option( 'woocommerce_thumbnail_cropping', 'custom' );
				update_option( 'woocommerce_thumbnail_cropping_custom_width', 4 );
				update_option( 'woocommerce_thumbnail_cropping_custom_height', 5 );
			}
		}

		/**
		 * Modify image width theme support.
		 */
		function modify_theme_support() {
			/*$theme_support                          = get_theme_support( 'woocommerce' );
			$theme_support                          = is_array( $theme_support ) ? $theme_support[0] : array();
			$theme_support['single_image_width']    = 760;
			$theme_support['thumbnail_image_width'] = 400;

			remove_theme_support( 'woocommerce' );*/
			add_theme_support( 'woocommerce' );
		}

		/**
		 * Returns true if on a page which uses WooCommerce templates exclude single product (cart and checkout are standard pages with shortcodes and which are also included)
		 *
		 * @access public
		 * @return bool
		 */
		function is_woocommerce_page_without_product() {
			if ( function_exists( 'is_shop' ) && is_shop() ) {
				return true;
			}

			if ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) {
				return true;
			}

			if ( is_post_type_archive( 'product' ) ) {
				return true;
			}

			$the_id = get_the_ID();

			if ( $the_id !== false ) {
				$woocommerce_keys = array(
					'woocommerce_shop_page_id',
					'woocommerce_terms_page_id',
					'woocommerce_cart_page_id',
					'woocommerce_checkout_page_id',
					'woocommerce_pay_page_id',
					'woocommerce_thanks_page_id',
					'woocommerce_myaccount_page_id',
					'woocommerce_edit_address_page_id',
					'woocommerce_view_order_page_id',
					'woocommerce_change_password_page_id',
					'woocommerce_logout_page_id',
					'woocommerce_lost_password_page_id',
				);

				foreach ( $woocommerce_keys as $wc_page_id ) {
					if ( $the_id == get_option( $wc_page_id, 0 ) ) {
						return true;
					}
				}
			}

			return false;
		}

		/**
		 * Returns true if on a page which uses WooCommerce templates (cart and checkout are standard pages with shortcodes and which are also included)
		 *
		 * @access public
		 * @return bool
		 */
		function is_woocommerce_page() {
			if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
				return true;
			}

			$woocommerce_keys = array(
				"woocommerce_shop_page_id",
				"woocommerce_terms_page_id",
				"woocommerce_cart_page_id",
				"woocommerce_checkout_page_id",
				"woocommerce_pay_page_id",
				"woocommerce_thanks_page_id",
				"woocommerce_myaccount_page_id",
				"woocommerce_edit_address_page_id",
				"woocommerce_view_order_page_id",
				"woocommerce_change_password_page_id",
				"woocommerce_logout_page_id",
				"woocommerce_lost_password_page_id",
			);

			foreach ( $woocommerce_keys as $wc_page_id ) {
				if ( get_the_ID() == get_option( $wc_page_id, 0 ) ) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Returns true if on a archive product pages.
		 *
		 * @access public
		 * @return bool
		 */
		function is_product_archive() {
			if ( is_post_type_archive( 'product' ) || ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) ) {
				return true;
			}

			return false;
		}

		/**
		 * Custom product title instead of default product title
		 *
		 * @see woocommerce_template_loop_product_title()
		 */
		function template_loop_product_title() {
			?>
			<h2 class="woocommerce-loop-product__title">
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</h2>
			<?php
		}

		function loop_shop_per_page() {
			if ( isset( $_GET['shop_archive_preset'] ) && in_array( $_GET['shop_archive_preset'], [
					'left-sidebar',
					'right-sidebar',
				] ) ) {
				// Hard set post per page. because override preset settings run after init hook.
				$number = 9;
			} else {
				$number = Maxcoach::setting( 'shop_archive_number_item' );
			}

			if ( isset( $_GET['product_per_page'] ) && is_scalar( $_GET['product_per_page'] ) ) {
				$per_page = (int) $_GET['product_per_page'];

				// Don't let visitors load unlimited products.
				if ( $per_page > 0 ) {
					return min( $per_page, (int) apply_filters( 'maxcoach_max_products_per_page', 100 ) );
				}
			}

			return $number;
		}

		function override_pagination_args( $args ) {
			$args['prev_text'] = Maxcoach_Templates::get_pagination_prev_text();
			$args['next_text'] = Maxcoach_Templates::get_pagination_next_text();

			return $args;
		}

		function woocommerce_review_gravatar_size() {
			return Maxcoach::COMMENT_AVATAR_SIZE;
		}

		function wp_init() {
			if ( Maxcoach::setting( 'single_product_tabs_enable' ) === '0' ) {
				remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
			}

			if ( Maxcoach::setting( 'single_product_up_sells_enable' ) === '0' ) {
				remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
			}

			if ( Maxcoach::setting( 'single_product_related_enable' ) === '0' ) {
				remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
			}

			// Remove Cross Sells from default position at Cart. Then add them back UNDER the Cart Table.
			remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
			if ( Maxcoach::setting( 'shopping_cart_cross_sells_enable' ) === '1' ) {
				add_action( 'woocommerce_after_cart_table', 'woocommerce_cross_sell_display' );
			}

			if ( Maxcoach::setting( 'shop_archive_sorting' ) !== '1' ) {
				remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
				remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
			} else {
				add_action( 'woocommerce_before_shop_loop', [ $this, 'add_shop_action_begin_wrapper' ], 15 );
				add_action( 'woocommerce_before_shop_loop', [ $this, 'add_shop_action_end_wrapper' ], 35 );
			}
		}

		function add_shop_action_begin_wrapper() {
			echo '<div class="archive-shop-actions row row-xs-center">';
		}

		function add_shop_action_end_wrapper() {
			echo '</div>';
		}

		public function custom_product_sorting( $sorting_options ) {
			if ( isset( $sorting_options['menu_order'] ) ) {
				$sorting_options['menu_order'] = esc_html__( 'Default', 'maxcoach' );
			}

			if ( isset( $sorting_options['popularity'] ) ) {
				$sorting_options['popularity'] = esc_html__( 'Popularity', 'maxcoach' );
			}

			if ( isset( $sorting_options['rating'] ) ) {
				$sorting_options['rating'] = esc_html__( 'Average rating', 'maxcoach' );
			}

			if ( isset( $sorting_options['date'] ) ) {
				$sorting_options['date'] = esc_html__( 'Latest', 'maxcoach' );
			}

			if ( isset( $sorting_options['price'] ) ) {
				$sorting_options['price'] = esc_html__( 'Price: low to high', 'maxcoach' );
			}

			if ( isset( $sorting_options['price-desc'] ) ) {
				$sorting_options['price-desc'] = esc_html__( 'Price: high to low', 'maxcoach' );
			}

			return $sorting_options;
		}

		/**
		 * Add placeholder for all fields.
		 *
		 * @param $fields
		 *
		 * @return mixed
		 */
		function override_checkout_fields( $fields ) {
			// Add placeholder for billing form.
			foreach ( $fields['billing'] as $field => $value ) {
				// If has label & not has placeholder.
				if ( ! empty( $fields['billing'][ $field ]['label'] ) && empty( $fields['billing'][ $field ]['placeholder'] ) ) {
					$fields['billing'][ $field ]['placeholder'] = $fields['billing'][ $field ]['label'];
				}
			}

			// Add placeholder for shipping form.
			foreach ( $fields['shipping'] as $field => $value ) {
				// If has label & not has placeholder.
				if ( ! empty( $fields['shipping'][ $field ]['label'] ) && empty( $fields['shipping'][ $field ]['placeholder'] ) ) {
					$fields['shipping'][ $field ]['placeholder'] = $fields['shipping'][ $field ]['label'];
				}
			}

			return $fields;
		}

		/**
		 * Ensure cart contents update when products are added to the cart via AJAX
		 * ========================================================================
		 *
		 * @param $fragments
		 *
		 * @return mixed
		 */
		function header_add_to_cart_fragment( $fragments ) {
			ob_start();
			$cart_html = $this->get_mini_cart();
			echo '' . $cart_html;
			$fragments['.mini-cart__button'] = ob_get_clean();

			return $fragments;
		}

		/**
		 * Get mini cart HTML
		 * ==================
		 *
		 * @return string
		 */
		function get_mini_cart() {
			global $woocommerce;
			$cart_url = '/cart';
			if ( isset( $woocommerce ) ) {
				$cart_url = wc_get_cart_url();
			}

			$cart_html = '';
			$qty       = WC()->cart->get_cart_contents_count();
			$cart_html .= '<a href="' . esc_url( $cart_url ) . '" class="mini-cart__button header-icon" title="' . esc_attr__( 'View your shopping cart', 'maxcoach' ) . '">';
			$cart_html .= '<span class="mini-cart-icon" data-count="' . $qty . '"></span>';
			$cart_html .= '</a>';

			return $cart_html;
		}

		function render_mini_cart() {
			$header_type = Maxcoach_Global::instance()->get_header_type();

			$enabled = Maxcoach::setting( "header_style_{$header_type}_cart_enable" );

			if ( $this->is_activated() && in_array( $enabled, array( '1', 'hide_on_empty' ) ) ) {
				$classes = 'mini-cart';
				if ( $enabled === 'hide_on_empty' ) {
					$classes .= ' hide-on-empty';
				}
				?>
				<div id="mini-cart" class="<?php echo esc_attr( $classes ); ?>">
					<?php echo '' . $this->get_mini_cart(); ?>
					<div class="widget_shopping_cart_content"></div>
				</div>
			<?php }
		}

		/**
		 * @return string
		 */
		function get_percentage_price() {
			global $product;

			if ( $product->is_type( 'simple' ) || $product->is_type( 'external' ) ) {
				$_regular_price = $product->get_regular_price();
				$_sale_price    = $product->get_sale_price();

				$percentage = round( ( ( $_regular_price - $_sale_price ) / $_regular_price ) * 100 );

				return "-{$percentage}%";
			} else {
				return esc_html__( 'Sale !', 'maxcoach' );
			}
		}

		function get_wishlist_button_template( $args = array() ) {
			if ( ( Maxcoach::setting( 'shop_archive_wishlist' ) !== '1' ) || ! class_exists( 'WPcleverWoosw' ) ) {
				return;
			}

			global $product;
			$product_id = $product->get_id();

			$defaults = array(
				'show_tooltip'     => true,
				'tooltip_position' => 'top',
				'tooltip_skin'     => 'primary',
				'style'            => '01',
			);
			$args     = wp_parse_args( $args, $defaults );

			$_wrapper_classes = "product-action wishlist-btn style-{$args['style']}";

			if ( $args['show_tooltip'] === true ) {
				$_wrapper_classes .= ' hint--bounce';
				$_wrapper_classes .= " hint--{$args['tooltip_position']}";
				$_wrapper_classes .= " hint--{$args['tooltip_skin']}";
			}
			?>
			<div class="<?php echo esc_attr( $_wrapper_classes ); ?>"
			     aria-label="<?php esc_attr_e( 'Add to wishlist', 'maxcoach' ) ?>">
				<?php echo do_shortcode( '[woosw id="' . $product_id . '" type="link"]' ); ?>
			</div>
			<?php
		}

		function get_compare_button_template( $args = array() ) {
			if ( Maxcoach::setting( 'shop_archive_compare' ) !== '1' || wp_is_mobile() || ! class_exists( 'WPCleverWoosc' ) ) {
				return;
			}

			global $product;
			$product_id = $product->get_id();

			$defaults = array(
				'show_tooltip'     => true,
				'tooltip_position' => 'top',
				'tooltip_skin'     => 'primary',
				'style'            => '01',
			);
			$args     = wp_parse_args( $args, $defaults );

			$_wrapper_classes = "product-action compare-btn style-{$args['style']}";

			if ( $args['show_tooltip'] === true ) {
				$_wrapper_classes .= ' hint--bounce';
				$_wrapper_classes .= " hint--{$args['tooltip_position']}";
				$_wrapper_classes .= " hint--{$args['tooltip_skin']}";
			}
			?>
			<div class="<?php echo esc_attr( $_wrapper_classes ); ?>"
			     aria-label="<?php esc_attr_e( 'Compare', 'maxcoach' ) ?>">
				<?php echo do_shortcode( '[woosc id="' . $product_id . '" type="link"]' ); ?>
			</div>
			<?php
		}

		function get_quick_view_button_template( $args = array() ) {
			if ( ( Maxcoach::setting( 'shop_archive_quick_view' ) !== '1' ) || wp_is_mobile() ) {
				return;
			}

			global $product;
			$product_id = $product->get_id();

			$defaults = array(
				'show_tooltip'     => true,
				'tooltip_position' => 'top',
				'tooltip_skin'     => 'primary',
				'style'            => '01',
			);
			$args     = wp_parse_args( $args, $defaults );

			$_wrapper_classes = "product-action quick-view-btn style-{$args['style']}";

			if ( $args['show_tooltip'] === true ) {
				$_wrapper_classes .= ' hint--bounce';
				$_wrapper_classes .= " hint--{$args['tooltip_position']}";
				$_wrapper_classes .= " hint--{$args['tooltip_skin']}";
			}
			?>
			<div class="<?php echo esc_attr( $_wrapper_classes ); ?>"
			     aria-label="<?php echo esc_attr__( 'Quick view', 'maxcoach' ) ?>"
			     data-pid="<?php echo esc_attr( $product_id ); ?>"
			     data-pnonce="<?php echo wp_create_nonce( 'woo_quick_view' ); ?>">
				<a class="quick-view-icon" href="#"></a>
			</div>
			<?php
		}

		public function get_quick_view_content() {
			check_ajax_referer( 'woo_quick_view', 'security' );

			$product_id  = isset( $_REQUEST['pid'] ) ? absint( $_REQUEST['pid'] ) : 0;
			$post_object = $product_id ? get_post( $product_id ) : null;

			// Only products visitor can see on single product page.
			if ( ! $post_object instanceof WP_Post
				|| 'product' !== $post_object->post_type
				|| ( 'publish' !== $post_object->post_status && ! current_user_can( 'read_post', $product_id ) )
				|| post_password_required( $post_object )
			) {
				wp_send_json_error( null, 404 );
			}

			$GLOBALS['post'] = $post_object; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			setup_postdata( $post_object );

			ob_start();
			wc_get_template_part( 'content', 'quick-view' );
			$response = array(
				'template' => ob_get_clean(),
			);

			wp_send_json( $response );
		}

		public function product_infinite_load() {
			check_ajax_referer( 'maxcoach_ajax', 'security' );

			// Query vars are signed by server (Maxcoach_Helper::get_grid_query_signed_data()).
			$query_vars = Maxcoach_Helper::get_ajax_query_vars( 'product' );

			if ( ! empty( $query_vars['extra_tax_query'] ) ) {
				$query_vars = $this->build_extra_terms_query( $query_vars, $query_vars['extra_tax_query'] );
			}

			unset( $query_vars['extra_tax_query'] );

			$query_vars['tax_query'] = $this->add_product_visibility_tax_query( isset( $query_vars['tax_query'] ) ? $query_vars['tax_query'] : array(), ! empty( $query_vars['s'] ) );

			// Shop sorting by price, popularity, rating (Current Query) uses posts_clauses filters WC only adds for main query.
			$wc_orderby  = isset( $query_vars['orderby'] ) && is_string( $query_vars['orderby'] ) ? $query_vars['orderby'] : '';
			$wc_ordering = in_array( $wc_orderby, array( 'price', 'popularity', 'rating' ), true ) && WC()->query instanceof WC_Query;

			if ( $wc_ordering ) {
				$ordering_args = WC()->query->get_catalog_ordering_args( $wc_orderby, isset( $query_vars['order'] ) ? $query_vars['order'] : '' );

				$query_vars['orderby'] = $ordering_args['orderby'];
				$query_vars['order']   = $ordering_args['order'];

				if ( ! empty( $ordering_args['meta_key'] ) ) {
					$query_vars['meta_key'] = $ordering_args['meta_key']; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				}
			}

			$maxcoach_query = new WP_Query( $query_vars );

			if ( $wc_ordering ) {
				WC()->query->remove_ordering_args();
			}

			$response = Maxcoach_Helper::get_ajax_query_response( $maxcoach_query );

			ob_start();

			if ( $maxcoach_query->have_posts() ) :

				while ( $maxcoach_query->have_posts() ) : $maxcoach_query->the_post();
					wc_get_template_part( 'content', 'product' );
				endwhile;

				wp_reset_postdata();

			endif;

			$template = ob_get_clean();
			$template = preg_replace( '~>\s+<~', '><', $template );

			$response['template'] = $template;

			wp_send_json_success( $response );
		}

		/**
		 * Exclude products hidden from catalog (or search) and out of stock products (if hidden by WC settings)
		 * like WC main product query does.
		 *
		 * @param array $tax_query Current tax query.
		 * @param bool  $is_search Search results query.
		 *
		 * @return array
		 */
		public function add_product_visibility_tax_query( $tax_query, $is_search = false ) {
			$tax_query = is_array( $tax_query ) ? $tax_query : array();

			if ( ! function_exists( 'wc_get_product_visibility_term_ids' ) ) {
				return $tax_query;
			}

			$visibility_terms = wc_get_product_visibility_term_ids();
			$exclude_terms    = array( $is_search ? $visibility_terms['exclude-from-search'] : $visibility_terms['exclude-from-catalog'] );

			if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
				$exclude_terms[] = $visibility_terms['outofstock'];
			}

			$exclude_terms = array_values( array_filter( $exclude_terms ) );

			if ( empty( $exclude_terms ) ) {
				return $tax_query;
			}

			$visibility_query = array(
				'taxonomy' => 'product_visibility',
				'field'    => 'term_taxonomy_id',
				'terms'    => $exclude_terms,
				'operator' => 'NOT IN',
			);

			if ( empty( $tax_query ) ) {
				return array( $visibility_query );
			}

			// Nest current query to keep its own relation.
			return array(
				'relation' => 'AND',
				$tax_query,
				$visibility_query,
			);
		}

		function get_product_image( $args = array() ) {
			$defaults = array(
				'extra_class' => '',
			);

			$args = wp_parse_args( $args, $defaults );

			// Calculate product loop image size.
			if ( self::$product_image_size_width === '' ) {
				$width = 400;

				$shop_layout = Maxcoach::setting( 'shop_archive_layout' );
				if ( 'wide' === $shop_layout ) {
					$width = 540;
				}

				$cropping = get_option( 'woocommerce_thumbnail_cropping' );
				$height   = $width;

				if ( $cropping === 'custom' ) {
					// Empty or 0 ratio (not saved yet or cleared by merchant) causes division by zero.
					$ratio_w = max( 1, (float) get_option( 'woocommerce_thumbnail_cropping_custom_width', 4 ) );
					$ratio_h = max( 1, (float) get_option( 'woocommerce_thumbnail_cropping_custom_height', 3 ) );

					$height = ( $width * $ratio_h ) / $ratio_w;
					$height = (int) $height;
				} elseif ( $cropping === 'uncropped' ) {
					self::$product_image_crop = false;
					$height                   = 9999;
				}

				self::$product_image_size_width  = $width;
				self::$product_image_size_height = $height;
			}

			$image_args = array(
				'id'     => $args['id'],
				'size'   => 'custom',
				'width'  => self::$product_image_size_width,
				'height' => self::$product_image_size_height,
				'crop'   => self::$product_image_crop,
			);

			if ( $args['extra_class'] !== '' ) {
				$image_args['class'] = $args['extra_class'];
			}

			Maxcoach_Image::the_attachment_by_id( $image_args );
		}

		function move_layered_nav_count_inside_link( $term_html, $term, $link, $count ) {
			if ( $count > 0 ) {
				$term_html = str_replace( '</a>', '', $term_html );
				$term_html = str_replace( '</span>', '</span></a>', $term_html );
			}

			return $term_html;
		}

		/**
		 * @param int $product_id Read the option from this product instead of current page options.
		 *
		 * @return string
		 */
		public function get_single_product_style( $product_id = 0 ) {
			if ( $product_id ) {
				$product_options = maybe_unserialize( get_post_meta( $product_id, 'insight_product_options', true ) );
				$style           = Maxcoach_Helper::get_the_post_meta( $product_options, 'single_product_layout_style' );
			} else {
				$style = Maxcoach_Helper::get_post_meta( 'single_product_layout_style' );
			}

			if ( empty( $style ) ) {
				$style = Maxcoach::setting( 'single_product_layout_style' );
			}

			return $style;
		}
	}

	Maxcoach_Woo::instance()->initialize();
}
