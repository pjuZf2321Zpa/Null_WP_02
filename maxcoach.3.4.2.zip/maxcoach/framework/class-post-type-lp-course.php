<?php

use LearnPress\TemplateHooks\Course\SingleCourseTemplate;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Maxcoach_LP_Course' ) ) {
	class Maxcoach_LP_Course extends Maxcoach_Post_Type {

		protected static $instance = null;
		const POST_TYPE            = 'lp_course';
		const TAXONOMY_CATEGORY    = 'course_category';
		const TAXONOMY_TAGS        = 'course_tag';
		const POST_META_STUDENTS   = '_lp_students';
		const POST_META_PRICE      = '_lp_price';
		const POST_META_SALE_PRICE = '_lp_sale_price';

		/**
		 * "No enrollment requirement" course option (LearnPress\Models\CoursePostModel::META_KEY_NO_REQUIRED_ENROLL).
		 */
		const POST_META_NO_REQUIRED_ENROLL = '_lp_no_required_enroll';

		/**
		 * custom post meta, used for ordering on archive pages.
		 */
		const CUSTOM_POST_META_SORT_PRICE = '_lp_sort_price';


		/**
		 * Oldest LearnPress version tested with hooks used by the theme (TGMPA recommends the latest one).
		 */
		const MINIMUM_LEARNPRESS_VERSION = '4.4.6';

		const MINIMUM_TM_PAYMENT_VERSION = '1.2.0';

		/**
		 * Theme version whose data update (course sort price re-sync) must run, see maxcoach_update_db().
		 * 2.5.2: sort price meta added. 3.4.1: "No enrollment requirement" courses are free on LearnPress 4.4.11.
		 */
		const DB_VERSION = '3.4.1';

		/**
		 * Password strength rules already printed by theme register form.
		 *
		 * @var bool
		 */
		private $password_strength_description_printed = false;

		/**
		 * Content importer is running (import_start - import_end).
		 *
		 * @var bool
		 */
		private $is_importing = false;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			if ( ! $this->is_activated() ) {
				return;
			}

			if ( version_compare( LEARNPRESS_VERSION, self::MINIMUM_LEARNPRESS_VERSION, '<' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_learnpress_version' ] );
			}

			if ( defined( 'TM_ADDON_PAYMENT_VER' ) && version_compare( TM_ADDON_PAYMENT_VER, self::MINIMUM_TM_PAYMENT_VERSION, '<' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_tm_payment_version' ] );
			}

			$maxcoach_db_version = get_option( 'maxcoach_db_version' );
			if ( empty( $maxcoach_db_version ) || version_compare( $maxcoach_db_version, self::DB_VERSION, '<' ) ) {
				add_action( 'admin_notices', [ $this, 'update_db_252' ] );

				add_action( 'admin_init', [ $this, 'maxcoach_update_db' ] );
			}

			add_filter( 'learn-press/override-templates', '__return_true', 9999 );
			add_filter( 'learn-press/enable-cart', '__return_true', 9999 );

			/**
			 * Force offline courses to use the theme's legacy single course template.
			 *
			 * Since LP 4.x, an "offline" course is routed by LearnPress to its own
			 * component template (`single-course-offline.php` => SingleCourseOfflineTemplate),
			 * which bypasses ALL of the theme's single-course overrides and hooks even when
			 * `single-course.php` is overridden. That renders an unstyled layout (and even
			 * duplicates the theme title bar + breadcrumb). Route offline courses back to the
			 * legacy `single-course.php` so the MaxCoach single course design applies, same as
			 * online courses.
			 *
			 * @see LP_Page_Controller::get_page_template()
			 */
			add_filter( 'learn-press/page-template', [ $this, 'use_theme_template_for_offline_course' ] );

			/**
			 * Fix Course Membership Levels not render properly make save not working.
			 */
			add_action( 'lp_course_data_setting_tab_content', [ $this, 'fix_course_data_settings_not_saved' ], -1 );

			$this->change_single_components();

			$this->change_archive_components();

			$this->change_profile_components();

			/**
			 * Add more setting for password on register form.
			 */
			add_filter( 'lp/settings/profile', [ $this, 'add_user_profile_password_settings' ], 10, 1 );
			add_action( 'learn-press/update-settings/updated', array( $this, 'update_instructor_event_caps' ) );

			/**
			 * Password strength settings, validated on LearnPress register (Profile & Checkout).
			 *
			 * @see LP_Forms_Handler::learnpress_create_new_customer()
			 */
			add_action( 'lp/before_create_new_customer', array( $this, 'validate_register_password_strength' ), 10, 3 );
			// Before LearnPress extra fields (priority 10), right after the password fields.
			add_action( 'learn-press/after-form-register-fields', array( $this, 'register_password_strength_description' ), 5 );

			add_filter( 'learn_press_course_price_html_free', [ $this, 'change_course_free_price' ], 99, 2 );
			add_filter( 'learn-press/course/regular-price-html', [ $this, 'add_wrapper_decimals_separator' ], 99, 1 ); // LP >= 4.2.6.9.
			// LP 4.1.5 - 4.2.6.8.2 has no usable regular-price hook; the filter below covers the full
			// price html on every LP 4.x version (the callback is idempotent, so double runs are safe).
			add_filter( 'learn_press_course_price_html', [ $this, 'add_wrapper_decimals_separator' ], 99, 1 );

			add_filter( 'maxcoach_sidebar_1', [ $this, 'remove_sidebar_for_sticky_layout' ] );

			add_action( 'maxcoach/title-bar-meta', [ $this, 'add_title_bar_meta_course_instructor' ] );
			add_action( 'maxcoach/title-bar-meta', [ $this, 'add_title_bar_meta_course_duration' ] );
			add_action( 'maxcoach/title-bar-meta', [ $this, 'add_title_bar_meta_course_lesson' ] );
			add_action( 'maxcoach/title-bar-meta', [ $this, 'add_title_bar_meta_course_student' ] );

			// Remove learn paid membership css.
			add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ], 99 );

			add_filter( 'learn-press/frontend-default-styles', [ $this, 'change_plugin_style' ], 9999 );
			add_action( 'elementor/frontend/before_enqueue_scripts', [ $this, 'enqueue_frontend_scripts' ], 9999 );

			add_filter( 'lp/course/meta-box/fields/general', [ $this, 'add_fields_to_meta_box' ] );

			// Save theme course fields submitted from LearnPress Course Builder.
			add_action( 'learn-press/course-builder/save-course-settings', array( $this, 'save_course_builder_course_settings' ), 10, 2 );

			// LearnPress single course layout option has no effect with the theme templates.
			add_filter( 'learn-press/course-settings-fields/general', array( $this, 'add_single_course_layout_setting_note' ) );

			// Adds custom classes to the array of body classes.
			add_filter( 'body_class', [ $this, 'body_classes' ] );

			// LearnPress buttons outside course pages (profile, checkout, order received) use theme button colors.
			add_filter( 'maxcoach_customize_output_button_selectors', array( $this, 'customize_output_button_selectors' ) );
			add_filter( 'maxcoach_customize_output_button_hover_selectors', array( $this, 'customize_output_button_hover_selectors' ) );

			add_action( 'wp_ajax_lp_course_infinite_load', [ $this, 'infinite_load' ] );
			add_action( 'wp_ajax_nopriv_lp_course_infinite_load', [ $this, 'infinite_load' ] );

			// Same numeric sorting for first page of course grids as ajax pagination.
			add_filter( 'maxcoach_elementor_grid_query_args', array( $this, 'elementor_grid_query_args' ), 10, 2 );

			/**
			 * Add course meta price sort.
			 * Used priority 9999 to sure run after cmb2 plugin, make sure post meta saved.
			 */
			add_action( 'learnpress_save_lp_course_metabox', [ $this, 'save_course_sale_price' ], 9999 );

			/**
			 * Keep sort price in sync when LearnPress saves price outside the course edit screen
			 * (Course Builder, REST, setup wizard demo courses, imports).
			 */
			add_action( 'added_post_meta', array( $this, 'sync_course_sort_price' ), 10, 3 );
			add_action( 'updated_post_meta', array( $this, 'sync_course_sort_price' ), 10, 3 );
			add_action( 'wp_after_insert_post', array( $this, 'add_missing_course_sort_price' ), 20, 2 );
			add_action( 'import_start', array( $this, 'on_import_start' ) );
			add_action( 'import_end', array( $this, 'on_import_end' ) );

			// LearnPress widget areas are not displayed by the theme templates, use theme sidebars instead.
			add_action( 'widgets_init', array( $this, 'unregister_learnpress_sidebars' ), 99 );

			// Change button back to class style.
			add_action( 'learn-press/after-checkout-form', [ $this, 'back_to_class_button' ], 25 );
			add_action( 'learn-press/after-empty-cart-message', [ $this, 'back_to_class_button' ] );

			/**
			 * @see LP_Profile::get_profile_picture()
			 */
			add_filter( 'learn-press/user-profile/avatar', [ $this, 'maxcoach_fix_lp_gvatar_blurry' ], 9999, 3 );
		}

		public function maxcoach_fix_lp_gvatar_blurry( $img, $avatar_url, $args ) {
			if ( str_contains( $img, 'gravatar.com' ) && str_contains( $img, 's=96' ) ) {
				$img = str_replace( 's=96', 's=' . $args['width'], $img );
			}

			return $img;
		}

		public function admin_notice_minimum_learnpress_version() {
			maxcoach_notice_required_plugin_version( 'LearnPress', self::MINIMUM_LEARNPRESS_VERSION );
		}

		public function admin_notice_minimum_tm_payment_version() {
			maxcoach_notice_required_plugin_version( 'Thememove Payment Add-ons for LearnPress', self::MINIMUM_TM_PAYMENT_VERSION );
		}

		function fix_course_data_settings_not_saved() {
			global $thepostid, $post;

			$thepostid = empty( $thepostid ) ? $post->ID : $thepostid;
		}

		/**
		 * Translate the Free price text with theme text domain.
		 * Keep LearnPress markup (origin price of courses on sale to free).
		 *
		 * @param string $text   Free price html.
		 * @param mixed  $course Course.
		 *
		 * @return string
		 */
		public function change_course_free_price( $text, $course ) {
			$label = esc_html__( 'Free', 'maxcoach' );

			if ( ! is_string( $text ) || false === strpos( $text, 'class="free"' ) ) {
				return $label;
			}

			return preg_replace_callback(
				'#(<span class="free">).*?(</span>)#s',
				function ( $matches ) use ( $label ) {
					return $matches[1] . $label . $matches[2];
				},
				$text
			);
		}

		public function back_to_class_button() {
			$courses_link = learn_press_get_page_link( 'courses' );
			if ( ! $courses_link ) {
				return;
			}

			Maxcoach_Templates::render_button( [
				'link'          => [
					'url' => esc_url( $courses_link ),
				],
				'text'          => esc_html__( 'Back to class', 'maxcoach' ),
				'icon'          => 'fal fa-long-arrow-left',
				'wrapper_class' => 'btn-back-to-class',
			] );
			?>
			<?php
		}

		/**
		 * Password strength rules enabled in LearnPress > Settings > Profile.
		 *
		 * @return array Rule key => array( pattern, error message, description ).
		 */
		public function get_password_strength_rules() {
			$rules = array();

			if ( 'yes' === LP()->settings->get( 'enable_password_capitalized_letter', 'yes' ) ) {
				$rules['capitalized'] = array(
					'pattern'     => '#[A-Z]+#',
					'error'       => __( 'Password must include at least one capitalized letter!', 'maxcoach' ),
					'description' => __( 'at least one capitalized letter', 'maxcoach' ),
				);
			}

			if ( 'yes' === LP()->settings->get( 'enable_password_number', 'yes' ) ) {
				$rules['number'] = array(
					'pattern'     => '#[0-9]+#',
					'error'       => __( 'Password must include at least one number!', 'maxcoach' ),
					'description' => __( 'at least one number', 'maxcoach' ),
				);
			}

			if ( 'yes' === LP()->settings->get( 'enable_password_special_character', 'yes' ) ) {
				$rules['special_char'] = array(
					'pattern'     => '#[~!@\#$%^&*()]#',
					'error'       => __( 'Password must include at least one of these characters ~!@#$%^&*() !', 'maxcoach' ),
					'description' => __( 'at least one of these characters ~!@#$%^&*()', 'maxcoach' ),
				);
			}

			return $rules;
		}

		/**
		 * Validate password strength on LearnPress register (Profile & Checkout).
		 * LearnPress shows the exception message as register error.
		 *
		 * @param string $email    Email.
		 * @param string $username Username.
		 * @param string $password Password.
		 *
		 * @throws Exception Password is not strong enough.
		 */
		public function validate_register_password_strength( $email, $username, $password ) {
			// Password generated by LearnPress, not chosen by the user.
			if ( apply_filters( 'learnpress_registration_generate_password', false ) ) { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LearnPress hook.
				return;
			}

			$password = is_string( $password ) ? $password : '';

			foreach ( $this->get_password_strength_rules() as $rule ) {
				if ( ! preg_match( $rule['pattern'], $password ) ) {
					throw new Exception( $rule['error'] ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Plain text (also used by REST register), LearnPress escapes it with wp_kses_post() when printed.
				}
			}
		}

		/**
		 * Text of enabled password strength rules.
		 *
		 * @return string Not escaped, empty when no rule enabled.
		 */
		public function get_password_strength_description() {
			$rules = $this->get_password_strength_rules();

			if ( empty( $rules ) ) {
				return '';
			}

			return sprintf(
				/* translators: %s: List of password requirements. */
				__( 'Password must include %s.', 'maxcoach' ),
				implode( ', ', wp_list_pluck( $rules, 'description' ) )
			);
		}

		/**
		 * Print password strength rules, used below the password field of theme register form.
		 */
		public function the_password_strength_description() {
			$description = $this->get_password_strength_description();

			$this->password_strength_description_printed = true;

			if ( '' !== $description ) {
				echo ' ' . esc_html( $description );
			}
		}

		/**
		 * Show password strength rules on register forms that don't print it themselves (Checkout).
		 */
		public function register_password_strength_description() {
			if ( $this->password_strength_description_printed ) {
				return;
			}

			$description = $this->get_password_strength_description();

			if ( '' === $description ) {
				return;
			}
			?>
			<li class="form-field form-field-password-strength">
				<p class="form-input-description"><?php echo esc_html( $description ); ?></p>
			</li>
			<?php
		}

		public function add_user_profile_password_settings( $settings ) {
			$password_settings = array(
				array(
					'title' => esc_html__( 'Password Strength', 'maxcoach' ),
					'type'  => 'title',
					'desc'  => esc_html__( 'Controls the password strength on register form.', 'maxcoach' ),
					'id'    => 'maxcoach_profile_password',
				),
				array(
					'title'   => esc_html__( 'Password capitalized letter', 'maxcoach' ),
					'desc'    => esc_html__( 'Force user register with password at least one capitalized letter.', 'maxcoach' ),
					'id'      => 'enable_password_capitalized_letter',
					'default' => 'yes',
					'type'    => 'yes-no',
				),
				array(
					'title'   => esc_html__( 'Password number', 'maxcoach' ),
					'desc'    => esc_html__( 'Force user register with password at least one number.', 'maxcoach' ),
					'id'      => 'enable_password_number',
					'default' => 'yes',
					'type'    => 'yes-no',
				),
				array(
					'title'   => esc_html__( 'Password special character', 'maxcoach' ),
					'desc'    => esc_html__( 'Force user register with password at least one of these characters ~!@#$%^&*() ', 'maxcoach' ),
					'id'      => 'enable_password_special_character',
					'default' => 'yes',
					'type'    => 'yes-no',
				),
				array(
					'type' => 'sectionend',
					'id'   => 'maxcoach_profile_password',
				),
			);

			$password_settings = apply_filters( 'learn-press/profile-settings-fields/password', $password_settings );

			$instructor_settings = array(
				array(
					'title' => esc_html__( 'Instructors', 'maxcoach' ),
					'type'  => 'title',
					'desc'  => esc_html__( 'Settings for instructors.', 'maxcoach' ),
					'id'    => 'maxcoach_profile_instructors',
				),
				array(
					'title'   => esc_html__( 'Create Events', 'maxcoach' ),
					'desc'    => esc_html__( 'Allows instructors create event posts.', 'maxcoach' ),
					'id'      => 'instructor_manage_event',
					'default' => '',
					'type'    => 'yes-no',
				),
				array(
					'type' => 'sectionend',
					'id'   => 'maxcoach_profile_instructors',
				),
			);

			$instructor_settings = apply_filters( 'learn-press/profile-settings-fields/instructors', $instructor_settings );

			$settings = array_merge( $settings, $password_settings, $instructor_settings );

			return $settings;
		}

		/**
		 * Grant/revoke event capabilities of instructors after LearnPress settings saved.
		 * Setting "Create Events" is stored by LearnPress as 'yes'/'no'.
		 */
		public function update_instructor_event_caps() {
			$instructor = get_role( LP_TEACHER_ROLE );

			if ( ! $instructor ) {
				return;
			}

			// Read the saved option, LP_Settings cache may still hold the old value in this request.
			$grant = 'yes' === get_option( 'learn_press_instructor_manage_event', 'no' );

			$caps = array(
				'edit_tp_event',
				'read_tp_event',
				'delete_tp_event',
				'edit_tp_events',
				'edit_others_tp_events',
				'publish_tp_events',
				'read_private_tp_events',
				'delete_tp_events',
			);

			foreach ( $caps as $cap ) {
				if ( $grant ) {
					$instructor->add_cap( $cap );
				} else {
					$instructor->remove_cap( $cap );
				}
			}
		}

		/**
		 * LearnPress 4.4.8 gives .lp-button its own text color, pages without "learnpress-page" body class
		 * (profile, checkout, order received) need theme button colors.
		 *
		 * @param array $selectors Selectors.
		 *
		 * @return array
		 */
		public function customize_output_button_selectors( $selectors ) {
			$selectors[] = '.learnpress-profile .lp-button, .learnpress-checkout .lp-button, .order_details .lp-button';

			return $selectors;
		}

		/**
		 * @param array $selectors Selectors.
		 *
		 * @return array
		 */
		public function customize_output_button_hover_selectors( $selectors ) {
			$selectors[] = '.learnpress-profile .lp-button:hover, .learnpress-checkout .lp-button:hover, .order_details .lp-button:hover';

			return $selectors;
		}

		/**
		 * Save theme course fields (Language, Time) submitted from LearnPress Course Builder.
		 * LearnPress saves meta data of the course model after this hook, so update it too.
		 *
		 * @param object $course_model LearnPress CourseModel / CoursePostModel.
		 * @param array  $data         Submitted course settings.
		 */
		public function save_course_builder_course_settings( $course_model, $data ) {
			if ( ! is_object( $course_model ) || empty( $course_model->ID ) || ! is_array( $data ) ) {
				return;
			}

			$course_id = absint( $course_model->ID );

			if ( ! $course_id ) {
				return;
			}

			// Same permission as LearnPress Course Builder (author, admin or co-instructor), see CourseBuilderAjax::save_course_settings().
			$user_id           = get_current_user_id();
			$co_instructor_ids = array();

			// Co-instructors are stored as one row per user or as an array.
			foreach ( (array) get_post_meta( $course_id, '_lp_co_teacher' ) as $co_instructor ) {
				$co_instructor_ids = array_merge( $co_instructor_ids, array_map( 'absint', (array) $co_instructor ) );
			}

			if ( ! current_user_can( 'edit_post', $course_id ) && absint( get_post_field( 'post_author', $course_id ) ) !== $user_id && ! current_user_can( 'manage_options' ) && ! in_array( $user_id, $co_instructor_ids, true ) ) {
				return;
			}

			foreach ( array( 'maxcoach_course_language', 'maxcoach_course_time' ) as $key ) {
				if ( ! isset( $data[ $key ] ) || ! is_scalar( $data[ $key ] ) ) {
					continue;
				}

				$value = sanitize_text_field( (string) $data[ $key ] );

				if ( isset( $course_model->meta_data ) && is_object( $course_model->meta_data ) ) {
					$course_model->meta_data->{$key} = $value;
				}

				update_post_meta( $course_id, $key, $value );
			}
		}

		/**
		 * Note on LearnPress "Single course layout" setting, theme uses its own layouts.
		 *
		 * @param array $fields Settings fields.
		 *
		 * @return array
		 */
		public function add_single_course_layout_setting_note( $fields ) {
			if ( ! is_array( $fields ) ) {
				return $fields;
			}

			foreach ( $fields as $index => $field ) {
				if ( is_array( $field ) && isset( $field['id'] ) && 'layout_single_course' === $field['id'] ) {
					$note = esc_html__( 'MaxCoach uses its own single course layout (Customize > Course > Single Course), this option has no effect.', 'maxcoach' );

					$fields[ $index ]['desc'] = ! empty( $field['desc'] ) ? $field['desc'] . '<br/>' . $note : $note;
				}
			}

			return $fields;
		}

		/**
		 * LearnPress widget areas are not rendered by theme templates, remove them to avoid confusion
		 * ("Course Sidebar" of LearnPress has the same name as theme sidebar).
		 */
		public function unregister_learnpress_sidebars() {
			unregister_sidebar( 'course-sidebar' );
			unregister_sidebar( 'archive-courses-sidebar' );
		}

		/**
		 * @deprecated 3.3.9 LearnPress never fires "learnpress_registration_errors".
		 * @see        Maxcoach_LP_Course::validate_register_password_strength()
		 *
		 * @param mixed $errors Errors.
		 *
		 * @return mixed
		 */
		public function user_registration_validate( $errors ) {
			_deprecated_function( __METHOD__, '3.3.9', 'Maxcoach_LP_Course::validate_register_password_strength()' );

			return $errors;
		}

		/**
		 * @deprecated 3.3.9
		 * @see        Maxcoach_LP_Course::update_instructor_event_caps()
		 *
		 * @param string $url Redirect url.
		 *
		 * @return string
		 */
		public function update_settings( $url ) {
			_deprecated_function( __METHOD__, '3.3.9', 'Maxcoach_LP_Course::update_instructor_event_caps()' );

			return $url;
		}

		/**
		 * @deprecated 3.3.9 LearnPress 4 archive doesn't render courses from the main query.
		 */
		public function change_main_loop_courses_query() {
			_deprecated_function( __METHOD__, '3.3.9' );
		}

		/**
		 * @deprecated 3.3.9 Profile dashboard tab of LearnPress 4 doesn't have this section.
		 */
		public function profile_dashboard_user_courses_progress() {
			_deprecated_function( __METHOD__, '3.3.9' );
		}

		public function enqueue_scripts() {
			wp_dequeue_style( 'learn-press-pmpro-style' );

			wp_register_style( 'maxcoach-lp-frontend', MAXCOACH_THEME_URI . '/learnpress.css', array(), MAXCOACH_THEME_VERSION );
			wp_enqueue_style( 'maxcoach-lp-frontend' );

			// load_dashicons_for_users.
			if ( ! is_admin() ) {
				wp_enqueue_style( 'dashicons' );
			}

		}

		public function change_profile_components() {
			LP()->template( 'profile' )->remove( 'learn-press/user-profile-account', '*' );
			add_action( 'learn-press/user-profile-account', LP()->template( 'profile' )->func( 'header' ), 20 );

			// Used item-count file from theme.
			add_filter( 'learn-press/profile/layout/instructor-statistics/item-count', [
				$this,
				'change_statistic_item_count_file',
			] );
			add_filter( 'learn-press/profile/layout/student-statistics/item-count', [
				$this,
				'change_statistic_item_count_file',
			] );
		}

		/**
		 * @return string|null
		 *
		 * @see \LearnPress\Helpers\Template::get_frontend_template()
		 * @see LearnPress\TemplateHooks\Profile\ProfileInstructorStatisticsTemplate::sections()
		 *
		 */
		public function change_statistic_item_count_file() {
			return \LearnPress\Helpers\Template::instance( false )->get_frontend_template( 'profile/tabs/statistics/item-count.php' );
		}

		public function infinite_load() {
			check_ajax_referer( 'maxcoach_ajax', 'security' );
			// Query vars & settings are signed by server (Maxcoach_Helper::get_grid_query_signed_data()).
			$query_vars = Maxcoach_Helper::get_ajax_query_vars( self::POST_TYPE );

			if ( ! empty( $query_vars['extra_tax_query'] ) ) {
				$query_vars = $this->build_extra_terms_query( $query_vars, $query_vars['extra_tax_query'] );
			}

			unset( $query_vars['extra_tax_query'] );

			$query_vars = $this->set_numeric_meta_sorting( $query_vars );

			$maxcoach_query = new WP_Query( $query_vars );

			$settings = Maxcoach_Helper::get_ajax_grid_settings();

			$response = Maxcoach_Helper::get_ajax_query_response( $maxcoach_query );

			ob_start();

			if ( $maxcoach_query->have_posts() ) :
				learn_press_setup_user();
				set_query_var( 'maxcoach_query', $maxcoach_query );
				set_query_var( 'settings', $settings );

				// Whitelist allowed layouts
				$allowed_layouts = array( 'grid', 'masonry', 'zigzag' );
				$layout          = isset( $settings['layout'] ) ? sanitize_text_field( $settings['layout'] ) : 'grid';

				if ( in_array( $layout, $allowed_layouts, true ) ) {
					get_template_part( 'loop/widgets/course/style', $layout );
				}

				wp_reset_postdata();
			endif;

			$template = ob_get_clean();

			$template = preg_replace( '~>\s+<~', '><', $template );

			$response['template'] = $template;

			wp_send_json_success( $response );
		}

		public function get_setting( $name ) {
			/**
			 * @var LP_Settings $settings
			 */
			$settings = LP()->settings;

			$setting = $settings->get( $name );

			return $setting;
		}

		/**
		 * Add html tag wrap decimal separator.
		 *
		 * @param string $price_html
		 *
		 * @return mixed
		 */
		public function add_wrapper_decimals_separator( $price_html ) {
			$number_decimal     = intval( $this->get_setting( 'number_of_decimals' ) );
			$decimals_separator = $this->get_setting( 'decimals_separator' );

			if ( $number_decimal > 0 && ! empty( $decimals_separator ) && is_string( $price_html ) ) {
				// This filter can run twice on the same fragment (regular price html is embedded
				// in the full price html) - unwrap first so the callback stays idempotent.
				$price_html = preg_replace( '#<span class="decimals-separator">(.*?)</span>#', '$1', $price_html );

				// Wrap every decimal part (origin + sale price). The (?!\d) guard skips
				// thousands groups when both separators use the same character.
				$price_html = preg_replace(
					'#' . preg_quote( $decimals_separator, '#' ) . '\d{1,' . $number_decimal . '}(?!\d)#',
					'<span class="decimals-separator">$0</span>',
					$price_html
				);
			}

			return $price_html;
		}

		/**
		 * Price used to sort courses.
		 *
		 * @param int $post_id Course ID.
		 *
		 * @return float
		 */
		public function get_course_sort_price( $post_id ) {
			// LP 4.4.11+: "No enrollment requirement" courses are free (CourseModel::get_price() returns 0),
			// but their _lp_price meta keeps the old price until the course is saved again.
			if ( version_compare( LEARNPRESS_VERSION, '4.4.11', '>=' ) && 'yes' === get_post_meta( $post_id, self::POST_META_NO_REQUIRED_ENROLL, true ) ) {
				return 0;
			}

			$price = get_post_meta( $post_id, self::POST_META_PRICE, true );

			// LP 4.x: _lp_price is the price to sort (sale price when on sale), set when price saved.
			if ( metadata_exists( 'post', $post_id, '_lp_regular_price' ) ) {
				return is_numeric( $price ) ? (float) $price : 0;
			}

			// Legacy data: _lp_price is the regular price.
			$sale_price = get_post_meta( $post_id, self::POST_META_SALE_PRICE, true );

			if ( is_numeric( $sale_price ) ) {
				return (float) $sale_price;
			}

			return is_numeric( $price ) ? (float) $price : 0;
		}

		/**
		 * @param int $post_ID
		 */
		public function save_course_sale_price( $post_ID ) {
			update_post_meta( $post_ID, self::CUSTOM_POST_META_SORT_PRICE, $this->get_course_sort_price( $post_ID ) );
		}

		/**
		 * WordPress Importer & Insight Core importer: keep sort price of exported courses.
		 */
		public function on_import_start() {
			$this->is_importing = true;
		}

		public function on_import_end() {
			$this->is_importing = false;
		}

		/**
		 * Update sort price whenever LearnPress saves the course price or the "No enrollment requirement" option.
		 *
		 * @param int    $meta_id   Meta ID.
		 * @param int    $object_id Post ID.
		 * @param string $meta_key  Meta key.
		 */
		public function sync_course_sort_price( $meta_id, $object_id, $meta_key ) {
			// Importers add meta of exported courses (sort price included) after the post is inserted.
			if ( $this->is_importing || ! in_array( $meta_key, array( self::POST_META_PRICE, self::POST_META_NO_REQUIRED_ENROLL ), true ) || self::POST_TYPE !== get_post_type( $object_id ) ) {
				return;
			}

			$this->save_course_sale_price( $object_id );
		}

		/**
		 * Add sort price to new courses that have no price saved yet (e.g. created by REST, imports).
		 *
		 * @param int     $post_id Post ID.
		 * @param WP_Post $post    Post.
		 */
		public function add_missing_course_sort_price( $post_id, $post ) {
			if ( $this->is_importing || ! $post instanceof WP_Post || self::POST_TYPE !== $post->post_type || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
				return;
			}

			if ( ! metadata_exists( 'post', $post_id, self::CUSTOM_POST_META_SORT_PRICE ) ) {
				$this->save_course_sale_price( $post_id );
			}
		}

		/**
		 * Sort numeric meta (price, students) as numbers.
		 * Courses without the meta are not excluded from results (their order is not guaranteed).
		 * Query vars sorting is validated by Maxcoach_Helper::get_ajax_query_vars().
		 *
		 * @param array $query_vars Query vars.
		 *
		 * @return array
		 */
		public function set_numeric_meta_sorting( $query_vars ) {
			$meta_key = isset( $query_vars['meta_key'] ) ? $query_vars['meta_key'] : '';
			$orderby  = isset( $query_vars['orderby'] ) ? $query_vars['orderby'] : '';

			if ( ! is_string( $orderby ) || 0 !== strpos( $orderby, 'meta_value' ) || ! in_array( $meta_key, array( self::CUSTOM_POST_META_SORT_PRICE, self::POST_META_STUDENTS ), true ) ) {
				return $query_vars;
			}

			$order = isset( $query_vars['order'] ) && is_string( $query_vars['order'] ) && 'ASC' === strtoupper( $query_vars['order'] ) ? 'ASC' : 'DESC';

			$sort_meta_query = array(
				'relation'      => 'OR',
				'maxcoach_sort' => array(
					'key'     => $meta_key,
					'compare' => 'EXISTS',
					'type'    => self::CUSTOM_POST_META_SORT_PRICE === $meta_key ? 'DECIMAL(20,4)' : 'NUMERIC',
				),
				array(
					'key'     => $meta_key,
					'compare' => 'NOT EXISTS',
				),
			);

			if ( ! empty( $query_vars['meta_query'] ) && is_array( $query_vars['meta_query'] ) ) {
				$sort_meta_query = array(
					'relation' => 'AND',
					$query_vars['meta_query'],
					$sort_meta_query,
				);
			}

			unset( $query_vars['meta_key'] );

			$query_vars['meta_query'] = $sort_meta_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			// Unique order (ID) keeps pages consistent.
			$query_vars['orderby'] = array(
				'maxcoach_sort' => $order,
				'title'         => 'ASC',
				'ID'            => 'ASC',
			);

			return $query_vars;
		}

		/**
		 * @param array  $query_args Query args of Elementor grid first page.
		 * @param string $post_type  Post type of the grid.
		 *
		 * @return array
		 */
		public function elementor_grid_query_args( $query_args, $post_type ) {
			if ( self::POST_TYPE !== $post_type || ! is_array( $query_args ) ) {
				return $query_args;
			}

			return $this->set_numeric_meta_sorting( $query_args );
		}

		public function change_archive_components() {
			/**
			 * @action learn-press/after-courses-loop-item
			 *
			 * @hooked
			 * @see    learn_press_courses_loop_item_begin_meta - 10
			 * @see    learn_press_courses_loop_item_price - 20
			 * @see    learn_press_courses_loop_item_title - 21
			 * @see    learn_press_courses_loop_item_instructor - 25
			 * @see    learn_press_courses_loop_item_end_meta - 30
			 * @see    learn_press_course_loop_item_buttons - 35
			 * @see    learn_press_course_loop_item_user_progress - 40
			 */

			/**
			 * Remove all hooks from Plugin.
			 */
			LP()->template( 'course' )->remove( 'learn-press/before-courses-loop-item', '*' );
			LP()->template( 'course' )->remove( 'learn-press/courses-loop-item-title', '*' );
			LP()->template( 'course' )->remove( 'learn-press/after-courses-loop-item', '*' );

			/**
			 * Re-add components
			 */
			add_action( 'learn-press/before-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/thumbnail.php' ), 20 );

			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/info-begin.php' ), 0 );
			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->func( 'courses_loop_item_price' ), 10 );
			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/title.php' ), 50 );
			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/meta.php' ), 60 );
			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/meta-begin.php' ), 100 );
			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/meta-duration.php' ), 110 );
			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/meta-lessons.php' ), 120 );
			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/meta-quiz.php' ), 130 );
			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/meta-level' ), 140 );
			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/meta-students.php' ), 150 );
			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/meta-end.php' ), 200 );
			add_action( 'learn-press/after-courses-loop-item', LP()->template( 'course' )->callback( 'loop/course/info-end.php' ), 1000 );

			//LP()->template( 'course' )->remove( 'learn-press/before-courses-loop', 'courses_top_bar', 10 );
			add_filter( 'learn_press_pagination_args', [ $this, 'change_pagination_args' ] );

			add_filter( 'learn-press/layout/list-courses/item-li', [
				$this,
				'change_courses_item_html',
			], 99, 3 );
			add_filter( 'learn-press/layout/list-courses/item/section/bottom', [
				$this,
				'change_courses_item_info_html',
			], 99, 3 );
			add_filter( 'learn-press/layout/list-courses/section/courses', [
				$this,
				'change_courses_html',
			], 99, 3 );
		}

		/**
		 * @see LearnPress\TemplateHooks\Course\ListCoursesTemplate::render_courses()
		 */
		public function change_courses_item_html( array $components, \LearnPress\Models\CourseModel $course, array $settings ) : array {
			$components['wrapper_li']  = sprintf( '<li class="course grid-item" data-id="%s">', esc_attr( $course->get_id() ) );
			$components['wrapper_div'] = '<div class="course-wrapper maxcoach-box">';
			$components['top']         = $this->get_course_thumbnail_html( $course );

			return $components;
		}

		/**
		 * @see LearnPress\TemplateHooks\Course\ListCoursesTemplate::render_courses()
		 */
		public function change_courses_item_info_html( array $components, \LearnPress\Models\CourseModel $course, array $settings ) : array {
			$single_course_template = SingleCourseTemplate::instance();

			$new_components = array(
				'wrapper' => '<div class="course-info">',
				'price'   => $single_course_template->html_price( $course ),
			);

			// Keep star rating added by LearnPress Course Review add-on (before title).
			if ( ! empty( $components['review'] ) ) {
				$new_components['review'] = $components['review'];
			}

			$new_components['title']       = sprintf(
				'<h3 class="course-title"><a class="course-permalink" href="%s">%s</a></h3>',
				esc_url( $course->get_permalink() ),
				$single_course_template->html_title( $course )
			);
			$new_components['short_des']   = $single_course_template->html_short_description( $course, 15 );
			$new_components['meta']        = $this->get_course_meta_html( $course );
			$new_components['wrapper_end'] = '</div>';

			return $new_components;
		}

		/**
		 * @see LearnPress\TemplateHooks\Course\ListCoursesTemplate::render_courses()
		 */
		public function get_course_thumbnail_html( LearnPress\Models\CourseModel $course ) : string {
			ob_start();
			?>
			<div class="course-thumbnail maxcoach-image">
				<a href="<?php echo esc_url( $course->get_permalink() ); ?>" class="course-permalink">
					<?php echo Maxcoach_LP_Course::instance()->get_course_image( $course->get_id(), '480x298' ); ?>
				</a>
			</div>
			<?php
			return ob_get_clean();
		}

		/**
		 * @see LearnPress\TemplateHooks\Course\ListCoursesTemplate::render_courses()
		 */
		public function get_course_meta_html( \LearnPress\Models\CourseModel $course ) : string {
			ob_start();
			if ( ! empty( Maxcoach::setting( 'course_archive_meta_lession_enable', '1' ) ) ) {
				$count_items = $course->count_items( 'lp_lesson' );
				?>
				<div class="course-lesson">
					<span class="meta-icon far fa-file-alt"></span>
					<span class="meta-value">
						<?php echo esc_html( sprintf( _n( '%s Lesson', '%s Lessons', $count_items, 'maxcoach' ), number_format_i18n( $count_items ) ) ); ?>
					</span>
				</div>
				<?php
			}

			if ( ! empty( Maxcoach::setting( 'course_archive_meta_duration_enable', '0' ) ) ) {
				?>
				<div class="course-duration">
					<span class="meta-icon far fa-clock"></span>
					<span class="meta-value">
						<?php echo learn_press_get_post_translated_duration( $course->get_id(), esc_html__( 'Lifetime access', 'maxcoach' ) ); ?>
					</span>
				</div>
				<?php
			}

			if ( ! empty( Maxcoach::setting( 'course_archive_meta_quiz_enable', '0' ) ) ) {
				$count_items = $course->count_items( 'lp_quiz' );
				?>
				<div class="course-quiz">
					<span class="meta-icon far fa-puzzle-piece"></span>
					<span class="meta-value"><?php echo esc_html( sprintf( _n( '%s Quiz', '%s Quizzes', $count_items, 'maxcoach' ), number_format_i18n( $count_items ) ) ); ?></span>
				</div>
				<?php
			}

			if ( ! empty( Maxcoach::setting( 'course_archive_meta_level_enable', '0' ) ) ) {
				$level = learn_press_get_post_level( $course->get_id() );
				if ( $level ) {
					?>
					<div class="course-level">
						<span class="meta-icon far fa-signal"></span>
						<span class="meta-value"><?php echo esc_html( $level ); ?></span>
					</div>
					<?php
				}
			}

			if ( ! empty( Maxcoach::setting( 'course_archive_meta_student_enable', '1' ) ) ) {
				// Same count as other course lists (includes fake students).
				$count = method_exists( $course, 'count_students' ) ? $course->count_students() : $course->get_total_user_enrolled_or_purchased();
				?>
				<div class="course-students">
					<span class="meta-icon far fa-user-alt"></span>
					<span class="meta-value"><?php echo esc_html( sprintf( _n( '%s Student', '%s Students', $count, 'maxcoach' ), number_format_i18n( $count ) ) ); ?></span>
				</div>
				<?php
			}
			$meta_html = ob_get_clean();

			return '<div class="course-meta">' . $meta_html . '</div>';
		}

		/**
		 * @see LearnPress\TemplateHooks\Course\ListCoursesTemplate::render_courses()
		 */
		public function change_courses_html( $html_parts, $courses, $settings ) {
			$lg_columns     = Maxcoach::setting( 'course_archive_lg_columns', 3 );
			$md_columns     = Maxcoach::setting( 'course_archive_md_columns', 2 );
			$sm_columns     = Maxcoach::setting( 'course_archive_sm_columns', 1 );
			$wrap_css_class = "maxcoach-main-post maxcoach-grid-wrapper grid maxcoach-course maxcoach-animation-zoom-in grid-sm-{$sm_columns} grid-md-{$md_columns} grid-lg-{$lg_columns}";

			$html_parts['wrap'] = preg_replace(
				'/class="/',
				'class="' . $wrap_css_class . ' ',
				$html_parts['wrap']
			);

			return $html_parts;
		}

		public function change_pagination_args( $args ) {
			$args['prev_text'] = Maxcoach_Templates::get_pagination_prev_text();
			$args['next_text'] = Maxcoach_Templates::get_pagination_next_text();

			return $args;
		}

		/**
		 * Current course for title bar meta, only on single course.
		 * Title bar 03 also shows meta on course archive pages, where there is no current course.
		 *
		 * @return LP_Course|false
		 */
		private function get_title_bar_course() {
			if ( ! is_singular( self::POST_TYPE ) ) {
				return false;
			}

			return LP_Global::course();
		}

		public function add_title_bar_meta_course_instructor() {
			/**
			 * @var LP_Course        $course
			 * @var LP_Abstract_User $instructor
			 */
			$course = $this->get_title_bar_course();

			if ( ! $course ) {
				return;
			}

			$instructor = $course->get_instructor();

			if ( ! $instructor ) {
				return;
			}
			?>
			<div class="course-instructor post-author">
				<span class="meta-icon meta-image">
					<?php Maxcoach_Helper::e( $instructor->get_profile_picture( '', 32 ) ); ?>
				</span>
				<span class="meta-value"><?php echo esc_html( $instructor->get_display_name() ); ?></span>
			</div>
			<?php
		}

		public function add_title_bar_meta_course_duration() {
			if ( ! $this->get_title_bar_course() ) {
				return;
			}

			$duration = $this->get_duration_translatable();

			if ( empty( $duration ) ) {
				return;
			}
			?>
			<div class="course-duration">
				<span class="meta-icon far fa-clock"></span>
				<span class="meta-value"><?php echo esc_html( $duration ); ?></span>
			</div>
			<?php
		}

		public function add_title_bar_meta_course_lesson() {
			$course = $this->get_title_bar_course();

			if ( ! $course ) {
				return;
			}

			$count_items = $course->count_items();

			if ( empty( $count_items ) ) {
				return;
			}

			$count_items = intval( $count_items );
			?>
			<div class="course-lesson">
				<span class="meta-icon far fa-file-alt"></span>
				<span class="meta-value">
					<?php
					printf( _n( '%s Lesson', '%s Lessons', $count_items, 'maxcoach' ), number_format_i18n( $count_items ) );
					?>
				</span>
			</div>
			<?php
		}

		public function add_title_bar_meta_course_student() {
			$course = $this->get_title_bar_course();
			if ( ! $course || ! $course->is_required_enroll() ) {
				return;
			}

			$count = intval( $course->count_students() );
			?>

			<div class="course-students">
				<span class="meta-icon far fa-user-alt"></span>
				<span class="meta-value">
					<?php printf( _n( '%s Student', '%s Students', $count, 'maxcoach' ), number_format_i18n( $count ) ); ?>
				</span>
			</div>
			<?php
		}

		public function body_classes( $classes ) {
			if ( is_singular( self::POST_TYPE ) ) {
				$layout = $this->get_single_layout();

				$classes[] = 'single-course-layout-' . $layout;
			}

			return $classes;
		}

		public function is_single_lessons() {
			global $wp_query;

			if ( $wp_query->is_single && ! empty( $wp_query->query_vars['post_type'] ) && 'lp_course' === $wp_query->query_vars['post_type'] && ! empty( $wp_query->query_vars['item-type'] ) && in_array( $wp_query->query_vars['item-type'], [
					'lp_lesson',
					'lp_quiz',
				] ) ) {
				return true;
			}

			return false;
		}

		public function change_plugin_style( $handles ) {
			/**
			 * Remove font awesome to avoid duplicate enqueue.
			 */
			unset( $handles['font-awesome-5-all'] );

			return $handles;
		}

		public function enqueue_frontend_scripts() {
			wp_dequeue_style( 'font-awesome-5-all' );
		}

		/**
		 * Change components for single pages.
		 */
		public function change_single_components() {
			LP()->template( 'course' )->remove( 'learn-press/course-content-summary', '*' );

			add_action( 'learn-press/course-content-summary', LP()->template( 'course' )->func( 'user_progress' ), 10 );

			add_action( 'learn-press/course-content-summary', LP()->template( 'course' )->func( 'course_extra_boxes' ), 40 );

			add_action( 'learn-press/course-content-summary', LP()->template( 'course' )->callback( 'single-course/tabs/tabs' ), 60 );

			// Add title.
			if ( 'none' === Maxcoach::setting( 'course_single_title_bar_layout' ) ) {
				add_action( 'learn-press/before-single-course', [ $this, 'maxcoach_learn_press_course_title' ] );
			}

			add_action( 'learn-press/single-course-summary', [ $this, 'entry_course_thumbnail' ], 1 );

			/**
			 * For other layouts.
			 */
			add_action( 'learn-press/after-single-course-summary', [ $this, 'single_course_buttons' ], 10 );

			/**
			 * For layout 01 Sticky Bar Features.
			 */
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'single_course_price' ], 5 );
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'single_course_meta_start_wrapper' ], 10 );
			add_action( 'learn-press/single-sticky-bar-features', [
				$this,
				'add_single_course_meta_instructor',
			], 20 );
			/**
			 * Offline course meta (LP 4.x). Each callback self-skips for online courses.
			 */
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'add_single_course_meta_delivery_type' ], 22 );
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'add_single_course_meta_capacity' ], 24 );
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'add_single_course_meta_address' ], 26 );
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'add_single_course_meta_duration' ], 30 );
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'add_single_course_meta_lesson' ], 40 );
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'single_course_students' ], 50 );
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'add_single_course_meta_language' ], 60 );
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'add_single_course_meta_time' ], 70 );
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'single_course_meta_end_wrapper' ], 80 );
			add_action( 'learn-press/single-sticky-bar-features', [ $this, 'single_course_buttons' ], 90 );
			add_action( 'learn-press/after-course-buttons', [ $this, 'entry_sharing' ] );

			// Offline courses are not learned online; drop the curriculum tab for them.
			add_filter( 'learn-press/course-tabs', [ $this, 'remove_curriculum_tab_for_offline_course' ], 20, 2 );
		}

		/**
		 * Remove the curriculum tab for offline courses.
		 *
		 * @param array $tabs
		 * @param mixed $course CourseModel (LP 4.x) passed by the filter.
		 *
		 * @return array
		 */
		public function remove_curriculum_tab_for_offline_course( $tabs, $course = null ) {
			if ( $course instanceof \LearnPress\Models\CourseModel && $course->is_offline() && isset( $tabs['curriculum'] ) ) {
				unset( $tabs['curriculum'] );
			}

			return $tabs;
		}

		/**
		 * Get the offline CourseModel for the current course.
		 *
		 * @return \LearnPress\Models\CourseModel|null Null when not an offline course or LP API unavailable.
		 */
		private function get_offline_course_model() {
			if ( ! class_exists( '\LearnPress\Models\CourseModel' ) ) {
				return null;
			}

			$course = \LearnPress\Models\CourseModel::find( get_the_ID(), true );

			if ( ! $course instanceof \LearnPress\Models\CourseModel || ! $course->is_offline() ) {
				return null;
			}

			return $course;
		}

		public function add_single_course_meta_delivery_type() {
			$course = $this->get_offline_course_model();
			if ( ! $course || ! class_exists( '\LearnPress\TemplateHooks\Course\SingleCourseOfflineTemplate' ) ) {
				return;
			}

			$deliver_type = wp_strip_all_tags( \LearnPress\TemplateHooks\Course\SingleCourseOfflineTemplate::instance()->html_deliver_type( $course ) );
			if ( '' === $deliver_type ) {
				return;
			}
			?>
			<div class="course-deliver-type">
				<span class="meta-label">
					<i class="meta-icon far fa-chalkboard-teacher"></i>
					<?php esc_html_e( 'Delivery type', 'maxcoach' ); ?>
				</span>
				<span class="meta-value"><?php echo esc_html( $deliver_type ); ?></span>
			</div>
			<?php
		}

		public function add_single_course_meta_capacity() {
			$course = $this->get_offline_course_model();
			if ( ! $course || ! class_exists( '\LearnPress\TemplateHooks\Course\SingleCourseTemplate' ) ) {
				return;
			}

			$capacity = wp_strip_all_tags( \LearnPress\TemplateHooks\Course\SingleCourseTemplate::instance()->html_capacity( $course ) );
			if ( '' === $capacity ) {
				return;
			}
			?>
			<div class="course-capacity">
				<span class="meta-label">
					<i class="meta-icon far fa-users"></i>
					<?php esc_html_e( 'Capacity', 'maxcoach' ); ?>
				</span>
				<span class="meta-value"><?php echo esc_html( $capacity ); ?></span>
			</div>
			<?php
		}

		public function add_single_course_meta_address() {
			$course = $this->get_offline_course_model();
			if ( ! $course || ! class_exists( '\LearnPress\TemplateHooks\Course\SingleCourseOfflineTemplate' ) ) {
				return;
			}

			$address = wp_strip_all_tags( \LearnPress\TemplateHooks\Course\SingleCourseOfflineTemplate::instance()->html_address( $course ) );
			if ( '' === $address ) {
				return;
			}
			?>
			<div class="course-address">
				<span class="meta-label">
					<i class="meta-icon far fa-map-marker-alt"></i>
					<?php esc_html_e( 'Address', 'maxcoach' ); ?>
				</span>
				<span class="meta-value"><?php echo esc_html( $address ); ?></span>
			</div>
			<?php
		}

		public function maxcoach_learn_press_course_title() {
			learn_press_get_template( 'single-course/title.php' );
		}

		public function single_course_meta_start_wrapper() {
			echo '<div class="course-meta">';
		}

		public function single_course_meta_end_wrapper() {
			echo '</div>';
		}

		public function single_course_price() {
			learn_press_get_template( 'single-course/price.php' );
		}

		public function single_course_buttons() {
			LP()->template( 'course' )->course_buttons();
		}

		public function single_course_students() {
			learn_press_get_template( 'single-course/students.php' );
		}

		public function add_fields_to_meta_box( $fields ) {
			$custom_fields = array(
				'maxcoach_course_language' => new LP_Meta_Box_Text_Field( esc_html__( 'Language', 'maxcoach' ), '', '', array() ),
				'maxcoach_course_time'     => new LP_Meta_Box_Text_Field( esc_html__( 'Time', 'maxcoach' ), '', '', array() ),
			);

			return array_merge( $fields, $custom_fields );
		}

		public function add_single_course_meta_language() {
			$course_language = get_post_meta( get_the_ID(), 'maxcoach_course_language', true );
			if ( empty( $course_language ) ) {
				return;
			}
			?>
			<div class="course-language">
				<span class="meta-label">
					<i class="meta-icon far fa-language"></i>
					<?php esc_html_e( 'Language', 'maxcoach' ); ?>
				</span>
				<span class="meta-value"><?php echo esc_html( $course_language ); ?></span>
			</div>
			<?php
		}

		public function add_single_course_meta_time() {
			$course_time = get_post_meta( get_the_ID(), 'maxcoach_course_time', true );
			if ( empty( $course_time ) ) {
				return;
			}
			?>
			<div class="course-time">
				<span class="meta-label">
					<i class="meta-icon far fa-calendar"></i>
					<?php esc_html_e( 'Deadline', 'maxcoach' ); ?>
				</span>
				<span class="meta-value"><?php echo esc_html( $course_time ); ?></span>
			</div>
			<?php
		}

		public function add_single_course_meta_instructor() {
			$course = LP_Global::course();

			if ( ! $course ) {
				return;
			}

			$instructor = $course->get_instructor_name();
			?>
			<div class="course-instructor">
				<span class="meta-label">
					<i class="meta-icon far fa-chalkboard-teacher"></i>
					<?php esc_html_e( 'Instructor', 'maxcoach' ); ?>
				</span>
				<span class="meta-value"><?php echo esc_html( $instructor ); ?></span>
			</div>
			<?php
		}

		public function add_single_course_meta_duration() {
			$duration = $this->get_duration_translatable();

			if ( empty( $duration ) ) {
				return;
			}
			?>
			<div class="course-duration">
				<span class="meta-label">
					<i class="meta-icon far fa-clock"></i>
					<?php esc_html_e( 'Duration', 'maxcoach' ); ?>
				</span>
				<span class="meta-value"><?php echo esc_html( $duration ); ?></span>
			</div>
			<?php
		}

		/**
		 * Fix duration text can't be translatable.
		 *
		 * @return string translatable duration.
		 */
		public function get_duration_translatable() {
			$course = LP_Global::course();

			if ( ! $course ) {
				return '';
			}

			$duration_text = $course->get_data( 'duration' );

			$duration_text_translatable = $duration_text;

			$duration_arr = explode( ' ', $duration_text );
			if ( count( $duration_arr ) === 2 ) {
				$duration_number = intval( $duration_arr[0] );
				$duration_time   = $duration_arr[1];

				switch ( $duration_time ) {
					case 'week' :
						$duration_text_translatable = sprintf( _n( '%s week', '%s weeks', $duration_number, 'maxcoach' ), number_format_i18n( $duration_number ) );
						break;
					case 'day' :
						$duration_text_translatable = sprintf( _n( '%s day', '%s days', $duration_number, 'maxcoach' ), number_format_i18n( $duration_number ) );
						break;
					case 'hour' :
						$duration_text_translatable = sprintf( _n( '%s hour', '%s hours', $duration_number, 'maxcoach' ), number_format_i18n( $duration_number ) );
						break;
					case 'minute' :
						$duration_text_translatable = sprintf( _n( '%s minute', '%s minutes', $duration_number, 'maxcoach' ), number_format_i18n( $duration_number ) );
						break;
				}
			}

			return $duration_text_translatable;
		}

		public function add_single_course_meta_lesson() {
			$course      = LP_Global::course();
			$count_items = $course->count_items();

			// Offline courses have no real curriculum items; use the manual "Lessons" count.
			$offline_course = $this->get_offline_course_model();
			if ( $offline_course ) {
				$count_items = $offline_course->get_meta_value_by_key( '_lp_offline_lesson_count', $count_items );
			}

			if ( empty( $count_items ) ) {
				return;
			}

			// Offline courses label this as "Lessons" to match the course setting.
			$label = $offline_course ? esc_html__( 'Lessons', 'maxcoach' ) : esc_html__( 'Lectures', 'maxcoach' );
			?>
			<div class="course-lectures">
				<span class="meta-label">
					<i class="meta-icon far fa-file-alt"></i>
					<?php echo esc_html( $label ); ?>
				</span>
				<span class="meta-value"><?php echo esc_html( $count_items ); ?></span>
			</div>
			<?php
		}

		public function entry_sharing() {
			if ( ! is_singular( self::POST_TYPE ) || ! class_exists( 'InsightCore' ) ) {
				return;
			}

			$social_sharing = Maxcoach::setting( 'social_sharing_item_enable' );
			if ( empty( $social_sharing ) ) {
				return;
			}

			$layout = $this->get_single_layout();
			?>
			<div class="entry-course-share">
				<div class="post-share style-02">
					<div class="share-media">

						<?php if ( '01' === $layout ) : ?>
							<div class="share-label">
								<?php esc_html_e( 'Share this course', 'maxcoach' ); ?>
							</div>
							<span class="share-icon far fa-share-alt"></span>

							<div class="share-list">
								<?php Maxcoach_Templates::get_sharing_list(); ?>
							</div>
						<?php else : ?>
							<?php Maxcoach_Templates::render_button( [
								'text'       => esc_html__( 'Share this course', 'maxcoach' ),
								'link'       => [
									'url' => 'javascript:void(0)',
								],
								'icon'       => 'far fa-share-alt',
								'icon_align' => 'right',
							] ); ?>

							<div class="share-list">
								<?php Maxcoach_Templates::get_sharing_list(); ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Remove sidebar if single layout is layout '01 => Sticky Features Bar' style.
		 *
		 * @param $sidebar
		 *
		 * @return string
		 */
		public function remove_sidebar_for_sticky_layout( $sidebar ) {
			$layout = $this->get_single_layout();

			if ( is_singular( self::POST_TYPE ) && '01' === $layout ) {
				return 'none';
			}

			return $sidebar;
		}

		/**
		 * Route offline courses back to the theme's legacy single course template.
		 *
		 * @param string $template Page template filename resolved by LearnPress.
		 *
		 * @return string
		 */
		public function use_theme_template_for_offline_course( $template ) {
			if ( 'single-course-offline.php' === $template ) {
				$template = 'single-course.php';
			}

			return $template;
		}

		/**
		 * Get single course layout.
		 *
		 * @return string $layout
		 */
		public function get_single_layout() {
			$layout = Maxcoach_Helper::get_post_meta( 'single_course_layout', '' );

			if ( empty( $layout ) ) {
				$layout = Maxcoach::setting( 'single_course_layout' );
			}

			return $layout;
		}

		public function is_activated() : bool {
			return class_exists( 'LearnPress' );
		}

		public function get_categories( $args = array() ) {
			$defaults = array(
				'all' => true,
			);
			$args     = wp_parse_args( $args, $defaults );
			$terms    = get_terms( array(
				'taxonomy' => self::TAXONOMY_CATEGORY,
			) );
			$results  = array();

			if ( $args['all'] === true ) {
				$results['-1'] = esc_html__( 'All', 'maxcoach' );
			}

			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$results[ $term->slug ] = $term->name;
				}
			}

			return $results;
		}

		public function get_tags( $args = array() ) {
			$defaults = array(
				'all' => true,
			);
			$args     = wp_parse_args( $args, $defaults );
			$terms    = get_terms( array(
				'taxonomy' => self::TAXONOMY_TAGS,
			) );
			$results  = array();

			if ( $args['all'] === true ) {
				$results['-1'] = esc_html__( 'All', 'maxcoach' );
			}

			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$results[ $term->slug ] = $term->name;
				}
			}

			return $results;
		}

		public function is_taxonomy() : bool {
			return function_exists( 'learn_press_is_course_taxonomy' ) && learn_press_is_course_taxonomy();
		}

		public function is_tag() : bool {
			return function_exists( 'learn_press_is_course_tag' ) && learn_press_is_course_tag();
		}

		public function is_category() : bool {
			return function_exists( 'learn_press_is_course_category' ) && learn_press_is_course_category();
		}

		public function is_archive() : bool {
			return function_exists( 'learn_press_is_course_archive' ) && learn_press_is_course_archive();
		}

		public function has_tag() : bool {
			return has_term( '', self::TAXONOMY_TAGS );
		}

		public function has_category() : bool {
			return has_term( '', self::TAXONOMY_CATEGORY );
		}

		public function the_loop_categories() {
			?>
			<div class="course-categories">
				<?php echo get_the_term_list( get_the_ID(), self::TAXONOMY_CATEGORY, '', ', ', '' ); ?>
			</div>
			<?php
		}

		public function the_loop_meta_categories() {
			?>
			<div class="meta-item course-categories">
				<span class="meta-icon far fa-folders"></span>
				<?php echo get_the_term_list( get_the_ID(), self::TAXONOMY_CATEGORY, '', ', ', '' ); ?>
			</div>
			<?php
		}

		public function the_loop_price() {
			$course          = LP_Global::course();
			$wrapper_classes = 'course-price';

			if ( $course->is_free() ) {
				$wrapper_classes .= ' course-free';
			}
			?>
			<div class="<?php echo esc_attr( $wrapper_classes ); ?>">
				<?php if ( $price_html = $course->get_course_price_html() ) { ?>
					<?php echo '<span class="price">' . wp_kses_post( $price_html ) . '</span>'; ?>
				<?php } ?>
			</div>
			<?php
		}

		/**
		 * Custom price template used for caption style 01.
		 * Edit free price with value + badge.
		 */
		public function the_loop_custom_price() {
			$course = LP_Global::course();

			$price      = $course->get_price();
			$price      = learn_press_format_price( $price, true );
			$price_html = apply_filters( 'learn_press_course_price_html', $price, $course->has_sale_price(), $course->get_id() ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LearnPress hook.
			?>

			<?php if ( $course->is_free() ): ?>
				<div class="course-price-badge">
					<?php
					$free_price = apply_filters( 'learn_press_course_price_html_free', __( 'Free', 'maxcoach' ), $course );
					echo esc_html( $free_price );
					?>
				</div>
			<?php endif; ?>

			<div class="course-price">
				<?php if ( $price_html ) { ?>
					<?php echo '<span class="price">' . wp_kses_post( $price_html ) . '</span>'; ?>
				<?php } ?>
			</div>
			<?php
		}

		public function the_loop_duration() {
			$duration = $this->get_duration_translatable();

			if ( empty( $duration ) ) {
				return;
			}
			?>
			<div class="meta-item course-duration">
				<span class="meta-icon far fa-clock"></span>
				<span class="meta-value"><?php echo esc_html( $duration ); ?></span>
			</div>
			<?php
		}

		public function the_loop_lessons() {
			$course      = LP_Global::course();
			$count_items = $course->count_items();

			if ( empty( $count_items ) ) {
				return;
			}

			$count_items = intval( $count_items );
			?>
			<div class="meta-item course-lesson">
				<span class="meta-icon far fa-file-alt"></span>
				<span class="meta-value">
					<?php printf( _n( '%s Lesson', '%s Lessons', $count_items, 'maxcoach' ), number_format_i18n( $count_items ) ); ?>
				</span>
			</div>
			<?php
		}

		public function the_loop_students() {
			$course = LP_Global::course();
			if ( ! $course || ! $course->is_required_enroll() ) {
				return;
			}

			$count = intval( $course->count_students() );
			?>

			<div class="meta-item course-students">
				<span class="meta-icon far fa-user-alt"></span>
				<span class="meta-value">
					<?php printf( _n( '%s Student', '%s Students', $count, 'maxcoach' ), number_format_i18n( $count ) ); ?>
				</span>
			</div>
			<?php
		}

		public function the_loop_instructor() {
			/**
			 * @var LP_Course        $course
			 * @var LP_Abstract_User $instructor
			 */
			$course     = LP_Global::course();
			$instructor = $course->get_instructor();
			?>
			<div class="course-instructor">
				<span class="instructor-avatar">
					<?php Maxcoach_Helper::e( $instructor->get_profile_picture( '', 32 ) ); ?>
				</span>
				<span class="instructor-name"><?php echo esc_html( $instructor->get_display_name() ); ?></span>
			</div>
			<?php
		}

		/**
		 * @param string $text Button text, "View More" if empty.
		 */
		public function the_loop_buttons( $text = '' ) {
			$text = is_string( $text ) && '' !== trim( $text ) ? $text : __( 'View More', 'maxcoach' );
			?>
			<a class="lp-button button" href="<?php echo esc_url( get_the_permalink() ); ?>"><?php echo esc_html( $text ); ?></a>
			<?php
		}

		/**
		 * Get url account page
		 */
		public function get_login_page_url( $redirect_url = '' ) {
			$page = get_page_by_path( 'account' );
			if ( $page ) {
				return ! empty( $redirect_url ) ? add_query_arg( 'redirect_to', urlencode( $redirect_url ), get_permalink( $page[0] ) ) : get_permalink( $page->ID );
			}

			return wp_login_url();
		}

		/**
		 * Get membership level price
		 *
		 * @param mixed $level Membership level.
		 */
		public function get_membership_level_price( $level ) {
			if ( pmpro_isLevelFree( $level ) ): ?>
				<?php esc_html_e( 'Free', 'maxcoach' ); ?>
			<?php else: ?>
				<?php
				global $pmpro_currency, $pmpro_currency_symbol, $pmpro_currencies;

				$price = $level->initial_payment;
				//start with the price formatted with two decimals
				$formatted = number_format( (float) $price, 0 );

				//settings stored in array?
				if ( ! empty( $pmpro_currencies[ $pmpro_currency ] ) && is_array( $pmpro_currencies[ $pmpro_currency ] ) ) {
					//format number do decimals, with decimal_separator and thousands_separator
					$formatted = number_format( $price, ( isset( $pmpro_currencies[ $pmpro_currency ]['decimals'] ) ? (int) $pmpro_currencies[ $pmpro_currency ]['decimals'] : 2 ),
						( isset( $pmpro_currencies[ $pmpro_currency ]['decimal_separator'] ) ? $pmpro_currencies[ $pmpro_currency ]['decimal_separator'] : '.' ),
						( isset( $pmpro_currencies[ $pmpro_currency ]['thousands_separator'] ) ? $pmpro_currencies[ $pmpro_currency ]['thousands_separator'] : ',' ) );

					//which side is the symbol on?
					if ( ! empty( $pmpro_currencies[ $pmpro_currency ]['position'] ) && $pmpro_currencies[ $pmpro_currency ]['position'] == 'left' ) {
						$formatted = $pmpro_currency_symbol . $formatted;
					} else {
						$formatted = $formatted . $pmpro_currency_symbol;
					}
				} else {
					$formatted = $pmpro_currency_symbol . $formatted;
				}    //default to symbol on the left

				//filter
				$cost_text = apply_filters( 'pmpro_format_price', $formatted, $price, $pmpro_currency, $pmpro_currency_symbol );

				echo ent2ncr( $cost_text ); ?>
			<?php endif;
		}

		public function get_course_image( $course_id, $size = '480x298' ) {
			$image = '';

			// Used thumbnail size setting.
			$image_size = LP()->settings->get( 'course_thumbnail_dimensions' );

			if ( ! empty( $image_size ) && ( ! empty( $image_size['width'] ) || ! empty( $image_size['height'] ) ) ) {
				$image_size_width = $image_size_height = 9999;

				if ( ! empty( $image_size['width'] ) ) {
					$image_size_width = $image_size['width'];
				}

				if ( ! empty( $image_size['height'] ) ) {
					$image_size_height = $image_size['height'];
				}

				$size = "{$image_size_width}x{$image_size_height}";
			}

			if ( has_post_thumbnail( $course_id ) ) {
				$image = Maxcoach_Image::get_the_post_thumbnail( [
					'post_id' => $course_id,
					'size'    => $size,
				] );
			} elseif ( ( $parent_id = wp_get_post_parent_id( $course_id ) ) && has_post_thumbnail( $parent_id ) ) {
				$image = Maxcoach_Image::get_the_post_thumbnail( [
					'post_id' => $parent_id,
					'size'    => $size,
				] );
			}

			if ( empty( $image ) ) {
				$image = Maxcoach_Image::build_img_tag( [
					'src' => LearnPress::instance()->image( 'no-image.png' ),
				] );
			}

			return $image;
		}

		public function entry_course_thumbnail() {
			$thumbnail_enable = Maxcoach::setting( 'single_course_featured_image_enable' );

			if ( '1' !== $thumbnail_enable || ! has_post_thumbnail() ) {
				return;
			}
			?>
			<div class="entry-course-thumbnail">
				<?php
				Maxcoach_Image::the_post_thumbnail( [
					'size' => '770x450',
				] );
				?>
			</div>
			<?php
		}

		public function get_the_categories() {
			$id    = get_the_ID();
			$terms = get_the_terms( $id, self::TAXONOMY_CATEGORY );

			return $terms;
		}

		public function get_the_tags() {
			$id    = get_the_ID();
			$terms = get_the_terms( $id, self::TAXONOMY_TAGS );

			return $terms;
		}

		public function get_related_courses( $args ) {
			$defaults = array(
				'post_id'      => '',
				'number_posts' => 3,
			);
			$args     = wp_parse_args( $args, $defaults );

			if ( $args['number_posts'] <= 0 || $args['post_id'] === '' ) {
				return false;
			}

			$related_by = Maxcoach::setting( 'course_related_by' );

			if ( empty( $related_by ) ) {
				return false;
			}

			$query_args = array(
				'post_type'      => self::POST_TYPE,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'posts_per_page' => $args['number_posts'],
				'post__not_in'   => array( $args['post_id'] ),
				'no_found_rows'  => true,
			);

			if ( in_array( 'category', $related_by, true ) ) {
				$terms = $this->get_the_categories();

				if ( $terms && ! is_wp_error( $terms ) ) {

					$term_ids = array();

					foreach ( $terms as $category ) {
						if ( $category->parent === 0 ) {
							$term_ids[] = $category->term_id;
						} else {
							$term_ids[] = $category->parent;
							$term_ids[] = $category->term_id;
						}
					}

					// Remove duplicate values from the array.
					$unique_term_ids = array_unique( $term_ids );

					if ( empty( $query_args['tax_query'] ) ) {
						$query_args['tax_query'] = [];
					}

					$query_args['tax_query'][] = array(
						'taxonomy'         => self::TAXONOMY_CATEGORY,
						'terms'            => $unique_term_ids,
						'include_children' => false,
					);
				}
			}

			if ( in_array( 'tags', $related_by, true ) ) {
				$terms = $this->get_the_tags();

				if ( $terms && ! is_wp_error( $terms ) ) {
					$term_ids = array();

					foreach ( $terms as $tag ) {
						if ( $tag->parent === 0 ) {
							$term_ids[] = $tag->term_id;
						} else {
							$term_ids[] = $tag->parent;
							$term_ids[] = $tag->term_id;
						}
					}

					// Remove duplicate values from the array.
					$unique_term_ids = array_unique( $term_ids );

					if ( empty( $query_args['tax_query'] ) ) {
						$query_args['tax_query'] = [];
					}

					$query_args['tax_query'][] = array(
						'taxonomy'         => self::TAXONOMY_TAGS,
						'terms'            => $unique_term_ids,
						'include_children' => false,
					);
				}
			}

			if ( isset( $query_args['tax_query'] ) && count( $query_args['tax_query'] ) > 1 ) {
				$query_args['tax_query']['relation'] = 'OR';
			}

			$query = new WP_Query( $query_args );

			wp_reset_postdata();

			return $query;
		}

		public function update_db_252() {
			$message = sprintf( '<strong>%1$s</strong><br/><a href="%2$s" class="button">Go to Update</a>', __( 'Maxcoach update - We need to update your database to the latest version.', 'maxcoach' ),
				wp_nonce_url( admin_url( 'themes.php' ), 'theme_update_database', 'maxcoach_nonce' ) );

			printf( '<div class="notice notice-warning"><p>%1$s</p></div>', $message );
		}

		/**
		 * Re-sync the sort price of every course (admin clicks the notice, see DB_VERSION).
		 */
		public function maxcoach_update_db() {
			$maxcoach_db_version = get_option( 'maxcoach_db_version' );
			if ( empty( $maxcoach_db_version ) || version_compare( $maxcoach_db_version, self::DB_VERSION, '<' ) ) {
				if ( isset( $_GET['maxcoach_nonce'] ) && wp_verify_nonce( sanitize_key( wp_unslash( $_GET['maxcoach_nonce'] ) ), 'theme_update_database' ) && current_user_can( 'manage_options' ) ) {
					$course_ids = get_posts(
						array(
							'post_type'              => self::POST_TYPE,
							'post_status'            => 'any',
							'posts_per_page'         => -1,
							'fields'                 => 'ids',
							'no_found_rows'          => true,
							'update_post_term_cache' => false,
						)
					);

					foreach ( $course_ids as $course_id ) {
						$this->save_course_sale_price( $course_id );
					}

					update_option( 'maxcoach_db_version', self::DB_VERSION );
				}
			}
		}
	}

	Maxcoach_LP_Course::instance()->initialize();
}
