jQuery( document ).ready( function( $ ) {
	'use strict';

	var $body = $( 'body' );

	initProductImagesSlider();
	initQuickViewPopup();

	function initProductImagesSlider() {
		if ( $maxcoach.isProduct !== '1' ) {
			return;
		}

		var $singleInfo = $( '#woo-single-info' );
		var $defaultGallery = $singleInfo.find( '.maxcoach-product-gallery' ).first();

		// Old product-image.php markup, e.g. overridden in child theme.
		if ( ! $defaultGallery.length ) {
			$defaultGallery = $singleInfo.find( '.woo-single-gallery' ).first().parent();
		}

		if ( ! $defaultGallery.length ) {
			return;
		}

		var $currentGallery = $defaultGallery;
		var currentVariationId = 0;

		initGallerySliders( $defaultGallery );

		/**
		 * Use WC variation events, they also fire in ajax mode (more than 30 variations).
		 * WC 10.8+ sends gallery_images_html (product-image.php of this theme rendered with the variation images)
		 * for variations that have a gallery. Other variations slide to the variation image if the gallery has it.
		 */
		$singleInfo.find( '.variations_form' ).on( 'found_variation', function( event, variation ) {
			if ( ! variation ) {
				return;
			}

			var $variationGallery = parseVariationGallery( variation.gallery_images_html );

			if ( $variationGallery ) {
				if ( currentVariationId !== variation.variation_id ) {
					showGallery( $variationGallery );
					currentVariationId = variation.variation_id;
				}

				return;
			}

			showGallery( $defaultGallery );
			restoreMainImage( $defaultGallery );

			// Like WC core: show variation image in place of main image if the gallery doesn't have it.
			if ( ! slideToImage( $defaultGallery, variation.image_id ) && setMainImage( $defaultGallery, variation.image ) ) {
				slideToImage( $defaultGallery, 0 );
			}
		} ).on( 'reset_data', function() {
			showGallery( $defaultGallery );
			restoreMainImage( $defaultGallery );
			slideToImage( $defaultGallery, 0 );
		} );

		function parseVariationGallery( html ) {
			html = html ? String( html ).trim() : '';

			if ( '' === html ) {
				return false;
			}

			var $gallery = $( $.parseHTML( html ) ).filter( '.maxcoach-product-gallery' ).first();

			// Ajax renders may resolve another layout, only swap the same one.
			if ( ! $gallery.length || ! $gallery.hasClass( 'feature-style-' + $maxcoach.productFeatureStyle ) ) {
				return false;
			}

			return $gallery;
		}

		function showGallery( $gallery ) {
			if ( $gallery.is( $currentGallery ) ) {
				return;
			}

			var lightGalleryDelay = 0;

			// Keep default gallery in the DOM to restore it without re-init.
			if ( $currentGallery.is( $defaultGallery ) ) {
				$defaultGallery.hide();
			} else {
				lightGalleryDelay = destroyGallery( $currentGallery );
			}

			$currentGallery = $gallery;

			if ( $gallery.is( $defaultGallery ) ) {
				$defaultGallery.show();
				updateGallerySliders( $defaultGallery );
				currentVariationId = 0;
			} else {
				$defaultGallery.after( $gallery );
				initGallerySliders( $gallery );

				if ( $gallery.hasClass( 'maxcoach-light-gallery' ) ) {
					initGalleryLightbox( $gallery, lightGalleryDelay );
				}
			}

			$( document.body ).trigger( 'sticky_kit:recalc' );
		}

		function initGalleryLightbox( $gallery, delay ) {
			var init = function() {
				// Gallery may be replaced while waiting.
				if ( $gallery.is( $currentGallery ) ) {
					// Own gallery id, lightGallery opens gallery "1" if url has #lg=1.
					$( document ).trigger( 'MaxcoachInitLightGallery', [ $gallery, { galleryId: 'maxcoach-variation' } ] );
				}
			};

			if ( delay > 0 ) {
				setTimeout( init, delay );
			} else {
				init();
			}
		}

		function initGallerySliders( $gallery ) {
			var $sliderWrap = $gallery.children( '.woo-single-gallery' );

			if ( ! $sliderWrap.length ) {
				return;
			}

			var options = {};
			var thumbsSlider = null;

			if ( $sliderWrap.hasClass( 'has-thumbs-slider' ) ) {
				thumbsSlider = $sliderWrap.children( '.maxcoach-thumbs-swiper' ).MaxcoachSwiper();
				options = {
					thumbs: {
						swiper: thumbsSlider
					}
				};
			}

			var mainSlider = $sliderWrap.children( '.maxcoach-main-swiper' ).MaxcoachSwiper( options );

			$gallery.data( 'maxcoachSliders', {
				main: mainSlider,
				thumbs: thumbsSlider
			} );
		}

		function updateGallerySliders( $gallery ) {
			var sliders = $gallery.data( 'maxcoachSliders' );

			if ( ! sliders ) {
				return;
			}

			if ( sliders.thumbs ) {
				sliders.thumbs.update();
			}

			if ( sliders.main ) {
				sliders.main.update();
			}
		}

		/**
		 * @param $gallery
		 * @return {number} Delay (ms) before init lightGallery of new gallery.
		 */
		function destroyGallery( $gallery ) {
			var sliders = $gallery.data( 'maxcoachSliders' );
			var lightGallery = $gallery.data( 'lightGallery' );
			var delay = 0;

			if ( sliders ) {
				if ( sliders.main ) {
					sliders.main.destroy( true, true );
				}

				if ( sliders.thumbs ) {
					sliders.thumbs.destroy( true, true );
				}
			}

			/*
			 * lightGallery destroy() removes all .lg-backdrop (after backdropDuration) and all window .lg events,
			 * of other instances too. Only an opened lightbox needs it, remove() below cleans a closed one.
			 */
			if ( lightGallery && lightGallery.lGalleryOn ) {
				lightGallery.destroy( true );
				delay = ( parseInt( lightGallery.s.backdropDuration, 10 ) || 0 ) + 100;
			}

			$gallery.remove();

			return delay;
		}

		/**
		 * @param $gallery
		 * @param imageId Attachment id, 0 to slide to the main image.
		 * @return {boolean} Gallery has the image.
		 */
		function slideToImage( $gallery, imageId ) {
			var sliders = $gallery.data( 'maxcoachSliders' );

			if ( ! sliders || ! sliders.main ) {
				return false;
			}

			var $slides = $( sliders.main.wrapperEl ).children( '.swiper-slide' );
			var $slide = imageId ? $slides.filter( '[data-image-id="' + parseInt( imageId, 10 ) + '"]' ) : $slides.filter( '.product-main-image' );

			if ( ! imageId && ! $slide.length ) {
				$slide = $slides.first();
			}

			if ( ! $slide.length ) {
				return false;
			}

			sliders.main.slideTo( $slides.index( $slide.first() ) );

			return true;
		}

		/**
		 * Main image element of the gallery layout (slider, list, single).
		 */
		function getMainImageItem( $gallery ) {
			var $item = $gallery.find( '.product-main-image' ).first();

			if ( ! $item.length ) {
				$item = $gallery.find( '.zoom' ).first();
			}

			return $item.length ? $item : $gallery;
		}

		/**
		 * @param $gallery
		 * @param image Variation image props (wc_get_product_attachment_props()).
		 * @return {boolean} Main image was changed.
		 */
		function setMainImage( $gallery, image ) {
			if ( ! image || ! ( image.full_src || image.src ) ) {
				return false;
			}

			var $item = getMainImageItem( $gallery );
			var $img = $item.find( 'img' ).first();

			if ( ! $img.length ) {
				return false;
			}

			var changes = [];

			// Theme images are cropped by theme sizes (no srcset), full image fits all layouts.
			changes.push( changeAttrs( $img, {
				src: image.full_src || image.src,
				srcset: null,
				sizes: null,
				alt: image.alt || '',
				width: image.full_src_w || image.src_w || null,
				height: image.full_src_h || image.src_h || null
			} ) );

			var itemAttrs = {};

			if ( image.full_src && undefined !== $item.attr( 'data-src' ) ) {
				itemAttrs[ 'data-src' ] = image.full_src;
			}

			if ( image.full_src && undefined !== $item.attr( 'href' ) ) {
				itemAttrs.href = image.full_src;
			}

			// Lightbox caption, same markup as product-image.php.
			if ( ! $item.is( $gallery ) && ( undefined !== $item.attr( 'data-sub-html' ) || image.title || image.caption ) ) {
				var subHtml = '';

				if ( image.title ) {
					subHtml += '<h4>' + escapeHtml( image.title ) + '</h4>';
				}

				if ( image.caption ) {
					subHtml += '<p>' + escapeHtml( image.caption ) + '</p>';
				}

				itemAttrs[ 'data-sub-html' ] = subHtml || null;
			}

			changes.push( changeAttrs( $item, itemAttrs ) );

			// Thumbnail of main image in thumbs slider.
			var $thumbImg = $gallery.find( '.maxcoach-thumbs-swiper .swiper-slide' ).eq( $item.index() ).find( 'img' ).first();

			if ( $item.hasClass( 'swiper-slide' ) && $thumbImg.length && image.gallery_thumbnail_src ) {
				changes.push( changeAttrs( $thumbImg, {
					src: image.gallery_thumbnail_src,
					srcset: null,
					sizes: null
				} ) );
			}

			$gallery.data( 'maxcoachMainImage', changes );

			return true;
		}

		/**
		 * @param $el
		 * @param attrs Attribute values, null to remove.
		 * @return {object} Original values to restore.
		 */
		function changeAttrs( $el, attrs ) {
			var original = {};

			$.each( attrs, function( name, value ) {
				original[ name ] = $el.attr( name );

				if ( null === value ) {
					$el.removeAttr( name );
				} else {
					$el.attr( name, value );
				}
			} );

			return { $el: $el, original: original };
		}

		function escapeHtml( text ) {
			return $( '<div>' ).text( text ).html();
		}

		function restoreMainImage( $gallery ) {
			var changes = $gallery.data( 'maxcoachMainImage' );

			if ( ! changes ) {
				return;
			}

			$.each( changes, function( i, change ) {
				$.each( change.original, function( name, value ) {
					if ( undefined === value ) {
						change.$el.removeAttr( name );
					} else {
						change.$el.attr( name, value );
					}
				} );
			} );

			$gallery.removeData( 'maxcoachMainImage' );
		}
	}

	function initQuickViewPopup() {
		$( '.maxcoach-product' ).on( 'click.maxcoachQuickView', '.quick-view-btn', onQuickViewClick );

		// WC replaces cart form (with cross-sells products) after cart updated via ajax.
		$( document.body ).on( 'updated_wc_div', function() {
			$( '.woocommerce-cart-form .maxcoach-product' ).off( 'click.maxcoachQuickView' ).on( 'click.maxcoachQuickView', '.quick-view-btn', onQuickViewClick );
		} );
	}

	function onQuickViewClick( e ) {
		e.preventDefault();
		e.stopPropagation();

		var $button = $( this );

		var $actions = $button.parents('.product-actions').first();
		$actions.addClass('refresh');

		$button.addClass( 'loading' );
		var productID = $button.data( 'pid' );

		/**
		 * Avoid duplicate ajax request.
		 */
		var $popup = $body.children( '#' + 'popup-product-quick-view-content-' + productID );
		if ( $popup.length > 0 ) {
			openQuickViewPopup( $popup, $button );
		} else {
			var data = {
				action: 'product_quick_view',
				pid: productID,
				security: $button.data( 'pnonce' )
			};

			$.ajax( {
				url: $maxcoach.ajaxurl,
				type: 'POST',
				data: $.param( data ),
				dataType: 'json',
				success: function( results ) {
					$popup = $( results.template );
					$body.append( $popup );
					openQuickViewPopup( $popup, $button );
				},
				error: function() {
					$button.removeClass( 'loading' );
				}
			} );
		}
	}

	function openQuickViewPopup( $popup, $button ) {
		$button.removeClass( 'loading' );

		$.magnificPopup.open( {
			mainClass: 'mfp-fade popup-product-quick-view',
			items: {
				src: $popup.html(),
				type: 'inline'
			},
			callbacks: {
				open: function() {
					var $sliderWrap = this.content.find( '.woo-single-gallery' );
					var thumbsSlider = $sliderWrap.children( '.maxcoach-thumbs-swiper' ).MaxcoachSwiper();
					var mainSlider = $sliderWrap.children( '.maxcoach-main-swiper' ).MaxcoachSwiper( {
						thumbs: {
							swiper: thumbsSlider
						}
					} );

					this.content.find( '.entry-summary .inner-content' ).perfectScrollbar( {
						suppressScrollX: true
					} );

					// Variation form is loaded via ajax, WC only inits forms on page load.
					if ( 'function' === typeof $.fn.wc_variation_form && 'undefined' !== typeof wc_add_to_cart_variation_params ) {
						this.content.find( '.variations_form' ).each( function() {
							$( this ).wc_variation_form();
						} );
					}
				},
			}
		} );
	}
} );
