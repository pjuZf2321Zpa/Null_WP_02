<?php
/**
 * Show options for ordering
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/orderby.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     9.7.0
 */

defined( 'ABSPATH' ) || exit;

$maxcoach_orderby_id = 'woocommerce-orderby-' . wp_unique_id();
?>
<div class="shop-filter-right col-md-6">

	<form class="woocommerce-ordering" method="get">
		<?php // $use_label is passed since WC 9.7.0. ?>
		<?php if ( ! empty( $use_label ) ) : ?>
			<label for="<?php echo esc_attr( $maxcoach_orderby_id ); ?>"><?php echo esc_html__( 'Sort by', 'maxcoach' ); ?></label>
		<?php endif; ?>
		<?php
		$select_settings = [
			'fieldLabel' => esc_html__( 'Sort by:', 'maxcoach' ),
		];
		?>
		<select name="orderby" class="maxcoach-nice-select orderby"
			<?php if ( ! empty( $use_label ) ) : ?>
				id="<?php echo esc_attr( $maxcoach_orderby_id ); ?>"
			<?php else : ?>
				aria-label="<?php esc_attr_e( 'Shop order', 'maxcoach' ); ?>"
			<?php endif; ?>
			    data-select="<?php echo esc_attr( wp_json_encode( $select_settings ) ); ?>">
			<?php foreach ( $catalog_orderby_options as $id => $name ) : ?>
				<option
					value="<?php echo esc_attr( $id ); ?>" <?php selected( $orderby, $id ); ?>><?php echo esc_html( $name ); ?></option>
			<?php endforeach; ?>
		</select>
		<input type="hidden" name="paged" value="1"/>
		<?php wc_query_string_form_fields( null, array( 'orderby', 'submit', 'paged', 'product-page' ) ); ?>
	</form>

</div>
