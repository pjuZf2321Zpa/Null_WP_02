<?php
/**
 * Cart Page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 11.2.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_cart' );
?>

<form class="woocommerce-cart-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
	<?php do_action( 'woocommerce_before_cart_table' ); ?>

	<table class="shop_table shop_table_responsive cart woocommerce-cart-form__contents" cellspacing="0">
		<thead>
		<tr>
			<th scope="col" class="product-thumbnail"><?php esc_html_e( 'Product', 'maxcoach' ); ?></th>
			<th scope="col" class="product-name"><span class="screen-reader-text"><?php esc_html_e( 'Product name', 'maxcoach' ); ?></span></th>
			<th scope="col" class="product-price"><?php esc_html_e( 'Price', 'maxcoach' ); ?></th>
			<th scope="col" class="product-quantity"><?php esc_html_e( 'Quantity', 'maxcoach' ); ?></th>
			<th scope="col" class="product-subtotal"><?php esc_html_e( 'Subtotal', 'maxcoach' ); ?></th>
			<th scope="col" class="product-remove"><span class="screen-reader-text"><?php esc_html_e( 'Remove item', 'maxcoach' ); ?></span></th>
		</tr>
		</thead>
		<tbody>
		<?php do_action( 'woocommerce_before_cart_contents' ); ?>

		<?php
		foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			$_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
			$product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

			/**
			 * Filter whether this cart item is visible in the cart.
			 *
			 * @since 2.1.0
			 * @param bool   $visible     Whether the cart item is visible. Default true.
			 * @param array  $cart_item     The cart item data.
			 * @param string $cart_item_key The cart item key.
			 */
			$visible = apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key );

			if ( $_product instanceof WC_Product && $_product->exists() && $cart_item['quantity'] > 0 && $visible ) {
				// WC 11.2+: name with the selected "Any" attributes. Fallback for older WC.
				$cart_item_name = method_exists( WC()->cart, 'get_item_product_name' ) ? WC()->cart->get_item_product_name( $cart_item, $_product ) : $_product->get_name();

				/**
				 * Filter the product name.
				 *
				 * @param string $product_name  Name of the product in the cart.
				 * @param array  $cart_item     The product in the cart.
				 * @param string $cart_item_key Key for the product in the cart.
				 *
				 * @since 2.1.0
				 */
				$product_name      = apply_filters( 'woocommerce_cart_item_name', $cart_item_name, $cart_item, $cart_item_key );
				$product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
				?>
				<tr class="woocommerce-cart-form__cart-item <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">
					<td class="product-thumbnail">
						<?php
						$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image( 'widget-product' ), $cart_item, $cart_item_key );

						if ( ! $product_permalink ) {
							echo '' . $thumbnail;
						} else {
							printf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $thumbnail );
						}
						?>
					</td>

					<td role="rowheader" class="product-name">
						<?php
						if ( ! $product_permalink ) {
							echo wp_kses_post( sprintf( '<h6 class="product-title">%s</h6>', $product_name ) );
						} else {
							/**
							 * This filter is documented above.
							 *
							 * @since 2.1.0
							 */
							echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', sprintf( '<h6 class="product-title"><a href="%s">%s</a></h6>', esc_url( $product_permalink ), $cart_item_name ), $cart_item,
								$cart_item_key ) );
						}

						do_action( 'woocommerce_after_cart_item_name', $cart_item, $cart_item_key );

						// Meta data.
						// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo wc_get_formatted_cart_item_data( $cart_item, false, $cart_item_name );

						// Backorder notification.
						if ( $_product->backorders_require_notification() && $_product->is_on_backorder( $cart_item['quantity'] ) ) {
							echo wp_kses_post( apply_filters( 'woocommerce_cart_item_backorder_notification', '<p class="backorder_notification">' . esc_html__( 'Available on backorder', 'maxcoach' ) . '</p>', $product_id ) );
						}
						?>
					</td>

					<td class="product-price" data-title="<?php esc_attr_e( 'Price', 'maxcoach' ); ?>">
						<?php
						echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
						?>
					</td>

					<td class="product-quantity" data-title="<?php esc_attr_e( 'Quantity', 'maxcoach' ); ?>">
						<?php
						if ( $_product->is_sold_individually() ) {
							$min_quantity = 1;
							$max_quantity = 1;
						} else {
							$min_quantity = 0;
							$max_quantity = $_product->get_max_purchase_quantity();
						}

						$product_quantity = woocommerce_quantity_input( array(
							'input_name'   => "cart[{$cart_item_key}][qty]",
							'input_value'  => $cart_item['quantity'],
							'max_value'    => $max_quantity,
							'min_value'    => $min_quantity,
							'product_name' => $product_name,
						), $_product, false );

						echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item ); // PHPCS: XSS ok.
						?>
					</td>

					<td class="product-subtotal" data-title="<?php esc_attr_e( 'Subtotal', 'maxcoach' ); ?>">
						<label><?php esc_html_e( 'Subtotal :', 'maxcoach' ); ?></label>
						<?php
						echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); // PHPCS: XSS ok.
						?>
					</td>

					<td class="product-remove">
						<?php
						// @codingStandardsIgnoreLine
						echo apply_filters( 'woocommerce_cart_item_remove_link',
							sprintf( '<a role="button" href="%s" class="%s" title="%s" data-product_id="%s" data-product_sku="%s"><div class="button-content-wrapper"><span class="button-text">%s</span></div></a>',
								esc_url( wc_get_cart_remove_url( $cart_item_key ) ), esc_attr( 'tm-button style-bottom-line' ), esc_attr__( 'Remove this item', 'maxcoach' ), esc_attr( $product_id ), esc_attr( $_product->get_sku() ),
								esc_html__( 'Remove', 'maxcoach' ) ), $cart_item_key );
						?>
					</td>
				</tr>
				<?php
			}
		}

		do_action( 'woocommerce_cart_contents' );
		?>
		<tr>
			<td colspan="6" class="actions">

				<div class="actions-wrap">
					<?php if ( wc_coupons_enabled() ) { ?>
						<div class="coupon-wrap">
							<div class="coupon">
								<label for="coupon_code"
								       class="screen-reader-text"><?php esc_html_e( 'Coupon:', 'maxcoach' ); ?></label>
								<input type="text" name="coupon_code" class="input-text" id="coupon_code" value=""
								       placeholder="<?php esc_attr_e( 'Coupon code', 'maxcoach' ); ?>"/>

								<button type="submit"
								        class="button<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>"
								        name="apply_coupon"
								        value="<?php esc_attr_e( 'Apply coupon', 'maxcoach' ); ?>"><?php esc_attr_e( 'Apply coupon', 'maxcoach' ); ?></button>
								<?php do_action( 'woocommerce_cart_coupon' ); ?>
							</div>
						</div>
					<?php } ?>

					<div class="actions-buttons">
						<a class="button btn-empty-cart"
						   href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'empty-cart', '1', wc_get_cart_url() ), 'woocommerce-cart' ) ); ?>">
							<?php esc_html_e( 'Empty cart', 'maxcoach' ); ?>
						</a>

						<button type="submit"
						        class="button<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>"
						        name="update_cart"
						        value="<?php esc_attr_e( 'Update cart', 'maxcoach' ); ?>"><?php esc_html_e( 'Update cart', 'maxcoach' ); ?></button>

						<?php do_action( 'woocommerce_cart_actions' ); ?>

						<?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
					</div>
				</div>

			</td>
		</tr>

		<?php do_action( 'woocommerce_after_cart_contents' ); ?>
		</tbody>
	</table>

	<?php do_action( 'woocommerce_after_cart_table' ); ?>

</form>

<?php do_action( 'woocommerce_before_cart_collaterals' ); ?>

<div class="cart-collaterals">
	<?php
	/**
	 * Cart collaterals hook.
	 *
	 * @hooked woocommerce_cross_sell_display
	 * @hooked woocommerce_cart_totals - 10
	 */
	do_action( 'woocommerce_cart_collaterals' );
	?>
</div>

<?php do_action( 'woocommerce_after_cart' ); ?>
