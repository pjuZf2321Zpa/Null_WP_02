<?php
/**
 * Single Product Meta
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/meta.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     11.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;
?>
<div class="entry-product-meta product_meta">

	<?php do_action( 'woocommerce_product_meta_start' ); ?>

	<?php // Use string instead of Automattic\WooCommerce\Enums\ProductType (WC 9.7+) to keep older WC working. ?>
	<?php if ( wc_product_sku_enabled() && ( $product->get_sku() || $product->is_type( 'variable' ) ) ) : ?>
		<div class="sku_wrapper meta-item">
			<h6><?php esc_html_e( 'SKU:', 'maxcoach' ); ?></h6>
			<div class="meta-content">
				<span class="sku">
					<?php if ( $sku = $product->get_sku() ) : ?>
						<?php Maxcoach_Helper::e( $sku ); ?>
					<?php else: ?>
						<?php esc_html_e( 'N/A', 'maxcoach' ); ?>
					<?php endif; ?>
				</span>
			</div>
		</div>
	<?php endif; ?>

	<?php if ( Maxcoach::setting( 'single_product_categories_enable' ) === '1' ) : ?>
		<?php
		/**
		 * Filters the ordering mode for product categories in the single product meta.
		 *
		 * @param string     $orderby Ordering mode passed to wc_get_product_category_list().
		 * @param WC_Product $product Product object.
		 *
		 * @since 11.2.0
		 */
		$product_category_orderby = apply_filters( 'woocommerce_product_meta_category_orderby', 'breadcrumb', $product ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WC core hook. Template-scoped variable.

		// WC < 11.2 ignores the $orderby argument.
		$product_category_list = wc_get_product_category_list( // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template-scoped variable.
			$product->get_id(),
			' / ',
			'<div class="posted_in meta-item"><h6>' . _n( 'Category:', 'Categories:', count( $product->get_category_ids() ), 'maxcoach' ) . '</h6><div class="meta-content">',
			'</div></div>',
			is_string( $product_category_orderby ) ? $product_category_orderby : ''
		);
		echo is_string( $product_category_list ) ? $product_category_list : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		?>
	<?php endif; ?>

	<?php if ( Maxcoach::setting( 'single_product_tags_enable' ) === '1' ) : ?>
		<?php echo wc_get_product_tag_list( $product->get_id(), ' / ', '<div class="tagged_as meta-item"><h6>' . _n( 'Tag:', 'Tags:', count( $product->get_tag_ids() ), 'maxcoach' ) . '</h6><div class="meta-content">', '</div></div>' ); ?>
	<?php endif; ?>

	<?php do_action( 'woocommerce_product_meta_end' ); ?>

</div>
