<?php
/**
 * The Template for displaying location in single event page.
 *
 * Override this template by copying it to yourtheme/wp-events-manager/loop/location.php
 *
 * @author        ThimPress, leehld
 * @package       WP-Events-Manager/Template
 * @version       2.1.7
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();
?>

<?php
$maxcoach_location = wpems_event_location();
$maxcoach_iframe   = get_post_meta( get_the_ID(), 'tp_event_iframe', true );
$maxcoach_has_map  = wpems_get_option( 'google_map_api_key' ) && $maxcoach_location;
?>

<?php if ( $maxcoach_location || $maxcoach_iframe ) : ?>
	<div class="entry-location">
		<?php
		if ( $maxcoach_has_map ) {
			// Render Google Map via API key + address.
			wpems_get_location_map();
		} elseif ( $maxcoach_iframe ) {
			// Fallback: render the embedded map iframe (no Google Map API key needed).
			$maxcoach_allowed_iframe = array(
				'iframe' => array(
					'src'             => true,
					'width'           => true,
					'height'          => true,
					'style'           => true,
					'class'           => true,
					'id'              => true,
					'name'            => true,
					'title'           => true,
					'frameborder'     => true,
					'scrolling'       => true,
					'marginwidth'     => true,
					'marginheight'    => true,
					'allow'           => true,
					'allowfullscreen' => true,
					'loading'         => true,
					'referrerpolicy'  => true,
					'sandbox'         => true,
				),
			);
			?>
			<div class="event-location-iframe">
				<?php echo wp_kses( $maxcoach_iframe, $maxcoach_allowed_iframe ); ?>
			</div>
			<?php
		}
		?>
	</div>

	<?php if ( $maxcoach_location ) : ?>
		<div class="entry-location-address">
			<span class="fal fa-map-marker-alt primary-color"></span>
			<?php echo esc_html( $maxcoach_location ); ?>
		</div>
	<?php endif; ?>
<?php endif; ?>
