<?php

defined( 'ABSPATH' ) || exit;

class RSTheme_Demo_Config {

	public function __construct() {
		add_filter( 'ocdi/plugin_page_setup', [ $this, 'plugin_page_setup' ] );
		add_filter( 'ocdi/plugin_intro_text', [ $this, 'plugin_intro_text' ] );
		add_filter( 'ocdi/import_files', [ $this, 'import_files' ] );
		add_action( 'ocdi/before_widgets_import', [ $this, 'before_widgets_import' ] );
		add_action( 'ocdi/after_import', [ $this, 'after_import_demo' ] );
		add_filter( 'ocdi/register_plugins', [ $this, 'register_plugins' ] );
	}

	public function plugin_page_setup( $default_settings ): array {
		$default_settings[ 'capability' ] = 'manage_options';
		$default_settings[ 'menu_slug' ]  = 'reobiz-demo-import';

		return $default_settings;
	}

	public function plugin_intro_text(): string {
		ob_start();
		?>
        <div class="ocdi__intro-text">
			<?php
			esc_html_e(
				'Import any of the demo sites below. This feature is recommended for fresh installations. Please do not refresh the page while the demo data is being imported.',
				'reobiz'
			);
			?>
        </div>
		<?php
		return ob_get_clean();
	}

	public function import_files(): array {
		$demos_array = [];
		$demos       = $this->demo_files();

		foreach ( $demos as $value ) {
			$demos_array[] = [
				'import_file_name'           => $value[ 'name' ] ?? '',
				'categories'                 => $value[ 'categories' ] ?? [],
				'import_file_url'            => $value[ 'content' ] ?? '',
				'import_widget_file_url'     => $value[ 'widgets' ] ?? '',
				'import_customizer_file_url' => $value[ 'customizer' ] ?? '',
				'import_preview_image_url'   => $value[ 'preview' ] ?? '',
				'preview_url'                => $value[ 'preview_url' ] ?? '',
				'import_redux'               => $value[ 'redux' ] ?? [],
				'elementor_kit'              => $value[ 'elementor_kit' ] ?? '',
				'revslider'                  => $value[ 'revslider' ] ?? '',
				'onepage'                    => $value[ 'onepage' ] ?? false,
			];
		}

		return $demos_array;
	}

	public function before_widgets_import( $selected_import ): void {
		update_option( 'sidebars_widgets', [ 'wp_inactive_widgets' => [] ] );
	}

	public function after_import_demo( $selected_import ): void {
		// Set Menus
		$main_menu   = wp_get_nav_menu_object( 'Main Menu' );
		$single_menu = wp_get_nav_menu_object( 'Single Menu' );
		$mobile_menu = wp_get_nav_menu_object( 'Mobile Menu' );

		set_theme_mod( 'nav_menu_locations', [
			'menu-1' => $main_menu ? $main_menu->term_id : 0,
			'menu-2' => $single_menu ? $single_menu->term_id : 0,
			'menu-3' => $mobile_menu ? $mobile_menu->term_id : 0,
		] );

		$front_page_title = ! empty( $selected_import[ 'onepage' ] ) ? 'Onepage' : 'Home';
		$blog_page_title  = 'Blog';

		$front_page = get_posts( [
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'title'          => $front_page_title,
			'fields'         => 'ids',
		] );

		$blog_page = get_posts( [
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'title'          => $blog_page_title,
			'fields'         => 'ids',
		] );

		update_option( 'show_on_front', 'page' );

		if ( ! empty( $front_page ) ) {
			update_option( 'page_on_front', $front_page[ 0 ] );
		}

		if ( ! empty( $blog_page ) ) {
			update_option( 'page_for_posts', $blog_page[ 0 ] );
		}

		if ( ! empty( $selected_import[ 'elementor_kit' ] ) && class_exists( '\Elementor\Plugin' ) ) {
			$kit = get_template_directory() . '/ocdi/kits/' . $selected_import[ 'elementor_kit' ];

			if ( file_exists( $kit ) ) {
				$import_export_module = \Elementor\Plugin::$instance->app->get_component( 'import-export' );
				$import_export_module->import_kit( $kit, [ 'referrer' => 'remote' ] );
			}
		}

		if ( ! empty( $selected_import[ 'revslider' ] ) && class_exists( 'RevSliderSlider' ) ) {
			$sliders = $selected_import[ 'revslider' ];

			if ( ! is_array( $sliders ) ) {
				$sliders = array( $sliders );
			}

			foreach ( $sliders as $slider ) {
				$slider_path = get_template_directory() . '/ocdi/sliders/' . $slider;

				if ( ! file_exists( $slider_path ) ) {
					continue;
				}

				$rev_slider = new \RevSliderSlider();
				$rev_slider->importSliderFromPost( true, true, $slider_path );
			}
		}

		// Disable Elementor Default schemes
		update_option( 'elementor_disable_color_schemes', 'yes' );
		update_option( 'elementor_disable_typography_schemes', 'yes' );
	}

	public function register_plugins( $plugins ): array {
		$theme_plugins = reobiz_required_plugin();

		return array_merge( $plugins, $theme_plugins );
	}

	public function demo_files(): array {
		return [
			// Multi-Pages
			[
				'name'          => 'Business Main',
				'categories'    => [ 'Business' ],
				'content'       => 'https://reobiztheme.com/demos/business/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/business/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/business/screen.png',
				'preview_url'   => 'https://business.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/business/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'business.zip',
				'revslider'     => 'business.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Business Consultant',
				'categories'    => [ 'Business', 'Consultant' ],
				'content'       => 'https://reobiztheme.com/demos/consultant/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consultant/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consultant/screen.png',
				'preview_url'   => 'https://consultant.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consultant/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consultant.zip',
				'revslider'     => 'consultant.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Business Consulting',
				'categories'    => [ 'Business', 'Consulting' ],
				'content'       => 'https://reobiztheme.com/demos/consulting/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consulting/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consulting/screen.png',
				'preview_url'   => 'https://consulting.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consulting/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consulting.zip',
				'revslider'     => 'consulting.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Digital Agency(SEO)',
				'categories'    => [ 'Agency', 'SEO' ],
				'content'       => 'https://reobiztheme.com/demos/seo/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/seo/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/seo/screen.png',
				'preview_url'   => 'https://seo.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/seo/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'seo.zip',
				'revslider'     => false,
				'onepage'       => false,
			],
			[
				'name'          => 'Law Firm Demo',
				'categories'    => [ 'Law Firm' ],
				'content'       => 'https://reobiztheme.com/demos/lawfirm/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/lawfirm/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/lawfirm/screen.png',
				'preview_url'   => 'https://lawfirm.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/lawfirm/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'lawfirm.zip',
				'revslider'     => 'lawfirm.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Digital Agency',
				'categories'    => [ 'Agency' ],
				'content'       => 'https://reobiztheme.com/demos/agency/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/agency/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/agency/screen.png',
				'preview_url'   => 'https://agency.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/agency/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'agency.zip',
				'revslider'     => false,
				'onepage'       => false,
			],
			[
				'name'          => 'Business consulting 02',
				'categories'    => [ 'Business', 'Consulting' ],
				'content'       => 'https://reobiztheme.com/demos/consulting2/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consulting2/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consulting2/screen.png',
				'preview_url'   => 'https://consulting2.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consulting2/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consulting2.zip',
				'revslider'     => 'consulting2.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Business 03',
				'categories'    => [ 'Business' ],
				'content'       => 'https://reobiztheme.com/demos/business3/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/business3/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/business3/screen.png',
				'preview_url'   => 'https://business3.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/business3/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'business3.zip',
				'revslider'     => 'business3.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Insurance',
				'categories'    => [ 'Insurance' ],
				'content'       => 'https://reobiztheme.com/demos/insurance/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/insurance/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/insurance/screen.png',
				'preview_url'   => 'https://insurance.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/insurance/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'insurance.zip',
				'revslider'     => 'insurance.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Human Resource',
				'categories'    => [ 'HR' ],
				'content'       => 'https://reobiztheme.com/demos/human/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/human/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/human/screen.png',
				'preview_url'   => 'https://human.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/human/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'human.zip',
				'revslider'     => 'human.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Digital Agency 02',
				'categories'    => [ 'Agency' ],
				'content'       => 'https://reobiztheme.com/demos/digital/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/digital/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/digital/screen.png',
				'preview_url'   => 'https://digital.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/digital/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'digital.zip',
				'revslider'     => 'digital.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Business Consulting 03',
				'categories'    => [ 'Business', 'Consulting' ],
				'content'       => 'https://reobiztheme.com/demos/consulting3/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consulting3/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consulting3/screen.png',
				'preview_url'   => 'https://consulting3.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consulting3/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consulting3.zip',
				'revslider'     => 'consulting3.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Corporate Business',
				'categories'    => [ 'Business', 'Corporate' ],
				'content'       => 'https://reobiztheme.com/demos/corporate/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/corporate/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/corporate/screen.png',
				'preview_url'   => 'https://corporate.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/corporate/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'corporate.zip',
				'revslider'     => 'corporate.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'IT Solutions',
				'categories'    => [ 'IT', 'Corporate' ],
				'content'       => 'https://reobiztheme.com/demos/itsolutions/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/itsolutions/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/itsolutions/screen.png',
				'preview_url'   => 'https://itsolutions.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/itsolutions/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'itsolutions.zip',
				'revslider'     => 'itsolutions.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Marketing',
				'categories'    => [ 'Business', 'Agency' ],
				'content'       => 'https://reobiztheme.com/demos/marketing/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/marketing/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/marketing/screen.png',
				'preview_url'   => 'https://marketing.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/marketing/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'marketing.zip',
				'revslider'     => 'marketing.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Business Corporate 02',
				'categories'    => [ 'Business', 'Corporate' ],
				'content'       => 'https://reobiztheme.com/demos/corporate2/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/corporate2/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/corporate2/screen.png',
				'preview_url'   => 'https://corporate2.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/corporate2/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'corporate2.zip',
				'revslider'     => 'corporate2.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Finance',
				'categories'    => [ 'Business', 'Corporate' ],
				'content'       => 'https://reobiztheme.com/demos/finance/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/finance/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/finance/screen.png',
				'preview_url'   => 'https://finance.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/finance/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'finance.zip',
				'revslider'     => false,
				'onepage'       => false,
			],
			[
				'name'          => 'Business 02',
				'categories'    => [ 'Business' ],
				'content'       => 'https://reobiztheme.com/demos/business2/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/business2/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/business2/screen.png',
				'preview_url'   => 'https://business2.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/business2/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'business2.zip',
				'revslider'     => 'business2.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Business Consulting 04',
				'categories'    => [ 'Business', 'Consulting' ],
				'content'       => 'https://reobiztheme.com/demos/consulting4/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consulting4/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consulting4/screen.png',
				'preview_url'   => 'https://consutling4.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consulting4/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consulting4.zip',
				'revslider'     => false,
				'onepage'       => false,
			],
			[
				'name'          => 'Marketing Consulting',
				'categories'    => [ 'Business', 'Consulting' ],
				'content'       => 'https://reobiztheme.com/demos/marketing-consulting/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/marketing-consulting/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/marketing-consulting/screen.png',
				'preview_url'   => 'https://marketing2025.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/marketing-consulting/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'marketing-consulting.zip',
				'revslider'     => false,
				'onepage'       => false,
			],
			[
				'name'          => 'Business 04 (2026)',
				'categories'    => [ 'Business' ],
				'content'       => 'https://reobiztheme.com/demos/business4/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/business4/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/business4/screen.png',
				'preview_url'   => 'https://business2026.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/business4/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'business4.zip',
				'revslider'     => false,
				'onepage'       => false,
			],			

			[
				'name'          => 'Business Consulting 05 (2026)',
				'categories'    => [ 'Business', 'Consulting' ],
				'content'       => 'https://reobiztheme.com/demos/consulting5/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consulting5/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consulting5/screen.png',
				'preview_url'   => 'https://new.reobiztheme.com/consulting2026/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consulting5/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consulting5.zip',
				'revslider'     => 'consulting5.zip',
				'onepage'       => false,
			],			

			[
				'name'          => 'Visa Consulting',
				'categories'    => [ 'Visa', 'Consulting' ],
				'content'       => 'https://reobiztheme.com/demos/visa/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/visa/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/visa/screen.png',
				'preview_url'   => 'https://new.reobiztheme.com/visa-consulting2026/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/visa/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'visa.zip',
				'revslider'     => 'false',
				'onepage'       => false,
			],			

			[
				'name'          => 'Tech Consulting',
				'categories'    => [ 'Tech', 'Consulting', 'IT', 'Technology' ],
				'content'       => 'https://reobiztheme.com/demos/tech/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/tech/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/tech/screen.png',
				'preview_url'   => 'https://new.reobiztheme.com/tech-consulting2026/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/tech/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'tech.zip',
				'revslider'     => 'false',
				'onepage'       => false,
			],
			[
				'name'          => 'Business Strategy (2026)',
				'categories'    => [ 'Business', 'Strategy' ],
				'content'       => 'https://reobiztheme.com/demos/business5/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/business5/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/business5/screen.png',
				'preview_url'   => 'https://new.reobiztheme.com/business-strategy2026/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/business5/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'business5.zip',
				'revslider'     => false,
				'onepage'       => false,
			],	

			// OnePage
			[
				'name'          => 'SASS',
				'categories'    => [ 'Saas', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/saas/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/saas/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/saas/screen.png',
				'preview_url'   => 'https://saas.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/saas/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'saas.zip',
				'revslider'     => [ 'saas-full.zip', 'saas-integration.zip', 'sass-data.zip' ],
				'onepage'       => false,
			],
			[
				'name'          => 'App Landing',
				'categories'    => [ 'Saas', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/app/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/app/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/app/screen.png',
				'preview_url'   => 'https://app.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/app/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'app.zip',
				'revslider'     => 'app.zip',
				'onepage'       => false,
			],
			[
				'name'          => 'Business Main Onepage',
				'categories'    => [ 'Business', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/business/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/business/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/business/screen.png',
				'preview_url'   => 'https://business.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/business/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'business.zip',
				'revslider'     => 'business.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Business Consultant Onepage',
				'categories'    => [ 'Business', 'Consultant', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/consultant/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consultant/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consultant/screen.png',
				'preview_url'   => 'https://consultant.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consultant/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consultant.zip',
				'revslider'     => 'consultant.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Business consulting Onepage',
				'categories'    => [ 'Business', 'Consulting', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/consulting/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consulting/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consulting/screen.png',
				'preview_url'   => 'https://consulting.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consulting/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consulting.zip',
				'revslider'     => 'consulting.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Digital Agency(SEO) Onepage',
				'categories'    => [ 'Agency', 'SEO', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/seo/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/seo/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/seo/screen.png',
				'preview_url'   => 'https://seo.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/seo/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'seo.zip',
				'revslider'     => false,
				'onepage'       => true,
			],
			[
				'name'          => 'Law Firm Demo Onepage',
				'categories'    => [ 'Law Firm', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/lawfirm/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/lawfirm/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/lawfirm/screen.png',
				'preview_url'   => 'https://lawfirm.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/lawfirm/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'lawfirm.zip',
				'revslider'     => 'lawfirm.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Digital Agency Onepage',
				'categories'    => [ 'Agency', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/agency/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/agency/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/agency/screen.png',
				'preview_url'   => 'https://agency.reobiztheme.com/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/agency/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'agency.zip',
				'revslider'     => false,
				'onepage'       => true,
			],
			[
				'name'          => 'Business consulting 02 Onepage',
				'categories'    => [ 'Business', 'Consulting', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/consulting2/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consulting2/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consulting2/screen.png',
				'preview_url'   => 'https://consulting2.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consulting2/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consulting2.zip',
				'revslider'     => 'consulting2.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Business 03 Onepage',
				'categories'    => [ 'Business', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/business3/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/business3/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/business3/screen.png',
				'preview_url'   => 'https://business3.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/business3/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'business3.zip',
				'revslider'     => 'business3.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Insurance Onepage',
				'categories'    => [ 'Insurance', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/insurance/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/insurance/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/insurance/screen.png',
				'preview_url'   => 'https://insurance.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/insurance/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'insurance.zip',
				'revslider'     => 'insurance.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Human Resource Onepage',
				'categories'    => [ 'HR', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/human/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/human/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/human/screen.png',
				'preview_url'   => 'https://human.reobiztheme.com/onepage',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/human/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'human.zip',
				'revslider'     => 'human.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Digital Agency 02 Onepage',
				'categories'    => [ 'Agency' ],
				'content'       => 'https://reobiztheme.com/demos/digital/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/digital/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/digital/screen.png',
				'preview_url'   => 'https://digital.reobiztheme.com/onepage',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/digital/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'digital.zip',
				'revslider'     => 'digital.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Business Consulting 03 Onepage',
				'categories'    => [ 'Business', 'Consulting', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/consulting3/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consulting3/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consulting3/screen.png',
				'preview_url'   => 'https://consulting3.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consulting3/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consulting3.zip',
				'revslider'     => 'consulting3.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Corporate Business Onepage',
				'categories'    => [ 'Business', 'Corporate', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/corporate/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/corporate/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/corporate/screen.png',
				'preview_url'   => 'https://corporate.reobiztheme.com/onepage',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/corporate/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'corporate.zip',
				'revslider'     => 'corporate.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'IT Solutions Onepage',
				'categories'    => [ 'IT', 'Corporate', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/itsolutions/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/itsolutions/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/itsolutions/screen.png',
				'preview_url'   => 'https://itsolutions.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/itsolutions/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'itsolutions.zip',
				'revslider'     => 'itsolutions.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Marketing Onepage',
				'categories'    => [ 'Business', 'Agency', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/marketing/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/marketing/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/marketing/screen.png',
				'preview_url'   => 'https://marketing.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/marketing/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'marketing.zip',
				'revslider'     => 'marketing.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Business Corporate 02 Onepage',
				'categories'    => [ 'Business', 'Corporate', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/corporate2/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/corporate2/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/corporate2/screen.png',
				'preview_url'   => 'https://corporate2.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/corporate2/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'corporate2.zip',
				'revslider'     => 'corporate2.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Finance Onepage',
				'categories'    => [ 'Business', 'Corporate', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/finance/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/finance/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/finance/screen.png',
				'preview_url'   => 'https://finance.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/finance/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'finance.zip',
				'revslider'     => false,
				'onepage'       => true,
			],
			[
				'name'          => 'Business 02 Onepage',
				'categories'    => [ 'Business' ],
				'content'       => 'https://reobiztheme.com/demos/business2/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/business2/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/business2/screen.png',
				'preview_url'   => 'https://business2.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/business2/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'business2.zip',
				'revslider'     => 'business2.zip',
				'onepage'       => true,
			],
			[
				'name'          => 'Business Consulting 04 Onepage',
				'categories'    => [ 'Business', 'Consulting', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/consulting4/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consulting4/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consulting4/screen.png',
				'preview_url'   => 'https://consutling4.reobiztheme.com/onepage',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consulting4/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consulting4.zip',
				'revslider'     => false,
				'onepage'       => true,
			],
			[
				'name'          => 'Marketing Consulting Onepage',
				'categories'    => [ 'Business', 'Consulting', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/marketing-consulting/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/marketing-consulting/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/marketing-consulting/screen.png',
				'preview_url'   => 'https://marketing2025.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/marketing-consulting/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'marketing-consulting.zip',
				'revslider'     => false,
				'onepage'       => true,
			],
			[
				'name'          => 'Business 04 (2026) Onepage',
				'categories'    => [ 'Business', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/business4/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/business4/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/business4/screen.png',
				'preview_url'   => 'https://business2026.reobiztheme.com/onepage/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/business4/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'business4.zip',
				'revslider'     => false,
				'onepage'       => true,
			],
			[
				'name'          => 'Business Consulting 05 (2026) Onepage',
				'categories'    => [ 'Business', 'Consulting' , 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/consulting5/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/consulting5/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/consulting5/screen.png',
				'preview_url'   => 'https://new.reobiztheme.com/consulting2026/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/consulting5/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'consulting5.zip',
				'revslider'     => 'consulting5.zip',
				'onepage'       => true,
			],

			[
				'name'          => 'Visa Consulting Onepage',
				'categories'    => [ 'Visa', 'Consulting', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/visa/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/visa/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/visa/screen.png',
				'preview_url'   => 'https://new.reobiztheme.com/visa-consulting2026/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/visa/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'visa.zip',
				'revslider'     => 'false',
				'onepage'       => true,
			],			

			[
				'name'          => 'Tech Consulting',
				'categories'    => [ 'Tech', 'Consulting', 'IT', 'Technology', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/tech/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/tech/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/tech/screen.png',
				'preview_url'   => 'https://new.reobiztheme.com/tech-consulting2026/',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/tech/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'tech.zip',
				'revslider'     => 'false',
				'onepage'       => true,
			],

			[
				'name'          => 'Business Strategy Onepage (2026)',
				'categories'    => [ 'Business', 'Strategy', 'Onepage' ],
				'content'       => 'https://reobiztheme.com/demos/business5/reobiz-content.xml',
				'widgets'       => 'https://reobiztheme.com/demos/business5/reobiz-widget.wie',
				'preview'       => 'https://reobiztheme.com/demos/business5/screen.png',
				'preview_url'   => 'https://new.reobiztheme.com/business-strategy2026/onepage',
				'redux'         => [
					[
						'file_url'    => 'https://reobiztheme.com/demos/business5/reobiz-options.json',
						'option_name' => 'reobiz_option',
					],
				],
				'elementor_kit' => 'business5.zip',
				'revslider'     => false,
				'onepage'       => true,
			],	


		];
	}
}

new RSTheme_Demo_Config();