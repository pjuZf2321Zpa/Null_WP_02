<?php
/**
 * @author  rs-theme
 * @since   1.0
 * @version 1.0
 */
wp_head();

get_template_part( 'template-parts/content', '404' );

wp_footer();
