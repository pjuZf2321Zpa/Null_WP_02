<?php
/**
 * @author  rs-theme
 * @since   1.0
 * @version 1.0
 */

global $reobiz_option;
?>

</div><!-- .main-container -->

<?php
if ( apply_filters( 'rstb_show_theme_footer', true ) ) {
	get_template_part( 'inc/footer/footer' );
} else {
	do_action( 'rstb_init_footer' );
}
?>

</div><!-- #page -->

<?php
if ( ! empty( $reobiz_option[ 'show_top_bottom' ] ) ) :
	$show_top_bottom_postition = ! empty( $reobiz_option[ 'show_top_bottom_postition' ] ) ? $reobiz_option[ 'show_top_bottom_postition' ] : 'right';
	?>
    <!-- start scrollUp  -->
    <div id="scrollUp" class="<?php echo esc_attr( $show_top_bottom_postition ); ?>">
        <i class="fa fa-angle-up"></i>
    </div>
<?php
endif;

wp_footer(); ?>
</body>
</html>
