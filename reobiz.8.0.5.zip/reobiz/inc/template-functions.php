<?php
/**
 * @author  rs-theme
 */
function reobiz_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	return $classes;
}

add_filter( 'body_class', 'reobiz_body_classes' );

/**
 * Add a pingback url auto-discovery header for singularly identifiable articles.
 */
function reobiz_pingback_header() {
	if ( is_singular() && pings_open() ) {
		echo '<link rel="pingback" href="', esc_url( get_bloginfo( 'pingback_url' ) ), '">';
	}
}

add_action( 'wp_head', 'reobiz_pingback_header' );

/**  kses_allowed_html */

function reobiz_prefix_kses_allowed_html( $tags, $context ) {
	switch ( $context ) {
		case 'reobiz':
			$tags = array(
				'a'                             => array(
					'class'  => array(),
					'href'   => array(),
					'rel'    => array(),
					'title'  => array(),
					'target' => array(),
				),
				'abbr'                          => array(
					'title' => array(),
				),
				'b'                             => array(),
				'blockquote'                    => array(
					'cite' => array(),
				),
				'cite'                          => array(
					'title' => array(),
				),
				'code'                          => array(),
				'del'                           => array(
					'datetime' => array(),
					'title'    => array(),
				),
				'dd'                            => array(),
				'div'                           => array(
					'class' => array(),
					'title' => array(),
					'style' => array(),
				),
				'dl'                            => array(),
				'dt'                            => array(),
				'em'                            => array(),
				'h1'                            => array(),
				'h2'                            => array(),
				'h3'                            => array(),
				'h4'                            => array(),
				'h5'                            => array(),
				'h6'                            => array(),
				'i'                             => array(
					'class' => array(),
				),
				'img'                           => array(
					'alt'    => array(),
					'class'  => array(),
					'height' => array(),
					'src'    => array(),
					'width'  => array(),
				),
				'li'                            => array(
					'class' => array(),
				),
				'ol'                            => array(
					'class' => array(),
				),
				'p'                             => array(
					'class' => array(),
				),
				'q'                             => array(
					'cite'  => array(),
					'title' => array(),
				),
				'span'                          => array(
					'class' => array(),
					'title' => array(),
					'style' => array(),
				),
				'iframe'                        => array(
					'width'       => array(),
					'height'      => array(),
					'scrolling'   => array(),
					'frameborder' => array(),
					'allow'       => array(),
					'src'         => array(),
				),
				'strike'                        => array(),
				'small'                         => array(),
				'br'                            => array(),
				'strong'                        => array(),
				'data-wow-duration'             => array(),
				'data-wow-delay'                => array(),
				'data-wallpaper-options'        => array(),
				'data-stellar-background-ratio' => array(),
				'ul'                            => array(
					'class' => array(),
				),

			);

			return $tags;
		default:
			return $tags;
	}
}

add_filter( 'wp_kses_allowed_html', 'reobiz_prefix_kses_allowed_html', 10, 2 );

/*
Register Fonts theme google font
*/
function reobiz_studio_fonts_url() {
	$font_url = '';

	/*
	Translators: If there are characters in your language that are not supported
	by chosen font(s), translate this to 'off'. Do not translate into your own language.
	 */
	if ( 'off' !== _x( 'on', 'Google font: on or off', 'reobiz' ) ) {
		$font_url = add_query_arg( 'family', urlencode( 'Poppins:300,400,500,600,700,900' ), "//fonts.googleapis.com/css" );
	}

	return $font_url;
}

/*
Enqueue scripts and styles.
*/
function reobiz_studio_scripts() {
	wp_enqueue_style( 'studio-fonts', reobiz_studio_fonts_url(), array(), '1.0.0' );
}

add_action( 'wp_enqueue_scripts', 'reobiz_studio_scripts' );

// Favicon Icon
function reobiz_site_icon() {
	if ( ! ( function_exists( 'has_site_icon' ) && has_site_icon() ) ) {
		global $reobiz_option;

		if ( ! empty( $reobiz_option[ 'rs_favicon' ][ 'url' ] ) ) {
			?>
            <link rel="shortcut icon" type="image/x-icon" href="<?php echo esc_url( ( $reobiz_option[ 'rs_favicon' ][ 'url' ] ) ); ?>">
			<?php
		}
	}
}

add_filter( 'wp_head', 'reobiz_site_icon' );

// Excerpt for specific section
function reobiz_wpex_get_excerpt( $args = array() ) {
	// Defaults
	$defaults = array(
		'post'            => '',
		'length'          => 48,
		'readmore'        => false,
		'readmore_text'   => esc_html__( 'read more', 'reobiz' ),
		'readmore_after'  => '',
		'custom_excerpts' => true,
		'disable_more'    => false,
	);
	// Apply filters
	$defaults = apply_filters( 'reobiz_wpex_get_excerpt_defaults', $defaults );
	// Parse args
	$args = wp_parse_args( $args, $defaults );
	// Apply filters to args
	$args = apply_filters( 'reobiz_wpex_get_excerpt_args', $defaults );
	// Extract
	extract( $args );
	// Get global post data
	if ( ! $post ) {
		global $post;
	}

	// Get post ID
	$post_id = $post->ID;

	// Check for custom excerpt
	if ( $custom_excerpts && has_excerpt( $post_id ) ) {
		$output = $post->post_excerpt;
	} // No custom excerpt...so lets generate one
	else {
		// Readmore link
		$readmore_link = '<a href="' . get_permalink( $post_id ) . '" class="readmore">' . $readmore_text . $readmore_after . '</a>';
		// Check for more tag and return content if it exists
		if ( ! $disable_more && strpos( $post->post_content, '<!--more-->' ) ) {
			$output = apply_filters( 'the_content', get_the_content( $readmore_text . $readmore_after ) );
		} // No more tag defined so generate excerpt using wp_trim_words
		else {
			// Generate excerpt
			$output = wp_trim_words( strip_shortcodes( $post->post_content ), $length );
			// Add readmore to excerpt if enabled
			if ( $readmore ) {
				$output .= apply_filters( 'reobiz_wpex_readmore_link', $readmore_link );
			}

		}

	}

	// Apply filters and echo
	return apply_filters( 'reobiz_wpex_get_excerpt', $output );
}

// Disables the block editor from managing widgets in the Gutenberg plugin.
add_filter( 'gutenberg_use_widgets_block_editor', '__return_false' );

// Disables the block editor from managing widgets.
add_filter( 'use_widgets_block_editor', '__return_false' );

function reobiz_has_active_license() {
	$license = get_option( 'ReobizWordPressTheme_lic_Key' );

	return is_string( $license ) && trim( $license ) !== '';
}