(function ($) {
  "use strict";

  $(document).on('blonweShopPageInit', function () {
    blonweThemeModule.countdown();
  });

  blonweThemeModule.countdown = function() {
    $('.klb-countdown').each(function() {

      let $this = $(this);

      let dateStr = $this.data('date');
      let tz = $this.data('timezone') || 'UTC';

      let m = moment.tz(dateStr, [
        'YYYY/MM/DD HH:mm:ss',
        'YYYY-MM-DD HH:mm:ss',
        'YYYY/MM/DD',
        'YYYY-MM-DD'
      ], tz);

      let finalDate = m.isValid() ? m.toDate() : dateStr;

      let $days = $this.find('.days');
      let $hours = $this.find('.hours');
      let $minutes = $this.find('.minutes');
      let $second = $this.find('.second');

      $this.countdown(finalDate, function(event) {
        $days.html(event.strftime('%D'));
        $hours.html(event.strftime('%H'));
        $minutes.html(event.strftime('%M'));
        $second.html(event.strftime('%S'));
      });

    });
  }

  $(document).ready(function() {
    blonweThemeModule.countdown();
  });

})(jQuery);
