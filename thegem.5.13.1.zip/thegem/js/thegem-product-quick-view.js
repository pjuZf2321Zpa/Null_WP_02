(function ($) {
    $(function () {
        $(document.body).on('click', '.product .quick-view-button, .product-quick-view-navigation a', function (e) {
            e.preventDefault();
            var $button = $(this);
            $.fancybox.close();
            $.fancybox.open({
                type: 'ajax',
                src: thegem_woo_data.ajax_url,
                autoFocus: false,
                ajax: {
                    settings: {
                        method: 'POST',
                        data: {
                            ajax_nonce: thegem_woo_data.ajax_nonce,
                            action: 'thegem_product_quick_view',
                            product_id: $button.data('product-id'),
                            quick_view_layout_source: $button.data('quick-view-layout-source'),
                            quick_view_template: $button.data('quick-view-template'),
                            quick_view_container_bg: $button.data('quick-view-bg'),
                            quick_view_scope: $button.data('quick-view-scope')
                        }
                    }
                },
                slideClass: 'woo-modal-product',
                baseClass: "product-quick-view product-quick-view__wrapper",
                afterShow: function (el) {
                    var builderSelector = '.thegem-quick-view-builder[data-quick-view-source="builder"]';
                    var $builderContent = el.current.$content.filter(builderSelector).add(el.current.$content.find(builderSelector));

                    if ($builderContent.length) {
                        builderQuickView(el, $builderContent);
                        return;
                    }

                    var quickViewGalleryType = $('.product-quick-view .single-product').attr("data-quick-view");
                    var quickViewLayoutType = $('.product-quick-view .single-product-content ').attr("data-layout");

                    $('.product-quick-view .gem-attribute-selector').gemWooAttributeSelector();

                    if (quickViewLayoutType !== 'legacy') {
                        el.current.$content.initProductQuickViewScripts();
                    }

                    if (quickViewGalleryType === 'legacy'){
                        legacyQuickViewGallery(el);
                    } else {
                        defaultQuickViewGallery(el);
                    }
                }
            }, {
                spinnerTpl: '<div class="gem-fancybox-preloader"><div class="preloader-spin"></div></div>',
                caption: '<div class="product-navigation-caption"></div>',
                touch: false,
                backFocus: false,
                locked: false,
            });
        });

        function builderQuickView(el, $builderContent) {
            // Loading animation relies on window scroll, which never fires inside the popup.
            $builderContent.find('.portfolio.loading-animation').removeClass('loading-animation')
                .find('.item-animations-not-inited').removeClass('item-animations-not-inited');

            if (typeof $.fn.gemWooAttributeSelector === 'function') {
                $builderContent.find('.gem-attribute-selector').gemWooAttributeSelector();
            }

            if (typeof $builderContent.updateProductGalleries === 'function') {
                $builderContent.updateProductGalleries();
            }

            $builderContent.find('.variations_form').each(function () {
                var $form = $(this);
                $form.on('reset_image show_variation', function () {
                    el.removeEvents();
                    window.setTimeout(function () {
                        el.addEvents();
                    }, 100);
                });
                $form.wc_variation_form();
            });

            if (typeof $builderContent.thegemInitProductScripts === 'function') {
                $builderContent.thegemInitProductScripts();
            }

            if (typeof $.fn.initExtendedPortfolioGrids === 'function') {
                $builderContent.find('.extended-portfolio-grid:not(.extended-carousel-grid)').initExtendedPortfolioGrids();
            }

            if (typeof $.fn.initProductGalleries === 'function') {
                $builderContent.find('.extended-products-grid-carousel').initProductGalleries();
            }

            if (window.tgpLazyItems !== undefined) {
                window.tgpLazyItems.scrollHandle();
            }

            $builderContent.find('.fancybox').fancybox({
                touch: false,
            });

            if (typeof window.vc_js === 'function') {
                // Skip vc_js()'s row-stretch pass: it sizes rows to the viewport, not the popup.
                var vcFullWidthRowJsDisabled = window.wpb_disable_full_width_row_js;
                window.wpb_disable_full_width_row_js = true;
                window.vc_js();
                window.wpb_disable_full_width_row_js = vcFullWidthRowJsDisabled;
            }
        }

        function defaultQuickViewGallery(el) {
            $('.gem-combobox').combobox();
            el.current.$content.buildQuickViewGallery();
            el.current.$content.updateProductGalleries();
            $('.variations_form', el.current.$content).each(function () {
                var $form = $(this);
                $form.on('reset_image show_variation', function () {
                    el.removeEvents();
                    window.setTimeout(function () {
                        el.addEvents();
                    }, 100);
                });
                $form.on('show_variation', function (e, variation) {
                    if(variation.image_id) {
                        var $product_content = $(this).closest('.single-product-content');
                        var $gallery = $product_content.find('.product-gallery').eq(0);
                        var $mainCarousel = $gallery.find('.product-gallery-slider');
                        if($gallery.length) {
                            var $gallery_item = $gallery.find('.product-gallery-slider .product-gallery-slider-item[data-image-id="'+variation.image_id+'"]').parent('.owl-item').index();
                            $mainCarousel.trigger('to.owl.carousel', [$gallery_item, 300, true]);
                        }
                    }
                });
                $form.wc_variation_form();
                $form.on('change', '.variations select', function (event) {
                    var $text = $(this).closest('.combobox-wrapper').find('.combobox-text');
                    $text.text($('option:selected', $(this)).text());
                });
            });
        }

        function legacyQuickViewGallery(el) {
            $('.gem-combobox').combobox();
            el.current.$content.buildSimpleGalleries();
            el.current.$content.updateSimpleGalleries();
            $('.variations_form', el.current.$content).each(function () {
                var $form = $(this);
                $form.on('reset_image show_variation', function () {
                    el.removeEvents();
                    window.setTimeout(function () {
                        el.addEvents();
                    }, 100);
                });
                $form.on('show_variation', function (e, variation) {
                    if (variation.image && variation.image.src) {
                        var $g_item = $('.gem-quick-view-gallery .gem-gallery-item img[src="' + variation.image.src + '"]', el.current.$content).closest('.gem-gallery-item');
                        $('.gem-quick-view-gallery .gem-gallery-items-carousel', el.current.$content).trigger('slideTo', [$g_item]);
                    }
                });
                $form.wc_variation_form();
                $form.on('change', '.variations select', function (event) {
                    var $text = $(this).closest('.combobox-wrapper').find('.combobox-text');
                    $text.text($('option:selected', $(this)).text());
                });
            });
        }
    });
})(jQuery);