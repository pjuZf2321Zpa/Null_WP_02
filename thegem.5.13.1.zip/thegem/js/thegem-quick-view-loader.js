(function ($) {
	var assets = window.thegem_quick_view_assets,
		state = 'idle',
		pending = null;

	if (!assets) {
		return;
	}

	function inject(tag, attrs, text) {
		return new Promise(function (resolve) {
			var el = document.createElement(tag);
			Object.keys(attrs).forEach(function (key) {
				el.setAttribute(key, attrs[key]);
			});
			if (text !== undefined) {
				el.textContent = text;
				document.head.appendChild(el);
				return resolve();
			}
			el.onload = el.onerror = resolve;
			document.head.appendChild(el);
		});
	}

	function loadStyles() {
		return Promise.all(assets.styles.map(function (style) {
			return inject('link', {rel: 'stylesheet', href: style.src, media: style.media || 'all'}).then(function () {
				return style.after ? inject('style', {}, style.after) : null;
			});
		}));
	}

	function loadScripts() {
		return assets.scripts.reduce(function (chain, script) {
			return chain
				.then(function () { return script.data ? inject('script', {}, script.data) : null; })
				.then(function () { return script.before ? inject('script', {}, script.before) : null; })
				.then(function () { return inject('script', {src: script.src}); })
				.then(function () { return script.after ? inject('script', {}, script.after) : null; });
		}, Promise.resolve());
	}

	function load() {
		if (state !== 'idle') {
			return;
		}
		state = 'loading';
		Promise.all([loadStyles(), loadScripts()]).then(function () {
			state = 'ready';
			if (!pending) {
				return;
			}
			var $button = $(pending);
			pending = null;
			window.setTimeout(function () {
				$button.css({opacity: '', cursor: '', pointerEvents: ''}).trigger('click');
			}, 50);
		});
	}

	$(document.body).one('mouseover touchstart focusin', '.product, .quick-view-button', load);

	$(document.body).on('click', '.quick-view-button', function (e) {
		if (state === 'ready') {
			return;
		}
		e.preventDefault();
		e.stopImmediatePropagation();
		pending = this;
		$(this).css({opacity: 0.5, cursor: 'progress', pointerEvents: 'none'});
		load();
	});
})(jQuery);
