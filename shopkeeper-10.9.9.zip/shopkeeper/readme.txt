=== Shopkeeper ===
Contributors: Get Bowtied
Author: Get Bowtied
Author URI: https://getbowtied.com/
Theme URI: https://shopkeeper.getbowtied.com/
Tags: wordpress, woocommerce, elementor, visual website builder
Requires at least: 5.0
Tested up to: 7.1.2
Requires PHP: 7.4.1
Stable tag: 10.9.9
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Text Domain: shopkeeper
Domain Path: /languages/

Shopkeeper - a Hassle-free Worpress Theme with great design and extensive functionality.

== Description ==

Shopkeeper - a Hassle-free Worpress Theme with great design and extensive functionality.

== Installation ==

1. Upload the `shopkeeper` folder to the `/wp-content/themes/` directory.
2. Activate the theme from the WordPress Dashboard under Appearance > Themes.
3. Install/enable any required plugins as prompted by the theme.

== Screenshots ==

1. Main screenshot
   screenshot.png

== Changelog ==

= 10.9.9 =
* Notice: Shopkeeper ThemeForest version has reached end of life. Updates on ThemeForest stop after October 1, 2026. From v11, new features, updates, and support continue on our own platform. Convert your ThemeForest purchase code into a new license key in your WordPress dashboard. Questions? Reach us at https://getbowtied.com/support/
