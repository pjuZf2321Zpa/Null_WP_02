<?php

if (!defined('ABSPATH')) exit; // Exit if accessed directly

return [
    'themeforest_updates_cutoff' => '2026-10-01',
    'themeforest_updates_cutoff_soon' => false,
    'business_plan_licenses' => 3,
    'price_increase' => [
        'date' => '2026-12-31',
    ],
    'themeforest_coupons' => [
        1 => [
            'coupon' => 'THEMEFOREST20',
            'date'   => '2010-01-01',
            'value'  => 20,
        ],
        2 => [
            'coupon' => 'THEMEFOREST30',
            'date'   => '2026-09-01',
            'value'  => 30,
        ],
    ],
    'supported_themes' => [
        "shopkeeper" => [
            "theme_infos_url"      => "https://getbowtied.com",
            "theme_name"           => "Shopkeeper",
            "theme_since"          => 2014,
            "theme_docs_path"      => "/docs/shopkeeper/",
            "theme_changelog_path" => "/documentation/shopkeeper/changelog/",
            "theme_update_url"     => "https://getbowtied.github.io/updates/info/shopkeeper.json",
            "freemius" => [
                "id"         => "16122",
                "slug"       => "shopkeeper",
                "public_key" => "pk_03b827f35d0bf54009952bb4ceb61",
            ],
        ],
        "theretailer" => [
            "theme_infos_url"      => "https://getbowtied.com",
            "theme_name"           => "The Retailer",
            "theme_since"          => 2013,
            "theme_docs_path"      => "/docs/the-retailer/",
            "theme_changelog_path" => "/documentation/the-retailer/changelog-the-retailer/",
            "theme_update_url"     => "https://getbowtied.github.io/updates/info/theretailer.json",
            "freemius" => [
                "id"         => "16120",
                "slug"       => "theretailer",
                "public_key" => "pk_9c45b9c9fa78e25f8ce9ea9a43c3a",
            ],
        ],
        "mrtailor" => [
            "theme_infos_url"      => "https://getbowtied.com",
            "theme_name"           => "Mr Tailor",
            "theme_since"          => 2014,
            "theme_docs_path"      => "/docs/mr-tailor/",
            "theme_changelog_path" => "/documentation/mr-tailor/changelog-mr-tailor/",
            "theme_update_url"     => "https://getbowtied.github.io/updates/info/mrtailor.json",
            "freemius" => [
                "id"         => "16117",
                "slug"       => "mrtailor",
                "public_key" => "pk_632f8d1aa8f86eb31f09b2071f856",
            ],
        ],
        "merchandiser" => [
            "theme_infos_url"      => "https://getbowtied.com",
            "theme_name"           => "Merchandiser",
            "theme_since"          => 2016,
            "theme_docs_path"      => "/docs/merchandiser/",
            "theme_changelog_path" => "/documentation/merchandiser/changelog-merchandiser/",
            "theme_update_url"     => "https://getbowtied.github.io/updates/info/merchandiser.json",
            "freemius" => [
                "id"         => "16092",
                "slug"       => "merchandiser",
                "public_key" => "pk_314a679cbea7d3a7140cf2c3a7114",
            ],
        ],
        "the-hanger" => [
            "theme_infos_url"      => "https://getbowtied.com",
            "theme_name"           => "The Hanger",
            "theme_since"          => 2018,
            "theme_docs_path"      => "/docs/the-hanger/",
            "theme_changelog_path" => "/documentation/the-hanger/changelog-the-hanger/",
            "theme_update_url"     => "https://getbowtied.github.io/updates/info/the-hanger.json",
            "freemius" => [
                "id"         => "16112",
                "slug"       => "the-hanger",
                "public_key" => "pk_fcada1fed99ee7b10845caa247524",
            ],
        ],
        "block-shop" => [
            "theme_infos_url"      => "https://woocommerce.com",
            "theme_name"           => "Block Shop",
            "theme_since"          => 2019,
            "theme_docs_path"      => "/document/block-shop-theme/",
            "theme_changelog_path" => "/products/block-shop/",
            "theme_update_url"     => "https://getbowtied.github.io/updates/themes/block-shop.json",
        ]
    ],
];
