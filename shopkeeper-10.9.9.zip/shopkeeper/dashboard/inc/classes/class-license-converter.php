<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Themeforest purchase code → Freemius license via api1 migrate endpoint.
 */
class GBT_License_Converter {

	private static $instance = null;

	/** @var array<string,mixed>|null */
	private $primary_sale_cache = null;

	private bool $primary_sale_loaded = false;

	const AJAX_ACTION          = 'gbt_convert_tf_license';
	const NONCE_ACTION         = 'gbt_convert_tf_license';
	const MIGRATION_API        = 'https://api1.getbowtied.net/v1/themeforest-to-freemius/';
	const SALES_OPTION         = 'gbt_themeforest_sales';
	const GRACE_DISMISS_META   = 'gbt_tf_grace_notice_dismissed';
	const GRACE_DISMISS_ACTION = 'gbt_dismiss_tf_grace_notice';
	const CREDIT_DISMISS_META  = 'gbt_tf_credit_notice_dismissed';
	const CREDIT_DISMISS_ACTION = 'gbt_dismiss_tf_credit_notice';
	const CREDIT_GRACE_DAYS    = 14;
	const TF_UPDATES_ANNOUNCEMENT_URL = 'https://getbowtied.com/announcements/why-themeforest-updates-are-ending-and-why-this-is-not-the-end/';

	private function __construct() {}

	/** @see gbt_now() */
	private function now(): int {
		return function_exists( 'gbt_now' ) ? gbt_now() : time();
	}

	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public static function init(): void {
		static $booted = false;
		if ( $booted ) {
			return;
		}
		$booted   = true;
		$instance = self::get_instance();
		add_action( 'wp_ajax_' . self::AJAX_ACTION, array( $instance, 'ajax_convert' ) );
		add_action( 'wp_ajax_' . self::GRACE_DISMISS_ACTION, array( $instance, 'ajax_dismiss_grace_notice' ) );
		add_action( 'wp_ajax_' . self::CREDIT_DISMISS_ACTION, array( $instance, 'ajax_dismiss_credit_notice' ) );
	}

	public function ajax_convert(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'You do not have permission to convert a license.' ), 403 );
		}

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$purchase_code = isset( $_POST['purchase_code'] )
			? sanitize_text_field( wp_unslash( $_POST['purchase_code'] ) )
			: '';
		$email = isset( $_POST['email'] )
			? sanitize_email( wp_unslash( $_POST['email'] ) )
			: '';

		$result = $this->convert_and_activate( $purchase_code, $email );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
					'code'    => $result->get_error_code(),
				)
			);
		}

		wp_send_json_success(
			array(
				'message'  => 'License converted and activated.',
				'redirect' => GBT_License_Manager::license_page_url(),
			)
		);
	}

	/**
	 * @return true|WP_Error
	 */
	public function activate_if_migrated( string $purchase_code ) {
		$purchase_code = trim( $purchase_code );

		if ( ! GBT_License_Manager::is_themeforest_purchase_code( $purchase_code ) ) {
			return new WP_Error( 'invalid_purchase_code', 'Please enter a valid Themeforest purchase code.' );
		}

		$body = $this->post_migration_api(
			array(
				'lookup'        => true,
				'purchase_code' => $purchase_code,
			)
		);

		if ( is_wp_error( $body ) ) {
			return $body;
		}

		if ( empty( $body['success'] ) ) {
			return $this->api_response_error( $body, 'Could not verify this purchase code.' );
		}

		$this->persist_sale( $purchase_code, $body );

		if ( empty( $body['migrated'] ) || empty( $body['license_key'] ) ) {
			return new WP_Error(
				'not_migrated',
				'This Themeforest purchase code is valid but has not been converted yet.'
			);
		}

		$activated = $this->activate_license_key(
			(string) $body['license_key'],
			'Converted license found but could not be activated. Paste the license key manually.',
			false
		);
		if ( is_wp_error( $activated ) ) {
			return $activated;
		}

		$this->remember_converted_code( $purchase_code );

		return true;
	}

	/**
	 * @return true|WP_Error
	 */
	public function convert_and_activate( string $purchase_code, string $email ) {
		$purchase_code = trim( $purchase_code );
		$email         = trim( $email );

		if ( ! GBT_License_Manager::is_themeforest_purchase_code( $purchase_code ) ) {
			return new WP_Error( 'invalid_purchase_code', 'Please enter a valid Themeforest purchase code.' );
		}

		if ( $email === '' || ! is_email( $email ) ) {
			return new WP_Error( 'invalid_email', 'Please enter a valid email address.' );
		}

		$body = $this->post_migration_api(
			array(
				'purchase_code' => $purchase_code,
				'email'         => $email,
				'site_url'      => home_url( '/' ),
			)
		);

		if ( is_wp_error( $body ) ) {
			return $body;
		}

		if ( empty( $body['success'] ) || empty( $body['license_key'] ) ) {
			return $this->api_response_error( $body, 'Conversion failed. Please try again.' );
		}

		$this->persist_sale( $purchase_code, $body );

		$activated = $this->activate_license_key(
			(string) $body['license_key'],
			'License was created but could not be activated. Paste the key manually.',
			true
		);
		if ( is_wp_error( $activated ) ) {
			return $activated;
		}

		$this->remember_converted_code( $purchase_code );

		return true;
	}

	/**
	 * @param array<string,mixed> $payload
	 * @return array<string,mixed>|WP_Error
	 */
	private function post_migration_api( array $payload ) {
		$setup = GBT_Dashboard_Setup::init();
		$slug  = (string) $setup->get_theme_slug();
		$fs    = $setup->get_theme_config( 'freemius' );
		if ( is_array( $fs ) && ! empty( $fs['slug'] ) ) {
			$slug = (string) $fs['slug'];
		}

		if ( empty( $payload['product_slug'] ) ) {
			$payload['product_slug'] = $slug;
		}

		$response = wp_remote_post(
			self::MIGRATION_API,
			array(
				'timeout' => 60,
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'server_error',
				'Could not reach the conversion service. ' . $response->get_error_message()
			);
		}

		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) ) {
			return new WP_Error( 'server_error', 'Unexpected response from the conversion service.' );
		}

		return $body;
	}

	/**
	 * @param array<string,mixed> $body
	 */
	private function api_response_error( array $body, string $default ): WP_Error {
		$message  = ! empty( $body['message'] ) ? (string) $body['message'] : $default;
		$err_code = ! empty( $body['code'] ) ? (string) $body['code'] : 'server_error';
		return new WP_Error( $err_code, $message );
	}

	/**
	 * @param bool $from_conversion True only for a fresh Themeforest → license conversion.
	 * @return true|WP_Error
	 */
	private function activate_license_key( string $license_key, string $fallback, bool $from_conversion = false ) {
		$result = GBT_License_Manager::get_instance()->activate( trim( $license_key ), $from_conversion );
		if ( true === $result ) {
			return true;
		}
		if ( is_array( $result ) ) {
			return new WP_Error(
				'activate_failed',
				isset( $result['message'] ) ? (string) $result['message'] : $fallback,
				$result
			);
		}
		return new WP_Error(
			'activate_failed',
			is_string( $result ) && $result !== '' ? $result : $fallback
		);
	}

	private function remember_converted_code( string $purchase_code ): void {
		$used = get_option( 'gbt_converted_purchase_codes', array() );
		if ( ! is_array( $used ) ) {
			$used = array();
		}
		$used[] = $purchase_code;
		update_option( 'gbt_converted_purchase_codes', array_values( array_unique( $used ) ), false );
	}

	/**
	 * @param array<string,mixed> $body
	 */
	private function persist_sale( string $purchase_code, array $body ): void {
		gbt_tf_store_sale( $purchase_code, $body );
		$this->primary_sale_loaded = false;
		$this->primary_sale_cache  = null;
		delete_user_meta( get_current_user_id(), self::GRACE_DISMISS_META );
		delete_user_meta( get_current_user_id(), self::CREDIT_DISMISS_META );
	}

	/**
	 * @return array<string,mixed>
	 */
	private function primary_sale(): array {
		if ( ! $this->primary_sale_loaded ) {
			$this->primary_sale_cache  = gbt_tf_get_sale();
			$this->primary_sale_loaded = true;
		}
		return $this->primary_sale_cache;
	}

	/**
	 * @return array<string,mixed>
	 */
	public function get_themeforest_sale( string $purchase_code = '' ): array {
		return gbt_tf_get_sale( $purchase_code );
	}

	public function get_primary_themeforest_sale(): array {
		return $this->primary_sale();
	}

	public function get_themeforest_purchase_date_display(): string {
		$sale = $this->primary_sale();
		return ! empty( $sale['sold_at'] ) ? gbt_tf_format_date( (string) $sale['sold_at'] ) : '';
	}

	public function get_themeforest_purchase_count(): int {
		$sale  = $this->primary_sale();
		$count = isset( $sale['purchase_count'] ) ? (int) $sale['purchase_count'] : 0;
		return max( 0, $count );
	}

	public function get_themeforest_purchase_when_display(): string {
		return gbt_tf_purchase_when_display( $this->primary_sale() );
	}

	public function get_themeforest_coupon_code(): string {
		$matched = $this->get_themeforest_coupon_entry();
		return is_array( $matched ) ? (string) $matched['coupon'] : '';
	}

	/**
	 * ThemeForest credit coupon: active legacy only (see is_themeforest_legacy_active()).
	 */
	public function is_themeforest_coupon_eligible(): bool {
		return $this->is_themeforest_legacy_active();
	}

	/**
	 * @return array{coupon:string,date:string,value:int|float}|null
	 */
	public function get_themeforest_coupon_entry(): ?array {
		if ( ! $this->is_themeforest_coupon_eligible() ) {
			return null;
		}

		// Credit only after ThemeForest support has expired.
		$sale = $this->primary_sale();
		if ( gbt_tf_support_is_active( $sale ) ) {
			return null;
		}

		$coupons = GBT_Dashboard_Setup::init()->get_global_config( 'themeforest_coupons' );
		if ( ! is_array( $coupons ) || empty( $coupons ) ) {
			return null;
		}

		return gbt_tf_coupon_entry( $sale, $coupons );
	}

	public function get_themeforest_credit_value(): int {
		$entry = $this->get_themeforest_coupon_entry();
		return is_array( $entry ) ? max( 0, (int) $entry['value'] ) : 0;
	}

	/**
	 * ThemeForest legacy UX: migrated from ThemeForest and has not yet paid for a Freemius plan.
	 */
	public function is_themeforest_legacy_active(): bool {
		$manager = GBT_License_Manager::get_instance();

		if ( ! $manager->is_themeforest_migrated_license() ) {
			return false;
		}

		return ! $manager->has_freemius_paid_plan();
	}

	/**
	 * First claim deadline for legacy TF credit: license created + CREDIT_GRACE_DAYS.
	 * Availability is not gated on this timestamp — credit stays claimable after
	 * the deadline and after the license expires (legacy only).
	 */
	public function get_coupon_until_ts(): int {
		if ( ! $this->is_themeforest_legacy_active() ) {
			return 0;
		}

		$manager = GBT_License_Manager::get_instance();
		$fs      = $manager->fs();
		$license = ( $fs && method_exists( $fs, '_get_license' ) ) ? $fs->_get_license() : null;
		if ( ! is_object( $license ) || empty( $license->created ) ) {
			return 0;
		}

		$created_ts = strtotime( (string) $license->created );
		if ( false === $created_ts ) {
			return 0;
		}

		return (int) $created_ts + ( self::CREDIT_GRACE_DAYS * DAY_IN_SECONDS );
	}

	public function get_coupon_until_display(): string {
		$ts = $this->get_coupon_until_ts();
		if ( $ts <= 0 ) {
			return '';
		}

		// After the first deadline, omit the date (credit stays claimable).
		if ( wp_date( 'Y-m-d', $ts ) < wp_date( 'Y-m-d', $this->now() ) ) {
			return '';
		}

		return gbt_tf_format_date( gmdate( 'c', $ts ) );
	}

	public function get_themeforest_support_until_display(): string {
		$sale = $this->primary_sale();
		return ! empty( $sale['supported_until'] ) ? gbt_tf_format_date( (string) $sale['supported_until'] ) : '';
	}

	/**
	 * @return array{case:string,bought:string,support_until:string,support_ts:int,until:string,until_ts:int,plan:string}|null
	 */
	public function get_grace_period_notice_data(): ?array {
		$manager = GBT_License_Manager::get_instance();
		$data    = $manager->get_display_data();

		if ( ! $this->is_themeforest_legacy_active() || $manager->is_lifetime() ) {
			return null;
		}
		if ( ! $manager->has_dated_expiration() ) {
			return null;
		}

		$sale = $this->primary_sale();
		if ( empty( $sale['sold_at'] ) ) {
			return null;
		}

		$fs      = $manager->fs();
		$license = ( $fs && method_exists( $fs, '_get_license' ) ) ? $fs->_get_license() : null;
		if ( ! is_object( $license ) || empty( $license->expiration ) ) {
			return null;
		}

		$until_ts = strtotime( (string) $license->expiration );
		if ( false === $until_ts ) {
			return null;
		}

		$bought = $this->get_themeforest_purchase_date_display();
		$until  = trim( (string) ( $data['expires'] ?? '' ) );
		if ( $bought === '' || $until === '' || $until === '—' ) {
			return null;
		}

		$support_raw = ! empty( $sale['supported_until'] ) ? (string) $sale['supported_until'] : '';
		$support_ts  = $support_raw !== '' ? strtotime( $support_raw ) : false;
		$support_fmt = $this->get_themeforest_support_until_display();
		$today_ymd   = wp_date( 'Y-m-d', $this->now() );

		if ( false === $support_ts || (int) $support_ts <= 0 ) {
			$case          = 'missing';
			$support_until = '';
			$support_ts    = 0;
		} elseif ( wp_date( 'Y-m-d', (int) $support_ts ) >= $today_ymd ) {
			$case          = 'active';
			$support_until = $support_fmt;
			$support_ts    = (int) $support_ts;
		} else {
			$case          = 'expired';
			$support_until = $support_fmt;
			$support_ts    = (int) $support_ts;
		}

		if ( ( 'active' === $case || 'expired' === $case ) && $support_until === '' ) {
			return null;
		}

		return array(
			'case'          => $case,
			'bought'        => $bought,
			'support_until' => $support_until,
			'support_ts'    => $support_ts,
			'until'         => $until,
			'until_ts'      => (int) $until_ts,
			'plan'          => gbt_tf_plan_name_for_copy( (string) ( $data['plan'] ?? '' ) ),
		);
	}

	/**
	 * Permanent yellow notice: unlocked credit + updates/support expiry + coupon CTA.
	 */
	public function render_grace_period_notice( string $wrap_class = 'mt-5' ): void {
		$data = $this->get_grace_period_notice_data();
		if ( ! is_array( $data ) ) {
			return;
		}

		$until = (string) ( $data['until'] ?? '' );
		if ( $until === '' ) {
			return;
		}

		$credit       = $this->get_themeforest_credit_value();
		$until_ts     = (int) ( $data['until_ts'] ?? 0 );
		$until_past   = $until_ts > 0 && wp_date( 'Y-m-d', $until_ts ) < wp_date( 'Y-m-d', $this->now() );
		$credit_until = $credit > 0 ? $this->get_coupon_until_display() : '';
		$message      = $this->grace_notice_message( $until, $until_past, $credit, $credit_until );
		if ( $message === '' ) {
			return;
		}
		$icon = $credit > 0 ? 'ticket' : 'information-circle';
		?>
		<div class="gbt-license-flash rounded-md border border-[var(--color-gbt-yellow)]/20 bg-[var(--color-gbt-yellow)]/10 px-4 py-3 text-sm text-[var(--color-gbt-yellow)]<?php echo $wrap_class !== '' ? ' ' . esc_attr( $wrap_class ) : ''; ?>" role="status">
			<span class="gbt-license-flash__icon" aria-hidden="true"><?php gbt_icon_e( $icon, 'size-5', 'solid', 20 ); ?></span>
			<span class="gbt-license-flash__body">
				<?php echo wp_kses( $message, gbt_tf_notice_allowed_html() ); ?>
			</span>
		</div>
		<?php
	}

	/**
	 * Combined Themeforest grace + credit selling panel (license page).
	 */
	public function render_tf_upgrade_offer( string $wrap_class = '' ): void {
		$offer = $this->get_tf_upgrade_offer_data();
		if ( ! is_array( $offer ) ) {
			return;
		}

		$this->render_tf_upgrade_offer_markup( $offer, 'dark', $wrap_class );
	}

	/**
	 * @return array{
	 *   until:string,
	 *   until_ts:int,
	 *   support_until:string,
	 *   support_case:string,
	 *   credit:int,
	 *   credit_until:string,
	 *   credit_ts:int,
	 *   purchase_when:string,
	 *   pricing_url:string,
	 *   show_expiry:bool,
	 *   show_credit:bool
	 * }|null
	 */
	public function get_tf_upgrade_offer_data(): ?array {
		if ( ! $this->is_themeforest_legacy_active() ) {
			return null;
		}

		$grace  = $this->get_grace_period_notice_data();
		$credit = $this->get_themeforest_credit_value();

		// Legacy credit stays shown after the first deadline and after license expiry.
		$show_credit  = $credit > 0;
		$credit_ts    = $show_credit ? $this->get_coupon_until_ts() : 0;
		$credit_until = $show_credit ? $this->get_coupon_until_display() : '';

		$show_expiry = is_array( $grace );

		$expires_until    = '';
		$expires_until_ts = 0;
		$support_until    = '';
		$support_case     = '';
		if ( is_array( $grace ) ) {
			$expires_until    = (string) $grace['until'];
			$expires_until_ts = (int) ( $grace['until_ts'] ?? 0 );
			$support_until    = (string) $grace['support_until'];
			$support_case     = (string) $grace['case'];
		}

		$days_left = ( $expires_until_ts > 0 && $expires_until_ts > $this->now() )
			? (int) ceil( ( $expires_until_ts - $this->now() ) / DAY_IN_SECONDS )
			: 0;

		$converted_date = '';
		$converted_ts   = false;
		$purchase_ts    = false;
		$support_ts     = false;
		$manager        = GBT_License_Manager::get_instance();
		$fs             = $manager->fs();
		$license        = ( $fs && method_exists( $fs, '_get_license' ) ) ? $fs->_get_license() : null;
		if ( is_object( $license ) && ! empty( $license->created ) ) {
			$converted_ts   = strtotime( (string) $license->created );
			$converted_date = gbt_tf_format_date( (string) $license->created );
		}
		$sale = $this->primary_sale();
		if ( ! empty( $sale['sold_at'] ) ) {
			$purchase_ts = strtotime( (string) $sale['sold_at'] );
		}
		if ( ! empty( $sale['supported_until'] ) ) {
			$support_ts = strtotime( (string) $sale['supported_until'] );
		}

		return array(
			'until'           => $expires_until,
			'until_ts'        => $expires_until_ts,
			'support_until'   => $support_until,
			'support_case'    => $support_case,
			'support_ts'      => false !== $support_ts ? (int) $support_ts : 0,
			'credit'          => $show_credit ? $credit : 0,
			'credit_until'    => $show_credit ? $credit_until : '',
			'credit_ts'       => $show_credit ? $credit_ts : 0,
			'purchase_when'   => $this->get_themeforest_purchase_when_display(),
			'purchase_date'   => $this->get_themeforest_purchase_date_display(),
			'purchase_ts'     => false !== $purchase_ts ? (int) $purchase_ts : 0,
			'converted_date'  => $converted_date,
			'converted_ts'    => false !== $converted_ts ? (int) $converted_ts : 0,
			'days_left'       => $days_left,
			'pricing_url'     => GBT_License_Manager::pricing_page_url(),
			'show_expiry'     => $show_expiry || $expires_until !== '',
			'show_credit'     => $show_credit,
		);
	}

	/**
	 * Migration history timeline for the TF upgrade offer.
	 * Events that fall on the same calendar day are grouped under one node.
	 *
	 * @param array{
	 *   until:string,
	 *   until_ts?:int,
	 *   support_until:string,
	 *   support_case:string,
	 *   support_ts?:int,
	 *   credit:int,
	 *   credit_until:string,
	 *   credit_ts?:int,
	 *   purchase_when:string,
	 *   purchase_date:string,
	 *   purchase_ts?:int,
	 *   converted_date:string,
	 *   converted_ts?:int,
	 *   show_credit:bool
	 * } $offer
	 * @return list<array{date:string,ts:int,kind:'past'|'today'|'now'|'future',events:list<array{id:string,label:string,desc:string,icon?:string,here?:bool}>}>
	 */
	private function build_tf_migration_timeline( array $offer ): array {
		$until          = (string) ( $offer['until'] ?? '' );
		$support_until  = (string) ( $offer['support_until'] ?? '' );
		$support_case   = (string) ( $offer['support_case'] ?? '' );
		$credit         = (int) ( $offer['credit'] ?? 0 );
		$credit_until   = (string) ( $offer['credit_until'] ?? '' );
		$purchase_when  = (string) ( $offer['purchase_when'] ?? '' );
		$purchase_date  = (string) ( $offer['purchase_date'] ?? '' );
		$converted_date = (string) ( $offer['converted_date'] ?? '' );
		$show_credit    = ! empty( $offer['show_credit'] ) && $credit > 0;
		$now            = $this->now();
		$today_ymd      = wp_date( 'Y-m-d', $now );
		$events         = array();

		$rank = array(
			'purchase'         => 0,
			'tf_support_ended' => 1,
			'converted'        => 2,
			'credit_unlocked'  => 3,
			'credit_expires'   => 4,
			'support_end'      => 5,
			'price_increase'   => 6,
		);

		$push = static function ( string $id, string $label, string $date_label, $ts, string $desc, string $icon = '' ) use ( &$events ): void {
			if ( false === $ts || (int) $ts <= 0 || $date_label === '' ) {
				return;
			}
			$ts = (int) $ts;
			if ( 'Today' !== $date_label ) {
				$short = gbt_tf_format_date_short( $ts );
				if ( $short !== '' ) {
					$date_label = $short;
				}
			}
			$events[] = array(
				'id'    => $id,
				'label' => $label,
				'date'  => $date_label,
				'ts'    => $ts,
				'desc'  => $desc,
				'icon'  => $icon,
			);
		};

		$purchase_ts = (int) ( $offer['purchase_ts'] ?? 0 );
		if ( $purchase_ts <= 0 && $purchase_date !== '' ) {
			$purchase_ts = (int) strtotime( $purchase_date );
		}
		if ( $purchase_date !== '' ) {
			$theme_name = (string) GBT_Dashboard_Setup::init()->get_theme_name();
			if ( $theme_name === '' ) {
				$theme_name = 'this theme';
			}
			$purchase_desc = sprintf(
				'You bought %1$s on Themeforest%2$s.',
				$theme_name,
				$purchase_when !== '' ? ' ' . $purchase_when : ''
			);
			$push( 'purchase', 'Initial purchase', $purchase_date, $purchase_ts, $purchase_desc );
		}

		$support_ts = (int) ( $offer['support_ts'] ?? 0 );
		if ( $support_ts <= 0 && $support_until !== '' ) {
			$support_ts = (int) strtotime( $support_until );
		}

		$until_ts = (int) ( $offer['until_ts'] ?? 0 );
		if ( $until_ts <= 0 && $until !== '' ) {
			$parsed = strtotime( $until );
			$until_ts = false !== $parsed ? (int) $parsed : 0;
		}

		// Skip TF support-ended when it falls on/after the license end date (same day counts as after).
		if (
			$support_until !== ''
			&& 'active' !== $support_case
			&& $support_ts > 0
			&& (
				$until_ts <= 0
				|| wp_date( 'Y-m-d', $support_ts ) < wp_date( 'Y-m-d', $until_ts )
			)
		) {
			$push(
				'tf_support_ended',
				'Themeforest support ended',
				$support_until,
				$support_ts,
				'Your original Themeforest support period is over.'
			);
		}

		$converted_ts = (int) ( $offer['converted_ts'] ?? 0 );
		if ( $converted_ts <= 0 && $converted_date !== '' ) {
			$converted_ts = (int) strtotime( $converted_date );
		}
		$converted_push_ts = $converted_ts > 0 ? $converted_ts : $now;
		if ( $converted_ts > 0 && wp_date( 'Y-m-d', $converted_ts ) === $today_ymd ) {
			$converted_label = 'Today';
		} elseif ( $converted_date !== '' ) {
			$converted_label = $converted_date;
		} elseif ( $converted_ts > 0 ) {
			$converted_short = gbt_tf_format_date_short( $converted_ts );
			$converted_label   = $converted_short !== '' ? $converted_short : wp_date( 'M j, Y', $converted_ts );
		} else {
			$converted_label = 'Today';
		}

		$until_past = $until_ts > 0 && wp_date( 'Y-m-d', $until_ts ) < $today_ymd;

		$credit_ts = (int) ( $offer['credit_ts'] ?? 0 );
		if ( $credit_ts <= 0 && $show_credit && $credit_until !== '' ) {
			$parsed    = strtotime( $credit_until );
			$credit_ts = false !== $parsed ? (int) $parsed : 0;
		}

		if ( 'active' === $support_case ) {
			$converted_desc = 'Your Themeforest purchase code was converted to a license key.<br>You’re on a modern platform for updates and support.';
		} elseif ( $until !== '' && $until_past ) {
			$converted_desc = sprintf(
				'Your Themeforest purchase code was converted to a license key.<br>You were on a modern platform for updates and support, covered until %s.',
				$until
			);
		} elseif ( $until !== '' ) {
			$converted_desc = sprintf(
				'Your Themeforest purchase code was converted to a license key.<br>You’re on a modern platform for updates and support, covered until %s.',
				$until
			);
		} else {
			$converted_desc = 'Your Themeforest purchase code was converted to a license key.<br>You’re on a modern platform for updates and support again.';
		}
		$theme_name = (string) GBT_Dashboard_Setup::init()->get_theme_name();
		$converted_title = $theme_name !== ''
			? sprintf( 'You’ve moved to the new %s platform', $theme_name )
			: 'You’ve moved to the new theme platform';
		$push(
			'converted',
			$converted_title,
			$converted_label,
			$converted_push_ts,
			$converted_desc
		);

		if ( $show_credit ) {
			$credit_unlock_desc = $credit_until !== ''
				? sprintf(
					'You earned a $%1$d credit from that Themeforest purchase.<br>Claim it before %2$s on a yearly plan.',
					$credit,
					$credit_until
				)
				: sprintf(
					'You earned a $%1$d credit from that Themeforest purchase.<br>Claim it on a yearly plan.',
					$credit
				);
			$push(
				'credit_unlocked',
				'Credit unlocked',
				$converted_label,
				$converted_push_ts,
				$credit_unlock_desc,
				'ticket'
			);
		}

		// credit_until is empty after the deadline (get_coupon_until_display) — date not shown.
		$same_day = (
			$credit_until !== ''
			&& $credit_ts > 0
			&& $until_ts > 0
			&& wp_date( 'Y-m-d', $credit_ts ) === wp_date( 'Y-m-d', $until_ts )
		);

		if ( $same_day ) {
			if ( $until_past ) {
				$push(
					'support_end',
					'Updates & support ended',
					$until,
					$until_ts,
					'Updates and support ended on this date.'
				);
			} else {
				$push(
					'support_end',
					'Updates & support end',
					$until,
					$until_ts,
					'Choose a plan before this date to stay covered.'
				);
			}
		} else {
			if ( $show_credit && $credit_until !== '' ) {
				$push(
					'credit_expires',
					'Credit expires',
					$credit_until,
					$credit_ts,
					'Credit valid through this date — claim it before it\'s gone.',
					'ticket'
				);
			}
			if ( $until !== '' ) {
				if ( $until_past ) {
					$push(
						'support_end',
						'Updates & support ended',
						$until,
						$until_ts,
						'Updates and support ended on this date.'
					);
				} else {
					$push(
						'support_end',
						'Updates & support end',
						$until,
						$until_ts,
						'Choose a plan before this date to keep receiving updates and support.'
					);
				}
			}
		}

		$price_increase = function_exists( 'gbt_tf_price_increase_scheduled' ) ? gbt_tf_price_increase_scheduled() : null;
		if ( is_array( $price_increase ) ) {
			$price_increase_date = (string) $price_increase['date'];
			$price_increase_ts   = strtotime( $price_increase_date );
			if ( false !== $price_increase_ts && (int) $price_increase_ts > 0 ) {
				$price_increase_ymd = wp_date( 'Y-m-d', (int) $price_increase_ts );
				if ( $price_increase_ymd > $today_ymd ) {
					$push(
						'price_increase',
						'Price increase scheduled',
						$price_increase_date,
						(int) $price_increase_ts,
						'Plan prices go up after this date — choose a plan before then to lock in current pricing.'
					);
				}
			}
		}

		usort(
			$events,
			static function ( array $a, array $b ) use ( $rank ): int {
				$day_a = wp_date( 'Y-m-d', $a['ts'] );
				$day_b = wp_date( 'Y-m-d', $b['ts'] );
				if ( $day_a !== $day_b ) {
					return $a['ts'] <=> $b['ts'];
				}
				$ra = $rank[ $a['id'] ] ?? 5;
				$rb = $rank[ $b['id'] ] ?? 5;
				return $ra <=> $rb;
			}
		);

		$grouped = array();
		foreach ( $events as $event ) {
			$day_key = wp_date( 'Y-m-d', $event['ts'] );
			if ( ! isset( $grouped[ $day_key ] ) ) {
				$grouped[ $day_key ] = array(
					'date'   => ( $day_key === $today_ymd ) ? 'Today' : $event['date'],
					'ts'     => $event['ts'],
					'kind'   => 'past',
					'events' => array(),
				);
			}
			// Prefer a real formatted date over "Today" only when the day is not today.
			if ( $day_key !== $today_ymd && 'Today' !== $event['date'] ) {
				$grouped[ $day_key ]['date'] = $event['date'];
			}
			$grouped[ $day_key ]['events'][] = array(
				'id'    => (string) ( $event['id'] ?? '' ),
				'label' => $event['label'],
				'desc'  => $event['desc'],
				'icon'  => (string) ( $event['icon'] ?? '' ),
			);
		}

		$nodes = array_values( $grouped );

		$past_nodes   = array();
		$future_nodes = array();
		$today_node   = null;

		foreach ( $nodes as $node ) {
			$node_ymd = wp_date( 'Y-m-d', $node['ts'] );
			if ( $node_ymd < $today_ymd ) {
				$node['kind'] = 'past';
				$past_nodes[] = $node;
			} elseif ( $node_ymd === $today_ymd ) {
				$today_node = $node;
			} else {
				$node['kind'] = 'future';
				$future_nodes[] = $node;
			}
		}

		// Calendar “today” (milestones on this date) + separate “now” anchor for You are here / next steps.
		$here_event = array(
			'id'    => 'here',
			'label' => 'You are here',
			'desc'  => '',
			'icon'  => '',
			'here'  => true,
		);

		if ( is_array( $today_node ) ) {
			$today_node['date'] = 'Today';
			$today_node['kind'] = 'today';
		}

		$now_node = array(
			'date'   => is_array( $today_node ) ? 'Now' : 'Today',
			'ts'     => $now,
			'kind'   => 'now',
			'events' => array( $here_event ),
		);

		$timeline = $past_nodes;
		if ( is_array( $today_node ) ) {
			$timeline[] = $today_node;
		}
		$timeline[] = $now_node;

		return array_merge( $timeline, $future_nodes );
	}

	/**
	 * @param array{
	 *   until:string,
	 *   support_until:string,
	 *   support_case:string,
	 *   credit:int,
	 *   credit_until:string,
	 *   purchase_when:string,
	 *   purchase_date:string,
	 *   converted_date?:string,
	 *   days_left:int,
	 *   pricing_url:string,
	 *   show_expiry:bool,
	 *   show_credit:bool
	 * } $offer
	 */
	private function render_tf_upgrade_offer_markup( array $offer, string $variant, string $wrap_class ): void {
		$is_dark       = ( 'dark' === $variant );
		$pricing_url   = $is_dark ? (string) $offer['pricing_url'] : '#gbt-pricing-plans';
		$until         = (string) $offer['until'];
		$until_ts      = (int) ( $offer['until_ts'] ?? 0 );
		$credit        = (int) $offer['credit'];
		$days_left     = (int) ( $offer['days_left'] ?? 0 );
		$show_credit   = ! empty( $offer['show_credit'] ) && $credit > 0;
		$credit_until  = (string) ( $offer['credit_until'] ?? '' );
		$until_past    = $until_ts > 0 && wp_date( 'Y-m-d', $until_ts ) < wp_date( 'Y-m-d', $this->now() );
		$cta_label     = $show_credit
			? 'Choose a plan'
			: ( $is_dark ? 'Choose a plan' : 'Browse plans below' );

		$nodes         = $this->build_tf_migration_timeline( $offer );
		$show_timeline = count( $nodes ) >= 2;
		$last_node_index = count( $nodes ) - 1;

		$theme_light = $is_dark ? '' : ' gbt-tf-offer--light';
		$shell       = $is_dark
			? 'gbt-tf-offer gbt-tf-offer--flush'
			: 'gbt-tf-offer text-left';

		$date_hl    = $is_dark ? 'text-[var(--color-gbt-yellow-soft)]' : 'text-[#8a6116]';
		$muted_txt  = $is_dark ? 'text-gray-400' : 'text-gray-500';
		$strong_txt = $is_dark ? 'text-white' : 'text-gray-900';
		$line_cls   = $is_dark ? 'bg-white/10' : 'bg-gray-200';
		$dot_cls    = $is_dark ? 'bg-gray-600 ring ring-gray-500' : 'bg-gray-100 ring ring-gray-300';

		$element_id = $is_dark ? 'gbt-tf-offer-notice' : 'gbt-tf-offer-pricing';
		?>
		<div id="<?php echo esc_attr( $element_id ); ?>" class="<?php echo esc_attr( $shell . $theme_light ); ?><?php echo $wrap_class !== '' ? ' ' . esc_attr( $wrap_class ) : ''; ?>" role="region" aria-label="License plan options">
			<?php if ( $show_timeline ) : ?>
				<ul role="list" class="m-0 flex flex-col" aria-label="License journey">
					<?php
					foreach ( $nodes as $node_index => $node ) :
						$is_past  = ( 'past' === $node['kind'] );
						$is_now   = 'now' === (string) ( $node['kind'] ?? '' );
						$is_today = 'today' === (string) ( $node['kind'] ?? '' );
						$is_end   = false;
						$credit_only = true;
						$has_body_event = false;
						foreach ( $node['events'] as $ev ) {
							if ( ! empty( $ev['here'] ) || 'here' === ( $ev['id'] ?? '' ) ) {
								continue;
							}
							$has_body_event = true;
							$ev_id = (string) ( $ev['id'] ?? '' );
							$is_accent = ( 'credit_unlocked' === $ev_id )
								|| ( 'credit_expires' === $ev_id && $is_past );
							if ( ! $is_accent ) {
								$credit_only = false;
							}
							if ( 'support_end' === $ev_id ) {
								$is_end = true;
							}
						}
						if ( ! $has_body_event ) {
							$credit_only = false;
						}
						// Default = past-item colors. Accents: blue (today date/mark), yellow (credit), red (support end).
						$label_cls = $strong_txt;
						$time_cls  = $is_now
							? 'text-[var(--color-gbt-blue-lighter)]'
							: ( $is_end ? '' : ( $credit_only ? $date_hl : $muted_txt ) );
						$row_cls   = 'gbt-tf-feed__row'
							. ( $is_now ? ' is-today is-next' : '' )
							. ( $is_today ? ' is-today-cal' : '' )
							. ( $is_end ? ' is-end' : '' )
							. ( $credit_only ? ' is-credit' : '' )
							. ( $node_index === $last_node_index ? ' is-last' : '' );
						?>
						<li class="<?php echo esc_attr( $row_cls ); ?>">
							<time class="gbt-tf-feed__date<?php echo $is_now ? '' : ' ' . esc_attr( $time_cls ); ?>">
								<?php if ( $is_now ) : ?>
									<span class="gbt-tf-feed__pill gbt-tf-feed__pill--here"><?php echo esc_html( $node['date'] ); ?></span>
								<?php else : ?>
									<?php echo esc_html( $node['date'] ); ?>
								<?php endif; ?>
							</time>
							<div class="gbt-tf-feed__rail" aria-hidden="true">
								<div class="gbt-tf-feed__line <?php echo esc_attr( $line_cls ); ?>"></div>
								<div class="gbt-tf-feed__mark">
									<?php if ( $is_end ) : ?>
										<span class="inline-flex size-5 items-center justify-center">
											<?php gbt_icon_e( $is_past ? 'x-circle' : 'clock', 'size-5', 'solid', 20 ); ?>
										</span>
									<?php elseif ( $is_now ) : ?>
										<span class="relative flex size-2.5 items-center justify-center">
											<span class="absolute inline-flex size-full animate-ping rounded-full bg-[var(--color-gbt-blue-lighter)] opacity-40"></span>
											<span class="relative size-2.5 rounded-full bg-[var(--color-gbt-blue-lighter)]"></span>
										</span>
									<?php elseif ( $credit_only ) : ?>
										<span class="size-2.5 rounded-full bg-[var(--tf-accent)] ring ring-[var(--tf-accent)]/40"></span>
									<?php else : ?>
										<span class="size-2.5 rounded-full <?php echo esc_attr( $dot_cls ); ?>"></span>
									<?php endif; ?>
								</div>
							</div>
							<div class="gbt-tf-feed__body min-w-0">
								<?php
								$here_event   = null;
								$body_events  = array();
								foreach ( $node['events'] as $event ) {
									$eid = (string) ( $event['id'] ?? '' );
									if ( ! empty( $event['here'] ) || 'here' === $eid ) {
										$here_event = $event;
									} else {
										$body_events[] = $event;
									}
								}

								if ( is_array( $here_event ) ) :
									?>
									<div class="gbt-tf-feed__decision">
										<div class="gbt-tf-feed__event" data-event="here">
											<div class="gbt-tf-feed__title gbt-tf-feed__title--wrap">
												<span class="gbt-tf-feed__pill gbt-tf-feed__pill--here"><?php echo esc_html( $here_event['label'] ); ?></span>
												<?php if ( $is_now ) : ?>
													<span class="gbt-tf-feed__pill gbt-tf-feed__pill--ask"><?php
														if ( $until !== '' && ! $until_past ) {
															$until_no_year = $until_ts > 0 ? date_i18n( 'F j', $until_ts ) : $until;
															echo 'What happens&nbsp;<em class="italic">after</em>&nbsp;' . esc_html( $until_no_year ) . '? You decide.';
														} else {
															echo 'What&rsquo;s next? You decide.';
														}
													?></span>
													<?php echo $this->tf_why_decide_link(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
												<?php endif; ?>
											</div>
										</div>
										<?php if ( $is_now && $until !== '' && ! $until_past ) : ?>
											<div class="gbt-tf-feed__notes <?php echo esc_attr( $muted_txt ); ?>">
												<div class="gbt-tf-feed__note-line">
													<span class="gbt-tf-feed__note-icon" aria-hidden="true"><?php gbt_icon_e( 'information-circle', 'size-4 shrink-0', 'solid', 16 ); ?></span>
													<span><?php
													echo esc_html(
														( $show_credit && $credit > 0 )
															? 'On that date, updates and support end, and any unused credit expires.'
															: 'On that date, updates and support end.'
													);
													?></span>
												</div>
												<div class="gbt-tf-feed__note-line">
													<span class="gbt-tf-feed__note-icon" aria-hidden="true"><?php gbt_icon_e( 'information-circle', 'size-4 shrink-0', 'solid', 16 ); ?></span>
													<span>Don’t let it expire — choose now; billing starts after current support ends.</span>
												</div>
											</div>
										<?php endif; ?>
										<?php
										if ( $is_now ) {
											$this->render_tf_next_content(
												$until,
												$until_past,
												$strong_txt,
												$muted_txt,
												$is_dark,
												$show_credit,
												$credit,
												$pricing_url,
												$cta_label,
												$date_hl,
												$credit_until,
												'',
												false
											);
										}
										?>
									</div>
									<?php
								endif;

								foreach ( $body_events as $event ) :
									$event_id   = (string) ( $event['id'] ?? '' );
									$event_icon = (string) ( $event['icon'] ?? '' );
									$is_accent  = ( 'credit_unlocked' === $event_id )
										|| ( 'credit_expires' === $event_id && $is_past );
									$is_support_end = ( 'support_end' === $event_id );
									if ( $is_accent ) {
										$event_cls = $date_hl;
									} elseif ( $is_support_end ) {
										$event_cls = '';
									} else {
										$event_cls = $label_cls;
									}
									?>
									<div class="gbt-tf-feed__event<?php echo $is_accent ? ' gbt-tf-feed__event--credit' : ''; ?>"<?php echo $event_id !== '' ? ' data-event="' . esc_attr( $event_id ) . '"' : ''; ?>>
										<div class="gbt-tf-feed__title">
											<?php if ( $event_icon !== '' ) : ?>
												<span class="inline-flex shrink-0 <?php echo esc_attr( $event_cls ); ?>"><?php gbt_icon_e( $event_icon, 'size-4', 'solid', 20 ); ?></span>
											<?php endif; ?>
											<span class="gbt-tf-feed__label <?php echo esc_attr( $event_cls ); ?>"><?php
												echo esc_html( $event['label'] );
												if ( $is_support_end && $days_left > 0 ) :
													?> <span class="gbt-tf-feed__meta">— <?php echo esc_html( (string) $days_left ); ?> days left</span><?php
												endif;
											?></span>
										</div>
										<?php if ( $event['desc'] !== '' ) : ?>
											<p class="gbt-tf-feed__desc <?php echo esc_attr( $muted_txt ); ?>"><?php echo wp_kses( $event['desc'], gbt_tf_notice_allowed_html() ); ?></p>
										<?php endif; ?>
									</div>
								<?php endforeach; ?>
							</div>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<?php if ( $until !== '' ) : ?>
					<p class="mt-4 mb-0 text-sm font-medium <?php echo esc_attr( $until_past ? 'text-[var(--color-gbt-red)]' : $date_hl ); ?>">
						<?php if ( $until_past ) : ?>
							Updates and support ended <?php echo esc_html( $until ); ?>
						<?php else : ?>
							Updates and support until <?php echo esc_html( $until ); ?>
							<?php if ( $days_left > 0 ) : ?>
								<span class="gbt-tf-feed__meta ml-2">— <?php echo esc_html( (string) $days_left ); ?> days left</span>
							<?php endif; ?>
						<?php endif; ?>
					</p>
				<?php endif; ?>

				<div class="mt-6">
					<?php
					$this->render_tf_next_content(
						$until,
						$until_past,
						$strong_txt,
						$muted_txt,
						$is_dark,
						$show_credit,
						$credit,
						$pricing_url,
						$cta_label,
						$date_hl,
						$credit_until
					);
					?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Linked CTA to the TF updates announcement (sits after the “You decide.” pill).
	 */
	private function tf_why_decide_link(): string {
		return '<a href="' . esc_url( self::TF_UPDATES_ANNOUNCEMENT_URL ) . '" target="_blank" rel="noopener noreferrer" class="gbt-tf-feed__why-decide-link">Learn why</a>';
	}

	/**
	 * “What’s next?” intro (optional) and Option A / B cards.
	 */
	private function render_tf_next_content(
		string $until,
		bool $until_past,
		string $strong_txt,
		string $muted_txt,
		bool $is_dark,
		bool $show_credit,
		int $credit,
		string $pricing_url,
		string $cta_label,
		string $date_hl,
		string $credit_until,
		string $wrap_class = '',
		bool $show_intro = true
	): void {
		if ( $show_intro ) :
			?>
		<div class="gbt-tf-feed__event" data-event="next">
			<div class="gbt-tf-feed__title">
				<?php if ( $until !== '' && $until_past ) : ?>
					<span class="gbt-tf-feed__label <?php echo esc_attr( $strong_txt ); ?>">
						<span class="text-[var(--color-gbt-red)]">Updates and support ended on <?php echo esc_html( $until ); ?>.</span> What&rsquo;s next?
					</span>
				<?php elseif ( $until !== '' ) : ?>
					<span class="gbt-tf-feed__label <?php echo esc_attr( $strong_txt ); ?>">
						What happens&nbsp;<em class="italic">after</em>&nbsp;<?php echo esc_html( $until ); ?>?
					</span>
				<?php else : ?>
					<span class="gbt-tf-feed__label <?php echo esc_attr( $strong_txt ); ?>">What&rsquo;s next?</span>
				<?php endif; ?>
			</div>
			<p class="gbt-tf-feed__desc <?php echo esc_attr( $muted_txt ); ?>">You decide.</p>
		</div>
			<?php
		endif;
		$this->render_tf_offer_paths(
			$is_dark,
			$show_credit,
			$credit,
			$pricing_url,
			$cta_label,
			$date_hl,
			$muted_txt,
			$strong_txt,
			$wrap_class,
			$until_past,
			$credit_until
		);
	}

	/**
	 * Option A / Option B path cards for the TF upgrade offer.
	 */
	private function render_tf_offer_paths(
		bool $is_dark,
		bool $show_credit,
		int $credit,
		string $pricing_url,
		string $cta_label,
		string $date_hl,
		string $muted_txt,
		string $strong_txt,
		string $wrap_class = '',
		bool $until_past = false,
		string $credit_until = ''
	): void {
		// credit_until empty after first deadline — same rule as get_coupon_until_display().
		$show_credit_deadline = $show_credit && $credit_until !== '';
		$path_base            = 'gbt-tf-offer__path relative flex h-full flex-col rounded-lg';
		$path_a               = $path_base . ' gbt-tf-offer__path--quiet';
		$path_b               = $path_base . ' gbt-tf-offer__path--hot';
		$cta_class            = 'inline-flex h-11 w-full items-center justify-center gap-2 rounded-md bg-[var(--color-gbt-blue)] px-4 text-sm font-medium leading-none text-white no-underline shadow-none transition duration-150 ease-in-out hover:bg-[var(--color-gbt-blue-darker)]';
		$path_a_title         = $until_past
			? 'Leave it expired'
			: 'Let it expire';
		$path_b_title         = $until_past ? 'Choose a plan &amp; restore coverage' : 'Choose a plan &amp; stay covered';
		$path_b_support       = $until_past ? 'Updates &amp; support resume' : 'Updates &amp; support continue';
		$claim_credit_html    = $show_credit_deadline
			? sprintf(
				'<strong class="font-semibold %1$s">Claim your $%2$d credit</strong> — valid through %3$s.',
				esc_attr( $date_hl ),
				$credit,
				esc_html( $credit_until )
			)
			: sprintf(
				'<strong class="font-semibold %1$s">Claim your $%2$d credit</strong>.',
				esc_attr( $date_hl ),
				$credit
			);
		?>
		<div class="gbt-tf-offer__paths<?php echo $wrap_class !== '' ? ' ' . esc_attr( $wrap_class ) : ''; ?>">
			<div class="<?php echo esc_attr( $path_b ); ?>">
				<p class="m-0 flex min-h-6 items-center gap-2 text-sm font-medium <?php echo esc_attr( $date_hl ); ?>">
					<span>Option A</span>
					<span class="inline-flex items-center gap-1 rounded-full bg-[var(--tf-accent)] px-2.5 py-0.5 text-xs font-semibold leading-none text-gray-900">
						<?php gbt_icon_e( 'shield-check', 'size-4 shrink-0', 'solid', 20 ); ?>
						Safer choice
					</span>
				</p>
				<p class="m-0 mt-2 text-base font-semibold <?php echo esc_attr( $strong_txt ); ?>"><?php echo $path_b_title; ?></p>
				<ul class="m-0 mt-3 flex list-none flex-col gap-1.5 p-0 text-sm leading-6 <?php echo $is_dark ? 'text-gray-300' : 'text-gray-700'; ?>">
					<li class="flex max-w-full items-start gap-x-2.5">
						<span class="inline-flex h-6 shrink-0 items-center"><?php gbt_icon_e( 'check', 'size-4 shrink-0 text-[var(--color-gbt-green)]', 'solid', 16 ); ?></span>
						<span><?php echo $path_b_support; ?></span>
					</li>
					<li class="flex max-w-full items-start gap-x-2.5">
						<span class="inline-flex h-6 shrink-0 items-center"><?php gbt_icon_e( 'check', 'size-4 shrink-0 text-[var(--color-gbt-green)]', 'solid', 16 ); ?></span>
						<span><strong class="font-semibold <?php echo esc_attr( $strong_txt ); ?>">Monthly</strong>, <strong class="font-semibold <?php echo esc_attr( $strong_txt ); ?>">yearly</strong>, or <strong class="font-semibold <?php echo esc_attr( $strong_txt ); ?>">lifetime</strong></span>
					</li>
					<?php if ( $show_credit ) : ?>
						<li class="flex max-w-full items-start gap-x-2.5">
							<span class="inline-flex h-6 shrink-0 items-center"><?php gbt_icon_e( 'ticket', 'size-4 shrink-0 ' . esc_attr( $date_hl ), 'solid', 20 ); ?></span>
							<span><?php echo $claim_credit_html; ?></span>
						</li>
					<?php endif; ?>
				</ul>

				<?php if ( $pricing_url !== '' ) : ?>
					<div class="mt-auto pt-4">
						<a href="<?php echo esc_url( $pricing_url ); ?>" class="<?php echo esc_attr( $cta_class ); ?>">
							<?php echo esc_html( $cta_label ); ?>
						</a>
					</div>
				<?php else : ?>
					<p class="m-0 mt-auto pt-4 text-sm <?php echo esc_attr( $muted_txt ); ?>">&nbsp;</p>
				<?php endif; ?>
			</div>

			<div class="<?php echo esc_attr( $path_a ); ?>">
				<p class="m-0 flex min-h-6 items-center text-sm font-medium <?php echo esc_attr( $muted_txt ); ?>">Option B</p>
				<p class="m-0 mt-2 text-base font-semibold <?php echo esc_attr( $strong_txt ); ?>"><?php echo esc_html( $path_a_title ); ?></p>
				<ul class="m-0 mt-3 flex list-none flex-col gap-1.5 p-0 text-sm leading-6 <?php echo esc_attr( $muted_txt ); ?>">
					<li class="flex max-w-full items-start gap-x-2.5">
						<span class="inline-flex h-6 shrink-0 items-center"><?php gbt_icon_e( 'check', 'size-4 shrink-0 ' . ( $is_dark ? 'text-gray-500' : 'text-gray-400' ), 'solid', 16 ); ?></span>
						<span>Shop keeps running as-is</span>
					</li>
					<li class="flex max-w-full items-start gap-x-2.5">
						<span class="inline-flex h-6 shrink-0 items-center"><?php gbt_icon_e( 'x-circle', 'size-4 shrink-0 text-[var(--color-gbt-red)]', 'solid', 20 ); ?></span>
						<span>No updates or support</span>
					</li>
					<?php if ( $show_credit_deadline ) : ?>
						<li class="flex max-w-full items-start gap-x-2.5">
							<span class="inline-flex h-6 shrink-0 items-center"><?php gbt_icon_e( 'ticket', 'size-4 shrink-0 text-[var(--color-gbt-red)]', 'solid', 20 ); ?></span>
							<span>Unlocked $<?php echo esc_html( (string) $credit ); ?> credit lost</span>
						</li>
					<?php endif; ?>
				</ul>
				<p class="m-0 mt-auto pt-4 text-sm <?php echo esc_attr( $muted_txt ); ?>">No action needed</p>
			</div>
		</div>
		<?php
	}

	private function grace_notice_message( string $until, bool $until_past, int $credit, string $credit_until = '' ): string {
		if ( $until === '' ) {
			return '';
		}

		if ( $credit > 0 ) {
			// Prefer coupon deadline while it is still active; after that, fall back to coverage.
			if ( $credit_until !== '' ) {
				return sprintf(
					'You’ve unlocked a $%1$d credit — use it toward a plan that keeps your updates from expiring.<br>Credit valid through %2$s.',
					$credit,
					$credit_until
				);
			}

			if ( $until_past ) {
				return sprintf(
					'You’ve unlocked a $%1$d credit — claim it toward a plan that keeps your updates from expiring. Your coverage ended %2$s.',
					$credit,
					$until
				);
			}

			return sprintf(
				'You’ve unlocked a $%1$d credit — claim it toward a plan that keeps your updates from expiring. Your current coverage ends %2$s.',
				$credit,
				$until
			);
		}

		if ( $until_past ) {
			return sprintf(
				'Your coverage ended %s — choose a plan that keeps your updates from expiring when you are ready.',
				$until
			);
		}

		return sprintf(
			'Your current coverage ends %s — choose a plan that keeps your updates from expiring when you are ready.',
			$until
		);
	}

	public function is_grace_notice_dismissed(): bool {
		return (bool) get_user_meta( get_current_user_id(), self::GRACE_DISMISS_META, true );
	}

	public function is_credit_notice_dismissed(): bool {
		return (bool) get_user_meta( get_current_user_id(), self::CREDIT_DISMISS_META, true );
	}

	public function ajax_dismiss_grace_notice(): void {
		$this->ajax_dismiss_notice( self::GRACE_DISMISS_META, self::GRACE_DISMISS_ACTION );
	}

	public function ajax_dismiss_credit_notice(): void {
		$this->ajax_dismiss_notice( self::CREDIT_DISMISS_META, self::CREDIT_DISMISS_ACTION );
	}

	private function ajax_dismiss_notice( string $meta_key, string $nonce_action ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
		}
		check_ajax_referer( $nonce_action, 'nonce' );
		update_user_meta( get_current_user_id(), $meta_key, 1 );
		wp_send_json_success();
	}
}

GBT_License_Converter::init();
