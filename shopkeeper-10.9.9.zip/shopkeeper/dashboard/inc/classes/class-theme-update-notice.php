<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Theme update notice + unlicensed blocked package:
 * - Admin notice mirrors WordPress update_themes (licensed and unlicensed)
 * - Inject blocked:// package from GitHub JSON so Themes / Updates UI can list the update when unlicensed
 * - Block actual download until Freemius license is active
 *
 * Dismissible notice via GBT_Notification_Handler (resets after 7 days).
 */
class GBT_Theme_Update_Notice {

	const BLOCKED_URL_PREFIX = 'blocked://';

	private static $instance = null;

	private function __construct() {}

	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public static function init(): void {
		static $booted = false;
		if ( $booted ) {
			return;
		}
		$booted = true;

		$instance = self::get_instance();
		add_action( 'admin_notices', array( $instance, 'render' ) );
		add_action( 'admin_enqueue_scripts', array( $instance, 'enqueue_assets' ) );
		add_filter( 'site_transient_update_themes', array( $instance, 'inject_blocked_update' ), 999 );
		add_filter( 'upgrader_pre_download', array( $instance, 'block_download' ), 10, 3 );
	}

	/**
	 * Show update in WP Themes / Updates UI with a non-downloadable package.
	 *
	 * @param object|false $transient
	 * @return object|false
	 */
	public function inject_blocked_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$update = $this->get_blocked_update_from_json();
		if ( ! $update ) {
			return $transient;
		}

		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}

		$transient->response[ $update['theme'] ] = $update;
		return $transient;
	}

	/**
	 * Fail install attempts that use our blocked:// package.
	 *
	 * @param bool|WP_Error $reply
	 * @param string        $package
	 * @param WP_Upgrader   $upgrader
	 * @return bool|WP_Error
	 */
	public function block_download( $reply, $package, $upgrader ) {
		if ( ! is_a( $upgrader, 'Theme_Upgrader' ) ) {
			return $reply;
		}

		if ( ! is_string( $package ) || strpos( $package, self::BLOCKED_URL_PREFIX ) !== 0 ) {
			return $reply;
		}

		$setup = GBT_Dashboard_Setup::init();
		$url   = admin_url( 'admin.php?page=getbowtied-license' );

		return new WP_Error(
			$setup->get_theme_slug() . '_update_restricted',
			sprintf(
				'%s requires an active license to update. <a href="%s" target="_top"><strong>Activate now</strong></a>.',
				esc_html( $setup->get_theme_name() ),
				esc_url( $url )
			),
			array( 'theme' => $setup->get_theme_slug() )
		);
	}

	/**
	 * Enqueue auto-update handler when the update notice is visible and auto-updates are off.
	 */
	public function enqueue_assets(): void {
		if ( ! current_user_can( 'update_themes' ) ) {
			return;
		}

		$context = $this->get_notice_context();

		if ( ! $context || $context['auto_update_enabled'] ) {
			return;
		}

		$setup      = GBT_Dashboard_Setup::init();
		$base_paths = $setup->get_base_paths();

		wp_enqueue_script(
			'getbowtied-auto-update-handler',
			$base_paths['url'] . '/dashboard/js/auto-update-handler.js',
			array( 'jquery' ),
			$setup->get_theme_version(),
			true
		);

		wp_localize_script(
			'getbowtied-auto-update-handler',
			'gbtAutoUpdateData',
			array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'gbt_enable_auto_updates' ),
			)
		);
	}

	/**
	 * Admin notice when WP lists a theme update.
	 * Uses the same filtered update_themes transient as Dashboard → Updates / version badge.
	 * Licensed → Updates; expired → pricing; unlicensed → license activation.
	 */
	public function render(): void {
		$context = $this->get_notice_context();

		if ( ! $context ) {
			return;
		}

		$setup      = GBT_Dashboard_Setup::init();
		$slug        = $context['slug'];
		$new_version = $context['new_version'];
		$message_id  = $context['message_id'];
		$licensed    = $context['licensed'];
		$expired     = $context['expired'];
		$theme_name  = $setup->get_theme_name();
		$current     = $setup->get_theme_version();

		if ( $licensed ) {
			$cta_url   = admin_url( 'update-core.php#update-themes-table' );
			$cta_label = 'Update now';
			$cta_tail  = ' — includes new features and security fixes.';
		} elseif ( $expired ) {
			$cta_url   = GBT_License_Manager::pricing_page_url();
			$cta_label = 'Renew your license';
			$cta_tail  = ' to update — includes new features and security fixes.';
		} else {
			$cta_url   = GBT_License_Manager::license_page_url();
			$cta_label = 'Activate your license';
			$cta_tail  = ' to update — includes new features and security fixes.';
		}
		?>
		<div
			class="notice notice-info is-dismissible gbt-dashboard-notification"
			data-message-id="<?php echo esc_attr( $message_id ); ?>"
			data-theme-slug="<?php echo esc_attr( $slug ); ?>"
		>
			<p style="display:flex;align-items:center;">
				<span class="dashicons dashicons-update" style="color:var(--wp-admin-theme-color);margin-right:8px;"></span>
				<span>
					<strong><?php echo esc_html( $theme_name ); ?> <?php echo esc_html( $new_version ); ?> is available.</strong>
					You&rsquo;re on <?php echo esc_html( $current ); ?>.
					<a href="<?php echo esc_url( $cta_url ); ?>"><strong><?php echo esc_html( $cta_label ); ?></strong></a><?php echo esc_html( $cta_tail ); ?>
					<?php if ( ! $context['auto_update_enabled'] ) : ?>
						<span
							class="gbt-auto-update-text-wrapper"
							data-enabling-text="<?php echo esc_attr__( 'Enabling auto-updates…', 'getbowtied' ); ?>"
							data-success-text="<?php echo esc_attr__( 'Auto-updates are enabled.', 'getbowtied' ); ?>"
						>
							<?php
							echo esc_html__( 'You may also', 'getbowtied' ) . ' ';
							printf(
								'<a href="#" class="gbt-enable-auto-updates gbt-auto-update-link" data-theme="%1$s"><strong>%2$s</strong></a>',
								esc_attr( $slug ),
								esc_html__( 'enable automatic updates', 'getbowtied' )
							);
							echo ' ' . esc_html__( "so you won't be bothered again.", 'getbowtied' );
							?>
						</span>
					<?php endif; ?>
				</span>
			</p>
		</div>
		<?php
	}

	/**
	 * Shared context for the update notice and its assets.
	 *
	 * @return array{slug:string,new_version:string,message_id:string,licensed:bool,expired:bool,auto_update_enabled:bool}|null
	 */
	private function get_notice_context(): ?array {
		$setup = GBT_Dashboard_Setup::init();

		if ( ! $setup->supports_license() || ! class_exists( 'GBT_License_Manager' ) ) {
			return null;
		}

		$license_manager = GBT_License_Manager::get_instance();
		$licensed        = $license_manager->is_active();
		$expired         = $license_manager->is_expired();

		$slug    = $setup->get_theme_slug();
		$updates = get_site_transient( 'update_themes' );

		if ( ! $updates || empty( $updates->response[ $slug ] ) || ! is_array( $updates->response[ $slug ] ) ) {
			return null;
		}

		$new_version = isset( $updates->response[ $slug ]['new_version'] )
			? (string) $updates->response[ $slug ]['new_version']
			: '';

		if ( $new_version === '' ) {
			return null;
		}

		$message_id = 'theme_update_' . $slug . '_' . $new_version;

		if ( function_exists( 'gbt_notification_handler' ) && gbt_notification_handler()->is_dismissed( $message_id ) ) {
			return null;
		}

		$auto_update_status = $setup->get_theme_auto_update_status();

		return array(
			'slug'                  => $slug,
			'new_version'           => $new_version,
			'message_id'            => $message_id,
			'licensed'              => $licensed,
			'expired'               => $expired,
			'auto_update_enabled'   => ! empty( $auto_update_status['is_enabled'] ),
		);
	}

	/**
	 * Build blocked:// update payload from GitHub JSON for unlicensed inject.
	 *
	 * @return array{theme:string,new_version:string,url:string,package:string}|null
	 */
	private function get_blocked_update_from_json() {
		$setup = GBT_Dashboard_Setup::init();

		if ( ! $setup->supports_license() ) {
			return null;
		}

		if ( ! class_exists( 'GBT_License_Manager' ) ) {
			return null;
		}

		if ( GBT_License_Manager::get_instance()->is_active() ) {
			return null;
		}

		$current = $setup->get_theme_version();
		$info    = $setup->get_remote_theme_update_info();
		$remote  = isset( $info['version'] ) ? (string) $info['version'] : '';

		if ( $remote === '' || ! version_compare( $remote, $current, '>' ) ) {
			return null;
		}

		$slug = $setup->get_theme_slug();

		return array(
			'theme'       => $slug,
			'new_version' => $remote,
			'url'         => ! empty( $info['details_url'] )
				? (string) $info['details_url']
				: $setup->get_theme_url_changelog(),
			'package'     => self::BLOCKED_URL_PREFIX . $slug,
		);
	}
}

GBT_Theme_Update_Notice::init();
