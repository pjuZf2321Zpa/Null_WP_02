<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Freemius license gates + admin UX (notice, menu badge).
 */
class GBT_License_Manager {

	private static $instance = null;

	/**
	 * Outcome of the early License page POST handling (admin_init), consumed by the
	 * page renderer for error display / Themeforest email overlay.
	 *
	 * @var array{posted:string,error:string,error_detail:string,portal_url:string,show_tf_email_overlay:bool}|null
	 */
	private static $license_post_result = null;

	/** @var object|false|null Cached Freemius instance; false when unavailable. */
	private $fs_cache = null;

	private bool $fs_resolved = false;

	/** True while activate() is running for a Themeforest conversion. */
	private $activation_is_migration = false;

	const NOTICE_ID         = 'gbt-license-missing';
	const LEGACY_OPTION_KEY = 'getbowtied_theme_license_key';
	/** Site has activated a Freemius license at least once (migration or key). */
	const FS_SEEN_OPTION    = 'gbt_freemius_license_seen';
	/** Unix timestamp of last license info sync (SDK / local). */
	const LAST_CHECKED_OPTION = 'gbt_license_last_checked';
	/** Customer Portal (manage activations / deactivate other sites). */
	const CUSTOMER_PORTAL_URL = 'https://getbowtied.com/customer-portal/';
	const PURCHASE_COMPLETED_ACTION = 'gbt_purchase_completed';

	private function __construct() {}

	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Boot admin notice + menu badge.
	 */
	public static function init(): void {
		static $booted = false;
		if ( $booted ) {
			return;
		}
		$booted   = true;
		$instance = self::get_instance();
		add_action( 'admin_init', array( $instance, 'handle_license_page_post' ), 5 );
		add_action( 'admin_init', array( $instance, 'register_admin_hooks' ) );
		add_action( 'wp_ajax_' . self::PURCHASE_COMPLETED_ACTION, array( $instance, 'ajax_purchase_completed' ) );
		add_action( 'gbt_fs_loaded', array( $instance, 'register_freemius_hooks' ) );
		// Dashboard loads after gbt_fs_loaded — register immediately if FS is already up.
		if ( did_action( 'gbt_fs_loaded' ) ) {
			$instance->register_freemius_hooks();
		}
	}

	public function register_admin_hooks(): void {
		add_action( 'admin_notices', array( $this, 'render_admin_notice' ) );
		add_action( 'admin_head', array( $this, 'print_menu_badge_styles' ) );
		add_filter( 'parent_file', array( $this, 'add_menu_badge' ) );

		if ( $this->is_active() || $this->has_license() ) {
			$this->mark_freemius_license_seen();
		}
	}

	/**
	 * Refresh license page after Freemius license changes.
	 * Uses only documented Freemius actions (no private SDK calls).
	 */
	public function register_freemius_hooks(): void {
		$fs = $this->fs();
		if ( ! $fs || ! is_object( $fs ) || ! method_exists( $fs, 'add_action' ) ) {
			return;
		}

		$fs->add_action( 'after_license_activation', array( $this, 'on_license_activated' ) );
		$fs->add_action( 'after_license_deactivation', array( $this, 'on_license_deactivated' ) );
		$fs->add_action( 'after_account_plan_sync', array( $this, 'on_account_plan_synced' ) );
		$fs->add_action( 'after_license_change', array( $this, 'on_license_changed' ), 10, 2 );

		if ( method_exists( $fs, 'add_filter' ) ) {
			$fs->add_filter( 'checkout/purchaseCompleted', array( $this, 'filter_purchase_completed_js' ) );
		}
	}

	/**
	 * Official checkout/purchaseCompleted JS. Returns a promise so Freemius waits,
	 * then redirects to the License page.
	 *
	 * @see https://freemius.com/help/documentation/wordpress-sdk/customization/filters-actions-hooks/#checkoutpurchasedcompleted
	 */
	public function filter_purchase_completed_js(): string {
		$ajax     = wp_json_encode( admin_url( 'admin-ajax.php' ) );
		$nonce    = wp_json_encode( wp_create_nonce( self::PURCHASE_COMPLETED_ACTION ) );
		$redirect = wp_json_encode( self::license_page_url_after_purchase() );
		$action   = wp_json_encode( self::PURCHASE_COMPLETED_ACTION );

		return <<<JS
function (data) {
    return fetch({$ajax}, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        },
        credentials: 'same-origin',
        body: 'action=' + encodeURIComponent({$action}) + '&nonce=' + encodeURIComponent({$nonce}) + '&data=' + encodeURIComponent(JSON.stringify(data || {}))
    }).then(function (res) {
        return res.json();
    }).then(function (json) {
        var url = (json && json.success && json.data && json.data.redirect)
            ? json.data.redirect
            : {$redirect};
        window.top.location.href = url;
    });
}
JS;
	}

	/**
	 * Sync after overlay checkout, then tell the JS callback where to go.
	 */
	public function ajax_purchase_completed(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
		}

		check_ajax_referer( self::PURCHASE_COMPLETED_ACTION, 'nonce' );

		$this->mark_freemius_license_seen();
		$this->sync_license();
		set_transient( 'gbt_license_purchased_' . get_current_user_id(), 1, MINUTE_IN_SECONDS );

		wp_send_json_success(
			array(
				'redirect' => self::license_page_url_after_purchase(),
			)
		);
	}

	public function on_license_activated(): void {
		$this->mark_freemius_license_seen();
		$this->after_license_sync( true );
	}

	/**
	 * Plan change (upgrade/switch) is not always an "activation". Freemius still
	 * returns to Account; send those buyers to License too.
	 *
	 * @param string $status Freemius plan-change type.
	 */
	public function on_license_changed( $status, $plan = null ): void {
		$send = array( 'upgraded', 'activated', 'changed', 'extended' );
		if ( ! in_array( (string) $status, $send, true ) ) {
			return;
		}

		$this->after_license_sync( false );
	}

	/**
	 * One-shot flag so the License page can celebrate after a successful activation.
	 * When set during Themeforest conversion, uses the migration flash instead.
	 */
	public function flag_activation_celebration(): void {
		$prefix = $this->activation_is_migration ? 'gbt_license_migrated_' : 'gbt_license_celebrate_';
		set_transient( $prefix . get_current_user_id(), 1, MINUTE_IN_SECONDS );
	}

	/**
	 * Activate a Freemius license key via public opt_in().
	 *
	 * @param bool $from_migration True only for a fresh Themeforest → license conversion.
	 * @return true|string|array{message:string,detail?:string,portal_url?:string} True on success, error string, or structured utilization error.
	 */
	public function activate( string $license_key, bool $from_migration = false ) {
		$license_key = trim( $license_key );
		if ( $license_key === '' ) {
			return 'Please enter your license key.';
		}

		$fs = $this->fs();
		if ( ! $fs || ! method_exists( $fs, 'opt_in' ) ) {
			return 'License activation is not available right now. Please try again or contact support.';
		}

		$this->activation_is_migration = $from_migration;

		try {
			// Public API: email/first/last false → license owner; redirect false → stay in our UI.
			$result = $fs->opt_in(
				false,
				false,
				false,
				$license_key,
				false,
				false,
				false,
				null,
				array(),
				false
			);
		} catch ( \Throwable $e ) {
			$this->activation_is_migration = false;
			return 'Could not activate this license key. Please try again or contact support.';
		}

		if ( is_object( $result ) && isset( $result->error ) ) {
			$error   = $result->error;
			$code    = ( is_object( $error ) && ! empty( $error->code ) ) ? (string) $error->code : '';
			$message = '';
			if ( is_object( $error ) && ! empty( $error->message ) ) {
				$message = (string) $error->message;
			} elseif ( is_string( $error ) && $error !== '' ) {
				$message = $error;
			} else {
				$message = 'Could not activate this license key. Please check the key and try again.';
			}

			// Already linked on Freemius for this install — sync local state instead of failing.
			if ( 'license_activated' === $code || false !== stripos( $message, 'already activated' ) ) {
				$this->sync_license();
				if ( $this->is_active() ) {
					$this->mark_freemius_license_seen();
					$this->flag_activation_celebration();
					$this->activation_is_migration = false;
					return true;
				}
			}

			$this->activation_is_migration = false;

			// Quota full / already used on another production domain.
			if ( $this->is_license_utilization_error( $code, $message ) ) {
				return array(
					'message'    => 'This license is already activated on another production site (or has reached its activation limit). Deactivate it there, or manage activations in the Customer Portal.',
					'detail'     => $message,
					'portal_url' => self::CUSTOMER_PORTAL_URL,
				);
			}

			return $message;
		}

		if ( false === $result ) {
			$this->activation_is_migration = false;
			return 'Could not activate this license key. Please check the key and try again.';
		}

		$this->sync_license();
		$this->mark_freemius_license_seen();
		$this->flag_activation_celebration();
		$this->activation_is_migration = false;

		return true;
	}

	private function is_license_admin_page(): bool {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return 'getbowtied-license' === $page;
	}

	/**
	 * Sync license state and optionally reload the license page.
	 */
	private function after_license_sync( bool $celebrate ): void {
		if ( $celebrate ) {
			$this->flag_activation_celebration();
		}

		$this->sync_license();

		if ( ! $this->is_license_admin_page() ) {
			$this->reload_license_page();
		}
	}

	/**
	 * @return array{posted:string,error:string,error_detail:string,portal_url:string,show_tf_email_overlay:bool}
	 */
	private static function license_post_outcome( string $posted = '' ): array {
		return array(
			'posted'                => $posted,
			'error'                 => '',
			'error_detail'          => '',
			'portal_url'            => '',
			'show_tf_email_overlay' => false,
		);
	}

	/**
	 * @param array{posted:string,error:string,error_detail:string,portal_url:string,show_tf_email_overlay:bool} $outcome
	 * @return array{posted:string,error:string,error_detail:string,portal_url:string,show_tf_email_overlay:bool}
	 */
	private function apply_wp_error_to_outcome( array $outcome, $error ): array {
		if ( ! is_wp_error( $error ) ) {
			return $outcome;
		}

		$outcome['error'] = $error->get_error_message();
		$data             = $error->get_error_data();
		if ( is_array( $data ) ) {
			$outcome['error_detail'] = isset( $data['detail'] ) ? (string) $data['detail'] : '';
			$outcome['portal_url']   = isset( $data['portal_url'] ) ? (string) $data['portal_url'] : '';
		}

		return $outcome;
	}

	/**
	 * @return array{posted:string,error:string,error_detail:string,portal_url:string,show_tf_email_overlay:bool}|null
	 */
	public static function get_license_post_result(): ?array {
		return self::$license_post_result;
	}

	/**
	 * Handle License page form POSTs on admin_init — before any admin output — so
	 * reload_license_page() can still send its redirect header. (The page content
	 * callback runs after the admin header, where headers_sent() blocks redirects.)
	 * Non-redirect outcomes (errors, TF email overlay) are stashed for the renderer.
	 */
	public function handle_license_page_post(): void {
		if ( wp_doing_ajax() || ! $this->is_license_admin_page() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if (
			! isset( $_POST['gbt_activate_freemius_license'] )
			|| $this->is_active()
			|| $this->has_license()
			|| ! check_admin_referer( 'gbt_activate_freemius_license' )
		) {
			return;
		}

		$posted = isset( $_POST['freemius_license_key'] )
			? trim( (string) wp_unslash( $_POST['freemius_license_key'] ) )
			: '';

		$outcome = self::license_post_outcome( $posted );

		if ( $posted === '' ) {
			$outcome['error'] = 'Please enter your license key.';
		} elseif ( self::is_themeforest_purchase_code( $posted ) ) {
			$outcome = $this->handle_themeforest_post( $posted, $outcome );
		} else {
			$result = $this->activate( $posted );

			if ( true === $result ) {
				$this->reload_license_page();
			} elseif ( is_array( $result ) ) {
				$outcome['error']        = isset( $result['message'] ) ? (string) $result['message'] : '';
				$outcome['error_detail'] = isset( $result['detail'] ) ? (string) $result['detail'] : '';
				$outcome['portal_url']   = isset( $result['portal_url'] ) ? (string) $result['portal_url'] : '';
			} elseif ( is_string( $result ) && $result !== '' ) {
				$outcome['error'] = $result;
			}
		}

		self::$license_post_result = $outcome;
	}

	/**
	 * @param array{posted:string,error:string,error_detail:string,portal_url:string,show_tf_email_overlay:bool} $outcome
	 * @return array{posted:string,error:string,error_detail:string,portal_url:string,show_tf_email_overlay:bool}
	 */
	private function handle_themeforest_post( string $posted, array $outcome ): array {
		if ( ! class_exists( 'GBT_License_Converter' ) ) {
			$outcome['error'] = 'Purchase code conversion is not available right now. Please try again or contact support.';
			return $outcome;
		}

		$lookup = GBT_License_Converter::get_instance()->activate_if_migrated( $posted );

		if ( true === $lookup ) {
			$this->reload_license_page();
		}

		if ( is_wp_error( $lookup ) && 'not_migrated' === $lookup->get_error_code() ) {
			if ( $this->set_legacy_purchase_code( $posted ) ) {
				$outcome['show_tf_email_overlay'] = true;
			} else {
				$outcome['error'] = 'Please enter a valid Themeforest purchase code.';
			}
			return $outcome;
		}

		return $this->apply_wp_error_to_outcome( $outcome, $lookup );
	}

	public function on_license_deactivated(): void {
		$this->sync_license();

		// Freemius also fires this hook on API failure — only leave Account after a real unlink.
		if ( ! $this->has_license() ) {
			$this->reload_license_page();
		}
	}

	/**
	 * After Account → Sync License (official fs_action), return to our License page.
	 * Guarded so background/cron syncs do not redirect.
	 */
	public function on_account_plan_synced(): void {
		$this->mark_license_info_checked();

		if ( ! is_admin() || wp_doing_ajax() || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) ) {
			return;
		}

		if ( empty( $_REQUEST['gbt_return_license'] ) ) {
			return;
		}

		$fs = $this->fs();
		if ( ! $fs || ! method_exists( $fs, 'get_unique_affix' ) ) {
			return;
		}

		$action = isset( $_REQUEST['fs_action'] )
			? sanitize_text_field( wp_unslash( $_REQUEST['fs_action'] ) )
			: '';

		if ( $action !== $fs->get_unique_affix() . '_sync_license' ) {
			return;
		}

		set_transient( 'gbt_license_synced_' . get_current_user_id(), 1, MINUTE_IN_SECONDS );
		$this->reload_license_page();
	}

	/**
	 * Soft refresh of local install/license cache via public Freemius APIs only.
	 * UI Sync uses the official Account fs_action; this is for post-activate cleanup.
	 */
	public function sync_license(): void {
		$fs = $this->fs();
		if ( ! $fs || ! $fs->is_registered() ) {
			return;
		}

		// Public sync entry Freemius uses for its own cron (invokes full license sync).
		if ( method_exists( $fs, '_sync_cron' ) ) {
			$fs->_sync_cron();
		}

		if ( method_exists( $fs, 'sync_install' ) ) {
			$fs->sync_install( array(), true );
		}

		$this->mark_license_info_checked();
	}

	/**
	 * Stamp when license data was last refreshed locally.
	 */
	public function mark_license_info_checked(): void {
		update_option( self::LAST_CHECKED_OPTION, time(), false );
	}

	/**
	 * Best-known time the Freemius SDK last refreshed license infos.
	 * Prefers SDK sync cron timestamp, then license.updated, then local stamp.
	 */
	public function get_license_last_checked_ts(): int {
		$candidates = array();

		$fs = $this->fs();
		if ( $fs && method_exists( $fs, 'last_sync_cron' ) ) {
			$sync_ts = $fs->last_sync_cron();
			if ( is_numeric( $sync_ts ) && (int) $sync_ts > 0 ) {
				$candidates[] = (int) $sync_ts;
			}
		}

		$license = ( $fs && method_exists( $fs, '_get_license' ) ) ? $fs->_get_license() : null;
		if ( is_object( $license ) && ! empty( $license->updated ) ) {
			$updated_ts = strtotime( (string) $license->updated );
			if ( false !== $updated_ts && $updated_ts > 0 ) {
				$candidates[] = (int) $updated_ts;
			}
		}

		$stored = (int) get_option( self::LAST_CHECKED_OPTION, 0 );
		if ( $stored > 0 ) {
			$candidates[] = $stored;
		}

		return ! empty( $candidates ) ? max( $candidates ) : 0;
	}

	/**
	 * Full reload so WP/Freemius admin menus rebuild for the new license state.
	 *
	 * @param array<string,string> $query Extra query args.
	 */
	public function reload_license_page( array $query = array() ): void {
		if ( ! is_admin() || wp_doing_ajax() || headers_sent() ) {
			return;
		}

		$url = admin_url( 'admin.php?page=getbowtied-license' );
		if ( ! empty( $query ) ) {
			$url = add_query_arg( $query, $url );
		}

		wp_safe_redirect( $url );
		exit;
	}

	public static function license_page_url(): string {
		return admin_url( 'admin.php?page=getbowtied-license' );
	}

	public static function license_page_url_after_purchase(): string {
		return add_query_arg( 'purchase', 'success', self::license_page_url() );
	}

	public static function pricing_page_url(): string {
		return admin_url( 'admin.php?page=getbowtied-pricing' );
	}

	/**
	 * Active Freemius license unlocks updates and premium UX.
	 */
	public function is_active(): bool {
		// When GBT_NOW is set, derive active from license expiration vs dashboard clock.
		if ( function_exists( 'gbt_now_is_overridden' ) && gbt_now_is_overridden() && $this->has_license() ) {
			if ( $this->is_lifetime() ) {
				return true;
			}
			$license = $this->get_license_object();
			if ( $license && ! empty( $license->expiration ) ) {
				$exp = strtotime( (string) $license->expiration );
				if ( false !== $exp ) {
					return $exp > gbt_now();
				}
			}
		}

		$fs = $this->fs();
		return $fs && $fs->is_registered() && $fs->has_active_valid_license();
	}

	/**
	 * Site has a Freemius license attached (active or expired).
	 * Distinguishes "expired" from "never activated / deactivated".
	 */
	public function has_license(): bool {
		$fs = $this->fs();
		if ( ! $fs || ! $fs->is_registered() || ! method_exists( $fs, 'get_site' ) ) {
			return false;
		}

		$site = $fs->get_site();
		return is_object( $site ) && ! empty( $site->license_id );
	}

	/**
	 * License is present but no longer valid (expired / not entitled to updates).
	 */
	public function is_expired(): bool {
		return $this->has_license() && ! $this->is_active();
	}

	/**
	 * @return object|null Freemius license object
	 */
	private function get_license_object() {
		$fs = $this->fs();
		if ( ! $fs || ! method_exists( $fs, '_get_license' ) ) {
			return null;
		}
		$license = $fs->_get_license();
		return is_object( $license ) ? $license : null;
	}

	public function is_lifetime(): bool {
		$license = $this->get_license_object();
		return $license && method_exists( $license, 'is_lifetime' ) && $license->is_lifetime();
	}

	/**
	 * True once the user purchased via Freemius subscription or lifetime.
	 * Migration licenses also have pricing_id — they are dated, not lifetime, and have no subscription.
	 */
	public function has_freemius_paid_plan(): bool {
		if ( ! $this->has_license() ) {
			return false;
		}

		return ! $this->never_had_subscription() || $this->is_lifetime();
	}

	/**
	 * True when this license is a Freemius migration (any origin).
	 *
	 * Prefer a non-zero Freemius source (1+ = migrated; 7 = ThemeForest).
	 * Install Sync sometimes omits source (or sends 0) even when the dashboard
	 * marks the license Migrated — fall back to how the migrator mints keys:
	 * dated expiry and no Freemius subscription.
	 */
	public function is_themeforest_migrated_license(): bool {
		$license = $this->get_license_object();
		if ( ! $license || empty( $license->id ) ) {
			return false;
		}

		if ( isset( $license->source ) && 0 !== (int) $license->source ) {
			return true;
		}

		return $this->has_dated_expiration() && $this->never_had_subscription();
	}

	/**
	 * True when this license never had a Freemius subscription (historically).
	 * FS_Plugin_License does not keep subscription_id — subscriptions live in
	 * SDK storage and are loaded with _get_subscription( $license_id ).
	 * Cancelled storefront purchases still have that record. Themeforest
	 * migrations are minted with expires_at and no subscription.
	 */
	public function never_had_subscription(): bool {
		$license = $this->get_license_object();
		if ( ! $license || empty( $license->id ) ) {
			return false;
		}

		$fs = $this->fs();
		if ( ! $fs || ! method_exists( $fs, '_get_subscription' ) ) {
			return true;
		}

		$sub = $fs->_get_subscription( $license->id );

		return ! ( is_object( $sub ) && ! empty( $sub->id ) );
	}

	/**
	 * True when the license has a real expiration timestamp (not lifetime).
	 */
	public function has_dated_expiration(): bool {
		if ( ! $this->has_license() || $this->is_lifetime() ) {
			return false;
		}
		$license = $this->get_license_object();
		if ( ! $license || empty( $license->expiration ) ) {
			return false;
		}
		return false !== strtotime( (string) $license->expiration );
	}

	/**
	 * True once a Freemius license was activated on this site (even if later deactivated).
	 * Hides Themeforest migration UX until a purchase code is pasted again to reopen convert.
	 */
	public function has_seen_freemius_license(): bool {
		return (bool) get_option( self::FS_SEEN_OPTION, false );
	}

	public function mark_freemius_license_seen(): void {
		if ( ! get_option( self::FS_SEEN_OPTION, false ) ) {
			update_option( self::FS_SEEN_OPTION, 1, false );
		}
	}

	/**
	 * Themeforest purchase codes are UUIDs (Envato format).
	 */
	public static function is_themeforest_purchase_code( string $code ): bool {
		$code = trim( $code );
		return (bool) preg_match(
			'/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i',
			$code
		);
	}

	/**
	 * Stored Themeforest purchase code (migration helper only).
	 * Empty while Freemius-seen is set — cleared again when set_legacy_purchase_code() reopens convert.
	 */
	public function get_legacy_purchase_code(): string {
		if ( $this->has_seen_freemius_license() ) {
			return '';
		}

		$key = get_option( self::LEGACY_OPTION_KEY, '' );
		return is_string( $key ) ? trim( $key ) : '';
	}

	/**
	 * Persist a Themeforest purchase code and reopen the migration UI
	 * (clears Freemius-seen so convert can show again).
	 */
	public function set_legacy_purchase_code( string $code ): bool {
		$code = trim( $code );
		if ( ! self::is_themeforest_purchase_code( $code ) ) {
			return false;
		}
		update_option( self::LEGACY_OPTION_KEY, $code, false );
		delete_option( self::FS_SEEN_OPTION );
		return true;
	}

	/**
	 * @return object|false Freemius instance
	 */
	public function fs() {
		if ( $this->fs_resolved ) {
			return false === $this->fs_cache ? false : $this->fs_cache;
		}

		$this->fs_resolved = true;

		if ( ! function_exists( 'gbt_fs' ) ) {
			$this->fs_cache = false;
			return false;
		}

		$fs = gbt_fs();
		$this->fs_cache = ( $fs && is_object( $fs ) ) ? $fs : false;

		return $this->fs_cache;
	}

	/**
	 * Freemius returns license_utilized (and a localhost/staging tip) when production seats are full.
	 */
	private function is_license_utilization_error( string $code, string $message ): bool {
		if ( 'license_utilized' === $code ) {
			return true;
		}

		$lower = strtolower( $message );
		if ( false !== strpos( $lower, 'quota' ) && false !== strpos( $lower, 'reached' ) ) {
			return true;
		}

		// Default Freemius copy when a production domain hits a full single-site license.
		return false !== strpos( $lower, 'localhost' )
			&& ( false !== strpos( $lower, 'staging' ) || false !== strpos( $lower, 'development' ) );
	}

	/**
	 * Display fields for the license status panel.
	 *
	 * @return array{plan:string,key:string,key_full:string,license_id:string,buyer:string,user_id:string,purchase_date:string,expires:string,subscription_active:bool,account_url:string,pricing_url:string,deactivate_url:string,change_plan_url:string,sync_url:string,sync_action:string}
	 */
	public function get_display_data(): array {
		$account_url = admin_url( 'admin.php?page=getbowtied-dashboard-account' );
		$data        = array(
			'plan'                 => 'License',
			'key'                  => '',
			'key_full'             => '',
			'license_id'           => '—',
			'buyer'                => '—',
			'user_id'              => '—',
			'purchase_date'        => '',
			'expires'              => '—',
			'subscription_active'  => false,
			'account_url'          => $account_url,
			'pricing_url'          => '',
			'deactivate_url'       => $account_url,
			'change_plan_url'      => '',
			'sync_url'             => $account_url,
			'sync_action'          => '',
		);

		$fs = $this->fs();
		if ( ! $fs ) {
			return $data;
		}

		if ( method_exists( $fs, 'get_account_url' ) ) {
			$account_url = $fs->get_account_url();
			$data['account_url']    = $account_url;
			$data['deactivate_url'] = $account_url;
			$data['sync_url']       = $account_url;
		}
		if ( method_exists( $fs, 'get_unique_affix' ) ) {
			$data['sync_action'] = $fs->get_unique_affix() . '_sync_license';
		}
		if ( method_exists( $fs, 'pricing_url' ) ) {
			$data['pricing_url'] = (string) $fs->pricing_url();
		}
		if ( method_exists( $fs, 'get_upgrade_url' ) ) {
			$data['change_plan_url'] = (string) $fs->get_upgrade_url();
		} elseif ( $data['pricing_url'] !== '' ) {
			$data['change_plan_url'] = $data['pricing_url'];
		}
		if ( method_exists( $fs, 'get_plan_title' ) ) {
			$plan = (string) $fs->get_plan_title();
			if ( $plan !== '' ) {
				$data['plan'] = $plan;
			}
		}

		$license = method_exists( $fs, '_get_license' ) ? $fs->_get_license() : null;
		if ( is_object( $license ) ) {
			if ( isset( $license->id ) && $license->id !== '' && $license->id !== null ) {
				$data['license_id'] = (string) $license->id;
			}
			if ( ! empty( $license->secret_key ) ) {
				$key = (string) $license->secret_key;
				$data['key_full'] = $key;
				$data['key']      = strlen( $key ) > 8
					? substr( $key, 0, 4 ) . '-****-****-****-' . substr( $key, -4 )
					: '••••••••';
			}
			if ( ! empty( $license->created ) ) {
				$data['purchase_date'] = $this->format_license_date( $license->created );
			}
			if ( method_exists( $license, 'is_lifetime' ) && $license->is_lifetime() ) {
				$data['expires'] = 'Does not expire';
			} elseif ( ! empty( $license->expiration ) ) {
				$data['expires'] = $this->format_license_date( $license->expiration );
			}
			$data['subscription_active'] = $this->is_active();
		}

		if ( $data['license_id'] === '—' && method_exists( $fs, 'get_site' ) ) {
			$site = $fs->get_site();
			if ( is_object( $site ) && ! empty( $site->license_id ) ) {
				$data['license_id'] = (string) $site->license_id;
			}
		}

		$user = method_exists( $fs, 'get_user' ) ? $fs->get_user() : null;
		if ( is_object( $user ) ) {
			$name = trim( (string) ( $user->first ?? '' ) . ' ' . (string) ( $user->last ?? '' ) );
			$data['buyer'] = $name !== ''
				? $name
				: ( ! empty( $user->email ) ? (string) $user->email : '—' );
			if ( isset( $user->id ) && $user->id !== '' && $user->id !== null ) {
				$data['user_id'] = (string) $user->id;
			}
		}

		return $data;
	}

	/**
	 * @param mixed $value Freemius date string or timestamp.
	 */
	private function format_license_date( $value ): string {
		$ts = strtotime( (string) $value );
		return $ts ? date_i18n( get_option( 'date_format' ), $ts ) : (string) $value;
	}

	/**
	 * Paid Freemius plans/pricing for the License and Pricing pages.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function get_available_plans(): array {
		$fs = $this->fs();
		return $fs ? gbt_plans_get_available( $fs ) : array();
	}

	/**
	 * @param array<string,mixed> $card Card from get_available_plans().
	 */
	public function is_plan_card_owned( array $card ): bool {
		$fs = $this->fs();
		return $fs && gbt_plans_is_card_owned( $fs, $card, $this->is_active() );
	}

	/**
	 * @return array<int,array{promise:string,items:array<int,array{title:string,description:string,new:bool}>}>
	 */
	public function get_pricing_feature_groups(): array {
		return function_exists( 'gbt_pricing_feature_groups' ) ? gbt_pricing_feature_groups() : array();
	}

	/**
	 * @return array<int,array{title:string,description:string,new?:bool}>
	 */
	public function get_premium_features(): array {
		return function_exists( 'gbt_pricing_premium_features' ) ? gbt_pricing_premium_features() : array();
	}

	public function render_admin_notice(): void {
		$legacy = function_exists( 'gbt_legacy_plan_notice_copy' ) ? gbt_legacy_plan_notice_copy() : null;
		$is_legacy_notice = is_array( $legacy );

		if ( ( $this->is_active() && ! $is_legacy_notice ) || $this->is_dashboard_page() ) {
			return;
		}

		$setup      = GBT_Dashboard_Setup::init();
		$expired    = $this->is_expired();
		$url        = admin_url( 'admin.php?page=getbowtied-license' );
		$theme_slug = $setup->get_theme_slug();

		// Only expired / legacy notices are dismissible (7 days). Missing license always shows.
		$dismissible = $expired || $is_legacy_notice;
		if ( $dismissible ) {
			$message_id = ( $is_legacy_notice ? 'license_legacy_no_plan_' : 'license_expired_' ) . $theme_slug;
			if ( function_exists( 'gbt_notification_handler' ) && gbt_notification_handler()->is_dismissed( $message_id ) ) {
				return;
			}
		}

		$show_tf_migration = ! $expired && ! $this->has_seen_freemius_license() && $this->get_legacy_purchase_code() !== '';
		$notice_class      = $is_legacy_notice && ( $legacy['variant'] ?? '' ) === 'yellow'
			? 'notice notice-warning'
			: 'notice notice-error';
		if ( $dismissible ) {
			$notice_class .= ' is-dismissible gbt-dashboard-notification';
		}
		?>
		<div
			id="<?php echo esc_attr( self::NOTICE_ID ); ?>"
			class="<?php echo esc_attr( $notice_class ); ?>"
			<?php if ( $dismissible ) : ?>
				data-message-id="<?php echo esc_attr( $message_id ); ?>"
				data-theme-slug="<?php echo esc_attr( $theme_slug ); ?>"
			<?php endif; ?>
		>
			<p style="display:flex;align-items:center;">
				<span class="dashicons dashicons-warning" style="color:<?php echo $is_legacy_notice && ( $legacy['variant'] ?? '' ) === 'yellow' ? '#dba617' : '#d63638'; ?>;margin-right:8px;"></span>
				<span><?php
				if ( $is_legacy_notice ) {
					echo '<strong>' . esc_html( $legacy['compact_lead'] ?? $legacy['compact'] ) . '</strong>';
					if ( ! empty( $legacy['compact_rest'] ) ) {
						echo esc_html( $legacy['compact_rest'] );
					}
					echo ' <a href="' . esc_url( $legacy['cta_url'] ) . '"><strong>' . esc_html( $legacy['compact_cta'] ?? $legacy['cta'] ) . '</strong></a>';
				} elseif ( $expired ) {
					echo esc_html( sprintf( 'Your %s theme license has expired.', $setup->get_theme_name() ) );
					echo ' Renew to continue getting updates and support. ';
					echo '<a href="' . esc_url( $url ) . '"><strong>Manage license</strong></a>';
				} else {
					if ( $show_tf_migration && function_exists( 'gbt_tf_convert_deadline_copy' ) ) {
						$tf_copy = gbt_tf_convert_deadline_copy( (string) $setup->get_theme_name() );
						echo esc_html( $tf_copy['side_body'] );
						echo ' <a href="' . esc_url( $url ) . '"><strong>Convert now</strong></a>';
					} elseif ( $show_tf_migration ) {
						echo esc_html( $setup->get_theme_name() ) . ' now uses our new platform. ';
						echo 'Convert your Themeforest purchase code into a license key to keep updates and support.';
						echo ' <a href="' . esc_url( $url ) . '"><strong>Convert now</strong></a>';
					} else {
						echo 'A license key is needed for ' . esc_html( $setup->get_theme_name() ) . ' theme.';
						echo ' <a href="' . esc_url( $url ) . '"><strong>Activate now</strong></a>';
					}
				}
				?></span>
			</p>
		</div>
		<?php
	}

	public function add_menu_badge( $parent_file ) {
		if ( $this->is_active() ) {
			return $parent_file;
		}

		global $menu, $submenu;
		$badge = ' <span class="update-plugins count-1 gbt-license-badge"><span class="plugin-count">!</span></span>';

		if ( ! empty( $menu ) ) {
			foreach ( $menu as $key => $item ) {
				if ( isset( $item[2] ) && $item[2] === 'getbowtied-dashboard' ) {
					$menu[ $key ][0] .= $badge;
					break;
				}
			}
		}

		if ( isset( $submenu['getbowtied-dashboard'] ) ) {
			foreach ( $submenu['getbowtied-dashboard'] as $key => $item ) {
				if ( isset( $item[2] ) && $item[2] === 'getbowtied-license' ) {
					$submenu['getbowtied-dashboard'][ $key ][0] .= $badge;
				}
			}
		}

		return $parent_file;
	}

	/**
	 * Force license menu badges to WP error red (overrides admin color scheme).
	 */
	public function print_menu_badge_styles(): void {
		if ( $this->is_active() ) {
			return;
		}
		?>
		<style id="gbt-license-badge-styles">
			#adminmenu .gbt-license-badge,
			#adminmenu .gbt-license-badge .plugin-count,
			#adminmenu .current .gbt-license-badge,
			#adminmenu .current .gbt-license-badge .plugin-count,
			#adminmenu .wp-has-current-submenu .gbt-license-badge,
			#adminmenu .wp-has-current-submenu .gbt-license-badge .plugin-count,
			#adminmenu a.current .gbt-license-badge,
			#adminmenu a.current .gbt-license-badge .plugin-count,
			#adminmenu li a:focus .gbt-license-badge,
			#adminmenu li a:hover .gbt-license-badge,
			#adminmenu li.opensub a.menu-top .gbt-license-badge {
				background: #d63638 !important;
				background-color: #d63638 !important;
				color: #fff !important;
			}
		</style>
		<?php
	}

	private function is_dashboard_page(): bool {
		if ( empty( $_GET['page'] ) ) {
			return false;
		}
		$pages = GBT_Dashboard_Setup::init()->get_dashboard_page_slugs();
		return in_array( $_GET['page'], $pages, true );
	}
}

GBT_License_Manager::init();
