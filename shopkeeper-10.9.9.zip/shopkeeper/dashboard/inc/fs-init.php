<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// gbt_fs() is defined in functions.php (required by Freemius deployment checks).

/**
 * Skip Freemius license/opt-in screens; we use getbowtied-license instead.
 *
 * Always persist the skip (do not bail on in-memory anonymous_mode simulation),
 * and clear require_license_activation so premium themes stay out of activation mode.
 */
function gbt_fs_skip_freemius_onboarding( $fs ): void {
	if ( ! $fs || ! is_object( $fs ) ) {
		return;
	}

	if ( method_exists( $fs, 'is_registered' ) && $fs->is_registered() ) {
		return;
	}

	if ( method_exists( $fs, 'get_storage' ) ) {
		$fs->get_storage()->require_license_activation = false;
	}

	if ( method_exists( $fs, 'skip_connection' ) ) {
		$fs->skip_connection( is_multisite() && is_network_admin() );
	}
}

add_action( 'gbt_fs_loaded', function () {
	$fs = gbt_fs();

	if ( ! $fs || ! is_object( $fs ) || ! method_exists( $fs, 'add_filter' ) ) {
		return;
	}

	// Skip immediately — activation redirect exits before admin_menu.
	gbt_fs_skip_freemius_onboarding( $fs );

	// Freemius may re-set require_license_activation on after_switch_theme.
	add_action( 'after_switch_theme', static function () use ( $fs ) {
		gbt_fs_skip_freemius_onboarding( $fs );
	}, 20 );

	// Safety net before Freemius builds / overrides admin menus.
	add_action( 'admin_menu', static function () use ( $fs ) {
		gbt_fs_skip_freemius_onboarding( $fs );
	}, 0 );

	// Early fallback on Freemius activation redirects ("Activate Free Version" URL flag).
	$fs->add_filter(
		'connect_url',
		static function ( $url ) {
			return add_query_arg( 'require_license', 'false', $url );
		}
	);

	// Show annual totals (e.g. $79.99 / year) instead of monthly equivalents ($6.67 / mo).
	$fs->add_filter( 'pricing/show_annual_in_monthly', '__return_false' );

	// Freemius defaults some checkout links to lifetime; prefer annual unless a plan is explicitly chosen.
	$fs->add_filter( 'checkout_url', 'gbt_fs_filter_checkout_url' );

	gbt_fs_suppress_premium_activated_notice( $fs );
} );

/**
 * ThemeForest legacy coupon when credit is claimable (same rules as pricing page).
 */
function gbt_fs_checkout_tf_coupon_code(): string {
	if ( ! class_exists( 'GBT_License_Converter' ) ) {
		return '';
	}

	$converter = GBT_License_Converter::get_instance();
	if ( $converter->get_themeforest_credit_value() <= 0 ) {
		return '';
	}

	return $converter->get_themeforest_coupon_code();
}

/**
 * Freemius uses billing_cycle=lifetime when a license has no subscription (e.g. ThemeForest
 * migrations) and for some generic checkout links. Default those to annual instead.
 * Appends the ThemeForest coupon when credit applies (annual only) and is still available.
 * Pricing-page checkouts include plan_id/pricing_id and are left to gbt_pricing_apply_coupon_to_plans().
 *
 * @param string $url Checkout URL from Freemius.
 */
function gbt_fs_filter_checkout_url( string $url ): string {
	$lifetime = defined( 'WP_FS__PERIOD_LIFETIME' ) ? WP_FS__PERIOD_LIFETIME : 'lifetime';
	$annual   = defined( 'WP_FS__PERIOD_ANNUALLY' ) ? WP_FS__PERIOD_ANNUALLY : 'annual';

	$query = array();
	parse_str( (string) wp_parse_url( $url, PHP_URL_QUERY ), $query );

	if ( empty( $query['checkout'] ) ) {
		return $url;
	}

	$explicit_plan = ! empty( $query['plan_id'] ) || ! empty( $query['pricing_id'] );

	if ( ! $explicit_plan && ( $query['billing_cycle'] ?? '' ) === $lifetime ) {
		$url                    = add_query_arg( 'billing_cycle', $annual, remove_query_arg( 'billing_cycle', $url ) );
		$query['billing_cycle'] = $annual;
	}

	if ( $explicit_plan || ! empty( $query['coupon'] ) ) {
		return $url;
	}

	$coupon = gbt_fs_checkout_tf_coupon_code();
	if ( $coupon === '' ) {
		return $url;
	}

	$cycle = (string) ( $query['billing_cycle'] ?? $annual );
	if ( ! function_exists( 'gbt_pricing_credit_applies' ) || ! gbt_pricing_credit_applies( $cycle ) ) {
		return $url;
	}

	return add_query_arg( 'coupon', $coupon, $url );
}

/**
 * Hide only Freemius sticky "W00t! Premium theme version was successfully activated."
 * Other Freemius admin notices are left untouched.
 *
 * @param object $fs Freemius instance.
 */
function gbt_fs_suppress_premium_activated_notice( $fs ): void {
	if ( ! $fs || ! is_object( $fs ) || ! method_exists( $fs, 'add_filter' ) ) {
		return;
	}

	$notice_id = 'premium_activated';

	// Block render even if Freemius re-adds the sticky after a theme update.
	$fs->add_filter(
		'show_admin_notice',
		static function ( $show, $msg ) use ( $notice_id ) {
			if ( is_array( $msg ) && isset( $msg['id'] ) && $notice_id === $msg['id'] ) {
				return false;
			}
			return $show;
		},
		10,
		2
	);

	// Drop persisted sticky from storage (does not affect other notice IDs).
	if ( method_exists( $fs, 'remove_sticky' ) ) {
		$fs->remove_sticky( $notice_id );
	}

	// Freemius adds this sticky on after_premium_version_activation — remove immediately.
	if ( method_exists( $fs, 'add_action' ) ) {
		$fs->add_action(
			'after_premium_version_activation',
			static function () use ( $fs, $notice_id ) {
				if ( method_exists( $fs, 'remove_sticky' ) ) {
					$fs->remove_sticky( $notice_id );
				}
			}
		);
	}
}

/**
 * Lowest-risk way to use our Plans page: leave Freemius pricing/checkout alone,
 * and only redirect browse visits (no checkout=) to getbowtied-pricing.
 */
add_action( 'admin_init', function () {
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	if ( 'getbowtied-dashboard-pricing' === $page && empty( $_GET['checkout'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		wp_safe_redirect( admin_url( 'admin.php?page=getbowtied-pricing' ) );
		exit;
	}
} );
