<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gbt_tf_sales_option_key' ) ) {
	function gbt_tf_sales_option_key(): string {
		return 'gbt_themeforest_sales';
	}
}

if ( ! function_exists( 'gbt_tf_is_sale_row' ) ) {
	/**
	 * @param mixed $row
	 */
	function gbt_tf_is_sale_row( $row ): bool {
		return is_array( $row )
			&& ( isset( $row['sold_at'] ) || isset( $row['supported_until'] ) || isset( $row['purchase_code'] ) || isset( $row['buyer'] ) );
	}
}

if ( ! function_exists( 'gbt_tf_sanitize_sale' ) ) {
	/**
	 * @param array<string,mixed> $raw
	 * @return array<string,mixed>
	 */
	function gbt_tf_sanitize_sale( array $raw, string $purchase_code ): array {
		$nullable_text = static function ( $value ): ?string {
			if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
				return null;
			}
			$text = sanitize_text_field( (string) $value );
			return $text === '' ? null : $text;
		};

		return array(
			'purchase_code'   => $purchase_code,
			'buyer'           => isset( $raw['buyer'] ) ? sanitize_text_field( (string) $raw['buyer'] ) : '',
			'license'         => isset( $raw['license'] ) ? sanitize_text_field( (string) $raw['license'] ) : '',
			'purchase_count'  => isset( $raw['purchase_count'] ) && is_numeric( $raw['purchase_count'] ) ? (int) $raw['purchase_count'] : 0,
			'amount'          => $nullable_text( $raw['amount'] ?? null ),
			'support_amount'  => $nullable_text( $raw['support_amount'] ?? null ),
			'sold_at'         => $nullable_text( $raw['sold_at'] ?? null ),
			'supported_until' => $nullable_text( $raw['supported_until'] ?? null ),
			'item_id'         => isset( $raw['item_id'] ) ? sanitize_text_field( (string) $raw['item_id'] ) : '',
			'item_name'       => isset( $raw['item_name'] ) ? sanitize_text_field( (string) $raw['item_name'] ) : '',
			'stored_at'       => gmdate( 'c' ),
		);
	}
}

if ( ! function_exists( 'gbt_tf_store_sale' ) ) {
	/**
	 * @param array<string,mixed> $body Migration API response.
	 */
	function gbt_tf_store_sale( string $purchase_code, array $body ): void {
		if ( empty( $body['themeforest'] ) || ! is_array( $body['themeforest'] ) ) {
			return;
		}

		$code = strtolower( trim( $purchase_code ) );
		if ( $code === '' ) {
			return;
		}

		update_option(
			gbt_tf_sales_option_key(),
			gbt_tf_sanitize_sale( $body['themeforest'], $code ),
			false
		);
	}
}

if ( ! function_exists( 'gbt_tf_get_sale' ) ) {
	/**
	 * Stored Envato sale (single latest record), or empty when none.
	 *
	 * @return array<string,mixed>
	 */
	function gbt_tf_get_sale( string $purchase_code = '' ): array {
		$stored = get_option( gbt_tf_sales_option_key(), array() );
		if ( ! is_array( $stored ) || $stored === array() ) {
			return array();
		}

		if ( gbt_tf_is_sale_row( $stored ) ) {
			return gbt_tf_sale_matches_code( $stored, $purchase_code ) ? $stored : array();
		}

		$best    = array();
		$best_ts = 0;
		foreach ( $stored as $sale ) {
			if ( ! gbt_tf_is_sale_row( $sale ) ) {
				continue;
			}
			$raw = ! empty( $sale['stored_at'] ) ? (string) $sale['stored_at'] : ( ! empty( $sale['sold_at'] ) ? (string) $sale['sold_at'] : '' );
			$ts  = $raw !== '' ? strtotime( $raw ) : false;
			$ts  = false !== $ts ? $ts : 0;
			if ( $best === array() || $ts >= $best_ts ) {
				$best    = $sale;
				$best_ts = $ts;
			}
		}

		if ( $best !== array() ) {
			update_option( gbt_tf_sales_option_key(), $best, false );
		}

		return gbt_tf_sale_matches_code( $best, $purchase_code ) ? $best : array();
	}
}

if ( ! function_exists( 'gbt_tf_sale_matches_code' ) ) {
	/**
	 * @param array<string,mixed> $sale
	 */
	function gbt_tf_sale_matches_code( array $sale, string $purchase_code ): bool {
		$code = strtolower( trim( $purchase_code ) );
		if ( $code === '' ) {
			return true;
		}
		return ! empty( $sale['purchase_code'] ) && strtolower( (string) $sale['purchase_code'] ) === $code;
	}
}

if ( ! function_exists( 'gbt_tf_format_date' ) ) {
	function gbt_tf_format_date( string $raw ): string {
		if ( $raw === '' ) {
			return '';
		}

		$ts = strtotime( $raw );
		return false !== $ts ? date_i18n( get_option( 'date_format' ), $ts ) : sanitize_text_field( $raw );
	}
}

if ( ! function_exists( 'gbt_tf_format_date_short' ) ) {
	/**
	 * Compact timeline date: "Jul 15, 2016".
	 */
	function gbt_tf_format_date_short( int $ts ): string {
		return $ts > 0 ? date_i18n( 'M j, Y', $ts ) : '';
	}
}

if ( ! function_exists( 'gbt_tf_purchase_when_display' ) ) {
	/**
	 * Relative phrase: 'earlier this year', 'last year', or 'back in 2016'.
	 */
	function gbt_tf_purchase_when_display( array $sale ): string {
		if ( empty( $sale['sold_at'] ) ) {
			return '';
		}

		$ts = strtotime( (string) $sale['sold_at'] );
		if ( false === $ts ) {
			return '';
		}

		$year    = (int) gmdate( 'Y', $ts );
		$current = (int) gmdate( 'Y' );
		if ( $year >= $current ) {
			return 'earlier this year';
		}
		if ( $year === $current - 1 ) {
			return 'last year';
		}

		return 'back in ' . $year;
	}
}

if ( ! function_exists( 'gbt_tf_support_is_active' ) ) {
	/**
	 * True when Envato support (supported_until) is still in effect.
	 *
	 * @param array<string,mixed> $sale
	 */
	function gbt_tf_support_is_active( array $sale ): bool {
		$support_raw = ! empty( $sale['supported_until'] ) ? (string) $sale['supported_until'] : '';
		if ( $support_raw === '' ) {
			return false;
		}

		$support_ts = strtotime( $support_raw );
		if ( false === $support_ts || (int) $support_ts <= 0 ) {
			return false;
		}

		return wp_date( 'Y-m-d', (int) $support_ts ) >= wp_date( 'Y-m-d' );
	}
}

if ( ! function_exists( 'gbt_tf_coupon_entry' ) ) {
	/**
	 * Pick config coupon row on/before sold_at (latest matching date tier).
	 *
	 * @param array<string,mixed>            $sale
	 * @param array<int,array<string,mixed>> $coupons
	 * @return array{coupon:string,date:string,value:int|float}|null
	 */
	function gbt_tf_coupon_entry( array $sale, array $coupons ): ?array {
		$normalized = array();
		foreach ( $coupons as $coupon ) {
			if ( ! is_array( $coupon ) ) {
				continue;
			}
			$code = trim( (string) ( $coupon['coupon'] ?? '' ) );
			if ( $code === '' ) {
				continue;
			}
			$date = trim( (string) ( $coupon['date'] ?? '' ) );
			$ts   = $date !== '' ? strtotime( $date . ' UTC' ) : false;
			$normalized[] = array(
				'ts'     => false !== $ts ? $ts : 0,
				'coupon' => $code,
				'date'   => $date,
				'value'  => is_numeric( $coupon['value'] ?? null ) ? 0 + $coupon['value'] : 0,
			);
		}

		if ( empty( $normalized ) ) {
			return null;
		}

		usort(
			$normalized,
			static function ( array $a, array $b ): int {
				return $a['ts'] <=> $b['ts'];
			}
		);

		$sold_ts = ! empty( $sale['sold_at'] ) ? strtotime( (string) $sale['sold_at'] ) : false;
		$pick    = $normalized[0];
		if ( false !== $sold_ts ) {
			foreach ( $normalized as $coupon ) {
				if ( $sold_ts >= $coupon['ts'] ) {
					$pick = $coupon;
				}
			}
		}

		return array(
			'coupon' => $pick['coupon'],
			'date'   => $pick['date'],
			'value'  => $pick['value'],
		);
	}
}

if ( ! function_exists( 'gbt_tf_plan_name_for_copy' ) ) {
	function gbt_tf_plan_name_for_copy( string $plan ): string {
		$plan = trim( $plan );
		if ( $plan === '' || strcasecmp( $plan, 'License' ) === 0 ) {
			return 'plan';
		}
		if ( preg_match( '/\bplan\b/i', $plan ) ) {
			return $plan;
		}
		return $plan . ' plan';
	}
}

if ( ! function_exists( 'gbt_tf_notice_allowed_html' ) ) {
	/**
	 * @return array<string, array<string, bool>>
	 */
	function gbt_tf_notice_allowed_html(): array {
		return array(
			'a'    => array(
				'href'  => true,
				'class' => true,
			),
			'br'   => array(),
			'span' => array(
				'class' => true,
			),
		);
	}
}
