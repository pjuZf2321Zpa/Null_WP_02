<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gbt_license_period_attr' ) ) {
	function gbt_license_period_attr( string $freq, bool $toggleable ): string {
		if ( ! $toggleable || ! in_array( $freq, array( 'annual', 'lifetime', 'monthly' ), true ) ) {
			return '';
		}
		return ' data-period="' . esc_attr( $freq ) . '"';
	}
}

if ( ! function_exists( 'gbt_render_dark_card_overlays' ) ) {
	function gbt_render_dark_card_overlays( bool $rounded = false ): void {
		$extra = $rounded ? ' overflow-hidden rounded-3xl' : '';
		?>
		<div class="pointer-events-none absolute inset-0 gbt-dark-card-bg-radial<?php echo esc_attr( $extra ); ?>"></div>
		<div class="pointer-events-none absolute inset-0 gbt-dark-card-bg-texture<?php echo esc_attr( $extra ); ?>"></div>
		<?php
	}
}

if ( ! function_exists( 'gbt_render_pricing_price' ) ) {
	function gbt_render_pricing_price( string $price, string $period_label = '', string $period_class = 'text-gray-500', string $was_price = '' ): void {
		$period_label = trim( $period_label );
		$was_price    = trim( $was_price );

		$render_period = static function () use ( $period_label, $period_class ): void {
			if ( $period_label === '' ) {
				return;
			}
			?>
			<span class="invisible text-sm leading-none" aria-hidden="true">lifetime</span>
			<span class="absolute bottom-0 left-0 z-0 -translate-y-[2px] whitespace-nowrap text-sm font-normal leading-none tracking-normal <?php echo esc_attr( $period_class ); ?>"><?php echo esc_html( $period_label ); ?></span>
			<?php
		};

		$render_was = static function () use ( $was_price, $period_class ): void {
			if ( $was_price === '' ) {
				return;
			}
			?>
			<span class="mb-1.5 text-sm font-normal leading-none tracking-normal line-through opacity-60 <?php echo esc_attr( $period_class ); ?>"><?php echo esc_html( $was_price ); ?></span>
			<?php
		};

		if ( ! preg_match( '/^(.*?)(\d[\d,]*)(?:\.(\d+))?$/u', $price, $m ) ) {
			?>
			<span class="inline-flex flex-col items-start leading-none">
				<?php $render_was(); ?>
				<span class="inline-flex items-end gap-x-3 leading-none">
					<span><?php echo esc_html( $price ); ?></span>
					<?php $render_period(); ?>
				</span>
			</span>
			<?php
			return;
		}

		$prefix = (string) $m[1];
		$whole  = (string) $m[2];
		$cents  = isset( $m[3] ) ? (string) $m[3] : '';
		?>
		<span class="inline-flex flex-col items-start leading-none">
			<?php $render_was(); ?>
			<span class="inline-flex items-start gap-x-3 leading-none">
				<span class="inline-flex items-start gap-x-[0.06em] leading-none">
					<?php if ( $prefix !== '' ) : ?>
						<span class="mt-[calc(0.32em+1px)] text-[0.4em] font-semibold leading-none tracking-tight"><?php echo esc_html( $prefix ); ?></span>
					<?php endif; ?>
					<span class="tabular-nums leading-none"><?php echo esc_html( $whole ); ?></span>
					<?php if ( $cents !== '' || $period_label !== '' ) : ?>
						<span class="relative inline-flex flex-col justify-between self-stretch leading-none">
							<?php if ( $cents !== '' ) : ?>
								<span class="mt-[calc(0.32em+1px)] text-[0.4em] font-semibold leading-none tracking-tight tabular-nums"><?php echo esc_html( $cents ); ?></span>
							<?php else : ?>
								<span aria-hidden="true"></span>
							<?php endif; ?>
							<?php $render_period(); ?>
						</span>
					<?php endif; ?>
				</span>
			</span>
		</span>
		<?php
	}
}

if ( ! function_exists( 'gbt_pricing_business_plan_licenses' ) ) {
	/** Max site licenses on the Business plan (Freemius quota). */
	function gbt_pricing_business_plan_licenses(): int {
		$n = GBT_Dashboard_Setup::init()->get_global_config( 'business_plan_licenses' );
		$n = is_numeric( $n ) ? (int) $n : 0;
		return $n > 0 ? $n : 3;
	}
}

if ( ! function_exists( 'gbt_pricing_plan_meta' ) ) {
	function gbt_pricing_plan_meta( string $title ): string {
		$t = strtolower( $title );

		if ( false !== strpos( $t, 'agency' ) || false !== strpos( $t, 'unlimited' ) ) {
			return 'For agencies and freelancers with client sites';
		}
		if ( false !== strpos( $t, 'business' ) ) {
			return 'For brands running several sites';
		}
		if ( false !== strpos( $t, 'professional' ) ) {
			return 'For a single-site owner';
		}

		return '';
	}
}

if ( ! function_exists( 'gbt_pricing_tf_cover_badge' ) ) {
	function gbt_pricing_tf_cover_badge( string $title, int $count ): string {
		if ( $count < 1 ) {
			return '';
		}

		$biz_max   = gbt_pricing_business_plan_licenses();
		$t         = strtolower( $title );
		$is_agency = ( false !== strpos( $t, 'agency' ) || false !== strpos( $t, 'unlimited' ) );
		$is_biz    = ( ! $is_agency && false !== strpos( $t, 'business' ) );
		$is_pro    = ( ! $is_agency && ! $is_biz && false !== strpos( $t, 'professional' ) );

		if (
			( $is_pro && 1 === $count )
			|| ( $is_biz && $count >= 2 && $count <= $biz_max )
			|| ( $is_agency && $count > $biz_max )
		) {
			return 'Best fit for you';
		}

		return '';
	}
}

if ( ! function_exists( 'gbt_render_pricing_card_badge' ) ) {
	function gbt_render_pricing_card_badge( string $text, bool $featured = false ): void {
		if ( $text === '' ) {
			return;
		}
		$wrap = $featured
			? 'pointer-events-none absolute inset-x-0 top-0 z-30 flex justify-center lg:-top-6'
			: 'pointer-events-none absolute inset-x-0 top-0 z-30 flex justify-center';
		?>
		<div class="<?php echo esc_attr( $wrap ); ?>">
			<span class="gbt-featured-badge pointer-events-none relative z-30 inline-flex -translate-y-1/2 rounded-full bg-[var(--color-gbt-yellow-soft)] px-5 py-1.5 text-sm font-semibold text-gray-900 shadow-md ring-2 ring-[var(--color-gbt-gray-dark)] whitespace-nowrap"><?php echo esc_html( $text ); ?></span>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_pricing_trio_light_shell' ) ) {
	function gbt_pricing_trio_light_shell( int $i ): string {
		$base = 'group/card relative flex h-full flex-col rounded-3xl bg-white/60 p-8 ring-1 ring-gray-900/10 sm:mx-8 sm:p-10 lg:mx-0';

		if ( 0 === $i ) {
			return $base . ' sm:rounded-b-none lg:rounded-tl-3xl lg:rounded-bl-3xl lg:rounded-tr-none lg:rounded-br-none';
		}
		if ( 2 === $i ) {
			return $base . ' sm:rounded-t-none lg:rounded-tr-3xl lg:rounded-br-3xl lg:rounded-tl-none lg:rounded-bl-none';
		}

		return $base . ' sm:rounded-none lg:rounded-none';
	}
}

if ( ! function_exists( 'gbt_pricing_parse_amount' ) ) {
	function gbt_pricing_parse_amount( $price ): ?float {
		return gbt_parse_price_amount( $price );
	}
}

if ( ! function_exists( 'gbt_pricing_lifetime_is_about_two_years' ) ) {
	function gbt_pricing_lifetime_is_about_two_years( float $annual, float $lifetime ): bool {
		if ( $annual < 1 ) {
			return false;
		}
		$ratio = $lifetime / $annual;
		return $ratio >= 1.5 && $ratio <= 2.5;
	}
}

if ( ! function_exists( 'gbt_pricing_lifetime_savings_copy' ) ) {
	function gbt_pricing_lifetime_savings_copy( array $plans ): string {
		foreach ( $plans as $plan ) {
			$periods = isset( $plan['periods'] ) && is_array( $plan['periods'] ) ? $plan['periods'] : array();
			if ( empty( $periods['annual']['price'] ) || empty( $periods['lifetime']['price'] ) ) {
				continue;
			}

			$annual   = gbt_pricing_parse_amount( (string) $periods['annual']['price'] );
			$lifetime = gbt_pricing_parse_amount( (string) $periods['lifetime']['price'] );
			if ( null === $annual || null === $lifetime ) {
				continue;
			}

			if ( gbt_pricing_lifetime_is_about_two_years( $annual, $lifetime ) ) {
				return 'Same as 2 years of Yearly — then it’s lifetime';
			}
		}

		return '';
	}
}

if ( ! function_exists( 'gbt_pricing_currency_symbol' ) ) {
	function gbt_pricing_currency_symbol( string $price, string $fallback = '$' ): string {
		if ( preg_match( '/^([^\d\s]+)/u', $price, $sym ) ) {
			return $sym[1];
		}
		return $fallback;
	}
}

if ( ! function_exists( 'gbt_pricing_format_amount' ) ) {
	function gbt_pricing_format_amount( float $amount, string $sample_price = '$' ): string {
		$symbol = gbt_pricing_currency_symbol( $sample_price );
		return $symbol . number_format( max( 0, $amount ), 2, '.', '' );
	}
}

if ( ! function_exists( 'gbt_pricing_credit_applies' ) ) {
	function gbt_pricing_credit_applies( string $freq ): bool {
		return 'annual' === $freq;
	}
}

if ( ! function_exists( 'gbt_pricing_price_after_credit' ) ) {
	function gbt_pricing_price_after_credit( string $price, int $credit ): ?string {
		if ( $credit <= 0 ) {
			return null;
		}

		$amount = gbt_pricing_parse_amount( $price );
		if ( null === $amount ) {
			return null;
		}

		return gbt_pricing_format_amount( $amount - $credit, $price );
	}
}

if ( ! function_exists( 'gbt_pricing_card_price_parts' ) ) {
	function gbt_pricing_card_price_parts( string $price, string $freq, string $period_label, int $credit ): array {
		if ( ! gbt_pricing_credit_applies( $freq ) ) {
			$credit = 0;
		}

		$after = gbt_pricing_price_after_credit( $price, $credit );
		if ( null === $after ) {
			return array( $price, $period_label, '' );
		}

		if ( 'annual' === $freq ) {
			return array( $after, 'today — renews at ' . $price . '/year', 'Regular price ' . $price . '/year' );
		}

		return array( $after, $period_label, 'Regular price ' . $price );
	}
}

if ( ! function_exists( 'gbt_pricing_plan_period_price' ) ) {
	function gbt_pricing_plan_period_price( array $plan, string $freq = 'annual' ): string {
		$periods = ( ! empty( $plan['periods'] ) && is_array( $plan['periods'] ) ) ? $plan['periods'] : array();
		if ( ! empty( $periods[ $freq ]['price'] ) ) {
			return (string) $periods[ $freq ]['price'];
		}
		if ( $freq === (string) ( $plan['period'] ?? '' ) && ! empty( $plan['price'] ) ) {
			return (string) $plan['price'];
		}
		return ! empty( $plan['price'] ) ? (string) $plan['price'] : '';
	}
}

if ( ! function_exists( 'gbt_pricing_tf_cta_label' ) ) {
	function gbt_pricing_tf_cta_label( string $plan_title, string $freq, string $price, int $credit, string $verb = 'Get' ): string {
		if ( ! gbt_pricing_credit_applies( $freq ) ) {
			$credit = 0;
		}

		$after = gbt_pricing_price_after_credit( $price, $credit );
		$lead  = trim( $plan_title ) !== ''
			? 'Get ' . $plan_title
			: ( in_array( $verb, array( 'Get', 'Choose', 'Upgrade', 'Downgrade', 'Activate' ), true ) ? $verb : 'Get' );
		$pay   = $after ?? $price;

		if ( 'lifetime' === $freq ) {
			if ( $pay === '' ) {
				return $lead;
			}
			if ( null !== $after ) {
				return sprintf( '%s — <span class="text-[#ffe08a]">%s once</span>', esc_html( $lead ), esc_html( $pay ) );
			}
			return sprintf( '%s — %s once', esc_html( $lead ), esc_html( $pay ) );
		}

		if ( null !== $after ) {
			return sprintf( '%s — <span class="text-[#ffe08a]">%s today</span>', esc_html( $lead ), esc_html( $after ) );
		}

		if ( $price !== '' ) {
			$suffix = ( 'monthly' === $freq ) ? '/ month' : '/ year';
			return sprintf( '%s — %s %s', esc_html( $lead ), esc_html( $price ), $suffix );
		}

		return esc_html( $lead );
	}
}

if ( ! function_exists( 'gbt_pricing_cta_label_kses' ) ) {
	function gbt_pricing_cta_label_kses( string $label ): void {
		echo wp_kses( $label, array( 'span' => array( 'class' => true ) ) );
	}
}

if ( ! function_exists( 'gbt_pricing_pill_badge_class' ) ) {
	function gbt_pricing_pill_badge_class( string $variant = 'blue' ): string {
		$base = 'inline-flex items-center rounded-full px-2.5 py-1.5 text-[0.625rem] font-semibold uppercase leading-none';

		if ( 'green' === $variant ) {
			return $base . ' bg-gbt-green text-white';
		}
		if ( 'green-soft' === $variant ) {
			return $base . ' ring-1 ring-inset bg-gbt-green/10 text-gbt-green-darker ring-gbt-green/25';
		}
		if ( 'yellow-solid' === $variant ) {
			$save = str_replace( 'font-semibold', 'font-bold', $base );
			return $save
				. ' ring-1 ring-inset transition-[background-color,color,box-shadow] duration-150'
				. ' bg-gray-900/15 text-gray-900/60 ring-gray-900/25'
				. ' group-has-[:checked]/save:bg-white/20 group-has-[:checked]/save:text-white/80 group-has-[:checked]/save:ring-white/40';
		}
		if ( 'yellow' === $variant ) {
			return $base . ' ring-1 ring-inset bg-[var(--color-gbt-yellow)]/10 text-[#8a6116] ring-[var(--color-gbt-yellow)]/25';
		}
		if ( 'red' === $variant ) {
			return $base . ' ring-1 ring-inset bg-[var(--color-gbt-red)]/10 text-[var(--color-gbt-red)] ring-[var(--color-gbt-red)]/25';
		}

		return $base . ' ring-1 ring-inset bg-[var(--color-gbt-blue)]/10 text-[var(--color-gbt-blue-darker)] ring-[var(--color-gbt-blue)]/25';
	}
}

if ( ! function_exists( 'gbt_pricing_cta_note' ) ) {
	function gbt_pricing_cta_note( bool $toggleable, string $fallback_freq = 'annual' ): void {
		$wrap = 'mx-auto mt-8 flex w-full max-w-4xl flex-wrap items-center justify-center gap-2';
		$pill = gbt_pricing_pill_badge_class( 'blue' ) . ' group/feat relative gap-1 cursor-help';

		$render = static function ( array $items, string $period = '' ) use ( $wrap, $pill ): void {
			?>
			<div class="<?php echo esc_attr( $wrap ); ?>"<?php echo $period !== '' ? ' data-period="' . esc_attr( $period ) . '"' : ''; ?>>
				<?php foreach ( $items as $item ) : ?>
					<span class="<?php echo esc_attr( $pill ); ?>">
						<span class="gbt-feat-label inline-flex items-center">
							<?php echo esc_html( $item['title'] ); ?>
							<span class="gbt-feat-help text-sm leading-none" aria-hidden="true"><?php gbt_icon_e( 'question-mark-circle', 'text-current', 'solid', 16 ); ?></span>
						</span>
						<span role="tooltip" class="gbt-feat-tip pointer-events-none absolute left-0 top-full z-[100001] mt-1.5 w-max max-w-[18rem] rounded-md px-3.5 py-2.5 text-left text-sm leading-normal !font-normal normal-case tracking-normal text-white opacity-0 transition-opacity duration-150 group-hover/feat:opacity-100">
							<?php echo esc_html( $item['description'] ); ?>
						</span>
					</span>
				<?php endforeach; ?>
			</div>
			<?php
		};

		$monthly = array(
			array(
				'title'       => 'Activate instantly',
				'description' => 'This site is licensed the moment you pay — no email hunt, no key to paste.',
			),
			array(
				'title'       => 'Billed monthly',
				'description' => 'You’re billed each month so updates and support don’t lapse.',
			),
			array(
				'title'       => 'Cancel anytime',
				'description' => 'Stop whenever you want. Coverage lasts through the month you already paid for.',
			),
		);
		$annual = array(
			array(
				'title'       => 'Activate instantly',
				'description' => 'This site is licensed the moment you pay — no email hunt, no key to paste.',
			),
			array(
				'title'       => 'Billed yearly',
				'description' => 'You’re billed once a year so updates and support don’t lapse.',
			),
			array(
				'title'       => 'Cancel anytime',
				'description' => 'Stop whenever you want. Coverage lasts through the year you already paid for.',
			),
		);
		$lifetime = array(
			array(
				'title'       => 'Activate instantly',
				'description' => 'This site is licensed the moment you pay — no email hunt, no key to paste.',
			),
			array(
				'title'       => 'Lifetime payment',
				'description' => 'A lifetime license — transfer it to another site whenever you move.',
			),
			array(
				'title'       => 'No renewals',
				'description' => 'A single charge. No monthly or yearly invoice and no subscription to manage.',
			),
		);

		if ( $toggleable ) {
			$render( $monthly, 'monthly' );
			$render( $annual, 'annual' );
			$render( $lifetime, 'lifetime' );
			return;
		}

		if ( 'lifetime' === $fallback_freq ) {
			$render( $lifetime );
		} elseif ( 'monthly' === $fallback_freq ) {
			$render( $monthly );
		} else {
			$render( $annual );
		}
	}
}

if ( ! function_exists( 'gbt_pricing_apply_coupon_to_plans' ) ) {
	function gbt_pricing_apply_coupon_to_plans( array $plans, string $coupon ): array {
		if ( $coupon === '' ) {
			return $plans;
		}

		foreach ( $plans as $i => $plan ) {
			$default_freq = (string) ( $plan['period'] ?? 'annual' );
			if ( ! empty( $plan['checkout_url'] ) && gbt_pricing_credit_applies( $default_freq ) ) {
				$plans[ $i ]['checkout_url'] = add_query_arg( 'coupon', $coupon, (string) $plan['checkout_url'] );
			}
			if ( empty( $plan['periods'] ) || ! is_array( $plan['periods'] ) ) {
				continue;
			}
			foreach ( $plan['periods'] as $freq => $period ) {
				if ( empty( $period['checkout_url'] ) || ! gbt_pricing_credit_applies( (string) $freq ) ) {
					continue;
				}
				$plans[ $i ]['periods'][ $freq ]['checkout_url'] = add_query_arg( 'coupon', $coupon, (string) $period['checkout_url'] );
			}
		}

		return $plans;
	}
}

if ( ! function_exists( 'gbt_render_pricing_license_status' ) ) {
	function gbt_render_pricing_license_status( string $text, string $variant = 'red' ): void {
		$is_red = ( 'red' === $variant );
		$shell  = $is_red
			? 'flex items-start gap-2 rounded-md border border-[var(--color-gbt-red)]/40 bg-[var(--color-gbt-red)]/15 px-4 py-3 text-sm text-[var(--color-gbt-red)]'
			: 'flex items-start gap-2 rounded-md border border-[var(--color-gbt-yellow)]/40 bg-[var(--color-gbt-yellow)]/15 px-4 py-3 text-sm text-[#8a6116]';
		$icon   = $is_red ? 'exclamation-circle' : 'information-circle';
		?>
		<div class="mx-auto flex w-full max-w-4xl justify-center">
			<div class="<?php echo esc_attr( $shell ); ?> max-w-full" role="status">
				<?php gbt_icon_e( $icon, 'mt-0.5 size-5 shrink-0', 'solid', 20 ); ?>
				<span class="min-w-0 text-pretty leading-normal"><?php echo esc_html( $text ); ?></span>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_pricing_normalize_feature' ) ) {
	function gbt_pricing_normalize_feature( $feature ): array {
		if ( is_array( $feature ) ) {
			$title = trim( (string) ( $feature['title'] ?? '' ) );
			$desc  = trim( (string) ( $feature['description'] ?? '' ) );
			$new   = ! empty( $feature['new'] );
		} else {
			$title = trim( (string) $feature );
			$desc  = '';
			$new   = false;
		}

		if ( preg_match( '/^new:\s*(.+)$/i', $title, $m ) ) {
			$new   = true;
			$title = trim( $m[1] );
		}

		return array(
			'title'       => $title,
			'description' => $desc,
			'new'         => $new,
		);
	}
}

if ( ! function_exists( 'gbt_pricing_feature_title_key' ) ) {
	function gbt_pricing_feature_title_key( $feature ): string {
		$item = gbt_pricing_normalize_feature( $feature );
		$key  = strtolower( $item['title'] );
		return $key !== '' ? $key : '';
	}
}

if ( ! function_exists( 'gbt_pricing_order_plan_features' ) ) {
	/**
	 * Reorder Freemius plan features: unique to the plan first, then common to all plans.
	 *
	 * @param array<int,array<string,mixed>> $plans Plan cards from get_available_plans().
	 * @return array<int,array<string,mixed>>
	 */
	function gbt_pricing_order_plan_features( array $plans ): array {
		$plan_count = count( $plans );
		if ( $plan_count <= 1 ) {
			return $plans;
		}

		$title_counts = array();
		foreach ( $plans as $plan ) {
			$seen = array();
			foreach ( $plan['features'] ?? array() as $feature ) {
				$key = gbt_pricing_feature_title_key( $feature );
				if ( $key === '' || isset( $seen[ $key ] ) ) {
					continue;
				}
				$seen[ $key ] = true;
				$title_counts[ $key ] = ( $title_counts[ $key ] ?? 0 ) + 1;
			}
		}

		foreach ( $plans as $i => $plan ) {
			$unique = array();
			$common = array();
			foreach ( $plan['features'] ?? array() as $feature ) {
				$key = gbt_pricing_feature_title_key( $feature );
				if ( $key !== '' && ( $title_counts[ $key ] ?? 0 ) === $plan_count ) {
					$common[] = $feature;
				} else {
					$unique[] = $feature;
				}
			}
			$plans[ $i ]['features'] = array_merge( $unique, $common );
		}

		return $plans;
	}
}

if ( ! function_exists( 'gbt_pricing_period_coverage_features' ) ) {
	/**
	 * Updates & support lines that follow Freemius plan properties, keyed by billing period.
	 *
	 * @return array<int,array{title:string,description:string}>
	 */
	function gbt_pricing_period_coverage_features( string $freq ): array {
		if ( 'lifetime' === $freq ) {
			return array(
				array(
					'title'       => 'Lifetime updates',
					'description' => '',
				),
				array(
					'title'       => 'Lifetime support',
					'description' => '',
				),
			);
		}

		$is_annual = ( 'annual' === $freq );
		$span      = $is_annual ? '1 year' : '1 month';

		return array(
			array(
				'title'       => 'Updates for ' . $span,
				'description' => '',
			),
			array(
				'title'       => 'Support for ' . $span,
				'description' => '',
			),
			array(
				'title'       => $is_annual ? 'Auto-renews every year' : 'Auto-renews every month',
				'description' => $is_annual
					? 'Renews automatically each year. Cancel anytime — coverage lasts through the year you already paid for.'
					: 'Renews automatically each month. Cancel anytime — coverage lasts through the month you already paid for.',
			),
		);
	}
}

if ( ! function_exists( 'gbt_render_pricing_feature_item' ) ) {
	function gbt_render_pricing_feature_item( $feature, string $li_class = '', string $period = '' ): void {
		$item = gbt_pricing_normalize_feature( $feature );
		if ( $item['title'] === '' ) {
			return;
		}

		$has_tip = $item['description'] !== '';
		$head    = '';
		$tail    = $item['title'];
		if ( $has_tip && preg_match( '/^(.*\s)(\S+)$/us', $item['title'], $parts ) ) {
			$head = rtrim( $parts[1] );
			$tail = $parts[2];
		}

		$li = trim( 'flex max-w-full items-start ' . ( $li_class !== '' ? $li_class : 'gap-x-3' ) );
		$tip_class = 'gbt-feat-tip pointer-events-none absolute left-0 top-full z-[100001] mt-1.5 w-max max-w-[18rem] rounded-md px-3.5 py-2.5 text-left text-sm leading-normal !font-normal normal-case tracking-normal text-white opacity-0 transition-opacity duration-150 group-hover/feat:opacity-100';
		?>
		<li class="<?php echo esc_attr( $li ); ?>"<?php echo gbt_license_period_attr( $period, $period !== '' ); ?>>
			<span class="inline-flex h-6 shrink-0 items-center">
				<?php if ( $item['new'] ) : ?>
					<span class="<?php echo esc_attr( gbt_pricing_pill_badge_class( 'green' ) ); ?>">New</span>
				<?php else : ?>
					<?php gbt_icon_e( 'check', 'size-4 shrink-0 text-gray-500', 'solid', 16 ); ?>
				<?php endif; ?>
			</span>
			<?php if ( $has_tip ) : ?>
				<span class="gbt-feat-label group/feat relative inline-block max-w-full cursor-help">
					<?php if ( $head !== '' ) : ?>
						<?php echo esc_html( $head ); ?>
					<?php endif; ?><span class="gbt-feat-help-unit"><?php echo $head !== '' ? ' ' : ''; ?><?php echo esc_html( $tail ); ?><span class="gbt-feat-help" aria-hidden="true"><?php gbt_icon_e( 'question-mark-circle', 'text-gray-500 group-hover/feat:text-gray-300', 'solid', 16 ); ?></span></span>
					<span role="tooltip" class="<?php echo esc_attr( $tip_class ); ?>"><?php echo esc_html( $item['description'] ); ?></span>
				</span>
			<?php else : ?>
				<span><?php echo esc_html( $item['title'] ); ?></span>
			<?php endif; ?>
		</li>
		<?php
	}
}

if ( ! function_exists( 'gbt_render_pricing_features' ) ) {
	/**
	 * @param array<int,mixed>            $features   Freemius plan features.
	 * @param bool                        $on_dark    Featured (dark) card styling.
	 * @param array<string,array<string,mixed>> $periods Card billing periods.
	 * @param bool                        $toggleable Whether the page period switch is active.
	 */
	function gbt_render_pricing_features( array $features, bool $on_dark, array $periods = array(), bool $toggleable = false ): void {
		$coverage_freqs = array();
		if ( ! empty( $periods ) ) {
			$order = array( 'monthly', 'annual', 'lifetime' );
			if ( $toggleable ) {
				foreach ( $order as $freq ) {
					if ( isset( $periods[ $freq ] ) ) {
						$coverage_freqs[] = $freq;
					}
				}
			} else {
				$first = (string) array_key_first( $periods );
				if ( $first !== '' ) {
					$coverage_freqs[] = $first;
				}
			}
		}

		if ( empty( $features ) && empty( $coverage_freqs ) ) {
			return;
		}

		$list_class = $on_dark
			? 'mt-6 space-y-2.5 text-sm/6 text-white'
			: 'mt-6 space-y-2.5 text-sm/6 text-gray-600';
		?>
		<ul role="list" class="<?php echo esc_attr( $list_class ); ?>">
			<?php foreach ( $features as $feature ) : ?>
				<?php gbt_render_pricing_feature_item( $feature, 'gap-x-2.5' ); ?>
			<?php endforeach; ?>
			<?php foreach ( $coverage_freqs as $freq ) : ?>
				<?php
				$period_attr = $toggleable ? $freq : '';
				foreach ( gbt_pricing_period_coverage_features( $freq ) as $feature ) :
					gbt_render_pricing_feature_item( $feature, 'gap-x-2.5', $period_attr );
				endforeach;
				?>
			<?php endforeach; ?>
		</ul>
		<?php
	}
}

if ( ! function_exists( 'gbt_render_premium_features_tip' ) ) {
	function gbt_render_premium_features_tip( array $features ): void {
		if ( empty( $features ) ) {
			return;
		}
		?>
		<span class="group/prem relative inline-flex items-center gap-1 cursor-help" tabindex="0" id="gbt-prem-features-trigger" data-gbt-tip-trigger role="button" aria-describedby="gbt-prem-features-tip">
			<span class="border-b border-dotted border-gray-500 text-gray-300">new features</span>
			<?php gbt_icon_e( 'question-mark-circle', 'size-4 shrink-0 text-gray-400', 'solid', 16 ); ?>
			<span role="tooltip" id="gbt-prem-features-tip" data-gbt-tip class="gbt-prem-tip pointer-events-none fixed top-0 left-0 z-[100001] w-max max-w-[min(20rem,calc(100vw-1.5rem))] rounded-md px-3.5 py-2.5 text-left text-[11px] leading-normal font-normal text-white transition-opacity duration-150">
				<span class="mb-2 block border-b border-white/10 pb-2 text-[12px] font-semibold leading-snug text-white">Your new features:</span>
				<span class="flex flex-col gap-1.5">
					<?php foreach ( $features as $feature ) : ?>
						<?php
						$item = gbt_pricing_normalize_feature( $feature );
						if ( $item['title'] === '' ) {
							continue;
						}
						?>
						<span class="inline-flex items-start gap-2">
							<span class="inline-flex shrink-0 items-center rounded-full bg-gbt-green px-2 py-0.5 text-[0.625rem] font-semibold uppercase leading-none text-white">New</span>
							<span class="font-normal"><?php echo esc_html( $item['title'] ); ?></span>
						</span>
					<?php endforeach; ?>
				</span>
			</span>
		</span>
		<?php
	}
}

if ( ! function_exists( 'gbt_render_pricing_features_overview' ) ) {
	function gbt_render_pricing_features_overview( array $groups, string $theme_name = '' ): void {
		if ( empty( $groups ) ) {
			return;
		}

		$group_count = count( $groups );
		$use_lg_grid = $group_count >= 3;
		$sub         = 'Same full toolkit on every plan. Scale sites when you need to — never lose features.';
		$headline    = 'Stay licensed and keep your theme ready as WooCommerce changes';
		if ( $theme_name !== '' ) {
			$headline = sprintf( 'Stay licensed and keep %s ready as WooCommerce changes', $theme_name );
		}
		$list_class = $use_lg_grid
			? 'mt-8 divide-y divide-gray-200/90 lg:mt-12 lg:grid lg:grid-cols-3 lg:gap-x-10 lg:gap-y-10 lg:divide-y-0'
			: 'mt-8 divide-y divide-gray-200/90';
		?>
		<div class="gbt-pricing-features mx-auto mt-10 w-full max-w-lg lg:max-w-7xl">
			<div class="rounded-3xl px-8 py-10 ring-1 ring-gray-900/10 sm:px-10">
				<div class="max-w-2xl text-left sm:mx-auto sm:text-center">
					<p class="text-sm font-semibold text-gbt-blue">Don’t wait until updates stop</p>
					<h3 class="mt-2 text-2xl font-semibold tracking-tight text-balance text-gray-900 lg:text-4xl">
						<?php echo esc_html( $headline ); ?>
					</h3>
					<p class="mt-3 text-sm/6 text-pretty text-gray-600 sm:mt-4"><?php echo esc_html( $sub ); ?></p>
				</div>

				<div class="<?php echo esc_attr( $list_class ); ?>">
					<?php foreach ( $groups as $index => $group ) : ?>
						<div class="<?php echo esc_attr( 'py-7 first:pt-0' . ( $use_lg_grid ? ' lg:py-0' : '' ) . ( $use_lg_grid && $index > 0 ? ' lg:border-l lg:border-gray-200 lg:pl-8' : '' ) ); ?>">
							<p class="text-base/6 font-semibold text-pretty text-gray-900"><?php echo esc_html( $group['promise'] ); ?></p>
							<ul role="list" class="mt-4 space-y-2.5 sm:mt-5">
								<?php foreach ( $group['items'] as $feature ) : ?>
									<?php gbt_render_pricing_feature_item( $feature, 'gap-x-2.5 text-sm/6 text-gray-800' ); ?>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_pricing_faq_inline' ) ) {
	function gbt_pricing_faq_inline( string $text ): void {
		$escaped = esc_html( $text );
		$html    = preg_replace( '/\*\*(.+?)\*\*/s', '<strong class="font-semibold text-gray-900">$1</strong>', $escaped );
		$html    = preg_replace( '/\*(.+?)\*/s', '<em class="italic">$1</em>', is_string( $html ) ? $html : $escaped );
		echo wp_kses(
			is_string( $html ) ? $html : $escaped,
			array(
				'strong' => array( 'class' => true ),
				'em'     => array( 'class' => true ),
			)
		);
	}
}

if ( ! function_exists( 'gbt_pricing_faq_example_annual' ) ) {
	function gbt_pricing_faq_example_annual( array $plans ): string {
		$fallback = '';
		foreach ( $plans as $plan ) {
			$price = gbt_pricing_plan_period_price( $plan, 'annual' );
			if ( $price === '' ) {
				continue;
			}
			$t = strtolower( (string) ( $plan['title'] ?? '' ) );
			if ( false !== strpos( $t, 'professional' ) ) {
				return $price;
			}
			if ( $fallback === '' ) {
				$fallback = $price;
			}
		}

		return $fallback;
	}
}

if ( ! function_exists( 'gbt_pricing_faq_items' ) ) {
	function gbt_pricing_faq_items( string $purchase_date, string $annual_price, int $credit, string $theme_name = '' ): array {
		$bought = $purchase_date !== ''
			? 'Your ThemeForest purchase from **' . $purchase_date . '** has been verified and recognized, and migrated to our new **Professional** plan. Expiration matches your original ThemeForest support date — or a 14-day grace period if it had already expired.'
			: 'Your ThemeForest purchase has been verified and recognized, and migrated to our new **Professional** plan. Expiration matches your original ThemeForest support date — or a 14-day grace period if it had already expired.';

		$credit_label = $credit > 0 ? '$' . $credit : '';
		$moving       = $credit_label !== ''
			? 'Your new plan gives you continuous updates and support, license and site management, downloads, future add-ons, and more. **As a courtesy to existing customers, you receive a ' . $credit_label . ' credit toward your first yearly payment.**'
			: 'Your new plan gives you continuous updates and support, license and site management, downloads, future add-ons, and more.';

		$credit_example = '';
		if ( $credit > 0 && $annual_price !== '' ) {
			$pay_today = gbt_pricing_price_after_credit( $annual_price, $credit );
			if ( null !== $pay_today ) {
				$credit_example = sprintf(
					'For example, if your new plan is **%s**, your **%s credit** is applied, so you pay **%s today**.',
					$annual_price,
					$credit_label,
					$pay_today
				);
			}
		}

		$plan_intro = $theme_name !== ''
			? 'Your license and active plan keep ' . $theme_name . ' current and give you continued access to:'
			: 'Your license and active plan keep your theme current and give you continued access to:';

		$plan_benefits = array(
			$theme_name !== ''
				? 'Full feature updates, compatibility releases, and security updates for ' . $theme_name
				: 'Full feature updates, compatibility releases, and security updates',
			'Automatic updates directly from your WordPress dashboard',
			$theme_name !== ''
				? 'Premium support from the team behind ' . $theme_name
				: 'Premium support from the team behind the theme',
			'Current and previous theme versions',
			'New features, future add-ons, and bundles as they’re released',
			'A dedicated portal to manage your license and move it between sites — including remotely on client websites',
			'Plan and renewal management directly from your account',
		);

		$why_now = $theme_name !== ''
			? $theme_name . ' was previously tied to ThemeForest’s exclusive marketplace model. That old business model is no longer sustainable.'
			: 'The theme was previously tied to ThemeForest’s exclusive marketplace model. That old business model is no longer sustainable.';

		$why_team = 'Moving to our own platform gives us more control over licensing, updates, support, downloads, and future features — all built around the theme.';

		$items = array(
			array(
				'q'      => 'Am I paying again for a theme I already bought?',
				'blocks' => array_values(
					array_filter(
						array(
							array( 'p' => '**No. You are not buying the theme again — you are upgrading to a plan on our platform.**' ),
							array( 'p' => $bought ),
							array( 'p' => $moving ),
							$credit_example !== '' ? array( 'p' => $credit_example ) : null,
						),
						'is_array'
					)
				),
			),
			array(
				'q'      => 'What about the lifetime updates promised with my ThemeForest purchase?',
				'blocks' => array(
					array(
						'p' => $theme_name !== ''
							? 'Your ThemeForest license remains valid, but **' . $theme_name . ' ThemeForest version has reached end of life**. No further updates will be published there.'
							: 'Your ThemeForest license remains valid, but the **ThemeForest version has reached end of life**. No further updates will be published there.',
					),
					array(
						'p' => $theme_name !== ''
							? 'Going forward, future features, updates, and support for ' . $theme_name . ' are delivered together exclusively through our platform on the **Professional, Business, and Agency** plans.'
							: 'Going forward, future features, updates, and support are delivered together exclusively through our platform on the **Professional, Business, and Agency** plans.',
					),
				),
			),
			array(
				'q'      => 'What do I get with an active plan?',
				'blocks' => array(
					array( 'p' => $plan_intro ),
					array(
						'ul' => $plan_benefits,
					),
					array( 'p' => 'You can change to a larger plan at any time. Your account, license history, and existing site activations stay with you.' ),
				),
			),
			array(
				'q'      => 'What if I don’t choose a plan?',
				'blocks' => array(
					array( 'p' => 'Your website **continues to work**. Your theme, content, products, settings, and customizations stay as they are, and you can keep using your current installed version.' ),
					array( 'p' => '**What changes is access going forward:** future releases, automatic updates, new premium features, downloads, and support on the new platform require an eligible license and an active plan.' ),
				),
			),
			array(
				'q'      => 'Does choosing a plan change my live website?',
				'blocks' => array(
					array( 'p' => '**Nothing on your website will be modified or removed when you choose a plan.** Choosing a plan only activates your license and gives you access to updates and support.' ),
				),
			),
			array(
				'q'      => 'Why are you making this change now?',
				'blocks' => array(
					array( 'p' => $why_now ),
					array( 'p' => $why_team ),
				),
			),
			array(
				'q'      => 'What payment options are available?',
				'blocks' => array(
					array( 'p' => 'You can choose a **Monthly**, **Yearly**, or **Lifetime** plan.' ),
					array( 'p' => '**Monthly:** Pay month to month and cancel anytime. Your plan remains active until the end of your current billing period.' ),
					array( 'p' => '**Yearly:** Pay once per year and save compared with monthly. You can cancel anytime to prevent the next renewal.' ),
					array( 'p' => '**Lifetime:** Pay once with no recurring payments. You keep the updates, downloads, and support included with your plan.' ),
				),
			),
		);

		$items[] = array(
			'q'      => 'Can I change my plan later?',
			'blocks' => array(
				array( 'p' => '**Yes.** You can choose a different plan anytime as your needs change. Your account, license history, and existing activations stay with you.' ),
			),
		);

		return $items;
	}
}

if ( ! function_exists( 'gbt_render_pricing_faq' ) ) {
	function gbt_render_pricing_faq( array $plans = array(), string $theme_name = '' ): void {
		$converter     = GBT_License_Converter::get_instance();
		$purchase_date = $converter->get_themeforest_purchase_date_display();
		$credit        = $converter->get_themeforest_credit_value();
		$credit_until  = $credit > 0 ? $converter->get_coupon_until_display() : '';
		$annual_price  = gbt_pricing_faq_example_annual( $plans );
		$items         = gbt_pricing_faq_items( $purchase_date, $annual_price, $credit, $theme_name );
		?>
		<div id="gbt-pricing-faq" class="gbt-pricing-faq mx-auto mt-10 w-full max-w-lg lg:max-w-7xl">
			<div class="rounded-3xl px-8 py-10 ring-1 ring-gray-900/10 sm:px-10">
				<div class="max-w-2xl text-left sm:mx-auto sm:text-center">
					<p class="text-sm font-semibold text-gbt-blue">Answers for existing customers</p>
					<h3 class="mt-2 text-2xl font-semibold tracking-tight text-balance text-gray-900 lg:text-4xl">
						Frequently Asked Questions
					</h3>
				</div>

				<div class="gbt-pricing-faq__list mx-auto mt-8 max-w-3xl space-y-3 lg:mt-12">
					<?php foreach ( $items as $item ) : ?>
						<details class="group/faq overflow-hidden rounded-xl border border-gray-200/90 bg-white">
							<summary class="gbt-pricing-faq__summary grid cursor-pointer select-none grid-cols-[minmax(0,1fr)_auto] items-center gap-x-3 px-5 py-3.5 text-left sm:px-6 sm:py-4 [&::-webkit-details-marker]:hidden">
								<span class="gbt-pricing-faq__question select-none"><?php echo esc_html( $item['q'] ); ?></span>
								<span class="gbt-faq-chevron inline-flex shrink-0 rounded-full bg-gray-100 p-1 text-gray-500" aria-hidden="true">
									<?php gbt_icon_e( 'arrow-down', 'size-4', 'solid', 20 ); ?>
								</span>
							</summary>
							<div class="gbt-pricing-faq__answer border-t border-gray-200/90 px-5 pb-5 pt-3.5 sm:px-6 sm:pb-6 sm:pt-4">
								<div class="gbt-pricing-faq__content">
								<?php foreach ( $item['blocks'] as $block ) : ?>
									<?php if ( ! empty( $block['ul'] ) && is_array( $block['ul'] ) ) : ?>
										<ul>
											<?php foreach ( $block['ul'] as $li ) : ?>
												<li><?php gbt_pricing_faq_inline( (string) $li ); ?></li>
											<?php endforeach; ?>
										</ul>
									<?php elseif ( isset( $block['p'] ) ) : ?>
										<p><?php gbt_pricing_faq_inline( (string) $block['p'] ); ?></p>
									<?php endif; ?>
								<?php endforeach; ?>
								</div>
							</div>
						</details>
					<?php endforeach; ?>
				</div>

				<div class="gbt-pricing-faq__migrated relative mx-auto mt-10 max-w-3xl overflow-hidden rounded-2xl bg-[var(--color-gbt-gray-dark)] px-6 py-14 text-center shadow-2xl ring-1 ring-[var(--color-gbt-gray-dark)]/20 sm:px-10 sm:py-16">
					<?php gbt_render_dark_card_overlays( true ); ?>
					<div class="relative z-10">
					<span class="mx-auto inline-flex size-12 items-center justify-center rounded-full bg-gbt-green/20" aria-hidden="true">
						<?php gbt_icon_e( 'check-badge', 'size-6 text-gbt-green', 'solid', 24 ); ?>
					</span>
					<p class="mt-4 text-sm font-semibold text-[var(--color-gbt-blue-lighter)]">When you’re ready</p>
					<h4 class="mt-2 text-xl font-semibold tracking-tight text-balance text-white sm:text-2xl">Continue with the plan that fits</h4>
					<p class="mx-auto mt-4 max-w-xl text-sm/6 text-pretty text-gray-400">
						<?php if ( $credit > 0 ) : ?>
							Your ThemeForest purchase is recognized, your license is ready, and your $<?php echo esc_html( (string) $credit ); ?> credit is available.
						<?php else : ?>
							Your ThemeForest purchase is recognized, and your license is ready.
						<?php endif; ?>
						Choose the plan that fits you now — you can change plans later.
					</p>
					<a href="<?php echo esc_url( $credit > 0 ? '#gbt-pricing-credit' : '#pricing-options' ); ?>" class="mt-6 inline-flex w-full max-w-sm flex-col items-center justify-center gap-y-0.5 rounded-md bg-[var(--color-gbt-blue)] px-8 py-3 text-center text-sm font-semibold text-white shadow-xs no-underline transition duration-150 ease-in-out hover:bg-[var(--color-gbt-blue-darker)] sm:w-auto sm:max-w-none sm:flex-row sm:gap-x-1.5 sm:whitespace-nowrap sm:px-8 sm:py-2.5">
						<?php if ( $credit > 0 ) : ?>
							<span>Choose your plan</span>
							<span class="font-semibold text-[#ffe08a]">— $<?php echo esc_html( (string) $credit ); ?> credit applied</span>
						<?php else : ?>
							Choose your plan
						<?php endif; ?>
					</a>
					<?php if ( $credit > 0 && $credit_until !== '' ) : ?>
						<p class="mx-auto mt-4 max-w-xl text-sm/6 text-pretty text-gray-500">Credit valid until <?php echo esc_html( $credit_until ); ?>.</p>
					<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_pricing_prepare_layout' ) ) {
	/**
	 * Resolve featured plan, reorder trio grid, detect period toggle.
	 *
	 * @return array{plans:array,featured_idx:?int,owned_idx:?int,show_period_toggle:bool,available_periods:array<int,string>,plan_count:int}
	 */
	function gbt_pricing_prepare_layout( array $plans, GBT_License_Manager $manager, bool $tf_legacy_active, int $tf_licenses ): array {
		$plan_count          = count( $plans );
		$featured_idx        = null;
		$featured_from_owned = false;
		$owned_idx           = null;

		if ( ! $tf_legacy_active ) {
			foreach ( $plans as $i => $plan_card ) {
				if ( $manager->is_plan_card_owned( $plan_card ) ) {
					$owned_idx = $i;
				}
			}
		}
		if ( null !== $owned_idx ) {
			$last_idx            = $plan_count - 1;
			$featured_idx        = ( $owned_idx < $last_idx ) ? $owned_idx + 1 : $owned_idx;
			$featured_from_owned = true;
		}

		if ( null === $featured_idx && $tf_licenses > 0 ) {
			foreach ( $plans as $i => $plan_card ) {
				if ( gbt_pricing_tf_cover_badge( (string) ( $plan_card['title'] ?? '' ), $tf_licenses ) !== '' ) {
					$featured_idx = $i;
					break;
				}
			}
		}
		if ( null === $featured_idx ) {
			foreach ( $plans as $i => $plan_card ) {
				if ( ! empty( $plan_card['featured'] ) ) {
					$featured_idx = $i;
					break;
				}
			}
		}
		if ( null === $featured_idx && $plan_count >= 3 ) {
			$featured_idx = 1;
		} elseif ( null === $featured_idx && 1 === $plan_count ) {
			$featured_idx = 0;
		}

		if ( ! $featured_from_owned && $tf_licenses < 1 && 3 === $plan_count && null !== $featured_idx && 1 !== $featured_idx ) {
			$featured_plan = $plans[ $featured_idx ];
			unset( $plans[ $featured_idx ] );
			$plans        = array_values( $plans );
			array_splice( $plans, 1, 0, array( $featured_plan ) );
			$featured_idx = 1;
		}

		// Toggle order: cheapest commitment first (Monthly), then Annual, then Lifetime.
		$period_flags = array(
			'monthly'  => false,
			'annual'   => false,
			'lifetime' => false,
		);
		foreach ( $plans as $plan_card ) {
			$card_periods = ( ! empty( $plan_card['periods'] ) && is_array( $plan_card['periods'] ) ) ? $plan_card['periods'] : array();
			foreach ( array_keys( $period_flags ) as $freq ) {
				if ( ! empty( $card_periods[ $freq ] ) ) {
					$period_flags[ $freq ] = true;
				}
			}
		}
		$available_periods  = array_keys( array_filter( $period_flags ) );
		$show_period_toggle = count( $available_periods ) >= 2;

		$plans = gbt_pricing_order_plan_features( $plans );

		return array(
			'plans'              => $plans,
			'featured_idx'       => $featured_idx,
			'owned_idx'          => $owned_idx,
			'show_period_toggle' => $show_period_toggle,
			'available_periods'  => $available_periods,
			'plan_count'         => $plan_count,
		);
	}
}

if ( ! function_exists( 'gbt_pricing_license_badge_state' ) ) {
	/**
	 * @return array{show:bool,text:string,variant:string}
	 */
	function gbt_pricing_license_badge_state(
		bool $has_license,
		bool $license_expired,
		bool $tf_legacy_active,
		bool $has_expiry_date,
		bool $has_tf_credit,
		string $plan_label,
		string $expires_label,
		string $tf_credit_lead
	): array {
		$show = $tf_legacy_active && ( $has_expiry_date || $has_tf_credit );

		if ( ! $has_license ) {
			$text    = 'No license yet — pick a plan and unlock updates, support, and more';
			$variant = 'red';
		} elseif ( $tf_legacy_active && $license_expired ) {
			$text    = $tf_credit_lead !== '' ? $tf_credit_lead : sprintf( '%s ended on %s — renew to bring updates & support back', $plan_label, $expires_label );
			$variant = 'red';
		} elseif ( $tf_legacy_active ) {
			$text    = $tf_credit_lead !== '' ? $tf_credit_lead : sprintf( '%s runs until %s — renew to keep everything unlocked', $plan_label, $expires_label );
			$variant = 'yellow';
		} elseif ( $license_expired ) {
			$text    = sprintf( '%s ended on %s — renew to bring updates & support back', $plan_label, $expires_label );
			$variant = 'red';
		} else {
			$text    = sprintf( '%s runs until %s — renew to keep everything unlocked', $plan_label, $expires_label );
			$variant = 'yellow';
		}

		if ( $has_tf_credit ) {
			$variant = 'yellow';
		}

		return array(
			'show'    => $show,
			'text'    => $text,
			'variant' => $variant,
		);
	}
}

if ( ! function_exists( 'gbt_pricing_cta_fallback_freq' ) ) {
	function gbt_pricing_cta_fallback_freq( array $plans, bool $show_period_toggle ): string {
		if ( $show_period_toggle ) {
			return 'annual';
		}

		$has_annual   = false;
		$has_lifetime = false;
		$has_monthly  = false;
		foreach ( $plans as $plan_card ) {
			$probe = ( ! empty( $plan_card['periods'] ) && is_array( $plan_card['periods'] ) ) ? $plan_card['periods'] : array();
			if ( isset( $probe['annual'] ) ) {
				$has_annual = true;
			}
			if ( isset( $probe['lifetime'] ) ) {
				$has_lifetime = true;
			}
			if ( isset( $probe['monthly'] ) ) {
				$has_monthly = true;
			}
		}

		if ( $has_annual ) {
			return 'annual';
		}
		if ( $has_monthly ) {
			return 'monthly';
		}
		if ( $has_lifetime ) {
			return 'lifetime';
		}

		return 'monthly';
	}
}

if ( ! function_exists( 'gbt_pricing_plan_periods' ) ) {
	function gbt_pricing_plan_periods( array $plan_card ): array {
		if ( ! empty( $plan_card['periods'] ) && is_array( $plan_card['periods'] ) ) {
			return $plan_card['periods'];
		}

		return array(
			(string) ( $plan_card['period'] ?? '' ) => array(
				'price'        => $plan_card['price'] ?? '',
				'period_label' => $plan_card['period_label'] ?? '',
				'checkout_url' => $plan_card['checkout_url'] ?? '',
			),
		);
	}
}

if ( ! function_exists( 'gbt_pricing_plan_has_checkout' ) ) {
	function gbt_pricing_plan_has_checkout( array $periods ): bool {
		foreach ( $periods as $p ) {
			if ( ! empty( $p['checkout_url'] ) ) {
				return true;
			}
		}
		return false;
	}
}

if ( ! function_exists( 'gbt_render_pricing_card' ) ) {
	/**
	 * Single plan card — featured (dark) or light shell.
	 *
	 * @param array<string,mixed> $args Card context.
	 */
	function gbt_render_pricing_card( array $args ): void {
		$is_featured     = ! empty( $args['is_featured'] );
		$plan_card       = $args['plan_card'];
		$periods         = $args['periods'];
		$toggleable      = ! empty( $args['toggleable'] );
		$plan_meta       = (string) ( $args['plan_meta'] ?? '' );
		$plan_title      = (string) ( $args['plan_title'] ?? '' );
		$tf_credit_value = (int) ( $args['tf_credit_value'] ?? 0 );
		$is_owned        = ! empty( $args['is_owned'] );
		$has_checkout    = ! empty( $args['has_checkout'] );
		$card_cta_verb   = (string) ( $args['card_cta_verb'] ?? 'Choose' );
		$card_badge      = (string) ( $args['card_badge'] ?? '' );
		$features        = is_array( $args['features'] ?? null ) ? $args['features'] : array();

		$title_class  = $is_featured ? 'text-base/7 font-semibold text-[var(--color-gbt-blue-lighter)]' : 'text-base/7 font-semibold text-gbt-blue';
		$meta_class   = $is_featured ? 'mt-1 text-sm/6 text-gray-400' : 'mt-1 text-sm/6 text-gray-500';
		$price_class  = $is_featured
			? 'text-5xl font-semibold leading-none tracking-tight text-white'
			: 'text-5xl font-semibold leading-none tracking-tight text-gray-900';
		$period_class = $is_featured ? 'text-gray-400' : 'text-gray-500';
		$cta_class    = $is_featured
			? 'mt-6 block rounded-md bg-[var(--color-gbt-blue)] px-3.5 py-2.5 text-center text-sm font-semibold text-white shadow-xs hover:bg-[var(--color-gbt-blue-darker)] transition duration-150 ease-in-out no-underline'
			: 'mt-6 block rounded-md bg-gbt-blue px-3.5 py-2.5 text-center text-sm font-semibold text-white shadow-sm hover:bg-gbt-blue/90 transition duration-150 ease-in-out no-underline';
		$owned_class  = $is_featured
			? 'mt-6 inline-flex w-full items-center justify-center gap-2 rounded-md bg-white/15 px-3.5 py-2.5 text-center text-sm font-semibold text-white ring-1 ring-inset ring-white/25 cursor-not-allowed border-0'
			: 'mt-6 inline-flex w-full items-center justify-center gap-2 rounded-md bg-gray-200 px-3.5 py-2.5 text-center text-sm font-semibold text-gray-800 ring-1 ring-inset ring-gray-300 cursor-not-allowed border-0';

		$render_body = static function () use (
			$plan_card,
			$periods,
			$toggleable,
			$title_class,
			$meta_class,
			$plan_meta,
			$price_class,
			$period_class,
			$tf_credit_value,
			$is_owned,
			$owned_class,
			$has_checkout,
			$plan_title,
			$card_cta_verb,
			$cta_class,
			$features,
			$is_featured
		): void {
			?>
			<h3 class="<?php echo esc_attr( $title_class ); ?>"><?php echo esc_html( $plan_card['title'] ); ?></h3>
			<?php if ( $plan_meta !== '' ) : ?>
				<p class="<?php echo esc_attr( $meta_class ); ?>"><?php echo esc_html( $plan_meta ); ?></p>
			<?php endif; ?>
			<div class="mt-1">
				<?php foreach ( $periods as $freq => $p ) : ?>
					<span class="block <?php echo esc_attr( $price_class ); ?>"<?php echo gbt_license_period_attr( (string) $freq, $toggleable ); ?>>
						<?php
						[ $display_price, $display_period, $was_price ] = gbt_pricing_card_price_parts(
							(string) $p['price'],
							(string) $freq,
							(string) $p['period_label'],
							$tf_credit_value
						);
						gbt_render_pricing_price( $display_price, $display_period, $period_class, $was_price );
						?>
					</span>
				<?php endforeach; ?>
			</div>

			<?php if ( $is_owned ) : ?>
				<button type="button" disabled class="<?php echo esc_attr( $owned_class ); ?>">
					<?php gbt_icon_e( 'check-badge', 'size-5 shrink-0', 'solid' ); ?>
					You currently own this plan.
				</button>
			<?php elseif ( $has_checkout ) : ?>
				<?php foreach ( $periods as $freq => $p ) : ?>
					<?php if ( empty( $p['checkout_url'] ) ) { continue; } ?>
					<?php
					$cta_label = gbt_pricing_tf_cta_label(
						$plan_title,
						(string) $freq,
						(string) $p['price'],
						$tf_credit_value,
						$card_cta_verb
					);
					?>
					<a href="<?php echo esc_url( $p['checkout_url'] ); ?>" class="<?php echo esc_attr( $cta_class ); ?>"<?php echo gbt_license_period_attr( (string) $freq, $toggleable ); ?>><?php gbt_pricing_cta_label_kses( $cta_label ); ?></a>
				<?php endforeach; ?>
			<?php endif; ?>

			<?php gbt_render_pricing_features( $features, $is_featured, $periods, $toggleable ); ?>
			<?php
		};

		if ( $is_featured ) {
			$use_trio = ! empty( $args['use_trio_layout'] );
			?>
			<div class="group/card group/card--featured relative z-10 h-full <?php echo $use_trio ? '' : 'lg:col-span-1'; ?>">
				<?php gbt_render_pricing_card_badge( $card_badge, true ); ?>
				<div class="relative z-10 flex h-full flex-col overflow-visible rounded-3xl bg-[var(--color-gbt-gray-dark)] px-8 py-8 shadow-2xl ring-1 ring-[var(--color-gbt-gray-dark)]/10 sm:px-10 sm:py-10 lg:absolute lg:inset-x-0 lg:-top-6 lg:-bottom-6 lg:h-auto lg:py-16">
					<?php gbt_render_dark_card_overlays( true ); ?>
					<div class="relative z-10 flex flex-1 flex-col">
						<?php $render_body(); ?>
					</div>
				</div>
			</div>
			<?php
			return;
		}

		$shell = (string) ( $args['shell'] ?? 'group/card relative flex h-full flex-col rounded-3xl bg-white/60 p-8 ring-1 ring-gray-900/10 sm:p-10' );
		?>
		<div class="<?php echo esc_attr( $shell ); ?>">
			<?php gbt_render_pricing_card_badge( $card_badge ); ?>
			<?php $render_body(); ?>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_pricing_feature_groups' ) ) {
	/**
	 * @return array<int,array{promise:string,items:array<int,array{title:string,description:string,new:bool}>}>
	 */
	function gbt_pricing_feature_groups(): array {
		static $groups = null;
		if ( null !== $groups ) {
			return $groups;
		}

		$path = GBT_Dashboard_Setup::init()->get_base_paths()['path'] . '/dashboard/inc/pricing-features.json';
		if ( ! is_readable( $path ) ) {
			$groups = array();
			return $groups;
		}

		$data   = json_decode( (string) file_get_contents( $path ), true );
		$groups = is_array( $data ) ? $data : array();

		return $groups;
	}
}

if ( ! function_exists( 'gbt_pricing_premium_features' ) ) {
	/**
	 * Migration tooltip items — `new` flagged entries, or all if none marked.
	 *
	 * @return array<int,array{title:string,description:string,new?:bool}>
	 */
	function gbt_pricing_premium_features(): array {
		$all = array();
		$new = array();

		foreach ( gbt_pricing_feature_groups() as $group ) {
			if ( empty( $group['items'] ) || ! is_array( $group['items'] ) ) {
				continue;
			}
			foreach ( $group['items'] as $item ) {
				if ( empty( $item['title'] ) ) {
					continue;
				}
				$all[] = $item;
				if ( ! empty( $item['new'] ) ) {
					$new[] = $item;
				}
			}
		}

		return ! empty( $new ) ? $new : $all;
	}
}
