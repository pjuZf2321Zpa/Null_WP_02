<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gbt_icon' ) ) {
	/**
	 * Render a Heroicon SVG from synced icons/ or node_modules.
	 *
	 * @param string $name  Icon name (e.g. 'key').
	 * @param string $class CSS classes.
	 * @param string $style 'outline' or 'solid'.
	 * @param int    $size  16, 20, or 24 (outline always uses 24).
	 */
	function gbt_icon( string $name, string $class = 'size-5', string $style = 'outline', int $size = 24 ): string {
		$name  = preg_replace( '/[^a-z0-9-]/', '', strtolower( $name ) );
		$style = ( 'solid' === $style ) ? 'solid' : 'outline';
		$size  = in_array( $size, array( 16, 20, 24 ), true ) ? $size : 24;

		if ( '' === $name ) {
			return '';
		}
		if ( 'outline' === $style ) {
			$size = 24;
		}

		$rel  = "{$size}/{$style}/{$name}.svg";
		$base = dirname( __DIR__, 2 );
		$path = "{$base}/icons/{$rel}";

		if ( ! is_readable( $path ) ) {
			$path = "{$base}/node_modules/heroicons/{$rel}";
		}
		if ( ! is_readable( $path ) ) {
			return '';
		}

		$svg = file_get_contents( $path );
		if ( ! $svg ) {
			return '';
		}

		$class = trim( $class ) ?: 'size-5';
		$px    = preg_match( '/\b(?:size|h)-(\d+)\b/', $class, $m ) ? (int) $m[1] * 4 : $size;

		$svg = preg_replace( '/\sclass="[^"]*"/', '', $svg, 1 );
		$svg = preg_replace(
			'/<svg\b/',
			sprintf( '<svg class="%s" width="%d" height="%d"', esc_attr( $class ), $px, $px ),
			$svg,
			1
		);

		return is_string( $svg ) ? $svg : '';
	}
}

if ( ! function_exists( 'gbt_icon_e' ) ) {
	/**
	 * Echo a Heroicon SVG.
	 */
	function gbt_icon_e( string $name, string $class = 'size-5', string $style = 'outline', int $size = 24 ): void {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted local SVG assets.
		echo gbt_icon( $name, $class, $style, $size );
	}
}
