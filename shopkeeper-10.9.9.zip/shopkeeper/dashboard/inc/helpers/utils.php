<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dashboard wall-clock override (`Y-m-d H:i:s`). Empty string = real PHP `time()`.
 * Used by TF offer, timeline, cutoff copy, and license active/expired checks.
 */
if ( ! defined( 'GBT_NOW' ) ) {
	define( 'GBT_NOW', '' );
}

if ( ! function_exists( 'gbt_now_is_overridden' ) ) {
	function gbt_now_is_overridden(): bool {
		return defined( 'GBT_NOW' ) && GBT_NOW !== '';
	}
}

if ( ! function_exists( 'gbt_now' ) ) {
	/** Canonical dashboard “now” — use instead of `time()` / `current_time()` for date logic. */
	function gbt_now(): int {
		if ( gbt_now_is_overridden() ) {
			$ts = strtotime( GBT_NOW );
			if ( false !== $ts ) {
				return $ts;
			}
		}
		return time();
	}
}

if ( ! function_exists( 'gbt_now_ymd' ) ) {
	function gbt_now_ymd(): string {
		return wp_date( 'Y-m-d', gbt_now() );
	}
}

if ( ! function_exists( 'gbt_parse_price_amount' ) ) {
	/**
	 * Parse a price string or number into a positive float.
	 *
	 * @param mixed $price Raw price from Freemius or formatted display string.
	 */
	function gbt_parse_price_amount( $price ): ?float {
		if ( null === $price || '' === $price || false === $price ) {
			return null;
		}

		if ( is_numeric( $price ) ) {
			$amount = (float) $price;
			return $amount > 0 ? $amount : null;
		}

		$str = (string) $price;
		if ( preg_match( '/(\d[\d,]*(?:\.\d+)?)/', $str, $m ) ) {
			$amount = (float) str_replace( ',', '', $m[1] );
			return $amount > 0 ? $amount : null;
		}

		$cleaned = preg_replace( '/[^0-9.]/', '', $str );
		if ( ! is_numeric( $cleaned ) ) {
			return null;
		}

		$amount = (float) $cleaned;
		return $amount > 0 ? $amount : null;
	}
}
