<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gbt_plans_as_object' ) ) {
	/**
	 * @param mixed $value Plan or pricing payload.
	 */
	function gbt_plans_as_object( $value ) {
		if ( is_array( $value ) ) {
			return (object) $value;
		}
		return is_object( $value ) ? $value : null;
	}
}

if ( ! function_exists( 'gbt_plans_currency_symbol' ) ) {
	function gbt_plans_currency_symbol( string $currency ): string {
		switch ( strtoupper( $currency ) ) {
			case 'EUR':
				return '€';
			case 'GBP':
				return '£';
			default:
				return '$';
		}
	}
}

if ( ! function_exists( 'gbt_plans_is_hidden' ) ) {
	function gbt_plans_is_hidden( $plan ): bool {
		$plan = gbt_plans_as_object( $plan );
		if ( ! $plan || ! isset( $plan->is_hidden ) ) {
			return false;
		}

		$hidden = $plan->is_hidden;
		return true === $hidden || 1 === $hidden || '1' === $hidden || 'true' === $hidden;
	}
}

if ( ! function_exists( 'gbt_plans_normalize_pricing_list' ) ) {
	/**
	 * @param mixed $pricing Raw plan pricing payload.
	 * @return object[]
	 */
	function gbt_plans_normalize_pricing_list( $pricing ): array {
		if ( empty( $pricing ) ) {
			return array();
		}

		if ( is_object( $pricing ) ) {
			$pricing = (array) $pricing;
		}

		if ( ! is_array( $pricing ) ) {
			return array();
		}

		if ( isset( $pricing['annual_price'] ) || isset( $pricing['lifetime_price'] ) || isset( $pricing['monthly_price'] ) ) {
			return array( (object) $pricing );
		}

		$out = array();
		foreach ( $pricing as $key => $item ) {
			$item = gbt_plans_as_object( $item );
			if ( ! $item ) {
				continue;
			}
			if ( empty( $item->id ) && ( is_int( $key ) || ( is_string( $key ) && ctype_digit( (string) $key ) ) ) ) {
				$item->id = (string) $key;
			}
			$out[] = $item;
		}

		return $out;
	}
}

if ( ! function_exists( 'gbt_plans_get_local_titles' ) ) {
	/**
	 * @param object $fs Freemius instance.
	 * @return array<string,string>
	 */
	function gbt_plans_get_local_titles( $fs ): array {
		$titles = array();

		if ( method_exists( $fs, 'get_plan' ) ) {
			$current = $fs->get_plan();
			if ( is_object( $current ) && ! empty( $current->id ) && ! empty( $current->title ) ) {
				$titles[ (string) $current->id ] = (string) $current->title;
			}
		}

		$plans = array();
		if ( method_exists( $fs, '_sync_plans' ) ) {
			try {
				$synced = $fs->_sync_plans();
				if ( is_array( $synced ) ) {
					$plans = $synced;
				}
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
			}
		}

		foreach ( $plans as $plan ) {
			$plan = gbt_plans_as_object( $plan );
			if ( ! $plan || empty( $plan->id ) || empty( $plan->title ) ) {
				continue;
			}
			$titles[ (string) $plan->id ] = (string) $plan->title;
		}

		return $titles;
	}
}

if ( ! function_exists( 'gbt_plans_build_periods' ) ) {
	/**
	 * @param object              $fs      Freemius instance.
	 * @param object              $pricing Pricing object.
	 * @param string              $symbol  Currency symbol.
	 * @param array<string,mixed> $extra   Checkout URL extras.
	 * @return array<string,array{price:string,period_label:string,checkout_url:string}>
	 */
	function gbt_plans_build_periods( $fs, $pricing, string $symbol, array $extra ): array {
		$fallback = method_exists( $fs, 'pricing_url' ) ? (string) $fs->pricing_url() : '';
		$checkout = static function ( $cycle ) use ( $fs, $extra, $fallback ) {
			return method_exists( $fs, 'checkout_url' )
				? (string) $fs->checkout_url( $cycle, false, $extra )
				: $fallback;
		};
		$format = static function ( $amount ) use ( $symbol ) {
			return $symbol . rtrim( rtrim( number_format( (float) $amount, 2, '.', '' ), '0' ), '.' );
		};

		$defs = array(
			'annual'   => array( $pricing->annual_price ?? null, '/ year', defined( 'WP_FS__PERIOD_ANNUALLY' ) ? WP_FS__PERIOD_ANNUALLY : 'annual' ),
			'lifetime' => array( $pricing->lifetime_price ?? null, 'once', defined( 'WP_FS__PERIOD_LIFETIME' ) ? WP_FS__PERIOD_LIFETIME : 'lifetime' ),
			'monthly'  => array( $pricing->monthly_price ?? null, '/ month', defined( 'WP_FS__PERIOD_MONTHLY' ) ? WP_FS__PERIOD_MONTHLY : 'monthly' ),
		);

		$periods = array();
		foreach ( $defs as $key => $def ) {
			$amount = gbt_parse_price_amount( $def[0] );
			if ( null === $amount || $amount <= 0 ) {
				continue;
			}
			$periods[ $key ] = array(
				'price'        => $format( $amount ),
				'period_label' => $def[1],
				'checkout_url' => $checkout( $def[2] ),
			);
		}

		return $periods;
	}
}

if ( ! function_exists( 'gbt_plans_extract_features' ) ) {
	/**
	 * @param object $plan Freemius plan object.
	 * @return array<int,array{title:string,description:string}>
	 */
	function gbt_plans_extract_features( $plan ): array {
		$out = array();
		if ( empty( $plan->features ) || ! is_array( $plan->features ) ) {
			return $out;
		}

		foreach ( $plan->features as $feature ) {
			$feature = gbt_plans_as_object( $feature );
			if ( ! $feature ) {
				continue;
			}
			$title = ! empty( $feature->title ) ? wp_strip_all_tags( (string) $feature->title ) : '';
			if ( $title === '' ) {
				continue;
			}
			if ( isset( $feature->is_featured ) && false === $feature->is_featured ) {
				continue;
			}
			$desc = '';
			if ( ! empty( $feature->description ) ) {
				$desc = wp_strip_all_tags( (string) $feature->description );
			} elseif ( ! empty( $feature->desc ) ) {
				$desc = wp_strip_all_tags( (string) $feature->desc );
			}
			$out[] = array(
				'title'       => $title,
				'description' => $desc,
			);
		}

		return $out;
	}
}

if ( ! function_exists( 'gbt_plans_fetch_raw' ) ) {
	/**
	 * @param object $fs Freemius instance.
	 * @return object[]
	 */
	function gbt_plans_fetch_raw( $fs ): array {
		if ( method_exists( $fs, 'get_api_plugin_scope' ) ) {
			try {
				$api    = $fs->get_api_plugin_scope();
				$params = array( 'is_enriched' => true );
				$path   = 'pricing.json?' . http_build_query( $params );
				if ( method_exists( $fs, 'add_show_pending' ) ) {
					$path = $fs->add_show_pending( $path );
				}
				if ( is_object( $api ) && method_exists( $api, 'get' ) ) {
					$result = $api->get( $path, true );
					if ( is_object( $result ) && ! empty( $result->plans ) && is_array( $result->plans ) ) {
						return $result->plans;
					}
				}
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
			}
		}

		if ( method_exists( $fs, '_sync_plans' ) ) {
			try {
				$plans = $fs->_sync_plans();
				if ( is_array( $plans ) && ! empty( $plans ) ) {
					return $plans;
				}
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
			}
		}

		return array();
	}
}

if ( ! function_exists( 'gbt_plans_get_available' ) ) {
	/**
	 * Paid Freemius plans/pricing for license and pricing pages.
	 *
	 * @param object $fs Freemius instance.
	 * @return array<int,array<string,mixed>>
	 */
	function gbt_plans_get_available( $fs ): array {
		$raw_plans = gbt_plans_fetch_raw( $fs );
		if ( empty( $raw_plans ) ) {
			return array();
		}

		$local_titles  = gbt_plans_get_local_titles( $fs );
		$current_plan  = method_exists( $fs, 'get_plan' ) ? $fs->get_plan() : null;
		$current_id    = ( is_object( $current_plan ) && ! empty( $current_plan->id ) ) ? (string) $current_plan->id : '';
		$current_title = '';
		if ( method_exists( $fs, 'get_plan_title' ) ) {
			$t = (string) $fs->get_plan_title();
			if ( $t !== '' && 'PLAN_TITLE' !== $t ) {
				$current_title = $t;
			}
		}

		$cards = array();

		foreach ( $raw_plans as $plan ) {
			$plan = gbt_plans_as_object( $plan );
			if ( ! $plan ) {
				continue;
			}

			$name = isset( $plan->name ) ? strtolower( (string) $plan->name ) : '';
			if ( 'free' === $name || gbt_plans_is_hidden( $plan ) ) {
				continue;
			}

			$pricing_list = gbt_plans_normalize_pricing_list( $plan->pricing ?? null );
			if ( empty( $pricing_list ) ) {
				continue;
			}

			$plan_id = ! empty( $plan->id ) ? (string) $plan->id : '';
			$title   = ! empty( $plan->title ) ? (string) $plan->title : ( $name !== '' ? ucwords( $name ) : 'Premium' );

			if ( $plan_id !== '' && ! empty( $local_titles[ $plan_id ] ) ) {
				$title = $local_titles[ $plan_id ];
			}
			if ( $plan_id !== '' && $plan_id === $current_id && $current_title !== '' ) {
				$title = $current_title;
			}

			$desc     = ! empty( $plan->description ) ? wp_strip_all_tags( (string) $plan->description ) : '';
			$features = gbt_plans_extract_features( $plan );

			foreach ( $pricing_list as $pricing ) {
				$currency = ! empty( $pricing->currency ) ? strtoupper( (string) $pricing->currency ) : 'USD';
				$symbol   = gbt_plans_currency_symbol( $currency );

				$extra = array();
				if ( $plan_id !== '' ) {
					$extra['plan_id'] = $plan_id;
				}
				if ( ! empty( $pricing->id ) ) {
					$extra['pricing_id'] = $pricing->id;
				}

				$periods = gbt_plans_build_periods( $fs, $pricing, $symbol, $extra );
				if ( empty( $periods ) ) {
					continue;
				}

				$default_key = isset( $periods['monthly'] )
					? 'monthly'
					: ( isset( $periods['annual'] )
						? 'annual'
						: ( isset( $periods['lifetime'] ) ? 'lifetime' : (string) array_key_first( $periods ) ) );
				$default     = $periods[ $default_key ];

				$cards[] = array(
					'title'        => $title,
					'name'         => $name,
					'slug'         => $name,
					'plan_id'      => $plan_id,
					'pricing_id'   => ! empty( $pricing->id ) ? (string) $pricing->id : '',
					'price'        => $default['price'],
					'period'       => $default_key,
					'period_label' => $default['period_label'],
					'checkout_url' => $default['checkout_url'],
					'featured'     => ! empty( $plan->is_featured ),
					'description'  => $desc,
					'features'     => $features,
					'periods'      => $periods,
				);
			}
		}

		return $cards;
	}
}

if ( ! function_exists( 'gbt_plans_is_card_owned' ) ) {
	/**
	 * @param object              $fs        Freemius instance.
	 * @param array<string,mixed> $card      Plan card from gbt_plans_get_available().
	 * @param bool                $is_active Whether the site has an active license.
	 */
	function gbt_plans_is_card_owned( $fs, array $card, bool $is_active ): bool {
		if ( ! $is_active ) {
			return false;
		}

		$card_plan_id    = ! empty( $card['plan_id'] ) ? (string) $card['plan_id'] : '';
		$card_pricing_id = ! empty( $card['pricing_id'] ) ? (string) $card['pricing_id'] : '';

		$license_pricing_id = '';
		if ( method_exists( $fs, '_get_license' ) ) {
			$license = $fs->_get_license();
			if ( is_object( $license ) && ! empty( $license->pricing_id ) ) {
				$license_pricing_id = (string) $license->pricing_id;
			}
		}

		if ( $license_pricing_id !== '' && $card_pricing_id !== '' ) {
			return $card_pricing_id === $license_pricing_id;
		}

		$site_plan_id = '';
		if ( method_exists( $fs, 'get_plan_id' ) ) {
			$pid = $fs->get_plan_id();
			if ( $pid !== null && $pid !== '' && false !== $pid ) {
				$site_plan_id = (string) $pid;
			}
		}
		if ( $site_plan_id === '' && method_exists( $fs, 'get_plan' ) ) {
			$plan = $fs->get_plan();
			if ( is_object( $plan ) && ! empty( $plan->id ) ) {
				$site_plan_id = (string) $plan->id;
			}
		}

		return $site_plan_id !== '' && $card_plan_id !== '' && $card_plan_id === $site_plan_id;
	}
}
