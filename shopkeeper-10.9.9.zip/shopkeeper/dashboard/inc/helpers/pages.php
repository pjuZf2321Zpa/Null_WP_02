<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gbt_dashboard_context' ) ) {
	/**
	 * Shared setup instance and base paths for dashboard pages.
	 *
	 * @return array{setup: GBT_Dashboard_Setup, paths: array{path: string, url: string}}
	 */
	function gbt_dashboard_context(): array {
		static $context = null;

		if ( null === $context ) {
			$setup            = GBT_Dashboard_Setup::init();
			$context          = array();
			$context['setup'] = $setup;
			$context['paths'] = $setup->get_base_paths();
		}

		return $context;
	}
}

if ( ! function_exists( 'gbt_render_dashboard_page' ) ) {
	/**
	 * Render a dashboard admin page with standard chrome.
	 *
	 * @param callable $render Callback receiving (GBT_Dashboard_Setup $setup, array $paths).
	 * @param array    $args   Optional: badges (bool, default true).
	 */
	function gbt_render_dashboard_page( callable $render, array $args = array() ): void {
		$context     = gbt_dashboard_context();
		$setup       = $context['setup'];
		$paths       = $context['paths'];
		$show_badges = ! isset( $args['badges'] ) || $args['badges'];
		$parts       = $paths['path'] . '/dashboard/inc/pages/content/template-parts/';

		include_once $parts . 'content-start.php';

		if ( $show_badges ) {
			include_once $parts . 'badges.php';
		}

		$render( $setup, $paths );

		include_once $parts . 'content-end.php';
	}
}

if ( ! function_exists( 'gbt_render_extension_card' ) ) {
	/**
	 * Render a Woo extension promo card on the home page.
	 */
	function gbt_render_extension_card( string $base_url, array $card ): void {
		$url         = (string) ( $card['url'] ?? '' );
		$image       = (string) ( $card['image'] ?? '' );
		$title       = (string) ( $card['title'] ?? '' );
		$description = (string) ( $card['description'] ?? '' );
		$badge       = (string) ( $card['badge'] ?? 'Revenue Booster' );

		if ( $url === '' || $image === '' || $title === '' ) {
			return;
		}
		?>
		<li class="col-span-1 flex flex-col rounded-lg bg-white text-center shadow-sm overflow-hidden cursor-pointer hover:shadow-md transition-all duration-300 group">
			<a href="<?php echo esc_url( $url ); ?>" target="_blank" class="flex flex-col flex-1">
				<div class="flex flex-1 flex-col p-8">
					<img class="mx-auto size-20 shrink-0 rounded-lg shadow-sm transition-all duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)] group-hover:-translate-y-2 group-hover:shadow-md will-change-transform" src="<?php echo esc_url( $base_url . $image ); ?>" alt="<?php echo esc_attr( $title ); ?>">
					<h3 class="mt-6 text-lg font-medium text-gray-900"><?php echo esc_html( $title ); ?></h3>
					<dl class="mt-1 flex grow flex-col justify-between">
						<dt class="sr-only">Title</dt>
						<dd class="text-sm text-gray-500"><?php echo esc_html( $description ); ?></dd>
						<dt class="sr-only">Role</dt>
						<dd class="mt-3">
							<span class="inline-flex items-center rounded-full bg-[var(--color-gbt-green)]/10 px-2 py-1 text-xs font-medium text-[var(--color-gbt-green)] ring-1 ring-[var(--color-gbt-green)]/20 ring-inset"><?php echo esc_html( $badge ); ?></span>
						</dd>
					</dl>
				</div>
				<div class="mt-auto border-t border-gray-200 bg-gray-50">
					<div class="flex items-center justify-center gap-x-3 py-4">
						<?php gbt_icon_e( 'arrow-top-right-on-square', 'size-5 text-gray-400' ); ?>
						<span class="text-sm font-semibold text-gray-900">View Extension</span>
					</div>
				</div>
			</a>
		</li>
		<?php
	}
}
