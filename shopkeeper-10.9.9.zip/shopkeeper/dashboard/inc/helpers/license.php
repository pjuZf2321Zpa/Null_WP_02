<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'gbt_license_consume_user_transient' ) ) {
	function gbt_license_consume_user_transient( string $prefix ): bool {
		$key = $prefix . get_current_user_id();
		if ( ! get_transient( $key ) ) {
			return false;
		}
		delete_transient( $key );
		return true;
	}
}

if ( ! function_exists( 'gbt_license_flash_messages' ) ) {
	/**
	 * @return array{purchased:bool,celebrate:bool,migrated:bool,synced:bool}
	 */
	function gbt_license_flash_messages( GBT_License_Manager $manager ): array {
		$purchased = isset( $_GET['purchase'] ) && 'success' === sanitize_key( wp_unslash( $_GET['purchase'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( gbt_license_consume_user_transient( 'gbt_license_purchased_' ) ) {
			$purchased = true;
		}
		if ( $purchased ) {
			$manager->sync_license();
		}

		$migrated  = gbt_license_consume_user_transient( 'gbt_license_migrated_' );
		$celebrate = gbt_license_consume_user_transient( 'gbt_license_celebrate_' );
		// Prefer conversion flash if both were set in the same request.
		if ( $migrated ) {
			$celebrate = false;
		}

		return array(
			'purchased' => $purchased,
			'celebrate' => $celebrate,
			'migrated'  => $migrated,
			'synced'    => gbt_license_consume_user_transient( 'gbt_license_synced_' ),
		);
	}
}

if ( ! function_exists( 'gbt_license_format_panel_title' ) ) {
	function gbt_license_format_panel_title( string $plan_name ): string {
		$title = trim( $plan_name );
		if ( $title === '' ) {
			return '';
		}
		if ( ! preg_match( '/\bplan\b/i', $title ) ) {
			return $title . ' Plan';
		}
		return $title;
	}
}

if ( ! function_exists( 'gbt_license_intro_text' ) ) {
	function gbt_license_intro_text( bool $licensed, bool $expired, string $plan = '' ): string {
		if ( $licensed ) {
			$plan_title = gbt_license_format_panel_title( $plan );
			if ( $plan_title !== '' ) {
				return 'License active. You\'re on the ' . $plan_title . '. Everything is unlocked.';
			}
			return 'License active. Everything is unlocked.';
		}
		if ( $expired ) {
			return 'Your license expired. Renew to restore updates, support, and full plan access.';
		}
		return 'Activate your license to unlock updates, support, and new features.';
	}
}

if ( ! function_exists( 'gbt_legacy_plan_notice_copy' ) ) {
	/**
	 * Shared copy for legacy (converted, no Freemius plan) license notices.
	 *
	 * @return array{badge:string,title:string,body:string,cta:string,cta_url:string,compact:string,variant:string}|null
	 */
	function gbt_legacy_plan_notice_copy(): ?array {
		if ( ! class_exists( 'GBT_License_Converter' ) ) {
			return null;
		}

		$converter = GBT_License_Converter::get_instance();
		if ( ! $converter->is_themeforest_legacy_active() ) {
			return null;
		}

		$manager     = GBT_License_Manager::get_instance();
		$expired     = $manager->is_expired();
		$grace       = $converter->get_grace_period_notice_data();
		$until_ts    = is_array( $grace ) ? (int) ( $grace['until_ts'] ?? 0 ) : 0;
		$until       = $until_ts > 0 ? date_i18n( 'F j', $until_ts ) : '';
		$pricing_url = GBT_License_Manager::pricing_page_url();
		$credit      = $converter->get_themeforest_credit_value();
		$cta         = $credit > 0 ? sprintf( 'Choose a plan — $%d credit', $credit ) : 'Choose a plan';
		$credit_bit  = $credit > 0 ? sprintf( ' $%d credit available at checkout.', $credit ) : '';
		$theme_name  = trim( (string) GBT_Dashboard_Setup::init()->get_theme_name() );
		$license_ref = $theme_name !== '' ? $theme_name . ' license' : 'license';
		$lead        = 'No plan associated with the ' . $license_ref . '.';

		if ( $expired ) {
			$body = $until !== ''
				? 'There\'s no plan associated with the ' . $license_ref . '. Updates and support ended on ' . $until . ' — choose a plan to bring them back.'
				: 'There\'s no plan associated with the ' . $license_ref . '. Updates and support have ended — choose a plan to bring them back.';
			$rest = $until !== ''
				? ' Updates and support ended on ' . $until . '.'
				: ' Updates and support have ended.';
			return array(
				'badge'       => 'No plan',
				'title'       => 'Updates and support have ended',
				'body'        => $body,
				'cta'         => $cta,
				'cta_url'     => $pricing_url,
				'compact'     => $lead . $rest . $credit_bit,
				'compact_lead'=> $lead,
				'compact_rest'=> $rest . $credit_bit,
				'compact_cta' => 'Choose a plan',
				'variant'     => $credit > 0 ? 'yellow' : 'red',
			);
		}

		$body = $until !== ''
			? 'There\'s no plan associated with the ' . $license_ref . '. Updates and support end on ' . $until . ' — choose a plan to keep everything unlocked.'
			: 'There\'s no plan associated with the ' . $license_ref . '. Updates and support will end — choose a plan to keep everything unlocked.';
		$rest = $until !== ''
			? ' Updates and support end on ' . $until . '.'
			: ' Updates and support will end.';

		return array(
			'badge'        => 'No plan',
			'title'        => 'Keep updates and support active',
			'body'         => $body,
			'cta'          => $cta,
			'cta_url'      => $pricing_url,
			'compact'      => $lead . $rest . $credit_bit,
			'compact_lead' => $lead,
			'compact_rest' => $rest . $credit_bit,
			'compact_cta'  => 'Choose a plan',
			'variant'      => 'yellow',
		);
	}
}

if ( ! function_exists( 'gbt_tf_updates_cutoff_date' ) ) {
	/** Themeforest marketplace theme-update cutoff (Y-m-d, site timezone). */
	function gbt_tf_updates_cutoff_date(): string {
		return trim( (string) GBT_Dashboard_Setup::init()->get_global_config( 'themeforest_updates_cutoff' ) );
	}
}

if ( ! function_exists( 'gbt_tf_price_increase_scheduled' ) ) {
	/**
	 * Scheduled plan price increase config, or null when unset / no date.
	 *
	 * @return array{date:string}|null
	 */
	function gbt_tf_price_increase_scheduled(): ?array {
		$config = GBT_Dashboard_Setup::init()->get_global_config( 'price_increase' );
		if ( ! is_array( $config ) ) {
			return null;
		}

		$date = trim( (string) ( $config['date'] ?? '' ) );
		if ( $date === '' ) {
			return null;
		}

		return array(
			'date' => $date,
		);
	}
}

if ( ! function_exists( 'gbt_tf_price_increase_date' ) ) {
	/** Scheduled plan price increase (Y-m-d, site timezone). Empty when not configured. */
	function gbt_tf_price_increase_date(): string {
		$config = gbt_tf_price_increase_scheduled();
		return is_array( $config ) ? (string) $config['date'] : '';
	}
}

if ( ! function_exists( 'gbt_tf_updates_cutoff_passed' ) ) {
	function gbt_tf_updates_cutoff_passed(): bool {
		$cutoff = gbt_tf_updates_cutoff_date();
		return $cutoff !== '' && gbt_now_ymd() >= $cutoff;
	}
}

if ( ! function_exists( 'gbt_tf_updates_cutoff_soon' ) ) {
	/** When true, conversion copy uses “stop soon” (future) instead of the cutoff date. */
	function gbt_tf_updates_cutoff_soon(): bool {
		return (bool) GBT_Dashboard_Setup::init()->get_global_config( 'themeforest_updates_cutoff_soon' );
	}
}

if ( ! function_exists( 'gbt_tf_updates_cutoff_label' ) ) {
	function gbt_tf_updates_cutoff_label(): string {
		$ts = strtotime( gbt_tf_updates_cutoff_date() );
		return false !== $ts ? date_i18n( 'F j, Y', $ts ) : '';
	}
}

if ( ! function_exists( 'gbt_tf_convert_deadline_copy' ) ) {
	/**
	 * Date-aware titles/copy for Themeforest conversion surfaces.
	 * When themeforest_updates_cutoff_soon is true, always uses the future “stop soon” branch.
	 *
	 * @return array{
	 *   passed:bool,
	 *   label:string,
	 *   side_title:string,
	 *   side_body:string,
	 *   why_title_line1:string,
	 *   why_title_line2:string,
	 *   why_body:string,
	 *   why_step2_title:string,
	 *   why_step2_desc:string,
	 *   howto_title:string,
	 *   howto_body:string,
	 *   howto_updates_desc:string
	 * }
	 */
	function gbt_tf_convert_deadline_copy( string $theme_name = '' ): array {
		$soon        = gbt_tf_updates_cutoff_soon();
		$passed      = $soon ? false : gbt_tf_updates_cutoff_passed();
		$label       = gbt_tf_updates_cutoff_label();
		$theme_name  = trim( $theme_name );
		$theme_label = $theme_name !== '' ? $theme_name : 'Theme';
		$tf_verb     = $passed ? 'stopped' : 'stop';
		$tf_when     = $soon ? 'soon' : $label;
		$tf_stop     = $theme_label . ' updates from Themeforest ' . $tf_verb . ' ' . $tf_when;
		$platform    = 'our new platform';

		return array(
			'passed'             => $passed,
			'label'              => $label,
			'side_title'         => 'Convert your Themeforest purchase code',
			'side_body'          => $tf_stop . '. Convert your Themeforest purchase code to a license key to keep updates and support.',
			'why_title_line1'    => $tf_stop . '.',
			'why_title_line2'    => 'We continue updates on ' . $platform . '.',
			'why_body'           => 'Your Themeforest purchase is recognized. Conversion turns the purchase code into a license key so you keep updates and support. Nothing on your site changes.',
			'why_step2_title'    => $tf_stop,
			'why_step2_desc'     => 'Updates continue on ' . $platform . '.',
			'howto_title'        => 'Your purchase code becomes a license key',
			'howto_body'         => 'After that, updates and support come from ' . $platform . ' instead of Themeforest.',
			'howto_updates_desc' => 'Continued on ' . $platform,
		);
	}
}

if ( ! function_exists( 'gbt_render_license_success_notice' ) ) {
	function gbt_render_license_success_notice( string $message ): void {
		?>
		<div class="gbt-license-flash mt-4 rounded-md border border-[var(--color-gbt-green)]/20 bg-[var(--color-gbt-green)]/10 px-4 py-3 text-sm text-[var(--color-gbt-green)]" role="status">
			<span class="gbt-license-flash__icon" aria-hidden="true"><?php gbt_icon_e( 'check-badge', 'size-5', 'solid' ); ?></span>
			<span class="gbt-license-flash__body"><?php echo esc_html( $message ); ?></span>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_render_license_key_block' ) ) {
	/**
	 * License key row (masked/reveal + valid/expired) and optional sync form.
	 *
	 * @param array<string,mixed> $fs Display data from license manager.
	 */
	function gbt_render_license_key_block( array $fs, bool $expired, bool $include_sync = true, string $wrap_class = '' ): void {
		$key_masked = ! empty( $fs['key'] ) ? (string) $fs['key'] : '••••••••';
		$key_full   = ! empty( $fs['key_full'] ) ? (string) $fs['key_full'] : $key_masked;
		$can_reveal = $key_full !== '' && $key_full !== $key_masked;
		$key_color  = $expired ? 'text-[var(--color-gbt-red)]' : 'text-[var(--color-gbt-green)]';
		?>
		<div class="<?php echo esc_attr( trim( 'flex flex-col gap-4 ' . $wrap_class ) ); ?>">
			<div>
				<div class="flex items-center gap-2 mb-2">
					<?php gbt_icon_e( 'key', 'size-5 shrink-0 text-gray-400' ); ?>
					<span class="text-sm font-medium text-white">License key</span>
				</div>
				<div class="flex items-center gap-3 w-full py-1">
					<span class="font-mono text-sm tracking-wide break-all <?php echo esc_attr( $key_color ); ?>" data-gbt-key-display data-masked="<?php echo esc_attr( $key_masked ); ?>" data-full="<?php echo esc_attr( $key_full ); ?>"><?php echo esc_html( $key_masked ); ?></span>
					<?php if ( $can_reveal ) : ?>
						<button type="button" class="inline-flex shrink-0 items-center justify-center rounded p-1 text-gray-400 hover:text-white transition duration-150 ease-in-out cursor-pointer border-0 bg-transparent shadow-none" data-gbt-key-reveal aria-pressed="false" aria-label="Reveal license key" title="Reveal license key">
							<span data-reveal-show class="inline-flex"><?php gbt_icon_e( 'eye', 'size-5' ); ?></span>
							<span data-reveal-hide class="hidden"><?php gbt_icon_e( 'eye-slash', 'size-5' ); ?></span>
						</button>
					<?php endif; ?>
					<?php if ( $expired ) : ?>
						<span class="inline-flex items-center text-sm font-medium text-[var(--color-gbt-red)]">
							<?php gbt_icon_e( 'exclamation-circle', 'size-5 mr-1.5', 'solid', 20 ); ?>
							Expired
						</span>
					<?php else : ?>
						<span class="inline-flex items-center text-sm font-medium text-[var(--color-gbt-green)]">
							<?php gbt_icon_e( 'check-badge', 'size-5 mr-1.5', 'solid' ); ?>
							Valid
						</span>
					<?php endif; ?>
				</div>
			</div>

			<?php if ( $include_sync && ! empty( $fs['sync_action'] ) && ! empty( $fs['sync_url'] ) ) : ?>
				<div class="flex flex-wrap items-center gap-3">
					<form id="gbt-sync-license-form" method="post" action="<?php echo esc_url( (string) $fs['sync_url'] ); ?>" class="inline-flex m-0 p-0" data-gbt-busy-submit data-gbt-busy-label="Syncing…">
						<input type="hidden" name="fs_action" value="<?php echo esc_attr( (string) $fs['sync_action'] ); ?>">
						<input type="hidden" name="gbt_return_license" value="1">
						<?php wp_nonce_field( (string) $fs['sync_action'] ); ?>
						<button type="submit" id="gbt-sync-license-submit" class="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-[var(--color-gbt-gray-lighter)] px-6 text-sm font-medium leading-none text-white/80 ring-1 ring-[var(--color-gbt-gray-lighter)] hover:bg-[var(--color-gbt-gray-light)] hover:text-white transition duration-150 ease-in-out cursor-pointer border-0 shadow-none">
							<?php gbt_icon_e( 'arrow-path', 'size-5 shrink-0' ); ?>
							Sync license
						</button>
					</form>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_render_license_seal' ) ) {
	function gbt_render_license_seal( string $tone, string $icon, string $style = 'outline', int $size = 24 ): void {
		?>
		<div class="gbt-license-seal <?php echo esc_attr( $tone ); ?>" aria-hidden="true">
			<span class="gbt-license-seal__bloom"></span>
			<span class="gbt-license-seal__orbit"></span>
			<span class="gbt-license-seal__ring"></span>
			<span class="gbt-license-seal__spark gbt-license-seal__spark--a"></span>
			<span class="gbt-license-seal__spark gbt-license-seal__spark--b"></span>
			<span class="gbt-license-seal__spark gbt-license-seal__spark--c"></span>
			<span class="gbt-license-seal__core">
				<?php gbt_icon_e( $icon, 'gbt-license-seal__icon', $style, $size ); ?>
			</span>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_mask_purchase_code' ) ) {
	function gbt_mask_purchase_code( string $key ): string {
		$parts = explode( '-', $key );
		if ( 5 !== count( $parts ) ) {
			return $key;
		}
		$parts[1] = '****';
		$parts[2] = '****';
		$parts[3] = '****';
		return implode( '-', $parts );
	}
}

if ( ! function_exists( 'gbt_mask_license_key_compact' ) ) {
	/** Short table mask: first 4 + bullet block + last 4. */
	function gbt_mask_license_key_compact( string $key ): string {
		$key = trim( $key );
		if ( strlen( $key ) <= 8 ) {
			return '••••••••';
		}
		return substr( $key, 0, 4 ) . '-••••-' . substr( $key, -4 );
	}
}

if ( ! function_exists( 'gbt_render_license_key_status_row' ) ) {
	/**
	 * Status-table license key row: compact mask, eye expands full key, sync beside eye.
	 *
	 * @param array<string,mixed> $fs Display data from license manager.
	 */
	function gbt_render_license_key_status_row( array $fs ): void {
		$key_full   = ! empty( $fs['key_full'] ) ? (string) $fs['key_full'] : ( ! empty( $fs['key'] ) ? (string) $fs['key'] : '' );
		$key_masked = $key_full !== '' ? gbt_mask_license_key_compact( $key_full ) : '••••••••';
		$can_reveal = $key_full !== '' && $key_full !== $key_masked;
		$can_sync   = ! empty( $fs['sync_action'] ) && ! empty( $fs['sync_url'] );
		$btn        = 'inline-flex shrink-0 items-center justify-center rounded p-1 text-white hover:text-white/80 transition duration-150 ease-in-out cursor-pointer border-0 bg-transparent shadow-none';
		?>
		<div class="border-t border-white/10 py-3" data-gbt-key-row>
			<div class="flex items-center justify-between gap-3">
				<span class="text-sm text-gray-400">License key</span>
				<span class="inline-flex shrink-0 items-center justify-end gap-2.5">
					<span class="text-sm font-medium text-white text-right whitespace-nowrap"><?php echo esc_html( $key_masked ); ?></span>
					<span class="inline-flex items-center gap-1">
						<?php if ( $can_reveal ) : ?>
							<button type="button" class="<?php echo esc_attr( $btn ); ?>" data-gbt-key-reveal data-gbt-key-expand aria-pressed="false" aria-expanded="false" aria-controls="gbt-license-key-panel" aria-label="Reveal license key" title="Reveal license key">
								<span data-reveal-show class="inline-flex"><?php gbt_icon_e( 'eye', 'size-4' ); ?></span>
								<span data-reveal-hide class="hidden"><?php gbt_icon_e( 'eye-slash', 'size-4' ); ?></span>
							</button>
						<?php endif; ?>
						<?php if ( $can_sync ) : ?>
							<form id="gbt-sync-license-form" method="post" action="<?php echo esc_url( (string) $fs['sync_url'] ); ?>" class="inline-flex m-0 p-0" data-gbt-busy-submit data-gbt-busy-icon>
								<input type="hidden" name="fs_action" value="<?php echo esc_attr( (string) $fs['sync_action'] ); ?>">
								<input type="hidden" name="gbt_return_license" value="1">
								<?php wp_nonce_field( (string) $fs['sync_action'] ); ?>
								<button type="submit" id="gbt-sync-license-submit" class="<?php echo esc_attr( $btn ); ?>" aria-label="Sync license" title="Sync license">
									<?php gbt_icon_e( 'arrow-path', 'size-4 shrink-0' ); ?>
								</button>
							</form>
						<?php endif; ?>
					</span>
				</span>
			</div>
			<?php if ( $can_reveal ) : ?>
				<div id="gbt-license-key-panel" class="hidden mt-2 rounded-md bg-[var(--color-gbt-gray-dark)]/60 px-3 py-2.5 ring-1 ring-inset ring-white/5" data-gbt-key-panel>
					<div class="flex items-center gap-2">
						<p class="m-0 min-w-0 flex-1 font-mono text-sm tracking-wide leading-5 text-[var(--color-gbt-green)] break-all" data-gbt-key-full><?php echo esc_html( $key_full ); ?></p>
						<button type="button" class="<?php echo esc_attr( $btn ); ?>" data-gbt-key-copy aria-label="Copy license key" title="Copy license key">
							<span data-copy-idle class="inline-flex"><?php gbt_icon_e( 'clipboard-document-list', 'size-4' ); ?></span>
							<span data-copy-done class="hidden text-[var(--color-gbt-green)]"><?php gbt_icon_e( 'check', 'size-4', 'solid', 16 ); ?></span>
						</button>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_license_status_rows' ) ) {
	/**
	 * @return array<int,array{0:string,1:string,2:bool|string,3?:string}>
	 */
	function gbt_license_status_rows( array $fs, bool $entitled, string $tf_purchase, bool $include_key = false ): array {
		$rows = array(
			array( 'License plan', (string) ( $fs['plan'] ?? '' ), false ),
			array( 'License ID', (string) ( $fs['license_id'] ?? '' ), false ),
			array( 'User ID', (string) ( $fs['user_id'] ?? '' ), false ),
		);
		if ( $tf_purchase !== '' ) {
			$rows[] = array( 'Purchase date', $tf_purchase, false );
		}
		$rows[] = array( 'Active until', (string) ( $fs['expires'] ?? '' ), $entitled ? false : 'bad' );
		$rows[] = array( 'Updates', $entitled ? 'Available' : 'Disabled', $entitled ? true : 'bad' );
		$rows[] = array( 'Support', $entitled ? 'Available' : 'Disabled', $entitled ? true : 'bad' );
		return $rows;
	}
}

if ( ! function_exists( 'gbt_render_license_status_row' ) ) {
	/**
	 * @param bool|string $status true|false|'bad'
	 */
	function gbt_render_license_status_row( string $label, string $value, $status, string $full = '' ): void {
		?>
		<div class="border-t border-white/10 py-3">
			<div class="flex items-center justify-between gap-3">
				<span class="text-sm text-gray-400"><?php echo esc_html( $label ); ?></span>
				<?php if ( true === $status ) : ?>
					<span class="text-sm font-medium text-[var(--color-gbt-green)] flex items-center">
						<?php gbt_icon_e( 'check-badge', 'size-5 mr-1.5', 'solid' ); ?>
						<?php echo esc_html( $value ); ?>
					</span>
				<?php elseif ( 'bad' === $status ) : ?>
					<span class="text-sm font-medium text-[var(--color-gbt-red)] flex items-center gap-2">
						<?php gbt_icon_e( 'exclamation-circle', 'size-5 shrink-0', 'solid', 20 ); ?>
						<span><?php echo esc_html( $value ); ?></span>
					</span>
				<?php else : ?>
					<span class="text-sm font-medium text-white text-right"><?php echo esc_html( $value ); ?></span>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_license_panel_cta' ) ) {
	/**
	 * @return array{label:string,icon:string}
	 */
	function gbt_license_panel_cta( bool $expired, bool $is_legacy_plan, int $tf_credit_value ): array {
		if ( $expired && $is_legacy_plan ) {
			return array(
				'label' => 'Get full access - choose a plan',
				'icon'  => 'key',
			);
		}
		if ( $expired ) {
			return array(
				'label' => 'Renew plan - unlock instantly',
				'icon'  => 'key',
			);
		}
		if ( $is_legacy_plan ) {
			$label = 'Choose a plan';
			if ( $tf_credit_value > 0 ) {
				$label = sprintf( 'Choose a plan — $%d credit', $tf_credit_value );
			}
			return array(
				'label' => $label,
				'icon'  => '',
			);
		}
		return array(
			'label' => 'Change plan',
			'icon'  => '',
		);
	}
}

if ( ! function_exists( 'gbt_license_trust_status' ) ) {
	/**
	 * @return array{label:string,dot:string,pill:string}
	 */
	function gbt_license_trust_status( bool $licensed, bool $expired, bool $show_tf_migration ): array {
		if ( $licensed ) {
			return array(
				'label' => 'License active',
				'dot'   => 'bg-[var(--color-gbt-green)]',
				'pill'  => 'green-soft',
			);
		}
		if ( $expired ) {
			return array(
				'label' => 'License expired',
				'dot'   => 'bg-[var(--color-gbt-red)]',
				'pill'  => 'red',
			);
		}
		if ( $show_tf_migration ) {
			return array(
				'label' => 'Conversion needed',
				'dot'   => 'bg-[var(--color-gbt-red)]',
				'pill'  => 'red',
			);
		}
		return array(
			'label' => 'Awaiting activation',
			'dot'   => 'bg-[var(--color-gbt-yellow)]',
			'pill'  => 'yellow',
		);
	}
}

if ( ! function_exists( 'gbt_render_license_trust_footer' ) ) {
	function gbt_render_license_trust_footer( string $theme_name, string $theme_version, bool $licensed, bool $expired, bool $show_tf_migration ): void {
		$checked_ts = 0;
		if ( class_exists( 'GBT_License_Manager' ) ) {
			$checked_ts = GBT_License_Manager::get_instance()->get_license_last_checked_ts();
		}
		$checked_at = $checked_ts > 0
			? date_i18n( get_option( 'time_format' ) . ' · ' . get_option( 'date_format' ), $checked_ts )
			: date_i18n( get_option( 'time_format' ) . ' · ' . get_option( 'date_format' ) );
		$trust_bits = array_filter(
			array(
				$theme_name . ' Dashboard v' . $theme_version,
				'WordPress ' . get_bloginfo( 'version' ),
				defined( 'WC_VERSION' ) ? 'WooCommerce ' . WC_VERSION : '',
				'PHP ' . PHP_VERSION,
				defined( 'WP_FS__SDK_VERSION' ) ? 'SDK ' . WP_FS__SDK_VERSION : '',
				is_ssl() ? 'HTTPS' : 'HTTP',
			)
		);

		$status      = gbt_license_trust_status( $licensed, $expired, $show_tf_migration );
		$pill_base   = 'gap-1.5 ' . gbt_pricing_pill_badge_class( 'green-soft' );
		$pill_ok     = $pill_base;
		$pill_stat   = 'gap-1.5 ' . gbt_pricing_pill_badge_class( $status['pill'] );
		?>
		<div class="mt-5 flex flex-col items-center gap-3 px-2 text-center">
			<div class="flex flex-wrap items-center justify-center gap-2">
				<span class="<?php echo esc_attr( $pill_ok ); ?>">
					<span class="relative flex size-2 shrink-0">
						<span class="absolute inline-flex size-full animate-ping rounded-full bg-[var(--color-gbt-green)] opacity-40"></span>
						<span class="relative inline-flex size-2 rounded-full bg-[var(--color-gbt-green)]"></span>
					</span>
					All checks passed
				</span>
				<span class="<?php echo esc_attr( $pill_ok ); ?>">
					<span class="relative flex size-2 shrink-0">
						<span class="absolute inline-flex size-full animate-ping rounded-full bg-[var(--color-gbt-green)] opacity-40"></span>
						<span class="relative inline-flex size-2 rounded-full bg-[var(--color-gbt-green)]"></span>
					</span>
					Servers online
				</span>
				<span class="<?php echo esc_attr( $pill_stat ); ?>">
					<span class="relative flex size-2 shrink-0">
						<span class="absolute inline-flex size-full animate-ping rounded-full <?php echo esc_attr( $status['dot'] ); ?> opacity-40"></span>
						<span class="relative inline-flex size-2 rounded-full <?php echo esc_attr( $status['dot'] ); ?>"></span>
					</span>
					<?php echo esc_html( $status['label'] ); ?>
				</span>
			</div>
			<div class="flex flex-col items-center gap-0.5">
				<p class="max-w-3xl text-sm leading-5 text-gray-400">
					<?php
					$bit_i = 0;
					foreach ( $trust_bits as $bit ) :
						if ( $bit_i > 0 ) :
							?>
							<span class="mx-2 inline-block size-1 shrink-0 rounded-full bg-gray-400 align-middle" aria-hidden="true"></span>
							<?php
						endif;
						echo esc_html( $bit );
						++$bit_i;
					endforeach;
					?>
				</p>
				<p class="text-sm leading-5 text-gray-400">
					Last checked <?php echo esc_html( $checked_at ); ?>
				</p>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_render_license_overlay_close' ) ) {
	function gbt_render_license_overlay_close( string $dismiss_attr = 'data-gbt-overlay-dismiss' ): void {
		?>
		<button type="button" class="absolute top-6 right-6 z-20 inline-flex items-center justify-center rounded-md text-gray-300 bg-[var(--color-gbt-gray-light)] hover:text-white hover:bg-white/20 transition duration-150 ease-in-out cursor-pointer border-0 p-1.5" <?php echo esc_attr( $dismiss_attr ); ?> aria-label="Close">
			<?php gbt_icon_e( 'x-mark', 'size-5', 'solid', 20 ); ?>
		</button>
		<?php
	}
}

if ( ! function_exists( 'gbt_render_license_overlay_step' ) ) {
	function gbt_render_license_overlay_step( int $num, string $title, string $desc, string $variant = 'neutral' ): void {
		$badge = ( 'blue' === $variant )
			? 'bg-[var(--color-gbt-blue)]'
			: 'bg-[var(--color-gbt-gray-dark)]';
		?>
		<div class="flex flex-1 items-start gap-2.5 px-4 py-3 m-0">
			<span class="inline-flex h-6 w-9 shrink-0 items-center justify-center" aria-hidden="true">
				<span class="inline-flex size-6 items-center justify-center rounded-full <?php echo esc_attr( $badge ); ?> text-sm font-bold leading-none text-white"><?php echo esc_html( (string) $num ); ?></span>
			</span>
			<div class="min-w-0">
				<p class="text-sm font-medium leading-6 text-white"><?php echo esc_html( $title ); ?></p>
				<p class="mt-0.5 text-sm leading-5 text-gray-400"><?php echo esc_html( $desc ); ?></p>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'gbt_render_license_check_step' ) ) {
	function gbt_render_license_check_step( string $title, string $desc ): void {
		?>
		<div class="flex flex-1 items-start gap-2.5 px-4 py-3 m-0">
			<span class="inline-flex h-6 w-9 shrink-0 items-center justify-center" aria-hidden="true">
				<span class="inline-flex size-6 items-center justify-center rounded-full bg-[var(--color-gbt-blue)] text-white"><?php gbt_icon_e( 'check', 'size-3', 'solid', 16 ); ?></span>
			</span>
			<div class="min-w-0">
				<p class="text-sm font-medium leading-6 text-white"><?php echo esc_html( $title ); ?></p>
				<p class="mt-0.5 text-sm leading-5 text-gray-400"><?php echo esc_html( $desc ); ?></p>
			</div>
		</div>
		<?php
	}
}
