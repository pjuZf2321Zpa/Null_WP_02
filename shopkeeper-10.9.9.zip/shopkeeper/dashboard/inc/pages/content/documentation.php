<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'getbowtied_documentation_content' ) ) {
	function getbowtied_documentation_content() {
		gbt_render_dashboard_page(
			static function ( $setup ) {
				$theme_url_docs = $setup->get_theme_url_docs();
				?>
				<div style="padding:10px 40px; margin: 20px 0 0 0">
					<div style="padding:10px 10px; border: 1px solid #ddd; background: #fff">⚠ We are working on new documentation. You will find it here when it is ready. In the meantime you have the old one below.</div>
				</div>
				<iframe id="getbowtied_dashboard_iframe" src="<?php echo esc_url( $theme_url_docs ); ?>"></iframe>
				<?php
			},
			array( 'badges' => false )
		);
	}
}
