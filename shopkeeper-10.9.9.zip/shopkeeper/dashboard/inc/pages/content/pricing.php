<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'getbowtied_pricing_content' ) ) {
	/**
	 * Plans & Pricing page — Freemius plan cards and checkout.
	 */
	function getbowtied_pricing_content() {
		$setup   = GBT_Dashboard_Setup::init();
		$manager = GBT_License_Manager::get_instance();
		$fs          = $manager->get_display_data();
		$buy_url     = $fs['pricing_url'] !== '' ? $fs['pricing_url'] : (string) $setup->get_theme_config( 'theme_infos_url' );
		$license_url = GBT_License_Manager::license_page_url();
		$plans       = $manager->get_available_plans();
		$wp_years    = max( 0, (int) gmdate( 'Y' ) - 2012 );
		$theme_name  = (string) $setup->get_theme_name();
		$pricing_eyebrow = ( $theme_name !== '' )
			? sprintf( '%s Theme — Stay licensed', $theme_name )
			: 'Stay licensed';

		$license_expired  = $manager->is_expired();
		$has_license      = $manager->has_license();
		$expires_label    = trim( (string) ( $fs['expires'] ?? '' ) );
		$plan_name        = trim( (string) ( $fs['plan'] ?? '' ) );
		$has_expiry_date  = $manager->has_dated_expiration();
		$tf_converter     = GBT_License_Converter::get_instance();
		$tf_legacy_active = $tf_converter->is_themeforest_legacy_active();
		$tf_credit_value  = $tf_converter->get_themeforest_credit_value();
		$has_tf_credit    = $tf_credit_value > 0;
		$cta_verb         = 'Choose';
		$tf_licenses      = $tf_legacy_active ? $tf_converter->get_themeforest_purchase_count() : 0;

		if ( $has_tf_credit && ! empty( $plans ) ) {
			$plans = gbt_pricing_apply_coupon_to_plans(
				$plans,
				$tf_converter->get_themeforest_coupon_code()
			);
		}

		if ( $plan_name !== '' && ! preg_match( '/\bplan\b/i', $plan_name ) ) {
			$plan_label = $plan_name . ' Plan';
		} elseif ( $plan_name !== '' ) {
			$plan_label = $plan_name;
		} else {
			$plan_label = 'Current plan';
		}

		$tf_credit_lead = '';
		$tf_credit_until = '';
		if ( $has_tf_credit ) {
			$tf_credit_until = $tf_converter->get_coupon_until_display();
			$tf_credit_lead  = sprintf(
				'You’ve got a $%d credit for your ThemeForest purchase — applied on yearly plans',
				$tf_credit_value
			);
			if ( $tf_credit_until !== '' ) {
				$tf_credit_lead .= ' until ' . $tf_credit_until . '.';
			} else {
				$tf_credit_lead .= '.';
			}
		}

		$badge_state = gbt_pricing_license_badge_state(
			$has_license,
			$license_expired,
			$tf_legacy_active,
			$has_expiry_date,
			$has_tf_credit,
			$plan_label,
			$expires_label,
			$tf_credit_lead
		);

		gbt_render_dashboard_page(
			static function ( $setup, $paths ) use (
				$pricing_eyebrow,
				$badge_state,
				$wp_years,
				$plans,
				$cta_verb,
				$tf_legacy_active,
				$tf_licenses,
				$tf_credit_lead,
				$has_tf_credit,
				$tf_credit_value,
				$license_url,
				$buy_url,
				$manager,
				$theme_name
			) {
				?>

		<div class="min-w-0 overflow-x-clip">
		<section aria-label="Theme stats" class="px-4 pt-4 sm:px-6 sm:pt-5 lg:px-8">
			<div class="gbt-stats-bar mx-auto grid max-w-4xl grid-cols-3 items-center divide-x divide-gray-200/90 overflow-hidden rounded-full bg-white text-center text-xs font-medium leading-normal text-gray-700 ring-1 ring-gray-200/90">
				<div class="gbt-stats-cell flex h-full min-w-0 items-center justify-center gap-1.5 px-3 py-2.5 sm:px-4">
					<?php gbt_icon_e( 'shopping-bag', 'size-4 shrink-0 text-gbt-blue', 'solid', 16 ); ?>
					<span class="gbt-stats-cell__label">63,000+ customers bought our themes</span>
				</div>
				<div class="gbt-stats-cell flex h-full min-w-0 items-center justify-center gap-1.5 px-3 py-2.5 sm:px-4">
					<span class="inline-flex shrink-0 items-center gap-px text-[var(--color-gbt-yellow)]" aria-hidden="true">
						<?php for ( $i = 0; $i < 5; $i++ ) : ?>
							<?php gbt_icon_e( 'star', 0 === $i ? 'size-4 shrink-0' : 'hidden size-4 shrink-0 sm:inline', 'solid', 16 ); ?>
						<?php endfor; ?>
					</span>
					<span class="gbt-stats-cell__label">4.6 from 3,000+ ratings</span>
				</div>
				<?php if ( $wp_years > 0 ) : ?>
					<div class="gbt-stats-cell flex h-full min-w-0 items-center justify-center gap-1.5 px-3 py-2.5 sm:px-4">
						<?php gbt_icon_e( 'calendar-days', 'size-4 shrink-0 text-gbt-blue', 'solid', 16 ); ?>
						<span class="gbt-stats-cell__label"><?php echo esc_html( (string) $wp_years ); ?> years in the themes industry</span>
					</div>
				<?php else : ?>
					<div aria-hidden="true"></div>
				<?php endif; ?>
			</div>
		</section>

		<?php if ( empty( $plans ) ) : ?>
		<div class="pb-24 sm:pb-32">
			<div class="pt-16 sm:pt-20">
				<div class="mx-auto max-w-2xl text-center">
					<h2 class="text-base/7 font-semibold text-gbt-blue"><?php echo esc_html( $pricing_eyebrow ); ?></h2>
					<p class="mt-2 text-3xl font-semibold tracking-tight text-balance text-gray-900 sm:text-4xl lg:text-5xl">Plans are temporarily unavailable</p>
					<p class="mt-6 text-lg font-medium text-pretty text-gray-600">You can still get a license or activate a key you already have.</p>
					<div class="mt-8 flex flex-wrap items-center justify-center gap-3">
						<?php if ( $buy_url !== '' ) : ?>
							<a href="<?php echo esc_url( $buy_url ); ?>" class="inline-flex items-center justify-center rounded-md bg-gbt-blue px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-gbt-blue/90 transition duration-150 ease-in-out no-underline">Get a license</a>
						<?php endif; ?>
						<a href="<?php echo esc_url( $license_url ); ?>" class="inline-flex items-center justify-center rounded-md bg-white px-4 py-2.5 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 transition duration-150 ease-in-out no-underline">Activate license</a>
					</div>
				</div>
			</div>
		</div>
		<?php else :
			$layout             = gbt_pricing_prepare_layout( $plans, $manager, $tf_legacy_active, $tf_licenses );
			$plans              = $layout['plans'];
			$featured_idx       = $layout['featured_idx'];
			$show_period_toggle = $layout['show_period_toggle'];
			$available_periods  = $layout['available_periods'];
			$plan_count         = $layout['plan_count'];
			$use_trio_layout    = 3 === $plan_count;
			$feature_groups     = $manager->get_pricing_feature_groups();
			?>
		<div class="group/tiers relative isolate overflow-x-clip px-4 pt-14 pb-12 sm:px-6 sm:pt-16 sm:pb-16 lg:px-8">
			<div class="pointer-events-none absolute inset-x-0 -top-3 -z-10 overflow-hidden" aria-hidden="true">
				<div class="transform-gpu px-36 blur-3xl">
					<div class="mx-auto aspect-1155/678 w-[72.1875rem] bg-linear-to-tr from-[#80a2ff] to-[#89a7fc] opacity-30" style="clip-path: polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)"></div>
				</div>
			</div>
			<div class="mx-auto w-full max-w-lg text-center lg:max-w-4xl">
				<h2 id="pricing-options" class="scroll-mt-20 text-base/7 font-semibold text-gbt-blue"><?php echo esc_html( $pricing_eyebrow ); ?></h2>
				<p class="mt-2 text-3xl font-semibold tracking-tight leading-tight text-balance text-gray-900 sm:text-4xl lg:text-5xl lg:leading-tight">Keep your live shop updated, supported, and secure</p>
			</div>
			<p class="mx-auto mt-6 w-full max-w-lg text-center text-lg font-medium text-pretty text-gray-600 sm:max-w-2xl lg:mt-8 lg:text-xl/8">— With a modern license and plans billed monthly, yearly, or lifetime — including continuous updates and support.</p>

			<?php if ( $badge_state['show'] ) : ?>
				<div id="gbt-pricing-credit" class="mt-6 lg:mt-8">
					<?php gbt_render_pricing_license_status( $badge_state['text'], $badge_state['variant'] ); ?>
				</div>
			<?php endif; ?>

			<?php
			if ( $show_period_toggle ) :
				$period_labels  = array(
					'monthly'  => 'Monthly',
					'annual'   => 'Yearly',
					'lifetime' => 'Lifetime',
				);
				$default_period = in_array( 'annual', $available_periods, true ) ? 'annual' : (string) ( $available_periods[0] ?? 'annual' );
				?>
				<div class="mt-6 flex justify-center px-4 lg:mt-8 lg:px-0">
					<fieldset aria-label="Billing period" class="gbt-period-switch m-0 max-w-full border-0 p-0">
						<div class="inline-flex max-w-full items-stretch rounded-full p-1.5 text-center text-sm font-semibold text-gray-600 select-none">
							<?php foreach ( $available_periods as $freq ) : ?>
								<label class="relative inline-flex items-center justify-center rounded-full px-5 py-3 has-checked:text-white cursor-pointer lg:px-6">
									<input type="radio" name="frequency" value="<?php echo esc_attr( $freq ); ?>"<?php echo ( $freq === $default_period ) ? ' checked' : ''; ?> />
									<span><?php echo esc_html( $period_labels[ $freq ] ?? ucfirst( $freq ) ); ?></span>
								</label>
							<?php endforeach; ?>
						</div>
					</fieldset>
				</div>
			<?php endif; ?>

			<?php
			$grid_mt    = ( $show_period_toggle || $badge_state['show'] ) ? 'mt-6 lg:mt-14' : 'mt-8 lg:mt-16';
			$grid_class = 'mx-auto ' . $grid_mt . ' grid w-full max-w-lg grid-cols-1 items-stretch gap-y-6 pt-6 sm:gap-y-0 lg:max-w-7xl lg:pt-12 lg:pb-6';
			if ( $use_trio_layout ) {
				$grid_class .= ' lg:grid-cols-3';
			} elseif ( 2 === $plan_count ) {
				$grid_class .= ' lg:grid-cols-2 lg:gap-x-6';
			} elseif ( $plan_count > 3 ) {
				$grid_class .= ' lg:grid-cols-3 lg:gap-x-6';
			}
			?>
			<div class="<?php echo esc_attr( $grid_class ); ?>">
				<?php
				foreach ( $plans as $i => $plan_card ) :
					$is_featured = ( $featured_idx === $i );
					$is_owned    = ! $tf_legacy_active && $manager->is_plan_card_owned( $plan_card );
					$periods     = gbt_pricing_plan_periods( $plan_card );
					$toggleable  = $show_period_toggle && count( $periods ) >= 2;
					$plan_title  = (string) $plan_card['title'];
					$cover_badge = gbt_pricing_tf_cover_badge( $plan_title, $tf_licenses );

					$card_badge = $cover_badge;
					if ( $is_featured && $card_badge === '' && $tf_licenses < 1 ) {
						$card_badge = 'Recommended';
					}

					$shell = '';
					if ( ! $is_featured ) {
						$shell = ( $use_trio_layout )
							? gbt_pricing_trio_light_shell( (int) $i )
							: 'group/card relative flex h-full flex-col rounded-3xl bg-white/60 p-8 ring-1 ring-gray-900/10 sm:p-10';
					}

					$card_cta_verb = $cta_verb;

					gbt_render_pricing_card(
						array(
							'is_featured'     => $is_featured,
							'use_trio_layout' => $use_trio_layout,
							'shell'           => $shell,
							'plan_card'       => $plan_card,
							'periods'         => $periods,
							'toggleable'      => $toggleable,
							'plan_meta'       => gbt_pricing_plan_meta( $plan_title ),
							'plan_title'      => $plan_title,
							'tf_credit_value' => $tf_credit_value,
							'is_owned'        => $is_owned,
							'has_checkout'    => gbt_pricing_plan_has_checkout( $periods ),
							'card_cta_verb'   => $card_cta_verb,
							'card_badge'      => $card_badge,
							'features'        => is_array( $plan_card['features'] ?? null ) ? $plan_card['features'] : array(),
						)
					);
				endforeach;
				?>
			</div>

			<?php gbt_pricing_cta_note( $show_period_toggle, gbt_pricing_cta_fallback_freq( $plans, $show_period_toggle ) ); ?>

			<div class="mx-auto mt-6 w-full max-w-4xl text-center">
				<?php if ( $has_tf_credit ) : ?>
					<?php if ( $show_period_toggle ) : ?>
						<div class="text-sm/6 text-gray-500" data-period="monthly">
							Your $<?php echo esc_html( (string) $tf_credit_value ); ?> Themeforest purchase credit applies to yearly plans — not monthly or lifetime.
						</div>
						<div class="text-sm/6 text-gray-500" data-period="annual">
							Your $<?php echo esc_html( (string) $tf_credit_value ); ?> Themeforest purchase credit is already applied to your first payment.
						</div>
						<div class="text-sm/6 text-gray-500" data-period="lifetime">
							Your $<?php echo esc_html( (string) $tf_credit_value ); ?> Themeforest purchase credit applies to yearly plans — not lifetime.
						</div>
					<?php else : ?>
						<?php if ( in_array( 'annual', $available_periods, true ) ) : ?>
							<div class="text-sm/6 text-gray-500">
								Your $<?php echo esc_html( (string) $tf_credit_value ); ?> Themeforest purchase credit is already applied to your first payment.
							</div>
						<?php else : ?>
							<div class="text-sm/6 text-gray-500">
								Your $<?php echo esc_html( (string) $tf_credit_value ); ?> Themeforest purchase credit applies to yearly plans only.
							</div>
						<?php endif; ?>
					<?php endif; ?>
				<?php endif; ?>
				<div class="text-sm/6 text-gray-500">
					Change plans anytime — you only pay the difference.
				</div>
			</div>

			<?php gbt_render_pricing_features_overview( $feature_groups, $theme_name ); ?>

			<?php if ( $tf_legacy_active ) : ?>
				<?php gbt_render_pricing_faq( $plans, $theme_name ); ?>
			<?php else : ?>
			<div class="mx-auto mt-14 w-full max-w-lg text-center sm:max-w-2xl">
				<div class="inline-flex items-center justify-center gap-2 text-sm font-semibold text-gray-900">
					<?php gbt_icon_e( 'check-badge', 'size-5 shrink-0 text-gbt-green', 'solid' ); ?>
					100% Money-Back Guarantee
				</div>
				<p class="mt-3 text-sm/6 text-pretty text-gray-600">
					You are fully protected by our 100% Money Back Guarantee. If during the next 14 days you experience an issue that makes the theme unusable and we are unable to resolve it, we'll happily consider offering a full refund of your money.
				</p>
				<div class="mx-auto mt-6 h-px w-24 bg-gray-900/10" aria-hidden="true"></div>
			</div>
			<?php endif; ?>

			<?php
			$gbt_payment_section = 'all';
			include $paths['path'] . '/dashboard/inc/pages/content/template-parts/payment-trust.php';
			?>
		</div>
		<?php endif; ?>
		</div>

		<?php
			},
			array( 'badges' => false )
		);
	}
}
