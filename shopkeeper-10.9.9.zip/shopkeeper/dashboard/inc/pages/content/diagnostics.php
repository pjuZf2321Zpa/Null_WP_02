<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'getbowtied_diagnostics_content' ) ) {
	/**
	 * Display system diagnostics content
	 */
	function getbowtied_diagnostics_content() {
		$setup            = GBT_Dashboard_Setup::init();
		$supports_license = $setup->supports_license();
		$theme_name       = $setup->get_theme_name();

		$is_active         = false;
		$license_status    = 'inactive';
		$license_info_data = array();

		if ( $supports_license && class_exists( 'GBT_License_Manager' ) ) {
			$license_manager   = GBT_License_Manager::get_instance();
			$is_active         = $license_manager->is_active();
			$license_status    = $is_active ? 'active' : 'inactive';
			$fs_display        = $license_manager->get_display_data();
			$license_info_data = array(
				'License Status'   => ucfirst( $license_status ),
				'Plan'             => $fs_display['plan'],
				'Account'          => $fs_display['buyer'],
				'Active until'     => $fs_display['expires'],
				'Updates unlocked' => $is_active ? 'Yes' : 'No',
			);
		}

		$server_name = isset( $_SERVER['SERVER_NAME'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_NAME'] ) ) : 'Not available';
		$server_addr = isset( $_SERVER['SERVER_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) ) : 'Not available';
		$remote_addr = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'Not available';

		$theme_data     = wp_get_theme();
		$parent_theme   = $theme_data->parent() ? $theme_data->parent()->get( 'Name' ) . ' (v' . $theme_data->parent()->get( 'Version' ) . ')' : 'None';
		$active_plugins = count( get_option( 'active_plugins' ) );

		$diagnostic_data = array(
			'Server Name ($_SERVER[\'SERVER_NAME\'])'    => $server_name,
			'Server Address ($_SERVER[\'SERVER_ADDR\'])' => $server_addr,
			'Remote Address ($_SERVER[\'REMOTE_ADDR\'])' => $remote_addr,
			'PHP Version'                                => phpversion(),
			'WordPress Version'                          => get_bloginfo( 'version' ),
			'OS/Platform'                                => php_uname(),
		);

		$additional_data = array(
			'Theme Name'             => $theme_data->get( 'Name' ),
			'Theme Version'          => $theme_data->get( 'Version' ),
			'Parent Theme'           => $parent_theme,
			'Active Plugins'         => $active_plugins,
			'WordPress Memory Limit' => WP_MEMORY_LIMIT,
			'WP_DEBUG'               => defined( 'WP_DEBUG' ) && WP_DEBUG ? 'Enabled' : 'Disabled',
			'WP Cron'                => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ? 'Disabled' : 'Enabled',
			'Site URL'               => get_site_url(),
			'Home URL'               => get_home_url(),
			'Multisite'              => is_multisite() ? 'Yes' : 'No',
			'Database Version'       => get_option( 'db_version' ),
		);

		gbt_render_dashboard_page(
			static function () use (
				$theme_name,
				$supports_license,
				$diagnostic_data,
				$additional_data,
				$is_active,
				$license_status,
				$license_info_data
			) {
				?>

		<div class="overflow-hidden py-24 sm:py-32">
			<div class="mx-auto max-w-7xl px-6 lg:px-8">
				<div class="mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 sm:gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-1">
					<div>
						<div class="lg:max-w-lg">
							<?php gbt_display_version_badge(); ?>
							<h2 class="mt-4 text-4xl font-semibold tracking-tight text-pretty text-gray-900 sm:text-5xl leading-14"><?php echo esc_html( $theme_name ); ?> System Diagnostics</h2>
							<p class="mt-6 text-lg leading-8 text-gray-600">
								<?php if ( $supports_license ) : ?>
									View detailed information about your server environment, WordPress configuration, and license status.
								<?php else : ?>
									View detailed information about your server environment and WordPress configuration.
								<?php endif; ?>
							</p>
						</div>
					</div>

					<div>
						<div class="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
							<div class="bg-gray-50 px-6 py-4 border-b border-gray-200">
								<h3 class="text-base font-semibold text-gray-900">Server Environment & Configuration</h3>
							</div>
							<div class="p-8">
								<div class="overflow-x-auto">
									<table class="w-full text-left border-collapse text-sm">
										<thead>
											<tr>
												<th class="py-3 px-4 bg-gray-50 font-medium text-gray-700 border-b">Parameter</th>
												<th class="py-3 px-4 bg-gray-50 font-medium text-gray-700 border-b">Value</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ( $diagnostic_data as $param => $value ) : ?>
												<tr class="border-b border-gray-100">
													<td class="py-3 px-4 font-medium text-gray-700"><?php echo esc_html( $param ); ?></td>
													<td class="py-3 px-4 text-gray-600 font-mono"><?php echo esc_html( $value ); ?></td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>

						<div class="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden mt-8">
							<div class="bg-gray-50 px-6 py-4 border-b border-gray-200">
								<h3 class="text-base font-semibold text-gray-900">Theme & WordPress Configuration</h3>
							</div>
							<div class="p-8">
								<div class="overflow-x-auto">
									<table class="w-full text-left border-collapse text-sm">
										<thead>
											<tr>
												<th class="py-3 px-4 bg-gray-50 font-medium text-gray-700 border-b">Parameter</th>
												<th class="py-3 px-4 bg-gray-50 font-medium text-gray-700 border-b">Value</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ( $additional_data as $param => $value ) : ?>
												<tr class="border-b border-gray-100">
													<td class="py-3 px-4 font-medium text-gray-700"><?php echo esc_html( $param ); ?></td>
													<td class="py-3 px-4 text-gray-600 font-mono"><?php echo esc_html( $value ); ?></td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>

						<?php if ( $supports_license ) : ?>
						<div class="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden mt-8">
							<div class="bg-gray-50 px-6 py-4 border-b border-gray-200">
								<h3 class="text-base font-semibold text-gray-900">License Configuration</h3>
							</div>
							<div class="p-8">
								<div class="mb-6 p-4 rounded-lg border <?php echo $is_active ? 'border-[var(--color-gbt-green)]/20 bg-[var(--color-gbt-green)]/10' : 'border-[var(--color-gbt-yellow)]/20 bg-[var(--color-gbt-yellow)]/10'; ?>">
									<div class="flex">
										<div class="ml-3">
											<h3 class="text-sm font-medium <?php echo $is_active ? 'text-[var(--color-gbt-green)]' : 'text-[var(--color-gbt-yellow)]'; ?>">
												License Status: <?php echo esc_html( ucfirst( $license_status ) ); ?>
											</h3>
											<div class="mt-2 text-sm <?php echo $is_active ? 'text-[var(--color-gbt-green)]' : 'text-[var(--color-gbt-yellow)]'; ?>">
												<p class="m-0 text-sm">
													<?php if ( $is_active ) : ?>
														License is active. Updates and support are unlocked.
													<?php else : ?>
														No active license found. Activate a license on the License page.
													<?php endif; ?>
												</p>
											</div>
										</div>
									</div>
								</div>

								<div class="overflow-x-auto">
									<table class="w-full text-left border-collapse text-sm">
										<thead>
											<tr>
												<th class="py-3 px-4 bg-gray-50 font-medium text-gray-700 border-b">License Parameter</th>
												<th class="py-3 px-4 bg-gray-50 font-medium text-gray-700 border-b">Value</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ( $license_info_data as $param => $value ) : ?>
												<tr class="border-b border-gray-100">
													<td class="py-3 px-4 font-medium text-gray-700"><?php echo esc_html( $param ); ?></td>
													<td class="py-3 px-4 text-gray-600 font-mono"><?php echo esc_html( $value ); ?></td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>

								<div class="mt-6">
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=getbowtied-license' ) ); ?>" class="inline-flex items-center justify-center rounded-lg px-5 py-3 text-sm font-medium text-white bg-gbt-blue hover:bg-gbt-blue/90 transition-colors no-underline shadow-sm">
										<?php echo $is_active ? 'Manage License' : 'Activate License'; ?>
									</a>
								</div>
							</div>
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>

		<?php
			}
		);
	}
}
