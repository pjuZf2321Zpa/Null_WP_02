<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'getbowtied_home_content' ) ) {
	function getbowtied_home_content() {
		gbt_render_dashboard_page(
			static function ( $setup, $paths ) {
				$theme_slug                 = $setup->get_theme_slug();
				$theme_name                 = $setup->get_theme_name();
				$theme_child_download_link  = $setup->get_theme_child_download_link();
				$auto_update_status         = $setup->get_theme_auto_update_status();
				$success_content            = $setup->get_auto_update_content( 'success' );
				$disabled_content           = $setup->get_auto_update_content( 'disabled' );
				$extensions_url             = $paths['url'] . '/dashboard/assets/img/extensions/';
				$extensions                 = array(
					array(
						'url'         => 'https://automattic.pxf.io/woocommerce-woopayments',
						'image'       => 'woopayments.webp',
						'title'       => 'WooPayments',
						'description' => 'Increase your revenue by offering all popular payment methods with no monthly fees or setup costs.',
					),
					array(
						'url'         => 'https://automattic.pxf.io/woocommerce-product-bundles',
						'image'       => 'product-bundles.webp',
						'title'       => 'Product Bundles',
						'description' => 'Boost your average order value by creating compelling product packages that encourage larger purchases.',
					),
					array(
						'url'         => 'https://automattic.pxf.io/woocommerce-shipment-tracking',
						'image'       => 'shipment-tracking.webp',
						'title'       => 'Shipment Tracking',
						'description' => 'Reduce support inquiries and enhance customer satisfaction by providing real-time delivery updates.',
					),
					array(
						'url'         => 'https://automattic.pxf.io/woocommerce-gift-cards',
						'image'       => 'gift-cards.webp',
						'title'       => 'Gift Cards',
						'description' => 'Generate additional revenue streams and attract new customers by offering flexible digital gift options.',
					),
				);
				?>
				<div class="overflow-hidden py-24 sm:py-32">
					<div class="mx-auto max-w-7xl px-6 lg:px-8">
						<div class="mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 sm:gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-2">
							<div class="lg:pr-8">
								<div class="lg:max-w-lg">
									<?php gbt_display_version_badge(); ?>
									<h2 class="mt-4 text-4xl font-semibold tracking-tight text-pretty text-gray-900 sm:text-5xl leading-14"><?php echo esc_html( $theme_name ); ?></h2>
									<dl class="mt-10 max-w-xl space-y-8 text-base/7 text-gray-600 lg:max-w-none">
										<?php if ( ! $auto_update_status['is_enabled'] ) : ?>
											<div class="relative pl-9 gbt-auto-update-section rounded-lg" data-success-title="<?php echo esc_attr( $success_content['title'] ); ?>" data-success-description="<?php echo esc_attr( $success_content['description'] ); ?>" data-success-icon-html="<?php echo esc_attr( gbt_icon( $success_content['icon'], 'gbt-auto-update-icon absolute top-1 left-1 size-5' ) ); ?>">
												<dt class="inline font-semibold">
													<?php gbt_icon_e( $disabled_content['icon'], 'gbt-auto-update-icon absolute top-1 left-1 size-5' ); ?>
													<span class="gbt-auto-update-title"><?php echo esc_html( $disabled_content['title'] ); ?></span>
												</dt>
												<dd class="gbt-auto-update-description inline"><?php echo esc_html( $disabled_content['description'] ); ?></dd>
												<dd class="mt-3"><?php
													echo $setup->get_auto_update_enable_button(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
												?></dd>
											</div>
										<?php else : ?>
											<div class="relative pl-9">
												<dt class="inline font-semibold text-gray-900">
													<?php gbt_icon_e( $success_content['icon'], 'absolute top-1 left-1 size-5' ); ?>
													<?php echo esc_html( $success_content['title'] ); ?>
												</dt>
												<dd class="inline"><?php echo esc_html( $success_content['description'] ); ?></dd>
											</div>
										<?php endif; ?>
										<div class="relative pl-9">
											<dt class="inline font-semibold">
												<?php gbt_icon_e( 'beaker', 'absolute top-1 left-1 size-5' ); ?>
												Want to customize files?
											</dt>
											<dd class="inline">Use the <a href="<?php echo esc_html( $theme_child_download_link ); ?>" class="underline">Child Theme</a> to safely customize your website's code without losing changes when the theme updates.</dd>
										</div>
										<div class="relative pl-9">
											<dt class="inline font-semibold">
												<?php gbt_icon_e( 'paint-brush', 'absolute top-1 left-1 size-5' ); ?>
												Personalize your website.
											</dt>
											<dd class="inline">Use the <a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="underline">Customizer</a> to effortlessly tailor your website's look and feel to match your unique brand. Your customizations will not be reset on theme updates.</dd>
										</div>
										<div class="relative pl-9">
											<dt class="inline font-semibold text-gray-900">
												<?php gbt_icon_e( 'question-mark-circle', 'absolute top-1 left-1 size-5' ); ?>
												Need Support?
											</dt>
											<dd class="inline">Our team is ready to <a href="<?php echo esc_url( admin_url( 'admin.php?page=getbowtied-help' ) ); ?>" class="underline">help you</a> overcome challenges and unlock your website's full potential.</dd>
										</div>
									</dl>
								</div>
							</div>
							<img src="<?php echo esc_url( $paths['url'] . '/dashboard/assets/img/theme/' . $theme_slug . '/screenshot.png' ); ?>" alt="<?php echo esc_attr( $theme_name ); ?> Screenshot" class="w-full h-auto object-cover rounded-xl shadow-xl ring-1 ring-gray-400/10 lg:w-full">
						</div>

						<hr class="mt-24 border-t border-gray-200" />

						<div class="mx-auto max-w-7xl mt-16">
							<div class="text-center mb-8">
								<h3 class="text-2xl font-semibold tracking-tight text-pretty text-gray-900 sm:text-3xl">Supercharge Your Online Sales with Essential Extensions</h3>
								<div class="mx-auto max-w-2xl">
									<p class="mt-4 text-base/7 text-gray-600">These powerful extensions will help you boost conversions, simplify checkout, and deliver a better customer experience.</p>
								</div>
							</div>

							<ul role="list" class="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
								<?php foreach ( $extensions as $extension ) : ?>
									<?php gbt_render_extension_card( $extensions_url, $extension ); ?>
								<?php endforeach; ?>
							</ul>

							<div class="mt-12 text-center">
								<a href="https://automattic.pxf.io/woocommerce-extensions" target="_blank" class="inline-flex items-center gap-x-2 rounded-md bg-[var(--color-gbt-blue)] px-3.5 py-2.5 text-sm font-semibold text-white shadow-xs hover:bg-[var(--color-gbt-blue-darker)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-gbt-blue)] transition-all duration-300 cursor-pointer">
									<?php gbt_icon_e( 'plus-circle', '-ml-0.5 size-5', 'solid', 20 ); ?>
									More Essential Extensions
								</a>
							</div>
						</div>
					</div>
				</div>
				<?php
			}
		);
	}
}
