<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'getbowtied_templates_content' ) ) {
	function getbowtied_templates_content() {
		gbt_render_dashboard_page(
			static function ( $setup ) {
				$theme_name = $setup->get_theme_name();
				?>
				<div class="overflow-hidden py-24 sm:py-32">
					<div class="mx-auto max-w-7xl px-6 lg:px-8">
						<div class="mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 sm:gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-1">
							<div>
								<div class="lg:max-w-lg">
									<?php gbt_display_version_badge(); ?>
									<h2 class="mt-4 text-4xl font-semibold tracking-tight text-pretty text-gray-900 sm:text-5xl leading-14"><?php echo esc_html( $theme_name ); ?> Templates</h2>
									<p class="mt-6 text-lg leading-8 text-gray-600">
										Install the <span class="font-semibold text-gray-700">"Kits, Templates and Patterns"</span> plugin and give our Starter Templates a try!
										They'll help you launch your project faster.
									</p>
									<p class="mt-4 text-lg leading-8 text-gray-600">
										These templates are built with Elementor, and you will have access to all the widgets in Elementor PRO without a subscription.
									</p>

									<div class="mt-8">
										<a href="<?php echo esc_url( admin_url( 'admin.php?page=getbowtied-plugins' ) ); ?>"
											class="inline-flex items-center rounded-md px-3.5 py-2 text-sm font-medium text-white bg-gbt-blue hover:bg-gbt-blue/90 transition-colors no-underline">
											<?php gbt_icon_e( 'arrow-down-tray', 'size-4 mr-2' ); ?>
											Get "Kits, Templates and Patterns" plugin
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php
			}
		);
	}
}
