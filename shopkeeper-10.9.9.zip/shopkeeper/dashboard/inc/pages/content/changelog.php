<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'getbowtied_changelog_content' ) ) {
	function getbowtied_changelog_content() {
		gbt_render_dashboard_page(
			static function ( $setup ) {
				$theme_url_changelog = $setup->get_theme_url_changelog();
				?>
				<iframe id="getbowtied_dashboard_iframe" src="<?php echo esc_url( $theme_url_changelog ); ?>"></iframe>
				<?php
			},
			array( 'badges' => false )
		);
	}
}
