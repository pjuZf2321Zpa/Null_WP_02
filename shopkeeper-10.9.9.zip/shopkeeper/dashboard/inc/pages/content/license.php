<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'getbowtied_license_content' ) ) {
	/**
	 * License page - Freemius activation, status, and ThemeForest migration.
	 */
	function getbowtied_license_content() {
		$setup      = GBT_Dashboard_Setup::init();
		$theme_name = $setup->get_theme_name();
		$manager    = GBT_License_Manager::get_instance();

		$licensed          = $manager->is_active();
		$has_license       = $manager->has_license();
		$expired           = $manager->is_expired();
		$legacy_key        = $manager->get_legacy_purchase_code();
		$has_legacy        = $legacy_key !== '';
		$show_tf_migration = ! $manager->has_seen_freemius_license() && $has_legacy;
		$support_url       = (string) $setup->get_theme_url_support();
		$current_user      = wp_get_current_user();
		$default_email     = ( $current_user && ! empty( $current_user->user_email ) ) ? (string) $current_user->user_email : '';

		$error                 = '';
		$error_detail          = '';
		$portal_url            = '';
		$posted                = '';
		$show_tf_email_overlay = false;

		$flash     = gbt_license_flash_messages( $manager );
		$purchased = $flash['purchased'];
		$celebrate = $flash['celebrate'];
		$migrated  = $flash['migrated'];
		$synced    = $flash['synced'];

		$post_result = GBT_License_Manager::get_license_post_result();
		if ( is_array( $post_result ) ) {
			$posted                = $post_result['posted'];
			$error                 = $post_result['error'];
			$error_detail          = $post_result['error_detail'];
			$portal_url            = $post_result['portal_url'];
			$show_tf_email_overlay = $post_result['show_tf_email_overlay'];
		}

		$state = ( $licensed || $has_license ) ? 'freemius' : 'activate';

		$fs            = $manager->get_display_data();
		$intro         = gbt_license_intro_text( $licensed, $expired, (string) ( $fs['plan'] ?? '' ) );
		$buy_url       = $fs['pricing_url'] !== '' ? $fs['pricing_url'] : (string) $setup->get_theme_config( 'theme_infos_url' );
		$help_url      = $support_url !== '' ? $support_url : (string) $setup->get_theme_config( 'theme_infos_url' );
		$plans         = $manager->get_available_plans();
		$pricing_url   = GBT_License_Manager::pricing_page_url();
		$plans_cta_url = ! empty( $plans ) ? $pricing_url : ( $buy_url !== '' ? $buy_url : '' );
		$premium_features = $manager->get_premium_features();
		$legacy_display   = gbt_mask_purchase_code( $legacy_key );
		$theme_version    = (string) $setup->get_theme_version();

		$parts = $setup->get_base_paths()['path'] . '/dashboard/inc/pages/content/template-parts/';

		gbt_render_dashboard_page(
			static function ( $setup, $paths ) use (
				$state,
				$show_tf_migration,
				$show_tf_email_overlay,
				$legacy_key,
				$legacy_display,
				$default_email,
				$plans_cta_url,
				$help_url,
				$fs,
				$expired,
				$licensed,
				$plans,
				$purchased,
				$celebrate,
				$migrated,
				$synced,
				$intro,
				$posted,
				$error,
				$error_detail,
				$portal_url,
				$premium_features,
				$theme_name,
				$theme_version,
				$parts
			) {
				?>

		<div
			id="gbt-license-root"
			class="flex min-h-[calc(100dvh-6rem)] min-w-0 flex-col overflow-x-hidden px-4 py-6 sm:px-6 sm:py-8"
			data-overlays="<?php echo ( 'activate' === $state && $show_tf_migration ) ? '1' : '0'; ?>"
			data-key-reveal="<?php echo ( 'freemius' === $state && ! empty( $fs['key_full'] ) ) ? '1' : '0'; ?>"
			data-confetti="<?php echo ( ( $purchased || $celebrate || $migrated ) && $licensed ) ? '1' : '0'; ?>"
		>
			<div class="mx-auto my-auto w-full min-w-0 max-w-3xl lg:max-w-[90rem]">
				<div class="relative mx-auto w-full min-w-0 max-w-3xl overflow-hidden rounded-3xl bg-[var(--color-gbt-gray-dark)] shadow-2xl ring-1 ring-[var(--color-gbt-gray-dark)]/20 lg:mx-0 lg:flex lg:max-w-none">
					<div class="absolute inset-0 z-0 gbt-dark-card-bg-radial"></div>
					<div class="absolute inset-0 z-0 pointer-events-none gbt-dark-card-bg-texture"></div>

					<?php include $parts . 'license-main.php'; ?>
					<?php include $parts . 'license-side.php'; ?>

					<?php if ( 'activate' === $state && $show_tf_migration ) : ?>
						<?php include $parts . 'license-overlays.php'; ?>
					<?php endif; ?>
				</div>

				<?php gbt_render_license_trust_footer( $theme_name, $theme_version, $licensed, $expired, $show_tf_migration ); ?>
			</div>
		</div>

		<?php if ( 'activate' === $state && $show_tf_migration ) : ?>
			<?php include $parts . 'license-confirm-modal.php'; ?>
		<?php endif; ?>

		<?php
			},
			array( 'badges' => true )
		);
	}
}
