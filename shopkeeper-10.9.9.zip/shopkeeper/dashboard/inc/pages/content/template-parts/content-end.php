<?php
// Template part: closing markup for GBT Dashboard content.
?>
</div><!-- GBT Dashboard Scoped Content -->
