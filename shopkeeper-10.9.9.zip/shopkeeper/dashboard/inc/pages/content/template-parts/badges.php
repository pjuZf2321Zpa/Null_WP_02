<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! function_exists( 'gbt_display_version_badge' ) ) {
	/**
	 * Display version badge with update status.
	 * Always mirrors WordPress update_themes (same source as Dashboard → Updates).
	 * Unlicensed CTAs still point at license/pricing; JSON feeds that transient via GBT_Theme_Update_Notice.
	 */
	function gbt_display_version_badge() {
		?>
		<style>
			@keyframes coin-flip {
				0% { transform: rotateY(0deg); }
				20% { transform: rotateY(360deg); }
				100% { transform: rotateY(360deg); }
			}
		</style>
		<?php
		$setup         = GBT_Dashboard_Setup::init();
		$theme_version = $setup->get_theme_version();
		$theme_slug    = $setup->get_theme_slug();
		$changelog_url = $setup->get_theme_url_changelog();
		$licensed      = true;

		$expired = false;
		if ( $setup->supports_license() && class_exists( 'GBT_License_Manager' ) ) {
			$license_manager = GBT_License_Manager::get_instance();
			$licensed        = $license_manager->is_active();
			$expired         = $license_manager->is_expired();
		}

		$update_available = false;
		$update_version   = '';
		$update_url       = admin_url( 'update-core.php#update-themes-table' );

		// Same filtered transient WP Updates uses (includes Freemius + blocked unlicensed inject).
		$updates = get_site_transient( 'update_themes' );
		if ( $updates && isset( $updates->response[ $theme_slug ] ) ) {
			$update_available = true;
			$update_version   = isset( $updates->response[ $theme_slug ]['new_version'] )
				? (string) $updates->response[ $theme_slug ]['new_version']
				: '';

			if ( ! $licensed && class_exists( 'GBT_License_Manager' ) ) {
				$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				// Already on the license screen — send them to Updates instead of a self-link.
				if ( 'getbowtied-license' !== $page ) {
					$update_url = $expired
						? GBT_License_Manager::pricing_page_url()
						: GBT_License_Manager::license_page_url();
				}
			}
		}

		if ( $expired ) {
			$badge_class = 'bg-[var(--color-gbt-red)]';
			$status_text = 'Renew license for updates';
		} elseif ( ! $licensed ) {
			$badge_class = 'bg-[var(--color-gbt-red)]';
			$status_text = $update_available ? 'Outdated' : 'Activate license for updates';
		} elseif ( $update_available ) {
			$badge_class = 'bg-[var(--color-gbt-red)]';
			$status_text = 'Outdated';
		} else {
			$badge_class = 'bg-[var(--color-gbt-green)]';
			$status_text = "You're up to date";
		}

		// Shared pill chrome — keep padding, type, and icon gap identical across badges.
		$pill  = 'inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-medium !text-white shadow-sm no-underline';
		$label = 'uppercase tracking-wide text-[10px] leading-none !text-white';
		$icon  = 'size-4 shrink-0 !text-white';
		?>
		<div class="mt-4 mb-2 flex flex-wrap items-center gap-3">
			<span class="<?php echo esc_attr( $pill . ' ' . $badge_class ); ?>" aria-label="Theme version">
				<?php if ( $expired || ( ! $licensed && ! $update_available ) ) : ?>
					<?php gbt_icon_e( 'lock-closed', $icon ); ?>
				<?php elseif ( $update_available ) : ?>
					<?php gbt_icon_e( 'exclamation-circle', $icon, 'solid', 20 ); ?>
				<?php else : ?>
					<?php gbt_icon_e( 'check-badge', $icon, 'solid' ); ?>
				<?php endif; ?>
				<span class="<?php echo esc_attr( $label ); ?>">VERSION <?php echo esc_html( $theme_version ); ?></span>
				<span class="hidden sm:inline-block h-3 w-px shrink-0 bg-white/80" aria-hidden="true"></span>
				<span class="hidden sm:inline <?php echo esc_attr( $label ); ?> font-semibold">
					<?php echo esc_html( $status_text ); ?>
				</span>
			</span>

			<?php if ( $update_available ) : ?>
				<?php
				$version_part = ! empty( $update_version ) ? $update_version : 'latest';
				$status_cta   = $licensed ? 'Update' : ( $expired ? 'Renew license' : 'Activate license' );
				$update_label = 'VERSION ' . $version_part . ' | ' . $status_cta;
				?>
				<a href="<?php echo esc_url( $update_url ); ?>" class="<?php echo esc_attr( $pill ); ?> bg-[var(--color-gbt-yellow)] transition animate-pulse" role="button" aria-label="<?php echo esc_attr( $update_label ); ?>">
					<?php gbt_icon_e( 'arrow-down', $icon . ' [transform-style:preserve-3d] [animation:coin-flip_4s_ease-in-out_infinite]', 'solid', 20 ); ?>
					<span class="<?php echo esc_attr( $label ); ?>">VERSION <?php echo esc_html( $version_part ); ?></span>
					<span class="hidden sm:inline-block h-3 w-px shrink-0 bg-white/80" aria-hidden="true"></span>
					<span class="hidden sm:inline <?php echo esc_attr( $label ); ?> font-semibold"><?php echo esc_html( $status_cta ); ?></span>
				</a>
			<?php endif; ?>

			<a href="<?php echo esc_url( $changelog_url ); ?>" target="_blank" rel="noopener noreferrer" class="<?php echo esc_attr( $pill ); ?> bg-[var(--color-gbt-gray-lighter)]" role="button" aria-label="View changelog">
				<?php gbt_icon_e( 'document-text', $icon, 'solid', 20 ); ?>
				<span class="<?php echo esc_attr( $label ); ?>">CHANGELOG</span>
			</a>
		</div>
		<?php
	}
}
