<!-- GBT Dashboard Scoped Content -->
<div class="gbt-dashboard-scope">

	<?php
	$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$hide_license_banner = in_array( $page, array( 'getbowtied-license', 'getbowtied-pricing' ), true );

	if ( ! $hide_license_banner && GBT_Dashboard_Setup::init()->supports_license() ) {
		$banner_path = dirname( __FILE__ ) . '/license-status-banner.php';
		if ( file_exists( $banner_path ) ) {
			include $banner_path;
		}
	}
	?>
