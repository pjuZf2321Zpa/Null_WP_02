<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div id="gbt-confirm-email-modal" class="fixed inset-0 z-[100001] hidden" role="dialog" aria-modal="true" aria-labelledby="gbt-confirm-email-modal-title" aria-hidden="true">
	<div class="absolute inset-0 bg-black/60" data-gbt-confirm-email-close tabindex="-1"></div>
	<div class="relative mx-auto flex min-h-full items-center justify-center p-4 sm:p-6">
		<div class="relative w-full max-w-md rounded-2xl bg-[var(--color-gbt-gray-dark)] ring-1 ring-[var(--color-gbt-gray-lighter)] shadow-2xl overflow-hidden">
			<div class="absolute inset-0 pointer-events-none gbt-dark-card-bg-radial"></div>
			<div class="relative p-6 sm:p-8">
				<div class="flex items-start justify-between gap-4">
					<div>
						<span class="inline-flex items-center rounded bg-[var(--color-gbt-yellow)]/15 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[var(--color-gbt-yellow)] ring-1 ring-inset ring-[var(--color-gbt-yellow)]/25">Confirm email</span>
						<h2 id="gbt-confirm-email-modal-title" class="mt-2 text-xl font-semibold tracking-tight text-white">Double-check your email</h2>
					</div>
					<button type="button" class="shrink-0 inline-flex items-center justify-center rounded-md text-gray-400 hover:text-white hover:bg-[var(--color-gbt-gray-light)] transition duration-150 ease-in-out cursor-pointer border-0 bg-transparent p-1.5" data-gbt-confirm-email-close aria-label="Close">
						<?php gbt_icon_e( 'x-mark', 'size-5', 'solid', 20 ); ?>
					</button>
				</div>

				<p class="mt-4 text-sm leading-6 text-gray-300">
					Your license key and account details will be sent to this address. Make sure you can access it.
				</p>
				<p id="gbt-confirm-email-value" class="mt-4 break-all rounded-md bg-[var(--color-gbt-gray-light)] px-4 py-5 text-center text-base sm:text-lg font-semibold leading-snug tracking-tight text-white"></p>

				<div class="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
					<button type="button" id="gbt-confirm-email-edit" class="inline-flex items-center justify-center rounded-md bg-transparent px-4 py-2.5 text-sm font-medium text-gray-300 ring-1 ring-inset ring-[var(--color-gbt-gray-lighter)] hover:bg-[var(--color-gbt-gray-light)] hover:text-white transition duration-150 ease-in-out cursor-pointer border-0" data-gbt-confirm-email-close>Edit email</button>
					<button type="button" id="gbt-confirm-email-submit" class="inline-flex items-center justify-center gap-2 rounded-md bg-gbt-blue px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-gbt-blue/90 transition duration-150 ease-in-out cursor-pointer border-0">
						<?php gbt_icon_e( 'arrows-right-left', 'size-5' ); ?>
						Yes, convert &amp; activate
					</button>
				</div>
			</div>
		</div>
	</div>
</div>
