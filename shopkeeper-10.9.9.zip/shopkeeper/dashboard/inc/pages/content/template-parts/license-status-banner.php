<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Compact license banner for dashboard pages (missing, expired, or legacy no-plan).
 */
$setup   = GBT_Dashboard_Setup::init();
$manager = GBT_License_Manager::get_instance();
$legacy  = function_exists( 'gbt_legacy_plan_notice_copy' ) ? gbt_legacy_plan_notice_copy() : null;

if ( $manager->is_active() && ! is_array( $legacy ) ) {
	return;
}

$expired     = $manager->is_expired();
$theme_name  = $setup->get_theme_name();
$license_url = GBT_License_Manager::license_page_url();
$show_tf     = ! $expired && ! $manager->has_seen_freemius_license();
$has_legacy  = $show_tf && $manager->get_legacy_purchase_code() !== '';
$cta_url     = $license_url;
$tf_copy     = ( $has_legacy && function_exists( 'gbt_tf_convert_deadline_copy' ) )
	? gbt_tf_convert_deadline_copy( (string) $theme_name )
	: null;

$is_legacy_notice = is_array( $legacy );
$tone_red         = ! $is_legacy_notice || ( ( $legacy['variant'] ?? '' ) === 'red' );
$border           = $tone_red ? 'border-[var(--color-gbt-red)] border-l-[var(--color-gbt-red)]' : 'border-[var(--color-gbt-yellow)] border-l-[var(--color-gbt-yellow)]';
$icon_wrap        = $tone_red ? 'bg-[var(--color-gbt-red)]/10' : 'bg-[var(--color-gbt-yellow)]/10';
$icon_color       = $tone_red ? 'text-[var(--color-gbt-red)]' : 'text-[#8a6116]';
$badge_wrap       = $tone_red
	? 'bg-[var(--color-gbt-red)]/10 text-[var(--color-gbt-red)] ring-[var(--color-gbt-red)]/20'
	: 'bg-[var(--color-gbt-yellow)]/10 text-[#8a6116] ring-[var(--color-gbt-yellow)]/20';
?>
<div class="relative overflow-hidden bg-white border border-l-4 <?php echo esc_attr( $border ); ?> shadow-sm m-6 px-6 py-5 lg:m-8">
	<div class="flex items-start gap-4">
		<div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full <?php echo esc_attr( $icon_wrap ); ?>">
			<?php gbt_icon_e( 'exclamation-triangle', 'size-5 ' . $icon_color ); ?>
		</div>
		<div class="min-w-0 flex-1">
			<div class="mb-1 flex flex-wrap items-center gap-2">
				<span class="inline-flex items-center rounded-md px-2 py-0.5 text-xs font-semibold ring-1 ring-inset <?php echo esc_attr( $badge_wrap ); ?>">
					<?php
					if ( $is_legacy_notice ) {
						echo esc_html( $legacy['badge'] );
					} else {
						echo esc_html( $expired ? 'Expired License' : 'No License' );
					}
					?>
				</span>
				<span class="text-sm text-gray-500"><?php echo esc_html( $theme_name ); ?> v<?php echo esc_html( $setup->get_theme_version() ); ?></span>
			</div>
			<h3 class="text-lg font-semibold text-gray-900 mb-1"><?php
			if ( $is_legacy_notice ) {
				echo esc_html( $legacy['title'] );
			} elseif ( $expired ) {
				echo esc_html( sprintf( '%s license expired', $theme_name ) );
			} elseif ( is_array( $tf_copy ) ) {
				echo esc_html( $tf_copy['side_title'] );
			} else {
				echo esc_html( sprintf( 'Activate your %s license', $theme_name ) );
			}
			?></h3>
			<p class="text-sm text-gray-600 mb-3"><?php
			if ( $is_legacy_notice ) {
				echo esc_html( $legacy['body'] );
			} elseif ( $expired ) {
				echo 'Renew to restore updates, support, and full plan access.';
			} elseif ( is_array( $tf_copy ) ) {
				echo esc_html( $tf_copy['side_body'] );
			} else {
				echo 'Unlock updates and support by activating your license key.';
			}
			?></p>
			<a href="<?php echo esc_url( $is_legacy_notice ? $legacy['cta_url'] : $cta_url ); ?>" class="inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold no-underline transition-colors <?php echo esc_attr( $tone_red ? 'bg-[var(--color-gbt-red)] text-white hover:bg-[var(--color-gbt-red)]/90' : 'bg-[var(--color-gbt-yellow)] text-gray-900 hover:bg-[var(--color-gbt-yellow)]/90' ); ?>">
				<?php gbt_icon_e( 'key', 'size-4 shrink-0' ); ?>
				<?php
				if ( $is_legacy_notice ) {
					echo esc_html( $legacy['cta'] );
				} elseif ( $expired ) {
					echo 'Manage license';
				} elseif ( is_array( $tf_copy ) ) {
					echo 'Convert &amp; activate';
				} else {
					echo 'Activate License';
				}
				?>
			</a>
		</div>
	</div>
</div>
