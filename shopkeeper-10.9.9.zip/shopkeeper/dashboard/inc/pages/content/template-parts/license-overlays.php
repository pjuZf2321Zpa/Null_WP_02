<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Themeforest migration overlays (email, why, how-to).
 *
 * @var bool   $show_tf_email_overlay
 * @var string $legacy_display
 * @var string $default_email
 * @var string $theme_name
 * @var array  $premium_features
 */
$tf_converter  = GBT_License_Converter::get_instance();
$tf_bought_on  = $tf_converter->get_themeforest_purchase_date_display();
$tf_howto_date = $tf_bought_on;
$tf_deadline   = gbt_tf_convert_deadline_copy( (string) $theme_name );
?>
<div id="gbt-tf-email-overlay" class="relative z-10 w-full flex-col<?php echo $show_tf_email_overlay ? ' flex' : ' hidden'; ?>" role="dialog" aria-modal="true" aria-labelledby="gbt-tf-email-overlay-title" aria-hidden="<?php echo $show_tf_email_overlay ? 'false' : 'true'; ?>" data-gbt-convert-base>
	<div class="relative z-10 flex flex-col items-center justify-center px-6 py-12 sm:px-10 sm:py-16 lg:px-12">
		<?php gbt_render_license_overlay_close( 'data-gbt-email-close' ); ?>
		<div class="w-full max-w-md flex flex-col gap-6">
			<div class="text-center">
				<h2 id="gbt-tf-email-overlay-title" class="text-xl sm:text-2xl font-semibold tracking-tight text-white">Convert your Themeforest purchase code</h2>
				<p class="mt-2 text-sm leading-6 text-gray-400">Your purchase code becomes a license key on our new platform. Nothing on your site changes.</p>
				<div class="mt-6 rounded-lg bg-[var(--color-gbt-gray-light)] px-4 py-3.5 text-center ring-1 ring-inset ring-white/5">
					<span class="block text-[10px] font-semibold uppercase tracking-wide text-gray-400">Your Themeforest purchase code</span>
					<p class="mt-2 font-mono text-sm tracking-wider leading-5 text-[var(--color-gbt-green)] break-all"><?php echo esc_html( $legacy_display ); ?></p>
				</div>
			</div>

			<div class="flex flex-col gap-6 text-left">
				<div>
					<label for="gbt_tf_overlay_email" class="block text-sm font-medium text-white mb-2">Where should we email your license details?</label>
					<input type="email" id="gbt_tf_overlay_email" name="gbt_tf_overlay_email" value="<?php echo esc_attr( $default_email ); ?>" placeholder="Your email" autocomplete="email" required aria-required="true" class="block w-full px-4 py-2.5 text-sm text-white bg-[var(--color-gbt-gray-light)] border border-[var(--color-gbt-gray-lighter)] rounded-md focus:outline-none focus:ring-1 focus:ring-gbt-blue focus:border-gbt-blue placeholder:text-gray-500" />
					<p class="mt-2 text-sm leading-6 text-gray-400">Use an address you can access. The license key is sent here.</p>
				</div>

				<div id="gbt-tf-overlay-error" class="hidden rounded-md bg-[var(--color-gbt-red)]/10 border border-[var(--color-gbt-red)]/20 px-4 py-3 text-sm text-[var(--color-gbt-red)]"></div>

				<button type="button" id="gbt-tf-overlay-submit" class="inline-flex w-full h-11 items-center justify-center gap-2 rounded-md bg-[var(--color-gbt-blue)] px-6 text-sm font-medium leading-none text-white shadow-none hover:bg-[var(--color-gbt-blue-darker)] transition duration-150 ease-in-out cursor-pointer border-0">
					<?php gbt_icon_e( 'arrows-right-left', 'size-5 shrink-0' ); ?>
					Convert &amp; activate
				</button>
			</div>
		</div>
	</div>
</div>

<div id="gbt-conversion-why-overlay" class="relative z-10 w-full flex-col hidden" role="region" aria-labelledby="gbt-conversion-why-title" aria-hidden="true">
	<div class="relative z-10 flex flex-col px-6 py-10 sm:px-10 sm:py-12">
		<?php gbt_render_license_overlay_close(); ?>

		<div class="mx-auto flex w-full max-w-4xl flex-col gap-6">
			<div class="text-center pr-8">
				<span class="inline-flex items-center rounded bg-[var(--color-gbt-yellow)]/15 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[var(--color-gbt-yellow)] ring-1 ring-inset ring-[var(--color-gbt-yellow)]/25">Why convert?</span>
				<h2 id="gbt-conversion-why-title" class="mx-auto mt-2 max-w-2xl text-xl sm:text-2xl font-semibold tracking-tight text-white text-balance">
					<?php echo esc_html( $tf_deadline['why_title_line1'] ); ?><br>
					<?php echo esc_html( $tf_deadline['why_title_line2'] ); ?>
				</h2>
				<p class="mx-auto mt-2 max-w-2xl text-sm leading-6 text-gray-400 text-pretty"><?php echo esc_html( $tf_deadline['why_body'] ); ?></p>
			</div>

			<div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
				<section class="flex h-full min-w-0 flex-col overflow-hidden rounded-2xl bg-[var(--color-gbt-gray-light)]/80 ring-1 ring-inset ring-white/5" aria-labelledby="gbt-why-story-heading">
					<div class="flex h-11 shrink-0 items-center border-b border-white/5 px-4">
						<h3 id="gbt-why-story-heading" class="text-sm font-semibold text-white">What&rsquo;s happening</h3>
					</div>
					<div class="flex flex-1 flex-col divide-y divide-white/5">
						<?php
						$step1 = $tf_bought_on !== '' ? 'You bought from Themeforest on ' . $tf_bought_on : 'You bought from Themeforest';
						gbt_render_license_overlay_step( 1, $step1, 'Still recognized, with purchase details carried over.' );
						gbt_render_license_overlay_step( 2, $tf_deadline['why_step2_title'], $tf_deadline['why_step2_desc'] );
						gbt_render_license_overlay_step( 3, 'Your purchase code becomes a license key', 'Conversion connects this site to our new platform.' );
						?>
					</div>
				</section>

				<section class="flex h-full min-w-0 flex-col overflow-hidden rounded-2xl bg-[var(--color-gbt-gray-light)]/80 ring-1 ring-inset ring-white/5" aria-labelledby="gbt-why-next-heading">
					<div class="flex h-11 shrink-0 items-center border-b border-white/5 px-4">
						<h3 id="gbt-why-next-heading" class="text-sm font-semibold text-white">Your next move</h3>
					</div>
					<div class="flex flex-1 flex-col divide-y divide-white/5">
						<?php
						gbt_render_license_overlay_step( 1, 'Confirm your code', 'The Themeforest purchase code shown on this page.', 'blue' );
						gbt_render_license_overlay_step( 2, 'Enter your email', 'We email your license details there.', 'blue' );
						gbt_render_license_overlay_step( 3, 'Convert & activate', 'Conversion turns the purchase code into a license key and connects this site.', 'blue' );
						?>
					</div>
				</section>
			</div>

			<div class="flex flex-col items-center gap-6">
				<div class="flex w-full max-w-xl items-start justify-center gap-3 text-left">
					<span class="mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full bg-[var(--color-gbt-blue)]/15 text-[var(--color-gbt-blue-lighter)] ring-1 ring-inset ring-[var(--color-gbt-blue)]/30" aria-hidden="true">
						<?php gbt_icon_e( 'exclamation-circle', 'size-3.5', 'solid', 20 ); ?>
					</span>
					<p class="m-0 text-sm leading-6 text-gray-300">
						<strong class="font-semibold text-white">Quick note:</strong>
						Conversion connects this site to our new platform. Updates and support activate when conversion is complete.
					</p>
				</div>
				<button type="button" class="font-semibold text-[var(--color-gbt-blue-lighter)] hover:text-white transition duration-150 ease-in-out cursor-pointer border-0 bg-transparent p-0 text-sm leading-6 tracking-tight" data-gbt-howto-open aria-controls="gbt-conversion-howto-overlay" aria-expanded="false">How conversion works</button>
				<button type="button" class="inline-flex h-11 w-full max-w-md items-center justify-center gap-2 rounded-md bg-[var(--color-gbt-blue)] px-10 text-sm font-medium leading-none text-white shadow-none hover:bg-[var(--color-gbt-blue-darker)] transition duration-150 ease-in-out cursor-pointer border-0" data-gbt-back-to-convert>
					Back to convert
				</button>
			</div>
		</div>
	</div>
</div>

<div id="gbt-conversion-howto-overlay" class="relative z-10 w-full flex-col hidden" role="region" aria-labelledby="gbt-conversion-howto-title" aria-hidden="true">
	<div class="relative z-10 flex flex-col px-6 py-10 sm:px-10 sm:py-12">
		<?php gbt_render_license_overlay_close(); ?>

		<div class="mx-auto flex w-full max-w-4xl flex-col gap-6">
			<div class="text-center pr-8">
				<span class="inline-flex items-center rounded bg-[var(--color-gbt-blue)]/15 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[var(--color-gbt-blue-lighter)] ring-1 ring-inset ring-[var(--color-gbt-blue)]/25">How conversion works</span>
				<h2 id="gbt-conversion-howto-title" class="mt-2 text-xl sm:text-2xl font-semibold tracking-tight text-white"><?php echo esc_html( $tf_deadline['howto_title'] ); ?></h2>
				<p class="mx-auto mt-2 max-w-xl text-sm leading-6 text-gray-400"><?php echo esc_html( $tf_deadline['howto_body'] ); ?> Current benefits stay included, along with the new ones below.</p>
			</div>

			<div class="grid grid-cols-1 gap-6 lg:grid-cols-2<?php echo empty( $premium_features ) ? ' max-w-md mx-auto' : ''; ?>">
				<section class="flex h-full min-w-0 flex-col overflow-hidden rounded-2xl bg-[var(--color-gbt-gray-light)]/80 ring-1 ring-inset ring-white/5" aria-labelledby="gbt-howto-keep-heading">
					<div class="flex h-11 shrink-0 items-center border-b border-white/5 px-4">
						<h3 id="gbt-howto-keep-heading" class="text-sm font-semibold text-white">You still get</h3>
					</div>
					<div class="flex flex-1 flex-col divide-y divide-white/5">
						<?php
						$keep_title = 'Your Themeforest purchase' . ( $tf_howto_date !== '' ? ' from ' . $tf_howto_date : '' );
						gbt_render_license_check_step( $keep_title, 'Still recognized, with purchase details carried over' );
						gbt_render_license_check_step( 'Updates & support', $tf_deadline['howto_updates_desc'] );
						gbt_render_license_check_step( 'If support already ended', 'At least 14 days of coverage. Renew anytime.' );
						gbt_render_license_check_step( 'This site connected', 'Activated on our new platform' );
						?>
					</div>
				</section>

				<?php if ( ! empty( $premium_features ) ) : ?>
				<section class="flex h-full min-w-0 flex-col overflow-visible rounded-2xl bg-[var(--color-gbt-gray-light)]/80 ring-1 ring-inset ring-white/5" aria-labelledby="gbt-howto-new-heading">
					<div class="flex h-11 shrink-0 items-center border-b border-white/5 px-4">
						<h3 id="gbt-howto-new-heading" class="text-sm font-semibold text-white">Plus you unlock</h3>
					</div>
					<ul role="list" class="m-0 flex-1 list-none space-y-3 overflow-visible px-4 py-3 text-sm/6 text-white">
						<?php foreach ( $premium_features as $feature_item ) : ?>
							<?php gbt_render_pricing_feature_item( $feature_item ); ?>
						<?php endforeach; ?>
					</ul>
				</section>
				<?php endif; ?>
			</div>

			<div class="flex flex-col items-center gap-6">
				<div class="flex w-full max-w-xl items-start justify-center gap-3 text-left">
					<span class="mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full bg-[var(--color-gbt-green)]/15 text-[var(--color-gbt-green)] ring-1 ring-inset ring-[var(--color-gbt-green)]/30" aria-hidden="true">
						<?php gbt_icon_e( 'check', 'size-3', 'solid', 16 ); ?>
					</span>
					<p class="m-0 text-sm leading-6 text-gray-300">
						<strong class="font-semibold text-white">Nothing on your site changes.</strong>
						Conversion does not reinstall the theme or modify your pages, products, settings, or customizations. It connects this installation to our new platform.
					</p>
				</div>
				<button type="button" class="font-semibold text-[var(--color-gbt-blue-lighter)] hover:text-white transition duration-150 ease-in-out cursor-pointer border-0 bg-transparent p-0 text-sm leading-6 tracking-tight" data-gbt-why-open aria-controls="gbt-conversion-why-overlay" aria-expanded="false">Why convert?</button>
				<button type="button" class="inline-flex h-11 w-full max-w-md items-center justify-center gap-2 rounded-md bg-[var(--color-gbt-blue)] px-10 text-sm font-medium leading-none text-white shadow-none hover:bg-[var(--color-gbt-blue-darker)] transition duration-150 ease-in-out cursor-pointer border-0" data-gbt-back-to-convert>
					Back to convert
				</button>
			</div>
		</div>
	</div>
</div>
