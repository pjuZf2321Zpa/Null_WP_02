<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License page — right column (side panel).
 *
 * @var string $state
 * @var bool   $show_tf_email_overlay
 * @var bool   $show_tf_migration
 * @var string $legacy_key
 * @var string $legacy_display
 * @var string $default_email
 * @var string $plans_cta_url
 * @var array  $fs
 * @var bool   $expired
 * @var bool   $licensed
 * @var array  $plans
 * @var string $theme_name
 */
?>
<div id="gbt-license-side" class="relative z-10 -mt-2 min-w-0 p-2 lg:mt-0 lg:w-full lg:max-w-md lg:shrink-0<?php echo $show_tf_email_overlay ? ' hidden' : ''; ?>">
	<?php if ( 'activate' === $state ) : ?>
		<?php if ( $show_tf_migration ) : ?>
			<div class="rounded-2xl bg-[var(--color-gbt-gray-light)] ring-1 ring-[var(--color-gbt-gray-light)] gbt-shine-border h-full overflow-hidden">
				<div class="gbt-shine-border__glow" aria-hidden="true"></div>
				<div class="gbt-shine-border__body h-full flex flex-col">
					<div class="flex items-center justify-center gap-2 bg-[var(--color-gbt-blue)] px-6 sm:px-8 py-2.5 text-[10px] font-semibold uppercase tracking-wide leading-none text-white">
						<span class="inline-flex size-3.5 shrink-0 items-center justify-center" aria-hidden="true">
							<?php gbt_icon_e( 'arrows-right-left', 'block size-3.5 text-white', 'solid', 20 ); ?>
						</span>
						<span class="leading-none">Ready to convert</span>
					</div>
					<div class="flex flex-col flex-1 gap-6 p-6 sm:p-8">
						<?php
						$tf_deadline = gbt_tf_convert_deadline_copy( isset( $theme_name ) ? (string) $theme_name : '' );
						gbt_render_license_seal( 'gbt-license-seal--migrate', 'arrows-right-left' );
						?>
						<div class="text-center">
							<h3 class="text-xl sm:text-2xl font-semibold tracking-tight text-white"><?php echo esc_html( $tf_deadline['side_title'] ); ?></h3>
							<p class="mt-2 text-sm leading-6 text-gray-400"><?php echo esc_html( $tf_deadline['side_body'] ); ?> <button type="button" class="text-sm text-gray-400 underline underline-offset-2 hover:text-white transition duration-150 ease-in-out cursor-pointer border-0 bg-transparent p-0" data-gbt-why-open aria-controls="gbt-conversion-why-overlay" aria-expanded="false">Learn more</button></p>
						</div>

						<div class="rounded-lg bg-[var(--color-gbt-gray-dark)]/60 px-4 py-3.5 text-center ring-1 ring-inset ring-white/5">
							<span class="block text-[10px] font-semibold uppercase tracking-wide text-gray-400">Your Themeforest purchase code</span>
							<p class="mt-2 font-mono text-sm tracking-wider leading-5 text-[var(--color-gbt-green)] break-all"><?php echo esc_html( $legacy_display ); ?></p>
						</div>

						<form id="gbt-convert-license-form" class="flex flex-col gap-6" action="#" method="post">
							<input type="hidden" id="gbt_tf_purchase_code" name="purchase_code" value="<?php echo esc_attr( $legacy_key ); ?>" />
							<div>
								<label for="gbt_tf_email" class="block text-sm font-medium text-white mb-2">Where should we email your license details?</label>
								<input type="email" id="gbt_tf_email" name="email" value="<?php echo esc_attr( $default_email ); ?>" placeholder="Your email" autocomplete="email" required aria-required="true" class="block w-full px-4 py-2.5 text-sm text-white bg-[var(--color-gbt-gray-dark)] border border-[var(--color-gbt-gray-lighter)] rounded-md focus:outline-none focus:ring-1 focus:ring-gbt-blue focus:border-gbt-blue placeholder:text-gray-500" />
								<p class="mt-2 text-sm leading-6 text-gray-400">Use an address you can access. The license key is sent here.</p>
							</div>
							<div id="gbt-convert-license-error" class="hidden rounded-md bg-[var(--color-gbt-red)]/10 border border-[var(--color-gbt-red)]/20 px-4 py-3 text-sm text-[var(--color-gbt-red)]"></div>
							<p id="gbt-convert-license-status" class="hidden text-sm text-gray-400" aria-live="polite"></p>
							<button type="submit" id="gbt-convert-license-submit" class="inline-flex w-full h-11 items-center justify-center gap-2 rounded-md bg-gbt-blue px-4 text-sm font-medium leading-none text-white shadow-sm hover:bg-gbt-blue/90 transition duration-150 ease-in-out cursor-pointer border-0">
								<?php gbt_icon_e( 'arrows-right-left', 'size-5 shrink-0' ); ?>
								Convert &amp; activate
							</button>
							<div class="flex flex-wrap items-center justify-center gap-x-5 gap-y-2">
								<button type="button" id="gbt-migration-info-open" class="gbt-why-link" data-gbt-why-open aria-controls="gbt-conversion-why-overlay" aria-expanded="false">
									<?php gbt_icon_e( 'question-mark-circle', 'size-4 shrink-0', 'solid', 16 ); ?>
									Why convert?
								</button>
								<button type="button" id="gbt-migration-steps-open" class="gbt-howto-link" data-gbt-howto-open aria-controls="gbt-conversion-howto-overlay" aria-expanded="false">
									<?php gbt_icon_e( 'clipboard-document-list', 'size-4 shrink-0' ); ?>
									How conversion works
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		<?php else : ?>
			<div class="rounded-2xl bg-[var(--color-gbt-gray-light)] p-6 sm:p-8 text-center ring-1 ring-[var(--color-gbt-gray-light)] h-full flex flex-col lg:justify-center">
				<div class="mx-auto flex w-full flex-col items-center">
					<?php gbt_render_license_seal( 'gbt-license-seal--unlock', 'key' ); ?>
					<h3 class="mt-4 text-2xl font-semibold tracking-tight text-white">Activate Full Access</h3>
					<p class="mt-2 text-sm text-gray-400">Choose a plan, or enter a key you already have.</p>
					<?php if ( $plans_cta_url !== '' ) : ?>
						<div class="mt-6 w-full">
							<a href="<?php echo esc_url( $plans_cta_url ); ?>" class="inline-flex w-full items-center justify-center gap-2 rounded-md bg-gbt-blue px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-gbt-blue/90 transition duration-150 ease-in-out no-underline">
								<?php gbt_icon_e( 'key', 'size-5 text-white' ); ?>
								View plans &amp; pricing
							</a>
						</div>
					<?php endif; ?>
				</div>
			</div>
		<?php endif; ?>
	<?php else : ?>
		<?php
		$tf_converter    = GBT_License_Converter::get_instance();
		$is_legacy_plan  = $tf_converter->is_themeforest_legacy_active();
		$seal_tone       = $expired ? 'gbt-license-seal--expired' : 'gbt-license-seal--active';
		$seal_icon       = $expired ? 'exclamation-circle' : 'check-badge';
		$seal_icon_size  = $expired ? 20 : 24;
		$tf_purchase     = $is_legacy_plan ? $tf_converter->get_themeforest_purchase_date_display() : '';
		$tf_credit_value = $tf_converter->get_themeforest_credit_value();
		$entitled        = $licensed;
		$panel_cta       = gbt_license_panel_cta( $expired, $is_legacy_plan, $tf_credit_value );
		$panel_title     = gbt_license_format_panel_title( (string) ( $fs['plan'] ?? '' ) );
		?>
		<div class="rounded-2xl bg-[var(--color-gbt-gray-light)] p-6 sm:p-8 text-center ring-1 ring-[var(--color-gbt-gray-light)] h-full flex flex-col">
			<div class="mx-auto w-full flex flex-col flex-1">
				<?php gbt_render_license_seal( $seal_tone, $seal_icon, 'solid', $seal_icon_size ); ?>
				<h3 class="mt-4 text-2xl font-semibold tracking-tight text-white"><?php echo esc_html( $panel_title ); ?></h3>
				<div class="mt-6 space-y-0 text-left">
					<?php
					foreach ( gbt_license_status_rows( $fs, $entitled, $tf_purchase ) as $i => $row ) {
						gbt_render_license_status_row( $row[0], $row[1], $row[2], $row[3] ?? '' );
						if ( 0 === (int) $i && $is_legacy_plan ) {
							gbt_render_license_key_status_row( $fs );
						}
					}
					?>
				</div>
				<?php if ( $is_legacy_plan ) : ?>
					<div class="mt-8">
						<div class="gbt-license-flash rounded-md border border-[var(--color-gbt-yellow)]/20 bg-[var(--color-gbt-yellow)]/10 px-4 py-3 text-sm text-[var(--color-gbt-yellow)] text-left" role="status">
							<span class="gbt-license-flash__icon" aria-hidden="true"><?php gbt_icon_e( 'information-circle', 'size-5', 'solid', 20 ); ?></span>
							<span class="gbt-license-flash__body">
								<?php
								$grace         = $tf_converter->get_grace_period_notice_data();
								$expires_ts    = is_array( $grace ) ? (int) ( $grace['until_ts'] ?? 0 ) : 0;
								$expires_label = $expires_ts > 0 ? date_i18n( 'F j', $expires_ts ) : '';
								$days_left     = ( $expires_ts > 0 && $expires_ts > (int) current_time( 'timestamp' ) )
									? (int) ceil( ( $expires_ts - (int) current_time( 'timestamp' ) ) / DAY_IN_SECONDS )
									: 0;
								$theme_label   = trim( (string) ( $theme_name ?? '' ) );
								$license_ref   = $theme_label !== '' ? $theme_label . ' license' : 'license';
								if ( $expired ) {
									echo esc_html( 'There\'s no plan associated with the ' . $license_ref . ', and it has expired.' );
								} elseif ( $expires_label !== '' ) {
									$msg = 'There\'s no plan associated with the ' . $license_ref . '. It will expire on ' . $expires_label;
									if ( $days_left > 0 ) {
										$msg .= ' — ' . $days_left . ' ' . ( 1 === $days_left ? 'day' : 'days' ) . ' left';
									}
									echo esc_html( $msg . '.' );
								} else {
									echo esc_html( 'There\'s no plan associated with the ' . $license_ref . ', and it will expire.' );
								}
								?>
							</span>
						</div>
					</div>
				<?php elseif ( $plans_cta_url !== '' && ( ! empty( $plans ) || $expired ) ) : ?>
					<div class="mt-8">
						<a href="<?php echo esc_url( $plans_cta_url ); ?>" class="inline-flex w-full items-center justify-center gap-2 rounded-md bg-gbt-blue px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-gbt-blue/90 transition duration-150 ease-in-out no-underline">
							<?php
							if ( $panel_cta['icon'] !== '' ) {
								gbt_icon_e( $panel_cta['icon'], 'size-5 text-white' );
							}
							?>
							<?php echo esc_html( $panel_cta['label'] ); ?>
						</a>
					</div>
				<?php endif; ?>
				<div class="mt-auto pt-8 flex flex-col gap-3">
					<form id="gbt-deactivate-license-form" method="post" action="<?php echo esc_url( $fs['deactivate_url'] ); ?>" class="m-0 p-0 w-full flex justify-center" data-gbt-busy-submit data-gbt-busy-label="Deactivating…">
						<input type="hidden" name="fs_action" value="deactivate_license">
						<?php wp_nonce_field( 'deactivate_license' ); ?>
						<button type="submit" id="gbt-deactivate-license-submit" class="inline-flex items-center justify-center gap-2 text-sm text-gray-400 hover:text-white underline underline-offset-2 transition duration-150 ease-in-out cursor-pointer border-0 bg-transparent p-0 shadow-none" onclick="return confirm('Deactivate this license on the current site?');">
							Deactivate license on this site
						</button>
					</form>
					<?php if ( ! $is_legacy_plan && empty( $plans ) && $fs['change_plan_url'] !== '' ) : ?>
						<div class="flex flex-wrap items-center justify-center">
							<a href="<?php echo esc_url( $fs['change_plan_url'] ); ?>" class="text-sm text-gray-400 hover:text-white underline underline-offset-2 transition duration-150 ease-in-out">Change plan</a>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	<?php endif; ?>
</div>
