<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Payment + trust logos for Plans & Pricing.
 *
 * Sources (downloaded, not hand-drawn):
 * - Cards / iDEAL / PayPal: datatrans/payment-logos (GitHub)
 * - McAfee Secure: OpenIconLibrary payment-gateway-logos pack (MIT)
 * - Cloudflare: official brand SVG from cloudflare.com
 *
 * @var string $gbt_payment_section Optional: methods|trust|all
 */
$icons_url = trailingslashit( GBT_Dashboard_Setup::init()->get_base_paths()['url'] ) . 'dashboard/icons/payment/';
$section   = isset( $gbt_payment_section ) ? (string) $gbt_payment_section : 'all';

$methods = array(
	'visa'       => 'Visa',
	'mastercard' => 'Mastercard',
	'amex'       => 'American Express',
	'jcb'        => 'JCB',
	'ideal'      => 'iDEAL',
	'paypal'     => 'PayPal',
);

$trust = array(
	'mcafee-secure' => array( 'label' => 'McAfee Secure', 'class' => 'h-8 w-auto opacity-80' ),
	'cloudflare'    => array( 'label' => 'Cloudflare', 'class' => 'h-7 w-auto opacity-80' ),
);

$show_methods = in_array( $section, array( 'methods', 'all' ), true );
$show_trust   = in_array( $section, array( 'trust', 'all' ), true );
$show_note    = $show_methods;
?>
<div class="mx-auto mt-6 w-full max-w-lg lg:max-w-4xl" aria-label="Accepted payment methods and security">
	<?php if ( $show_note ) : ?>
		<p class="text-center text-sm/6 text-gray-600"><?php echo ! empty( $tf_legacy_active ) ? 'Encrypted payments at checkout.' : 'Encrypted payments · 14-day money-back.'; ?></p>
	<?php endif; ?>

	<?php if ( $show_methods ) : ?>
		<ul class="<?php echo esc_attr( $show_note ? 'mt-6 ' : '' ); ?>flex flex-wrap items-center justify-center gap-3 sm:gap-4" role="list">
			<?php foreach ( $methods as $file => $label ) : ?>
				<li class="inline-flex items-center">
					<img
						src="<?php echo esc_url( $icons_url . $file . '.svg' ); ?>"
						alt="<?php echo esc_attr( $label ); ?>"
						width="48"
						height="32"
						class="h-8 w-auto rounded-md"
						loading="lazy"
						decoding="async"
					/>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>

	<?php if ( $show_trust ) : ?>
		<ul class="<?php echo esc_attr( ( $show_methods || $show_note ) ? 'mt-6 ' : '' ); ?>flex flex-wrap items-center justify-center gap-x-12 gap-y-6" role="list">
			<?php foreach ( $trust as $file => $logo ) : ?>
				<li class="inline-flex h-8 items-center">
					<img
						src="<?php echo esc_url( $icons_url . $file . '.svg' ); ?>"
						alt="<?php echo esc_attr( $logo['label'] ); ?>"
						width="120"
						height="32"
						class="<?php echo esc_attr( $logo['class'] ); ?>"
						loading="lazy"
						decoding="async"
					/>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
