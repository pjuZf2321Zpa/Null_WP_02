<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License page — left column (main panel).
 *
 * @var string $state
 * @var bool   $show_tf_email_overlay
 * @var string $theme_name
 * @var bool   $show_tf_migration
 * @var array  $premium_features
 * @var string $intro
 * @var bool   $purchased
 * @var bool   $celebrate
 * @var bool   $migrated
 * @var bool   $synced
 * @var array  $fs
 * @var bool   $expired
 * @var string $posted
 * @var string $error
 * @var string $portal_url
 * @var string $error_detail
 * @var string $plans_cta_url
 */
?>
<div id="gbt-license-main" class="p-8 sm:p-10 lg:flex-auto flex flex-col relative z-10<?php echo $show_tf_email_overlay ? ' hidden' : ''; ?>">
	<?php gbt_display_version_badge(); ?>
	<h3 class="mt-2 text-4xl font-semibold tracking-tight text-pretty text-white sm:text-5xl"><?php echo esc_html( $theme_name ); ?></h3>
	<?php if ( ! GBT_License_Converter::get_instance()->is_themeforest_legacy_active() ) : ?>
	<div class="mt-5 text-sm text-gray-400"><?php
	if ( 'activate' === $state && $show_tf_migration && ! empty( $premium_features ) ) {
		echo 'Activate your license to unlock ';
		gbt_render_premium_features_tip( $premium_features );
		echo ', updates, and support.';
	} else {
		echo esc_html( $intro );
	}
	?></div>
	<?php endif; ?>

	<?php
	if ( $purchased ) {
		gbt_render_license_success_notice( 'Purchase completed successfully. Your license is now active.' );
	} elseif ( ! empty( $migrated ) ) {
		gbt_render_license_success_notice( 'Conversion complete — your license is active on this site. We emailed your license key and account details for your records only; ignore the download and install steps — the theme is already installed and activated.' );
	} elseif ( $celebrate ) {
		gbt_render_license_success_notice( 'License activated successfully.' );
	} elseif ( $synced ) {
		gbt_render_license_success_notice( 'License synced successfully.' );
	}
	?>

	<?php
	$tf_converter = GBT_License_Converter::get_instance();
	$tf_offer     = $tf_converter->get_tf_upgrade_offer_data();
	$tf_has_offer = is_array( $tf_offer );
	$tf_converter->render_grace_period_notice( 'mt-5' );
	if ( $tf_has_offer ) {
		$tf_converter->render_tf_upgrade_offer( 'mt-5' );
	}
	?>

	<?php if ( 'freemius' === $state ) : ?>
		<?php if ( ! GBT_License_Converter::get_instance()->is_themeforest_legacy_active() ) : ?>
			<div class="mt-12 max-w-3xl">
				<?php gbt_render_license_key_block( $fs, $expired ); ?>
			</div>
		<?php endif; ?>
	<?php else : ?>
		<div id="gbt-license-key-area" class="mt-12 max-w-3xl">
			<div class="flex items-center gap-2 mb-2">
				<?php gbt_icon_e( 'key', 'size-5 shrink-0 text-gray-400' ); ?>
				<label for="freemius_license_key" class="text-sm font-medium text-white">License key</label>
			</div>
			<form id="gbt-activate-license-form" method="post" action="" class="flex flex-col gap-4" data-gbt-busy-submit data-gbt-busy-label="Activating…" data-gbt-busy-disable-input="#freemius_license_key">
				<?php wp_nonce_field( 'gbt_activate_freemius_license' ); ?>
				<input type="hidden" name="gbt_activate_freemius_license" value="1" />
				<input type="text" id="freemius_license_key" name="freemius_license_key" value="<?php echo esc_attr( $posted ); ?>" placeholder="Enter your license key" autocomplete="off" required aria-required="true" class="block w-full px-4 py-3.5 text-sm text-white bg-[var(--color-gbt-gray-light)] border border-[var(--color-gbt-gray-lighter)] rounded-md focus:outline-none focus:ring-1 focus:ring-gbt-blue focus:border-gbt-blue" />
				<?php if ( $error !== '' ) : ?>
					<div class="flex flex-col gap-2 rounded-md bg-[var(--color-gbt-red)]/10 border border-[var(--color-gbt-red)]/20 px-4 py-3 text-sm text-[var(--color-gbt-red)]">
						<span><?php echo esc_html( $error ); ?></span>
						<?php if ( $portal_url !== '' ) : ?>
							<span>
								<a href="<?php echo esc_url( $portal_url ); ?>" target="_blank" rel="noopener noreferrer" class="font-medium underline underline-offset-2 hover:no-underline">
									Open Customer Portal
								</a>
							</span>
						<?php endif; ?>
						<?php if ( $error_detail !== '' ) : ?>
							<span class="pt-2 border-t border-[var(--color-gbt-red)]/20 text-[var(--color-gbt-red)]/80"><?php echo esc_html( $error_detail ); ?></span>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<div class="flex flex-wrap items-center gap-x-5 gap-y-3">
					<button type="submit" id="gbt-activate-license-submit" class="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-[var(--color-gbt-blue)] px-6 text-sm font-medium leading-none text-white shadow-none hover:bg-[var(--color-gbt-blue-darker)] transition duration-150 ease-in-out cursor-pointer border-0">
						Activate license key
					</button>
					<?php if ( $plans_cta_url !== '' && ! $show_tf_migration ) : ?>
						<a href="<?php echo esc_url( $plans_cta_url ); ?>" class="text-sm font-medium text-[var(--color-gbt-blue-lighter)] hover:underline no-underline">
							Get a license key
						</a>
					<?php endif; ?>
				</div>
			</form>
		</div>
	<?php endif; ?>

	<div class="mt-auto">
		<div class="border-t border-white/10 pt-6 mt-8">
			<div class="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
				<?php gbt_icon_e( 'lifebuoy', 'size-5 shrink-0 text-gray-400' ); ?>
				<span class="font-medium text-white">Need help?</span>
				<span class="text-gray-400">
					<a href="<?php echo esc_url( $help_url ); ?>" target="_blank" rel="noopener noreferrer" class="text-[var(--color-gbt-blue-lighter)] hover:underline">Contact us</a> if you get stuck.
				</span>
			</div>
		</div>
	</div>
</div>
