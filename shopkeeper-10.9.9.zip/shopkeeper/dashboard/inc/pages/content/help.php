<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'getbowtied_help_content' ) ) {
	function getbowtied_help_content() {
		gbt_render_dashboard_page(
			static function ( $setup ) {
				$theme_name           = $setup->get_theme_name();
				$theme_url_docs       = $setup->get_theme_url_docs();
				$theme_url_changelog  = $setup->get_theme_url_changelog();
				$theme_url_support    = $setup->get_theme_url_support();
				$cards                = array(
					array(
						'url'         => $theme_url_docs,
						'icon'        => 'book-open',
						'title'       => 'Documentation',
						'description' => 'Comprehensive guides and tutorials to help you set up and customize your theme exactly how you want it.',
						'cta'         => 'Read documentation',
					),
					array(
						'url'         => $theme_url_support,
						'icon'        => 'chat-bubble-left-right',
						'title'       => 'Customer Support',
						'description' => 'Our dedicated support team is ready to help you overcome any challenges and answer your questions.',
						'cta'         => 'Get support',
					),
					array(
						'url'         => $theme_url_changelog,
						'icon'        => 'clipboard-document-list',
						'title'       => 'Changelog',
						'description' => 'Stay up-to-date with the latest theme improvements, bug fixes, and new features in each release.',
						'cta'         => 'View changelog',
					),
				);
				?>
				<div class="overflow-hidden py-24 sm:py-32">
					<div class="mx-auto max-w-7xl px-6 lg:px-8">
						<div class="mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 sm:gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-1">
							<div>
								<div class="lg:max-w-lg">
									<?php gbt_display_version_badge(); ?>
									<h2 class="mt-4 text-4xl font-semibold tracking-tight text-pretty text-gray-900 sm:text-5xl leading-14"><?php echo esc_html( $theme_name ); ?> Help</h2>
									<p class="mt-6 text-lg leading-8 text-gray-600">
										Everything you need to make the most of your theme and create a stunning website.
									</p>
								</div>
							</div>

							<div class="mx-auto grid max-w-7xl grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 mt-4">
								<?php foreach ( $cards as $card ) : ?>
									<a href="<?php echo esc_url( $card['url'] ); ?>"
										target="_blank"
										class="flex flex-col h-full bg-white p-6 rounded-lg border border-gray-200 hover:border-gray-300 shadow-sm hover:shadow transition-all no-underline">
										<div class="flex items-center justify-center w-12 h-12 rounded-full bg-gbt-blue/10 text-gbt-blue mb-4">
											<?php gbt_icon_e( $card['icon'], 'size-6' ); ?>
										</div>
										<h3 class="text-xl font-medium text-gray-900 mb-2"><?php echo esc_html( $card['title'] ); ?></h3>
										<p class="text-sm text-gray-600 mb-4 flex-grow"><?php echo esc_html( $card['description'] ); ?></p>
										<div class="flex items-center text-sm text-gbt-blue font-medium">
											<span><?php echo esc_html( $card['cta'] ); ?></span>
											<?php gbt_icon_e( 'arrow-right', 'size-4 ml-1' ); ?>
										</div>
									</a>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				</div>
				<?php
			}
		);
	}
}
