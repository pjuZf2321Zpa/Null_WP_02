<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$gbt_dashboard_setup = GBT_Dashboard_Setup::init();
$base_paths          = $gbt_dashboard_setup->get_base_paths();

if ( $gbt_dashboard_setup->supports_license() ) {
	require_once $base_paths['path'] . '/dashboard/inc/helpers/plans.php';
	require_once $base_paths['path'] . '/dashboard/inc/helpers/themeforest.php';
	require_once $base_paths['path'] . '/dashboard/inc/classes/class-license-manager.php';
	require_once $base_paths['path'] . '/dashboard/inc/classes/class-license-converter.php';
	require_once $base_paths['path'] . '/dashboard/inc/classes/class-theme-update-notice.php';
}

include_once $base_paths['path'] . '/dashboard/inc/pages/includes.php';
include_once $base_paths['path'] . '/dashboard/inc/pages/pages.php';
include_once $base_paths['path'] . '/dashboard/inc/pages/pages-order.php';

include_once $base_paths['path'] . '/dashboard/inc/pages/content/home.php';
include_once $base_paths['path'] . '/dashboard/inc/pages/content/templates.php';
include_once $base_paths['path'] . '/dashboard/inc/pages/content/documentation.php';
include_once $base_paths['path'] . '/dashboard/inc/pages/content/changelog.php';
include_once $base_paths['path'] . '/dashboard/inc/pages/content/help.php';

if ( $gbt_dashboard_setup->supports_license() ) {
	include_once $base_paths['path'] . '/dashboard/inc/helpers/pricing.php';
	include_once $base_paths['path'] . '/dashboard/inc/pages/content/pricing.php';
	include_once $base_paths['path'] . '/dashboard/inc/helpers/license.php';
	include_once $base_paths['path'] . '/dashboard/inc/pages/content/license.php';
}

include_once $base_paths['path'] . '/dashboard/inc/pages/content/diagnostics.php';
