<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'getbowtied_dashboard_pages_styles_and_scripts' ) ) {
	function getbowtied_dashboard_pages_styles_and_scripts() {
		if ( empty( $_GET['page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$setup     = GBT_Dashboard_Setup::init();
		$our_pages = $setup->get_dashboard_page_slugs();
		$page      = sanitize_key( wp_unslash( $_GET['page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( ! in_array( $page, $our_pages, true ) ) {
			return;
		}

		add_filter( 'screen_options_show_screen', '__return_false' );

		getbowtied_clean_dashboard_admin_chrome();

		$base_paths = $setup->get_base_paths();
		$version    = $setup->get_theme_version();
		$base_url   = $base_paths['url'] . '/dashboard';
		$ajax_url   = admin_url( 'admin-ajax.php' );

		wp_enqueue_style(
			'getbowtied-dashboard-tailwind',
			$base_url . '/css/dashboard.css',
			array(),
			$version
		);

		wp_enqueue_style(
			'getbowtied-dashboard-pages',
			$base_url . '/css/pages.css',
			array( 'getbowtied-dashboard-tailwind' ),
			$version
		);

		$scripts = array(
			'getbowtied-auto-update-handler' => array(
				'file'  => 'auto-update-handler.js',
				'deps'  => array( 'jquery' ),
				'local' => array(
					'name' => 'gbtAutoUpdateData',
					'data' => array(
						'ajaxurl' => $ajax_url,
						'nonce'   => wp_create_nonce( 'gbt_enable_auto_updates' ),
					),
				),
			),
			'getbowtied-theme-installer'     => array(
				'file'  => 'theme-installer.js',
				'deps'  => array( 'jquery' ),
				'local' => array(
					'name' => 'gbtThemeInstallerData',
					'data' => array(
						'ajaxurl'        => $ajax_url,
						'nonce'          => wp_create_nonce( 'install_theme_ajax' ),
						'activate_nonce' => wp_create_nonce( 'activate_theme_ajax' ),
					),
				),
			),
			'getbowtied-dashboard-tips'        => array(
				'file' => 'dashboard-tips.js',
				'deps' => array(),
			),
			'getbowtied-pricing-scroll'       => array(
				'file' => 'pricing-scroll.js',
				'deps' => array(),
			),
			'getbowtied-gbt-ui'               => array(
				'file' => 'gbt-ui.js',
				'deps' => array(),
			),
			'getbowtied-license-page'         => array(
				'file' => 'license-page.js',
				'deps' => array( 'getbowtied-gbt-ui' ),
			),
			'getbowtied-license-converter'    => array(
				'file' => 'license-converter.js',
				'deps' => array( 'jquery', 'getbowtied-gbt-ui' ),
			),
			'getbowtied-dashboard-iframe'     => array(
				'file' => 'iframe.js',
				'deps' => array( 'jquery' ),
			),
		);

		$page_scripts = array(
			'getbowtied-auto-update-handler',
			'getbowtied-theme-installer',
		);

		if ( in_array( $page, array( 'getbowtied-documentation', 'getbowtied-changelog' ), true ) ) {
			wp_enqueue_script(
				'getbowtied-iframe-resizer',
				$base_url . '/js/vendor/iframe-resizer/iframeResizer.min.js',
				array( 'jquery' ),
				'4.3.2',
				true
			);
			$page_scripts[] = 'getbowtied-dashboard-iframe';
		}

		if ( 'getbowtied-theme-documentation' === $page ) {
			$page_scripts[] = 'getbowtied-dashboard-iframe';
		}

		if ( in_array( $page, array( 'getbowtied-pricing', 'getbowtied-license' ), true ) ) {
			$page_scripts[] = 'getbowtied-dashboard-tips';
		}

		if ( 'getbowtied-pricing' === $page ) {
			$page_scripts[] = 'getbowtied-pricing-scroll';
		}

		if ( 'getbowtied-license' === $page ) {
			$page_scripts[] = 'getbowtied-gbt-ui';
			$page_scripts[] = 'getbowtied-license-page';

			if ( getbowtied_should_enqueue_license_converter() ) {
				$page_scripts[] = 'getbowtied-license-converter';
			}
		}

		$page_scripts = array_values( array_unique( $page_scripts ) );

		foreach ( $page_scripts as $handle ) {
			if ( ! isset( $scripts[ $handle ] ) ) {
				continue;
			}

			$script = $scripts[ $handle ];
			wp_enqueue_script(
				$handle,
				$base_url . '/js/' . $script['file'],
				$script['deps'] ?? array(),
				$version,
				true
			);

			if ( ! empty( $script['local'] ) ) {
				wp_localize_script(
					$handle,
					$script['local']['name'],
					$script['local']['data']
				);
			}
		}

		if ( in_array( 'getbowtied-license-converter', $page_scripts, true ) ) {
			wp_localize_script(
				'getbowtied-license-converter',
				'gbtLicenseConverter',
				array(
					'ajaxurl'           => $ajax_url,
					'nonce'             => wp_create_nonce( 'gbt_convert_tf_license' ),
					'action'            => 'gbt_convert_tf_license',
					'convertingText'    => 'Converting…',
					'requiredText'      => 'Purchase code and email are required.',
					'emailRequiredText' => 'Email is required.',
					'emailInvalidText'  => 'Please enter a valid email address.',
					'errorText'         => 'Conversion failed. Please try again.',
				)
			);
		}
	}

	add_action( 'admin_enqueue_scripts', 'getbowtied_dashboard_pages_styles_and_scripts' );
}

if ( ! function_exists( 'getbowtied_should_enqueue_license_converter' ) ) {
	/**
	 * Whether ThemeForest conversion JS is needed on the license page.
	 */
	function getbowtied_should_enqueue_license_converter(): bool {
		if ( class_exists( 'GBT_License_Manager' ) ) {
			$legacy_key = GBT_License_Manager::get_instance()->get_legacy_purchase_code();
			if ( $legacy_key !== '' ) {
				return true;
			}
		}

		if (
			isset( $_POST['gbt_activate_freemius_license'], $_POST['freemius_license_key'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			&& class_exists( 'GBT_License_Manager' )
		) {
			$maybe_key = trim( (string) wp_unslash( $_POST['freemius_license_key'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return GBT_License_Manager::is_themeforest_purchase_code( $maybe_key );
		}

		return false;
	}
}

if ( ! function_exists( 'getbowtied_clean_dashboard_admin_chrome' ) ) {
	/**
	 * Strip WordPress / plugin chrome on Get Bowtied dashboard pages.
	 */
	function getbowtied_clean_dashboard_admin_chrome(): void {
		add_action(
			'in_admin_header',
			static function () {
				remove_all_actions( 'admin_notices' );
				remove_all_actions( 'all_admin_notices' );
				remove_all_actions( 'user_admin_notices' );
				remove_all_actions( 'network_admin_notices' );
			},
			1000
		);

		add_action(
			'admin_head',
			static function () {
				$screen = get_current_screen();
				if ( $screen ) {
					$screen->remove_help_tabs();
				}

				echo '<style id="gbt-clean-dashboard-pages">'
					. '#wpbody-content > .notice,'
					. '#wpbody-content > .update-nag,'
					. '#wpbody-content > .error,'
					. '#wpbody-content > .updated,'
					. '#wpbody-content > .fs-notice,'
					. '#screen-meta,'
					. '#screen-meta-links,'
					. '#wpfooter,'
					. '.wp-pointer{display:none!important;}'
					/* Equalize horizontal space: WP only pads #wpcontent on the left. */
					. 'body.gbt-clean-admin #wpcontent{padding-left:0!important;}'
					. 'body.gbt-clean-admin #wpbody-content{padding:0!important;}'
					. 'body.gbt-clean-admin #wpbody-content > .gbt-dashboard-scope{margin:0!important;}'
					. '</style>';
			},
			1
		);

		add_filter(
			'admin_body_class',
			static function ( $classes ) {
				return $classes . ' gbt-clean-admin';
			}
		);

		add_filter( 'admin_footer_text', '__return_empty_string', 999 );
		add_filter( 'update_footer', '__return_empty_string', 999 );

		remove_action( 'in_admin_footer', 'gbt_display_welcome_pointer' );
	}
}

if ( ! function_exists( 'getbowtied_clean_license_admin_chrome' ) ) {
	/**
	 * @deprecated Use getbowtied_clean_dashboard_admin_chrome().
	 */
	function getbowtied_clean_license_admin_chrome(): void {
		getbowtied_clean_dashboard_admin_chrome();
	}
}
