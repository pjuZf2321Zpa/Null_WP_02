<?php
/**
 * Single Product Thumbnails
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-thumbnails.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     11.1.0
 */

use Automattic\WooCommerce\Internal\ProductGallery\ProductMediaGallery;

defined( 'ABSPATH' ) || exit;

// Note: `wc_get_gallery_image_html` was added in WC 3.3.2 and did not exist prior. This check protects against theme overrides being used on older versions of WC.
if ( ! function_exists( 'wc_get_gallery_image_html' ) ) {
	return;
}

global $post, $product;

if ( ! $product || ! $product instanceof WC_Product ) {
	return '';
}

$post_custom_values   = get_post_custom( $post->ID );
$page_product_youtube = isset( $post_custom_values['page_product_youtube'] ) ? esc_attr( $post_custom_values['page_product_youtube'][0] ) : '';
$embed_code           = $page_product_youtube ? wp_oembed_get( $page_product_youtube ) : '';

if ( getbowtied_product_layout( get_the_ID() ) == 'default' ) {

	$media_items = ProductMediaGallery::get_product_media_gallery_items_for_display( $product );

	if ( count( $media_items ) > 1 ) {
		foreach ( array_slice( $media_items, 1 ) as $key => $media_item ) {
			$attachment_id = isset( $media_item['id'] ) ? absint( $media_item['id'] ) : 0;

			if ( ! $attachment_id ) {
				continue;
			}

			$is_video = 'video' === ( $media_item['media_type'] ?? '' );

			if ( $is_video ) {
				$html = ProductMediaGallery::get_gallery_video_html( $media_item, false );
			} else {
				$html = wc_get_gallery_image_html( $attachment_id, false, $key );
			}

			if ( $is_video ) {
				/**
				 * Filter product video thumbnail HTML string.
				 *
				 * @since 11.0.0
				 * @internal For exclusive usage of WooCommerce core, backwards compatibility not guaranteed.
				 *
				 * @param string $html          Product video thumbnail HTML string.
				 * @param int    $attachment_id Video attachment ID.
				 * @param array  $media_item    Product media gallery item.
				 */
				echo apply_filters( 'woocommerce_single_product_video_thumbnail_html', $html, $attachment_id, $media_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			} else {
				/**
				 * Filter product image thumbnail HTML string.
				 *
				 * @since 1.6.4
				 *
				 * @param string $html          Product image thumbnail HTML string.
				 * @param int    $attachment_id Attachment ID.
				 */
				echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, $attachment_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}
	}

	if ( $page_product_youtube ) {
		echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'woocommerce_single_product_image_thumbnail_html',
			'<div data-thumb="' . esc_url( get_template_directory_uri() . '/images/gtb-video-player.svg' ) . '" class="woocommerce-product-gallery__image youtube"><a class="video" href="' . esc_url( $page_product_youtube ) . '"><div class="fluid-width-video-wrapper">' . $embed_code . '</div></a></div>',
			0
		);
	}
} else {

	$attachment_ids = $product->get_gallery_image_ids();

	if ( $attachment_ids || $page_product_youtube ) {
		?>

		<ul class="product_thumbnails flex-control-nav show-for-medium">

			<?php
			// Featured.
			if ( $product->get_image_id() ) {

				$featured_image_src = wp_get_attachment_image_src( get_post_thumbnail_id(), 'shop_thumbnail' );

				echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', sprintf( '<li class="carousel-cell is-nav-selected"><img class="%s" src="%s" /></li>', 'attachment-shop_thumbnail size-shop_thumbnail', esc_url( $featured_image_src[0] ) ), $post->ID ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			} else {

				echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', sprintf( '<li class="carousel-cell is-nav-selected"><img src="%s" alt="Placeholder" /></li>', esc_url( wc_placeholder_img_src() ) ), $post->ID ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			}

			// Thumbs.
			if ( $attachment_ids ) {

				foreach ( $attachment_ids as $attachment_id ) {

					$image = wp_get_attachment_image( $attachment_id, apply_filters( 'single_product_small_thumbnail_size', 'shop_thumbnail' ) );

					echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', sprintf( '<li class="carousel-cell">%s</li>', $image ), $attachment_id, $post->ID ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

				}
			}

			// Youtube Video.
			if ( $page_product_youtube ) {
				echo '<li class="carousel-cell youtube"><i class="spk-icon spk-icon-video-player"></i></li>';
			}
			?>

		</ul>

		<?php
	}
}
