<?php

if ( ! function_exists( 'gbt_fs' ) ) {
	function gbt_fs() {
		global $gbt_fs;

		if ( ! isset( $gbt_fs ) ) {
			$config_path = get_template_directory() . '/dashboard/config.php';
			$sdk_path    = get_template_directory() . '/dashboard/inc/freemius/start.php';
			$config      = file_exists( $config_path ) ? include $config_path : array();
			$freemius    = $config['supported_themes'][ get_template() ]['freemius'] ?? null;

			if ( ! $freemius || ! file_exists( $sdk_path ) ) {
				$gbt_fs = false;
			} else {
				/*
				 * Workaround: skip our start.php if Freemius is already loaded.
				 * start.php fs_redirect()s to the same URL when the theme SDK is
				 * newer than a plugin's — themes can't win load order → redirect loop.
				 * Still call fs_dynamic_init() on the shared SDK.
				 *
				 * Revert when Freemius fixes this in start.php: always
				 * require_once $sdk_path; then fs_dynamic_init( ... );
				 */
				if ( ! class_exists( 'Freemius' ) ) {
					require_once $sdk_path;
				}

				$gbt_fs = fs_dynamic_init( array(
					'id'                  => $freemius['id'],
					'slug'                => $freemius['slug'],
					'premium_slug'        => $freemius['slug'],
					'type'                => 'theme',
					'public_key'          => $freemius['public_key'],
					'is_premium'          => true,
					'has_premium_version' => true,
					'is_premium_only'     => false,
					'has_addons'          => false,
					'has_paid_plans'      => true,
					'is_org_compliant'    => false,
					'menu'                => array(
						'slug'        => 'getbowtied-dashboard',
						'first-path'  => 'admin.php?page=getbowtied-dashboard&require_license=false',
						'contact'     => false,
						'support'     => false,
						'account'     => false,
						'pricing'     => false,
						'addons'      => false,
						'affiliation' => false,
					),
					'enable_anonymous'    => true,
					'anonymous_mode'      => true,
				) );
			}
		}

		return $gbt_fs;
	}
}

require_once get_template_directory() . '/dashboard/inc/fs-init.php';

gbt_fs();
do_action( 'gbt_fs_loaded' );

// Helpers.
include_once( get_template_directory() . '/functions/helpers/helpers.php');

// Theme setup.
include_once( get_template_directory() . '/functions/theme/theme-setup.php');
include_once( get_template_directory() . '/functions/theme/theme-styles.php');
include_once( get_template_directory() . '/functions/theme/theme-scripts.php');

// Admin setup.
if ( is_admin() || ( defined('WP_CLI') && WP_CLI ) ) {
	include_once( get_template_directory() . '/functions/admin/admin-setup.php');
	include_once( get_template_directory() . '/functions/admin/admin-styles.php');
	include_once( get_template_directory() . '/functions/admin/admin-scripts.php');
	include_once( get_template_directory() . '/dashboard/index.php' );
}

// Customizer.
include_once( get_template_directory() . '/inc/customizer/read-options.php' );
include_once( get_template_directory() . '/inc/customizer/backend/class/class-fonts.php' );
include_once( get_template_directory() . '/inc/customizer/frontend.php' );
include_once( get_template_directory() . '/inc/customizer/backend.php' );

// WP.
include_once( get_template_directory() . '/functions/wp/header-functions.php');
include_once( get_template_directory() . '/functions/wp/footer-functions.php');
include_once( get_template_directory() . '/functions/wp/actions.php');
include_once( get_template_directory() . '/functions/wp/filters.php');

// WC.
if( SHOPKEEPER_WOOCOMMERCE_IS_ACTIVE ) {
	include_once( get_template_directory() . '/functions/plugins/wc/actions.php');
	include_once( get_template_directory() . '/functions/plugins/wc/filters.php');
	include_once( get_template_directory() . '/functions/plugins/wc/custom.php');
}

// Germanized & German Market.
if( SHOPKEEPER_GERMAN_MARKET_IS_ACTIVE || SHOPKEEPER_WOOCOMMERCE_GERMANIZED_IS_ACTIVE ) {
	include_once( get_template_directory() . '/functions/plugins/germanized/functions.php');
}

// WPBakery.
if( SHOPKEEPER_WPBAKERY_IS_ACTIVE ) {
	include_once( get_template_directory() . '/functions/plugins/wb/functions.php');
}

// YITH Wishlist
if( SHOPKEEPER_WISHLIST_IS_ACTIVE ) {
	include_once( get_template_directory() . '/functions/plugins/wishlist/actions.php');
}

// WPML.
include_once( get_template_directory() . '/functions/plugins/wpml/functions.php');

// Load Custom Styles.
include_once( get_template_directory() . '/inc/custom-styles/init.php' );

// Load Post meta template.
include_once( get_template_directory() . '/inc/templates/post-meta.php' );

// Load Template Tags.
include_once( get_template_directory() . '/inc/templates/template-tags.php' );

//Include Metaboxes.
include_once( get_template_directory() . '/inc/metaboxes/page.php' );
include_once( get_template_directory() . '/inc/metaboxes/post.php' );
include_once( get_template_directory() . '/inc/metaboxes/product.php' );


function shopkeeper_register_elementor_locations( $elementor_theme_manager ) {
	$elementor_theme_manager->register_all_core_location();
}
add_action( 'elementor/theme/register_locations', 'shopkeeper_register_elementor_locations' );
