<div class="vehica-attachment-page">
    <div class="vehica-attachment-page__inner">
        <?php
        $post = get_queried_object();
        if ($post instanceof WP_Post && $post->post_type === 'attachment') {
            \Vehica\Core\Post\ContentRenderer::display($post);
        }
        ?>
    </div>
</div>
