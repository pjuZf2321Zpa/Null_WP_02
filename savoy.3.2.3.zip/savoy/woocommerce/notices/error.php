<?php
/**
 * Show error messages
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/notices/error.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woo.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 8.6.0
 NM: Modified */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! $notices ) {
	return;
}

$nm_shop_notice_single_class = ( count( $notices ) > 1 ) ? ' nm-shop-notice-multiple' : '';

?>

<ul class="nm-shop-notice woocommerce-error<?php echo esc_attr( $nm_shop_notice_single_class ); ?>" role="alert">
    <?php foreach ( $notices as $notice ) : ?>
    <li<?php echo wc_get_notice_data_attr( $notice ); ?>>
        <span><i class="nm-font nm-font-close"></i><?php echo wc_kses_notice( $notice['notice'] ); ?></span>
    </li>
    <?php endforeach; ?>
</ul>
