<?php

namespace Voxel\Modules\Elementor\Atomic_Vx;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vx_Supported_Elements {

	/**
	 * Atomic (v4) element types where Voxel loops and visibility rules are applied on the frontend.
	 * Atomic widgets are always supported through the classic `widget` hooks.
	 */
	const ELEMENT_TYPES = [
		'e-div-block',
		'e-flexbox',
		'e-grid',
		'e-tabs',
		'e-tabs-menu',
		'e-tab',
		'e-tabs-content-area',
		'e-tab-content',
		'e-accordion',
		'e-accordion-item',
		'e-accordion-item-header',
		'e-accordion-item-title',
		'e-accordion-item-icon',
		'e-accordion-item-content',
	];

	public static function supports_loops_and_visibility( $element ): bool {
		if ( $element instanceof \Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base ) {
			return true;
		}

		return in_array( $element->get_type(), self::ELEMENT_TYPES, true );
	}
}
