<?php

namespace Voxel\Modules\Elementor\Atomic_Vx;

use Elementor\Modules\AtomicWidgets\PropTypes\Contracts\Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Union_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Utils\Prop_Types_Schema_Extender;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vx_Prop_Types_Mapping extends Prop_Types_Schema_Extender {

	public static function make(): self {
		return new static();
	}

	protected function get_extended_prop_type( Prop_Type $prop_type ): Prop_Type {
		$extended = parent::get_extended_prop_type( $prop_type );

		// Elementor components wrap props in an "overridable" type that validates against a copy of the
		// original prop type, captured before Voxel runs. Extend that copy too, otherwise marking a prop
		// that holds a Voxel tag as overridable fails validation on save.
		$overridable_class = '\Elementor\Modules\Components\PropTypes\Overridable_Prop_Type';
		if ( $extended instanceof Union_Prop_Type && class_exists( $overridable_class ) ) {
			$overridable = $extended->get_prop_type( $overridable_class::get_key() );
			if ( $overridable instanceof $overridable_class ) {
				$origin = $overridable->get_origin_prop_type();
				if ( $origin instanceof Prop_Type ) {
					$overridable->set_origin_prop_type( parent::get_extended_prop_type( $origin ) );
				}
			}
		}

		return $extended;
	}

	protected function get_prop_types_to_add( Prop_Type $prop_type ): array {
		if ( ! ( $prop_type instanceof Union_Prop_Type ) ) {
			return [];
		}

		if ( ! $prop_type->get_prop_type( 'dynamic' ) ) {
			return [];
		}

		if ( $prop_type->get_prop_type( Vx_Prop_Type::get_key() ) ) {
			return [];
		}

		$vx = Vx_Prop_Type::make();

		if ( $prop_type->get_prop_type( 'image-src' ) ) {
			$vx->meta( 'vx_image_src', true );
		}

		return [ $vx ];
	}
}
