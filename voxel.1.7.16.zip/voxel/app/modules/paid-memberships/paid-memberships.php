<?php

namespace Voxel\Modules\Paid_Memberships;

use \Voxel\Modules\Paid_Memberships\Membership\Base_Membership as Membership;

if ( ! defined('ABSPATH') ) {
	exit;
}

new Controllers\Paid_Memberships_Controller;

/**
 * Store the given membership details and announce the transition.
 *
 * Stripe delivers `invoice.paid` and `customer.subscription.updated` for the same
 * renewal within milliseconds of each other, and checkout adds a third concurrent
 * event on top, so several requests can try to apply the same transition at once.
 * Only the request that actually moves the stored value announces it, otherwise
 * customers receive the same "plan renewed" email more than once.
 */
function update_user_plan( int $user_id, array $details, ?bool $is_test_mode = null ) {
	$user = \Voxel\User::get( $user_id );
	if ( ! $user ) {
		return;
	}

	if ( $is_test_mode === null ) {
		$is_test_mode = \Voxel\is_test_mode();
	}

	$meta_key = $is_test_mode ? 'voxel:test_plan' : 'voxel:plan';

	$previous_value = \Voxel\get_site_specific_user_meta( $user->get_id(), $meta_key, true );
	$previous_value = is_string( $previous_value ) ? $previous_value : '';
	$new_value = wp_json_encode( $details );

	if ( $previous_value === $new_value ) {
		return;
	}

	if ( $previous_value === '' ) {
		// no stored plan to compare against, so claim the transition instead
		$claim_key = sprintf( 'plan:%d:%s:%s', $user->get_id(), $meta_key, md5( $new_value ) );
		if ( ! \Voxel\claim_once( $claim_key, 15 * MINUTE_IN_SECONDS ) ) {
			return;
		}

		\Voxel\update_site_specific_user_meta( $user->get_id(), $meta_key, wp_slash( $new_value ) );
	} else {
		$applied = \Voxel\update_site_specific_user_meta(
			$user->get_id(),
			$meta_key,
			wp_slash( $new_value ),
			$previous_value
		);

		if ( ! $applied ) {
			// either another request got there first, or the value we compared against
			// came from a stale object cache; retry once against the database
			wp_cache_delete( $user->get_id(), 'user_meta' );

			$stored_value = \Voxel\get_site_specific_user_meta( $user->get_id(), $meta_key, true );
			$stored_value = is_string( $stored_value ) ? $stored_value : '';

			if ( $stored_value === $previous_value || $stored_value === $new_value ) {
				return;
			}

			$applied = \Voxel\update_site_specific_user_meta(
				$user->get_id(),
				$meta_key,
				wp_slash( $new_value ),
				$stored_value
			);

			if ( ! $applied ) {
				return;
			}

			$previous_value = $stored_value;
		}
	}

	$previous_plan = Membership::from( (array) json_decode( $previous_value, true ) );
	$new_plan = Membership::from( $details );

	do_action(
		'voxel/paid_memberships/updated_user_plan',
		$new_plan,
		$previous_plan,
		$user
	);
}
