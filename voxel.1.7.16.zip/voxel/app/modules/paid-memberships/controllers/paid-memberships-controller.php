<?php

namespace Voxel\Modules\Paid_Memberships\Controllers;

use \Voxel\Modules\Paid_Memberships as Module;
use \Voxel\Modules\Paid_Memberships\Membership\Base_Membership as Membership;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Paid_Memberships_Controller extends \Voxel\Controllers\Base_Controller {

	protected function authorize() {
		return !! \Voxel\get('settings.addons.paid_memberships.enabled');
	}

	protected function dependencies() {
		\Voxel\use_ecommerce();

		new Backend\Backend_Controller;
		new Backend\Plan_Controller;
		new Backend\Member_Controller;

		new Frontend\Cart_Controller;
		new Frontend\Checkout_Controller;
		new Frontend\Order_Controller;
		new Frontend\Auth_Controller;
	}

	protected function hooks() {
		$this->on( 'after_setup_theme', '@register_product_type', -100 );
		$this->filter( 'voxel/post/get_field/voxel:membership_plan', '@register_product_field', 10, 3 );
		$this->filter( 'voxel/app-events/categories', '@register_app_event_categories' );
		$this->filter( 'voxel/app-events/register', '@register_app_events' );
		$this->on( 'elementor/widgets/register', '@register_widgets', 1000 );
		$this->on( 'voxel/paid_memberships/updated_user_plan', '@trigger_app_events', 10, 3 );
	}

	protected function register_product_type() {
		return \Voxel\Product_Type::register_virtual( [
			'settings' => [
				'key' => 'voxel:membership_plan',
				'label' => _x( 'Membership plan', 'paid members', 'voxel' ),
				'product_mode' => 'regular',
				'payments' => [
					'mode' => 'subscription',
				],
				'supports_marketplace' => false,
			],
			'modules' => [
				'base_price' => [
					'enabled' => true,
					'discount_price' => [
						'enabled' => true,
					],
				],
				'cart' => [
					'enabled' => false,
				],
				'custom_currency' => [
					'enabled' => true,
				],
			],
		] );
	}

	protected function register_product_field( $field, $post, $post_type ) {
		if ( $post_type->get_key() !== '_vx_catalog' ) {
			return null;
		}

		$catalog_category = get_post_meta( $post->get_id(), '_vx_catalog_category', true );
		if ( $catalog_category !== 'paid_memberships_price' ) {
			return null;
		}

		$plan_key = (string) get_post_meta( $post->get_id(), '_vx_plan_key', true );
		$price_key = (string) get_post_meta( $post->get_id(), '_vx_price_key', true );
		if ( empty( $plan_key ) || empty( $price_key ) ) {
			return null;
		}

		try {
			$price = \Voxel\Modules\Paid_Memberships\Price::get( $plan_key, $price_key );
		} catch ( \Exception $e ) {
			return null;
		}

		$field = new \Voxel\Post_Types\Fields\Product_Field( [
			'label' => 'Membership plan',
			'key' => 'voxel:membership_plan',
			'product-types' => [ 'voxel:membership_plan' ],
		] );

		$field->set_post( $post );
		$field->_set_value( [
			'product_type' => 'voxel:membership_plan',
			'enabled' => true,
			'base_price' => [
				'amount' => $price->get_amount(),
				'discount_amount' => $price->get_discount_amount(),
			],
			'subscription' => [
				'frequency' => $price->get_billing_frequency(),
				'unit' => $price->get_billing_interval(),
			],
			'currency' => $price->get_currency(),
		] );

		return $field;
	}

	protected function register_widgets() {
		$manager = \Elementor\Plugin::instance()->widgets_manager;
		$manager->register( new \Voxel\Modules\Paid_Memberships\Widgets\Pricing_Plans_Widget );
		$manager->register( new \Voxel\Modules\Paid_Memberships\Widgets\Current_Plan_Widget );
	}

	protected function register_app_event_categories( array $categories ): array {
		$categories['paid_members'] = [
			'key' => 'paid_members',
			'label' => 'Paid Members',
		];

		return $categories;
	}

	protected function register_app_events( array $events ): array {
		foreach ( [
			Module\App_Events\Plan_Activated_Event::class,
			Module\App_Events\Plan_Renewed_Event::class,
			Module\App_Events\Plan_Switched_Event::class,
			Module\App_Events\Plan_Canceled_Event::class,
		] as $event_class ) {
			$event = new $event_class;
			$events[ $event->get_key() ] = $event;
		}

		return $events;
	}

	protected function trigger_app_events( Membership $plan, Membership $previous_plan, \Voxel\User $user ) {
		if ( $plan->get_type() === 'order' ) {
			if ( $previous_plan->get_type() === 'order' && $plan->get_order_item_id() === $previous_plan->get_order_item_id() ) {
				if ( $plan->is_canceled() && ! $previous_plan->is_canceled() ) {
					(new Module\App_Events\Plan_Canceled_Event)->dispatch( $user, $plan );
				} elseif ( $this->should_dispatch_plan_renewed( $plan, $previous_plan ) ) {
					(new Module\App_Events\Plan_Renewed_Event)->dispatch( $user, $plan );
				}
			} else {
				if ( $plan->is_active() ) {
					if ( $previous_plan->get_type() !== 'order' ) {
						(new Module\App_Events\Plan_Activated_Event)->dispatch( $user, $plan );
					} else {
						if ( $previous_plan->is_canceled() ) {
							(new Module\App_Events\Plan_Activated_Event)->dispatch( $user, $plan );
						} else {
							(new Module\App_Events\Plan_Switched_Event)->dispatch( $user, $plan, $previous_plan );
						}
					}
				}
			}
		} else {
			if ( $previous_plan->get_type() === 'order' && ! $previous_plan->is_canceled() ) {
				(new Module\App_Events\Plan_Canceled_Event)->dispatch( $user, $previous_plan );
			}
		}
	}

	/**
	 * "Plan renewed" must reflect a confirmed successful renewal payment.
	 * Stripe can advance current_period_* (and Voxel may call invoice createPreview)
	 * before any charge is attempted — that must not trigger the renewed email.
	 */
	protected function should_dispatch_plan_renewed( Membership $plan, Membership $previous_plan ): bool {
		if ( ! $plan->is_active() || ! ( $plan instanceof Module\Membership\Membership_Order ) ) {
			return false;
		}

		$payment_method = $plan->get_payment_method();
		if ( $payment_method && $payment_method->get_type() === 'stripe_subscription' ) {
			return $this->should_dispatch_stripe_plan_renewed( $plan, $previous_plan );
		}

		$period_start = $plan->get_current_period_start();
		$previous_period_start = $previous_plan->get_current_period_start();

		return (
			$period_start !== null
			&& $previous_period_start !== null
			&& ( strtotime( $period_start ) > strtotime( $previous_period_start ) )
		);
	}

	protected function should_dispatch_stripe_plan_renewed(
		Module\Membership\Membership_Order $plan,
		Membership $previous_plan
	): bool {
		$invoice_id = $plan->get_latest_invoice_id();
		$status = $plan->get_latest_invoice_status();
		$billing_reason = $plan->get_latest_invoice_billing_reason();

		if ( ! $invoice_id || $status !== 'paid' || $billing_reason !== 'subscription_cycle' ) {
			return false;
		}

		if (
			str_ends_with( $invoice_id, '-DRAFT' )
			|| str_starts_with( $invoice_id, 'upcoming_in' )
		) {
			return false;
		}

		$previous_invoice_id = null;
		$previous_invoice_status = null;
		if ( $previous_plan instanceof Module\Membership\Membership_Order ) {
			$previous_invoice_id = $previous_plan->get_latest_invoice_id();
			$previous_invoice_status = $previous_plan->get_latest_invoice_status();
		}

		// Same renewal invoice transitioned from draft/open → paid.
		if ( $previous_invoice_id === $invoice_id && $previous_invoice_status !== 'paid' ) {
			return true;
		}

		// A new paid cycle invoice replaced the previous one.
		if ( $previous_invoice_id !== null && $previous_invoice_id !== $invoice_id ) {
			return true;
		}

		// Legacy memberships without stored invoice metadata: keep the period-start
		// heuristic, but only together with a confirmed paid cycle invoice.
		if ( $previous_invoice_id === null ) {
			$period_start = $plan->get_current_period_start();
			$previous_period_start = $previous_plan->get_current_period_start();

			return (
				$period_start !== null
				&& $previous_period_start !== null
				&& ( strtotime( $period_start ) > strtotime( $previous_period_start ) )
			);
		}

		return false;
	}

}
