<?php

namespace Voxel\Modules\Stripe_Payments\Controllers;

use \Voxel\Modules\Stripe_Payments as Module;
use \Voxel\Modules\Stripe_Payments\Payment_Methods;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Stripe_Payments_Controller extends \Voxel\Controllers\Base_Controller {

	/**
	 * Tracks whether existing webhook endpoints have been brought up to date with
	 * the current event list. Kept outside the `voxel:payments` option group, which
	 * is rewritten from a schema whenever payment settings are saved and would drop
	 * any key the schema doesn't declare.
	 */
	const WEBHOOK_SYNC_OPTION = 'voxel:stripe_webhook_events_synced';

	const WEBHOOK_SYNC_MAX_ATTEMPTS = 10;

	protected function dependencies() {
		new Backend\Settings_Controller;

		new Frontend\Webhooks_Controller;
		new Frontend\Order_Controller;
		new Frontend\Payments_Controller;
		new Frontend\Subscriptions_Controller;
	}

	protected function hooks() {
		$this->filter( 'voxel/product-types/payment-services', '@register_payment_service' );
		$this->filter( 'voxel/product-types/payment-methods', '@register_payment_methods' );
		$this->on( 'init', '@register_async_requests' );
		$this->on( 'admin_init', '@migrate_settings' );
		$this->on( 'admin_init', '@maybe_sync_webhook_events', 20 );
		$this->on( 'voxel/stripe/sync_webhook_events', '@sync_webhook_events' );
	}

	protected function register_async_requests() {
		// must be registered on frontend requests too, since the async request
		// handler runs through the `?vx=1` endpoint rather than wp-admin
		\Voxel\Utils\Async_Requests\Sync_Stripe_Webhook_Events::instance();
	}

	/**
	 * Hand the webhook event sync off to a separate request. Retrieving and updating
	 * an endpoint takes up to four round trips to Stripe, which must never run inline
	 * on an admin page: the Stripe client allows 30s to connect and 80s to respond,
	 * with no retries.
	 */
	protected function maybe_sync_webhook_events() {
		$state = $this->get_webhook_sync_state();
		if ( $state['live'] && $state['sandbox'] ) {
			return;
		}

		if ( $state['next_attempt_at'] > time() ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// `admin_init` also runs on admin-ajax.php, so without a claim every heartbeat
		// request would open another loopback connection until the sync completes
		if ( ! \Voxel\claim_once( 'stripe_webhook_events_sync', 5 * MINUTE_IN_SECONDS ) ) {
			return;
		}

		// count the attempt here rather than in the handler, so that a loopback request
		// which never arrives (blocked by the host, or unable to authenticate) still
		// backs off and eventually stops instead of retrying on every admin page load
		$state['attempts']++;

		if ( $state['attempts'] >= static::WEBHOOK_SYNC_MAX_ATTEMPTS ) {
			$state['live'] = true;
			$state['sandbox'] = true;
		} else {
			$state['next_attempt_at'] = time() + ( 15 * MINUTE_IN_SECONDS );
		}

		$this->set_webhook_sync_state( $state );

		if ( $state['live'] && $state['sandbox'] ) {
			return;
		}

		\Voxel\Utils\Async_Requests\Sync_Stripe_Webhook_Events::instance()->dispatch();
	}

	protected function sync_webhook_events() {
		$state = $this->get_webhook_sync_state();
		if ( $state['live'] && $state['sandbox'] ) {
			return;
		}

		$http_client = \Voxel\Vendor\Stripe\HttpClient\CurlClient::instance();
		$previous_timeout = $http_client->getTimeout();
		$previous_connect_timeout = $http_client->getConnectTimeout();
		$http_client->setTimeout( 15 );
		$http_client->setConnectTimeout( 5 );

		$failed = false;

		try {
			foreach ( [ 'live', 'sandbox' ] as $mode ) {
				if ( $state[ $mode ] ) {
					continue;
				}

				$endpoint_id = \Voxel\get( sprintf( 'payments.stripe.%s.webhook.id', $mode ) );
				if ( ! is_string( $endpoint_id ) || $endpoint_id === '' ) {
					// endpoints created from this point on already use the current event list
					$state[ $mode ] = true;
					continue;
				}

				$api_key = \Voxel\get( sprintf( 'payments.stripe.%s.api_key', $mode ) );
				if ( ! is_string( $api_key ) || $api_key === '' ) {
					$failed = true;
					continue;
				}

				try {
					$stripe = new \Voxel\Vendor\Stripe\StripeClient( [
						'api_key' => $api_key,
						'stripe_version' => Module\Stripe_Client::API_VERSION,
					] );

					Module\Stripe_Client::sync_webhook_endpoint( $stripe, $endpoint_id );
					$state[ $mode ] = true;
				} catch ( \Exception $e ) {
					$failed = true;

					\Voxel\log( sprintf(
						'Stripe %s webhook event sync failed: %s',
						$mode,
						$e->getMessage()
					) );
				}
			}
		} finally {
			$http_client->setTimeout( $previous_timeout );
			$http_client->setConnectTimeout( $previous_connect_timeout );
		}

		if ( $failed ) {
			// Stripe is unreachable or the key is wrong; wait a while before trying
			// again. The attempt counter is raised on dispatch, so this eventually
			// gives up quietly — the endpoint can still be recreated from the payments
			// settings screen by clearing its ID and secret.
			$state['next_attempt_at'] = time() + ( 6 * HOUR_IN_SECONDS );
		} else {
			$state['attempts'] = 0;
			$state['next_attempt_at'] = 0;
		}

		$this->set_webhook_sync_state( $state );

		// leftover from an earlier revision which stored this flag inside the
		// `voxel:payments` option group, where saving settings would wipe it
		if ( \Voxel\get( 'payments.stripe.migrations' ) !== null ) {
			\Voxel\set( 'payments.stripe.migrations', null );
		}
	}

	protected function get_webhook_sync_state(): array {
		$state = get_option( static::WEBHOOK_SYNC_OPTION );
		$state = is_array( $state ) ? $state : [];

		return [
			'live' => ! empty( $state['live'] ),
			'sandbox' => ! empty( $state['sandbox'] ),
			'attempts' => absint( $state['attempts'] ?? 0 ),
			'next_attempt_at' => absint( $state['next_attempt_at'] ?? 0 ),
		];
	}

	protected function set_webhook_sync_state( array $state ): void {
		update_option( static::WEBHOOK_SYNC_OPTION, $state, true );
	}

	protected function register_payment_service( $payment_services ) {
		$payment_services['stripe'] = new Module\Stripe_Payment_Service;

		return $payment_services;
	}

	protected function register_payment_methods( $payment_methods ) {
		$payment_methods['stripe_payment'] = Payment_Methods\Stripe_Payment::class;
		$payment_methods['stripe_subscription'] = Payment_Methods\Stripe_Subscription::class;

		return $payment_methods;
	}

	protected function migrate_settings() {
		if ( \Voxel\get('payments.stripe.__migrated') ) {
			return;
		}

		$product_settings = \Voxel\get('product_settings');

		if ( ! empty( $product_settings['stripe_payments'] ) ) {
			\Voxel\set( 'payments.stripe.payments', $product_settings['stripe_payments'] );
		}

		if ( ! empty( $product_settings['stripe_subscriptions'] ) ) {
			\Voxel\set( 'payments.stripe.subscriptions', $product_settings['stripe_subscriptions'] );
		}

		if ( ! empty( $product_settings['multivendor'] ) ) {
			\Voxel\set( 'payments.stripe.stripe_connect', $product_settings['multivendor'] );
		}

		if ( ! empty( $product_settings['tax_collection'] ) ) {
			\Voxel\set( 'payments.stripe.tax_collection', $product_settings['tax_collection'] );
		}

		$stripe_settings = \Voxel\get('settings.stripe');
		if ( ! empty( $stripe_settings ) ) {
			\Voxel\set( 'payments.provider', 'stripe' );

			if ( isset( $stripe_settings['test_mode'] ) ) {
				\Voxel\set( 'payments.stripe.mode', $stripe_settings['test_mode'] ? 'sandbox' : 'live' );
			}

			if ( ! empty( $stripe_settings['currency'] ) ) {
				\Voxel\set( 'payments.stripe.currency', $stripe_settings['currency'] );
			}

			if ( ! empty( $stripe_settings['secret'] ) ) {
				\Voxel\set( 'payments.stripe.live.api_key', $stripe_settings['secret'] );
			}

			if ( ! empty( $stripe_settings['test_secret'] ) ) {
				\Voxel\set( 'payments.stripe.sandbox.api_key', $stripe_settings['test_secret'] );
			}

			if ( ! empty( $stripe_settings['webhooks']['live'] ) ) {
				\Voxel\set( 'payments.stripe.live.webhook', $stripe_settings['webhooks']['live'] );
			}

			if ( ! empty( $stripe_settings['webhooks']['test'] ) ) {
				\Voxel\set( 'payments.stripe.sandbox.webhook', $stripe_settings['webhooks']['test'] );
			}

			if ( ! empty( $stripe_settings['webhooks']['local']['enabled'] ) && ! empty( $stripe_settings['webhooks']['local']['secret'] ) ) {
				\Voxel\set( 'payments.stripe.sandbox.webhook.secret', $stripe_settings['webhooks']['local']['secret'] );
			}

			if ( ! empty( $stripe_settings['portal']['live_config_id'] ) ) {
				$portal = $stripe_settings['portal'];
				$portal['id'] = $stripe_settings['portal']['live_config_id'];
				unset( $portal['live_config_id'] );
				unset( $portal['test_config_id'] );

				\Voxel\set( 'payments.stripe.live.customer_portal', $portal );
			}

			if ( ! empty( $stripe_settings['portal']['test_config_id'] ) ) {
				$portal = $stripe_settings['portal'];
				$portal['id'] = $stripe_settings['portal']['test_config_id'];
				unset( $portal['live_config_id'] );
				unset( $portal['test_config_id'] );

				\Voxel\set( 'payments.stripe.sandbox.customer_portal', $portal );
			}

			if ( ! empty( $stripe_settings['webhooks']['live_connect'] ) ) {
				\Voxel\set( 'payments.stripe.stripe_connect.webhook.live', $stripe_settings['webhooks']['live_connect'] );
			}

			if ( ! empty( $stripe_settings['webhooks']['test_connect'] ) ) {
				\Voxel\set( 'payments.stripe.stripe_connect.webhook.sandbox', $stripe_settings['webhooks']['test_connect'] );
			}
		}

		if ( ! empty( \Voxel\get('product_settings.promotions') ) ) {
			\Voxel\set( 'paid_listings.settings.promotions', \Voxel\get('product_settings.promotions') );
			\Voxel\set( 'product_settings.promotions', null );
		}

		\Voxel\set( 'payments.stripe.__migrated', true );

		\Voxel\set( 'product_settings.stripe_payments', null );
		\Voxel\set( 'product_settings.stripe_subscriptions', null );
		\Voxel\set( 'product_settings.multivendor', null );
		\Voxel\set( 'product_settings.tax_collection', null );
		\Voxel\set( 'settings.stripe', null );
		\Voxel\set( 'settings.addons.paid_memberships.enabled', true );
	}

}
