<?php

namespace Voxel\Modules\Stripe_Payments;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Stripe_Client {

	private static $liveClient, $testClient;

	const API_VERSION = '2025-07-30.basil';

	const WEBHOOK_EVENTS = [
		'customer.subscription.created',
		'customer.subscription.updated',
		'customer.subscription.deleted',
		'invoice.paid',
		'checkout.session.completed',
		'checkout.session.async_payment_succeeded',
		'checkout.session.async_payment_failed',
		'payment_intent.amount_capturable_updated',
		'payment_intent.canceled',
		'payment_intent.succeeded',
		'charge.captured',
		'charge.refunded',
		'charge.refund.updated',
	];

	const CONNECT_WEBHOOK_EVENTS = [
		'account.updated',
	];

	/**
	 * Resolve the subscription ID from an Invoice (Basil+ uses parent.subscription_details).
	 */
	public static function get_subscription_id_from_invoice( $invoice ): ?string {
		$parent = $invoice->parent ?? null;
		if ( is_object( $parent ) && ( $parent->type ?? null ) === 'subscription_details' ) {
			$subscription = $parent->subscription_details->subscription ?? null;
			if ( is_string( $subscription ) && $subscription !== '' ) {
				return $subscription;
			}
			if ( is_object( $subscription ) && ! empty( $subscription->id ) ) {
				return $subscription->id;
			}
		}

		// Legacy pre-Basil field (may still appear on older event payloads).
		$legacy = $invoice->subscription ?? null;
		if ( is_string( $legacy ) && $legacy !== '' ) {
			return $legacy;
		}
		if ( is_object( $legacy ) && ! empty( $legacy->id ) ) {
			return $legacy->id;
		}

		return null;
	}

	public static function sync_webhook_endpoint(
		\Voxel\Vendor\Stripe\StripeClient $stripe,
		string $endpoint_id,
		?string $url = null
	) {
		$endpoint = $stripe->webhookEndpoints->retrieve( $endpoint_id, [] );
		$current_events = array_values( (array) $endpoint->enabled_events );

		$params = [];
		if ( ! empty( static::get_missing_webhook_events( $current_events ) ) ) {
			$params['enabled_events'] = static::merge_webhook_events( $current_events );
		}

		if ( $url !== null && $endpoint->url !== $url ) {
			$params['url'] = $url;
		}

		if ( ! empty( $params ) ) {
			$endpoint = $stripe->webhookEndpoints->update( $endpoint_id, $params );
		}

		return $endpoint;
	}

	/**
	 * Events the endpoint needs but doesn't listen for yet. Compared as a set, so
	 * an endpoint that already covers everything is never updated just because it
	 * lists the same events in a different order.
	 */
	public static function get_missing_webhook_events( array $current_events ): array {
		if ( in_array( '*', $current_events, true ) ) {
			return [];
		}

		return array_values( array_diff( static::WEBHOOK_EVENTS, $current_events ) );
	}

	public static function merge_webhook_events( array $current_events ): array {
		if ( in_array( '*', $current_events, true ) ) {
			return $current_events;
		}

		return array_values( array_unique( array_merge(
			$current_events,
			static::WEBHOOK_EVENTS
		) ) );
	}

	public static function is_test_mode() {
		return \Voxel\get( 'payments.stripe.mode', 'sandbox' ) === 'sandbox';
	}

	public static function getClient() {
		return static::is_test_mode()
			? static::getTestClient()
			: static::getLiveClient();
	}

	public static function get_client() {
		return static::is_test_mode() ? static::getTestClient() : static::getLiveClient();
	}

	public static function get_live_client() {
		if ( is_null( static::$liveClient ) ) {
			\Voxel\Vendor\Stripe\Stripe::setApiKey( \Voxel\get( 'payments.stripe.live.api_key', '' ) );
			\Voxel\Vendor\Stripe\Stripe::setApiVersion( static::API_VERSION );
			static::$liveClient = new \Voxel\Vendor\Stripe\StripeClient( [
				'api_key' => \Voxel\get( 'payments.stripe.live.api_key', '' ),
				'stripe_version' => static::API_VERSION,
			] );
		}

		return static::$liveClient;
	}

	public static function getLiveClient() {
		return static::get_live_client();
	}

	public static function get_test_client() {
		if ( is_null( static::$testClient ) ) {
			\Voxel\Vendor\Stripe\Stripe::setApiKey( \Voxel\get( 'payments.stripe.sandbox.api_key', '' ) );
			\Voxel\Vendor\Stripe\Stripe::setApiVersion( static::API_VERSION );
			static::$testClient = new \Voxel\Vendor\Stripe\StripeClient( [
				'api_key' => \Voxel\get( 'payments.stripe.sandbox.api_key', '' ),
				'stripe_version' => static::API_VERSION,
			] );
		}

		return static::$testClient;
	}

	public static function getTestClient() {
		return static::get_test_client();
	}

	public static function base_dashboard_url( $path = '' ) {
		$url = 'https://dashboard.stripe.com/';
		$path = ltrim( $path, "/\\" );
		return $url.$path;
	}

	public static function dashboard_url( $path = '' ) {
		$url = static::base_dashboard_url();
		if ( static::is_test_mode() ) {
			$url .= 'test/';
		}

		$path = ltrim( $path, "/\\" );
		return $url.$path;
	}

	public static function get_portal_configuration_id() {
		return \Voxel\Modules\Stripe_Payments\Stripe_Client::is_test_mode()
			? \Voxel\get( 'payments.stripe.sandbox.customer_portal.id' )
			: \Voxel\get( 'payments.stripe.live.customer_portal.id' );
	}

	// @link https://docs.stripe.com/payments/checkout/taxes?tax-calculation=tax-rates#dynamic-tax-rates
	public static function get_supported_countries_for_dynamic_tax_rates(): array {
		return [
			'US', 'GB', 'AU', 'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK',
			'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LT',
			'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE',
		];
	}
}
