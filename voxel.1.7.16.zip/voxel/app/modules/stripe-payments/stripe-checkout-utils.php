<?php

namespace Voxel\Modules\Stripe_Payments;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Stripe_Checkout_Utils {

	public static function is_populate_billing_from_shipping_enabled(): bool {
		return (bool) \Voxel\get( 'payments.stripe.checkout.populate_billing_from_shipping', false );
	}

	public static function populate_customer_billing_from_shipping( string $customer_id, \Voxel\Product_Types\Orders\Order $order, string $checkout_mode = 'payment' ): void {
		if ( ! static::is_populate_billing_from_shipping_enabled() ) {
			return;
		}

		if ( ! $order->should_handle_shipping() ) {
			return;
		}

		$shipping = static::get_shipping_address( $order );
		if ( $shipping === null ) {
			return;
		}

		$address = static::build_stripe_address( $shipping );
		if ( empty( $address['country'] ) ) {
			return;
		}

		$name = static::build_name( $shipping );
		$phone = ! empty( $shipping['phone'] ) ? $shipping['phone'] : null;
		$stripe_shipping = static::build_stripe_shipping( $shipping, $name, $phone );

		$update = [];

		if ( $name !== '' ) {
			$update['name'] = $name;
		}

		if ( $phone !== null ) {
			$update['phone'] = $phone;
		}

		if ( ! empty( $address ) ) {
			$update['address'] = $address;
		}

		if ( $stripe_shipping !== null ) {
			$update['shipping'] = $stripe_shipping;
		}

		if ( empty( $update ) ) {
			return;
		}

		$stripe = Stripe_Client::getClient();
		$stripe->customers->update( $customer_id, $update );

		if ( static::has_complete_address( $shipping ) ) {
			$billing_details = [
				'name' => $name !== '' ? $name : null,
				'phone' => $phone,
				'email' => $order->get_customer()->get_email(),
				'address' => $address,
			];

			static::update_prefill_payment_method_billing_details( $customer_id, $billing_details, $checkout_mode );
		}
	}

	public static function apply_populate_billing_checkout_args( array &$args, \Voxel\Product_Types\Orders\Order $order ): void {
		if ( ! static::is_populate_billing_from_shipping_enabled() ) {
			return;
		}

		if ( ! $order->should_handle_shipping() ) {
			return;
		}

		$shipping = static::get_shipping_address( $order );
		if ( $shipping === null || ! static::has_complete_address( $shipping ) ) {
			return;
		}

		// Hosted Checkout only prefills billing fields from saved card billing_details, or
		// from customer.address when billing_address_collection is required. With automatic
		// tax and billing collection set to auto, only the country field may appear.
		$args['billing_address_collection'] = 'required';

		if ( ! isset( $args['customer_update'] ) || ! is_array( $args['customer_update'] ) ) {
			$args['customer_update'] = [];
		}

		$args['customer_update']['address'] = 'auto';
		$args['customer_update']['name'] = 'auto';

		if ( ( $args['mode'] ?? '' ) === 'subscription' ) {
			$args['customer_update']['shipping'] = 'auto';
		}
	}

	protected static function get_shipping_address( \Voxel\Product_Types\Orders\Order $order ): ?array {
		$shipping = $order->get_shipping_address();
		if ( ! $shipping || empty( $shipping['country'] ) ) {
			return null;
		}

		return $shipping;
	}

	protected static function build_name( array $shipping ): string {
		return trim( ( $shipping['first_name'] ?? '' ) . ' ' . ( $shipping['last_name'] ?? '' ) );
	}

	protected static function build_stripe_address( array $shipping ): array {
		$address = [];

		if ( ! empty( $shipping['address'] ) ) {
			$address['line1'] = $shipping['address'];
		}

		if ( ! empty( $shipping['address_2'] ) ) {
			$address['line2'] = $shipping['address_2'];
		}

		if ( ! empty( $shipping['city'] ) ) {
			$address['city'] = $shipping['city'];
		}

		if ( ! empty( $shipping['state'] ) ) {
			$address['state'] = $shipping['state'];
		}

		if ( ! empty( $shipping['zip'] ) ) {
			$address['postal_code'] = $shipping['zip'];
		}

		if ( ! empty( $shipping['country'] ) ) {
			$address['country'] = strtoupper( $shipping['country'] );
		}

		return $address;
	}

	protected static function build_stripe_shipping( array $shipping, string $name, ?string $phone ): ?array {
		$address = static::build_stripe_address( $shipping );
		if ( empty( $address['line1'] ) || empty( $address['country'] ) ) {
			return null;
		}

		$stripe_shipping = [
			'address' => $address,
		];

		if ( $name !== '' ) {
			$stripe_shipping['name'] = $name;
		}

		if ( $phone !== null ) {
			$stripe_shipping['phone'] = $phone;
		}

		return $stripe_shipping;
	}

	protected static function has_complete_address( array $shipping ): bool {
		return ! empty( trim( $shipping['address'] ?? '' ) )
			&& ! empty( trim( $shipping['city'] ?? '' ) )
			&& ! empty( trim( $shipping['zip'] ?? '' ) )
			&& ! empty( trim( $shipping['country'] ?? '' ) );
	}

	protected static function update_prefill_payment_method_billing_details( string $customer_id, array $billing_details, string $checkout_mode ): void {
		$stripe = Stripe_Client::getClient();
		$payment_method_id = null;

		try {
			$customer = $stripe->customers->retrieve( $customer_id );

			if ( $checkout_mode === 'subscription' && ! empty( $customer->invoice_settings->default_payment_method ) ) {
				$payment_method_id = $customer->invoice_settings->default_payment_method;
			}
		} catch ( \Exception $e ) {
			// Continue with fallback lookup.
		}

		if ( $payment_method_id === null ) {
			$payment_methods = $stripe->paymentMethods->all( [
				'customer' => $customer_id,
				'type' => 'card',
				'limit' => 100,
			] );

			if ( empty( $payment_methods->data ) ) {
				return;
			}

			$most_recent = $payment_methods->data[0];
			foreach ( $payment_methods->data as $payment_method ) {
				if ( $payment_method->created > $most_recent->created ) {
					$most_recent = $payment_method;
				}
			}

			$payment_method_id = $most_recent->id;
		}

		try {
			$stripe->paymentMethods->update( $payment_method_id, [
				'billing_details' => $billing_details,
			] );
		} catch ( \Exception $e ) {
			// Checkout can still prefill from customer.address when billing is required.
		}
	}
}
