<?php

namespace Voxel\Events\Products\Orders;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Vendor_Marked_As_Paid_Event extends Base_Order_Event {

	static $default_enabled = [
		'customer' => true,
		'vendor' => false,
		'admin' => false,
	];

	public function get_key(): string {
		return 'products/orders/vendor:marked_as_paid';
	}

	public function get_label(): string {
		return 'Offline payment: Vendor marked order as paid';
	}

	public static function get_customer_subject() {
		return 'Your order has been marked as paid.';
	}

	public static function get_customer_message() {
		return <<<HTML
		Order #@order(:id): Your order has been marked as paid and is now complete.
		<a href="@order(:link)">View order</a>
		HTML;
	}

	public static function get_vendor_subject() {
		return 'Order #@order(:id) has been marked as paid.';
	}

	public static function get_vendor_message() {
		return <<<HTML
		Order #@order(:id) has been marked as paid.
		<a href="@order(:link)">View order</a>
		HTML;
	}

	public static function get_admin_subject() {
		return 'Order #@order(:id) has been marked as paid.';
	}

	public static function get_admin_message() {
		return <<<HTML
		Order #@order(:id) has been marked as paid.
		<a href="@order(:link)">View order</a>
		HTML;
	}
}
