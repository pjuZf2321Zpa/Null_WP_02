<?php

namespace Voxel\Events\Products\Orders;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Vendor_Marked_Payment_Failed_Event extends Base_Order_Event {

	static $default_enabled = [
		'customer' => true,
		'vendor' => false,
		'admin' => false,
	];

	public function get_key(): string {
		return 'products/orders/vendor:payment_failed';
	}

	public function get_label(): string {
		return 'Offline payment: Vendor marked payment failed';
	}

	public static function get_customer_subject() {
		return 'Payment failed for order #@order(:id).';
	}

	public static function get_customer_message() {
		return <<<HTML
		Order #@order(:id): Payment was not completed, and your order has been canceled.
		<a href="@order(:link)">View order</a>
		HTML;
	}

	public static function get_vendor_subject() {
		return 'Payment failed for order #@order(:id).';
	}

	public static function get_vendor_message() {
		return <<<HTML
		Payment failed for order #@order(:id).
		<a href="@order(:link)">View order</a>
		HTML;
	}

	public static function get_admin_subject() {
		return 'Payment failed for order #@order(:id).';
	}

	public static function get_admin_message() {
		return <<<HTML
		Payment failed for order #@order(:id).
		<a href="@order(:link)">View order</a>
		HTML;
	}
}
