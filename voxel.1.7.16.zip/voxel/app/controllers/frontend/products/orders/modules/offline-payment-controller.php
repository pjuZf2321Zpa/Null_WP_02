<?php

namespace Voxel\Controllers\Frontend\Products\Orders\Modules;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Offline_Payment_Controller extends \Voxel\Controllers\Base_Controller {

	protected function hooks() {
		$this->filter( 'voxel/orders/view_order/components', '@register_offline_payment_component', 10, 2 );
		$this->on( 'voxel_ajax_products.single_order.offline_payment.mark_payment_received', '@mark_payment_received' );
	}

	protected function register_offline_payment_component( $components, $order ) {
		if ( $order->get_payment_method_key() !== 'offline_payment' ) {
			return $components;
		}

		if ( $order->get_status() !== \Voxel\ORDER_PENDING_PAYMENT ) {
			return $components;
		}

		$status_config = \Voxel\Product_Types\Orders\Order::get_status_config()[ \Voxel\ORDER_PENDING_PAYMENT ] ?? [];

		$components[] = [
			'type' => 'order-offline-payment-details',
			'src' => \Voxel\get_esm_src('order-offline-payment-details.js'),
			'data' => [
				'status' => [
					'key' => $order->get_status(),
					'updated_at' => $order->get_status_last_updated_for_display(),
					'label' => $order->get_status_label(),
					'long_label' => _x( 'Awaiting payment confirmation', 'single order', 'voxel' ),
					'class' => $status_config['class'] ?? 'vx-orange',
				],
				'l10n' => [
					'mark_payment_received' => _x( 'Mark as Paid', 'single order', 'voxel' ),
					'decline' => _x( 'Cancel order', 'order actions', 'voxel' ),
				],
			],
		];

		return $components;
	}

	protected function mark_payment_received() {
		try {
			$payment_method = $this->authorize_vendor_payment_action();
			$payment_method->mark_payment_received();

			return wp_send_json( [
				'success' => true,
			] );
		} catch ( \Exception $e ) {
			return wp_send_json( [
				'success' => false,
				'message' => $e->getMessage(),
				'code' => $e->getCode(),
			] );
		}
	}

	protected function authorize_vendor_payment_action(): \Voxel\Product_Types\Payment_Methods\Offline_Payment {
		if ( ( $_SERVER['REQUEST_METHOD'] ?? null ) !== 'POST' ) {
			throw new \Exception( __( 'Could not process request', 'voxel' ), 99 );
		}

		\Voxel\verify_nonce( $_REQUEST['_wpnonce'] ?? '', 'vx_orders' );

		$order_id = absint( $_REQUEST['order_id'] ?? null );
		if ( ! $order_id ) {
			throw new \Exception( _x( 'Missing order id.', 'orders', 'voxel' ), 107 );
		}

		$order = \Voxel\Product_Types\Orders\Order::get( $order_id );
		if ( ! ( $order && $order->get_status() === \Voxel\ORDER_PENDING_PAYMENT && $order->get_payment_method_key() === 'offline_payment' ) ) {
			throw new \Exception( _x( 'Permission check failed.', 'orders', 'voxel' ), 108 );
		}

		$current_user = \Voxel\get_current_user();
		if ( ! ( current_user_can( 'administrator' ) || ( $current_user && $current_user->is_vendor_of( $order->get_id() ) ) ) ) {
			throw new \Exception( _x( 'Permission check failed.', 'orders', 'voxel' ), 111 );
		}

		$payment_method = $order->get_payment_method();
		if ( ! ( $payment_method instanceof \Voxel\Product_Types\Payment_Methods\Offline_Payment ) ) {
			throw new \Exception( _x( 'Permission check failed.', 'orders', 'voxel' ), 108 );
		}

		return $payment_method;
	}
}
