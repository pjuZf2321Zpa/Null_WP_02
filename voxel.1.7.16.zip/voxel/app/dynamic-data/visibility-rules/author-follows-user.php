<?php

namespace Voxel\Dynamic_Data\Visibility_Rules;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Author_Follows_User extends Base_Visibility_Rule {

	public function get_type(): string {
		return 'author:follows_user';
	}

	public function get_label(): string {
		return _x( 'Author follows user', 'visibility rules', 'voxel-backend' );
	}

	protected function define_args(): void {
		$this->define_arg( 'user_id', [
			'type' => 'text',
			'label' => _x( 'User ID', 'visibility rules', 'voxel-backend' ),
			'description' => 'Leave empty for current user',
			'placeholder' => 'Current user',
		] );
	}

	public function evaluate(): bool {
		$author = \Voxel\get_current_author();
		if ( ! $author ) {
			return false;
		}

		if ( is_numeric( $this->get_arg('user_id') ) ) {
			return $author->follows_user( $this->get_arg('user_id') );
		} else {
			$current_user = \Voxel\current_user();
			if ( ! $current_user ) {
				return false;
			}

			return $author->follows_user( $current_user->get_id() );
		}
	}
}
