<?php

namespace Voxel\Dynamic_Data\Data_Groups\Orders;

use \Voxel\Dynamic_Data\Tag as Tag;
use \Voxel\Dynamic_Data\Data_Types\Base_Data_Type as Base_Data_Type;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Order_Data_Group extends \Voxel\Dynamic_Data\Data_Groups\Base_Data_Group {

	public function get_type(): string {
		return 'order';
	}

	protected static $instances = [];
	public static function get( \Voxel\Product_Types\Orders\Order $order ): self {
		if ( ! array_key_exists( $order->get_id(), static::$instances ) ) {
			static::$instances[ $order->get_id() ] = new static( $order );
		}

		return static::$instances[ $order->get_id() ];
	}

	public $order;
	protected function __construct( \Voxel\Product_Types\Orders\Order $order ) {
		$this->order = $order;
	}

	protected $_shipping_address_resolved = false;
	protected $_shipping_address_cache = null;
	protected function _get_shipping_address(): ?array {
		if ( ! $this->_shipping_address_resolved ) {
			$this->_shipping_address_resolved = true;

			$address = $this->order->get_shipping_address();
			if ( ! $address ) {
				$parent_order = $this->order->get_parent_order();
				if ( $parent_order ) {
					$address = $parent_order->get_shipping_address();
				}
			}

			$this->_shipping_address_cache = $address;
		}

		return $this->_shipping_address_cache;
	}

	protected function properties(): array {
		return [
			'id' => Tag::Number('ID')->render( function() {
				return $this->order->get_id();
			} ),
			'created_at' => Tag::Date('Date created')->render( function() {
				$created_at = $this->order->get_created_at();
				if ( $created_at === null ) {
					return '';
				}

				// Orders store created_at in UTC; date tags expect site-local time
				// (same convention as @site(date), @post(date_created), membership start_date).
				return date( 'Y-m-d H:i:s', $created_at->getTimestamp() + (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) );
			} ),
			'link' => Tag::URL('Permalink')->render( function() {
				return $this->order->get_link();
			} ),
			'pricing' => Tag::Object('Pricing')->properties( function() {
				return [
					'total' => Tag::String('Total amount')->render( function() {
						$total = $this->order->get_total();
						if ( is_numeric( $total ) ) {
							return \Voxel\currency_format( $total, $this->order->get_currency(), false );
						}
					} ),
					'subtotal' => Tag::String('Subtotal')->render( function() {
						$subtotal = $this->order->get_subtotal();
						if ( is_numeric( $subtotal ) ) {
							return \Voxel\currency_format( $subtotal, $this->order->get_currency(), false );
						}
					} ),
					'tax' => Tag::String('Tax amount')->render( function() {
						$tax = $this->order->get_tax_amount();
						if ( is_numeric( $tax ) ) {
							return \Voxel\currency_format( $tax, $this->order->get_currency(), false );
						}
					} ),
					'discount' => Tag::String('Discount amount')->render( function() {
						$discount = $this->order->get_discount_amount();
						if ( is_numeric( $discount ) ) {
							return \Voxel\currency_format( $discount, $this->order->get_currency(), false );
						}
					} ),
					'shipping' => Tag::String('Shipping amount')->render( function() {
						$shipping = $this->order->get_shipping_amount();
						if ( is_numeric( $shipping ) ) {
							return \Voxel\currency_format( $shipping, $this->order->get_currency(), false );
						}
					} ),
				];
			} ),
			'status' => Tag::Object('Status')->properties( function() {
				return [
					'key' => Tag::String('Key')->render( function() {
						return $this->order->get_status();
					} ),
					'label' => Tag::String('Label')->render( function() {
						return $this->order->get_status_label();
					} ),
				];
			} ),
			'shipping' => Tag::Object('Shipping')->properties( function() {
				return [
					'status' => Tag::Object('Shipping status')->properties( function() {
						return [
							'key' => Tag::String('Key')->render( function() {
								if ( $this->order->should_handle_shipping() ) {
									return $this->order->get_shipping_status();
								}
							} ),
							'label' => Tag::String('Label')->render( function() {
								if ( $this->order->should_handle_shipping() ) {
									return $this->order->get_shipping_status_label();
								}
							} ),
						];
					} ),
					'tracking_link' => Tag::URL('Tracking link')->render( function() {
						if ( $this->order->should_handle_shipping() ) {
							return $this->order->get_details('shipping.tracking_details.link');
						}
					} ),
					'shipping_rate' => Tag::Object('Shipping rate')->properties( function() {
						return [
							'label' => Tag::String('Label')->render( function() {
								if ( $this->order->should_handle_shipping() ) {
									if ( $this->order->get_details('shipping.method') === 'vendor_rates' ) {
										if ( $this->order->has_vendor() ) {
											$shipping_rate = $this->order->get_shipping_rate_for_vendor( $this->order->get_vendor_id() );
										} else {
											$shipping_rate = $this->order->get_shipping_rate_for_platform();
										}
									} else {
										$shipping_rate = $this->order->get_shipping_rate();
									}

									if ( $shipping_rate ) {
										return $shipping_rate->get_label();
									}
								}
							} ),
							'delivery_estimate' => Tag::String('Delivery estimate')->render( function() {
								if ( $this->order->should_handle_shipping() ) {
									if ( $this->order->get_details('shipping.method') === 'vendor_rates' ) {
										if ( $this->order->has_vendor() ) {
											$shipping_rate = $this->order->get_shipping_rate_for_vendor( $this->order->get_vendor_id() );
										} else {
											$shipping_rate = $this->order->get_shipping_rate_for_platform();
										}
									} else {
										$shipping_rate = $this->order->get_shipping_rate();
									}

									if ( $shipping_rate ) {
										return $shipping_rate->get_delivery_estimate_message();
									}
								}
							} ),
						];
					} ),
					'address' => Tag::Object('Shipping address')->properties( function() {
						return [
							'first_name' => Tag::String('First name')->render( function() {
								if ( ! $this->order->should_handle_shipping() ) {
									return null;
								}

								$address = $this->_get_shipping_address();
								return $address['first_name'] ?? null;
							} ),
							'last_name' => Tag::String('Last name')->render( function() {
								if ( ! $this->order->should_handle_shipping() ) {
									return null;
								}

								$address = $this->_get_shipping_address();
								return $address['last_name'] ?? null;
							} ),
							'country' => Tag::Object('Country')->properties( function() {
								return [
									'key' => Tag::String('Country code')->render( function() {
										if ( ! $this->order->should_handle_shipping() ) {
											return null;
										}

										$address = $this->_get_shipping_address();
										return $address['country'] ?? null;
									} ),
									'label' => Tag::String('Country name')->render( function() {
										if ( ! $this->order->should_handle_shipping() ) {
											return null;
										}

										$address = $this->_get_shipping_address();
										$country_code = $address['country'] ?? null;
										if ( ! $country_code ) {
											return null;
										}

										$country = \Voxel\Utils\Data\Countries_With_Subdivisions::all()[ strtoupper( $country_code ) ] ?? null;
										return $country['name'] ?? $country_code;
									} ),
								];
							} ),
							'state' => Tag::Object('State')->properties( function() {
								return [
									'key' => Tag::String('State code')->render( function() {
										if ( ! $this->order->should_handle_shipping() ) {
											return null;
										}

										$address = $this->_get_shipping_address();
										return $address['state'] ?? null;
									} ),
									'label' => Tag::String('State name')->render( function() {
										if ( ! $this->order->should_handle_shipping() ) {
											return null;
										}

										$address = $this->_get_shipping_address();
										$country_code = $address['country'] ?? null;
										$state_code = $address['state'] ?? null;
										if ( ! $state_code ) {
											return null;
										}

										if ( $country_code ) {
											$country = \Voxel\Utils\Data\Countries_With_Subdivisions::all()[ strtoupper( $country_code ) ] ?? null;
											return $country['states'][ $state_code ]['name'] ?? $state_code;
										}

										return $state_code;
									} ),
								];
							} ),
							'line' => Tag::String('Street address')->render( function() {
								if ( ! $this->order->should_handle_shipping() ) {
									return null;
								}

								$address = $this->_get_shipping_address();
								return $address['address'] ?? null;
							} ),
							'line2' => Tag::String('Address line 2')->render( function() {
								if ( ! $this->order->should_handle_shipping() ) {
									return null;
								}

								$address = $this->_get_shipping_address();
								return $address['address_2'] ?? null;
							} ),
							'city' => Tag::String('City')->render( function() {
								if ( ! $this->order->should_handle_shipping() ) {
									return null;
								}

								$address = $this->_get_shipping_address();
								return $address['city'] ?? null;
							} ),
							'phone' => Tag::String('Phone number')->render( function() {
								if ( ! $this->order->should_handle_shipping() ) {
									return null;
								}

								$address = $this->_get_shipping_address();
								return $address['phone'] ?? null;
							} ),
							'zip' => Tag::String('Postal code')->render( function() {
								if ( ! $this->order->should_handle_shipping() ) {
									return null;
								}

								$address = $this->_get_shipping_address();
								return $address['zip'] ?? null;
							} ),
							'formatted' => Tag::String('Formatted address')->render( function() {
								if ( ! $this->order->should_handle_shipping() ) {
									return null;
								}

								$address = $this->_get_shipping_address();
								if ( ! $address ) {
									return null;
								}

								$name = trim( ( $address['first_name'] ?? '' ).' '.( $address['last_name'] ?? '' ) );

								$country_code = $address['country'] ?? null;
								$state_code = $address['state'] ?? null;
								$country_name = $country_code;
								$state_name = $state_code;

								if ( $country_code ) {
									$country = \Voxel\Utils\Data\Countries_With_Subdivisions::all()[ strtoupper( $country_code ) ] ?? null;
									$country_name = $country['name'] ?? $country_code;

									if ( $state_code ) {
										$state_name = $country['states'][ $state_code ]['name'] ?? $state_code;
									}
								}

								$line2 = trim( implode( ' ', array_filter( [
									$address['city'] ?? null,
									$address['zip'] ?? null,
									$state_name,
								] ) ) );

								$parts = array_filter( [
									$name,
									$address['address'] ?? null,
									$address['address_2'] ?? null,
									$line2,
									$country_name,
									$address['phone'] ?? null,
								], function( $value ) {
									return $value !== null && $value !== '';
								} );

								return implode( ', ', $parts );
							} ),
						];
					} ),
				];
			} ),
			'customer_notes' => Tag::String('Order notes')->render( function() {
				return $this->order->get_order_notes();
			} ),
		];
	}

	protected function aliases(): array {
		return [
			':id' => 'id',
			':created_at' => 'created_at',
			':link' => 'link',
			':pricing' => 'pricing',
			':status' => 'status',
			':shipping' => 'shipping',
			':customer_notes' => 'customer_notes',
		];
	}

	public static function mock(): self {
		return new static( \Voxel\Product_Types\Orders\Order::mock() );
	}
}