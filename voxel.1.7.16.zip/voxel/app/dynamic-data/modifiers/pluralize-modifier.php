<?php

namespace Voxel\Dynamic_Data\Modifiers;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Pluralize_Modifier extends Base_Modifier {

	public function get_label(): string {
		return _x( 'Pluralize', 'modifiers', 'voxel-backend' );
	}

	public function get_key(): string {
		return 'pluralize';
	}

	public function expects(): array {
		return [ static::TYPE_NUMBER ];
	}

	public function get_description(): string {
		return _x( 'Outputs the value followed by the singular or plural label (e.g. 1 place, 2 places). Singular is used when the value equals 1.', 'modifiers', 'voxel-backend' );
	}

	protected function define_args(): void {
		$this->define_arg( [
			'type' => 'text',
			'label' => _x( 'Singular', 'modifiers', 'voxel-backend' ),
			'placeholder' => 'place',
		] );

		$this->define_arg( [
			'type' => 'text',
			'label' => _x( 'Plural', 'modifiers', 'voxel-backend' ),
			'placeholder' => 'places',
		] );

		$this->define_arg( [
			'type' => 'select',
			'label' => _x( 'Include value', 'modifiers', 'voxel-backend' ),
			'description' => _x( 'Whether to prefix the output with the numeric value (e.g. "2 places" vs just "places").', 'modifiers', 'voxel-backend' ),
			'choices' => [
				'' => 'Yes',
				'0' => 'No',
			],
		] );
	}

	public function apply( string $value ) {
		if ( ! is_numeric( $value ) ) {
			return $value;
		}

		$n = (float) $value;
		$singular = $this->get_arg(0);
		$plural = $this->get_arg(1);
		$label = $n === 1.0 ? $singular : $plural;

		if ( $this->get_arg(2) === '0' ) {
			return $label;
		}

		if ( $label === '' ) {
			return $value;
		}

		return $value . ' ' . $label;
	}

}
