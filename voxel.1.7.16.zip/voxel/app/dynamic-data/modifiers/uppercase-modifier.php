<?php

namespace Voxel\Dynamic_Data\Modifiers;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Uppercase_Modifier extends Base_Modifier {

	public function get_label(): string {
		return _x( 'Uppercase', 'modifiers', 'voxel-backend' );
	}

	public function get_key(): string {
		return 'uppercase';
	}

	public function apply( string $value ) {
		return mb_strtoupper( $value );
	}

}
