<?php

namespace Voxel\Dynamic_Data\Modifiers;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Loop_Index_Modifier extends Base_Modifier {

	public function get_label(): string {
		return _x( 'Loop index', 'modifiers', 'voxel-backend' );
	}

	public function get_key(): string {
		return 'loop_index';
	}

	public function expects(): array {
		return [ static::TYPE_ARRAY ];
	}

	public function get_description(): string {
		return _x( 'Current index in a loop (1-based by default; pass 0 for zero-based).', 'modifiers', 'voxel-backend' );
	}

	protected function define_args(): void {
		$this->define_arg( [
			'type' => 'text',
			'label' => _x( 'Base index', 'modifiers', 'voxel-backend' ),
			'description' => _x( 'Leave empty or any value other than 0 for 1-based indexing. Use 0 for zero-based indexing.', 'modifiers', 'voxel-backend' ),
			'placeholder' => '1',
		] );
	}

	public function apply( string $value ) {
		$nearest_loopable = $this->_get_nearest_loopable_ancestor();
		if ( $nearest_loopable === null ) {
			return '';
		}

		$loopable = $nearest_loopable['property'];
		$index = $loopable->get_current_index();

		if ( $this->get_arg(0) === '0' ) {
			return (string) $index;
		}

		return (string) ( $index + 1 );
	}

}
