<?php

namespace Voxel\Dynamic_Data\Modifiers;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Shuffle_Modifier extends Base_Modifier {

	public function get_label(): string {
		return _x( 'Shuffle list', 'modifiers', 'voxel-backend' );
	}

	public function get_key(): string {
		return 'shuffle';
	}

	public function get_description(): string {
		return _x( 'Splits the value by the given separator, randomizes the order of the items, and joins them back. To shuffle items inside a loop, chain this after .list().', 'modifiers', 'voxel-backend' );
	}

	protected function define_args(): void {
		$this->define_arg( [
			'type' => 'text',
			'label' => _x( 'Separator', 'modifiers', 'voxel-backend' ),
			'description' => _x( 'Character(s) used to split and rejoin the list. Defaults to a comma.', 'modifiers', 'voxel-backend' ),
			'placeholder' => ',',
		] );
	}

	public function apply( string $value ) {
		if ( $value === '' ) {
			return $value;
		}

		$separator = $this->get_arg(0);
		if ( $separator === '' ) {
			$separator = ',';
		}

		$items = explode( $separator, $value );
		if ( count( $items ) <= 1 ) {
			return $value;
		}

		shuffle( $items );

		return join( $separator, $items );
	}

}
