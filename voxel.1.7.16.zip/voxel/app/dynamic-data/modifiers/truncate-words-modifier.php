<?php

namespace Voxel\Dynamic_Data\Modifiers;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Truncate_Words_Modifier extends Base_Modifier {

	public function get_label(): string {
		return _x( 'Truncate words', 'modifiers', 'voxel-backend' );
	}

	public function get_key(): string {
		return 'truncate_words';
	}

	public function get_description(): string {
		return _x( 'Limit output to a number of words, with an optional suffix appended when truncated.', 'modifiers', 'voxel-backend' );
	}

	protected function define_args(): void {
		$this->define_arg( [
			'type' => 'text',
			'label' => _x( 'Max words', 'modifiers', 'voxel-backend' ),
			'placeholder' => '20',
		] );

		$this->define_arg( [
			'type' => 'text',
			'label' => _x( 'Suffix when truncated', 'modifiers', 'voxel-backend' ),
			'placeholder' => '...',
		] );
	}

	public function apply( string $value ) {
		$trimmed = trim( $value );
		if ( $trimmed === '' ) {
			return $value;
		}

		$max_words_arg = $this->get_arg(0);
		$max_words = absint( is_numeric( $max_words_arg ) ? $max_words_arg : 20 );
		if ( $max_words <= 0 ) {
			return $value;
		}

		$words = preg_split( '/\s+/u', $trimmed, -1, PREG_SPLIT_NO_EMPTY );
		if ( count( $words ) <= $max_words ) {
			return $value;
		}

		$suffix = $this->get_arg(1);
		if ( $suffix === '' ) {
			$suffix = '...';
		}

		return join( ' ', array_slice( $words, 0, $max_words ) ) . $suffix;
	}

}
