<?php

namespace Voxel\Dynamic_Data\Modifiers;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Lowercase_Modifier extends Base_Modifier {

	public function get_label(): string {
		return _x( 'Lowercase', 'modifiers', 'voxel-backend' );
	}

	public function get_key(): string {
		return 'lowercase';
	}

	public function apply( string $value ) {
		return mb_strtolower( $value );
	}

}
