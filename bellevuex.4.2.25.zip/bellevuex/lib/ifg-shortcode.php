<?php
/**
 * Fallback for the optional legacy Instagram provider.
 *
 * @package Bellevue
 */

/**
 * Hide the exact IFG token only when its provider has not registered it.
 *
 * @return void
 */
function bellevue_register_ifg_shortcode_fallback() {
	if ( ! shortcode_exists( 'IFG' ) ) {
		add_shortcode( 'IFG', '__return_empty_string' );
	}
}

add_action( 'init', 'bellevue_register_ifg_shortcode_fallback', PHP_INT_MAX );
