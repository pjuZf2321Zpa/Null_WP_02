<?php
/**
 * Fallback for the optional legacy weather provider.
 *
 * @package Bellevue
 */

/**
 * Hide the legacy weather token only when its provider has not registered it.
 *
 * @return void
 */
function bellevue_register_weather_shortcode_fallback() {
	if ( ! shortcode_exists( 'weather_widget_wp_location' ) ) {
		add_shortcode( 'weather_widget_wp_location', '__return_empty_string' );
	}
}

add_action( 'init', 'bellevue_register_weather_shortcode_fallback', PHP_INT_MAX );
