<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Purchase-code-authorized Bellevue and Aloha updates.
 *
 * The purchase code is sent only in a TLS-protected POST body. The service
 * returns a short-lived signed package URL and re-checks the active one-site
 * entitlement when WordPress downloads it.
 */
final class BellevueDirectUpdates
{
    const ENDPOINT = 'https://bellevuetheme.com/wp-json/bellevue-direct/v1/updates/metadata';

    private static $metadata = array();
    private static $booted = false;
    private static $legacyValid = null;

    public static function boot()
    {
        if (self::$booted) {
            return;
        }
        self::$booted = true;
        add_filter('site_transient_update_themes', array(__CLASS__, 'filterThemeUpdates'), 20);
        add_filter('site_transient_update_plugins', array(__CLASS__, 'filterPluginUpdates'), 20);
        add_filter('plugins_api', array(__CLASS__, 'filterPluginInformation'), 20, 3);
        add_filter('upgrader_pre_download', array(__CLASS__, 'refreshSignedDownload'), 10, 4);
    }

    public static function filterThemeUpdates($updates)
    {
        if (!is_object($updates)) {
            return $updates;
        }
        $result = self::metadata('theme');
        $theme = function_exists('get_template') ? get_template() : ENVATO_THEME_REGISTER_NAME;

        if ('legacy' === $result['state'] && !self::legacyLicenseValid()) {
            $result['state'] = 'denied';
        }
        if ('denied' === $result['state']) {
            if (isset($updates->response) && is_array($updates->response)) {
                unset($updates->response[$theme]);
            }
            return $updates;
        }
        if ('authorized' !== $result['state']) {
            return $updates;
        }

        $installed = wp_get_theme($theme)->get('Version');
        if (empty($installed) || version_compare($result['manifest']['version'], $installed, '<=')) {
            if (isset($updates->response) && is_array($updates->response)) {
                unset($updates->response[$theme]);
            }
            return $updates;
        }
        if (!isset($updates->response) || !is_array($updates->response)) {
            $updates->response = array();
        }
        $updates->response[$theme] = array(
            'theme' => $theme,
            'new_version' => $result['manifest']['version'],
            'url' => isset($result['manifest']['homepage']) ? $result['manifest']['homepage'] : 'https://bellevuetheme.com/',
            'package' => $result['manifest']['download_url'],
            'requires' => isset($result['manifest']['requires']) ? $result['manifest']['requires'] : '',
            'requires_php' => isset($result['manifest']['requires_php']) ? $result['manifest']['requires_php'] : '',
        );
        return $updates;
    }

    /**
     * Return the authorized Bellevue theme update, if there is one.
     *
     * The Bellevue Dashboard uses this to decide whether it can safely send a
     * direct purchaser to WordPress' native theme upgrader. Keeping that
     * decision here prevents the dashboard from treating an unrelated Envato
     * token as proof that Envato can supply Bellevue.
     *
     * @return array|false
     */
    public static function getThemeUpdateManifest()
    {
        $result = self::metadata('theme');
        if ('authorized' !== $result['state']) {
            return false;
        }

        $theme = function_exists('get_template') ? get_template() : ENVATO_THEME_REGISTER_NAME;
        $installed = wp_get_theme($theme)->get('Version');
        if (empty($installed) || version_compare($result['manifest']['version'], $installed, '<=')) {
            return false;
        }

        return $result['manifest'];
    }

    public static function filterPluginUpdates($updates)
    {
        if (!is_object($updates)) {
            return $updates;
        }
        $result = self::metadata('aloha');
        $plugin = THMV_ALOHA_PLUGIN_FILE;

        if ('legacy' === $result['state'] && !self::legacyLicenseValid()) {
            $result['state'] = 'denied';
        }
        if ('denied' === $result['state']) {
            if (isset($updates->response) && is_array($updates->response)) {
                unset($updates->response[$plugin]);
            }
            return $updates;
        }
        if ('authorized' !== $result['state']) {
            return $updates;
        }

        $installed = function_exists('th_aloha_version') ? th_aloha_version() : '';
        if (empty($installed) || version_compare($result['manifest']['version'], $installed, '<=')) {
            if (isset($updates->response) && is_array($updates->response)) {
                unset($updates->response[$plugin]);
            }
            return $updates;
        }
        if (!isset($updates->response) || !is_array($updates->response)) {
            $updates->response = array();
        }
        $updates->response[$plugin] = (object) array(
            'id' => 0,
            'slug' => THMV_ALOHA_PLUGIN_SLUG,
            'plugin' => $plugin,
            'new_version' => $result['manifest']['version'],
            'package' => $result['manifest']['download_url'],
            'url' => isset($result['manifest']['homepage']) ? $result['manifest']['homepage'] : 'https://bellevuetheme.com/',
            'tested' => isset($result['manifest']['tested']) ? $result['manifest']['tested'] : '',
            'requires_php' => isset($result['manifest']['requires_php']) ? $result['manifest']['requires_php'] : '',
        );
        if (isset($updates->no_update) && is_array($updates->no_update)) {
            unset($updates->no_update[$plugin]);
        }
        return $updates;
    }

    public static function filterPluginInformation($result, $action, $args)
    {
        if ('plugin_information' !== $action || !is_object($args) || !isset($args->slug) || THMV_ALOHA_PLUGIN_SLUG !== $args->slug) {
            return $result;
        }
        $metadata = self::metadata('aloha');
        if ('authorized' !== $metadata['state']) {
            return $result;
        }
        $manifest = $metadata['manifest'];
        return (object) array(
            'name' => $manifest['name'],
            'slug' => $manifest['slug'],
            'version' => $manifest['version'],
            'author' => isset($manifest['author']) ? $manifest['author'] : '',
            'homepage' => isset($manifest['homepage']) ? $manifest['homepage'] : '',
            'requires' => isset($manifest['requires']) ? $manifest['requires'] : '',
            'tested' => isset($manifest['tested']) ? $manifest['tested'] : '',
            'requires_php' => isset($manifest['requires_php']) ? $manifest['requires_php'] : '',
            'download_link' => $manifest['download_url'],
            'sections' => isset($manifest['sections']) && is_array($manifest['sections']) ? $manifest['sections'] : array('description' => ''),
        );
    }

    public static function refreshSignedDownload($reply, $package, $upgrader, $hookExtra)
    {
        if (false !== $reply || !is_string($package)) {
            return $reply;
        }
        $product = self::signedPackageProduct($package);
        if (false === $product) {
            return $reply;
        }
        $result = self::metadata($product, true);
        if ('authorized' !== $result['state']) {
            return new WP_Error('bellevue_update_unauthorized', __('Bellevue could not authorize this update. Confirm that the purchase code is active on this website.', 'bellevue'));
        }
        if (!function_exists('download_url')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $file = download_url($result['manifest']['download_url'], 300);
        if (is_wp_error($file)) {
            return $file;
        }
        $expected = isset($result['manifest']['package_sha256']) ? strtolower($result['manifest']['package_sha256']) : '';
        if (!preg_match('/^[a-f0-9]{64}$/', $expected) || !hash_equals($expected, hash_file('sha256', $file))) {
            if (function_exists('wp_delete_file')) {
                wp_delete_file($file);
            } else {
                @unlink($file);
            }
            return new WP_Error('bellevue_update_checksum', __('The Bellevue update package did not pass its integrity check.', 'bellevue'));
        }
        return $file;
    }

    public static function signedPackageProduct($package)
    {
        $scheme = strtolower((string) wp_parse_url($package, PHP_URL_SCHEME));
        $host = strtolower((string) wp_parse_url($package, PHP_URL_HOST));
        $path = untrailingslashit((string) wp_parse_url($package, PHP_URL_PATH));
        if ('https' !== $scheme || 'bellevuetheme.com' !== $host || '/bellevue-update' !== $path) {
            return false;
        }
        parse_str((string) wp_parse_url($package, PHP_URL_QUERY), $query);
        $product = isset($query['product']) ? sanitize_key($query['product']) : '';
        return in_array($product, array('theme', 'aloha'), true) ? $product : false;
    }

    private static function metadata($product, $force = false)
    {
        if (!$force && isset(self::$metadata[$product])) {
            return self::$metadata[$product];
        }
        $code = strtolower(trim((string) get_option(BELLEVUE_CODE_REGISTRY, '')));
        if (empty($code) || !self::registeredLocally()) {
            return self::$metadata[$product] = array('state' => 'none');
        }
        $endpoint = apply_filters('bellevue_direct_update_endpoint', self::ENDPOINT);
        $body = wp_json_encode(array(
            'purchase_code' => $code,
            'site' => home_url('/'),
            'product' => $product,
            'installed_version' => self::installedVersion($product),
        ));
        $response = wp_remote_post($endpoint, array(
            'timeout' => 15,
            'redirection' => 0,
            'sslverify' => true,
            'headers' => array(
                'Accept' => 'application/json',
                'Content-Type' => 'application/json; charset=utf-8',
            ),
            'body' => $body,
            'data_format' => 'body',
        ));
        if (is_wp_error($response)) {
            return self::$metadata[$product] = array('state' => 'unavailable');
        }
        $status = (int) wp_remote_retrieve_response_code($response);
        $manifest = json_decode(wp_remote_retrieve_body($response), true);
        if (404 === $status) {
            return self::$metadata[$product] = array('state' => 'legacy');
        }
        if (403 === $status) {
            return self::$metadata[$product] = array('state' => 'denied');
        }
        if (200 !== $status || !self::validManifest($manifest, $product)) {
            return self::$metadata[$product] = array('state' => 'unavailable');
        }
        return self::$metadata[$product] = array('state' => 'authorized', 'manifest' => $manifest);
    }

    private static function validManifest($manifest, $product)
    {
        $slug = 'theme' === $product ? 'bellevue' : 'aloha-powerpack';
        return is_array($manifest)
            && 'authorized' === (isset($manifest['status']) ? $manifest['status'] : '')
            && $slug === (isset($manifest['slug']) ? $manifest['slug'] : '')
            && !empty($manifest['name'])
            && !empty($manifest['version'])
            && false !== self::signedPackageProduct(isset($manifest['download_url']) ? $manifest['download_url'] : '')
            && isset($manifest['package_sha256'])
            && 1 === preg_match('/^[a-f0-9]{64}$/', strtolower($manifest['package_sha256']));
    }

    private static function registeredLocally()
    {
        if (function_exists('th_theme_register')) {
            $status = th_theme_register('get');
        } else {
            $theme = defined('THEME_NAME') ? strtolower(THEME_NAME) : strtolower(ENVATO_THEME_REGISTER_NAME);
            $status = get_option('theme_is_registered_' . $theme, 0);
        }
        return in_array((int) $status, array(STATUS_ACTIVATED, STATUS_ACTIVATING_SUCCESS, STATUS_ACTIVATING_FAILURE_ACTIVATED_EARLY), true);
    }

    private static function legacyLicenseValid()
    {
        if (null !== self::$legacyValid) {
            return self::$legacyValid;
        }
        $code = (string) get_option(BELLEVUE_CODE_REGISTRY, '');
        if (empty($code) || !function_exists('th_get_license_repsonse')) {
            return self::$legacyValid = false;
        }
        $body = th_get_license_repsonse(REST_API_GET_CODE_DETAILS, wp_json_encode(array('code' => $code)));
        $details = json_decode((string) $body, true);
        return self::$legacyValid = is_array($details) && (string) ENVATO_STRATUS_ID === (string) (isset($details['item_id']) ? $details['item_id'] : '');
    }

    private static function installedVersion($product)
    {
        if ('aloha' === $product) {
            return function_exists('th_aloha_version') ? (string) th_aloha_version() : '';
        }
        $theme = function_exists('get_template') ? get_template() : ENVATO_THEME_REGISTER_NAME;
        return (string) wp_get_theme($theme)->get('Version');
    }
}

BellevueDirectUpdates::boot();
