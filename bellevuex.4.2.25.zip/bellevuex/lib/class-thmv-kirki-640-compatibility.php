<?php
/**
 * Contain Kirki 6.4.0's failed staging-table migration on legacy installations.
 *
 * Keep the legacy Customizer active; never change the WordPress posts table or
 * modify installed plugin files. Remove this bridge after an upstream fix.
 *
 * @package Bellevue
 */

/** Repairs missing schema and contains unavailable builder requests. */
final class THMV_Kirki_640_Compatibility {
	const RETRY_TRANSIENT = 'thmv_kirki_640_schema_retry';

	/**
	 * Initialize the bridge only for active Kirki 6.4.0.
	 */
	public static function boot() {
		if ( ! defined( 'KIRKI_VERSION' ) || '6.4.0' !== KIRKI_VERSION ||
			! is_plugin_active( 'kirki/kirki.php' ) ||
			! class_exists( '\Kirki\Manager\PluginActiveEvents' ) ||
			! class_exists( '\Kirki\App\Services\PageStageMigrationService' ) ) {
			return;
		}

		if ( self::tables_ready() ) {
			delete_transient( self::RETRY_TRANSIENT );
			return;
		}

		if ( ! get_transient( self::RETRY_TRANSIENT ) ) {
			// A failed repair must not add repeated DDL work to every request.
			set_transient( self::RETRY_TRANSIENT, 1, 5 * MINUTE_IN_SECONDS );
			try {
				if ( self::repair() ) {
					delete_transient( self::RETRY_TRANSIENT );
					return;
				}
			} catch ( \Throwable $error ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Persist actionable recovery failure diagnostics.
				error_log( 'Bellevue: Kirki staging repair failed: ' . $error->getMessage() );
			}
		}

		// Kirki's deleted_post callback otherwise fatals for unrelated post types,
		// including MotoPress reserved rooms. Only remove this exact callback.
		global $wp_filter;
		if ( isset( $wp_filter['deleted_post'] ) ) {
			foreach ( $wp_filter['deleted_post']->callbacks as $priority => $callbacks ) {
				foreach ( $callbacks as $callback ) {
					$function = $callback['function'];
					if ( is_array( $function ) &&
						$function[0] instanceof \Kirki\Manager\PluginLoadedEvents &&
						'delete_page_stages' === $function[1] ) {
						remove_action( 'deleted_post', $function, $priority );
					}
				}
			}
		}

		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'init', array( __CLASS__, 'guard_builder' ), -100 );
		add_filter( 'rest_pre_dispatch', array( __CLASS__, 'guard_rest' ), 10, 3 );
		foreach ( array( 'kirki_get_apis', 'kirki_post_apis', 'kirki_wp_admin_get_apis', 'kirki_wp_admin_post_apis' ) as $action ) {
			add_action( 'wp_ajax_' . $action, array( __CLASS__, 'guard_ajax' ), -100 );
			add_action( 'wp_ajax_nopriv_' . $action, array( __CLASS__, 'guard_ajax' ), -100 );
		}
	}

	/**
	 * Check live staging schema before allowing Kirki readers.
	 *
	 * @return bool Whether all required columns exist.
	 */
	private static function tables_ready() {
		global $wpdb;
		if ( ! \Kirki\Manager\PluginActiveEvents::page_stage_tables_exist() ) {
			return false;
		}
		// Kirki checks table names only. A partial/old schema can still make its
		// readers fatal; do not mistake that for a successful migration.
		$columns = array(
			KIRKI_PAGE_STAGES_TABLE     => array( 'id', 'post_id', 'type', 'version', 'name', 'edited_by', 'is_published', 'no_legacy_global_style', 'created_at', 'updated_at' ),
			KIRKI_PAGE_STAGE_DATA_TABLE => array( 'id', 'stage_id', 'meta_key', 'meta_value' ),
		);
		foreach ( $columns as $suffix => $required ) {
			$table = $wpdb->prefix . $suffix;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live schema check; identifier is the validated WP prefix plus a vendor constant.
			$found = $wpdb->get_col( "SHOW COLUMNS FROM `$table`" );
			if ( $wpdb->last_error || array_diff( $required, $found ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Create missing empty tables and resume the vendor migration.
	 *
	 * @return bool Whether recovery succeeded.
	 */
	private static function repair() {
		global $wpdb;
		// Do not rebuild a partly missing pair over surviving stage history.
		foreach ( array( KIRKI_PAGE_STAGES_TABLE, KIRKI_PAGE_STAGE_DATA_TABLE ) as $suffix ) {
			$table = $wpdb->prefix . $suffix;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Recovery must inspect the current schema instead of cached table state.
			$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
			if ( $found === $table ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Check for surviving history; identifier uses only the validated WP prefix and vendor constant.
				$row = $wpdb->get_var( "SELECT 1 FROM `$table` LIMIT 1" );
				if ( $wpdb->last_error || null !== $row ) {
					return false;
				}
			} elseif ( $wpdb->last_error ) {
				return false;
			}
		}

		// Scope the SQL adjustment to this synchronous vendor schema call. The
		// plugin already explicitly cleans up stages through deleted_post.
		add_filter( 'query', array( __CLASS__, 'compatible_stage_schema' ) );
		try {
			$ready = \Kirki\Manager\PluginActiveEvents::create_page_stage_tables();
		} finally {
			remove_filter( 'query', array( __CLASS__, 'compatible_stage_schema' ) );
		}
		if ( ! $ready || ! self::tables_ready() ) {
			return false;
		}

		// Activation may have recorded 6.4.0 before the schema existed. Resume
		// the data migration explicitly instead of relying on that checkpoint.
		( new \Kirki\App\Services\PageStageMigrationService() )->start();
		\Kirki\HelperFunctions::set_kirki_version_in_db();
		return true;
	}

	/**
	 * Remove the posts foreign key only during the staging schema call.
	 *
	 * @param string $query SQL statement.
	 * @return string Compatible SQL statement.
	 */
	public static function compatible_stage_schema( $query ) {
		global $wpdb;
		$table = $wpdb->prefix . KIRKI_PAGE_STAGES_TABLE;
		if ( 0 !== strpos( $query, "CREATE TABLE IF NOT EXISTS $table (" ) ) {
			return $query;
		}
		return str_replace(
			",\n\t\t\tFOREIGN KEY (post_id) REFERENCES {$wpdb->prefix}posts(ID) ON DELETE CASCADE",
			'',
			$query
		);
	}

	/**
	 * Describe the recoverable database failure.
	 *
	 * @return string Translated recovery guidance.
	 */
	private static function message() {
		return __( 'Kirki could not prepare its builder database tables. Your legacy Bellevue Customizer remains available. Ask your site administrator to check database table permissions and the Kirki migration error log, or restore missing staging data from a backup. Bellevue will retry the repair automatically.', 'bellevue' );
	}

	/**
	 * Show recovery guidance to site administrators.
	 */
	public static function notice() {
		if ( current_user_can( 'manage_options' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( self::message() ) . '</p></div>';
		}
	}

	/**
	 * Contain builder and signed staging-preview requests.
	 */
	public static function guard_builder() {
		// Read-only routing checks; no state change or nonce is involved.
		$action  = isset( $_GET['action'] ) && is_string( $_GET['action'] ) ? sanitize_text_field( wp_unslash( $_GET['action'] ) ) : '';
		$page    = isset( $_GET['page'] ) && is_string( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
		$preview = isset( $_GET['staging_version'], $_GET['nonce'] ) &&
			is_scalar( $_GET['staging_version'] ) && (int) $_GET['staging_version'] > 0 &&
			is_string( $_GET['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), 'kirki_preview_staging_nonce' );
		if ( 'kirki' === $action || ( is_admin() && 'kirki' === $page ) || $preview ) {
			wp_die( esc_html( self::message() ), esc_html__( 'Kirki database repair required', 'bellevue' ), array( 'response' => 503 ) );
		}
	}

	/**
	 * Return a controlled response for unavailable builder AJAX routes.
	 */
	public static function guard_ajax() {
		wp_send_json_error(
			array(
				'code'    => 'thmv_kirki_schema_unavailable',
				'message' => self::message(),
			),
			503
		);
	}

	/**
	 * Contain Kirki REST requests while preserving earlier results.
	 *
	 * @param mixed           $result Existing dispatch result.
	 * @param WP_REST_Server  $server REST server.
	 * @param WP_REST_Request $request Requested route.
	 * @return mixed Existing result or schema error.
	 */
	public static function guard_rest( $result, $server, $request ) {
		if ( null === $result && 0 === strpos( $request->get_route(), '/kirki/' ) ) {
			return new WP_Error( 'thmv_kirki_schema_unavailable', self::message(), array( 'status' => 503 ) );
		}
		return $result;
	}
}

add_action( 'after_setup_theme', array( 'THMV_Kirki_640_Compatibility', 'boot' ), 5 );
