<?php

// This is the setup wizard init file.
// This file changes for each one of dtbaker's themes
// This is where I extend the default 'Envato_Theme_Setup_Wizard' class and can do things like remove steps from the setup process.

// This particular init file has a custom "Update" step that is triggered on a theme update. If the setup wizard finds some old shortcodes after a theme update then it will go through the content and replace them. Probably remove this from your end product.

if ( ! defined( 'ABSPATH' ) ) exit;


//add_filter('envato_setup_logo_image','dtbwp_envato_setup_logo_image');
//function dtbwp_envato_setup_logo_image($old_image_url){
//	return get_template_directory_uri().'/images/logo.png';
//}

if ( ! function_exists( 'envato_theme_setup_wizard' ) ) :

    // THEMOVATION - Added missing Function.
    if ( ! function_exists( 'array_unshift_assoc' ) ) :
        function array_unshift_assoc( &$arr, $key, $val ) {
            $arr = array_reverse( $arr, true );
            $arr[$key] = $val;
            return array_reverse( $arr, true );
        }
    endif;


    function envato_theme_setup_wizard() {

        if(class_exists('Envato_Theme_Setup_Wizard')) {
            class dtbwp_Envato_Theme_Setup_Wizard extends Envato_Theme_Setup_Wizard {

                var $parent_slug = '';
                
                public function init_globals() {
                    $this->theme         = wp_get_theme();
                    $this->theme_name      = strtolower( preg_replace( '#[^a-zA-Z]#', '', $this->theme->get( 'Name' ) ) );
                    $this->envato_username = apply_filters( $this->theme_name . '_theme_setup_wizard_username', 'themovation' );
                    $this->oauth_script    = apply_filters( $this->theme_name . '_theme_setup_wizard_oauth_script', 'http://themovation.net/files/envato/wptoken/server-script.php' );
                    $this->page_slug       = apply_filters( $this->theme_name . '_theme_setup_wizard_page_slug', $this->theme_name . '-setup' );
                    $this->parent_slug     = apply_filters( $this->theme_name . '_theme_setup_wizard_parent_slug', '' );

                    // create an images/styleX/ folder for each style here.
                    $this->site_styles = array(
                        'style1' => 'Rustic - Chalet',
                        'style2' => 'Lakeshore - Cabin',
                        'style3' => 'Long Beach - Beach House',
                        'style4' => 'Parksville - Countryside',
                        'style5' => 'Yaletown - Urban Guest House',
                        'style6' => 'Bellevue - Hotel Classic',
                        'style7' => 'Yaletown - One Pager',
                        'style8' => 'Ashbury - Apartments',
                        'style9' => 'Hostel',
                        'style10' => 'Hotel',
                        'style11' => 'Tiny Home',
                        'style12' => 'Chalet 2',
                        'style13' => 'Beach House 2',
                        'style14' => 'Countryside 2',
                        'style15' => 'Camping & RV'
                    );

                    //If we have parent slug - set correct url
                    $this->page_url = 'admin.php?page=' . $this->page_slug;
                    $this->page_url = apply_filters( $this->theme_name . '_theme_setup_wizard_page_url', $this->page_url );

                    //set relative plugin path url
                    $this->plugin_path = trailingslashit( $this->cleanFilePath( dirname( __FILE__ ) ) );
                    $relative_url      = str_replace( $this->cleanFilePath( get_template_directory() ), '', $this->plugin_path );
                    //$this->plugin_url  = trailingslashit( get_template_directory_uri() . $relative_url );
                    $this->plugin_url = get_template_directory_uri() . '/plugins/envato_setup/';
                }


                public function get_header_logo_width() {
                    return '168px';
                }


                /**
                 * Holds the current instance of the theme manager
                 *
                 * @since 1.1.3
                 * @var Envato_Theme_Setup_Wizard
                 */
                private static $instance = null;

                /**
                 * @since 1.1.3
                 *
                 * @return Envato_Theme_Setup_Wizard
                 */
                public static function get_instance() {
                    if ( ! self::$instance ) {
                        self::$instance = new self;
                    }

                    return self::$instance;
                }

                public function init_actions(){
                    if ( apply_filters( $this->theme_name . '_enable_setup_wizard', true ) && current_user_can( 'edit_theme_options' )  ) {
                        add_filter( $this->theme_name . '_theme_setup_wizard_content', array(
                            $this,
                            'theme_setup_wizard_content'
                        ) );
                        add_filter( $this->theme_name . '_theme_setup_wizard_steps', array(
                            $this,
                            'theme_setup_wizard_steps'
                        ) );
                    }
                    parent::init_actions();
                }

                // THEMOVATION - Steps to skip
                public function theme_setup_wizard_steps($steps){
                    //unset($steps['design']); // this removes the "logo" step
//                    unset($steps['style']); // this removes the "logo" step
                    unset($steps['updates']); // this removes the "logo" step
                    unset($steps['design']); // this removes the "logo" step
                    return $steps;
                }
                public function theme_setup_wizard_content($content){
                    if($this->is_possible_upgrade()){
                        array_unshift_assoc($content,'upgrade',array(
                            'title' => __( 'Upgrade', 'bellevue' ),
                            'description' => __( 'Upgrade Content and Settings.', 'bellevue' ),
                            'pending' => __( 'Pending.', 'bellevue' ),
                            'installing' => __( 'Installing Updates.', 'bellevue' ),
                            'success' => __( 'Success.', 'bellevue' ),
                            'install_callback' => array( $this,'_content_install_updates' ),
                            'checked' => 1
                        ));
                    }
                    return $content;
                }

                public function is_possible_upgrade(){
                    $widget = get_option('widget_text');
                    if(is_array($widget)) {
                        foreach($widget as $item){
                            if(isset($item['dtbwp_widget_bg'])){
                                return true;
                            }
                        }
                    }
                    // check if shop page is already installed?
                    $shoppage = th_get_page_by_title( 'Shop' );
                    if ( $shoppage || get_option( 'page_on_front', false ) ) {
                        return true;
                    }

                    return false;
                }

                public function _content_install_updates(){

                    // THEOVATION - If there is a menu called 'Main Menu' set it was the priamry

                    $locations = get_theme_mod( 'nav_menu_locations' );

                    if(!empty($locations))
                    {
                        foreach($locations as $locationId => $menuValue)
                        {
                            switch($locationId)
                            {
                                case 'primary-navigation':
                                    $menu = get_term_by('name', 'Main Menu', 'nav_menu');
                                    break;

                            }

                            if(isset($menu))
                            {
                                $locations[$locationId] = $menu->term_id;
                            }
                        }

                        set_theme_mod('nav_menu_locations', $locations);
                    }

                    if ( empty( $locations ) ) {
                        $menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
                        if ( $menu && ! empty( $menu->term_id ) ) {
                            set_theme_mod(
                                'nav_menu_locations',
                                array(
                                    'primary_navigation' => (int) $menu->term_id,
                                )
                            );
                        }
                    }


                    return true;

                }

                // THEMOVATION - Custom Text & Action Hook
                public function envato_setup_customizeX() {
                    ?>

                    <?php do_action( 'th_post_content_import'); ?>

                    <h1><?php esc_html_e( 'Theme Customization', 'bellevue' ); ?></h1>
                    <p>
                        <?php esc_html_e( 'Most website changes can be made from Appearance > Customize in the WordPress dashboard. These include:', 'bellevue' ); ?>
                    </p>
                    <ul>
                        <li><?php esc_html_e( 'Logo: Upload a new logo and adjust its size.', 'bellevue' ); ?></li>
                        <li><?php esc_html_e( 'Menu & Header: Customize the site header and menus.', 'bellevue' ); ?></li>
                        <li><?php esc_html_e( 'Colors: Choose primary and accent colors.', 'bellevue' ); ?></li>
                        <li><?php esc_html_e( 'Typography: Configure font sizes, styles, and colors.', 'bellevue' ); ?></li>
                        <li><?php esc_html_e( 'Blog: Configure headings, styles, and layout.', 'bellevue' ); ?></li>
                        <li><?php esc_html_e( 'Cart / WooCommerce: Configure headings, sidebar, and settings.', 'bellevue' ); ?></li>
                        <li><?php esc_html_e( 'Slider: Configure slider settings.', 'bellevue' ); ?></li>
                        <li><?php esc_html_e( 'Miscellaneous: Configure additional settings.', 'bellevue' ); ?></li>
                        <li><?php esc_html_e( 'Footer: Configure widgets and layout settings.', 'bellevue' ); ?></li>
                    </ul>

                    <p>
                        <em><?php esc_html_e( 'Advanced users: If you plan to change the theme source code, use a', 'bellevue' ); ?> <a href="https://developer.wordpress.org/themes/advanced-topics/child-themes/" target="_blank"><?php esc_html_e( 'child theme', 'bellevue' ); ?></a> <?php esc_html_e( 'instead of modifying the parent theme. This allows the parent theme to receive updates without overwriting your changes.', 'bellevue' ); ?> <br/> <?php esc_html_e( 'See child-theme.zip in the main theme ZIP for an example.', 'bellevue' ); ?></em>
                    </p>

                    <p class="envato-setup-actions step">
                        <a href="<?php echo esc_url( $this->get_next_step_link() ); ?>"
                           class="button button-primary button-large button-next"><?php esc_html_e( 'Continue', 'bellevue' ); ?></a>
                    </p>

                    <?php
                }

                public function envato_setup_help_supportX() {
                    ?>
                    <h1><?php esc_html_e( 'Help and Support', 'bellevue' ); ?></h1>
                    <p><?php esc_html_e( 'This theme includes six months of item support from the purchase date, with an option to extend it. The license permits use on one website. Purchase an additional license for another website.', 'bellevue' ); ?></p>
                    <p><?php esc_html_e( 'Item support is available from', 'bellevue' ); ?> <a href="https://themovation.ticksy.com/" target="_blank">https://themovation.ticksy.com</a> <?php esc_html_e( 'and includes:', 'bellevue' ); ?></p>
                    <ul>
                        <li><?php esc_html_e( 'Author availability to answer questions', 'bellevue' ); ?></li>
                        <li><?php esc_html_e( 'Answers to technical questions about item features', 'bellevue' ); ?></li>
                        <li><?php esc_html_e( 'Assistance with reported bugs and issues', 'bellevue' ); ?></li>
                        <li><?php esc_html_e( 'Help with bundled third-party plugins', 'bellevue' ); ?></li>
                    </ul>

                    <p><?php esc_html_e( 'Item support does not include:', 'bellevue' ); ?></p>
                    <ul>
                        <li><?php esc_html_e( 'Customization services (available through', 'bellevue' ); ?> <a
                                    href="https://studio.envato.com/explore/wordpress-customization"
                                    target="_blank"><?php esc_html_e( 'Envato Studio', 'bellevue' ); ?></a>)
                        </li>
                        <li><?php esc_html_e( 'Installation services (available through', 'bellevue' ); ?> <a
                                    href="https://studio.envato.com/explore/wordpress-installation"
                                    target="_blank"><?php esc_html_e( 'Envato Studio', 'bellevue' ); ?></a>)
                        </li>
                        <li><?php esc_html_e( 'Help and support for non-bundled third-party plugins that you install separately', 'bellevue' ); ?></li>
                    </ul>
                    <p><?php esc_html_e( 'More details are available in the ThemeForest', 'bellevue' ); ?> <a
                                href="https://themeforest.net/page/item_support_policy" target="_blank"><?php esc_html_e( 'Item Support Policy', 'bellevue' ); ?></a>.</p>
                    <p class="envato-setup-actions step">
                        <a href="<?php echo esc_url( $this->get_next_step_link() ); ?>"
                           class="button button-primary button-large button-next"><?php esc_html_e( 'Agree and Continue', 'bellevue' ); ?></a>
                        <?php wp_nonce_field( 'envato-setup' ); ?>
                    </p>
                    <?php
                }


                /**
                 * Final step
                 */
                public function envato_setup_readyX() {

                    update_option( 'envato_setup_complete', time() );
                    update_option( 'dtbwp_update_notice', strtotime('-4 days') );
                    ?>

                    <h1><?php esc_html_e( 'Your Website is Ready!', 'bellevue' ); ?></h1>

                    <p>Congratulations! The theme has been activated and your website is ready. Login to your WordPress
                        dashboard to make changes and modify any of the default content to suit your needs.</p>

                    <div class="envato-setup-next-steps">
                        <div class="envato-setup-next-steps-first">
                            <h2><?php esc_html_e( 'Next Steps', 'bellevue' ); ?></h2>
                            <ul>
                                <li class="setup-product"><a class="button button-primary button-large"
                                                             href="https://twitter.com/themovation"
                                                             target="_blank"><?php esc_html_e( 'Follow @themovation on Twitter', 'bellevue' ); ?></a>
                                </li>
                                <li class="setup-product"><a class="button button-next button-large"
                                                             href="<?php echo esc_url( home_url() ); ?>"><?php esc_html_e( 'View your new website!', 'bellevue' ); ?></a>
                                </li>
                            </ul>
                        </div>
                        <div class="envato-setup-next-steps-last">
                            <h2><?php esc_html_e( 'More Resources', 'bellevue' ); ?></h2>
                            <ul>
                                <li class="documentation"><a href="http://help.bellevuetheme.com/"
                                                             target="_blank"><?php esc_html_e( 'Read the Theme Documentation', 'bellevue' ); ?></a>
                                </li>
                                <li class="howto"><a href="https://wordpress.org/support/"
                                                     target="_blank"><?php esc_html_e( 'Learn how to use WordPress', 'bellevue' ); ?></a>
                                </li>
                                <li class="rating"><a href="http://themeforest.net/downloads"
                                                      target="_blank"><?php esc_html_e( 'Leave an Item Rating', 'bellevue' ); ?></a></li>
                                <li class="support"><a href="https://themovation.ticksy.com/"
                                                       target="_blank"><?php esc_html_e( 'Get Help and Support', 'bellevue' ); ?></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                }

            }

            dtbwp_Envato_Theme_Setup_Wizard::get_instance();
        }else{
            // log error?
        }
    }
endif;
