/**
 * UpSolution Element: Content Carousel
 */
! function( $, undefined ) {
	"use strict";

	window.$us = window.$us || {};

	/**
	 * @param {String} container.
	 */
	function usContentCarousel( container ) {
		const self = this;

		// Elements
		const $carouselContainer = $( '.owl-carousel', container );
		self.$carousel = $carouselContainer;

		// Predefined options suitable for content carousel
		// https://owlcarousel2.github.io/OwlCarousel2/docs/api-options.html
		self.options = {
			responsiveRefreshRate: 100,
		}

		// Bindable events
		self._events = {
			continualRotationCssResize: self.continualRotationCssResize.bind( self ),
			controlItemAnimation: self.controlItemAnimation.bind( self ),
			updateAria: self.updateAria.bind( self ),
			togglePlayback: self.togglePlayback.bind( self ),
			keepNavFocus: self.keepNavFocus.bind( self ),
		};

		$.extend( self.options, $ush.getPassedData( $carouselContainer ) || {} );
		if ( ! $us.usbPreview() ) {
			$carouselContainer.removeAttr( 'data-us-json' );
		}

		// Disable autoWidth for [vc_row_inner] items
		// (!) Must run before prepareOptions(), which may replace the 'page' value of "slideBy"
		if ( self.options.slideBy == 'page' ) {
			if ( $( '.wpb_row:first', $carouselContainer ).length ) {
				$.each( self.options.responsive, ( _, options ) => {
					$.extend( options, {
						items:1,
						autoWidth: false
					} );
				} );
			}
		}

		self.prepareOptions();

		// Fixes for correct work in Live Builder
		if ( $us.usbPreview() ) {
			// TODO: Find a more elegant solution to work correctly in Live Builder!
			$carouselContainer.one( 'initialized.owl.carousel', () => {
				// ../plugins/us-core/builder/assets/js/builder-preview.js#L2734
				$( '.owl-item', $carouselContainer ).each( ( _, node ) => {
					var $node = $( node ),
						$element = $( '> *', node ),
						usbid = $element.data( 'usbid' ) || $element.data( 'usbid2' );
					$node.attr( 'data-usbid', usbid );
					$element.data( 'usbid2', usbid ).removeAttr( 'data-usbid' );
				} );
				$ush.timeout( () => {
					$( '.owl-dots *, .owl-prev, .owl-next, .owl-playpause', $carouselContainer ).addClass( 'usb_skip_elmSelected' );
				}, 1 );
			} );
			$( 'style[data-for]', $carouselContainer ).each( ( _, node ) => {
				$( node ).next().prepend( node );
			} );
		}

		// Re-init for "Show More" link after carousel init to set correct height.
		$carouselContainer.one( 'initialized.owl.carousel', () => {
			self.initCollapsibleContent();
		} );

		if ( $carouselContainer.data( 'owl.carousel' )) {
			$carouselContainer.trigger( 'destroy.owl.carousel' );
		}

		// (!) Leftovers of a previous instance would be turned into carousel items on init
		$( '> .owl-playpause', $carouselContainer ).remove();

		// Init Owl Carousel
		self.owlCarousel = $carouselContainer.owlCarousel( self.options ).data( 'owl.carousel' );

		self.initItemAnimation();

		// Trigger continual autoplay
		if ( self.owlCarousel && self.options.autoplayContinual ) {
			$carouselContainer.trigger( 'next.owl.carousel' );
		}

		self.applyResponsiveClasses();
		self.initContinualRotationCss();

		// Expose the carousel structure and state to assistive technology
		self.initA11y();

		// Control the carousel navigation from a keyboard
		self.initKeyboardNav();
	}

	// (!) Everything shared with the other carousel elements lives in the mixin, which comes
	// from ../elements/carousel.js — declared as a dependency in us-core/config/assets.php
	$.extend( usContentCarousel.prototype, $us.carouselMixin );

	$.fn.usContentCarousel = function( options ) {
		return this.each( function() {
			$( this ).data( 'usContentCarousel', new usContentCarousel( this, options ) );
		} );
	};

	$( () => {
		$( '.w-content-carousel' ).usContentCarousel();
	} );

}( jQuery );
