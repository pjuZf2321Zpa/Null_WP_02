/**
 * UpSolution Element: Map
 *
 * Reloads markers of posts, when List Filter or List Search are applied, and highlights them by hovered list items,
 * the same for all providers
 * @see functions/ajax/maps.php
 */
;( function( $, _undefined ) {
	"use strict";

	const DELETE_FILTER = null;

	// Check for is set objects
	window.$us = window.$us || {};

	/**
	 * Get black or white as a contrast for the color, the same formula as us_get_contrast_color() in PHP has.
	 *
	 * @param {String} color The color in "#rrggbb" or "rgba()" format
	 * @return {String} 'white' or 'black'
	 */
	function getContrastColor( color ) {
		const rgba = getRgba( color );

		// Determine color lightness (from 0 to 255)
		var lightness = rgba[0] * 0.213 + rgba[1] * 0.715 + rgba[2] * 0.072;

		// Increase lightness for semi-transparent color
		if ( rgba[3] < 1 ) {
			lightness = lightness + ( 1 - rgba[3] ) * ( 1 - lightness / 255 ) * 235;
		}

		return ( lightness < 178 ) ? 'white' : 'black';
	}

	/**
	 * Get channels of the color.
	 *
	 * @param {String} color The color in "#rrggbb" or "rgba()" format
	 * @return {Number[]} Red, green and blue from 0 to 255 and alpha from 0 to 1
	 */
	function getRgba( color ) {
		var rgba;
		if ( color.charAt( 0 ) === '#' ) {
			rgba = [ 1, 3, 5 ].map( ( i ) => parseInt( color.substr( i, 2 ), 16 ) ).concat( 1 );
		} else {
			rgba = ( color.match( /[\d.]+/g ) || [ 0, 0, 0 ] ).map( Number );
			rgba[3] = rgba.length > 3 ? rgba[3] : 1;
		}
		return rgba;
	}

	/**
	 * Get the color with the changed contrast, the same formula as the CSS "contrast()" filter has.
	 *
	 * @param {String} color The color in any CSS format, e.g. "white"
	 * @param {Number} contrast The contrast, 1 keeps the color, 0 makes it gray
	 * @return {String} The color in "rgba()" format
	 */
	function applyContrastFilter( color, contrast ) {
		const rgba = getRgba( normalizeColor( color ) );
		const rgb = rgba.slice( 0, 3 ).map( ( value ) => {
			return Math.round( Math.min( Math.max( ( value - 127.5 ) * contrast + 127.5, 0 ), 255 ) );
		} );
		return `rgba(${rgb.join( ',' )},${rgba[3]})`;
	}

	/**
	 * Normalize the color of any format to "#rrggbb" or "rgba()" by the canvas, invalid values are ignored,
	 * so the result is safe to be inserted into SVG markup.
	 *
	 * @param {...String} colors Colors in any CSS format, the last valid one is used, black when all are invalid
	 * @return {String} The color in "#rrggbb" or "rgba()" format
	 */
	function normalizeColor( ...colors ) {
		const context = normalizeColor.context || ( normalizeColor.context = document.createElement( 'canvas' ).getContext( '2d' ) );
		// The context is shared, so the color of the previous call is reset
		context.fillStyle = '#000';
		colors.forEach( ( color ) => {
			context.fillStyle = color;
		} );
		return context.fillStyle;
	}

	/**
	 * Get the color of a CSS variable, the primary color is used for an invalid value.
	 * Note: the computed value of a CSS variable is the final color, also of a color scheme of the section.
	 *
	 * @param {CSSStyleDeclaration} style The computed style of the map
	 * @param {String} name The variable name
	 * @return {String} The color in "#rrggbb" or "rgba()" format
	 */
	function getVariableColor( style, name ) {
		return normalizeColor(
			'#1a73e8',
			style.getPropertyValue( '--color-content-primary' ).trim(),
			style.getPropertyValue( name ).trim()
		);
	}

	/**
	 * Get circles of the dot marker and cluster icons: the circle of the color with a semi-transparent halo,
	 * which has the same width for icons of any size.
	 *
	 * @param {Number} size The icon size, it's also the size of the SVG viewBox
	 * @param {String} color The color
	 * @return {String}
	 */
	function getHaloCircles( size, color ) {
		return `<circle cx="50%" cy="50%" r="50%" fill="${color}" fill-opacity=".3"/>`
			+ `<circle cx="50%" cy="50%" r="${size / 2 - 5}" fill="${color}"/>`;
	}

	/**
	 * Get the width of the text in the font.
	 *
	 * @param {String} text The text
	 * @param {String} font The font in the CSS "font" format
	 * @return {Number}
	 */
	function getTextWidth( text, font ) {
		const context = getTextWidth.context || ( getTextWidth.context = document.createElement( 'canvas' ).getContext( '2d' ) );
		context.font = font;
		return context.measureText( text ).width;
	}

	/**
	 * Methods for markers, which are the same for maps of all providers, @see gmaps.js and lmaps.js
	 * Note: the provider defines `_mapInstance`, `_markersByPost`, `_redraw()`, `_fitMarkers()`, `_refreshClusters()`,
	 * `_refreshMarkerIcons()`, `_updateMarkerIcon()`, `_isMarkerShown()`, `_getMapView()`, `_getMarkerLatLng()`
	 * and `_closeInfoWindow()`, this file is loaded before them.
	 */
	$us.mapMarkers = {

		/**
		 * @var {Number} The scale of the highlighted marker, except labels and the default marker of Google Maps
		 */
		_highlightScale: 1.25,

		/**
		 * Init the built-in marker style, @see templates/elements/gmaps.php
		 */
		_initMarkerStyle: function() {
			const self = this;
			// Labels get icons with their texts, @see _getLabelIcon()
			if ( self.options.markerStyle && self.options.markerStyle !== 'label' ) {
				self.options.icon = self._getStyleIcon();
			}
		},

		/**
		 * Get the icon of the built-in marker style, except the label, the same for maps of all providers.
		 * Note: the anchor is the tip of the pin and the center of other styles.
		 *
		 * @param {Number} contrast The optional contrast of colors, @see _getVisitedContrast()
		 * @return {{url: String, size: Number[], anchor: Number[]}}
		 */
		_getStyleIcon: function( contrast ) {
			const self = this;
			var color = getVariableColor( getComputedStyle( self.$container[0] ), '--marker-color' );
			// The inner parts are in the contrast color, the same as numbers of clusters
			var contrastColor = getContrastColor( color );
			if ( contrast && contrast !== 1 ) {
				color = applyContrastFilter( color, contrast );
				contrastColor = applyContrastFilter( contrastColor, contrast );
			}
			const width = $ush.parseInt( self.options.markerSize ) || 30;

			var svg, height = width, anchorY = width / 2, viewBox = '0 0 24 24';

			// The same circles as for clusters, the viewBox is in pixels to keep the halo width
			if ( self.options.markerStyle === 'dot' ) {
				viewBox = `0 0 ${width} ${width}`;
				svg = getHaloCircles( width, color );

			} else if ( self.options.markerStyle === 'ring' ) {
				svg = `<circle cx="12" cy="12" r="11" fill="${contrastColor}"/>`
					+ `<circle cx="12" cy="12" r="9.5" fill="${color}"/>`
					+ `<circle cx="12" cy="12" r="4" fill="${contrastColor}"/>`;

				// Pin, it's higher than wide
			} else {
				height = Math.round( width * 4 / 3 );
				anchorY = height;
				viewBox = '0 0 24 32';
				svg = `<path d="M12 0C5.4 0 0 5.3 0 11.9 0 20.8 12 32 12 32s12-11.2 12-20.1C24 5.3 18.6 0 12 0z" fill="${color}"/>`
					+ `<circle cx="12" cy="12" r="4.5" fill="${contrastColor}"/>`;
			}

			svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${viewBox}">${svg}</svg>`;

			return {
				url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent( svg ),
				size: [ width, height ],
				anchor: [ width / 2, anchorY ],
			};
		},

		/**
		 * Get the style of labels: colors, the font and sizes, which depend on the "Marker Size" setting.
		 * Note: the active label has swapped colors.
		 *
		 * @param {Boolean} active The label is active, its popup is open or it's highlighted
		 * @param {Boolean} visited The label is visited, its colors get the contrast, @see _getVisitedContrast()
		 * @return {{background: String, color: String, fontFamily: String, fontWeight: String, fontSize: Number, height: Number, padding: Number}}
		 */
		_getLabelStyle: function( active, visited ) {
			const self = this;
			if ( ! self._labelStyle ) {
				const style = getComputedStyle( self.$container[0] );
				const color = getVariableColor( style, '--marker-color' );
				const height = $ush.parseInt( self.options.markerSize ) || 30;
				self._labelStyle = {
					background: color,
					color: getContrastColor( color ),
					// The font of the map, the same as labels of OpenStreetMap inherit
					fontFamily: style.fontFamily,
					fontWeight: style.fontWeight,
					fontSize: Math.round( height * .5 ),
					height: height,
					padding: Math.round( height * .4 ),
				};
			}
			var style = self._labelStyle;
			if ( active ) {
				style = $.extend( {}, style, {
					background: style.color,
					color: style.background,
				} );
			}
			const contrast = visited ? self._getVisitedContrast() : 1;
			if ( contrast !== 1 ) {
				style = $.extend( {}, style, {
					background: applyContrastFilter( style.background, contrast ),
					color: applyContrastFilter( style.color, contrast ),
				} );
			}
			return style;
		},

		/**
		 * Get the contrast of visited markers of the "Fade visited markers" setting, @see templates/elements/gmaps.php
		 * Note: OpenStreetMap applies it by the CSS filter, while Google Maps doesn't draw markers in the DOM,
		 * so icons of built-in styles are drawn with colors of the contrast, @see common/css/vendor/leaflet.css
		 *
		 * @return {Number} The contrast from 0 to 1, it's 1 when the setting is off
		 */
		_getVisitedContrast: function() {
			const self = this;
			if ( $ush.isUndefined( self._visitedContrast ) ) {
				const value = parseFloat( getComputedStyle( self.$container[0] ).getPropertyValue( '--visited-marker-contrast' ) );
				self._visitedContrast = value > 0 ? Math.min( value / 100, 1 ) : 1;
			}
			return self._visitedContrast;
		},

		/**
		 * Get the icon of the label as an image, which width fits the text.
		 * Note: the text isn't in the image, because fonts of the page don't apply to images.
		 *
		 * @param {String} text The label text, the label without text is a circle
		 * @param {Boolean} active The label is active
		 * @param {Boolean} visited The label is visited
		 * @return {{url: String, size: Number[], anchor: Number[]}}
		 */
		_getLabelIcon: function( text, active, visited ) {
			const self = this;
			const style = self._getLabelStyle( active, visited );

			// The label without text is a circle of the same height
			const height = style.height;
			var width = height;
			if ( text ) {
				width = Math.ceil( getTextWidth( text, `${style.fontWeight} ${style.fontSize}px ${style.fontFamily}` ) ) + style.padding * 2;
			}

			// The inner 1px border of the semi-transparent black, the same as the shadow of labels in maps.css
			const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}">`
				+ `<rect width="${width}" height="${height}" rx="${height / 2}" fill="${style.background}"/>`
				+ `<rect x=".5" y=".5" width="${width - 1}" height="${height - 1}" rx="${( height - 1 ) / 2}" fill="none" stroke="#000" stroke-opacity=".15"/>`
				+ '</svg>';

			return {
				url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent( svg ),
				size: [ width, height ],
				anchor: [ width / 2, height / 2 ],
			};
		},

		/**
		 * Get the label text of the marker.
		 *
		 * @param {{}} item The marker data, markers of posts have their own labels with dynamic values
		 * @return {String}
		 */
		_getMarkerLabel: function( item ) {
			const self = this;
			if ( item && ! $ush.isUndefined( item.label ) ) {
				return $ush.toString( item.label );
			}
			return $ush.toString( self.options.markerLabel );
		},

		/**
		 * Set the active marker, it's the marker with the open popup: the label has swapped colors, any marker of posts
		 * is above other markers and has the default contrast, even if it's visited.
		 *
		 * @param {{}|null} marker The marker of the provider or null to reset
		 */
		_setActiveMarker: function( marker ) {
			const self = this;
			const previous = self._activeMarker;
			self._activeMarker = marker;
			if ( previous ) {
				self._updateMarkerIcon( previous );
			}
			if ( marker ) {
				self._updateMarkerIcon( marker );
			}
		},

		/**
		 * Get the state of the marker, which its icon depends on.
		 *
		 * @param {{}} marker The marker of the provider
		 * @param {Number} postId The post ID of the marker of posts, undefined for other markers
		 * @return {{active: Boolean, highlighted: Boolean, visited: Boolean}}
		 */
		_getMarkerState: function( marker, postId ) {
			const self = this;
			return {
				active: marker === self._activeMarker,
				highlighted: marker === self._highlightedMarker,
				visited: self._isPostVisited( postId ),
			};
		},

		/**
		 * Highlight the marker of the post, while its list item is hovered, @see highlightPostMarkers()
		 * Note: the marker in a cluster isn't shown, so nothing is highlighted, the cluster isn't either.
		 *
		 * @param {Number} postId The post ID, zero to reset
		 */
		highlightMarker: function( postId ) {
			const self = this;
			var marker = ( postId && self._markersByPost ) ? self._markersByPost.get( postId ) : null;
			if ( ! marker || ! self._isMarkerShown( marker ) ) {
				marker = null;
			}
			const previous = self._highlightedMarker || null;
			if ( marker === previous ) {
				return;
			}
			self._highlightedMarker = marker;
			if ( previous ) {
				self._updateMarkerIcon( previous );
			}
			if ( marker ) {
				self._updateMarkerIcon( marker );
			}
		},

		/**
		 * Check if the marker of the post was clicked, the state is kept until the page reload by post IDs,
		 * so markers keep it, when they are created again after filtering.
		 *
		 * @param {Number} postId The post ID
		 * @return {Boolean}
		 */
		_isPostVisited: function( postId ) {
			return !! ( this._visitedPosts && this._visitedPosts.has( postId ) );
		},

		/**
		 * Mark the marker of the post as visited on its click, it's done only, when the click opens the popup
		 * or the post, @see the "Marker Click" setting.
		 *
		 * @param {{}} marker The marker of the provider
		 * @param {Number} postId The post ID
		 */
		_markPostVisited: function( marker, postId ) {
			const self = this;
			self._visitedPosts = self._visitedPosts || new Set();
			if ( self._visitedPosts.has( postId ) ) {
				return;
			}
			self._visitedPosts.add( postId );
			// The active marker looks as not visited, so it's redrawn, when it's no longer active, @see _setActiveMarker()
			if ( marker !== self._activeMarker && marker !== self._highlightedMarker ) {
				self._updateMarkerIcon( marker );
			}
		},

		/**
		 * Get the icon of the built-in style for visited markers, its colors get the contrast, @see _getVisitedContrast()
		 * Note: it's cached the same way as the icon of other markers, until icons are updated.
		 *
		 * @return {{url: String, size: Number[], anchor: Number[]}}
		 */
		_getVisitedStyleIcon: function() {
			const self = this;
			if ( ! self._visitedStyleIcon ) {
				self._visitedStyleIcon = self._getStyleIcon( self._getVisitedContrast() );
			}
			return self._visitedStyleIcon;
		},

		/**
		 * Update icons of markers and clusters, e.g. after the Color Scheme Switch or loading of fonts.
		 */
		updateIcons: function() {
			const self = this;

			// Markers of the built-in style, they are drawn on the map init
			if ( self.options.markerStyle && self._mapInstance ) {
				delete self._labelStyle;
				delete self._visitedStyleIcon;
				if ( self.options.markerStyle !== 'label' ) {
					self.options.icon = self._getStyleIcon();
				}
				self._refreshMarkerIcons();
			}

			// Clusters weren't rendered yet, they get the current colors on the first render
			if ( self._clusterStyle ) {
				delete self._clusterStyle;
				self._refreshClusters();
			}
		},

		/**
		 * Save markers of posts, they are set on init, when the map isn't initialized yet.
		 *
		 * @param {[]} markers The markers list, each one is { id, lat, lng, url?, label? }
		 * @return {Boolean} True if the map is initialized and markers can be set, False otherwise.
		 */
		_saveMarkers: function( markers ) {
			const self = this;
			self.options.markers = Array.isArray( markers ) ? markers : [];
			// The map isn't initialized yet, e.g. until the load confirmation
			if ( ! self._mapInstance ) {
				self._pendingMarkers = self.options.markers;
				return false;
			}
			return true;
		},

		/**
		 * Restore markers of posts on init, which were filtered before it.
		 */
		_restorePendingMarkers: function() {
			const self = this;
			if ( self._pendingMarkers ) {
				self.options.markers = self._pendingMarkers;
				delete self._pendingMarkers;
			}
		},

		/**
		 * Check if the map is hidden, its zero size doesn't allow to fit markers, so they're fitted when it becomes visible.
		 *
		 * @return {Boolean} True if the map is hidden, False otherwise.
		 */
		_waitForVisibility: function() {
			const self = this;
			self._needsFit = self.$container.is( ':hidden' );
			if ( self._needsFit ) {
				self._observeVisibility();
			}
			return self._needsFit;
		},

		/**
		 * Redraw the hidden map, when it becomes visible, even if the "contentChange" event isn't triggered.
		 */
		_observeVisibility: function() {
			const self = this;
			if ( self._resizeObserver || typeof ResizeObserver === 'undefined' ) {
				return;
			}
			self._resizeObserver = new ResizeObserver( () => {
				if ( self.$container.is( ':hidden' ) ) {
					return;
				}
				// The observer isn't needed for the visible map, it's created again, if the map is hidden before fitting
				self._resizeObserver.disconnect();
				delete self._resizeObserver;
				// The map can be already fitted on the "contentChange" event
				if ( self._needsFit ) {
					self._redraw();
				}
			} );
			self._resizeObserver.observe( self.$container[0] );
		},

		/**
		 * Get the size of a cluster icon, it depends on the quantity of markers.
		 *
		 * @param {Number} count The quantity of markers in the cluster
		 * @return {Number} Returns the size in pixels.
		 */
		_getClusterSize: function( count ) {
			if ( count < 10 ) {
				return 36;
			}
			return count < 100 ? 44 : 52;
		},

		/**
		 * Get the style of cluster icons: the color of the "Cluster Color" setting, its contrast color for numbers
		 * and the font of the map, @see templates/elements/gmaps.php
		 *
		 * @return {{color: String, textColor: String, fontFamily: String}}
		 */
		_getClusterStyle: function() {
			const self = this;
			if ( ! self._clusterStyle ) {
				const style = getComputedStyle( self.$container[0] );
				const color = getVariableColor( style, '--cluster-color' );
				self._clusterStyle = {
					color: color,
					textColor: getContrastColor( color ),
					fontFamily: style.fontFamily,
				};
			}
			return self._clusterStyle;
		},

		/**
		 * Get the SVG of a cluster icon, the same for maps of all providers.
		 *
		 * @param {Number} size The icon size
		 * @param {String} title The optional title
		 * @return {String}
		 */
		_getClusterSvg: function( size, title ) {
			const self = this;
			const color = self._getClusterStyle().color;
			return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}">`
				+ ( title ? `<title>${$( '<i>' ).text( title ).html()}</title>` : '' )
				+ getHaloCircles( size, color )
				+ '</svg>';
		},

		/**
		 * Get the title of a cluster icon.
		 *
		 * @param {Number} count The quantity of markers in the cluster
		 * @return {String}
		 */
		_getClusterTitle: function( count ) {
			return $ush.toString( this.options.clusterTitle ).replace( '%d', count );
		},

		/**
		 * Get the popup content of the marker of posts, when popups are list items by the Grid Layout.
		 * The item is loaded via AJAX on the first click and replaces the loading state, the loaded one is kept
		 * with its initialized elements and shown at once on the next clicks, @see templates/elements/gmaps.php
		 *
		 * @param {Number} postId The post ID of the marker
		 * @param {Function} onLoad Called with the content node and the success flag, when the request is done,
		 *                          so the popup gets resized to the item or closed on a failure.
		 *                          Returns true, when the loaded item is shown in the popup.
		 * @return {Element} The content node: the loaded item or the loading state
		 */
		_getAjaxInfoWindow: function( postId, onLoad ) {
			const self = this;

			// Loaded items by post IDs, they don't change while markers are filtered
			self._infoWindowNodes = self._infoWindowNodes || {};
			if ( self._infoWindowNodes[ postId ] ) {
				return self._infoWindowNodes[ postId ];
			}

			// The class of the layout and the width from the settings, @see templates/elements/gmaps.php
			const $content = $( '<div class="w-map-infowindow loading"><div class="g-preloader type_1"></div></div>' )
				.addClass( $ush.toString( self.options.infoWindowClass ) )
				.attr( 'style', $ush.toString( self.options.infoWindowStyle ) )
				// Links with the "#" only close the popup the same way as in the Popup element, except arrows
				// of the product gallery, @see popup.js. The page isn't scrolled to the top by such a link.
				.on( 'click', 'a[href="#"]:not(.flex-prev):not(.flex-next)', ( e ) => {
					e.preventDefault();
					self._closeInfoWindow();
				} );

			// The shown item is kept with its initialized elements. Elements of the item init their JS on the same
			// event as elements of items loaded into lists, e.g. "Add to Favorites", @see add-to-favs.js. It's triggered
			// once, as the item is kept with its elements. The event is deferred the same way as lists do, because
			// some elements measure their sizes on init, while the provider shows the resized popup. The data has
			// no list and no filter, so List Filter and list counters skip the event, @see list-filter.js and post-list.js
			const keepItem = () => {
				self._infoWindowNodes[ postId ] = $content[0];
				$ush.timeout( () => {
					$us.$document.trigger( 'usPostList.itemsLoaded', [
						$content.children( '.w-grid-item' ),
						{
							postListUid: null,
							listFilterUid: null,
							listFiltersApplied: false,
						},
					] );
				}, 1 );
			};

			const posts = getInstance( self.$container[0] );

			// The item preloaded in the background is shown at once, without the loading state and a request,
			// @see usMapPosts.preloadInfoWindows()
			const html = posts.getInfoWindowHtml( postId );
			if ( html ) {
				$content.removeClass( 'loading' ).html( html );
				keepItem();
				return $content[0];
			}

			posts.loadInfoWindow( postId, ( html ) => {
				if ( ! html ) {
					onLoad( $content[0], false );
					return;
				}
				$content.removeClass( 'loading' ).html( html );

				// The popup can be closed or moved to another marker meanwhile, then the item isn't kept and is loaded
				// again on the next click, because elements of the hidden item would measure zero sizes on init
				if ( onLoad( $content[0], true ) ) {
					keepItem();
				}
			} );

			return $content[0];
		},

		/**
		 * Preload popups of markers of posts, which are shown on the map, in the background, when popups are items
		 * by the Grid Layout. Markers in clusters can't be clicked, so their popups aren't loaded until the cluster
		 * is zoomed in, that's why the provider calls it on changes of the map view and of markers, @see maps.js
		 */
		_preloadVisibleInfoWindows: function() {
			const self = this;
			if ( self.options.markerClick === 'grid_layout' && self._mapInstance && self._markersByPost ) {
				getInstance( self.$container[0] ).preloadInfoWindows( self._getVisiblePostIds() );
			}
		},

		/**
		 * Get post IDs of markers, which are shown within the map view, not in clusters, the nearest to the center first.
		 * Note: the provider defines `_getMapView()` and `_getMarkerLatLng()`, which return the latitude and longitude
		 * as the [ lat, lng ] pair.
		 *
		 * @return {Number[]}
		 */
		_getVisiblePostIds: function() {
			const self = this;
			const view = self._getMapView();
			const items = [];
			if ( ! view ) {
				return items;
			}
			self._markersByPost.forEach( ( marker, postId ) => {
				const latLng = self._getMarkerLatLng( marker );
				if ( latLng && self._isMarkerShown( marker ) && view.contains( latLng ) ) {
					items.push( {
						id: postId,
						// The squared distance in degrees is enough for the order
						distance: Math.pow( latLng[0] - view.center[0], 2 ) + Math.pow( latLng[1] - view.center[1], 2 ),
					} );
				}
			} );
			return items
				.sort( ( a, b ) => a.distance - b.distance )
				.map( ( item ) => item.id );
		},

		/**
		 * Close the popup by the Grid Layout on the Escape key, as it has no close button, e.g. after the marker
		 * is opened from the keyboard, @see templates/elements/gmaps.php
		 *
		 * @event handler
		 * @param {Event} e The keydown event
		 */
		_closeInfoWindowOnEscape: function( e ) {
			if ( e.key === 'Escape' ) {
				this._closeInfoWindow();
			}
		},

		/**
		 * Show or hide the message, when there are no markers of posts.
		 *
		 * @param {Boolean} state
		 */
		_toggleNoResults: function( state ) {
			const self = this;
			if ( ! self.$message ) {
				if ( ! state ) {
					return;
				}
				self.$message = $( '<div class="w-map-message"></div>' )
					.text( self.options.noResultsText || '' )
					.appendTo( self.$container );
			}
			self.$message.toggleClass( 'hidden', ! state );
		},
	};

	/**
	 * @param {Node} container The map container
	 */
	function usMapPosts( container ) {
		const self = this;

		// Elements
		self.$container = $( container );

		// Private "variables"
		// Note: List Filter takes "facetedFilter" the same way as from Post List, @see list-filter.js
		self.data = {
			ajaxData: {},
			facetedFilter: {},
			infowindowAjaxData: {}, // set for popups by the Grid Layout only
		};
		self.listFilterUid = null;

		// Get element settings
		$.extend( true, self.data, $ush.getPassedData( self.$container ) || {} );

		// Bindable events
		self._events = {
			loadMarkers: $ush.debounce( self.loadMarkers.bind( self ), 1 ),
		};
	}

	// Map Posts API
	$.extend( usMapPosts.prototype, {

		/**
		 * Set values from "List Filter".
		 *
		 * @param {{}} values
		 */
		usListFilter: function( values ) {
			const self = this;
			var hasChanges = false;
			$.each( values, ( name, value ) => {
				if ( self.applyFilter( name, value ) ) {
					hasChanges = true;
				}
			} );
			if ( hasChanges ) {
				self._events.loadMarkers();
			}
		},

		/**
		 * Set the search string from "List Search".
		 *
		 * @param {String} name
		 * @param {String} value The search text.
		 */
		usListSearch: function( name, value ) {
			const self = this;
			if ( self.applyFilter( name, value ) ) {
				self._events.loadMarkers();
			}
		},

		/**
		 * Apply param to the request of markers.
		 *
		 * @param {String} name
		 * @param {*} value
		 * @return {Boolean} True if the param changes markers, False otherwise.
		 */
		applyFilter: function( name, value ) {
			const self = this;
			if ( $ush.toString( value ) == '{}' ) {
				value = DELETE_FILTER;
			}

			// Names and types of all filters to get the post count of Faceted Filtering
			if ( name === 'list_filters' ) {
				$.extend( value, JSON.parse( self.data.ajaxData[ name ] || '{}' ) );
				self.data.ajaxData[ name ] = JSON.stringify( value );
				return false;
			}
			if ( name === 'list_filter_uid' ) {
				self.listFilterUid = value;
				return false;
			}

			// Only params of filters and search change markers, they have the URL param prefix,
			// while the other ones, like "scroll_to_list", control lists only
			if ( $ush.toString( name ).charAt( 0 ) !== '_' ) {
				return false;
			}

			if ( value === DELETE_FILTER ) {
				delete self.data.ajaxData[ name ];
			} else {
				self.data.ajaxData[ name ] = value;
			}
			return true;
		},

		/**
		 * Load markers of posts with the current filter params.
		 */
		loadMarkers: function() {
			const self = this;

			if ( ! $ush.isUndefined( self.xhr ) ) {
				self.xhr.abort();
			}

			self.$container.addClass( 'loading' );

			self.xhr = $.ajax( {
				type: 'post',
				url: $us.ajaxUrl,
				dataType: 'json',
				cache: false,
				data: self.data.ajaxData,
				success: ( res ) => {
					if ( ! res.success ) {
						console.error( ( res.data || {} ).message );
						return;
					}

					self.setMarkers( res.data.markers );

					if ( res.data.facetedFilter ) {
						$.extend( self.data.facetedFilter, res.data.facetedFilter );
					}

					// List Filter updates the post count of Faceted Filtering on this event
					$us.$document.trigger( 'usMapPosts.markersLoaded', [
						$(), // no list items, the same arguments as for the "usPostList.itemsLoaded" event
						{
							listFilterUid: self.listFilterUid,
							listFiltersApplied: true,
						},
					] );
				},
				error: ( _, status ) => {
					// The previous request is aborted by the next one
					if ( status !== 'abort' ) {
						console.error( `Markers of posts were not loaded: ${status}` );
					}
				},
				complete: () => {
					self.$container.removeClass( 'loading' );
					delete self.xhr;
				}
			} );
		},

		/**
		 * Set markers to the map of any provider.
		 *
		 * @param {[]} markers
		 */
		setMarkers: function( markers ) {
			const node = this.$container[0];
			const map = node._wGmaps || node._wLmaps;
			if ( map ) {
				map.setMarkers( markers );
				// The new markers are created without the highlight, while the list item of the post can stay hovered
				// or focused, e.g. after filtering by the keyboard, so its marker is highlighted again
				map.highlightMarker( highlightedPosts.pointer || highlightedPosts.focus );
			}
		},

		/**
		 * Load the popup of the post by the Grid Layout on the click, @see us_ajax_map_infowindow() in PHP.
		 * Note: the loaded HTML is kept by post IDs, the same way as the shown item is kept by the map,
		 * @see $us.mapMarkers._getAjaxInfoWindow(), and the pending request is aborted by a click on another marker.
		 * The click doesn't wait for the preload of popups in the background, @see preloadInfoWindows()
		 *
		 * @param {Number} postId The post ID
		 * @param {Function} callback Called with the HTML, when it's loaded, with the empty string on a failure
		 */
		loadInfoWindow: function( postId, callback ) {
			const self = this;

			if ( ! $ush.isUndefined( self.infoWindowXhr ) ) {
				self.infoWindowXhr.abort();
			}

			self.infoWindowXhr = $.ajax( {
				type: 'post',
				url: $us.ajaxUrl,
				dataType: 'json',
				data: $.extend(
					{
						post_id: postId,
						// The same signed data as for markers, @see templates/elements/gmaps.php
						map_data: self.data.ajaxData.map_data,
					},
					self.data.infowindowAjaxData
				),
				success: ( res ) => {
					if ( ! res.success ) {
						console.error( ( res.data || {} ).message );
						callback( '' );
						return;
					}
					const html = $ush.toString( res.data.html );
					self._keepInfoWindowHtml( postId, html );
					callback( html );
				},
				error: ( _, status ) => {
					// The previous request is aborted by the next one, its popup is replaced by another one
					if ( status !== 'abort' ) {
						console.error( `The marker popup was not loaded: ${status}` );
						callback( '' );
					}
				},
				complete: () => {
					delete self.infoWindowXhr;
				}
			} );
		},

		/**
		 * Get the loaded HTML of the popup of the post.
		 *
		 * @param {Number} postId The post ID
		 * @return {String} The HTML, the empty string when it isn't loaded yet
		 */
		getInfoWindowHtml: function( postId ) {
			return ( this._infoWindowHtml || {} )[ postId ] || '';
		},

		/**
		 * Keep the loaded HTML of the popup by the post ID until the page reload, the posts don't change
		 * while markers are filtered. A failure isn't kept, so the popup is requested again on the click.
		 *
		 * @param {Number} postId The post ID
		 * @param {String} html The HTML
		 */
		_keepInfoWindowHtml: function( postId, html ) {
			if ( html ) {
				this._infoWindowHtml = this._infoWindowHtml || {};
				this._infoWindowHtml[ postId ] = html;
			}
		},

		/**
		 * Preload popups of the shown markers in the background, so the click opens them at once without a request,
		 * the same way as map services show cards of pins from the loaded results, @see us_ajax_map_infowindow() in PHP.
		 * Popups are requested in batches, one request at a time, when the browser is idle, in the given order:
		 * the nearest to the map center first, @see $us.mapMarkers._preloadVisibleInfoWindows(). The quantity
		 * of loaded popups per page is limited by the "us_gmaps_infowindow_preload_limit" filter, popups loaded
		 * by clicks count too, @see templates/elements/gmaps.php
		 * Note: the queue is replaced on every call, e.g. after zooming, while the pending request finishes,
		 * because its popups are likely still shown.
		 *
		 * @param {Number[]} postIds Post IDs of the shown markers
		 */
		preloadInfoWindows: function( postIds ) {
			const self = this;
			self._cancelInfoWindowsBatch();

			const limit = $ush.parseInt( self.data.infoWindowPreload );
			if ( limit <= 0 || ! self.data.infowindowAjaxData.action ) {
				return;
			}
			const loaded = Object.keys( self._infoWindowHtml || {} ).length;
			self._infoWindowQueue = ( postIds || [] )
				.filter( ( postId ) => postId && ! self.getInfoWindowHtml( postId ) )
				.slice( 0, Math.max( limit - loaded, 0 ) );

			if ( $ush.isUndefined( self._infoWindowsXhr ) ) {
				self._scheduleInfoWindowsBatch();
			}
		},

		/**
		 * @var {Number} The quantity of popups in one request of the preload, the server accepts up to 50
		 */
		_infoWindowBatchSize: 20,

		/**
		 * Request the next batch of the preload, when the browser is idle, @see preloadInfoWindows()
		 */
		_scheduleInfoWindowsBatch: function() {
			const self = this;
			if ( ! self._infoWindowQueue.length ) {
				return;
			}
			const run = () => {
				delete self._infoWindowIdle;
				self._loadInfoWindowsBatch();
			};
			// The idle callback waits for the end of the page load and the markers rendering,
			// while its timeout runs it anyway on a busy page
			self._infoWindowIdle = window.requestIdleCallback
				? { idle: window.requestIdleCallback( run, { timeout: 1000 } ) }
				: { timer: $ush.timeout( run, 200 ) };
		},

		/**
		 * Load the next batch of popups of the preload, @see preloadInfoWindows()
		 */
		_loadInfoWindowsBatch: function() {
			const self = this;

			// Popups loaded by clicks meanwhile are skipped
			const postIds = self._infoWindowQueue
				.splice( 0, self._infoWindowBatchSize )
				.filter( ( postId ) => ! self.getInfoWindowHtml( postId ) );
			if ( ! postIds.length ) {
				self._scheduleInfoWindowsBatch();
				return;
			}

			self._infoWindowsXhr = $.ajax( {
				type: 'post',
				url: $us.ajaxUrl,
				dataType: 'json',
				data: $.extend(
					{
						post_ids: postIds,
						map_data: self.data.ajaxData.map_data,
					},
					self.data.infowindowAjaxData
				),
				success: ( res ) => {
					if ( ! res.success ) {
						console.error( ( res.data || {} ).message );
						return;
					}
					$.each( res.data.items || {}, ( postId, html ) => {
						self._keepInfoWindowHtml( $ush.parseInt( postId ), $ush.toString( html ) );
					} );
					self._scheduleInfoWindowsBatch();
				},
				error: ( _, status ) => {
					// A failure stops the preload until the next change of the map view, as the next batches would fail too
					if ( status !== 'abort' ) {
						console.error( `Marker popups were not preloaded: ${status}` );
					}
				},
				complete: () => {
					delete self._infoWindowsXhr;
				}
			} );
		},

		/**
		 * Cancel the scheduled batch of the preload, @see preloadInfoWindows()
		 */
		_cancelInfoWindowsBatch: function() {
			const self = this;
			self._infoWindowQueue = [];
			if ( self._infoWindowIdle ) {
				if ( self._infoWindowIdle.idle ) {
					window.cancelIdleCallback( self._infoWindowIdle.idle );
				} else {
					$ush.clearTimeout( self._infoWindowIdle.timer );
				}
				delete self._infoWindowIdle;
			}
		},
	} );

	/**
	 * Get the instance of the map container, it's created on the first use.
	 *
	 * @param {Node} node The map container
	 * @return {usMapPosts}
	 */
	function getInstance( node ) {
		var instance = $.data( node, 'usMapPosts' );
		if ( ! instance ) {
			instance = new usMapPosts( node );
			$.data( node, 'usMapPosts', instance );
		}
		return instance;
	}

	/**
	 * Get the Map with markers of posts, which List Filter and List Search apply to along with the first list.
	 * Note: the visible map is preferred, e.g. when different maps are shown for different screen sizes.
	 *
	 * @param {jQuery} $context The content to search the map in
	 * @return {jQuery} Returns the node of the found map, empty when there is none.
	 */
	$us.getMapForPosts = function( $context ) {
		const $maps = $( '.w-map.for_posts', $context );
		const $visibleMap = $maps.filter( ':visible' ).first();
		return $visibleMap.length ? $visibleMap : $maps.first();
	};

	// Events of List Filter and List Search, they are handled on the document to not depend on the init order
	$( document )
		.on( 'usListFilter', '.w-map.for_posts', ( e, values ) => {
			getInstance( e.currentTarget ).usListFilter( values );
		} )
		.on( 'usListSearch', '.w-map.for_posts', ( e, name, value ) => {
			getInstance( e.currentTarget ).usListSearch( name, value );
		} );

	// Colors of markers and clusters can depend on the color scheme, the timeout runs after the scheme is changed,
	// @see common/js/base/_general.js
	$( document ).on( 'change', '[name=us-color-scheme-switch]', () => {
		$ush.timeout( () => {
			$( '.w-map' ).each( ( _, node ) => {
				const map = node._wGmaps || node._wLmaps;
				if ( map ) {
					map.updateIcons();
				}
			} );
		}, 1 );
	} );

	/**
	 * @var {{pointer: Number, focus: Number}} Post IDs of list items under the cursor and with the keyboard focus
	 */
	const highlightedPosts = {
		pointer: 0,
		focus: 0,
	};

	/**
	 * @var {Node|null} The list item under the cursor
	 */
	var hoveredItem = null;

	/**
	 * @var {jQuery} Maps with markers of posts, which are on the page on its load
	 */
	var $postMaps = $();

	/**
	 * Highlight markers of the post of the hovered or focused list item on all maps with markers of posts.
	 * Note: list items and markers are linked by post IDs only, so any list on the page works with any map.
	 */
	function highlightPostMarkers() {
		const postId = highlightedPosts.pointer || highlightedPosts.focus;
		$postMaps.each( ( _, node ) => {
			const map = node._wGmaps || node._wLmaps;
			if ( map ) {
				map.highlightMarker( postId );
			}
		} );
	}

	/**
	 * Get the post ID of the list item, @see templates/loop/item-post.php
	 *
	 * @param {Node} node The list item
	 * @return {Number} The post ID, zero for items in popups of maps, which belong to the marker itself
	 */
	function getListItemPostId( node ) {
		if ( $( node ).closest( '.w-map-infowindow' ).length ) {
			return 0;
		}
		return $ush.parseInt( node.getAttribute( 'data-id' ) );
	}

	/**
	 * Set the list item under the cursor and highlight markers of its post, when it's another item.
	 *
	 * @param {Node|null} node The list item or null, when the cursor isn't over any item
	 */
	function setHoveredItem( node ) {
		if ( node === hoveredItem ) {
			return;
		}
		hoveredItem = node;
		highlightedPosts.pointer = node ? getListItemPostId( node ) : 0;
		highlightPostMarkers();
	}

	/**
	 * Items of Post List and Product List highlight markers of their posts, the handlers are on the document,
	 * so items loaded via AJAX pagination or filtering work without init.
	 */
	function bindListItemEvents() {
		$( document )
			// The item is checked on the move over any element instead of leaving the item, so it's reset also,
			// when the hovered item is removed from the page, e.g. by its own button, which fires no "pointerleave"
			.on( 'pointerover', ( e ) => {
				// Touch screens have no hover, while a tap fires the event and would keep the marker highlighted
				if ( e.originalEvent.pointerType === 'touch' ) {
					return;
				}
				setHoveredItem( $( e.target ).closest( '.w-grid-item[data-id]' )[0] || null );
			} )
			.on( 'pointerout', ( e ) => {
				// The cursor leaves the page
				if ( ! e.originalEvent.relatedTarget ) {
					setHoveredItem( null );
				}
			} )
			.on( 'focusin', '.w-grid-item[data-id]', ( e ) => {
				// The focus from the keyboard only, not by a click or a tap
				highlightedPosts.focus = e.target.matches( ':focus-visible' ) ? getListItemPostId( e.currentTarget ) : 0;
				highlightPostMarkers();
			} )
			.on( 'focusout', '.w-grid-item[data-id]', ( e ) => {
				// The focus moves inside the same item
				if ( e.relatedTarget && e.currentTarget.contains( e.relatedTarget ) ) {
					return;
				}
				highlightedPosts.focus = 0;
				highlightPostMarkers();
			} );
	}

	$( () => {
		const $maps = $( '.w-map.for_posts' );

		// List Filter takes the data for Faceted Filtering on its init, when it applies to the map instead of a list
		$maps.each( ( _, node ) => {
			getInstance( node );
		} );

		// The page without maps of posts has nothing to highlight, while this file can be in the assets of all pages.
		// The found maps are kept, so they aren't searched on every hover of list items.
		// Note: a map added later, e.g. by the Live Builder, highlights its markers after the page reload.
		if ( $maps.length ) {
			$postMaps = $maps;
			bindListItemEvents();
		}
	} );

} )( jQuery );
