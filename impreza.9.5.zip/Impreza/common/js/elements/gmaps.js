/**
 * UpSolution Element: Google Maps
 *
 * Used for [us_gmaps] shortcode
 * @requires jQuery
 */
! function( $, undefined ) {
	"use strict";

	// Private variables that are used only in the context of this function, it is necessary to optimize the code
	var _document = document,
		_window = window,
		_null = null;

	// Check for is set objects
	_window.$us = _window.$us || {};

	/**
	 * @type {RegExp} Regular expression to check or extract coordinates.
	 */
	const _REGEXP_EXTRACT_COORDINATES_ = /^(-?[\d\.]+),(-?[\d\.]+)$/;

	/**
	 * @var {Function} The handler is called when Maps API is ready to use
	 */
	_window.usGmapLoaded = function() {
		$us.$document.trigger( 'usGmapLoaded' );
	};

	/**
	 * @var {{}}
	 */
	$us._wGmapsGeocodes = {
		_maxAttempts: 5, // maximum number of attempts
		_tasks: {}, // task stack

		/**
		 * Add a new task
		 *
		 * @param {String} key The unique key
		 * @param {Function} callback The callback
		 * @return {Function} self.run()
		 */
		add: function( key, callback ) {
			var self = this;
			self._tasks[ '' + key ] = {
				counter: 0,
				running: false,
				callback: callback,
			};
			return self.run.bind( self, key );
		},

		/**
		 * Remove task by key
		 *
		 * @param {String} key The unique key
		 */
		remove: function( key ) {
			var self = this;
			if ( self._tasks[ key ] ) {
				delete self._tasks[ key ];
			}
		},

		/**
		 * Run a task from the stack by key
		 *
		 * @param {String} key The unique key
		 */
		run: function( key ) {
			var self = this, task = self._tasks[ key ];
			if ( $ush.isUndefined( task ) || task.running ) {
				return;
			}
			if ( task.counter >= self._maxAttempts ) {
				self.remove( key );
				return;
			}
			if ( typeof task.callback === 'function' ) {
				task.counter++;
				task.running = true;
				task.callback( /* stopGeocodeTask */function() {
					task.running = false;
				} );
			}
		},

		/**
		 * Run a task from the stack by key again after a delay
		 *
		 * @param {String} key The unique key
		 */
		retry: function( key ) {
			var self = this, task = self._tasks[ key ];
			if ( $ush.isUndefined( task ) ) {
				return;
			}
			task.running = false;
			$ush.timeout( self.run.bind( self, key ), 2000 );
		}
	};

	/**
	 * @class wGmaps
	 * @param {Node} container The node container
	 * @param {{}} options The map options
	 */
	$us.wGmaps = function ( container, options ) {
		var self = this;

		// Elements
		self.$container = $( container );

		// Prevent double init
		if ( self.$container.data( '_inited' ) ) {
			return;
		}
		self.$container.data( '_inited', 1 );

		// Variables
		self._mapInstance = _null; // An instance of the Google Maps object
		self.cookieName = self.$container.data( 'cookie-name' ); // The cookie name to save the load consent
		self.options = options || {}; // Main options of the element
		self.style = {}; // Setting styles derived from the frontend
		self.uniqid = $ush.uniqid(); // Unique element id

		// Get a key to connect to the Google API
		var attributeName = 'data-api-key';
		if ( self.$container.is( '[' + attributeName + ']' ) ) {
			self._apiKey = self.$container.attr( attributeName );
			self.$container.removeAttr( attributeName );
		}

		/**
		 * @var {{}} Bindable events
		 */
		self._events = {
			confirm: self._confirm.bind( self ),
			redraw: self._redraw.bind( self ),
			init: self._init.bind( self ),
			markerClick: self._openInfoWindow.bind( self ),
			markerLink: self._openMarkerLink.bind( self ),
			closeInfoWindow: self._closeInfoWindow.bind( self ),
			keydown: self._closeInfoWindowOnEscape.bind( self ),
			// Popups of the shown markers are preloaded after the map view settles, the clusterer renders markers
			// on the same "idle" event, so its "clusteringend" is the last one, @see maps.js
			preloadVisible: $ush.debounce( self._preloadVisibleInfoWindows.bind( self ), 300 ),
		};

		// Events
		$us.$document
			// The handler is called when Maps API is ready to use
			.on( 'usGmapLoaded', self._events.init );

		// Initialization via confirmations
		if ( self.cookieName ) {
			self.$container
				.on( 'click', '.action_confirm_load', self._events.confirm )
				// The acceptance in the Cookie Notice, see _general.js
				.on( 'usLoadConfirmed', self._events.confirm );

			// The consent given earlier is checked on the client, as page caches skip the server-side check
			if ( $ush.isLoadConfirmed( self.$container ) ) {
				self._confirm();
			}
			return;
		}

		// Init the map
		self[ self.isGmapLoaded() ? '_init' : '_initAftetGmapLoaded' ]();
	};

	/**
	 * Export API
	 */
	// Note: methods for markers are common for all providers, @see maps.js
	$.extend( $us.wGmaps.prototype, $us.mapMarkers || {}, {

		/**
		 * Determines if gmap loaded
		 *
		 * @return {Boolean} True if Maps API loaded, False otherwise
		 */
		isGmapLoaded: function() {
			return !! ( _window['google'] || {} )['maps'];
		},

		/**
		 * Map initialization handler after confirmation
		 *
		 * @event handler
		 */
		_confirm: function() {
			var self = this;

			// Save permission to loading maps in cookies
			if ( $( 'input[name^=' + self.cookieName + ']:checked', self.$container ).length ) {
				$ush.setCookie( self.cookieName, /* value */1, /* days */365 );
			}

			self.$container
				// Add map html markup to element
				.html( $ush.base64Decode( '' + $( 'script[type="text/template"]', self.$container ).text() ) )
				.removeAttr( 'data-cookie-name' );

			// Init the map
			self[ self.isGmapLoaded() ? '_init' : '_initAftetGmapLoaded' ]();
		},

		/**
		 * Init the map
		 *
		 * @event handler
		 * @link https://developers.google.com/maps/documentation/javascript/overview
		 */
		_init: function() {
			var self = this;

			if (
				// If there is an attribute, stop initialization because it is not a validated map
				self.$container.is( '[data-cookie-name]' )
				// If the google.maps object is not loaded, stop the initialization
				|| ! self.isGmapLoaded()
			) {
				return;
			}

			// Get map options
			var $mapJson = $( '.w-map-json', self.$container );
			$.extend( self.options, $ush.getPassedData( $mapJson ) || {} );
			$mapJson.remove();

			// Markers of posts, which were filtered before the map init
			if ( self.options.fitMarkers ) {
				self._restorePendingMarkers();
			}

			self._initMarkerStyle();

			// Labels are measured in the font of the page, so they're redrawn, when it's loaded, @see maps.js
			if ( self.options.markerStyle === 'label' && document.fonts && document.fonts.status !== 'loaded' ) {
				document.fonts.ready.then( function() {
					self._refreshMarkerIcons();
				} );
			}

			// Get style options
			var $styleJson = $( '.w-map-style-json', self.$container );
			self.style = $ush.getPassedData( $styleJson ) || self.style;
			$styleJson.remove();

			/**
			 * @var {{}} Map options
			 */
			var mapOptions = {
				el: '#' + self.$container.attr( 'id' ),
				lat: 0,
				lng: 0,
				mapTypeId: google.maps.MapTypeId[ self.options.maptype ],
				type: self.options.type,
				zoom: self.options.zoom
			};

			if ( self.options.hideControls ) {
				mapOptions.disableDefaultUI = true;
			}

			// The mouse wheel zooms the map without the Ctrl key the same as for OpenStreetMap, while the default
			// "auto" value requires it on scrollable pages. Touch screens keep the default value, which moves the map
			// with two fingers on scrollable pages, so one finger still scrolls the page past the map.
			// The "cooperative" value zooms the map with Ctrl key only, and moves it on touch screens with two fingers.
			// Note: it replaces "scrollwheel" and "draggable" options, which are deprecated by Google.
			// @link https://developers.google.com/maps/documentation/javascript/interaction
			var isTouch = ! $us.$html.hasClass( 'no-touch' );
			if ( self.options.disableZoom || ( self.options.disableDragging && isTouch ) ) {
				mapOptions.gestureHandling = 'cooperative';
			} else if ( ! isTouch ) {
				mapOptions.gestureHandling = 'greedy';
			}

			// Create an instance of the GMaps class
			self._mapInstance = new GMaps( mapOptions );

			// Set map style
			if ( self.style != _null && Array.isArray( self.style ) ) {
				self._mapInstance.map.setOptions( { styles: self.style } );
			}

			// The popup by the Grid Layout has no close button, so it's closed by the click on the map the same way
			// as OpenStreetMap does, and by the Escape key, e.g. after the marker is opened from the keyboard
			if ( self.options.markerClick === 'grid_layout' ) {
				self._mapInstance.map.addListener( 'click', self._events.closeInfoWindow );
				self._mapInstance.map.addListener( 'idle', self._events.preloadVisible );
				self.$container.on( 'keydown', self._events.keydown );
			}

			// Markers of posts, the map fits all of them
			if ( self.options.fitMarkers ) {
				self.setMarkers( self.options.markers );
			} else {
				self._initManualMarkers();
			}

			$us.$canvas.on( 'contentChange', self._events.redraw );

			// Note: In case some toggler was opened before the actual page load
			$us.$window.on( 'load', self._events.redraw );
		},

		/**
		 * Set the map center and markers of the "Manual" source
		 */
		_initManualMarkers: function() {
			var self = this;

			var shouldRunGeoCode,
				matches = $ush.removeSpaces( '' + self.options.address ) // Remove all spaces and tabs
					.match( _REGEXP_EXTRACT_COORDINATES_ ); // Example: -0.00000,0.00000

			if ( matches ) {
				self.options.latitude = matches[/* latitude */1];
				self.options.longitude = matches[/* longitude */2];
				$ush.timeout( function() {
					self._mapInstance.setCenter( self.options.latitude, self.options.longitude );
				}, 1 );
			} else {
				// Get the address coordinates through the reverse call function
				$us._wGmapsGeocodes.add( self.uniqid, function( stopGeocodeTask ) {
					self._mapGeoCode(
						self.uniqid,
						self.options.address,
						function( latitude, longitude ) {
							self.options.latitude = latitude;
							self.options.longitude = longitude;
							self._mapInstance.setCenter( latitude, longitude );
							if ( typeof stopGeocodeTask === 'function' ) {
								stopGeocodeTask();
							}
						},
						self.uniqid
					)
				} )/* run */();
			}

			// Map Markers
			$.each( self.options.markers, function( i, _ ) {
				var markerOptions;
				if ( self.options.markers[ i ].marker_img != _null ) {
					markerOptions = self._getIconOptions( {
						url: self.options.markers[ i ].marker_img[0],
						size: self.options.markers[ i ].marker_size,
					} );
				} else {
					markerOptions = self._getMarkerOptions( self._getMarkerLabel() );
				}

				if ( self.options.markers[ i ] != _null ) {
					var matches = $ush.removeSpaces( self.options.markers[ i ].address ) // Remove all spaces and tabs
						.match( _REGEXP_EXTRACT_COORDINATES_ );
					if ( matches ) {
						markerOptions.lat = matches[/* latitude */1];
						markerOptions.lng = matches[/* longitude */2];
						// Do not output empty tooltips
						if ( self.options.markers[ i ].html ) {
							markerOptions.infoWindow = { content: self.options.markers[ i ].html };
						}
						var marker = self._mapInstance.addMarker( markerOptions );
						self._watchActiveMarker( marker );
						if ( self.options.markers[ i ].infowindow && marker.infoWindow ) {
							marker.infoWindow.open( self._mapInstance.map, marker );
						}
					} else {
						var markerGeocodeId = self.uniqid + ':' + i; // the unique marker id
						// Get the address coordinates through the reverse call function
						$us._wGmapsGeocodes.add( markerGeocodeId, function( stopGeocodeTask ) {
							self._mapGeoCode(
								markerGeocodeId,
								self.options.markers[i].address,
								function( latitude, longitude ) {
									markerOptions.lat = latitude;
									markerOptions.lng = longitude;
									if ( self.options.markers[ i ].html ) {
										markerOptions.infoWindow = { content: self.options.markers[ i ].html };
									}
									var marker = self._mapInstance.addMarker( markerOptions );
									self._watchActiveMarker( marker );
									if ( self.options.markers[ i ].infowindow && marker.infoWindow ) {
										marker.infoWindow.open( {
											map: self._mapInstance.map,
											anchor: marker,
											shouldFocus: false,
										} );
									}
									if ( typeof stopGeocodeTask === 'function' ) {
										stopGeocodeTask();
									}
								}
							);
						} )/* run */();
					}
				}
			});
		},

		/**
		 * Get the address coordinates through the reverse call function
		 *
		 * @param {String} uniqid The unique iteration id
		 * @param {String} address The address
		 * @param {Function} callback The callback
		 *
		 * @link https://developers.google.com/maps/documentation/javascript/geocoding
		 */
		_mapGeoCode: function( uniqid, address, callback ) {
			var self = this;
			GMaps.geocode( {
				address: address,
				callback: function( results, status ) {
					if ( status == 'OK' ) {
						var location = results[0].geometry.location;
						if ( typeof callback === 'function' ) {
							callback.call( _null, location.lat(), location.lng(), results );
						}
						$us._wGmapsGeocodes.remove( uniqid );
					} else if ( status == 'OVER_QUERY_LIMIT' ) {
						$us._wGmapsGeocodes.retry( uniqid );
					}
				}
			} );
		},

		/**
		 * Get options of the marker with the icon
		 *
		 * @param {{url: String, size: Number[], anchor: Number[]}} icon The icon, the anchor is optional
		 * @param {Number} scale The optional scale of the icon, the anchor is scaled too, so the icon keeps its point
		 * @return {{}} Returns the marker options
		 */
		_getIconOptions: function( icon, scale ) {
			scale = scale || 1;
			var size = new google.maps.Size(
				$ush.parseInt( icon.size[/* width */0] ) * scale,
				$ush.parseInt( icon.size[/* height */1] ) * scale
			);
			var options = {
				icon: {
					url: icon.url,
					size: size,
					scaledSize: size,
				},
			};
			// Without the anchor, the image is anchored at its bottom center
			if ( icon.anchor ) {
				options.icon.anchor = new google.maps.Point( icon.anchor[/* x */0] * scale, icon.anchor[/* y */1] * scale );
				// The popup opens above the image. The scale isn't applied, because Google moves the open popup
				// along with the anchor point, so it would jump, while the list item of its marker is hovered
				options.anchorPoint = new google.maps.Point( 0, - icon.anchor[/* y */1] );
			}
			return options;
		},

		/**
		 * Get options of the marker of the "Marker Style" setting, @see maps.js
		 *
		 * @param {String} label The label text, it's used by the label style only
		 * @param {{active: Boolean, highlighted: Boolean, visited: Boolean}} state The optional state, @see maps.js
		 * @return {{}} Returns the marker options
		 */
		_getMarkerOptions: function( label, state ) {
			var self = this,
				options = {};

			state = state || {};

			// The label under the cursor has swapped colors, the same as the label with the open popup
			var active = state.active || state.highlighted,
				// The active marker has the default contrast, even if it's visited
				visited = state.visited && ! active;

			if ( self.options.markerStyle === 'label' ) {
				var style = self._getLabelStyle( active, visited );
				options = self._getIconOptions( self._getLabelIcon( label, active, visited ) );

				// The text is the label of the marker, because it gets the font of the page unlike the image
				options.icon.labelOrigin = options.icon.anchor;
				options.label = label
					? {
						text: label,
						color: style.color,
						fontFamily: style.fontFamily,
						fontSize: style.fontSize + 'px',
						fontWeight: style.fontWeight,
					}
					: _null;

				// The active marker is above other markers and clusters
				options.zIndex = active ? $ush.parseInt( google.maps.Marker.MAX_ZINDEX ) * 2 : _null;
				options.markerLabel = label;

				// Other icons are enlarged under the cursor and are above other markers too, while the default
				// marker of Google can't be enlarged, so it stays as is
			} else if ( self.options.icon != _null ) {
				// Markers aren't in the DOM, so the CSS filter of visited markers can't apply, as for OpenStreetMap,
				// instead icons of built-in styles are drawn with colors of the same contrast, while the custom
				// image and the default marker stay as is, @see maps.js
				var icon = self.options.icon;
				if ( visited && self.options.markerStyle && self._getVisitedContrast() !== 1 ) {
					icon = self._getVisitedStyleIcon();
				}
				options = self._getIconOptions( icon, state.highlighted ? self._highlightScale : 1 );
				options.zIndex = active ? $ush.parseInt( google.maps.Marker.MAX_ZINDEX ) * 2 : _null;
			}

			// Icons of the built-in style are updated, e.g. after the Color Scheme Switch
			if ( self.options.markerStyle ) {
				options.styleIcon = true;
			}

			return options;
		},

		/**
		 * Update the icon of the marker of the built-in style, @see maps.js
		 *
		 * @param {google.maps.Marker} marker The marker
		 */
		_updateMarkerIcon: function( marker ) {
			var self = this;
			marker.setOptions( self._getMarkerOptions(
				marker.get( 'markerLabel' ),
				self._getMarkerState( marker, marker.get( 'postId' ) )
			) );
		},

		/**
		 * Check if the marker is shown on the map, it isn't, when it's in a cluster, @see maps.js
		 *
		 * @param {google.maps.Marker} marker The marker
		 * @return {Boolean}
		 */
		_isMarkerShown: function( marker ) {
			return !! marker.getMap();
		},

		/**
		 * Get the map view for the preload of popups of shown markers, @see maps.js
		 *
		 * @return {{center: Number[], contains: Function}|null} The center as [ lat, lng ] and the check of the bounds,
		 *                                                      null while the map has no bounds yet
		 */
		_getMapView: function() {
			var map = this._mapInstance.map,
				bounds = map.getBounds(),
				center = map.getCenter();
			if ( ! bounds || ! center ) {
				return _null;
			}
			return {
				center: [ center.lat(), center.lng() ],
				contains: function( latLng ) {
					return bounds.contains( { lat: latLng[/* lat */0], lng: latLng[/* lng */1] } );
				},
			};
		},

		/**
		 * Get the position of the marker, @see maps.js
		 *
		 * @param {google.maps.Marker} marker The marker
		 * @return {Number[]|null} The [ lat, lng ] pair
		 */
		_getMarkerLatLng: function( marker ) {
			var position = marker.getPosition();
			return position ? [ position.lat(), position.lng() ] : _null;
		},

		/**
		 * Update icons of all markers of the built-in style, @see maps.js
		 */
		_refreshMarkerIcons: function() {
			var self = this;
			// Markers of posts hidden in clusters are in the list too
			$.each( self._mapInstance.markers, function( _, marker ) {
				if ( marker.get( 'styleIcon' ) ) {
					self._updateMarkerIcon( marker );
				}
			} );
		},

		/**
		 * Make the marker of the label style active, while its popup is open, @see maps.js
		 * Note: it's for markers of the "Manual" source with their own popups, markers of posts share one, @see _openInfoWindow()
		 *
		 * @param {google.maps.Marker} marker The marker
		 */
		_watchActiveMarker: function( marker ) {
			var self = this;
			// Additional markers with their own images aren't labels
			if ( self.options.markerStyle !== 'label' || ! marker.get( 'styleIcon' ) || ! marker.infoWindow ) {
				return;
			}
			marker.infoWindow.addListener( 'visible', function() {
				self._setActiveMarker( marker );
			} );
			marker.infoWindow.addListener( 'close', function() {
				if ( self._activeMarker === marker ) {
					self._setActiveMarker( _null );
				}
			} );
		},

		/**
		 * Get the popup shared by all markers of posts, it's created on the first use.
		 * Note: a popup per marker would mean up to a thousand InfoWindow objects with their listeners,
		 * recreated on every filtering, while a single one is open at a time anyway.
		 *
		 * @return {google.maps.InfoWindow}
		 */
		_getInfoWindow: function() {
			var self = this;
			if ( ! self._infoWindow ) {
				self._infoWindow = new google.maps.InfoWindow();
				// The marker stays active while the popup is open, @see maps.js
				self._infoWindow.addListener( 'close', function() {
					self._setActiveMarker( _null );
				} );
			}
			return self._infoWindow;
		},

		/**
		 * Show the popup of the marker of posts on its click, @see setMarkers()
		 *
		 * @param {google.maps.Marker} marker The clicked marker
		 */
		_openInfoWindow: function( marker ) {
			var self = this,
				infoWindow = self._getInfoWindow();

			// Opening the open popup, also at another marker, fires "close" within open(), which resets the active
			// marker, so the clicked one is made active after it
			var showInfoWindow = function() {
				infoWindow.open( {
					map: self._mapInstance.map,
					anchor: marker,
					shouldFocus: false,
				} );
				// Not only labels: the active marker has the default contrast, even if it's visited
				self._setActiveMarker( marker );
			};

			// The item by the Grid Layout is loaded on the first click, @see maps.js
			infoWindow.setContent( self._getAjaxInfoWindow( marker.get( 'postId' ), function( node, isLoaded ) {
				// The popup can be moved to another marker or closed meanwhile
				if ( infoWindow.getContent() !== node || ! infoWindow.isOpen ) {
					return false;
				}
				// The popup is opened again with the loaded item, because Google pans the map to fit the popup
				// on open() only, not on the content change. A failure leaves nothing to show
				if ( isLoaded ) {
					showInfoWindow();
					return true;
				}
				infoWindow.close();
				return false;
			} ) );
			showInfoWindow();

			// After the marker is active, so its icon isn't redrawn, as the active marker looks as not visited
			self._markPostVisited( marker, marker.get( 'postId' ) );
		},

		/**
		 * Close the popup shared by markers of posts, @see _getInfoWindow() and maps.js
		 */
		_closeInfoWindow: function() {
			if ( this._infoWindow ) {
				this._infoWindow.close();
			}
		},

		/**
		 * Open the post of the marker in a new tab on its click, @see setMarkers()
		 *
		 * @param {google.maps.Marker} marker The clicked marker
		 */
		_openMarkerLink: function( marker ) {
			var url = $ush.toString( marker.get( 'postUrl' ) );
			if ( url ) {
				this._markPostVisited( marker, marker.get( 'postId' ) );
				_window.open( url, '_blank', 'noopener' );
			}
		},

		/**
		 * Set markers of posts and fit the map to them
		 *
		 * @param {[]} markers The markers list, each one is { id, lat, lng, url? }
		 */
		setMarkers: function( markers ) {
			var self = this;

			if ( ! self._saveMarkers( markers ) ) {
				return;
			}

			self.clearMarkers();

			// The same options for all markers, except labels with their own texts
			var sharedOptions = ( self.options.markerStyle !== 'label' ) ? self._getMarkerOptions() : _null;

			var clusterer = self._getClusterer();

			$.each( self.options.markers, function( _, item ) {
				// Markers, which were clicked before filtering, stay visited, so they get their own options
				var isVisited = self._isPostVisited( item.id ),
					markerOptions = $.extend(
						{
							lat: item.lat,
							lng: item.lng,
							postId: item.id,
						},
						( sharedOptions && ! isVisited )
							? sharedOptions
							: self._getMarkerOptions( self._getMarkerLabel( item ), { visited: isVisited } )
					);
				// The "Marker Click" setting: the shared popup shows the item by the Grid Layout, which is loaded
				// by the post ID, @see _openInfoWindow(), or the post link is opened in a new tab
				if ( self.options.markerClick === 'grid_layout' ) {
					markerOptions.click = self._events.markerClick;
				} else if ( self.options.markerClick === 'post_link' && item.url ) {
					markerOptions.postUrl = item.url;
					markerOptions.click = self._events.markerLink;
				}
				// Clustered markers are added to the map by the clusterer at once, it's much faster than one by one
				var marker;
				if ( clusterer ) {
					marker = self._mapInstance.createMarker( markerOptions );
					self._mapInstance.markers.push( marker );
				} else {
					marker = self._mapInstance.addMarker( markerOptions );
				}
				// Markers by post IDs, so the hovered list item finds its marker at once, @see maps.js
				self._markersByPost.set( item.id, marker );
			} );

			if ( clusterer ) {
				clusterer.addMarkers( self._mapInstance.markers );
			}

			self._fitMarkers();

			// Popups of the shown markers are loaded in the background, also when the view isn't changed, @see maps.js
			self._events.preloadVisible();
		},

		/**
		 * Get the clusterer of markers, it's created on the first use
		 * @link https://github.com/googlemaps/js-markerclusterer
		 *
		 * @return {markerClusterer.MarkerClusterer|null} Returns NULL when clustering is off
		 */
		_getClusterer: function() {
			var self = this,
				lib = _window.markerClusterer;

			if ( ! self.options.clusterMarkers || ! lib ) {
				return _null;
			}

			// GMaps clears this clusterer along with its markers, @see clearMarkers()
			if ( ! self._mapInstance.markerClusterer ) {
				self._mapInstance.markerClusterer = new lib.MarkerClusterer( {
					map: self._mapInstance.map,
					renderer: {
						render: function( cluster ) {
							return new google.maps.Marker( $.extend( self._getClusterIcon( cluster.count ), {
								position: cluster.position,
								title: self._getClusterTitle( cluster.count ),
								// Clusters are above markers, the bigger ones are above the smaller ones
								zIndex: $ush.parseInt( google.maps.Marker.MAX_ZINDEX ) + cluster.count,
							} ) );
						},
					},
				} );
				// Markers are shown or hidden in clusters after the clustering, their popups are preloaded, @see maps.js
				if ( self.options.markerClick === 'grid_layout' ) {
					google.maps.event.addListener( self._mapInstance.markerClusterer, 'clusteringend', self._events.preloadVisible );
				}
			}

			return self._mapInstance.markerClusterer;
		},

		/**
		 * Get the icon and the label of a cluster marker, the same icon as for OpenStreetMap, @see maps.js
		 * Note: the number is a label, because SVG images don't get fonts of the page
		 *
		 * @param {Number} count The quantity of markers in the cluster
		 * @return {{icon: {}, label: {}}}
		 */
		_getClusterIcon: function( count ) {
			var self = this,
				size = self._getClusterSize( count ),
				style = self._getClusterStyle();
			return {
				icon: {
					url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent( self._getClusterSvg( size ) ),
					scaledSize: new google.maps.Size( size, size ),
					anchor: new google.maps.Point( size / 2, size / 2 ),
				},
				label: {
					text: '' + count,
					color: style.textColor,
					fontFamily: style.fontFamily,
					fontSize: '13px',
					fontWeight: '600',
				},
			};
		},

		/**
		 * Redraw icons of clusters with the current colors, @see maps.js
		 */
		_refreshClusters: function() {
			var self = this,
				clusterer = ( self._mapInstance || {} ).markerClusterer;
			if ( ! clusterer ) {
				return;
			}
			$.each( clusterer.clusters, function( _, cluster ) {
				// A cluster of a single marker shows the marker itself instead of the cluster icon
				if ( cluster.marker && cluster.markers.length > 1 ) {
					cluster.marker.setOptions( self._getClusterIcon( cluster.count ) );
				}
			} );
		},

		/**
		 * Remove all markers from the map
		 */
		clearMarkers: function() {
			var self = this;
			// The shared popup is anchored to a removed marker, closing it resets the active marker, @see _getInfoWindow()
			self._closeInfoWindow();
			if ( self._mapInstance ) {
				self._mapInstance.removeMarkers();
			}
			self._activeMarker = _null;
			self._highlightedMarker = _null;
			self._markersByPost = new Map();
		},

		/**
		 * Fit the map to all markers, the "Zoom" option is used as the maximum zoom
		 */
		_fitMarkers: function() {
			var self = this,
				map = self._mapInstance.map,
				markers = self._mapInstance.markers,
				maxZoom = $ush.parseInt( self.options.zoom ) || 14;

			self._toggleNoResults( ! markers.length );

			// Show the whole world when there are no markers or the map is hidden
			if ( self._waitForVisibility() || ! markers.length ) {
				map.setCenter( { lat: 20, lng: 0 } );
				map.setZoom( 2 );
				return;
			}

			var bounds = new google.maps.LatLngBounds(),
				padding = 40;
			$.each( markers, function( _, marker ) {
				bounds.extend( marker.getPosition() );
			} );

			// Close markers or a single one would be fitted with the street level zoom, so limit it
			if ( self._getBoundsZoom( bounds, padding ) > maxZoom ) {
				map.setCenter( bounds.getCenter() );
				map.setZoom( maxZoom );
			} else {
				map.fitBounds( bounds, padding );
			}
		},

		/**
		 * Get the zoom that fits the bounds into the map, based on the Web Mercator projection
		 *
		 * @param {google.maps.LatLngBounds} bounds The bounds
		 * @param {Number} padding The padding inside the map in pixels
		 * @return {Number} Returns the zoom, it's Infinity for bounds of a single point
		 */
		_getBoundsZoom: function( bounds, padding ) {
			var self = this,
				northEast = bounds.getNorthEast(),
				southWest = bounds.getSouthWest(),
				tileSize = 256;

			var latRad = function( lat ) {
				var sin = Math.sin( lat * Math.PI / 180 ),
					radX2 = Math.log( ( 1 + sin ) / ( 1 - sin ) ) / 2;
				return Math.max( Math.min( radX2, Math.PI ), - Math.PI ) / 2;
			};
			var getZoom = function( mapSize, fraction ) {
				return Math.floor( Math.log( Math.max( mapSize, 1 ) / tileSize / fraction ) / Math.LN2 );
			};

			var lngDiff = northEast.lng() - southWest.lng(),
				lngFraction = ( lngDiff < 0 ? lngDiff + 360 : lngDiff ) / 360,
				latFraction = ( latRad( northEast.lat() ) - latRad( southWest.lat() ) ) / Math.PI;

			return Math.min(
				getZoom( self.$container.height() - padding * 2, latFraction ),
				getZoom( self.$container.width() - padding * 2, lngFraction )
			);
		},

		/**
		 * Map redraw
		 * Note: Fixing hidden and other breaking-cases maps
		 *
		 * @event handler
		 */
		_redraw: function() {
			var self = this;
			if ( self.$container.is( ':hidden' ) ) {
				return;
			}
			self.$container.css( { height: '', width: '' } );
			self._mapInstance.refresh();
			if ( self.options.fitMarkers ) {
				// Fit markers only when it was skipped for the hidden map, to keep the view set by a visitor
				if ( self._needsFit ) {
					self._fitMarkers();
				}
				return;
			}
			var latitude = $ush.parseFloat( self.options.latitude ),
				longitude = $ush.parseFloat( self.options.longitude );
			if ( latitude && longitude ) {
				self._mapInstance.setCenter( latitude, longitude );
			}
		},

		/**
		 * Initializes the Maps API load, which calls `self._init()`
		 */
		_initAftetGmapLoaded: function() {
			var $script = $( 'script#us-google-maps:first' );
			if ( ! $script.is( '[data-src]' ) ) { // Check if there is a data-src to the script
				return;
			}
			$script
				// The URL is escaped by WordPress, so all its params are separated by "&#038;"
				.attr( 'src', ( '' + $script.data( 'src' ) ).replace( /&#038;/g, '&' ) )
				.removeAttr( 'data-src' );
		}
	} );

	/**
	 * Wrapper for jQuery
	 *
	 * @param {{}} options The map options
	 * @return self
	 */
	$.fn.wGmaps = function( options ) {
		options = options || {};
		return this.each( function() {
			// Repeated calls must keep the instance, the constructor returns a blank object for the inited map
			if ( ! this._wGmaps ) {
				this._wGmaps = new $us.wGmaps( this, $ush.clone( options ) );
			}
		} );
	};

	// Initializing an element after loading a document
	$( function() {
		$( '.w-map.provider_google' ).wGmaps();
	} );

}( jQuery );
