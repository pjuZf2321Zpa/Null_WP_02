var _document = document,
	_navigator = navigator,
	_undefined = undefined,
	_window = window;

/*
 * imagesLoaded PACKAGED v5.0.0
 * JavaScript is all like "You images are done yet or what?"
 * MIT License
 */
!function(t,e){"object"==typeof module&&module.exports?module.exports=e():t.EvEmitter=e()}("undefined"!=typeof window?window:this,(function(){function t(){}let e=t.prototype;return e.on=function(t,e){if(!t||!e)return this;let i=this._events=this._events||{},s=i[t]=i[t]||[];return s.includes(e)||s.push(e),this},e.once=function(t,e){if(!t||!e)return this;this.on(t,e);let i=this._onceEvents=this._onceEvents||{};return(i[t]=i[t]||{})[e]=!0,this},e.off=function(t,e){let i=this._events&&this._events[t];if(!i||!i.length)return this;let s=i.indexOf(e);return-1!=s&&i.splice(s,1),this},e.emitEvent=function(t,e){let i=this._events&&this._events[t];if(!i||!i.length)return this;i=i.slice(0),e=e||[];let s=this._onceEvents&&this._onceEvents[t];for(let n of i){s&&s[n]&&(this.off(t,n),delete s[n]),n.apply(this,e)}return this},e.allOff=function(){return delete this._events,delete this._onceEvents,this},t})),
/*
 * imagesLoaded v5.0.0
 * JavaScript is all like "You images are done yet or what?"
 * MIT License
 */
function(t,e){"object"==typeof module&&module.exports?module.exports=e(t,require("ev-emitter")):t.imagesLoaded=e(t,t.EvEmitter)}("undefined"!=typeof window?window:this,(function(t,e){let i=t.jQuery,s=t.console;function n(t,e,o){if(!(this instanceof n))return new n(t,e,o);let r=t;var h;("string"==typeof t&&(r=document.querySelectorAll(t)),r)?(this.elements=(h=r,Array.isArray(h)?h:"object"==typeof h&&"number"==typeof h.length?[...h]:[h]),this.options={},"function"==typeof e?o=e:Object.assign(this.options,e),o&&this.on("always",o),this.getImages(),i&&(this.jqDeferred=new i.Deferred),setTimeout(this.check.bind(this))):s.error(`Bad element for imagesLoaded ${r||t}`)}n.prototype=Object.create(e.prototype),n.prototype.getImages=function(){this.images=[],this.elements.forEach(this.addElementImages,this)};const o=[1,9,11];n.prototype.addElementImages=function(t){"IMG"===t.nodeName&&this.addImage(t),!0===this.options.background&&this.addElementBackgroundImages(t);let{nodeType:e}=t;if(!e||!o.includes(e))return;let i=t.querySelectorAll("img");for(let t of i)this.addImage(t);if("string"==typeof this.options.background){let e=t.querySelectorAll(this.options.background);for(let t of e)this.addElementBackgroundImages(t)}};const r=/url\((['"])?(.*?)\1\)/gi;function h(t){this.img=t}function d(t,e){this.url=t,this.element=e,this.img=new Image}return n.prototype.addElementBackgroundImages=function(t){let e=getComputedStyle(t);if(!e)return;let i=r.exec(e.backgroundImage);for(;null!==i;){let s=i&&i[2];s&&this.addBackground(s,t),i=r.exec(e.backgroundImage)}},n.prototype.addImage=function(t){let e=new h(t);this.images.push(e)},n.prototype.addBackground=function(t,e){let i=new d(t,e);this.images.push(i)},n.prototype.check=function(){if(this.progressedCount=0,this.hasAnyBroken=!1,!this.images.length)return void this.complete();let t=(t,e,i)=>{setTimeout((()=>{this.progress(t,e,i)}))};this.images.forEach((function(e){e.once("progress",t),e.check()}))},n.prototype.progress=function(t,e,i){this.progressedCount++,this.hasAnyBroken=this.hasAnyBroken||!t.isLoaded,this.emitEvent("progress",[this,t,e]),this.jqDeferred&&this.jqDeferred.notify&&this.jqDeferred.notify(this,t),this.progressedCount===this.images.length&&this.complete(),this.options.debug&&s&&s.log(`progress: ${i}`,t,e)},n.prototype.complete=function(){let t=this.hasAnyBroken?"fail":"done";if(this.isComplete=!0,this.emitEvent(t,[this]),this.emitEvent("always",[this]),this.jqDeferred){let t=this.hasAnyBroken?"reject":"resolve";this.jqDeferred[t](this)}},h.prototype=Object.create(e.prototype),h.prototype.check=function(){this.getIsImageComplete()?this.confirm(0!==this.img.naturalWidth,"naturalWidth"):(this.proxyImage=new Image,this.img.crossOrigin&&(this.proxyImage.crossOrigin=this.img.crossOrigin),this.proxyImage.addEventListener("load",this),this.proxyImage.addEventListener("error",this),this.img.addEventListener("load",this),this.img.addEventListener("error",this),this.proxyImage.src=this.img.currentSrc||this.img.src)},h.prototype.getIsImageComplete=function(){return this.img.complete&&this.img.naturalWidth},h.prototype.confirm=function(t,e){this.isLoaded=t;let{parentNode:i}=this.img,s="PICTURE"===i.nodeName?i:this.img;this.emitEvent("progress",[this,s,e])},h.prototype.handleEvent=function(t){let e="on"+t.type;this[e]&&this[e](t)},h.prototype.onload=function(){this.confirm(!0,"onload"),this.unbindEvents()},h.prototype.onerror=function(){this.confirm(!1,"onerror"),this.unbindEvents()},h.prototype.unbindEvents=function(){this.proxyImage.removeEventListener("load",this),this.proxyImage.removeEventListener("error",this),this.img.removeEventListener("load",this),this.img.removeEventListener("error",this)},d.prototype=Object.create(h.prototype),d.prototype.check=function(){this.img.addEventListener("load",this),this.img.addEventListener("error",this),this.img.src=this.url,this.getIsImageComplete()&&(this.confirm(0!==this.img.naturalWidth,"naturalWidth"),this.unbindEvents())},d.prototype.unbindEvents=function(){this.img.removeEventListener("load",this),this.img.removeEventListener("error",this)},d.prototype.confirm=function(t,e){this.isLoaded=t,this.emitEvent("progress",[this,this.element,e])},n.makeJQueryPlugin=function(e){(e=e||t.jQuery)&&(i=e,i.fn.imagesLoaded=function(t,e){return new n(this,t,e).jqDeferred.promise(i(this))})},n.makeJQueryPlugin(),n}));

/*
 * jQuery Easing v1.4.1 - http://gsgd.co.uk/sandbox/jquery/easing/
 * Open source under the BSD License.
 * Copyright © 2008 George McGinley Smith
 * All rights reserved.
 * https://raw.github.com/gdsmith/jquery-easing/master/LICENSE
*/
jQuery.easing.jswing=jQuery.easing.swing;var pow=Math.pow;jQuery.extend(jQuery.easing,{def:"easeOutExpo",easeInExpo:function(a){return 0===a?0:pow(2,10*a-10)},easeOutExpo:function(a){return 1===a?1:1-pow(2,-10*a)},easeInOutExpo:function(a){return 0===a?0:1===a?1:.5>a?pow(2,20*a-10)/2:(2-pow(2,-20*a+10))/2}});

// UpSolution Theme Core
_window.$us = _window.$us || {};

// UpSolution Helper Library
_window.$ush = _window.$ush || {};

/**
 * Determines if the device is iOS
 *
 * @return {Boolean} True if iOS device, False otherwise
 */
$us.iOS = (
	/^iPad|iPhone|iPod/.test( _navigator.platform )
	// iPad on iOS 13 detection
	|| (
		_navigator.userAgent.indexOf( 'Mac' ) > -1
		&& _navigator.maxTouchPoints > 1
		&& $ush.isTouchend
	)
);

// Note: The variable is needed for the page-scroll.js file which changes only in menu.js
$us.mobileNavOpened = 0;

// The parameters that are in the code but not applied in the absence of a header
// When connecting header, correct parameters will be loaded
$us.header = {};
[
	'getCurrentHeight',
	'getHeaderInitialPos',
	'getHeight',
	'getScrollDirection',
	'getScrollTop',
	'isFixed',
	'isHidden',
	'isHorizontal',
	'isStatic',
	'isSticky',
	'isStickyAutoHidden',
	'stickyAutoHideEnabled',
	'stickyEnabled',
	'isTransparent',
	'isVertical',
	'on'
].map( ( name ) => {
	$us.header[ name ] = jQuery.noop;
} );

/**
 * Retrieve/set/erase dom modificator class <mod>_<value> for UpSolution CSS Framework
 * @param {String} mod Modificator namespace
 * @param {String} [value] Value
 * @returns {String|self}
 */
jQuery.fn.usMod = function( mod, value ) {
	const self = this;
	if ( self.length == 0 ) return self;
	// Retrieve modificator (The modifier will only be obtained from the first node)
	if ( value === _undefined ) {
		const pcre = new RegExp( '^.*?' + mod + '_([\dA-Za-z_-]+).*?$' );
		return ( pcre.exec( self.get( 0 ).className ) || [] )[ 1 ] || false;
	}
	// Set/Remove class modificator
	self.each( ( _, item ) => {
		// Remove class modificator
		item.className = item.className.replace( new RegExp( '(^| )' + mod + '_[\dA-Za-z_-]+( |$)' ), '$2' );
		if ( value !== false ) {
			item.className += ' ' + mod + '_' + value;
		}
	} );
	return self;
};

/**
 * Determines whether animation is available or not
 * @param {String} animationName The ease animation name
 * @param {String} defaultAnimationName The default animation name
 * @return {String}
 */
$us.getAnimationName = function( animationName, defaultAnimationName ) {
	if ( jQuery.easing.hasOwnProperty( animationName ) ) {
		return animationName;
	}
	return defaultAnimationName
		? defaultAnimationName
		: jQuery.easing._default;
};

// Prototype mixin for all classes working with events
// TODO: Replace with $ush.mixinEvents
$us.mixins = {};
$us.mixins.Events = {
	/**
	 * Attach a handler to an event for the class instance
	 * @param {String} eventType A string containing event type, such as 'beforeShow' or 'change'
	 * @param {Function} handler A function to execute each time the event is triggered
	 */
	on: function( eventType, handler ) {
		const self = this;
		if ( self.$$events === _undefined ) {
			self.$$events = {};
		}
		if ( self.$$events[ eventType ] === _undefined ) {
			self.$$events[ eventType ] = [];
		}
		self.$$events[ eventType ].push( handler );
		return self;
	},
	/**
	 * Remove a previously-attached event handler from the class instance
	 * @param {String} eventType A string containing event type, such as 'beforeShow' or 'change'
	 * @param {Function} [handler] The function that is to be no longer executed.
	 * @chainable
	 */
	off: function( eventType, handler ) {
		const self = this;
		if ( self.$$events === _undefined || self.$$events[ eventType ] === _undefined ) {
			return self;
		}
		if ( handler !== _undefined ) {
			var handlerPos = jQuery.inArray( handler, self.$$events[ eventType ] );
			if ( handlerPos != - 1 ) {
				self.$$events[ eventType ].splice( handlerPos, 1 );
			}
		} else {
			self.$$events[ eventType ] = [];
		}
		return self;
	},
	/**
	 * Execute all handlers and behaviours attached to the class instance for the given event type
	 * @param {String} eventType A string containing event type, such as 'beforeShow' or 'change'
	 * @param {Array} extraParameters Additional parameters to pass along to the event handler
	 * @chainable
	 */
	trigger: function( eventType, extraParameters ) {
		const self = this;
		if ( self.$$events === _undefined || self.$$events[ eventType ] === _undefined || self.$$events[ eventType ].length == 0 ) {
			return self;
		}
		var args = arguments,
			params = ( args.length > 2 || ! Array.isArray( extraParameters ) )
				? Array.prototype.slice.call( args, 1 )
				: extraParameters;
		// First argument is the current class instance
		params.unshift( self );
		for ( var index = 0; index < self.$$events[ eventType ].length; index ++ ) {
			self.$$events[ eventType ][ index ].apply( self.$$events[ eventType ][ index ], params );
		}
		return self;
	}
};

/**
 * Determines if mobile
 * Note: Fixing hovers for devices with both mouse and touch screen
 *
 * @return {Boolean} True if mobile, False otherwise
 */
jQuery.isMobile = (
	/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test( _navigator.userAgent )
	|| ( _navigator.platform == 'MacIntel' && _navigator.maxTouchPoints > 1 )
);

/**
 * Commonly used jQuery objects
 */
! function( $ ) {
	$us.$window = $( _window );
	$us.$document = $( _document );
	$us.$html = $( 'html' );
	$us.$body = $( '.l-body:first' );
	$us.$htmlBody = $us.$html.add( $us.$body );
	$us.$canvas = $( '.l-canvas:first' );

	/**
	 * Determines if effects are disabled, e.g. on narrow screens.
	 *
	 * @return {Boolean} True if effects are disabled, False otherwise.
	 */
	$us.areEffectsDisabled = () => {
		return $us.canvasOptions.disableEffectsWidth >= _document.body.clientWidth;
	};

	/**
	 * Determines if context of Live Builder.
	 *
	 * @return {Boolean} True if context of Live Builder, False otherwise.
	 */
	$us.usbPreview = () => {
		return _document.body.className.includes( 'usb_preview' );
	};

	// Add class to define touch devices
	if ( $us.iOS ) {
		// For all iOS devices
		$us.$html.removeClass( 'no-touch' ).addClass( 'ios-touch' );

	} else if ( $.isMobile || $ush.isTouchend ) {
		// For all mobile or supported touch devices
		$us.$html.removeClass( 'no-touch' ).addClass( 'touch' );
	} else {
		// All other devices without touch support
	}

}( jQuery );

/**
 * Helper Global Methods
 */
! function( $ ) {
	/**
	 * Get the current state.
	 *
	 * @return {String} Returns the current state (default|laptops|tablets|mobiles).
	 */
	$us.getCurrentState = () => {
		return $ush.toString( $us.$body.usMod( 'state' ) );
	};

	/**
	 * Checks if given state is current state.
	 *
	 * @param {String|[]} state State to be compared with.
	 * @return {Boolean} True if the state matches, False otherwise.
	 */
	$us.currentStateIs = ( state ) => {
		if ( ! state ) {
			return false;
		}
		if ( ! Array.isArray( state ) ) {
			state = [ $ush.toString( state ) ];
		}
		return state.includes( $us.getCurrentState() );
	};

	/**
	 * Get the admin bar height.
	 *
	 * @return {Number} Returns the height of the admin bar if it exists.
	 */
	$us.getAdminBarHeight = () => {
		return ( _document.getElementById('wpadminbar') || {} ).offsetHeight || 0;
	};
} ( jQuery );

/**
 * $us.canvas
 *
 * All the needed data and functions to work with overall canvas.
 *
 * TODO: Check all data that is linked from `$us.header` and use the functionality
 * of object `$us.header` and clear the current object.
 */
! function( $ ) {
	"use strict";

	function USCanvas( options ) {
		const self = this;

		// Setting options
		const defaults = {
			disableEffectsWidth: 900,
			backToTopDisplay: 100
		};

		self.options = $.extend( {}, defaults, options || {} );

		self.setGlobalState();

		// Commonly used dom elements
		self.$header = $( '.l-header', $us.$canvas );
		self.$main = $( '.l-main', $us.$canvas );
		// Content sections
		self.$sections = $( '> *:not(.l-header) .l-section', $us.$canvas );
		self.$firstSection = self.$sections.first();
		self.$secondSection = self.$sections.eq( 1 );
		self.$stickySections = self.$sections.filter( '.type_sticky:visible' );
		self.$fullscreenSections = self.$sections.filter( '.full_height' );
		self.$topLink = $( '.w-toplink' );

		// Canvas modificators
		self.type = $us.$canvas.usMod( 'type' );
		// Initial header position
		self._headerPos = self.$header.usMod( 'pos' );
		// Current header position
		self.headerPos = self._headerPos;
		self.headerBg = self.$header.usMod( 'bg' );
		self.rtl = $us.$body.hasClass( 'rtl' );

		// Used to prevent resize events on scroll for Android browsers
		self.isScrolling = false;
		self.isAndroid = /Android/i.test( _navigator.userAgent );

		// Bindable events
		self._events = {
			scroll: self.scroll.bind( self ),
			resize: self.resize.bind( self ),
			toggleClassIsSticky: self.toggleClassIsSticky.bind( self ),
		}

		// If in iframe...
		if ( $us.$body.hasClass( 'us_iframe' ) ) {
			// change links so they lead to main window
			$( 'a:not([target])' ).each( ( _, node ) => $( node ).attr( 'target', '_parent' ) );

			$( () => $( '.l-popup-box', _window.parent.document ).removeClass( 'loading' ) );
		}

		// Class assignments for adjusting header position via css.
		if ( self.hasStickyFirstSection() ) {
			$us.$body.addClass( 'sticky_first_section' );
		}

		// Events
		$us.$window
			.on( 'scroll.noPreventDefault', self._events.scroll )
			.on( 'resize load', self._events.resize )
			.on( 'scroll.noPreventDefault resize load', self._events.toggleClassIsSticky );

		// Complex logics requires two initial renders: before inner elements render and after
		$ush.timeout( self._events.resize, 25 );
		$ush.timeout( self._events.resize, 75 );
	}

	USCanvas.prototype = {

		/**
		 * Set the global state.
		 *
		 * Note: the initial state is set before the page is rendered by the same logic,
		 * keep it in sync with us_output_responsive_state_script() in us-core
		 */
		setGlobalState: function() {
			const self = this;

			// Window sizes
			self.winHeight = $ush.parseInt( $us.$window.height() );
			self.winWidth = $ush.parseInt( $us.$window.width() );

			// Disabling animation on mobile devices
			$us.$body.toggleClass( 'disable_effects', ( self.winWidth < self.options.disableEffectsWidth ) );

			var state;
			if ( self.winWidth > self.options.laptopsBreakpoint ) {
				state = 'default';
			} else if ( self.winWidth > self.options.tabletsBreakpoint ) {
				state = 'laptops';
			} else if ( self.winWidth > self.options.mobilesBreakpoint ) {
				state = 'tablets';
			} else {
				state = 'mobiles';
			}

			$us.$body.usMod( 'state', state );
		},

		/**
		 * Get the offset top.
		 *
		 * @return {Number} The offset top.
		 */
		getOffsetTop: function() {
			var top = Math.ceil( $us.$canvas.offset().top );
			if ( $us.currentStateIs( 'mobiles' ) ) {
				top -= $us.getAdminBarHeight();
			}
			return top;
		},

		/**
		 * Determines if sticky section.
		 *
		 * @return {Boolean} True if sticky section, False otherwise.
		 */
		isStickySection: function() {
			return this.$stickySections.length > 0;
		},

		/**
		 * Determines if there is a sticky active section
		 *
		 * @return {Boolean} True if sticky section, False otherwise.
		 */
		hasStickySection: function () {
			const self = this;
			if ( self.isStickySection() ) {
				return self.$stickySections.hasClass( 'is_sticky' );
			}
			return false
		},

		/**
		 * Determines if position sticky sections.
		 *
		 * @return {Boolean} True if position sticky sections, False otherwise.
		 */
		hasPositionStickySections: function() {
			const self = this;
			if ( self.isStickySection() ) {
				return self.$stickySections
					.filter( ( _, node ) => { return $( node ).css( 'position' ) == 'sticky' } )
					.length > 0;
			}
			return false;
		},

		/**
		 * Get the height first sticky section.
		 *
		 * @return {Number} The height first sticky section.
		 */
		getStickySectionHeight: function() {
			const self = this;
			var stickySectionHeight = 0;
			if ( self.isStickySection() ) {
				var header = $us.header,
					$stickySection = self.$stickySections.first();
				stickySectionHeight = $stickySection.outerHeight( true );
				// If the first section on page is sticky, it has header height added to its padding
				// Subtracting the header height from function return value in this case
				if ( self.hasStickyFirstSection() && header.isHorizontal() && ! header.isStatic() ) {
					stickySectionHeight -= header.getCurrentHeight();
				}
			}
			return stickySectionHeight;
		},

		/**
		 * Determines if sticky first section.
		 *
		 * @return {boolean} True if first sticky section, False otherwise.
		 */
		hasStickyFirstSection: function() {
			const self = this;
			const $first = self.$stickySections.first();
			return self.isStickySection() && $first.index() === 0 && $first.hasClass( 'is_sticky' );
		},

		/**
		 * Checks that the specified section is after the sticky section.
		 *
		 * @param {*} node Start node
		 * @return {Boolean} True if after sticky section, False otherwise.
		 */
		isAfterStickySection: function( node ) {
			var $node = $( node );
			if ( $node.length == 0 ) {
				return false;
			}
			if ( ! $node.hasClass( 'l-section' ) ) {
				$node = $node.closest( '.l-section' );
			}
			return $node.index() > this.$stickySections.index();
		},

		/**
		 * Gets the height first section.
		 *
		 * @return {number} The height first section.
		 */
		getHeightFirstSection: function() {
			return this.$firstSection.length > 0
				? parseFloat( this.$firstSection.outerHeight( true ) )
				: 0;
		},

		/**
		 * Scroll-driven logics
		 *
		 * @event handler
		 */
		scroll: function() {
			const self = this;
			const scrollTop = parseInt( $us.$window.scrollTop() );

			// Show/hide go to top link
			self.$topLink
				.toggleClass( 'visible', ( scrollTop >= self.winHeight * self.options.backToTopDisplay / 100 ) );

			if ( self.isAndroid ) {
				if ( self.pid ) {
					$ush.clearTimeout( self.pid );
				}
				self.isScrolling = true;
				self.pid = $ush.timeout( () => {
					self.isScrolling = false;
				}, 100 );
			}
		},

		/**
		 * Resize-driven logics
		 *
		 * @event handler
		 */
		resize: function() {
			const self = this;

			self.setGlobalState();

			// If the page is loaded in iframe
			if ( $us.$body.hasClass( 'us_iframe' ) ) {
				var $frameContent = $( '.l-popup-box-content', _window.parent.document ),
					outerHeight = $us.$body.outerHeight( true );
				if ( outerHeight > 0 && $( _window.parent ).height() > outerHeight ) {
					$frameContent.css( 'height', outerHeight );
				} else {
					$frameContent.css( 'height', '' );
				}
			}

			// Fix scroll glitches that could occur after the resize
			self.scroll();
		},

		/**
		 * Determining whether a section is fixed sticky or not
		 *
		 * @event handler
		 */
		toggleClassIsSticky: function() {
			const self = this;
			if ( ! self.isStickySection() ) {
				return;
			}
			self.$stickySections.each( ( _, section ) => {
				const $section = $( section );
				const offsetTop = section.getBoundingClientRect().top - parseInt( $section.css( 'top' ) );
				$section.toggleClass( 'is_sticky', ( parseInt( offsetTop ) === 0 && $section.css( 'position' ) == 'sticky' ) );
			} );
		}
	};

	$us.canvas = new USCanvas( $us.canvasOptions || {} );

}( jQuery );

/**
 * CSS-analog of jQuery slideDown/slideUp/fadeIn/fadeOut functions (for better rendering)
 */
! function( $ ) {

	/**
	 * Remove the passed inline CSS attributes.
	 *
	 * Usage: `$node.resetInlineCSS( 'height', 'width' )` or `$node.resetInlineCSS( [ 'height', 'width' ] )`
	 */
	$.fn.resetInlineCSS = function() {
		const self = this;
		var args = [].slice.call( arguments );
		if ( args.length > 0 && Array.isArray( args[0] ) ) {
			args = args[0];
		}
		for ( var index = 0; index < args.length; index++ ) {
			self.css( args[ index ], '' );
		}
		return self;
	};

	$.fn.clearPreviousTransitions = function() {
		const self = this;
		// Stopping previous events, if there were any
		const prevTimers = ( self.data( 'animation-timers' ) || '' ).split( ',' );
		if ( prevTimers.length >= 2 ) {
			self.resetInlineCSS( 'transition' );
			prevTimers.map( clearTimeout );
			self.removeData( 'animation-timers' );
		}
		return self;
	};

	/**
	 *
	 * @param {Object} css key-value pairs of animated css
	 * @param {Number} duration in milliseconds
	 * @param {Function} onFinish
	 * @param {String} easing CSS easing name
	 * @param {Number} delay in milliseconds
	 */
	$.fn.performCSSTransition = function( css, duration, onFinish, easing, delay ) {
		const self = this;

		var transition = [];

		duration = duration || 250;
		delay = delay || 25;
		easing = easing || 'ease';

		self.clearPreviousTransitions();

		for ( const attr in css ) {
			if ( ! css.hasOwnProperty( attr ) ) {
				continue;
			}
			transition.push( attr + ' ' + ( duration / 1000 ) + 's ' + easing );
		}
		transition = transition.join( ', ' );
		self.css( {
			transition: transition
		} );

		// Starting the transition with a slight delay for the proper application of CSS transition properties
		const timer1 = setTimeout( () => self.css( css ), delay );
		const timer2 = setTimeout( () => {
			self.resetInlineCSS( 'transition' );
			if ( typeof onFinish === 'function' ) {
				onFinish();
			}
		}, duration + delay );

		self.data( 'animation-timers', timer1 + ',' + timer2 );
	};

	// Height animations
	$.fn.slideDownCSS = function( duration, onFinish, easing, delay ) {
		const self = this;
		if ( self.length == 0 ) {
			return;
		}
		self.clearPreviousTransitions();
		// Grabbing paddings
		self.resetInlineCSS( 'padding-top', 'padding-bottom' );
		const timer1 = setTimeout( () => {
			const paddingTop = parseInt( self.css( 'padding-top' ) );
			const paddingBottom = parseInt( self.css( 'padding-bottom' ) );
			// Grabbing the "auto" height in px
			self.css( {
				visibility: 'hidden',
				position: 'absolute',
				height: 'auto',
				'padding-top': 0,
				'padding-bottom': 0,
				display: 'block'
			} );
			var height = self.height();
			self.css( {
				overflow: 'hidden',
				height: '0px',
				opacity: 0,
				visibility: '',
				position: ''
			} );
			self.performCSSTransition( {
				opacity: 1,
				height: height + paddingTop + paddingBottom,
				'padding-top': paddingTop,
				'padding-bottom': paddingBottom
			}, duration, () => {
				self.resetInlineCSS( 'overflow' ).css( 'height', 'auto' );
				if ( typeof onFinish == 'function' ) {
					onFinish();
				}
			}, easing, delay );
		}, 25 );
		self.data( 'animation-timers', timer1 + ',null' );
	};

	$.fn.slideUpCSS = function( duration, onFinish, easing, delay ) {
		const self = this;
		if ( self.length == 0 ) {
			return;
		}
		self.clearPreviousTransitions();
		self.css( {
			height: self.outerHeight(),
			overflow: 'hidden',
			'padding-top': self.css( 'padding-top' ),
			'padding-bottom': self.css( 'padding-bottom' )
		} );
		self.performCSSTransition( {
			height: 0,
			opacity: 0,
			'padding-top': 0,
			'padding-bottom': 0
		}, duration, () => {
			self.resetInlineCSS( 'overflow', 'padding-top', 'padding-bottom' ).css(
				{
					display: 'none'
				}
			);
			if ( typeof onFinish == 'function' ) {
				onFinish();
			}
		}, easing, delay );
	};

	// Opacity animations
	$.fn.fadeInCSS = function( duration, onFinish, easing, delay ) {
		const self = this;
		if ( self.length == 0 ) {
			return;
		}
		self.clearPreviousTransitions();
		self.css( { opacity: 0, display: 'block' } );
		self.performCSSTransition( { opacity: 1 }, duration, onFinish, easing, delay );
	};

	$.fn.fadeOutCSS = function( duration, onFinish, easing, delay ) {
		const self = this;
		if ( self.length == 0 ) {
			return;
		}
		self.performCSSTransition( {
			opacity: 0
		}, duration, () => {
			self.css( 'display', 'none' );
			if ( typeof onFinish === 'function' ) {
				onFinish();
			}
		}, easing, delay );
	};

}( jQuery );

jQuery( function( $ ) {
	"use strict";

	/**
	 * Background videos of rows blocked until the consent: the player is kept as a template, see vc_row.php
	 *
	 * @param {jQuery} $videos The ".l-section-video" containers to insert the players into
	 */
	function loadRowVideos( $videos ) {
		$videos.each( ( _, node ) => {
			const $video = $( node );
			$video
				.html( $ush.base64Decode( '' + $( 'script[type="text/template"]', $video ).text() ) )
				.removeClass( 'confirm_load' );
		} );
	}
	loadRowVideos( $( '.l-section-video.confirm_load' ).filter( ( _, node ) => $ush.isLoadConfirmed( node ) ) );

	/**
	 * Run the scripts kept as "text/plain" until the consent: the known tracking code of the Custom Code fields
	 * and any site script marked with the data-us-consent attribute, see us_block_trackers()
	 *
	 * Note: the scripts run in the order of the page, an external script without "async" or "defer" holds the next
	 * ones until it's loaded, as it does in the page source
	 */
	function runConsentScripts() {
		const nodes = $( 'script[type="text/plain"][data-us-consent]' ).toArray();
		const runNext = () => {
			const node = nodes.shift();
			if ( ! node ) {
				$us.$document.trigger( 'usConsentAccepted' );
				return;
			}
			const script = _document.createElement( 'script' );
			$.each( node.attributes, ( _, attr ) => {
				// The original type of a module, see us_block_trackers()
				if ( attr.name === 'data-us-type' ) {
					script.type = attr.value;

				} else if ( attr.name !== 'type' && attr.name !== 'data-us-consent' ) {
					script.setAttribute( attr.name, attr.value );
				}
			} );
			script.text = node.text;
			const holdsNext = (
				node.hasAttribute( 'src' )
				&& ! node.hasAttribute( 'async' )
				&& ! node.hasAttribute( 'defer' )
				&& script.type !== 'module'
			);
			if ( holdsNext ) {
				script.onload = script.onerror = runNext;
			}
			node.replaceWith( script );
			if ( ! holdsNext ) {
				runNext();
			}
		};
		runNext();
	}

	/**
	 * Cookie Notice: the informing notice with one button stores "true", the notice with Accept and Reject stores
	 * "accepted" or "rejected", so the "true" is never taken as the consent, see $ush.isLoadConfirmed()
	 * Note: the notice is output to every visitor, as page caches serve the same HTML, see cookie-notice.php
	 */
	const cookieNoticeValue = $ush.getCookie( 'us_cookie_notice_accepted' );
	const $cookieNotice = $( '.l-cookie' );
	const isConsentNotice = $cookieNotice.hasClass( 'for_consent' );

	if ( cookieNoticeValue === 'accepted' ) {
		runConsentScripts();
	}

	if ( isConsentNotice ? [ 'accepted', 'rejected' ].includes( cookieNoticeValue ) : cookieNoticeValue !== null ) {
		$cookieNotice.remove();

	} else {
		$us.$document.on( 'click', '#us-set-cookie, #us-reject-cookie', ( e ) => {
			e.preventDefault();
			e.stopPropagation();
			const isRejected = ( e.currentTarget.id === 'us-reject-cookie' );
			let value = 'true';
			if ( isConsentNotice ) {
				value = isRejected ? 'rejected' : 'accepted';
			}
			$ush.setCookie( 'us_cookie_notice_accepted', value, /* days */isRejected ? 180 : 365 );
			$cookieNotice.remove();

			// Load the content and run the tracking code blocked until the acceptance, the elements loaded
			// by their own click already have no button, see video.js, gmaps.js and lmaps.js
			if ( value === 'accepted' ) {
				$( '.confirm_by_notice .action_confirm_load' ).closest( '.confirm_by_notice' ).trigger( 'usLoadConfirmed' );
				loadRowVideos( $( '.l-section-video.confirm_load.confirm_by_notice' ) );
				runConsentScripts();
			}
		} );
	}

	/**
	 * Color Scheme Switch
	 *
	 * If Dark Theme is enabled and user OS in dark mode turn on switch
	 */
	if (
		$us.darkThemeIsOn
		&& window.matchMedia( '(prefers-color-scheme: dark)' ).matches
		&& ! $ush.getCookie( 'us_color_scheme_switch_is_on' )
	) {
		// The visitor who rejected cookies in the Cookie Notice gets the switch on every page instead of the cookie
		if ( cookieNoticeValue !== 'rejected' ) {
			$ush.setCookie( 'us_color_scheme_switch_is_on', 'true', 30 );
		}

		$( '.w-color-switch input[name=us-color-scheme-switch]' ).prop( 'checked', true );

		$us.$html.addClass( 'us-color-scheme-on' );
	}

	$us.$document.on( 'change', '[name=us-color-scheme-switch]', () => {
		// The current state is taken from the class, as the visitor who rejected cookies has no cookie until this change
		if ( $us.$html.hasClass( 'us-color-scheme-on' ) ) {
			$us.$html.removeClass( 'us-color-scheme-on' );
			$us.$html.addClass( 'us-color-scheme-off' );
			$ush.setCookie( 'us_color_scheme_switch_is_on', 'false', 30 );
		} else {
			$us.$html.addClass( 'us-color-scheme-on' );
			$us.$html.removeClass( 'us-color-scheme-off' );
			$ush.setCookie( 'us_color_scheme_switch_is_on', 'true', 30 );
		}

		if ( $us.header.$container.length ) {
			$us.header.$container.addClass( 'notransition' );
			$ush.timeout( () => $us.header.$container.removeClass( 'notransition' ), 50 );
		}
	} );

	// Force popup opening on links with ref
	function usPopupLink( context, opts ) {
		const $links = $( 'a[ref=magnificPopup][class!=direct-link]:not(.inited)', context || _document );
		const defaultOptions = {
			fixedContentPos: true,
			mainClass: 'mfp-fade',
			removalDelay: 300,
			type: 'image'
		};
		if ( $links.length > 0 ) {
			$links
				.addClass( 'inited' )
				.magnificPopup( $.extend( {}, defaultOptions, opts || {} ) );
		}
	};
	$.fn.usPopupLink = function( opts ) {
		return this.each( function() {
			$( this ).data( 'usPopupLink', new usPopupLink( this, opts ) );
		} );
	};

	$( () => $us.$document.usPopupLink() );

	/**
	 * Accessibility of Magnific Popup.
	 * Note: default callbacks are used, since Magnific Popup sends its events to the element it was
	 * initialized on and not to the document, so there is nothing to listen to globally.
	 */
	if ( $.magnificPopup ) {
		$.magnificPopup.defaults.callbacks = $.extend( {}, $.magnificPopup.defaults.callbacks, {

			/**
			 * The popup image is created by the script, which inherits the Alt only from an <img> placed
			 * inside the clicked link, so apply the Alt of the links laid over images.
			 */
			afterChange: function() {
				const item = this.currItem;
				if ( item && item.img && item.el && item.el.is( '[data-alt]' ) ) {
					item.img.attr( 'alt', item.el.attr( 'data-alt' ) );
				}
			},

			/**
			 * Turn the popup into a modal dialog, as it doesn't isolate the page content by itself.
			 */
			open: function() {
				const self = this;

				self.wrap.attr( {
					'role': 'dialog',
					'aria-modal': 'true',
					'aria-label': $us.langOptions.magnificPopup.tDialog
				} );

				// Hide the rest of the page from screen readers while the dialog is open
				$us.$body.children().each( ( _, node ) => {
					const $node = $( node );
					if (
						$node.is( self.wrap )
						|| $node.is( self.bgOverlay )
						|| $node.is( 'script, style, link' )
						|| $node.attr( 'aria-hidden' ) // don't touch the elements hidden by anything else
					) {
						return;
					}
					$node.attr( { 'aria-hidden': 'true', 'data-mfp-hidden': '' } );
				} );
			},

			afterClose: function() {
				$( '[data-mfp-hidden]' ).removeAttr( 'aria-hidden data-mfp-hidden' );
			}
		} );
	}

	// Footer Reveal handler
	( function() {
		const $footer = $( '.l-footer' );

		if ( $us.$body.hasClass( 'footer_reveal' ) && $footer.length > 0 && $footer.html().trim().length > 0 ) {
			function usFooterReveal() {
				var footerHeight = $footer.innerHeight();
				if ( _window.innerWidth > parseInt( $us.canvasOptions.columnsStackingWidth ) -1 ) {
					$us.$canvas.css( 'margin-bottom', Math.round( footerHeight ) -1 );
				} else {
					$us.$canvas.css( 'margin-bottom', '' );
				}
			};

			usFooterReveal();
			$us.$window.on( 'resize load', usFooterReveal );
		}
	} )();

	/* YouTube/Vimeo background */
	const $usYTVimeoVideoContainer = $( '.with_youtube, .with_vimeo' );
	if ( $usYTVimeoVideoContainer.length > 0 ) {
		$us.$window.on( 'resize load', () => {
			$usYTVimeoVideoContainer.each( function() {
				var $container = $( this ),
					$frame = $container.find( 'iframe' ).first(),
					cHeight = $container.innerHeight(),
					cWidth = $container.innerWidth(),
					fWidth = '',
					fHeight = '';

				if ( cWidth / cHeight < 16 / 9 ) {
					fWidth = cHeight * ( 16 / 9 );
					fHeight = cHeight;
				} else {
					fWidth = cWidth;
					fHeight = fWidth * ( 9 / 16 );
				}

				$frame.css( {
					'width': Math.round( fWidth ),
					'height': Math.round( fHeight ),
				} );
			} );
		} );
	}
} );

/**
 * $us.waypoints
 */
;( function( $ ) {
	"use strict";

	function USWaypoints() {
		const self = this;

		// Waypoints that will be called at certain scroll position
		self.waypoints = [];

		// Recount scroll waypoints on any content changes
		$us.$canvas
			.on( 'contentChange', self._countAll.bind( self ) );
		$us.$window
			.on( 'resize load', self._events.resize.bind( self ) )
			.on( 'scroll scroll.waypoints', self._events.scroll.bind( self ) );

		$ush.timeout( self._events.resize.bind( self ), 75 );
		$ush.timeout( self._events.scroll.bind( self ), 75 );
	}
	/**
	 * Export API
	 */
	USWaypoints.prototype = {
		// Handler's
		_events: {
			/**
			 * Scroll handler
			 */
			scroll: function() {
				const self = this;
				var scrollTop = parseInt( $us.$window.scrollTop() );

				// Safari negative scroller fix
				scrollTop = ( scrollTop >= 0 ) ? scrollTop : 0;

				// Handling waypoints
				for ( var i = 0; i < self.waypoints.length; i ++ ) {
					if ( self.waypoints[ i ].scrollPos < scrollTop ) {
						self.waypoints[ i ].fn( self.waypoints[ i ].$node );
						self.waypoints.splice( i, 1 );
						i --;
					}
				}
			},
			/**
			 * Resize handler
			 */
			resize: function() {
				const self = this;
				// Delaying the resize event to prevent glitches
				$ush.timeout( () => {
					self._countAll.call( self );
					self._events.scroll.call( self );
				}, 150 );
				self._countAll.call( self );
				self._events.scroll.call( self );
			}
		},
		/**
		 * Add new waypoint
		 *
		 * @param {jQuery} $node object with the element
		 * @param {*} offset Offset from bottom of screen in pixels ('100') or percents ('20%')
		 * @param {Function} fn The function that will be called
		 */
		add: function( $node, offset, fn ) {
			const self = this;
			$node = ( $node instanceof $ ) ? $node : $( $node );
			if ( $node.length == 0 ) {
				return;
			}
			if ( typeof offset != 'string' || offset.indexOf( '%' ) == - 1 ) {
				// Not percent: using pixels
				offset = parseInt( offset );
			}
			// Determining whether an element is already in the scope,
			// if it is visible, reset offset
			if ( $node.offset().top < ( $us.$window.height() + $us.$window.scrollTop() ) ) {
				offset = 0;
			}
			var waypoint = {
				$node: $node, offset: offset, fn: fn
			};
			self._count( waypoint );
			self.waypoints.push( waypoint );
		},
		/**
		 * Count target for proper scrolling
		 *
		 * @param {{}} waypoint
		 */
		_count: function( waypoint ) {
			const elmTop = waypoint.$node.offset().top, winHeight = $us.$window.height();
			if ( typeof waypoint.offset == 'number' ) {
				// Offset is defined in pixels
				waypoint.scrollPos = elmTop - winHeight + waypoint.offset;
			} else {
				// Offset is defined in percents
				waypoint.scrollPos = elmTop - winHeight + winHeight * parseInt( waypoint.offset ) / 100;
			}
		},
		/**
		 * Count all targets for proper scrolling
		 */
		_countAll: function() {
			const self = this;
			// Counting waypoints
			for ( var i = 0; i < self.waypoints.length; i ++ ) {
				self._count( self.waypoints[ i ] );
			}
		}
	};
	$us.waypoints = new USWaypoints;
})( jQuery );

;( function() {
	var lastTime = 0;
	const vendors = ['ms', 'moz', 'webkit', 'o'];
	for ( var x = 0; x < vendors.length && ! _window.requestAnimationFrame; ++ x ) {
		_window.requestAnimationFrame = _window[ vendors[ x ] + 'RequestAnimationFrame' ];
		_window.cancelAnimationFrame = _window[ vendors[ x ] + 'CancelAnimationFrame' ] || _window[ vendors[ x ] + 'CancelRequestAnimationFrame' ];
	}
	if ( ! _window.requestAnimationFrame ) {
		_window.requestAnimationFrame = ( callback, element ) => {
			const currTime = new Date().getTime();
			const timeToCall = Math.max( 0, 16 - ( currTime - lastTime ) );
			const id = _window.setTimeout( () => callback( currTime + timeToCall ), timeToCall );
			lastTime = currTime + timeToCall;
			return id;
		};
	}
	if ( ! _window.cancelAnimationFrame ) {
		_window.cancelAnimationFrame = ( id ) => clearTimeout( id );
	}
}() );

/*
 * Remove empty space before content for video post type with active preview
 */
! function( $ ) {
	if ( $us.$body.hasClass( 'single-format-video' ) ) {
		$( 'figure.wp-block-embed div.wp-block-embed__wrapper', $us.$body ).each( ( _, node ) => {
			if ( node.firstElementChild === null ) {
				node.remove();
			}
		} );
	}
}( jQuery );

/*
 * With "Show More" link, used in Text Block and Post Content elements
 */
! function( $ ) {
	"use strict";

	function usCollapsibleContent( container ) {
		const self = this;

		/**
		 * @var {{}} Bindable events.
		 */
		self._events = {
			showContent: self.showContent.bind( self ),
		};

		// Elements
		self.$container = $( container );
		self.$firstElement = $( '> *:first', self.$container );
		self.collapsedHeight = self.$container.data( 'content-height' ) || 200;

		// Events
		self.$container
			.on( 'click', '.collapsible-content-more, .collapsible-content-less', self._events.showContent );

		// Init if not in Owl Carousel context
		if ( self.$container.closest( '.owl-carousel' ).length == 0 ) {
			self.setHeight.call( self );
		}
	};

	// Collapsible Content API
	usCollapsibleContent.prototype = {

		setHeight: function() {
			const self = this;

			// Set the height to the element in any unit of measurement and get the height in pixels
			let collapsedHeight = self.$firstElement.css( 'height', self.collapsedHeight ).height();
			self.$firstElement.css( 'height', '' );
			let heightFirstElement = self.$firstElement.height();

			if ( heightFirstElement && heightFirstElement <= collapsedHeight ) {
				$( '.toggle-links', self.$container ).hide();
				self.$firstElement.css( 'height', '' );
				self.$container.removeClass( 'with_collapsible_content' );
			} else {
				$( '.toggle-links', self.$container ).show();
				self.$firstElement.css( 'height', self.collapsedHeight );
			}
		},

		/**
		 * Toggle show or hide content.
		 *
		 * @param {Event} e The Event interface represents an event which takes place in the DOM
		 */
		showContent: function( e ) {
			const self = this;

			e.preventDefault();
			e.stopPropagation();

			self.$container
				.toggleClass( 'show_content', $( e.target ).hasClass( 'collapsible-content-more' ) )
				.trigger( 'showContent' );
			$ush.timeout( () => {
				$us.$canvas.trigger( 'contentChange' );
				if ( $.isMobile && ! $ush.isNodeInViewport( self.$container[0] ) ) {
					$us.$htmlBody
						.stop( true, false )
						.scrollTop( self.$container.offset().top - $us.header.getCurrentHeight( /* adminBar */true ) );
				}
			}, 1 );
		}
	};

	$.fn.usCollapsibleContent = function() {
		return this.each( function() {
			$( this ).data( 'usCollapsibleContent', new usCollapsibleContent( this ) );
		} );
	};

	$( '[data-content-height]', $us.$canvas ).usCollapsibleContent();

	// Init in Grid Layout context
	$us.$document.on( 'usPostList.itemsLoaded usGrid.itemsLoaded', ( _, $items ) => {
		$( '[data-content-height]', $items ).usCollapsibleContent();
	} );

	/**
	 * Additional event validation for scanned Owl Carousel items
	 */
	if ( $( '.owl-carousel', $us.$canvas ).length > 0 ) {
		$us.$canvas.on( 'click', '.collapsible-content-more, .collapsible-content-less', ( e ) => {
			const $target = $( e.target );
			const $container = $target.closest( '[data-content-height]' );
			if ( ! $container.data( 'usCollapsibleContent' ) ) {
				$container.usCollapsibleContent();
				$target.trigger( 'click' );
			}
		} );
	}

}( jQuery );

/**
 * Will fire the original resize event so that the video element
 * recalculates the width and height of the player in usPopup
 */
! function( $ ) {
	$us.$document.on( 'usPopup.afterShow', ( _, usPopup ) => {
		if ( usPopup instanceof $us.usPopup && $( 'video.wp-video-shortcode', usPopup.$box ).length > 0 ) {
			const handle = $ush.timeout( () => {
				$ush.clearTimeout( handle );
				_window.dispatchEvent( new Event( 'resize' ) );
			}, 1 );
		}
	} );
}( jQuery );

/**
 * Scrollbar settings for all popups
 */
! function( $ ) {
	"use strict";

	$us.scrollbarWidth = function( force ) {
		const self = this;
		if ( $ush.isUndefined( self.width ) || force ) {
			const scrollDiv = _document.createElement( 'div' );
			scrollDiv.style.cssText = 'width: 99px; height: 99px; overflow: scroll; position: absolute; top: -9999px;';
			_document.body.appendChild( scrollDiv );
			self.width = scrollDiv.offsetWidth - scrollDiv.clientWidth;
			_document.body.removeChild( scrollDiv );
		}
		return self.width;
	};

	if ( $.magnificPopup ) {

		// Override MagnificPopup methods
		const origMfpOpen = $.magnificPopup.proto.open;
		const origMfpClose = $.magnificPopup.proto._close;

		$.magnificPopup.proto.open = function() {
			const result = origMfpOpen.apply( this, arguments );

			/**
			 * MagnificPopup locks the page with an inline "overflow: hidden" and compensates
			 * the scrollbar with an inline "margin-right". Only the latter is dropped here, as
			 * it causes a layout jump: the compensation is done via the "--scrollbar-width"
			 * variable instead. The overflow lock must stay, otherwise the page keeps
			 * scrolling behind the opened popup
			 */
			$us.$html.css( 'margin-right', '' );

			$us.$document.trigger( 'usMagnificPopupOpened', this );
			return result;
		};

		/**
		 * Note: the "_close" method is overridden and not the public "close" one, since the latter
		 * only starts the removal animation, while the inline styles of the <html> element are
		 * reset in "_close" after "removalDelay". Dropping the "us_popup_is_opened" class earlier
		 * would leave the page locked with "overflow: hidden" but without the scrollbar
		 * compensation, so the content would jump for the whole duration of the animation
		 */
		$.magnificPopup.proto._close = function() {
			const result = origMfpClose.apply( this, arguments );
			$us.$document.trigger( 'usMagnificPopupClosed', this );
			return result;
		};

		/**
		 * Sliding animation for switching between the gallery items, which also gives some
		 * feedback to the swipe gestures. The class is set on the wrapper, since the content
		 * itself is replaced by MagnificPopup on every switch.
		 *
		 * Note: the direction is the visual one, so in RTL it is mirrored the same way
		 * the gallery arrows are
		 *
		 * @param {Object} mfp The MagnificPopup instance
		 * @param {Boolean} fromRight Which side the new item comes in from
		 */
		function animateItemChange( mfp, fromRight ) {
			if ( ! mfp.wrap ) {
				return;
			}
			const wrap = mfp.wrap[ 0 ];
			wrap.classList.remove( 'us_mfp_from_left', 'us_mfp_from_right' );

			/**
			 * Reading a layout property in between forces a reflow, so that the animation is
			 * restarted even when the previous switch went in the same direction
			 */
			if ( wrap.offsetWidth ) {
				wrap.classList.add( fromRight ? 'us_mfp_from_right' : 'us_mfp_from_left' );
			}
		}

		const origMfpNext = $.magnificPopup.proto.next;
		const origMfpPrev = $.magnificPopup.proto.prev;

		$.magnificPopup.proto.next = function() {
			const result = origMfpNext.apply( this, arguments );
			animateItemChange( this, ! $ush.isRtl() );
			return result;
		};

		$.magnificPopup.proto.prev = function() {
			const result = origMfpPrev.apply( this, arguments );
			animateItemChange( this, $ush.isRtl() );
			return result;
		};

		/**
		 * Swipe gestures for MagnificPopup, which has no touch support of its own: a horizontal
		 * swipe navigates through the gallery items, a vertical one closes the popup.
		 * Bound once with delegation, so all the popup instances are covered.
		 *
		 * Note: the gesture is measured on "touchend" only, without a "touchmove" handler calling
		 * "e.preventDefault()". Touch listeners bound to the document are passive by default, so
		 * such a call would be ignored and would only fill the console with warnings. What it was
		 * meant for is done in CSS instead: the page behind is locked with "overflow: hidden",
		 * while "touch-action" on ".mfp-wrap" keeps the horizontal gestures, including the
		 * "swipe to go back" one, away from the browser
		 */
		const SWIPE_MIN_DISTANCE = 50; // px, shorter gestures are ignored
		const SWIPE_MAX_DURATION = 700; // ms, longer gestures are treated as scrolling
		const SWIPE_AXIS_RATIO = 1.5; // how much the dominant axis must exceed the other one

		let swipe;

		$us.$document
			.on( 'touchstart.usMfpSwipe', '.mfp-wrap', ( e ) => {
				const touches = e.originalEvent.touches;
				swipe = _undefined;

				// Skip multi-touch, so pinch zooming is never treated as a swipe
				if ( touches.length != 1 ) {
					return;
				}

				// Skip the arrows, they have their own handlers
				if ( $( e.target ).closest( '.mfp-arrow, .mfp-close' ).length ) {
					return;
				}

				swipe = {
					startX: touches[ 0 ].clientX,
					startY: touches[ 0 ].clientY,
					startTime: Date.now(),
				};
			} )
			.on( 'touchcancel.usMfpSwipe', '.mfp-wrap', () => {
				swipe = _undefined;
			} )
			.on( 'touchend.usMfpSwipe', '.mfp-wrap', ( e ) => {
				if ( ! swipe ) {
					return;
				}

				// The released point is in "changedTouches", since "touches" is already empty here
				const touch = e.originalEvent.changedTouches[ 0 ];
				const mfp = $.magnificPopup.instance;
				const deltaX = touch.clientX - swipe.startX;
				const deltaY = touch.clientY - swipe.startY;
				const isExpired = ( Date.now() - swipe.startTime ) > SWIPE_MAX_DURATION;

				swipe = _undefined;

				if ( isExpired || ! mfp || ! mfp.isOpen ) {
					return;
				}

				// Horizontal swipe: go to the next / previous gallery item
				if (
					Math.abs( deltaX ) >= SWIPE_MIN_DISTANCE
					&& Math.abs( deltaX ) > Math.abs( deltaY ) * SWIPE_AXIS_RATIO
				) {
					// Popups opened outside of a gallery have no navigation, so there is nothing to switch
					if ( ( mfp.st.gallery || {} ).enabled && ( mfp.items || [] ).length > 1 ) {

						// In RTL the gallery arrows are mirrored, so the swipe direction follows them
						if ( ( deltaX < 0 ) != $ush.isRtl() ) {
							mfp.next();
						} else {
							mfp.prev();
						}
					}
					return;
				}

				// Vertical swipe, both up and down: close the popup
				if (
					Math.abs( deltaY ) >= SWIPE_MIN_DISTANCE
					&& Math.abs( deltaY ) > Math.abs( deltaX ) * SWIPE_AXIS_RATIO
				) {
					mfp.close();
				}
			} );
	}

	$us.$document.on( 'usPopupOpened usMagnificPopupOpened', () => {
		$us.$html.addClass( 'us_popup_is_opened' );
		if ( ! $.isMobile && $us.$html[0].scrollHeight > $us.$html[0].clientHeight ) {
			const scrollbarWidth = $us.scrollbarWidth();
			if ( scrollbarWidth ) {
				$us.$html.css( '--scrollbar-width', scrollbarWidth + 'px' );
			}
		}
	} );

	$us.$document.on( 'usPopupClosed usMagnificPopupClosed', () => {
		$us.$html.removeClass( 'us_popup_is_opened' );
		if ( ! $.isMobile ) {
			$us.$html.css( '--scrollbar-width', '' );
		}
	} );

}( jQuery );
