<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Setup Wizard demo import as a WP-CLI command
 *
 * The wizard splits the import into steps because a browser needs them: every step
 * is a separate admin-ajax request with its own progress line in the interface.
 * On the command line the whole set runs at once, as `wp us-import-demo <demo>`.
 *
 * Internally the set is still run one handler per process, and that is not a choice:
 * every wizard handler ends with wp_send_json_*(), which calls wp_die() and ends the
 * process. Demo import handlers carry no data over to each other, so running them in
 * separate processes loses nothing. The --step argument exists for that plumbing.
 */

if ( ! defined( 'WP_CLI' ) OR ! WP_CLI ) {
	return;
}

if ( ! class_exists( 'US_Import_Demo_Command' ) ) {

	class US_Import_Demo_Command {

		/**
		 * The import set, in the order the wizard runs it, as "step name" =>
		 * array( "content key of the demo config", "ajax handler", "required function" ).
		 *
		 * An empty content key means the step applies to every demo: the Setup Wizard
		 * template shows those checkboxes unconditionally. A required function is what
		 * the handler calls from a plugin the wizard activates before the step: in the
		 * browser that plugin arrives with the queue, on the command line it may be missing.
		 *
		 * @see common/admin/templates/sw_site_prebuilt.php
		 *
		 * @var array
		 */
		protected $steps = array(
			'images' => array( '', 'us_import_content_images', '' ),
			'content' => array( '', 'wp_ajax_us_import_content_all', '' ),
			'site_settings' => array( 'options', 'us_import_site_settings', '' ),
			'theme_options' => array( '', 'us_import_content_theme_options', '' ),
			'woocommerce' => array( 'products', 'us_import_content_woocommerce', 'wc_sanitize_taxonomy_name' ),
			'acf' => array( 'acf_fields', 'us_import_content_acf', '' ),
			'index' => array( '', 'us_import_rebuild_index_table', '' ),
		);

		/**
		 * Import a prebuilt demo into this site
		 *
		 * The demo files are downloaded from the UpSolution server, which requires
		 * either an activated license or the US_THEMETEST_CODE constant in wp-config.php.
		 *
		 * Content is added, not replaced: importing into a site that already has the
		 * demo produces duplicates. Reset the site first to get a clean result.
		 *
		 * ## OPTIONS
		 *
		 * [<demo>]
		 * : Slug of the demo to import. Defaults to the first demo of the theme.
		 *
		 * [--list]
		 * : Print the demos available for this theme and exit.
		 *
		 * [--placeholders]
		 * : Import placeholder images instead of the original demo images. The wizard
		 * offers the same choice as a checkbox; the command defaults to the originals,
		 * because a site nobody sets up by hand is expected to look like the demo.
		 *
		 * [--step=<step>]
		 * : Run a single step of the import. Used by the command itself to run the
		 * set process by process, rarely needed by hand.
		 *
		 * [--offset=<offset>]
		 * : With --step: the portion to start from, for a step run in portions (images).
		 *
		 * ## EXAMPLES
		 *
		 *     wp us-import-demo --list
		 *     wp us-import-demo main
		 *     wp us-import-demo main --placeholders
		 *
		 * @param array $args Positional arguments
		 * @param array $assoc_args Associative arguments
		 */
		public function __invoke( $args, $assoc_args ) {
			if ( ! function_exists( 'us_get_demo_import_config' ) ) {
				WP_CLI::error( 'The UpSolution theme is not active on this site.' );
			}

			$config = us_get_demo_import_config();
			if ( empty( $config ) OR ! is_array( $config ) ) {
				WP_CLI::error( 'Could not get the demo list from the UpSolution server.' );
			}

			if ( ! empty( $assoc_args['list'] ) ) {
				foreach ( $config as $slug => $demo ) {
					WP_CLI::log( sprintf( "%s\t%s", $slug, isset( $demo['title'] ) ? $demo['title'] : '' ) );
				}

				return;
			}

			$demo_name = ! empty( $args[0] ) ? $args[0] : key( $config );
			if ( ! isset( $config[ $demo_name ] ) ) {
				WP_CLI::error(
					sprintf(
						'Unknown demo "%s". Available demos: %s',
						$demo_name,
						implode( ', ', array_keys( $config ) )
					)
				);
			}

			$skipped = array();
			$with_images = empty( $assoc_args['placeholders'] );
			$demo_steps = $this->get_demo_steps( $config[ $demo_name ], $with_images, $skipped );

			if ( ! empty( $assoc_args['step'] ) ) {
				$offset = isset( $assoc_args['offset'] ) ? (int) $assoc_args['offset'] : 0;
				$this->run_step( $demo_name, $assoc_args['step'], $demo_steps, $with_images, $offset );

				return;
			}

			$demo_title = ! empty( $config[ $demo_name ]['title'] )
				? $config[ $demo_name ]['title']
				: $demo_name;

			WP_CLI::log( sprintf( 'Starting import "%s"...', $demo_title ) );

			foreach ( $skipped as $step_name => $required_function ) {
				WP_CLI::warning(
					sprintf(
						'%s skipped: %s() is missing, activate the plugin it comes from and import again',
						$step_name,
						$required_function
					)
				);
			}

			$this->run_import( $demo_name, $demo_steps, $demo_title, $with_images );
		}

		/**
		 * Run the whole import set, one handler per process
		 *
		 * A step run in portions (the images) takes a process per portion: the handler
		 * answers how far it has got, and the step is repeated from there until the last
		 * portion, the same way the wizard does it.
		 *
		 * @param string $demo_name Slug of the demo
		 * @param array $demo_steps Step name => handler
		 * @param string $demo_title Title of the demo, for the messages
		 * @param bool $with_images Original demo images instead of placeholders
		 */
		protected function run_import( $demo_name, $demo_steps, $demo_title, $with_images ) {
			foreach ( array_keys( $demo_steps ) as $step_name ) {
				WP_CLI::log( sprintf( '%s...', $step_name ) );

				$offset = 0;
				do {
					$result = WP_CLI::runcommand(
						sprintf(
							'us-import-demo %s --step=%s --offset=%d%s',
							$demo_name,
							$step_name,
							$offset,
							$with_images ? '' : ' --placeholders'
						),
						array(
							'launch' => TRUE,
							'return' => 'all',
							'exit_error' => FALSE,
						)
					);

					// The handler answers in the format of the wizard: {"success":true}
					if ( strpos( (string) $result->stdout, '"success":true' ) === FALSE ) {
						$reason = trim( (string) $result->stderr );
						if ( $reason === '' ) {
							$reason = trim( (string) $result->stdout );
						}

						WP_CLI::error( sprintf( '%s failed: %s', $step_name, $reason ) );
					}

					// A step run in portions reports its progress: {"imported":10,"total":160}
					$has_more = (
						preg_match( '/"imported":(\d+),"total":(\d+)/', (string) $result->stdout, $portion )
						AND (int) $portion[2] > (int) $portion[1]
					);
					if ( $has_more ) {
						$offset = (int) $portion[1];
						WP_CLI::log( sprintf( '  %d / %d', $portion[1], $portion[2] ) );
					}
				} while ( $has_more );
			}

			WP_CLI::success( sprintf( 'Demo "%s" imported.', $demo_title ) );
		}

		/**
		 * Run a single handler of the set. Ends the process through wp_die().
		 *
		 * @param string $demo_name Slug of the demo
		 * @param string $step_name Name of the step
		 * @param array $demo_steps Step name => handler
		 * @param bool $with_images Original demo images instead of placeholders
		 * @param int $offset The portion to start from, for a step run in portions
		 */
		protected function run_step( $demo_name, $step_name, $demo_steps, $with_images, $offset = 0 ) {
			if ( ! isset( $demo_steps[ $step_name ] ) ) {
				WP_CLI::error(
					sprintf(
						'Unknown step "%s". Steps of this demo: %s',
						$step_name,
						implode( ', ', array_keys( $demo_steps ) )
					)
				);
			}

			$handler = $demo_steps[ $step_name ];
			if ( ! function_exists( $handler ) ) {
				WP_CLI::error( sprintf( 'Handler %s does not exist.', $handler ) );
			}

			$this->set_current_user_to_admin();

			// The wizard sends the selected demo with every request of the queue, and
			// `images` when the "import images" checkbox is on: the handlers then ask
			// the server for the `{name}_images.xml` variant of every content file
			$_POST = $_REQUEST = array( 'demo' => $demo_name );
			if ( $with_images ) {
				$_POST['images'] = $_REQUEST['images'] = 1;
			}

			// A step run in portions gets the portion to go on with, as it does from the wizard
			if ( $offset > 0 ) {
				$_POST['offset'] = $_REQUEST['offset'] = $offset;
			}

			call_user_func( $handler );
		}

		/**
		 * Steps that apply to a demo, in the order of the wizard queue
		 *
		 * @param array $demo Demo entry of the import config
		 * @param bool $with_images Original demo images instead of placeholders
		 * @param array $skipped Filled with "step name" => "missing function"
		 *
		 * @return array Step name => handler
		 */
		protected function get_demo_steps( $demo, $with_images, &$skipped = array() ) {
			$content = isset( $demo['content'] ) ? (array) $demo['content'] : array();
			$steps = array();
			$skipped = array();

			foreach ( $this->steps as $step_name => $step ) {
				list( $content_key, $handler, $required_function ) = $step;

				if ( $content_key !== '' AND ! in_array( $content_key, $content ) ) {
					continue;
				}

				// The placeholders come along with the content, so there is no images step for them
				if ( $step_name === 'images' AND ! $with_images ) {
					continue;
				}

				// The plugin this step depends on is not active on the site
				if ( $required_function !== '' AND ! function_exists( $required_function ) ) {
					$skipped[ $step_name ] = $required_function;

					continue;
				}

				$steps[ $step_name ] = $handler;
			}

			return $steps;
		}

		/**
		 * Import on behalf of an administrator: the importer assigns post authors
		 * and checks capabilities the same way it does for a logged in user
		 */
		protected function set_current_user_to_admin() {
			if ( current_user_can( 'manage_options' ) ) {
				return;
			}

			$admins = get_users(
				array(
					'role' => 'administrator',
					'number' => 1,
					'fields' => 'ID',
					'orderby' => 'ID',
				)
			);

			if ( empty( $admins ) ) {
				WP_CLI::error( 'The site has no administrator to import on behalf of.' );
			}

			wp_set_current_user( (int) $admins[0] );
		}
	}

	WP_CLI::add_command( 'us-import-demo', 'US_Import_Demo_Command' );
}
