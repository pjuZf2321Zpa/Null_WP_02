<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Setup Wizard admin page
 */

if ( ! function_exists( 'us_setup_wizard_verify_request' ) ) {
	/**
	 * Check that a Setup Wizard action was requested by the site admin
	 *
	 * The nonce protects the wizard from cross-site requests made by a browser.
	 * Under WP-CLI there is neither a browser nor a session, and the caller
	 * already has shell access to the site, so there is nothing left to protect:
	 * the check is skipped to let the wizard steps run from the command line.
	 *
	 * Note: the wizard steps install plugins, import content and change the options,
	 * so the capability of the wizard page is required along with the nonce.
	 *
	 * @return bool
	 */
	function us_setup_wizard_verify_request() {
		if ( defined( 'WP_CLI' ) AND WP_CLI ) {
			return TRUE;
		}

		return (
			current_user_can( 'manage_options' )
			AND check_ajax_referer( 'us-setup-wizard-actions', 'security', FALSE )
		);
	}
}

if ( ! function_exists( 'us_add_setup_wizard_page' ) ) {

	add_action( 'admin_menu', 'us_add_setup_wizard_page', 30 );

	function us_add_setup_wizard_page() {
		if ( ! defined( 'US_CORE_VERSION' ) ) {
			$parent_slug = 'us-home';
		} else {
			$parent_slug = 'us-theme-options';
		}
		add_submenu_page(
			$parent_slug,
			__( 'Setup Wizard', 'us' ),
			__( 'Setup Wizard', 'us' ),
			'manage_options',
			'us-setup-wizard',
			'us_setup_wizard_page'
		);
	}
}

if ( ! function_exists( 'us_setup_wizard_in_admin_header' ) ) {

	add_action( 'in_admin_header', 'us_setup_wizard_in_admin_header' );

	/**
	 * Hide notices on the Setup Wizard Page
	 *
	 */
	function us_setup_wizard_in_admin_header() {
		global $pagenow;
		if (
			$pagenow == 'admin.php'
			AND isset( $_GET['page'] )
			AND $_GET['page'] == 'us-setup-wizard'
		) {
			remove_all_actions( 'admin_notices' );
		}
	}
}

if ( ! function_exists( 'us_setup_wizard_check_activation' ) ) {

	add_action( 'admin_init', 'us_setup_wizard_check_activation' );

	/**
	 * Check license activation before the Setup Wizard page is rendered.
	 *
	 * Runs on `admin_init` (before any output) so that the post-activation
	 * redirect inside us_check_and_activate_theme() can still send its
	 * `Location` header. Doing this in the page-render callback is too late:
	 * the admin header and enqueued scripts are already flushed, which triggers
	 * "Cannot modify header information - headers already sent".
	 */
	function us_setup_wizard_check_activation() {
		global $pagenow;
		if (
			$pagenow == 'admin.php'
			AND isset( $_GET['page'] )
			AND $_GET['page'] == 'us-setup-wizard'
		) {
			us_check_and_activate_theme();
		}
	}
}

if ( ! function_exists( 'us_setup_wizard_page' ) ) {

	function us_setup_wizard_page() {

		// Output the success screen by URL
		if ( isset( $_GET['success'] ) ) {
			us_setup_wizard_load_template( 'common/admin/templates/sw_success' );

			return;
		}

		if (
			defined( 'US_THEMETEST_CODE' )
			OR get_option( 'us_license_activated', /* default */ 0 )
			OR get_option( 'us_license_dev_activated', /* default */ 0 )
		) {
			$steps = array(
				'setup_type' => array(
					'type' => 'start',
					'menu_label' => __( 'Setup Type', 'us' ),
					'template' => 'sw_setup_type',
				),
				'prebuilt_site' => array(
					'type' => 'prebuilt',
					'menu_label' => us_translate( 'Sites' ),
					'template' => 'sw_site_prebuilt',
				),
				'prebuilt_content' => array(
					'type' => 'prebuilt',
					'menu_label' => us_translate( 'Content' ),
					'template' => 'sw_site_prebuilt',
				),
				'prebuilt_install' => array(
					'type' => 'prebuilt',
					'menu_label' => us_translate_x( 'Installation', 'Plugin installer section title' ),
					'template' => 'sw_site_prebuilt',
				),
				'from_scratch_header' => array(
					'type' => 'from_scratch',
					'menu_label' => _x( 'Header', 'site top area', 'us' ),
					'template' => 'sw_site_from_scratch',
				),
				'from_scratch_footer' => array(
					'type' => 'from_scratch',
					'menu_label' => __( 'Footer', 'us' ),
					'template' => 'sw_site_from_scratch',
				),
				'from_scratch_colors' => array(
					'type' => 'from_scratch',
					'menu_label' => us_translate( 'Colors' ),
					'template' => 'sw_site_from_scratch',
				),
				'from_scratch_fonts' => array(
					'type' => 'from_scratch',
					'menu_label' => __( 'Fonts', 'us' ),
					'template' => 'sw_site_from_scratch',
				),
				'from_scratch_plugins' => array(
					'type' => 'from_scratch',
					'menu_label' => us_translate( 'Plugins' ),
					'template' => 'sw_site_from_scratch',
				),
				'from_scratch_install' => array(
					'type' => 'from_scratch',
					'menu_label' => us_translate_x( 'Installation', 'Plugin installer section title' ),
					'template' => 'sw_site_from_scratch',
				),
			);

		} else {
			$steps = array(
				'activate_theme' => array(
					'type' => 'start',
					'menu_label' => us_translate( 'Activate' ),
					'title' => sprintf( __( 'Welcome to %s', 'us' ), '<strong>' . US_THEMENAME . ' ' . US_THEMEVERSION . '</strong>' ),
					'template' => 'license_activation_form',
				),
			);
		}

		// Get plugins to install for the Prebuilt
		$plugins_to_install = array();

		/*
		 * Don't install ACF if ACF-PRO/SCF is active
		 * ACF-PRO may be installed not from Addons
		 */
		$scf_is_active = is_plugin_active( 'secure-custom-fields/secure-custom-fields.php' );
		$acf_pro_is_active = is_plugin_active( 'advanced-custom-fields-pro/acf.php' );

		foreach ( us_config( 'addons', array() ) as $plugin ) {
			if (
				in_array( $plugin['slug'], array( 'acf', 'advanced-custom-fields' ) )
				AND ( $scf_is_active OR $acf_pro_is_active )
			) {
				continue;
			}

			if ( in_array( $plugin['slug'], array( 'us-core', 'acf', 'advanced-custom-fields', 'woocommerce' ) ) ) {
				$plugin_folder = ( ! empty( $plugin['folder'] ) ) ? $plugin['folder'] : $plugin['slug'];
				if ( strpos( $plugin['slug'], '/' ) !== FALSE ) {
					$plugin_folder = substr(
						$plugin['slug'],
						0,
						strpos( $plugin['slug'], '/' )
					);
				}
				$plugin_to_activate = trailingslashit( $plugin_folder ) . ( $plugin['slug'] === 'advanced-custom-fields' ? 'acf' : $plugin['slug'] ) . '.php';
				if ( ! is_plugin_active( $plugin_to_activate ) ) {
					$plugins_to_install[ $plugin['slug'] ] = us_translate( 'Plugin' ) . ': ' . $plugin['name'];
				}
			}
		}

		$data_to_json = array(
			'ajax' => array(
				'url' => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'us-setup-wizard-actions' ),
			),
			'plugins' => $plugins_to_install,
			'steps' => $steps,
			'translations' => array(
				'home' => us_translate( 'Homepage' ),
				'theme_options' => us_translate( 'Theme Options' ),
			),
			// Unlike `translations`, these are not turned into installation actions
			'labels' => array(
				'install_failed' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				'install_retry' => us_translate( 'Try Again' ),
				'install_waiting' => 'The connection was interrupted. Checking whether the step has finished on the server...',
				// The thumbnails step, once the images themselves are a step of their own
				'image_sizes' => us_translate( 'Image sizes' ),
			),
		);

		$loaded_templates = array();
		?>
		<div id="us-wizard" class="us-wizard step-<?= array_key_first( $steps ) ?>">
			<div class="us-wizard-nav">
				<div class="us-wizard-menu">
					<?php foreach ( $steps as $step_id => $step ) {
						if ( isset( $step['menu_label'] ) ) { ?>
							<button type="button" class="us-wizard-menu-item type-<?= $step['type'] ?> <?= ( $step['type'] === 'start' ? 'active' : 'hidden' ) ?>" data-step-id="<?= $step_id ?>">
								<span><?= $step['menu_label'] ?></span>
							</button>
							<?php
						}
					} ?>
				</div>
				<button type="button" class="button button-primary action-next-step">
					<span><?= __( 'Next Step', 'us' ) ?></span>
				</button>
				<button type="button" class="button button-primary action-select-content">
					<span><?= __( 'Next Step', 'us' ) ?></span>
				</button>
				<button type="button" class="button button-primary action-install-website">
					<span><?= __( 'Start Installation', 'us' ) ?></span>
					<div class="g-preloader type_1"></div>
				</button>
			</div>
			<div class="us-wizard-body">
				<?php foreach ( $steps as $step ) {
					if ( ! empty( $step['template'] ) AND ! in_array( $step['template'], $loaded_templates ) ) {
						$loaded_templates[] = $step['template'];
						us_setup_wizard_load_template( 'common/admin/templates/' . $step['template'], array( 'plugins_to_install' => $plugins_to_install ) );
					}
				} ?>
			</div>
			<div class="us-wizard-json" data-us-json="<?= htmlspecialchars( json_encode( $data_to_json ), ENT_QUOTES, 'UTF-8' ) ?>"></div>
		</div>
	<?php }
}

/* Actions for install content from the scratch
------------------------------------------------------------------------------------*/
if ( ! function_exists( 'us_from_scratch_install_home' ) ) {

	add_action( 'wp_ajax_us_from_scratch_install_home', 'us_from_scratch_install_home' );

	/**
	 * Install selected content
	 */
	function us_from_scratch_install_home() {
		if ( ! us_setup_wizard_verify_request() ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		// Create Home Page
		$home_page_sections = us_config( 'sw-preview-content' );
		$home_page_content = '';

		if ( ! empty( $home_page_sections ) ) {
			foreach ( $home_page_sections as $home_page_section ) {
				$home_page_content .= $home_page_section;
			}
		}

		$home_page_id = wp_insert_post(
			array(
				'post_type' => 'page',
				'post_date' => date( 'Y-m-d H:i', time() - 86400 ),
				'post_status' => 'publish',
				'post_title' => us_translate( 'Home' ),
				'post_content' => $home_page_content,
			)
		);

		if ( $home_page_id < 1 ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		// Set Home Page on the Settings > Reading > Your homepage displays
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home_page_id );

		// Create basic menu
		$menu_name = 'main-menu';
		if ( ! wp_get_nav_menu_object( $menu_name ) ) {
			$menu_id = wp_create_nav_menu( $menu_name );
			$menu_items = array(
				'home' => us_translate( 'Home' ),
				'about' => us_translate_x( 'About', 'Block pattern category' ),
				'blog' => us_translate_x( 'Blog', 'Theme starter content' ),
				'contact' => us_translate_x( 'Contact', 'Block pattern category' ),
			);
			foreach ( $menu_items as $menu_key => $menu_item ) {
				$menu_item_data = array(
					'menu-item-title' => $menu_item,
					'menu-item-url' => '#',
					'menu-item-status' => 'publish',
				);
				if ( $menu_key === 'home' ) {
					$menu_item_data = array(
						'menu-item-object-id' => $home_page_id,
						'menu-item-object' => 'page',
						'menu-item-type' => 'post_type',
						'menu-item-status' => 'publish',
					);
				}

				wp_update_nav_menu_item( $menu_id, 0, $menu_item_data );
			}
		}

		// Create Header
		$header_post_id = '';
		if (
			isset( $_POST['header_id'] )
			AND $header_id = $_POST['header_id']
			AND $header_templates = us_config( 'header-templates', array() )
			AND isset( $header_templates[ $header_id ] )
		) {
			$header_content = $header_templates[ $header_id ];
			foreach ( $header_content['default']['layout'] as $layout ) {
				foreach ( $layout as $pos => $item ) {
					$name = explode( ':', $item );

					// Set created menu
					if ( isset( $name[0] ) and $name[0] == 'menu' ) {
						$header_content['data'][ $item ]['source'] = $menu_name;
					}
				}
			}

			$header_content = us_fix_header_template_settings( $header_content );

			$header_post_id = wp_insert_post(
				array(
					'post_type' => 'us_header',
					'post_date' => date( 'Y-m-d H:i', time() - 86400 ),
					'post_status' => 'publish',
					'post_title' => _x( 'Header', 'site top area', 'us' ),
					'post_content' => wp_slash( json_encode( $header_content, JSON_UNESCAPED_UNICODE ) ),
				)
			);
		}

		// Create Reusable Block for Footer
		$footer_post_id = '';
		if (
			isset( $_POST['footer_id'] )
			AND $footer_id = $_POST['footer_id']
			AND $footer_templates = us_config( 'footer-templates', array() )
			AND isset( $footer_templates[ $footer_id ] )
		) {
			$footer_content = $footer_templates[ $footer_id ]['content'];

			// Set created menu, if it exists in the shortcode
			$footer_content = preg_replace( '/source="(.*?)"/', 'source="' . $menu_name . '"', $footer_content );

			$footer_post_id = wp_insert_post(
				array(
					'post_type' => 'us_page_block',
					'post_date' => date( 'Y-m-d H:i', time() - 86400 ),
					'post_status' => 'publish',
					'post_title' => __( 'Footer', 'us' ),
					'post_content' => $footer_content,
				)
			);
		}

		$response_data = array(
			'header_post_id' => $header_post_id,
			'footer_post_id' => $footer_post_id,
		);

		us_demo_import_mark_step_done( $response_data );
		wp_send_json_success( $response_data );
	}
}

if ( ! function_exists( 'us_from_scratch_install_theme_options' ) ) {

	add_action( 'wp_ajax_us_from_scratch_install_theme_options', 'us_from_scratch_install_theme_options' );

	/**
	 * Install selected Theme Options
	 */
	function us_from_scratch_install_theme_options() {
		if ( ! us_setup_wizard_verify_request() ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		// Get the default Theme Options values
		// Note: they come from the static config, so there are no dependencies to preload, see usof_defaults()
		$updated_options = usof_defaults();

		// Header
		if ( isset( $_POST['header_post_id'] ) AND $header_post_id = (int) $_POST['header_post_id'] ) {
			$updated_options['header_id'] = $header_post_id;
		}

		// Footer
		if ( isset( $_POST['footer_post_id'] ) AND $footer_post_id = (int) $_POST['footer_post_id'] ) {
			$updated_options['footer_id'] = $footer_post_id;
		}

		// Fonts
		$typography_config = us_config( 'typography-templates' );
		if (
			isset( $_POST['font_id'] )
			AND isset( $typography_config[ $_POST['font_id'] ] )
		) {
			$updated_options = us_array_merge( $updated_options, $typography_config[ $_POST['font_id'] ] );
		}

		// Colors
		$colors_config = us_config( 'color-schemes' );
		if (
			isset( $_POST['scheme_id'] )
			AND isset( $colors_config[ $_POST['scheme_id'] ] )
		) {
			$updated_options = us_array_merge( $updated_options, $colors_config[ $_POST['scheme_id'] ]['values'] );
		}

		usof_save_options( $updated_options );

		us_demo_import_mark_step_done();
		wp_send_json_success();
	}
}

/* Actions for install content from the prebuilt
------------------------------------------------------------------------------------*/
if ( ! function_exists( 'us_ajax_install_plugin' ) ) {

	add_action( 'wp_ajax_us_ajax_install_plugin', 'us_ajax_install_plugin' );

	function us_ajax_install_plugin() {

		set_time_limit( 300 );

		if ( ! us_setup_wizard_verify_request() ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		if ( ! isset( $_POST['plugin'] ) OR ! $_POST['plugin'] ) {
			wp_send_json_error( array( 'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ) ) );
		}

		// Note: us_install_plugin() responds by itself, leaving no room for the step mark
		$result = us_load_plugin( $_POST['plugin'], /* activate */TRUE );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		$response_data = array( 'plugin' => $_POST['plugin'] );

		us_demo_import_mark_step_done( $response_data );
		wp_send_json_success( $response_data );
	}
}

if ( ! function_exists( 'us_get_selected_demo_name' ) ) {
	/**
	 * Returns name of selected demo site
	 *
	 * @return string
	 */
	function us_get_selected_demo_name() {
		$config = us_get_demo_import_config();
		$available_demos = array_keys( $config );
		$demo_name = $available_demos[0] ?? '';
		if ( in_array( $_POST['demo'], $available_demos ) ) {
			$demo_name = $_POST['demo'];
		}
		return $demo_name;
	}
}

if ( ! function_exists( 'us_demo_import_file_is_valid' ) ) {
	/**
	 * Checks that the UpSolution server has actually returned a demo file
	 *
	 * @param mixed $us_api_response The us_api() result
	 * @param string $extension [optional] The expected file type
	 * @return bool
	 */
	function us_demo_import_file_is_valid( $us_api_response, $extension = 'xml' ) {
		if ( empty( $us_api_response ) OR empty( $us_api_response['body'] ) ) {
			return FALSE;
		}

		// The server has reported a problem instead of returning the file
		if ( ! empty( $us_api_response['error_code'] ) OR ! empty( $us_api_response['error_message'] ) ) {
			return FALSE;
		}

		// A JSON error message would pass the length check below, so require a WXR file
		if ( $extension == 'xml' ) {
			return ( strpos( $us_api_response['body'], '<rss' ) !== FALSE );
		}

		// Short responses are error messages rather than content
		return ( strlen( $us_api_response['body'] ) >= 300 OR json_decode( $us_api_response['body'] ) !== NULL );
	}
}

if ( ! function_exists( 'us_demo_import_with_images' ) ) {
	/**
	 * Determines if the demo images are imported as is, instead of placeholders
	 *
	 * @return bool
	 */
	function us_demo_import_with_images() {
		return ! empty( $_POST['images'] );
	}
}

if ( ! function_exists( 'us_upload_import_file' ) ) {
	/**
	 * Upload demo data to server
	 *
	 * Content files come in two variants: `{name}.xml` with placeholders
	 * and `{name}_images.xml` with the original images.
	 *
	 * @param string $filename
	 * @param string $extension
	 *
	 * @return mixed
	 */
	function us_upload_import_file( $filename = '', $extension = 'xml' ) {
		if (
			! defined( 'US_THEMETEST_CODE' )
			AND ! get_option( 'us_license_activated' )
			AND ! get_option( 'us_license_dev_activated' )
		) {
			$message_error = new WP_Error( 'us-demo-import-file', 'The theme license is not activated.' );

			return $message_error;
		}

		$upload_dir = wp_upload_dir();
		$file_path = $upload_dir['basedir'] . '/' . $filename . '.' . $extension;

		// Determine if can't write to dir or file
		if ( ! is_writable( $upload_dir['basedir'] ) ) {
			$message_error = new WP_Error( 'us-demo-import-file', 'Failed to save files: the upload directory is not writable.' );

			return $message_error;
		}

		// Note: Theme Options and Site Settings have no images variant
		$requested_file = ( $extension == 'xml' AND us_demo_import_with_images() )
			? $filename . '_images'
			: $filename;

		/**
		 * @var array HTTP GET variables
		 */
		$get_variables = array(
			'demo' => us_get_selected_demo_name(),
			'domain' => wp_parse_url( site_url(), PHP_URL_HOST ),
			'file' => urlencode( $requested_file ),
			'secret' => (string) get_option( 'us_license_secret' ),
		);

		$us_api_response = us_api( '/us.api/download_demo/:us_themename', $get_variables );

		// Determine if the server doesn't get the file
		if ( ! us_demo_import_file_is_valid( $us_api_response, $extension ) ) {
			$message_error = new WP_Error(
				'us-demo-import-file',
				sprintf( 'Failed to download "%s" from the UpSolution server.', $requested_file )
			);

			return $message_error;
		}

		// Get the data from the server and write it into the relevant file
		if ( $fp = fopen( $file_path, 'w' ) AND fwrite( $fp, $us_api_response['body'] ) ) {
			return $file_path;

		} else {
			$message_error = new WP_Error( 'us-demo-import-file', 'Failed to create files on a disk.' );

			return $message_error;
		}
	}
}

if ( ! function_exists( 'us_demo_import_get_importer' ) ) {
	/**
	 * Loads the bundled WordPress Importer and returns a ready to use instance
	 *
	 * @return WP_Import
	 */
	function us_demo_import_get_importer() {
		if ( ! defined( 'WP_LOAD_IMPORTERS' ) ) {
			define( 'WP_LOAD_IMPORTERS', TRUE );
		}

		if ( ! class_exists( 'WP_Import' ) ) {
			require_once( US_CORE_DIR . 'vendor/wordpress-importer/wordpress-importer.php' );
		}

		$importer = new WP_Import;
		$importer->fetch_attachments = TRUE;

		return $importer;
	}
}

if ( ! function_exists( 'us_demo_import_origins_like' ) ) {
	/**
	 * Builds a "column LIKE ... OR column LIKE ..." condition matching any of the origins
	 *
	 * @param string $column The column name
	 * @param array $origins The URL origins to look for
	 * @return string
	 */
	function us_demo_import_origins_like( $column, $origins ) {
		global $wpdb;

		$conditions = array();
		foreach ( $origins as $origin ) {
			$conditions[] = $wpdb->prepare( "{$column} LIKE %s", '%' . $wpdb->esc_like( $origin ) . '%' );
		}

		return implode( ' OR ', $conditions );
	}
}

if ( ! function_exists( 'us_demo_import_remap_meta_urls' ) ) {
	/**
	 * Remaps the image URLs that WP_Import::backfill_attachment_urls() does not cover:
	 * the generated CSS in post meta and the percent-encoded `css="..."` attribute.
	 *
	 * @param array $url_remap The WP_Import::$url_remap value
	 * @return void
	 */
	function us_demo_import_remap_meta_urls( $url_remap ) {
		global $wpdb;

		if ( empty( $url_remap ) ) {
			return;
		}

		/**
		 * Every URL goes into the map in both spellings: plain for the generated CSS
		 * and percent-encoded for the `css="..."` attribute. Sorting is not needed,
		 * strtr() with an array tries the longest keys first.
		 */
		$replacements = array();
		$origins = array();

		foreach ( $url_remap as $from_url => $to_url ) {
			if ( $from_url === '' OR $from_url === $to_url ) {
				continue;
			}

			$replacements[ $from_url ] = $to_url;
			$replacements[ rawurlencode( $from_url ) ] = rawurlencode( $to_url );

			// Collect the source origins to narrow down the rows to look at
			$scheme = wp_parse_url( $from_url, PHP_URL_SCHEME );
			$host = wp_parse_url( $from_url, PHP_URL_HOST );
			if ( $scheme AND $host ) {
				$origin = $scheme . '://' . $host;
				$origins[ $origin ] = TRUE;
				$origins[ rawurlencode( $origin ) ] = TRUE;
			}
		}

		if ( empty( $replacements ) OR empty( $origins ) ) {
			return;
		}

		$origins = array_keys( $origins );

		// The generated CSS, stored as post meta
		$meta_ids = $wpdb->get_col(
			"SELECT meta_id FROM {$wpdb->postmeta}
			WHERE meta_key IN ( '_wpb_shortcodes_custom_css', 'us_og_image' )
				AND ( " . us_demo_import_origins_like( 'meta_value', $origins ) . " )"
		);

		// The values may be large, so do not load them all at once
		foreach ( array_chunk( (array) $meta_ids, 50 ) as $chunk ) {
			$rows = $wpdb->get_results(
				"SELECT meta_id, post_id, meta_value FROM {$wpdb->postmeta}
				WHERE meta_id IN ( " . implode( ',', array_map( 'intval', $chunk ) ) . " )"
			);

			foreach ( $rows as $row ) {
				$new_value = strtr( $row->meta_value, $replacements );

				if ( $new_value !== $row->meta_value ) {
					$wpdb->update( $wpdb->postmeta, array( 'meta_value' => $new_value ), array( 'meta_id' => $row->meta_id ) );
					wp_cache_delete( $row->post_id, 'post_meta' );
				}
			}
		}

		// The design options, stored percent-encoded inside the content
		$post_ids = $wpdb->get_col(
			"SELECT ID FROM {$wpdb->posts}
			WHERE post_type != 'revision'
				AND post_status != 'auto-draft'
				AND ( " . us_demo_import_origins_like( 'post_content', $origins ) . " )"
		);

		// Post contents may be large, so do not load them all at once
		foreach ( array_chunk( (array) $post_ids, 50 ) as $chunk ) {
			$rows = $wpdb->get_results(
				"SELECT ID, post_content FROM {$wpdb->posts}
				WHERE ID IN ( " . implode( ',', array_map( 'intval', $chunk ) ) . " )"
			);

			foreach ( $rows as $row ) {
				$new_content = strtr( $row->post_content, $replacements );

				if ( $new_content !== $row->post_content ) {
					$wpdb->update( $wpdb->posts, array( 'post_content' => $new_content ), array( 'ID' => $row->ID ) );
					clean_post_cache( $row->ID );
				}
			}
		}
	}
}

if ( ! function_exists( 'us_demo_import_collect_state' ) ) {
	/**
	 * Accumulates the data needed by the last step of the installation
	 *
	 * Every content file carries the whole media library, so the attachments are really
	 * imported by the "Images" step only, a portion per request: in the content files
	 * WP_Import finds them as already existing and leaves its `$url_remap` empty. That is
	 * why the map is collected here and applied at the very end, when it covers the
	 * content of every imported file.
	 *
	 * @param WP_Import $importer The importer that has finished its work
	 * @return void
	 */
	function us_demo_import_collect_state( $importer ) {
		if ( ! empty( $importer->url_remap ) ) {
			$url_remap = get_transient( 'us_demo_import_url_remap' );
			if ( ! is_array( $url_remap ) ) {
				$url_remap = array();
			}

			set_transient( 'us_demo_import_url_remap', $importer->url_remap + $url_remap, DAY_IN_SECONDS );
		}

		// The posts of every step, so that the last one knows which images were imported
		if ( ! empty( $importer->processed_posts ) ) {
			$post_ids = get_transient( 'us_demo_import_post_ids' );
			if ( ! is_array( $post_ids ) ) {
				$post_ids = array();
			}

			$post_ids = array_merge( $post_ids, array_map( 'intval', array_values( $importer->processed_posts ) ) );

			set_transient( 'us_demo_import_post_ids', array_unique( $post_ids ), DAY_IN_SECONDS );
		}
	}
}

if ( ! function_exists( 'us_demo_import_collect_orphans' ) ) {
	/**
	 * Keeps the attachments of the "Images" step whose parents are yet to be imported
	 *
	 * WP_Import::backfill_parents() only knows the orphans of its own run, and the images
	 * come in a run of their own, before any of their parents. So their orphans are kept
	 * aside, as "original attachment ID" => "original parent ID", for the content files.
	 *
	 * @see us_demo_import_backfill_attachment_parents()
	 * @param WP_Import $importer The importer that has finished its work
	 * @return void
	 */
	function us_demo_import_collect_orphans( $importer ) {
		if ( empty( $importer->post_orphans ) ) {
			return;
		}

		$orphans = get_transient( 'us_demo_import_post_orphans' );
		if ( ! is_array( $orphans ) ) {
			$orphans = array();
		}

		set_transient( 'us_demo_import_post_orphans', $importer->post_orphans + $orphans, DAY_IN_SECONDS );
	}
}

if ( ! function_exists( 'us_demo_import_backfill_attachment_parents' ) ) {
	/**
	 * Attaches the images of the "Images" step to their parents, once those are imported
	 *
	 * Every content file carries the whole media library, so the importer of a content
	 * file maps the existing attachments along with the posts it brings: the file that
	 * brings the parent has both of them in its `$processed_posts`. The orphans left over
	 * wait for the next file.
	 *
	 * @see us_demo_import_collect_orphans()
	 * @param WP_Import $importer The importer that has finished its work
	 * @return void
	 */
	function us_demo_import_backfill_attachment_parents( $importer ) {
		global $wpdb;

		$orphans = get_transient( 'us_demo_import_post_orphans' );
		if ( ! is_array( $orphans ) OR empty( $orphans ) ) {
			return;
		}

		foreach ( $orphans as $child_id => $parent_id ) {
			if ( ! isset( $importer->processed_posts[ $child_id ], $importer->processed_posts[ $parent_id ] ) ) {
				continue;
			}

			$local_child_id = (int) $importer->processed_posts[ $child_id ];

			$wpdb->update(
				$wpdb->posts,
				array( 'post_parent' => (int) $importer->processed_posts[ $parent_id ] ),
				array( 'ID' => $local_child_id ),
				'%d',
				'%d'
			);
			clean_post_cache( $local_child_id );

			unset( $orphans[ $child_id ] );
		}

		if ( empty( $orphans ) ) {
			delete_transient( 'us_demo_import_post_orphans' );
		} else {
			set_transient( 'us_demo_import_post_orphans', $orphans, DAY_IN_SECONDS );
		}
	}
}

if ( ! function_exists( 'us_demo_import_collect_term_thumbnail' ) ) {

	// Fires for the terms the importer creates only, so a term imported earlier is never touched again
	add_action( 'import_term_meta', 'us_demo_import_collect_term_thumbnail', 10, 3 );

	/**
	 * Remembers the demo image a product category created by the importer points to
	 *
	 * @see us_demo_import_remap_term_thumbnails()
	 * @param int $term_id The local term ID
	 * @param string $key The meta key
	 * @param mixed $value The meta value, as it comes from the demo
	 * @return void
	 */
	function us_demo_import_collect_term_thumbnail( $term_id, $key, $value ) {
		global $us_demo_import_term_thumbnails;

		if ( $key !== 'thumbnail_id' OR empty( $value ) ) {
			return;
		}

		if ( ! is_array( $us_demo_import_term_thumbnails ) ) {
			$us_demo_import_term_thumbnails = array();
		}

		$us_demo_import_term_thumbnails[ (int) $term_id ] = (int) $value;
	}
}

if ( ! function_exists( 'us_demo_import_remap_term_thumbnails' ) ) {
	/**
	 * Points the product categories created by the importer to the imported copies of their images
	 *
	 * WP_Import writes the term meta as it comes, so `thumbnail_id` keeps the attachment ID
	 * of the demo site: unlike the featured images of the posts, nothing remaps it. Once the
	 * importer is done it has the map: the images come before the content, and the importer
	 * finds them as existing.
	 *
	 * @see us_demo_import_collect_term_thumbnail()
	 * @param WP_Import $importer The importer that has finished its work
	 * @return void
	 */
	function us_demo_import_remap_term_thumbnails( $importer ) {
		global $us_demo_import_term_thumbnails;

		if ( empty( $us_demo_import_term_thumbnails ) ) {
			return;
		}

		foreach ( $us_demo_import_term_thumbnails as $term_id => $attachment_id ) {
			if ( isset( $importer->processed_posts[ $attachment_id ] ) ) {
				update_term_meta( $term_id, 'thumbnail_id', (int) $importer->processed_posts[ $attachment_id ] );

				// The image has not made it: no image is better than whatever has this ID here
			} else {
				delete_term_meta( $term_id, 'thumbnail_id' );
			}
		}

		$us_demo_import_term_thumbnails = array();
	}
}

if ( ! function_exists( 'us_demo_import_skip_theme_subsizes' ) ) {
	/**
	 * Postpones the theme thumbnails to the last step of the installation
	 *
	 * At the import time the registered theme sizes still come from the current `img_size`,
	 * while the demo brings its own one with the Theme Options, imported at a later step.
	 * So every theme thumbnail made here is cut for nothing and is cut again at the end.
	 *
	 * The sizes of WordPress and of the plugins are left alone: they do not come with
	 * the demo, and the Media Library expects them right away.
	 *
	 * @param array $new_sizes The image sizes to be created
	 * @param array $image_meta The attachment metadata
	 * @return array
	 */
	function us_demo_import_skip_theme_subsizes( $new_sizes, $image_meta = array() ) {
		// The placeholders are skipped by the regeneration, so leave them with all the sizes
		$file = isset( $image_meta['file'] ) ? $image_meta['file'] : '';
		if (
			strpos( $file, 'us-placeholder' ) !== FALSE
			OR strpos( $file, 'woocommerce-placeholder' ) !== FALSE
		) {
			return $new_sizes;
		}

		foreach ( $new_sizes as $size_name => $size ) {
			// Note: sizes with a zero dimension are not regenerated later, so keep them here
			if (
				strpos( $size_name, 'us_' ) === 0
				AND ! empty( $size['width'] )
				AND ! empty( $size['height'] )
			) {
				unset( $new_sizes[ $size_name ] );
			}
		}

		return $new_sizes;
	}
}

if ( ! function_exists( 'us_demo_import_step_key' ) ) {
	/**
	 * The key the current installation step is remembered by
	 *
	 * All the plugins are installed by one action, so the slug tells their steps apart:
	 * without it a mark left by an installed plugin would pass for a failed one. Likewise
	 * a step run in portions is marked per portion, so that a finished portion does not
	 * pass for the one still running.
	 *
	 * @return string
	 */
	function us_demo_import_step_key() {
		if ( empty( $_POST['action'] ) ) {
			return '';
		}

		$step = sanitize_text_field( $_POST['action'] );

		if ( ! empty( $_POST['plugin'] ) ) {
			$step .= ':' . sanitize_text_field( $_POST['plugin'] );
		}

		if ( ! empty( $_POST['offset'] ) ) {
			$step .= ':' . absint( $_POST['offset'] );
		}

		return $step;
	}
}

if ( ! function_exists( 'us_demo_import_catch_fatal' ) ) {

	/**
	 * Remembers the fatal error that has killed an installation step
	 *
	 * Without it the wizard cannot tell a step that is still running from the one that
	 * has died: neither of them has a completion mark. An exhausted memory limit and a
	 * reached execution time end up here as well, which is exactly what has to be shown.
	 *
	 * @see us_import_step_status()
	 * @return void
	 */
	function us_demo_import_catch_fatal() {
		$error = error_get_last();
		$fatal_types = array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR );

		if ( empty( $error['type'] ) OR ! in_array( $error['type'], $fatal_types, TRUE ) ) {
			return;
		}

		if ( ! $step = us_demo_import_step_key() ) {
			return;
		}

		set_transient(
			'us_demo_import_step_error', array(
				'step' => $step,
				'run_id' => sanitize_text_field( $_POST['run_id'] ),
				'message' => $error['message'],
			), HOUR_IN_SECONDS
		);
	}

	/**
	 * Note: the registration goes after the declaration, as a function declared inside
	 * a condition exists only from that point on, and the callback is validated at once
	 *
	 * Every installation step of the wizard comes with a `run_id`
	 */
	if ( wp_doing_ajax() AND ! empty( $_POST['run_id'] ) ) {
		register_shutdown_function( 'us_demo_import_catch_fatal' );
	}
}

if ( ! function_exists( 'us_demo_import_mark_step_done' ) ) {
	/**
	 * Remembers that the current installation step has finished
	 *
	 * A heavy step often outlives the request that started it: the browser or the server
	 * drops the connection, while PHP goes on and completes the work. This mark lets the
	 * wizard tell such a case from a step that has really failed.
	 *
	 * @see us_import_step_status()
	 * @param array $data [optional] The response data the step would have returned
	 * @return void
	 */
	function us_demo_import_mark_step_done( $data = NULL ) {
		if ( empty( $_POST['run_id'] ) OR ! $step = us_demo_import_step_key() ) {
			return;
		}

		$done_steps = get_transient( 'us_demo_import_done_steps' );
		if ( ! is_array( $done_steps ) ) {
			$done_steps = array();
		}

		$done_steps[ $step ] = array(
			'run_id' => sanitize_text_field( $_POST['run_id'] ),
			'data' => $data,
		);

		set_transient( 'us_demo_import_done_steps', $done_steps, HOUR_IN_SECONDS );
	}
}

if ( ! function_exists( 'us_import_step_status' ) ) {

	add_action( 'wp_ajax_us_import_step_status', 'us_import_step_status' );

	/**
	 * Tells the wizard whether the step it has lost the connection to has finished anyway
	 *
	 * @see us_demo_import_mark_step_done()
	 */
	function us_import_step_status() {
		if (
			! current_user_can( 'manage_options' )
			OR ! check_ajax_referer( 'us-setup-wizard-actions', 'security', FALSE )
		) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		$step = isset( $_POST['step'] ) ? sanitize_text_field( $_POST['step'] ) : '';
		$run_id = isset( $_POST['run_id'] ) ? sanitize_text_field( $_POST['run_id'] ) : '';
		$done_steps = get_transient( 'us_demo_import_done_steps' );

		// The run id tells the current installation from the marks left by a previous one
		$step_is_done = (
			$step
			AND $run_id
			AND is_array( $done_steps )
			AND isset( $done_steps[ $step ]['run_id'] )
			AND $done_steps[ $step ]['run_id'] === $run_id
		);

		// A step that has died leaves no mark either, so tell it from the one still running
		$step_error = get_transient( 'us_demo_import_step_error' );
		$step_has_failed = (
			! $step_is_done
			AND is_array( $step_error )
			AND isset( $step_error['step'], $step_error['run_id'] )
			AND $step_error['step'] === $step
			AND $step_error['run_id'] === $run_id
		);

		// Reported once: a repeated step must not stumble over the error of the previous try
		if ( $step_has_failed ) {
			delete_transient( 'us_demo_import_step_error' );
		}

		wp_send_json_success(
			array(
				'done' => $step_is_done,
				// The response that the interrupted request has never delivered
				'result' => $step_is_done ? $done_steps[ $step ]['data'] : NULL,
				'failed' => $step_has_failed,
				'message' => $step_has_failed ? $step_error['message'] : '',
			)
		);
	}
}

if ( ! function_exists( 'us_demo_import_apply_url_remap' ) ) {
	/**
	 * Remaps the collected image URLs, once the whole content is in place
	 *
	 * @see us_demo_import_collect_state()
	 * @return void
	 */
	function us_demo_import_apply_url_remap() {
		if ( is_array( $url_remap = get_transient( 'us_demo_import_url_remap' ) ) ) {
			us_demo_import_remap_meta_urls( $url_remap );
		}

		delete_transient( 'us_demo_import_url_remap' );
	}
}

if ( ! function_exists( 'us_import_content' ) ) {
	/**
	 * @param string $file_path The file path
	 * @param bool $with_images [optional] Import the original demo images instead of placeholders
	 */
	function us_import_content( $file_path, $with_images = FALSE ) {
		global $wp_import, $wpdb;

		us_set_time_limit();

		$wp_import = us_demo_import_get_importer();

		// The theme thumbnails are cut at the last step, when the demo `img_size` is known
		$skip_theme_subsizes = ( $with_images AND class_exists( 'US_Regenerate_Thumbnails' ) );
		if ( $skip_theme_subsizes ) {
			add_filter( 'intermediate_image_sizes_advanced', 'us_demo_import_skip_theme_subsizes', 10, 2 );
		}

		ob_start();
		$wp_import->import( $file_path );
		ob_end_clean();

		if ( $skip_theme_subsizes ) {
			remove_filter( 'intermediate_image_sizes_advanced', 'us_demo_import_skip_theme_subsizes', 10 );
		}

		if ( $with_images ) {
			us_demo_import_collect_state( $wp_import );
			us_demo_import_backfill_attachment_parents( $wp_import );
		}

		// Note: the placeholders point to placeholder attachments, which are imported as well
		us_demo_import_remap_term_thumbnails( $wp_import );

		// Replace images with placeholder.
		$placeholders = $with_images
			? array()
			: $wpdb->get_results( "SELECT ID, guid FROM `{$wpdb->posts}` WHERE guid LIKE '%us-placeholder%';", ARRAY_A );

		if ( ! empty( $placeholders ) ) {
			$wpdb_results = $wpdb->get_results( "
				SELECT p.ID, pm.meta_value, pm.meta_key
				FROM {$wpdb->postmeta} pm
				LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE
					pm.meta_key IN( '_wpb_shortcodes_custom_css', 'us_og_image', 'us_tile_additional_image' )
					AND p.post_status = 'publish'
			" );
			foreach ( $wpdb_results as $meta_result ) {
				if ( $meta_result->meta_key == 'us_tile_additional_image' ) {
					$count_images = count( explode( ',', $meta_result->meta_value ) );

					if ( $count_images ) {
						$new_meta_value = array();
						for ( $i = 0; $i < $count_images; $i++ ) {
							$new_meta_value[] = $placeholders[ $i % count( $placeholders ) ]['ID'];
						}

						update_post_meta( $meta_result->ID, $meta_result->meta_key, implode( ',', $new_meta_value ) );
					}

					// For "_wpb_shortcodes_custom_css" and "us_og_image"
				} else {
					$new_meta_value = preg_replace( '/(https?:\/\/[^ ,;]+\.(?:png|jpg))/i', $placeholders[0]['guid'], $meta_result->meta_value );
					if ( $new_meta_value !== $meta_result->meta_value ) {
						update_post_meta( $meta_result->ID, $meta_result->meta_key, $new_meta_value );
					}
				}
			}
		}

		// Remove meta duplicates for _wpb_shortcodes_custom_css
		$delete_meta_duplicates_sql = "
			DELETE FROM {$wpdb->postmeta}
			WHERE meta_key IN ('_wpb_shortcodes_custom_css', 'us_og_image', 'us_grid_layout_ids') AND meta_id NOT IN (
				SELECT *
				FROM (
					SELECT MAX(meta_id)
					FROM {$wpdb->postmeta}
					WHERE meta_key IN ('_wpb_shortcodes_custom_css', 'us_og_image', 'us_grid_layout_ids')
					GROUP BY post_id, meta_key
				) AS x
			)";

		$wpdb->query( $delete_meta_duplicates_sql );

		// Delete the saved styles for regeneration
		if ( get_option( 'us_theme_options_css' ) ) {
			delete_option( 'us_theme_options_css' );
		}

		unlink( $file_path );
	}
}

if ( ! function_exists( 'us_action_for_import' ) ) {
	/**
	 * Global action for import demo
	 *
	 * @param string $filename
	 *
	 * @return string
	 */
	function us_action_for_import( $filename, $callback = NULL ) {
		if ( ! us_setup_wizard_verify_request() ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		$file_path = us_upload_import_file( $filename );

		if ( ! is_wp_error( $file_path ) ) {
			us_import_content( $file_path, us_demo_import_with_images() );
			if ( is_callable( $callback ) ) {
				call_user_func( $callback );
			}
			us_demo_import_mark_step_done();
			wp_send_json_success();

		} else {
			wp_send_json_error(
				array(
					'message' => $file_path->get_error_message(),
				)
			);
		}
	}
}

// Import All Content
if ( ! function_exists( 'wp_ajax_us_import_content_all' ) ) {

	add_action( 'wp_ajax_us_import_content_all', 'wp_ajax_us_import_content_all' );

	function wp_ajax_us_import_content_all() {

		if ( ! us_setup_wizard_verify_request() ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		$config = us_get_demo_import_config();
		$demo_name = us_get_selected_demo_name();
		$demo_selected = isset( $_POST['demo'] ) ? $_POST['demo'] : '';

		$file_path = us_upload_import_file( 'all_content' );

		if ( ! is_wp_error( $file_path ) ) {

			// Actions BEFORE saving posts to database
			add_filter( 'wp_import_post_data_raw', 'us_demo_import_all_wp_import_post_data_raw' );
			function us_demo_import_all_wp_import_post_data_raw( $post ) {

				// Filter content of every post
				if ( ! in_array( $post['post_type'], array( 'nav_menu_item', 'attachment' ) ) AND ! empty( $post['post_content'] ) ) {
					$post['post_content'] = us_replace_post_list_term_slugs_with_ids( $post['post_content'] );
				}

				// Collect meta data of menu items 
				global $us_demo_import_mega_menu_data;
				if ( $post['post_type'] == 'nav_menu_item' AND isset( $post['postmeta'] ) AND is_array( $post['postmeta'] ) ) {
					foreach ( $post['postmeta'] as $postmeta ) {
						if ( is_array( $postmeta ) AND isset( $postmeta['key'] ) AND $postmeta['key'] == 'us_mega_menu_settings' AND ! empty( $postmeta['value'] ) ) {
							if ( ! isset( $us_demo_import_mega_menu_data ) OR ! is_array( $us_demo_import_mega_menu_data ) ) {
								$us_demo_import_mega_menu_data = array();
							}

							$us_demo_import_mega_menu_data[ (int) $post['post_id'] ] = $postmeta['value'];
						}
					}
				}

				return $post;
			}

			// Actions AFTER saving posts to database
			add_action( 'import_end', 'us_demo_import_all_import_end' );
			function us_demo_import_all_import_end() {
				global $wp_import, $us_demo_import_mega_menu_data;

				if ( is_array( $us_demo_import_mega_menu_data ) ) {
					foreach ( $us_demo_import_mega_menu_data as $menu_import_id => $mega_menu_data ) {
						if ( ! empty( $wp_import->processed_menu_items[ $menu_import_id ] ) ) {
							update_post_meta( (int) $wp_import->processed_menu_items[ $menu_import_id ], 'us_mega_menu_settings', maybe_unserialize( $mega_menu_data ) );
						}
					}
				}
			}

			// Register testimonials, if the demo has them in the contents
			if (
				! us_get_option( 'enable_testimonials' )
				AND isset( $config[ $demo_selected ] )
				AND in_array( 'testimonials', $config[ $demo_selected ]['content'] )
				AND function_exists( 'us_create_testimonials_post_type' )
			) {
				us_create_testimonials_post_type();
			}

			// Register portfolio, if the demo has it in the contents
			if (
				! us_get_option( 'enable_portfolio' )
				AND isset( $config[ $demo_selected ] )
				AND in_array( 'portfolio_items', $config[ $demo_selected ]['content'] )
				AND function_exists( 'us_create_portfolio_post_type' )
			) {
				us_create_portfolio_post_type();
			}

			/**
			 * Get page ID by title
			 *
			 * @param $page_slug
			 * @return string|null
			 */
			global $wpdb;
			$func_get_page_id_by_slug = function ( $page_slug ) use ( $wpdb ) {
				return $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_name = '" . $page_slug . "' AND post_type = 'page' AND post_status = 'publish'" );
			};

			// Delete initial WooCommerce pages to free their page slugs
			if ( $shop_page_id = $func_get_page_id_by_slug( 'shop' ) ) {
				wp_delete_post( $shop_page_id, TRUE );
			}
			if ( $cart_page_id = $func_get_page_id_by_slug( 'cart' ) ) {
				wp_delete_post( $cart_page_id, TRUE );
			}
			if ( $checkout_page_id = $func_get_page_id_by_slug( 'checkout' ) ) {
				wp_delete_post( $checkout_page_id, TRUE );
			}
			if ( $my_account_page_id = $func_get_page_id_by_slug( 'my-account' ) ) {
				wp_delete_post( $my_account_page_id, TRUE );
			}

			// Delete the initial WordPress sample page (the Privacy Policy page is kept, as it is linked from legal notices)
			if ( $sample_page_id = $func_get_page_id_by_slug( 'sample-page' ) ) {
				wp_delete_post( $sample_page_id, TRUE );
			}

			us_import_content( $file_path, us_demo_import_with_images() );

			// Set menu
			if ( isset( $config[ $demo_name ]['nav_menu_locations'] ) ) {
				$locations = get_theme_mod( 'nav_menu_locations' );
				$menus = array();
				foreach ( wp_get_nav_menus() as $menu ) {
					if ( is_object( $menu ) ) {
						$menus[ $menu->name ] = $menu->term_id;
					}
				}
				foreach ( $config[ $demo_name ]['nav_menu_locations'] as $nav_location_key => $menu_name ) {
					if ( isset( $menus[ $menu_name ] ) ) {
						$locations[ $nav_location_key ] = $menus[ $menu_name ];
					}
				}

				set_theme_mod( 'nav_menu_locations', $locations );
			}

			// Set Front Page
			if ( isset( $config[ $demo_name ]['front_page'] ) ) {
				$front_page = get_posts(
					array(
						'name' => $config[ $demo_name ]['front_page'],
						'post_type' => 'page',
						'post_status' => 'publish',
						'posts_per_page' => 1,
					)
				);

				if ( $front_page ) {
					$front_page = $front_page[0];
				}
				if ( isset( $front_page->ID ) ) {
					update_option( 'show_on_front', 'page' );
					update_option( 'page_on_front', $front_page->ID );
				}
			}

			// Trash the "Hello World" post
			wp_trash_post( 1 );

			if ( function_exists( 'wc_delete_product_transients' ) ) {
				wc_delete_product_transients();
			}

			// Set the permalink structure
			global $wp_rewrite;
			$wp_rewrite->set_permalink_structure( '/%postname%/' );
			update_option( 'us_flush_rules', TRUE, /* autoload */'yes' );

			us_demo_import_mark_step_done();
			wp_send_json_success();

		} else {
			wp_send_json_error(
				array(
					'message' => $file_path->get_error_message(),
				)
			);
		}
	}
}

// Images
if ( ! function_exists( 'us_import_content_images' ) ) {

	add_action( 'wp_ajax_us_import_content_images', 'us_import_content_images' );

	/**
	 * Imports the demo images, a portion per request
	 *
	 * The images take most of the installation time: every one is downloaded from the demo
	 * server and cut into sizes. Done within "All content" they kept a single request busy
	 * for minutes, long enough for a gateway to give up on it, while the wizard showed
	 * nothing but a spinner. So they go first and by portions: the wizard asks for the next
	 * one until the server reports the last, showing how far it has got.
	 *
	 * The content imported afterwards finds the images in place: WP_Import maps an
	 * attachment that already exists (by title and date) to its ID, so the featured images
	 * are remapped as usual, and the collected URL map is applied at the last step.
	 *
	 * @see us_demo_import_collect_state()
	 */
	function us_import_content_images() {
		if ( ! us_setup_wizard_verify_request() ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		// Nothing to do for the placeholders: they come along with the content
		if ( ! us_demo_import_with_images() ) {
			us_demo_import_mark_step_done();
			wp_send_json_success();
		}

		us_set_time_limit();

		// Every content file carries the whole media library, so the main one will do
		$file_path = us_upload_import_file( 'all_content' );

		if ( is_wp_error( $file_path ) ) {
			wp_send_json_error(
				array(
					'message' => $file_path->get_error_message(),
				)
			);
		}

		// Images per request: few enough to keep the request well within the usual gateway timeouts
		$per_request = 10;
		$offset = isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0;
		$total = 0;

		// The first portion starts a new installation: what an abandoned one has left behind
		// belongs to another demo, whose IDs would be taken for the IDs of this one
		if ( $offset === 0 ) {
			delete_transient( 'us_demo_import_post_orphans' );
		}

		// Only the attachments of this portion: the rest of the file comes with "All content"
		add_filter(
			'wp_import_posts', function ( $posts ) use ( $offset, $per_request, &$total ) {
				$attachments = array();
				foreach ( $posts as $post ) {
					if ( $post['post_type'] === 'attachment' ) {
						$attachments[] = $post;
					}
				}
				$total = count( $attachments );

				return array_slice( $attachments, $offset, $per_request );
			}
		);

		// The terms come with the content as well
		add_filter( 'wp_import_categories', '__return_empty_array' );
		add_filter( 'wp_import_tags', '__return_empty_array' );
		add_filter( 'wp_import_terms', '__return_empty_array' );

		$wp_import = us_demo_import_get_importer();

		// The theme thumbnails are cut at the last step, when the demo `img_size` is known
		$skip_theme_subsizes = class_exists( 'US_Regenerate_Thumbnails' );
		if ( $skip_theme_subsizes ) {
			add_filter( 'intermediate_image_sizes_advanced', 'us_demo_import_skip_theme_subsizes', 10, 2 );
		}

		ob_start();
		$wp_import->import( $file_path );
		ob_end_clean();

		if ( $skip_theme_subsizes ) {
			remove_filter( 'intermediate_image_sizes_advanced', 'us_demo_import_skip_theme_subsizes', 10 );
		}

		us_demo_import_collect_state( $wp_import );
		us_demo_import_collect_orphans( $wp_import );

		unlink( $file_path );

		// How far the step has got: the wizard asks for the next portion while there is one
		$result = array(
			'imported' => min( $offset + $per_request, $total ),
			'total' => $total,
		);

		us_demo_import_mark_step_done( $result );
		wp_send_json_success( $result );
	}
}

// Pages
if ( ! function_exists( 'us_import_content_pages' ) ) {

	add_action( 'wp_ajax_us_import_content_pages', 'us_import_content_pages' );

	function us_import_content_pages() {
		us_action_for_import( 'pages' );
	}
}

// Posts
if ( ! function_exists( 'us_import_content_posts' ) ) {

	add_action( 'wp_ajax_us_import_content_posts', 'us_import_content_posts' );

	function us_import_content_posts() {
		us_action_for_import( 'posts',  function() {
			wp_trash_post( 1 ); // trash Hello World Post
		} );
	}
}

// Portfolio
if ( ! function_exists( 'us_import_content_portfolio' ) ) {

	add_action( 'wp_ajax_us_import_content_portfolio', 'us_import_content_portfolio' );

	function us_import_content_portfolio() {
		if (
			! us_get_option( 'enable_portfolio' )
			AND function_exists( 'us_update_option' )
			AND function_exists( 'us_create_portfolio_post_type' )
		) {
			us_update_option( 'enable_portfolio', 1 );
			us_create_portfolio_post_type();
		}
		us_action_for_import( 'portfolio_items' );
	}
}

// Testimonials
if ( ! function_exists( 'us_import_content_testimonials' ) ) {

	add_action( 'wp_ajax_us_import_content_testimonials', 'us_import_content_testimonials' );

	function us_import_content_testimonials() {
		if (
			! us_get_option( 'enable_testimonials' )
			AND function_exists( 'us_update_option' )
			AND function_exists( 'us_create_testimonials_post_type' )
		) {
			us_update_option( 'enable_testimonials', 1 );
			us_create_testimonials_post_type();
		}
		us_action_for_import( 'testimonials' );
	}
}

// Headers
if ( ! function_exists( 'us_import_content_headers' ) ) {

	add_action( 'wp_ajax_us_import_content_headers', 'us_import_content_headers' );

	function us_import_content_headers() {
		us_action_for_import( 'headers' );
	}
}

// Grid Layouts
if ( ! function_exists( 'us_import_content_grid_layouts' ) ) {

	add_action( 'wp_ajax_us_import_content_grid_layouts', 'us_import_content_grid_layouts' );

	function us_import_content_grid_layouts() {
		us_action_for_import( 'grid_layouts' );
	}
}

// Reusable Blocks
if ( ! function_exists( 'us_import_content_page_blocks' ) ) {

	add_action( 'wp_ajax_us_import_content_page_blocks', 'us_import_content_page_blocks' );

	function us_import_content_page_blocks() {
		us_action_for_import( 'page_blocks' );
	}
}

// Page Templates
if ( ! function_exists( 'us_import_content_content_templates' ) ) {

	add_action( 'wp_ajax_us_import_content_content_templates', 'us_import_content_content_templates' );

	function us_import_content_content_templates() {
		us_action_for_import( 'content_templates' );
	}
}

// ACF fields
if ( ! function_exists( 'us_import_content_acf' ) ) {

	add_action( 'wp_ajax_us_import_content_acf', 'us_import_content_acf' );

	function us_import_content_acf() {
		us_action_for_import( 'acf_fields' );
	}
}

// WooCommerce Import
if ( ! function_exists( 'us_import_content_woocommerce' ) ) {

	add_action( 'wp_ajax_us_import_content_woocommerce', 'us_import_content_woocommerce' );

	function us_import_content_woocommerce() {
		if ( ! us_setup_wizard_verify_request() ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		us_set_time_limit();

		$file_path = us_upload_import_file( 'products' );

		if ( ! is_wp_error( $file_path ) ) {

			$wp_import = us_demo_import_get_importer();

			// Creating attributes taxonomies
			$parser = new WXR_Parser();
			$import_data = $parser->parse( $file_path );

			if ( isset( $import_data['posts'] ) ) {

				global $wpdb;

				foreach ( $import_data['posts'] as $post ) {

					if ( $post['post_type'] !== 'product' OR empty( $post['terms'] ) ) {
						continue;
					}

					foreach ( $post['terms'] as $term ) {

						if ( strpos( $term['domain'], 'pa_' ) === false ) {
							continue;
						}

						if ( taxonomy_exists( $term['domain'] ) ) {
							continue;
						}

						$attribute_name = wc_sanitize_taxonomy_name(
							str_replace( 'pa_', '', $term['domain'] )
						);

						// Create taxonomy if not exists
						$existing_attributes = wp_list_pluck( wc_get_attribute_taxonomies(), 'attribute_name' );

						if ( ! in_array( $attribute_name, $existing_attributes, TRUE ) ) {
							$wpdb->insert(
								$wpdb->prefix . 'woocommerce_attribute_taxonomies',
								array(
									'attribute_label' => $attribute_name,
									'attribute_name' => $attribute_name,
									'attribute_type' => 'select',
									'attribute_orderby' => 'menu_order',
									'attribute_public' => 1,
								)
							);

							delete_transient( 'wc_attribute_taxonomies' );
						}

						// Register taxonomy
						register_taxonomy(
							$term['domain'],
							apply_filters( 'woocommerce_taxonomy_objects_' . $term['domain'], array( 'product' ) ),
							apply_filters(
								'woocommerce_taxonomy_args_' . $term['domain'],
								array(
									'hierarchical' => TRUE,
									'show_ui' => FALSE,
									'query_var' => TRUE,
									'rewrite' => FALSE,
								)
							)
						);
					}
				}
			}

			// The theme thumbnails are cut at the last step, when the demo `img_size` is known
			$skip_theme_subsizes = ( us_demo_import_with_images() AND class_exists( 'US_Regenerate_Thumbnails' ) );
			if ( $skip_theme_subsizes ) {
				add_filter( 'intermediate_image_sizes_advanced', 'us_demo_import_skip_theme_subsizes', 10, 2 );
			}

			ob_start();
			$wp_import->import( $file_path );
			ob_end_clean();

			if ( $skip_theme_subsizes ) {
				remove_filter( 'intermediate_image_sizes_advanced', 'us_demo_import_skip_theme_subsizes', 10 );
			}

			if ( us_demo_import_with_images() ) {
				us_demo_import_collect_state( $wp_import );
				us_demo_import_backfill_attachment_parents( $wp_import );
			}

			// The product categories, when "All content" has not brought them already
			us_demo_import_remap_term_thumbnails( $wp_import );

			unlink( $file_path );

			if ( function_exists( 'wc_delete_product_transients' ) ) {
				wc_delete_product_transients();
			}
			us_demo_import_mark_step_done();
			wp_send_json_success();

		} else {
			wp_send_json_error(
				array(
					'message' => $file_path->get_error_message(),
				)
			);
		}
	}
}

// WooCommerce sales support, as the main import does not support this, we will check on the filter.
if ( ! function_exists( 'us_wp_import_post_meta' ) ) {

	add_filter( 'wp_import_post_meta', 'us_wp_import_post_meta', 10, 3 );

	function us_wp_import_post_meta( $postmeta, $post_id, $post ) {
		if ( empty( $postmeta ) OR empty( $post ) OR ! is_array( $postmeta ) OR ! is_array( $post ) ) {
			return false;
		}
		global $wpdb;
		if ( in_array( $post['post_type'], array( 'product', 'product_variation' ) ) ) {
			$postmeta_keys = array_flip( wp_list_pluck( $postmeta, 'key' ) );
			$postmeta_value = ( ! empty( $postmeta_keys['_sale_price'] ) ) ? us_arr_path( $postmeta, $postmeta_keys['_sale_price'] . '.value' ) : NULL;
			if ( ! empty( $postmeta_value ) ) {
				$sql = "
					SELECT
						`onsale`
					FROM {$wpdb->wc_product_meta_lookup}
					WHERE
						`product_id` = %s
						AND `onsale` = 1
					LIMIT 1;
				";
				if ( $wpdb->get_row( $wpdb->prepare( $sql, $post_id ) ) === NULL ) {
					$wpdb->insert(
						$wpdb->wc_product_meta_lookup, array(
							'product_id' => $post_id,
							'onsale' => 1,
							'max_price' => sprintf( '%0.2f', $postmeta_value ),
							'min_price' => sprintf( '%0.2f', $postmeta_value ),
							'stock_status' => 'instock',
						)
					);
				}
			}
		}

		return $postmeta;
	}
}

// Site settings
if ( ! function_exists( 'us_import_site_settings' ) ) {

	add_action( 'wp_ajax_us_import_site_settings', 'us_import_site_settings' );

	function us_import_site_settings() {
		if ( ! us_setup_wizard_verify_request() ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		us_set_time_limit();

		global $wpdb;
		$file_path = us_upload_import_file( 'options', 'json' );
		if ( ! is_wp_error( $file_path ) ) {
			$import_options = (array) json_decode( file_get_contents( $file_path ), TRUE );
			$allowed_options = array(
				'posts_per_page',
				'us_widget_areas',
				'sidebars_widgets',
				'usof_style_schemes_' . US_THEMENAME,
			);
			if ( $sidebars_widgets = (array) us_arr_path( $import_options, 'sidebars_widgets' ) ) {
				foreach( $sidebars_widgets as $sidebar ) {
					if ( is_array( $sidebar ) ) {
						foreach ( $sidebar as $widget_id ) {
							$allowed_options[] = sprintf( 'widget_%s', wp_parse_widget_id( $widget_id )['id_base'] );
						}
					}
				}
			}
			if ( class_exists( 'woocommerce' ) ) {
				$allowed_options = array_merge( $allowed_options, array(
					'woocommerce_shop_page_id',
					'woocommerce_cart_page_id',
					'woocommerce_checkout_page_id',
					'woocommerce_myaccount_page_id',
					'woocommerce_terms_page_id',
				) );
			}
			$allowed_options = array_unique( $allowed_options );
			foreach ( $import_options  as $option_name => $option_value ) {
				if ( in_array( $option_name, $allowed_options ) ) {

					// For settings with page ID use the page titles instead, because page IDs may change during import
					if ( substr( $option_name, -strlen( '_page_id' ) ) == '_page_id' ) {
						$option_value = $wpdb->get_var( $wpdb->prepare(
							"SELECT ID FROM $wpdb->posts WHERE post_title = %s AND post_type = 'page' AND post_status = 'publish'", $option_value
						) );
					}
					update_option( $option_name, $option_value );
				}
			}
			unlink( $file_path );

			us_demo_import_mark_step_done();
			wp_send_json_success();

		} else {
			wp_send_json_error(
				array(
					'message' => $file_path->get_error_message(),
				)
			);
		}
	}
}

// Theme Options
if ( ! function_exists( 'us_import_content_theme_options' ) ) {

	add_action( 'wp_ajax_us_import_content_theme_options', 'us_import_content_theme_options' );

	function us_import_content_theme_options() {
		if ( ! us_setup_wizard_verify_request() ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		if ( empty( get_option( 'usof_backup_' . US_THEMENAME, NULL )['usof_options'] ) ) {
			usof_backup();
		}

		$file_path = us_upload_import_file( 'theme_options', 'json' );

		if ( ! is_wp_error( $file_path ) ) {
			$updated_options = json_decode( file_get_contents( $file_path ), TRUE );

			if ( ! is_array( $updated_options ) ) {
				// Wrong file configuration
				wp_send_json(
					array(
						'success' => FALSE,
						'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
					)
				);
			}

			// Save custom settings
			foreach ( [ 'custom_css', 'custom_html', 'custom_html_head' ] as $custom_field ) {
				if ( isset( $updated_options[ $custom_field ] ) ) {
					$updated_options[ $custom_field ] = usof_get_option( $custom_field );
				}
			}

			usof_save_options( $updated_options );
			unlink( $file_path );

			us_demo_import_mark_step_done();
			wp_send_json_success();

		} else {
			wp_send_json_error(
				array(
					'message' => $file_path->get_error_message(),
				)
			);
		}
	}
}

// Rebuild the index table
if ( ! function_exists( 'us_import_rebuild_index_table' ) ) {

	add_action( 'wp_ajax_us_import_rebuild_index_table', 'us_import_rebuild_index_table' );

	function us_import_rebuild_index_table() {
		if ( ! us_setup_wizard_verify_request() ) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		if ( class_exists( 'US_Filter_Indexer' ) ) {
			$us_filter_indexer = US_Filter_Indexer::instance();

			if ( $us_filter_indexer->get_used_filter_params() ) {
				$us_filter_indexer->index();
			}
		}

		us_demo_import_mark_step_done();
		wp_send_json_success();
	}
}

// The last step of the demo installation
if ( ! function_exists( 'us_import_regenerate_thumbnails' ) ) {

	add_action( 'wp_ajax_us_import_regenerate_thumbnails', 'us_import_regenerate_thumbnails' );

	/**
	 * Remaps the collected image URLs and queues the imported images for the
	 * background thumbnails generation.
	 *
	 * The theme image sizes come from the `img_size` Theme Option, imported at a later
	 * step than the content, so this must be the last step of the installation.
	 *
	 * @see us_demo_import_collect_state()
	 * @see US_Regenerate_Thumbnails
	 */
	function us_import_regenerate_thumbnails() {
		if (
			! current_user_can( 'manage_options' )
			OR ! check_ajax_referer( 'us-setup-wizard-actions', 'security', FALSE )
		) {
			wp_send_json_error(
				array(
					'message' => us_translate( 'An error has occurred. Please reload the page and try again.' ),
				)
			);
		}

		// Otherwise there is nothing to remap or to regenerate: the demo images were not imported
		if ( us_demo_import_with_images() ) {

			// Now that every content file is imported, the URL map covers all of them
			us_demo_import_apply_url_remap();

			$imported_post_ids = get_transient( 'us_demo_import_post_ids' );
			delete_transient( 'us_demo_import_post_ids' );

			// The attachments whose parents no imported file has brought stay unattached
			delete_transient( 'us_demo_import_post_orphans' );

			if ( class_exists( 'US_Regenerate_Thumbnails' ) AND ! empty( $imported_post_ids ) ) {
				global $wpdb;

				// Only the imported images: the media the site already had is none of our business
				$image_ids = $wpdb->get_col(
					"SELECT ID FROM {$wpdb->posts}
					WHERE ID IN ( " . implode( ',', array_map( 'intval', (array) $imported_post_ids ) ) . " )
						AND post_type = 'attachment'
						AND post_status = 'inherit'
						AND post_mime_type IN ( 'image/jpeg', 'image/gif', 'image/png', 'image/webp' )"
				);

				if ( ! empty( $image_ids ) ) {
					$us_regenerate_thumbnails = US_Regenerate_Thumbnails::instance();

					foreach ( $image_ids as $image_id ) {
						$us_regenerate_thumbnails->push_to_queue( (int) $image_id );
					}

					/**
					 * Write the statistics BEFORE dispatching: dispatch() is non-blocking, so a
					 * short queue can complete and delete the option while we are still running
					 */
					$us_regenerate_thumbnails->set_stats_data( count( $image_ids ) );

					// The generation itself runs in the background, so do not wait for it here
					$us_regenerate_thumbnails->save()->dispatch();
				}
			}
		}

		us_demo_import_mark_step_done();
		wp_send_json_success();
	}
}

if ( ! function_exists( 'us_replace_post_list_term_slugs_with_ids' ) ) {
	/**
	 * Replacing term slugs with IDs in tax_query for "Loop" elements
	 */
	function us_replace_post_list_term_slugs_with_ids( $content ) {
		return preg_replace_callback(
			'/\[(us_post_list|us_post_carousel|us_product_list|us_product_carousel)([^\]]+?)tax_query="(.+?)"([^\]]*?)\]/',
			function ( $matches ) {

				if ( empty( $matches[3] ) ) {
					return $matches[0];
				}

				$tax_query = json_decode( rawurldecode( $matches[3] ), TRUE );

				if ( is_array( $tax_query ) ) {
					foreach ( $tax_query as &$query ) {
						if ( isset( $query['terms'] ) AND is_string( $query['terms'] ) ) {
							$term_slugs = explode( ',', $query['terms'] );
							$term_ids = array();

							foreach ( $term_slugs as $term_slug ) {
								if ( $term = get_term_by( 'slug', $term_slug, $query['taxonomy'] ) ) {
									$term_ids[] = $term->term_id;
								} else {
									$term_ids[] = '0';
								}
							}

							$query['terms'] = implode( ',', $term_ids );
						}
					}
				}

				$new_tax_query = rawurlencode( json_encode( $tax_query ) );

				return str_replace( $matches[3], $new_tax_query, $matches[0] );
			},
			$content
		);
	}
}
