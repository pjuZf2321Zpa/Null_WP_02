<?php return array('dependencies' => array('jquery'), 'version' => '7bbf26ef29213b54f93b');
