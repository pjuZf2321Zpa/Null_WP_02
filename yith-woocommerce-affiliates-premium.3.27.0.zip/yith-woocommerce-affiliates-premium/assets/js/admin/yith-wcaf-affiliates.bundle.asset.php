<?php return array('dependencies' => array('jquery'), 'version' => '5c3bbcc46e206f72141c');
