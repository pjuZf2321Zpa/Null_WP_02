<?php return array('dependencies' => array('jquery'), 'version' => '852b488c3532fb9cb02d');
