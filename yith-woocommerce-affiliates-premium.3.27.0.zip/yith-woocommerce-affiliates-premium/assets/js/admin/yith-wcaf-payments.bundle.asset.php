<?php return array('dependencies' => array('jquery'), 'version' => '78d8a28702bc61de9205');
