<?php return array('dependencies' => array('jquery'), 'version' => '8e24e1a5beb02b7c7d07');
