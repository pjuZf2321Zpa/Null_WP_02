<?php return array('dependencies' => array('jquery'), 'version' => 'edc3361920aac03fc289');
