<?php return array('dependencies' => array('jquery'), 'version' => '5b558d13b92de4ca8b3d');
