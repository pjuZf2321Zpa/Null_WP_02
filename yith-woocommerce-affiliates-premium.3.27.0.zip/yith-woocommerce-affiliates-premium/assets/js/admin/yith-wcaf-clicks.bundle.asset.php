<?php return array('dependencies' => array('jquery'), 'version' => '769c4eb88e346031a5c0');
