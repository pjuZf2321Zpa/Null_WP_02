Jannah 7.6.7 no longer ships these files inside the theme. They are kept here from 7.6.5:
- "Bundled Plugins": install each ZIP via Plugins > Add New > Upload Plugin.
- "Demos": demo-content-import-file.xml can be imported via Tools > Import > WordPress.
