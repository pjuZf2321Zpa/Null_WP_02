<?php

/**
 * WooCommerce Currency Switcher.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit ; // Exit if accessed directly.
}

use Automattic\WooCommerce\Utilities\NumberUtil;

if ( ! class_exists( 'FS_Woocommerce_Currency_Switcher' ) ) {

	/**
	 * Class FS_Woocommerce_Currency_Switcher
	 */
	class FS_Woocommerce_Currency_Switcher extends FS_Affiliates_Integrations {
				
		/**
		 * Class Constructor
		 */
		public function __construct() {
			$this->id    = 'woocommerce_currency_switcher' ;
			$this->title = __( 'WooCommerce Currency Switcher' , FS_AFFILIATES_LOCALE ) ;

			parent::__construct() ;
		}

		/*
		 * is enabled
		 */

		public function is_enabled() {

			return $this->is_plugin_enabled() && 'yes' === $this->enabled ;
		}

		/**
		 * Actions
		 */
		public function admin_action() {
			// ALter affiliate currency based on default currency.
			add_filter('fs_woocommerce_currency_switcher_enabled', array( $this, 'is_enabled' ), 10);
			add_filter('fs_affiliate_general_settings', array( $this, 'section_description' ), 10);
		}

		/**
		 * Actions
		 */
		public function actions() {
			add_filter( 'fs_affiliates_product_regular_price' , array( $this, 'alter_product_regular_price' ) , 10 , 3 ) ;
			// Convert the price based on default currency.
			add_filter('fs_convert_price', array( $this, 'convert_price' ), 10, 2);
			// Convert the price by currency based on default currency.
			add_filter('fs_convert_price_by_currency', array( $this, 'convert_price_by_currency' ), 10, 2);
			// Alter affiliate currency based on default currency.
			add_filter('fs_alter_affiliates_currency', array( $this, 'alter_affiliate_currency' ), 10);
			// Alter affiliate currency based on default currency.
			add_filter('fs_affiliates_currency_symbol', array( $this, 'alter_affiliate_currency_symbol' ), 10, 2);
			// Alter affiliate currency position based on default currency.
			add_filter('fs_alter_affiliate_currency_position', array( $this, 'alter_affiliate_currency_position' ), 10);
			// Alter affiliate currency price decimal number based on default currency.
			add_filter('fs_alter_affiliate_currency_price_decimal_number', array( $this, 'alter_affiliate_currency_price_decimal_number' ), 10);
		}

		/*
		 * Plugin enabled
		 */

		public function is_plugin_enabled() {
			$woocommerce = FS_Affiliates_Integration_Instances::get_integration_by_id( 'woocommerce' ) ;
			if ( class_exists( 'WOOCS' ) && $woocommerce->is_enabled() ) {
				return true ;
			}

			return false ;
		}

		/**
		 * May be alter the product regular price based on currency.
		 * 
		 * @return Float
		 */
		public function section_description( $settings ) {
			foreach ($settings as $key => $value) {
				if (isset($value['id'])) {
					if (in_array($value['id'], array( 'fs_affiliates_currency', 'fs_affiliates_currency_position', 'fs_affiliates_price_num_decimals' ))) {
						unset($settings[$key]);
					}

					if ($value['id'] === 'fs_affiliates_currency_options') {
						$settings[$key]['desc'] = sprintf(__('FOX - Currency Switcher Professional is activated. Hence, please set the default currency %s.', FS_AFFILIATES_LOCALE), '<a href="' . admin_url('admin.php?page=wc-settings&tab=woocs') . '">' . esc_html__('here', FS_AFFILIATES_LOCALE) . '</a>');
					}
				}
			}

			return $settings;
		}

		/**
		 * May be alter the product regular price based on currency.
		 * 
		 * @return Float
		 */
		public function alter_product_regular_price( $price, $item, $order ) {
			global $WOOCS ;
			if ( is_object( $WOOCS ) && $WOOCS->is_multiple_allowed ) {
				$current = $WOOCS->current_currency ;
				if ( $current != $WOOCS->default_currency ) {
					$currencies = $WOOCS->get_currencies() ;
					$rate       = $currencies[ $current ][ 'rate' ] ;
					$price      = NumberUtil::round(floatval($price / $rate), 6) ;
				}
			}

			return $price ;
		}

		/**
		 * Convert the price based on current currency in the site.
		 * 
		 * @since 11.5.0
		 * @param float/int $price
		 * @param bool $convert_to_default_currency
		 * @return float
		 */
		public function convert_price( $price, $convert_to_default_currency = false ) {
			if (!$price) {
				return $price;
			}

			global $WOOCS;
			if ( ! is_object( $WOOCS ) ) {
				return $price;
			}

			if ( $convert_to_default_currency ) {
				$currencies = $WOOCS->get_currencies();
				return ( floatval( $price ) / floatval( $currencies[ $WOOCS->get_woocommerce_currency() ]['rate'] ) ) * floatval( $currencies[ $WOOCS->default_currency ]['rate'] );
			}

			return $WOOCS->woocs_exchange_value( $price );
		}

		/**
		 * Convert the price by currency based on current currency in the site.
		 * 
		 * @since 11.5.0
		 * @param float/int $price        
		 * @return float
		 */
		public function convert_price_by_currency( $price, $currency ) {
			if ( ! $price || ! $currency ) {
				return $price;
			}

			global $WOOCS;
			if ( ! is_object( $WOOCS ) ) {
				return $price;
			}

			$current_currency = $WOOCS->get_woocommerce_currency();
			$WOOCS->set_currency( $currency );
			$price = $WOOCS->woocs_exchange_value( $price );
			$WOOCS->set_currency( $current_currency );

			return $price;
		}

		/**
		 * Alter Affiliate Currency.
		 * 
		 * @since 11.5.0
		 * @param string $currency        
		 * @return string
		 */
		public function alter_affiliate_currency( $currency ) {
			global $WOOCS;
			if ( ! is_object( $WOOCS ) ) {
				return $currency;
			}

			return $WOOCS->default_currency;
		}

		/**
		 * Alter Affiliate Currency Position
		 * 
		 * @since 11.5.0
		 * @param string $currency_position        
		 * @return string
		 */
		public function alter_affiliate_currency_symbol( $currency_symbol, $currency ) {
			global $WOOCS;
			if ( ! is_object( $WOOCS ) ) {
				return $currency_symbol;
			}

			global $WOOCS;
			if ( isset( $WOOCS->default_currency ) ) {
				$currencies = $WOOCS->get_currencies();
				$default_currency = $WOOCS->default_currency;

				return isset( $currencies[$default_currency]['symbol'] ) ? $currencies[$default_currency]['symbol'] : get_option( 'woocommerce_currency_symbol' );
			}

			return $currency_symbol;
		}

		/**
		 * Alter Affiliate Currency Position
		 * 
		 * @since 11.5.0
		 * @param string $currency_position        
		 * @return string
		 */
		public function alter_affiliate_currency_position( $currency_position ) {
			global $WOOCS;
			if ( ! is_object( $WOOCS ) ) {
				return $currency_position;
			}

			global $WOOCS;
			if ( isset( $WOOCS->default_currency ) ) {
				$currencies = $WOOCS->get_currencies();
				$default_currency = $WOOCS->default_currency;

				return isset( $currencies[$default_currency]['position'] ) ? $currencies[$default_currency]['position'] : get_option( 'woocommerce_currency_pos' );
			}

			return $currency_position;
		}

		/**
		 * Alter Affiliate Currency Position
		 * 
		 * @since 11.5.0
		 * @param int $decimals        
		 * @return int
		 */
		public function alter_affiliate_currency_price_decimal_number( $decimals ) {
			global $WOOCS;
			if ( ! is_object( $WOOCS ) ) {
				return $decimals;
			}

			global $WOOCS;
			if ( isset( $WOOCS->currencies ) ) {
				$default_currency = $WOOCS->default_currency;
				$currency_data = $WOOCS->currencies[$default_currency];

				$decimals = isset($currency_data['decimals']) ? $currency_data['decimals'] : wc_get_price_decimals();

				return $decimals;
			}

			return $decimals;
		}
	}

}
