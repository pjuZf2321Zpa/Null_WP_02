<?php
/**
 * Delete Affiliate Data
 *
 * @since 11.7.0
 * */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}
?>
<ul>
	<li>
		<label><?php esc_html_e('Delete Affiliate', FS_AFFILIATES_LOCALE); ?></label> 
		<input type="checkbox" name="fs_delete_affiliate_data" /></li>
</ul>
<?php
